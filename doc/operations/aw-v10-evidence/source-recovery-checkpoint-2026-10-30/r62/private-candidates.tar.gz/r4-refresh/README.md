# Parameterized private R4 final refresh

Preparation only. `refresh-r4-final.py` was syntax-parsed, not executed. No source hashes were refreshed, application/metadata source changed, bundles copied/rebuilt, tests run, or Main/Mirror writes performed. Host32 and Native final freeze/owner receipts remain pending; neither template contains a pass.

This helper reuses the existing R4 artifact owners and the Nov01 amendment's append-only policy. It consumes the R4 report, predecessor crosswalk, launch matrix, portable-source map and immutable baseline archive, plus the existing historical Nov01 amendment. It does not invoke the unsafe old portable-r3 generator (hardwired R3 destination, unconditional source-bundle deletion/rebuild), or rerun `build-amendment.py`'s stale R77/Host14.21/33-file selection. Those original scripts/artifacts remain unchanged historical inputs. The helper performs their needed final refresh operations directly on the existing artifact structures, with parameterized paths and exact reviewed pins.

## Inputs and bounded output

* Supply a clean exact final frozen Git worktree/HEAD. Unrelated untracked files may remain only under `doc/operations/aw-v10-evidence/`; a named source or receipt/input is never exempt. All refreshed source bytes come from the exact Git commit.
* Fill `baseline-pins.template.json` with the exact four existing R4 JSON hashes, original baseline archive hash and original amendment hash. No predecessor crosswalk, launch status or historical receipt is regenerated. The archive is streamed only for integrity at final execution, never recopied or rebuilt.
* Fill `final-owner-receipt-map.template.json` with the exact frozen head and reviewed `sourcePaths` to refresh. Source paths must be explicit, unique, tracked at that head, and nonempty. Historical evidence/bundle/predecessor paths cannot be masqueraded as current source. Unselected source pins remain explicitly historical; a selected refresh is not a claim that the entire old report was requalified.
* The three owner slots are `native9`, `host`, `guard`. Keep unavailable results as `state:pending`, `outcome:null`, `counts:null`, `receipts:[]`. A recorded entry requires exact final `frozenHead`, `outcome` passed/failed/inconclusive, `qualificationScope` software_component/software_managed_journey, a specific owner summary, and actual `{path,sha256}` receipts. Native9 passed additionally requires exact counts `{passed:9,failed:0,skipped:0,total:9,exitCode:0}`. No helper logic infers any result from source presence, test names, source-map membership or missing receipts.
* Recorded receipts must be compact workspace/repository sidecars (at most8MiB each; no raw database/provider-pack/archive copies). Their exact bytes are verified and copied into the new compact overlay. Owner declarations stay scoped declarations backed by receipts, never a new signed release/physical qualification.
* The output directory must not exist, must be under `/workspace/v10-preparation` and outside both the source worktree and baseline directory. It contains refreshed report/map/amendment, byte-identical predecessor crosswalk/launch matrix/historical amendment, compact owner receipts and checksums. The old baseline archive is retained by exact pinned reference. This is an additive metadata overlay requiring that immutable baseline, not a newly self-contained portable bundle or qualification upgrade.

## Concrete invocation after final freeze

Replace all angle-bracket values with reviewed final inputs; copy the templates to new final input filenames before filling them. The template's null values deliberately prevent accidental execution as a final refresh.

```sh
python3 /workspace/v10-preparation/r4-final-refresh-procedure-nov01/refresh-r4-final.py \
  --frozen-root '<clean-final-frozen-worktree>' \
  --expected-head '<exact-full-final-source-commit>' \
  --baseline-r4 /workspace/v10-preparation/v10-final-claim-reconciliation-candidate-r4-20261030 \
  --historical-amendment /workspace/v10-preparation/v10-nov01-claim-amendment/claim-amendment.json \
  --baseline-pins '<private-final-baseline-pins.json>' \
  --expected-baseline-pins-sha256 '<reviewed-baseline-map-SHA256>' \
  --owner-receipt-map '<private-final-owner-receipt-map.json>' \
  --expected-owner-map-sha256 '<reviewed-owner-map-SHA256>' \
  --output /workspace/v10-preparation/r4-final-refresh-procedure-nov01/final-refresh-overlay
```

No call to the old hardwired scripts, no manual 'adapt later' step and no destructive baseline copy are necessary. Parent can package the compact overlay alongside the existing exact baseline archive in its final evidence procedure.

## Preserved invariants and claim scope

The helper verifies that canonical register, R4 rows and launch rows contain exactly169 identical historical statuses with digest `e6630ae7f08def7034bdc1fc25fed68a8ea8ce216a9fe9938256a25eae06e19f`. It copies the predecessor crosswalk and launch matrix byte-for-byte, pins the original amendment, and asserts that every row's actualQualification, historicalEvidence, currentDisposition and currentReviewState remain unchanged. Historical failures and pending gates remain available; earlier 'latest' R77/Host14.21 facts are explicitly historical and never silently rewritten into final pass claims.

Only supplied sourcePaths hashes and exact source-pin state are refreshed. An appended owner-evidence section records actual final current receipts when supplied. Physical runtime, external provider/account/price/profile/route, hosted behavior, arbitrary restore, Human/operator and signed release gates remain open unless their independent owners supply evidence through their separate existing processes. An actual software Native9/Host/guard pass does not automatically close V10-149 or any of the other168 requirements.
