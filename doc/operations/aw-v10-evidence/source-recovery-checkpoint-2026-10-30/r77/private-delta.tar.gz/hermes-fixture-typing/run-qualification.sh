#!/bin/bash
set -euo pipefail
source /workspace/v10-preparation/env.sh
OUT=/workspace/v10-preparation/hermes-platform-skill-test-typing-nov01
set +e
/workspace/v10-dep-qualification/node_modules/.bin/tsc --noEmit --singleThreaded -p "$OUT/qualification-workspace/packages/adapters/hermes/tsconfig.json" > "$OUT/hermes-typecheck.log" 2>&1
status=$?
printf '%s\n' "$status" > "$OUT/hermes-typecheck.exit"
if [[ "$status" != 0 ]]; then tail -55 "$OUT/hermes-typecheck.log"; exit "$status"; fi
/workspace/v10-dep-qualification/node_modules/.bin/vitest run --config "$OUT/vitest.config.mjs" --reporter=verbose > "$OUT/hermes-whole-file.log" 2>&1
status=$?
printf '%s\n' "$status" > "$OUT/hermes-whole-file.exit"
tail -45 "$OUT/hermes-whole-file.log"
exit "$status"
