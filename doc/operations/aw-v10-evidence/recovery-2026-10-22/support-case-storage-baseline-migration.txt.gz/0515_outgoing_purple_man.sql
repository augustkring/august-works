CREATE TABLE "support_case_deletion_markers" (
	"subject_id" uuid PRIMARY KEY NOT NULL,
	"company_id" uuid NOT NULL,
	"case_id" uuid NOT NULL,
	"target_kind" text NOT NULL,
	"erased_at" timestamp with time zone DEFAULT now() NOT NULL,
	"retain_until" timestamp with time zone NOT NULL,
	CONSTRAINT "support_case_deletion_markers_target_check" CHECK (("support_case_deletion_markers"."target_kind"='case' and "support_case_deletion_markers"."subject_id"="support_case_deletion_markers"."case_id") or ("support_case_deletion_markers"."target_kind"='event' and "support_case_deletion_markers"."subject_id"<>"support_case_deletion_markers"."case_id")),
	CONSTRAINT "support_case_deletion_markers_horizon_check" CHECK ("support_case_deletion_markers"."retain_until">"support_case_deletion_markers"."erased_at")
);
--> statement-breakpoint
CREATE TABLE "support_case_events" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"company_id" uuid NOT NULL,
	"case_id" uuid NOT NULL,
	"author_user_id" text NOT NULL,
	"kind" text NOT NULL,
	"body" text NOT NULL,
	"customer_status" text NOT NULL,
	"safe_context" jsonb,
	"request_key" uuid NOT NULL,
	"request_hash" text NOT NULL,
	"delivery_state" text DEFAULT 'pending' NOT NULL,
	"delivery_attempt_id" uuid,
	"delivery_provider_key" text,
	"delivery_started_at" timestamp with time zone,
	"delivery_lease_until" timestamp with time zone,
	"delivered_at" timestamp with time zone,
	"provider_message_ref" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "support_case_events_kind_check" CHECK ("support_case_events"."kind" in ('request','customer_reply','support_message','status_change','resolution')),
	CONSTRAINT "support_case_events_body_check" CHECK (length(trim("support_case_events"."body")) between 1 and 10000),
	CONSTRAINT "support_case_events_status_check" CHECK ("support_case_events"."customer_status" in ('RECEIVED','INVESTIGATING','WORKING_ON_IT','WAITING_FOR_YOU','RESOLVED','CLOSED')),
	CONSTRAINT "support_case_events_hash_check" CHECK ("support_case_events"."request_hash" ~ '^[a-f0-9]{64}$'),
	CONSTRAINT "support_case_events_delivery_check" CHECK ("support_case_events"."delivery_state" in ('pending','sending','delivered','unknown','not_required') and
    (("support_case_events"."delivery_state"='delivered' and "support_case_events"."delivered_at" is not null) or ("support_case_events"."delivery_state"<>'delivered' and "support_case_events"."delivered_at" is null)) and
    ("support_case_events"."delivery_state"<>'sending' or ("support_case_events"."delivery_attempt_id" is not null and "support_case_events"."delivery_provider_key" is not null and "support_case_events"."delivery_started_at" is not null and "support_case_events"."delivery_lease_until" is not null)))
);
--> statement-breakpoint
CREATE TABLE "support_cases" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"company_id" uuid NOT NULL,
	"opened_by_user_id" text NOT NULL,
	"category" text DEFAULT 'other' NOT NULL,
	"subject" text NOT NULL,
	"description" text NOT NULL,
	"impact" text,
	"safe_context" jsonb,
	"follow_up_of_id" uuid,
	"customer_status" text DEFAULT 'RECEIVED' NOT NULL,
	"requested_response" text,
	"version" integer DEFAULT 0 NOT NULL,
	"data_policy" jsonb NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"last_message_at" timestamp with time zone DEFAULT now() NOT NULL,
	"legal_hold" boolean DEFAULT false NOT NULL,
	"hold_reason" text,
	"hold_release_at" timestamp with time zone,
	"provider_case_ref" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"resolved_at" timestamp with time zone,
	"closed_at" timestamp with time zone,
	CONSTRAINT "support_cases_category_check" CHECK ("support_cases"."category" in ('not_working','access','apps_connections','account_billing','using_blentera','other')),
	CONSTRAINT "support_cases_impact_check" CHECK ("support_cases"."impact" is null or "support_cases"."impact" in ('blocked','limited','question')),
	CONSTRAINT "support_cases_status_check" CHECK ("support_cases"."customer_status" in ('RECEIVED','INVESTIGATING','WORKING_ON_IT','WAITING_FOR_YOU','RESOLVED','CLOSED')),
	CONSTRAINT "support_cases_text_check" CHECK (length(trim("support_cases"."subject")) between 1 and 200 and length(trim("support_cases"."description")) between 1 and 10000),
	CONSTRAINT "support_cases_response_check" CHECK (("support_cases"."customer_status"='WAITING_FOR_YOU' and length(trim("support_cases"."requested_response")) between 1 and 10000) or ("support_cases"."customer_status"<>'WAITING_FOR_YOU' and "support_cases"."requested_response" is null)),
	CONSTRAINT "support_cases_hold_check" CHECK (("support_cases"."legal_hold" and length(trim("support_cases"."hold_reason")) between 1 and 1000) or (not "support_cases"."legal_hold" and "support_cases"."hold_reason" is null and "support_cases"."hold_release_at" is null)),
	CONSTRAINT "support_cases_version_check" CHECK ("support_cases"."version">=0),
	CONSTRAINT "support_cases_follow_up_check" CHECK ("support_cases"."follow_up_of_id" is null or "support_cases"."follow_up_of_id"<>"support_cases"."id")
);
--> statement-breakpoint
ALTER TABLE "support_case_events" ADD CONSTRAINT "support_case_events_author_user_id_user_id_fk" FOREIGN KEY ("author_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "support_case_events" ADD CONSTRAINT "support_case_events_company_id_case_id_support_cases_company_id_id_fk" FOREIGN KEY ("company_id","case_id") REFERENCES "public"."support_cases"("company_id","id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "support_cases" ADD CONSTRAINT "support_cases_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "support_cases" ADD CONSTRAINT "support_cases_opened_by_user_id_user_id_fk" FOREIGN KEY ("opened_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "support_cases" ADD CONSTRAINT "support_cases_company_id_follow_up_of_id_support_cases_company_id_id_fk" FOREIGN KEY ("company_id","follow_up_of_id") REFERENCES "public"."support_cases"("company_id","id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "support_case_deletion_markers_company_idx" ON "support_case_deletion_markers" USING btree ("company_id");--> statement-breakpoint
CREATE INDEX "support_case_deletion_markers_case_idx" ON "support_case_deletion_markers" USING btree ("case_id");--> statement-breakpoint
CREATE INDEX "support_case_deletion_markers_horizon_idx" ON "support_case_deletion_markers" USING btree ("retain_until");--> statement-breakpoint
CREATE UNIQUE INDEX "support_case_events_company_id_idx" ON "support_case_events" USING btree ("company_id","id");--> statement-breakpoint
CREATE UNIQUE INDEX "support_case_events_request_idx" ON "support_case_events" USING btree ("company_id","author_user_id","request_key");--> statement-breakpoint
CREATE INDEX "support_case_events_case_created_idx" ON "support_case_events" USING btree ("company_id","case_id","created_at","id");--> statement-breakpoint
CREATE INDEX "support_case_events_delivery_idx" ON "support_case_events" USING btree ("delivery_state","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "support_cases_company_id_idx" ON "support_cases" USING btree ("company_id","id");--> statement-breakpoint
CREATE INDEX "support_cases_company_created_idx" ON "support_cases" USING btree ("company_id","created_at","id");--> statement-breakpoint
CREATE INDEX "support_cases_opener_idx" ON "support_cases" USING btree ("opened_by_user_id","company_id");--> statement-breakpoint
CREATE INDEX "support_cases_expiry_idx" ON "support_cases" USING btree ("expires_at");