from pathlib import Path
import json,hashlib,shutil,subprocess
root=Path('/workspace/blentera-v10');src=Path('/workspace/v10-preparation/openshell-rt01-repo-integration-candidate')
paths=['third_party/openshell/rt01/'+name for name in ['openshell-rt01-expected-id.patch','source-pins.json','metadata.json','README.md']]
old=json.loads((root/'third_party/openshell/rt01/source-pins.json').read_text());new=json.loads((src/'third_party/openshell/rt01/source-pins.json').read_text())
assert old['patch']['sha256']=='bc7ea25a9c23a562707297a00d0da3adcb5e5cb527e2afb158db1e8bcf899cdc'
assert new['patch']['sha256']=='e28fc7fc8b860df810e7bf7337f59a53f2348e3595af6c883992d4ea09bc27d7'
assert hashlib.sha256((src/new['patch']['path']).read_bytes()).hexdigest()==new['patch']['sha256']
assert [p for p in old['files'] if old['files'][p]!=new['files'][p]]==['crates/openshell-server/src/grpc/sandbox.rs']
for rel in paths:shutil.copy2(src/rel,root/rel)
subprocess.run(['git','add','--',*paths],cwd=root,check=True)
print('Staged minimal API R4 test-only import correction with refreshed exact source pins.')
