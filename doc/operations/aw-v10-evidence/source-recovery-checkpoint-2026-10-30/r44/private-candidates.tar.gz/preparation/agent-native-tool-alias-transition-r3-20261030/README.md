# V10-122 alias transition private candidate r3

This candidate keeps all 38 current `paperclip-self:*` typed tool-name aliases active. The sidecar records each alias's manifest mapping, canonical tool ID, owner, authority mode, literal source/test consumer paths, and active lifecycle state. Shared transition state appears once: actual usage is unmeasured, external consumer inventory is unknown, no deprecation/sunset/retirement is approved, and runtime qualification remains source-only.

The binding is catalogue V10-122 plus §56.6 MIG-06. §21B.25 is for temporary raw REST/API/CLI fallbacks and does not apply to these typed aliases. The complete latest immutable Platform Skill release v3 registry record is checked against the live registry; its operation-manifest hash is separately verified against `agentNativeOperationManifestHash()`. The Skill release and operation contract are unchanged.

The declared source scan roots/extensions match the checker's actual constants. It inventories 17 literal alias consumer paths and separately pins 100 relevant runtime-instruction Markdown paths, including Skills and releases, platform Skill instructions, onboarding instructions, and built-in/adapter `SKILL.md` files. Instruction paths are not asserted to literally mention aliases when they do not. This is not telemetry and says nothing about external consumers or observed cadence.

Every distinct manifest alias owner file is source-pinned in addition to alias consumer, runtime-instruction, gateway/manifest, and release-registry paths. Mutation tests reject unreviewed alias removal/retargeting/duplication, lifecycle promotion, source/instruction path drift, stale/missing pins (including owner pins), and release/hash mismatch. No alias-removal test has been run; current gateway `tool_not_found` behavior for unavailable tools is not treated as alias-removal qualification.

No automatic retirement or universal time window is proposed. Any future transition requires observed consumer cadence, a usable canonical replacement with equivalent authority/idempotency/recovery on each claimed runtime, named owners and a migration plan, an actual no-dispatch/no-effect removal regression, and a tested rollback to the prior reviewed mapping. Rollback cannot undo external effects already performed.

Candidate validation: checker reports 38 active aliases, 17 literal consumer paths, 100 runtime-instruction paths, and 131 source pins. Node mutation tests pass 7/7. The candidate contains only the four listed source paths and makes no runtime/API/Skill changes.
