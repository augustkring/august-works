#!/usr/bin/env bash
set -euo pipefail
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH GOMEMLIMIT=1536MiB GOGC=50
out=/workspace/v10-preparation/resource-governance-current-typecheck-r6-20261030
main=/workspace/blentera-v10
mirror=/workspace/v10-dep-qualification
overlay=/workspace/v10-preparation/b-resource-0564-schema-overlay-20261029
companion=/workspace/v10-preparation/b-resource-governance-current.sql
reuse=/workspace/v10-preparation/resource-governance-qualified-r14-20261029
mkdir "$out"
# Cargo links in both workspaces target this regenerable cache location.
mkdir -p /tmp/blentera-preserved-current-rust-target
trap 'rc=$?; printf "%s\n" "$rc" > "$out/exit"; exit "$rc"' EXIT
# Verify the prior r5 exact cleanup receipt and preserved bytes before the
# fresh source snapshot. Do not repeat the unlink or alter any cleanup evidence.
python3 - "$main" "$mirror" "$out" <<'PYCHECK'
import pathlib,sys,json,hashlib,shutil
main,mirror,out=map(pathlib.Path,sys.argv[1:])
prep=pathlib.Path('/workspace/v10-preparation/responsibility-0565-overlay-pg-r2-20261030')
manifest_path=prep/'overlay-manifest.json'; receipt=prep/'cleanup-manifest.json'
assert receipt.is_file(), ('missing verified r2 cleanup receipt',str(receipt))
manifest=json.loads(manifest_path.read_text()); expected={x['path']:x['sha256'] for x in manifest}
proof=json.loads(receipt.read_text())
assert len(expected)==5 and len(proof.get('removedExactPaths',[]))==5, 'unexpected r2 cleanup receipt shape'
assert proof.get('cleanupPerformedUnderSharedLock') is True and proof.get('mainFilesAbsentAndPreservedBytesVerified') is True
assert proof.get('overlayManifestSha256')==hashlib.sha256(manifest_path.read_bytes()).hexdigest(), 'r2 cleanup receipt is for a different overlay manifest'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
rows={x['path']:x for x in proof['removedExactPaths']}
assert set(rows)==set(expected), 'r2 receipt paths differ from source manifest'
for rel,want in expected.items():
 row=rows[rel]; preserved=pathlib.Path(row['preservedExactPath']); mirror_path=mirror/rel
 assert not (main/rel).exists(), ('MAIN acquired a private-0565 path after cleanup',rel)
 assert not mirror_path.exists(), ('private-0565 mirror orphan reappeared',rel)
 assert row['expectedR2Sha256']==want and sha(preserved)==want and row['preservedSha256']==want, ('preserved r2 bytes mismatch',rel)
 assert format(preserved.stat().st_mode & 0o7777,'04o')==row['preservedMode'], ('preserved r2 mode mismatch',rel)
private_dir=mirror/'server/src/services/experience/private-0565'
left_code=sorted(p.relative_to(mirror).as_posix() for p in private_dir.rglob('*') if p.is_file() and p.suffix in {'.ts','.tsx','.js','.jsx'})
left_tests=sorted(p.relative_to(mirror).as_posix() for p in (mirror/'server/src/__tests__').glob('*private-0565*') if p.is_file() and p.suffix in {'.ts','.tsx','.js','.jsx'})
assert not left_code and not left_tests, ('private-0565 TS/JS orphans exist before snapshot',left_code,left_tests)
shutil.copyfile(receipt,out/'responsibility-r2-cleanup-manifest.json')
PYCHECK
python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$out/source-pins.json" > "$out/snapshot.log" 2>&1
python3 - "$main" "$mirror" "$overlay" "$out" <<'PY'
import pathlib,sys,json,hashlib,shutil
main,mirror,overlay,out=map(pathlib.Path,sys.argv[1:]); manifest=json.loads((overlay/'manifest.json').read_text())
for x in manifest:
 p=main/x['path']; assert hashlib.sha256(p.read_bytes()).hexdigest()==x['shelvedMainSha256'],('source changed since overlay review',x['path'])
 src=overlay/x['path']; assert hashlib.sha256(src.read_bytes()).hexdigest()==x['overlaySha256'],('overlay checksum mismatch',x['path'])
 dest=mirror/x['path']; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src,dest)
(out/'overlay-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
resource_paths=[
 'packages/shared/src/resource-governance.ts','packages/shared/src/resource-governance.test.ts','packages/shared/src/index.ts','packages/shared/src/validators/instance.ts',
 'packages/db/src/schema/index.ts','packages/db/src/schema/heartbeat_runs.ts','packages/db/src/schema/heartbeat_run_events.ts',
 'packages/db/src/schema/native_run_finalizations.ts','packages/db/src/schema/environment_leases.ts','packages/db/src/schema/workflows.ts','packages/db/src/schema/memory_jobs.ts',
 'server/src/errors.ts','server/src/middleware/error-handler.ts','server/src/routes/instance-settings.ts','server/src/routes/tool-gateway.ts','server/src/services/authorization.ts',
 'server/src/services/execution-blocker.ts','server/src/services/heartbeat.ts','server/src/services/instance-settings.ts',
 'server/src/services/resource-governance.ts','server/src/services/tool-gateway.ts','server/src/services/memory/memory-jobs.ts',
 'server/src/services/memory/memory-privacy.ts','server/src/services/memory/memory-retrieval.ts','server/src/services/workflows/workflow-executor.ts',
 'server/src/services/workflows/workflow-native-nodes.ts','server/src/__tests__/resource-governance.integration.test.ts',
 'server/src/__tests__/tool-gateway.test.ts','server/src/__tests__/helpers/embedded-postgres.ts','server/src/__tests__/helpers/current-human-source-fixture.ts']
pre={}
overlay_paths={x['path'] for x in manifest}
for rel in resource_paths:
 p=main/rel; mirrored=mirror/rel
 if p.is_file():
  pre[rel]=hashlib.sha256(p.read_bytes()).hexdigest()
  if rel not in overlay_paths: assert mirrored.is_file() and hashlib.sha256(mirrored.read_bytes()).hexdigest()==pre[rel],('resource source differs from qualification snapshot',rel)
 else:
  pre[rel]=None
  if rel not in overlay_paths: assert not mirrored.exists(),('resource source absence differs from qualification snapshot',rel)
(out/'resource-source-preconditions.json').write_text(json.dumps(pre,indent=2)+'\n')
syntax_pins=json.loads((out/'source-pins.json').read_text())
syntax_pins['copiedFiles']=[{'path':rel} for rel in resource_paths if (mirror/rel).is_file()]
for x in manifest:
 if x['path'].endswith(('.ts','.tsx','.js','.jsx')) and not any(i['path']==x['path'] for i in syntax_pins['copiedFiles']): syntax_pins['copiedFiles'].append({'path':x['path']})
(out/'resource-syntax-pins.json').write_text(json.dumps(syntax_pins,indent=2)+'\n')
(out/'source-before-migrations.json').write_text(json.dumps({str(p.relative_to(main)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (main/'packages/db/src/migrations').rglob('*') if p.is_file()},indent=2)+'\n')
PY
python3 - "$out" "$reuse" <<'PYREUSE'
import pathlib,sys,json,hashlib
out,reuse=map(pathlib.Path,sys.argv[1:])
current=json.loads((out/'resource-source-preconditions.json').read_text())
qualified=json.loads((reuse/'resource-source-preconditions.json').read_text())
changed={k:{'r14Sha256':qualified.get(k),'currentSha256':current.get(k)} for k in sorted(set(current)|set(qualified)) if current.get(k)!=qualified.get(k)}
approved_shared_barrel='packages/shared/src/index.ts'
approved_authorization='server/src/services/authorization.ts'
assert set(changed).issubset({approved_shared_barrel,approved_authorization}), ('manual rebase required for unexpected Resource precondition drift',changed)
assert current.get(approved_shared_barrel)=='8ced14d1d7882755ee69566c089a032727c74f02398b52e52e567ef1660988df', ('shared barrel differs from reviewed additive rebase',changed)
assert current.get(approved_authorization)=='04ba87abca957b5848689742d30e19e6a284d79c38938ee8686cf77457a78eff', ('authorization differs from root-approved typecheck rebase',changed)
# The current index retains the qualified customer-quality export and adds only the Resource barrel export.
import subprocess
main=pathlib.Path('/workspace/blentera-v10')
head_index=subprocess.check_output(['git','-C',str(main),'show','c080bfffb84350db24cd8a354fa5f5c58b4be11d:'+approved_shared_barrel])
current_index=(main/approved_shared_barrel).read_bytes()
resource_export=b'\nexport * from "./resource-governance.js";\n'
assert current_index.endswith(resource_export) and current_index.count(resource_export)==1, 'shared barrel rebase is not the reviewed Resource export'
assert hashlib.sha256(head_index).hexdigest()=='429ba633992678920dcf9aeeefc18687997e085bb20ea265099cad7985ffdf74', 'current qualification base index changed'
assert current_index[:-len(resource_export)]==head_index, 'shared barrel has additional unreviewed edits'
(out/'manual-rebase-preconditions.json').write_text(json.dumps({
 'rebase':'r14 Resource core reuses the unchanged owned implementation with the reviewed shared barrel export delta',
 'r14ResourcePreconditionsSha256':hashlib.sha256((reuse/'resource-source-preconditions.json').read_bytes()).hexdigest(),
 'currentResourcePreconditionsSha256':hashlib.sha256((out/'resource-source-preconditions.json').read_bytes()).hexdigest(),
 'changedResourcePreconditions':changed,
 'approvedAuthorizationTypecheckRebase':{'path':approved_authorization,'r14Sha256':qualified[approved_authorization],'currentSha256':current[approved_authorization],'rootApproval':'Resource task handoff 2026-10-30: auth 04ba87ab… is a type-only candidate'},
 'sharedBarrelRebase':{'path':approved_shared_barrel,'r14Sha256':qualified[approved_shared_barrel],'currentSha256':current[approved_shared_barrel]},
 'currentQualificationBase':'c080bfffb84350db24cd8a354fa5f5c58b4be11d',
 'qualificationBaseIndexSha256':hashlib.sha256(head_index).hexdigest(),
 'delta':'export * from "./resource-governance.js";',
 'customerQualityExportAlreadyPresentInQualificationBase':b'export * from "./customer-success-quality.js";' in head_index,
 'resourceOwnedPreconditionsUnchangedExceptRootApprovedDeltas':True
},indent=2)+'\n')
assert hashlib.sha256((out/'overlay-manifest.json').read_bytes()).hexdigest() == hashlib.sha256((reuse/'overlay-manifest.json').read_bytes()).hexdigest(), 'Resource overlay manifest changed since r14'
PYREUSE
node /workspace/v10-preparation/check-snapshot-syntax.cjs "$out/resource-syntax-pins.json" > "$out/syntax.log" 2>&1
cp "$companion" "$out/companion.sql"
sha256sum "$out/companion.sql" > "$out/companion.sha256"
cd "$mirror"
pnpm --filter @paperclipai/db generate > "$out/generate.log" 2>&1
python3 - "$mirror" "$out" <<'PY'
import pathlib,sys,json,shutil,hashlib
root,out=map(pathlib.Path,sys.argv[1:]); m=root/'packages/db/src/migrations'; j=json.loads((m/'meta/_journal.json').read_text()); e=j['entries'][-1]; assert e['idx']==564,e
sql=m/(e['tag']+'.sql'); assert sql.exists(); generated=sql.read_bytes(); (out/'generated.sql').write_bytes(generated)
reuse=pathlib.Path('/workspace/v10-preparation/resource-governance-qualified-r14-20261029')
assert hashlib.sha256(generated).hexdigest()==hashlib.sha256((reuse/'generated.sql').read_bytes()).hexdigest(), 'Generated Resource schema SQL differs from all-green r14'
preamble=b"-- Bounded Resource governance cutover; drain Native heartbeat/event writers. Any failure rolls the whole migration back without a journal row.\nSET LOCAL lock_timeout='5s';\n--> statement-breakpoint\nSET LOCAL statement_timeout='30s';\n--> statement-breakpoint\nLOCK TABLE heartbeat_runs IN ACCESS EXCLUSIVE MODE;\n--> statement-breakpoint\nLOCK TABLE heartbeat_run_events IN SHARE ROW EXCLUSIVE MODE NOWAIT;\n--> statement-breakpoint\n"
assembled=preamble+generated+b'\n--> statement-breakpoint\n'+(out/'companion.sql').read_bytes()
sql.write_bytes(assembled); (out/'assembled.sql').write_bytes(assembled)
(out/'migration-tag').write_text(e['tag']+'\n')
snap=m/'meta/0564_snapshot.json'; assert snap.exists(); shutil.copyfile(snap,out/'snapshot-0564.json')
PY
python3 - "$mirror" "$out" <<'PY2'
import pathlib,sys,json,hashlib
root,out=map(pathlib.Path,sys.argv[1:]); pins=json.loads((out/'source-pins.json').read_text()); rows=[]
source_before=json.loads((out/'source-before-migrations.json').read_text())
pruned=sorted(rel for rel in source_before if rel.endswith('_snapshot.json') and not (root/rel).exists())
for item in pins['copiedFiles']:
 rel=item['path']; p=root/rel
 if item.get('deleted'):
  assert not p.exists(),('deleted source unexpectedly present',rel); rows.append({'path':rel,'deleted':True}); continue
 if rel in pruned:
  rows.append({'path':rel,'deletedByDrizzleSnapshotPrune':True,'sourceSha256':source_before[rel]}); continue
 assert p.is_file(),('missing source in executed mirror',rel)
 rows.append({'path':rel,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
tag=(out/'migration-tag').read_text().strip(); migrations=root/'packages/db/src/migrations'
for p in [migrations/(tag+'.sql'),migrations/'meta/_journal.json',migrations/'meta/0564_snapshot.json']:
 assert p.is_file(),str(p); rows.append({'path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
for item in json.loads((out/'overlay-manifest.json').read_text()):
 p=root/item['path']; rows.append({'path':item['path'],'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'overlay':True})
(out/'qualified-tree-source-pins.json').write_text(json.dumps({'qualificationBaseCommit':pins['qualificationBaseCommit'],'sourceHead':pins['sourceHead'],'qualifiedWorkspace':str(root),'preOverlaySourcePinsSha256':hashlib.sha256((out/'source-pins.json').read_bytes()).hexdigest(),'overlayManifestSha256':hashlib.sha256((out/'overlay-manifest.json').read_bytes()).hexdigest(),'companionSqlSha256':hashlib.sha256((out/'companion.sql').read_bytes()).hexdigest(),'prunedSnapshots':pruned,'copiedFiles':rows},indent=2)+'\n')
PY2
pnpm --filter @paperclipai/db check:migrations > "$out/migration-check.log" 2>&1
pnpm --filter @paperclipai/db build > "$out/db-build.log" 2>&1
pnpm --filter @paperclipai/shared typecheck > "$out/shared-typecheck.log" 2>&1
node_modules/.bin/vitest run packages/shared/src/resource-governance.test.ts --reporter=verbose > "$out/shared-test.log" 2>&1
cat > "$out/preflight.mts" <<'MJS'
import fs from "node:fs";
import { createRequire } from "node:module";
const require = createRequire("/workspace/v10-dep-qualification/packages/db/package.json");
const postgres = require("postgres");
import { __startEmbeddedPostgresWithRetryForTests } from "/workspace/v10-dep-qualification/packages/db/src/test-embedded-postgres.ts";
const source = fs.readFileSync("/workspace/v10-preparation/b-resource-governance-current.sql", "utf8");
const functionSql = source.split("\n--> statement-breakpoint\n", 1)[0];
const { port, dataDir, instance } = await __startEmbeddedPostgresWithRetryForTests("resource-sql-preflight-");
const client = postgres(`postgres://paperclip:paperclip@127.0.0.1:${port}/postgres`);
try { await client.unsafe(functionSql); console.log("policy validation function parsed by embedded PostgreSQL"); }
finally {
  await client.end();
  await instance.stop().catch(() => {});
  fs.rmSync(dataDir, { recursive: true, force: true });
}
MJS
packages/db/node_modules/.bin/tsx "$out/preflight.mts" > "$out/sql-preflight.log" 2>&1
cp "$reuse/resource-pg-test.log" "$out/reused-r14-resource-pg-test.log"
cp "$reuse/gateway-test.log" "$out/reused-r14-gateway-test.log"
python3 - "$out" "$reuse" <<'PYREUSE'
import pathlib,sys,json,hashlib,re
out,reuse=map(pathlib.Path,sys.argv[1:])
resource=(reuse/'resource-pg-test.log').read_text(errors='replace')
gateway=(reuse/'gateway-test.log').read_text(errors='replace')
assert re.search(r'Tests\s+17 passed(?:\s*\(17\))?',resource), 'r14 Resource PG evidence not 17/17'
assert re.search(r'Tests\s+1 passed \| 74 skipped \(75\)',gateway), 'r14 gateway evidence not 1/1'
(out/'reused-r14-evidence.json').write_text(json.dumps({
 'qualification':'resource-governance-qualified-r14-20261029',
 'resourcePgTestLogSha256':hashlib.sha256((reuse/'resource-pg-test.log').read_bytes()).hexdigest(),
 'gatewayTestLogSha256':hashlib.sha256((reuse/'gateway-test.log').read_bytes()).hexdigest(),
 'resourcePreconditionsSha256':hashlib.sha256((reuse/'resource-source-preconditions.json').read_bytes()).hexdigest(),
 'overlayManifestSha256':hashlib.sha256((reuse/'overlay-manifest.json').read_bytes()).hexdigest(),
 'resourcePgPassed':17,'resourcePgFailed':0,'gatewayPassed':1,'gatewaySkipped':74
},indent=2)+'\n')
PYREUSE
pnpm --filter @paperclipai/server typecheck > "$out/server-typecheck.log" 2>&1
du -sb /tmp/blentera-preserved-current-rust-target > "$out/rust-target-bytes.txt"
python3 - "$main" "$mirror" "$out" "$overlay" <<'PY'
import pathlib,sys,json,hashlib,os
main,mirror,out,overlay=map(pathlib.Path,sys.argv[1:]); before=json.loads((out/'source-before-migrations.json').read_text())
pins=json.loads((out/'source-pins.json').read_text()); overlay_manifest=json.loads((out/'overlay-manifest.json').read_text()); overlays={x['path'] for x in overlay_manifest}
for item in pins['copiedFiles']:
 p=main/item['path']
 if item.get('deleted'):
  assert not p.exists(),('whole source changed after TSC snapshot',item['path'])
 else:
  assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],('whole source changed after TSC snapshot',item['path'])
qualified=json.loads((out/'qualified-tree-source-pins.json').read_text())
for item in qualified['copiedFiles']:
 p=mirror/item['path']
 if item.get('deleted') or item.get('deletedByDrizzleSnapshotPrune'):
  assert not p.exists(),('qualified deleted path reappeared',item['path'])
 else:
  assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],('qualified mirror source changed after pin',item['path'])
for x in overlay_manifest:
 assert hashlib.sha256((main/x['path']).read_bytes()).hexdigest()==x['shelvedMainSha256'],('overlay source changed during qualification',x['path'])
for rel,sha in json.loads((out/'resource-source-preconditions.json').read_text()).items():
 p=main/rel
 assert (not p.exists()) if sha is None else (p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==sha),('resource source changed during qualification',rel)
for rel,sha in before.items(): assert hashlib.sha256((main/rel).read_bytes()).hexdigest()==sha,('main migration source changed during qualification',rel)
tag=(out/'migration-tag').read_text().strip(); base=pathlib.Path('packages/db/src/migrations/')
pruned=json.loads((out/'qualified-tree-source-pins.json').read_text()).get('prunedSnapshots',[])
rels=[base/(tag+'.sql'),base/'meta/_journal.json',base/'meta/0564_snapshot.json'] + [pathlib.Path(p) for p in pruned]
for x in json.loads((out/'overlay-manifest.json').read_text()): rels.append(pathlib.Path(x['path']))
stage=out/'publish-staging'; stage.mkdir()
for rel in rels:
 src=mirror/rel; dst=stage/rel; dst.parent.mkdir(parents=True,exist_ok=True)
 if rel.as_posix() in pruned:
  assert not src.exists(),('snapshot should be pruned by official Drizzle generation',str(rel)); continue
 assert src.is_file(),str(src); dst.write_bytes(src.read_bytes())
# Publish only after all mirror checks passed; every destination is replaced from a complete staged file under this shared flock.
manifest=[]
for rel in rels:
 dst=main/rel
 if rel.as_posix() in pruned:
  assert dst.is_file() and hashlib.sha256(dst.read_bytes()).hexdigest()==before[str(rel)],('source snapshot changed before official prune',str(rel)); dst.unlink(); manifest.append({'path':str(rel),'deleted':True}); continue
 src=stage/rel; dst.parent.mkdir(parents=True,exist_ok=True); tmp=dst.with_name(dst.name+'.resource-governance-current-typecheck-r4-tmp'); tmp.write_bytes(src.read_bytes()); os.replace(tmp,dst)
 manifest.append({'path':str(rel),'sha256':hashlib.sha256(dst.read_bytes()).hexdigest()})
(out/'published-files.json').write_text(json.dumps(manifest,indent=2)+'\n')
PY
trap - EXIT
printf '0\n' > "$out/exit"
