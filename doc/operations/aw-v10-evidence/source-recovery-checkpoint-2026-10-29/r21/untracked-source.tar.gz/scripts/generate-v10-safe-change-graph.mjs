import { createHash } from "node:crypto";
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(fileURLToPath(new URL("..", import.meta.url)));
const manifestPath = "doc/operations/v10-safe-change-graph.source.json";
const outputPath = "doc/operations/v10-safe-change-graph.json";

export function buildGraph(manifest, read = (path) => readFileSync(resolve(root, path))) {
  const changes = manifest.changes.map((change) => ({
    ...change,
    sources: change.sourcePaths.map((path) => ({
      path,
      sha256: createHash("sha256").update(read(path)).digest("hex"),
    })),
  }));
  return {
    schemaVersion: 1,
    requirement: manifest.requirement,
    status: "scoped-source-transition-graph; not final V10 matrix",
    scope: manifest.scope,
    sourceIdentity: { commitSha: null, identityKind: "sha256_of_each_listed_source_file", releaseQualification: "not_claimed" },
    sourceManifest: manifestPath,
    qualificationBoundary: "File hashes identify the inspected working-tree bytes. They are not commit IDs, immutable release artifacts, external approval, or proof of performance/hosted behavior.",
    nodes: [
      ...changes.map(({ dependencies, changeId, ...node }) => ({ id: changeId, ...node, kind: "safe_change_record", dependencyIds: dependencies })),
      ...[...new Set(changes.flatMap((change) => change.dependencies))].map((dependencyId) => {
        const path = `packages/db/src/migrations/${dependencyId}`;
        return {
          id: dependencyId,
          kind: "existing_migration_dependency",
          path,
          sha256: createHash("sha256").update(readFileSync(resolve(root, path))).digest("hex"),
          qualification: "historical_sql_source_only",
        };
      }),
    ],
    edges: changes.flatMap((change) => change.dependencies.map((dependency) => ({
      from: change.changeId,
      to: dependency,
      relation: "migration-order-or-runtime-recovery-dependency",
    }))),
  };
}

const manifest = JSON.parse(readFileSync(resolve(root, manifestPath), "utf8"));
const rendered = `${JSON.stringify(buildGraph(manifest), null, 2)}\n`;
const check = process.argv.includes("--check");
if (check) {
  const current = readFileSync(resolve(root, outputPath), "utf8");
  if (current !== rendered) throw new Error(`${outputPath} is stale; regenerate from its source manifest and current source paths.`);
} else {
  mkdirSync(dirname(resolve(root, outputPath)), { recursive: true });
  writeFileSync(resolve(root, outputPath), rendered, "utf8");
}
