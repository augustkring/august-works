from pathlib import Path
import json,hashlib,subprocess
repo=Path('/workspace/blentera-v10');prep=Path('/workspace/v10-preparation');out=prep/'final-metadata-inventory-audit-nov01'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
canonical_sha=lambda v:hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
manifest=read(repo/'doc/operations/v10-safe-change-graph.source.json')
base=manifest['sourceBase']['commitSha'];groups={v['changeId'] for v in manifest['changes']};assert len(groups)==50
historical=read(repo/'doc/operations/aw-v10-evidence/recovery-2026-10-22/requirement-reconciliation.json')
statuses={v['id']:v['reconciliation'] for v in historical['items']};assert len(statuses)==169
assert canonical_sha(statuses)=='e6630ae7f08def7034bdc1fc25fed68a8ea8ce216a9fe9938256a25eae06e19f'
existing={p for g in manifest['changes'] for p in g['sourcePaths']}
oldplans=[prep/'safe-change-graph-final-guard-owner-plan-nov01.json',prep/'safe-change-graph-final-host-native-owner-plan-nov01.json']
excluded='server/src/__tests__/qualification-fixed-platform-echo.integration.test.ts'
planned={v['path']:dict(v) for p in oldplans for v in read(p)['additions'] if v['path']!=excluded}
inputs=[('guard_final55',prep/'final-paid-boundary-r56-nov01/source-pins.json','files'),('host26_lineage_pending_final_freeze',prep/'v10-149-r14.38.4.26-projection-c7-native-private/source-pins.json','sourceFiles'),('server_capability7',prep/'server-broker-capability-composition-nov01/source-pins.json','files'),('constructor2_overlap',prep/'server-broker-constructor-origin-followup-nov01/source-pins.json','files'),('native_r104',prep/'native-r103-clean-host26-overlay-r104/source-pins.json','files')]
coverage={};inputrecords=[]
for name,p,key in inputs:
 data=read(p); paths={v['path'] for v in data[key] if v['path']!=excluded};
 if name=='guard_final55':assert data['finalFileCount']==55 and len(paths)==55
 inputrecords.append({'id':name,'path':str(p),'sha256':sha(p),'pathCount':len(paths),'sourceFreezeDisposition':'reference-only; final Host/Native freeze and exact combined receipts pending'})
 for path in paths:coverage.setdefault(path,[]).append(name)
missing=sorted(set(coverage)-existing-set(planned));new=[];nonsource=[]
for path in missing:
 if path.startswith('doc/'):
  nonsource.append({'path':path,'disposition':'operational documentation; exclude from sourcePaths under existing source inventory boundary; retain as Help/source-review input where relevant'});continue
 if path in ['server/src/__tests__/generic-mcp-connection.test.ts','server/src/__tests__/remote-mcp-connectors.test.ts','server/src/__tests__/tool-gateway-connector-telemetry.test.ts']:
  group='SCR-V10-HOTSPOT-07';rationale='Existing connected tool owner tests retain protocol/telemetry behavior while rejecting opaque model effects before credentials/providers.'
 else:
  group='SCR-V10-NATIVE-RUNTIME-AND-AUTHORITY';rationale=('Installed Host runtime App/model profile discovery, exact binary/role/origin and current-capability composition.' if 'broker' in path or path.endswith('Dockerfile') else 'Native actual SDK qualifier and adapter pre-dispatch/setup source qualification; explicit opt-in and real protocol tests.')
 assert group in groups
 proc=subprocess.run(['git','cat-file','blob',base+':'+path],cwd=repo,capture_output=True)
 pin={'path':path,'baseCommitSha':base,'status':'present_at_base' if proc.returncode==0 else 'absent_at_base','sha256':hashlib.sha256(proc.stdout).hexdigest() if proc.returncode==0 else None}
 entry={'path':path,'existingOwnerGroup':group,'rationale':rationale,'sourceBeforePin':pin,'sourceSets':coverage[path],'candidateHashDisposition':'DO NOT refresh current/source-after hashes until final coherent freeze; consume owner-approved exact final bytes then regenerate'}
 new.append(entry);planned[path]=entry
all_additions=[v for p,v in sorted(planned.items()) if p not in existing]
assert all(v['existingOwnerGroup'] in groups for v in all_additions)
result={'schemaVersion':1,'status':'PRIVATE PREPARATION ONLY; no source manifest/generated graph/status mutation; final combined Host/Native hashes pending','sourceBase':base,'preservedGroupCount':50,'preservedHotspotCount':25,'historicalRequirementCount':169,'historicalStatusMapSha256':canonical_sha(statuses),'historicalRequirementsCrosswalkSha256':canonical_sha(manifest['requirementsCrosswalk']),'sourceManifestSha256':sha(repo/'doc/operations/v10-safe-change-graph.source.json'),'inputs':inputrecords,'inheritedOwnerPlanInputs':[{'path':str(p),'sha256':sha(p)} for p in oldplans],'exclusions':[{'path':excluded,'disposition':'NEVER_ADDED_UNPUBLISHED_COPY; remove proposed addition only, no deletedSourcePaths/base-deletion tombstone; existing original v7-sandbox-host-bridge.integration.test.ts remains canonical test owner'}]+nonsource,'newMissingSourcePaths':new,'consolidatedAdditions':all_additions,'coveredAlreadyByCurrentInventory':sorted(set(coverage)&existing),'coveredByEarlierPlans':sorted((set(coverage)-existing)&(set(planned)-{v['path'] for v in new})),'nativeAdapterAndSDKDisposition':{'qualifier':'packages/paperclip-runner/scripts/qualify-opencode-runtime.test.mjs needs explicit Native group addition','adapterPaths':['packages/paperclip-runner/src/drivers/opencode/opencode-server-driver.ts','packages/paperclip-runner/src/drivers/opencode/opencode-server-driver.test.ts'],'adapterInventory':'already represented; retain actual driver/qualifier baseline and final owner receipts; no synthetic SDK qualification or provider activation claim'},'followupOverlap':'constructor2 replaces capability7 versions of control.ts and component test; seven plus two = seven unique paths, not nine distinct source additions','freezeGates':['Final Host/current-target/health/C7 coherent source and exact receipts','Final Native R104 or successor source/actualSDK and full required journey receipts','Final55 stays immutable; exclude unapplied942 delta and copied test','Preserve sourceBase, all50 groups, all169 historical statuses and crosswalk digest; source trace links are not acceptance upgrades']}
(out/'updated-owner-plan.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'newSourcePaths':len(new),'consolidatedAdditions':len(all_additions),'excludedDocs':nonsource,'newPaths':[v['path'] for v in new],'statusDigest':canonical_sha(statuses),'crosswalkDigest':canonical_sha(manifest['requirementsCrosswalk'])},indent=2))
