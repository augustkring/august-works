from pathlib import Path
import hashlib,json,difflib
root=Path('/workspace/blentera-v10');out=Path('/workspace/v10-preparation/native-predicate-certificate-r64-candidate');rows={}
def save(rel,a,s):
 p=out/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);rows[rel]={'priorSha256':hashlib.sha256(a.encode()).hexdigest(),'candidateSha256':hashlib.sha256(s.encode()).hexdigest()};(out/(Path(rel).name+'.diff')).write_text(''.join(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
rel='server/src/services/authorization.ts';a=(root/rel).read_text();s=a
needle='''/** Return the already-owned page proof map only inside its exact active'''
helper='''/** Full effective temporal predicate, separate from the original owner
 * identity. This certifies equality only; it never supplies an allow decision
 * or changes the owner partition of page proofs and pinned source rows. */
export function activeMemoryTemporalReadScopePredicateIdentity(db: Db | DbTransaction,
  actor: AuthorizationActor, companyId: string): string | null {
  const scope = memoryTemporalReadScopes.getStore();
  if (!scope?.active || scope.db !== (db as object) || scope.companyId !== companyId ||
    scope.actorKey !== routineActorKey(actor)) return null;
  return createHash("sha256").update(JSON.stringify({ companyId: scope.companyId, actorKey: scope.actorKey,
    issueIds: [...scope.issueIds].sort(), runIds: [...scope.runIds].sort(),
    contextIds: [...scope.contextIds].sort() }), "utf8").digest("hex");
}

'''
assert s.count(needle)==1;s=s.replace(needle,helper+needle,1);save(rel,a,s)
rel='server/src/services/native-direct-input.ts';a=(root/rel).read_text();s=a
def rep(old,new):
 global s
 assert s.count(old)==1,(old[:100],s.count(old));s=s.replace(old,new,1)
rep('activeMemoryTemporalContexts, activeMemoryTemporalReadScopeIdentity,','activeMemoryTemporalContexts, activeMemoryTemporalReadScopeIdentity, activeMemoryTemporalReadScopePredicateIdentity,')
helper='''interface NativeSourcePredicateAlias { key: string; predicate: string; originalIdentity: string }
function nativeSourcePredicateCertificate(scope: NativeSourceReadScope, companyId: string,
  actor: AuthorizationActor): string | null {
  const context = scope.context;
  if (!context.active || nativeSourceReadScopes.getStore() !== context || !is(context.db, PgTransaction) ||
    context.ancestry.graphProofsDisabled || scope.actorKey !== nativeSha256(actor) ||
    !context.privacyLockedCompanies.has(companyId) || context.memoryTemporalIdentity === null ||
    context.memoryTemporalIdentity !== activeMemoryTemporalReadScopeIdentity(context.db as Db, actor)) return null;
  return activeMemoryTemporalReadScopePredicateIdentity(context.db as Db, actor, companyId);
}
function nativeSourcePredicateAlias(scope: NativeSourceReadScope, companyId: string, actor: AuthorizationActor,
  kind: string, binding: Record<string, unknown>): NativeSourcePredicateAlias | undefined {
  const predicate = nativeSourcePredicateCertificate(scope, companyId, actor);
  if (!predicate || !scope.context.memoryTemporalIdentity) return undefined;
  const exactBinding = { ...binding };
  delete exactBinding.memoryTemporalIdentity;
  return { key: `predicate-equivalent:${kind}:${nativeSha256({ predicate, binding: exactBinding })}`,
    predicate, originalIdentity: scope.context.memoryTemporalIdentity };
}
function nativeSourcePredicateAliasCurrent(scope: NativeSourceReadScope, companyId: string,
  actor: AuthorizationActor, alias: NativeSourcePredicateAlias | undefined): alias is NativeSourcePredicateAlias {
  return !!alias && alias.originalIdentity === scope.context.memoryTemporalIdentity &&
    alias.predicate === nativeSourcePredicateCertificate(scope, companyId, actor);
}
function recordNativePredicateVisit(scope: NativeSourceReadScope, companyId: string, actor: AuthorizationActor,
  key: string, alias?: NativeSourcePredicateAlias): string {
  // Keep the original visit key. The second key is cycle provenance for the
  // exact full predicate, including descendants retained by local shortcuts.
  const equivalent = nativeSourcePredicateAliasCurrent(scope, companyId, actor, alias) ? alias.key :
    scope.context.memoryTemporalIdentity === null && scope.context.active &&
    nativeSourceReadScopes.getStore() === scope.context && scope.actorKey === nativeSha256(actor) &&
    activeMemoryTemporalReadScopeIdentity(scope.context.db as Db, actor) === null ? key : undefined;
  const marker = equivalent ? `predicate-visit:${JSON.stringify([key, equivalent])}` : `predicate-uncertified:${key}`;
  for (const frame of scope.context.ancestry.frozenTaskProofStacks.get(scope.actorKey) ?? []) {
    if (equivalent) frame.descendants.add(equivalent);
    frame.descendants.add(marker);
  }
  return marker;
}
function nativePredicateDescendantClosureComplete(descendants: ReadonlySet<string>): boolean {
  const aliases = new Map<string, string>();
  for (const value of descendants) if (value.startsWith("predicate-uncertified:")) return false;
  for (const value of descendants) if (value.startsWith("predicate-visit:")) {
    let pair: unknown;
    try { pair = JSON.parse(value.slice("predicate-visit:".length)); } catch { return false; }
    if (!Array.isArray(pair) || pair.length !== 2 || pair.some(item => typeof item !== "string")) return false;
    const [key, alias] = pair as [string, string];
    if (aliases.has(key) && aliases.get(key) !== alias) return false;
    aliases.set(key, alias);
  }
  for (const value of descendants) {
    if (value.startsWith("predicate-visit:")) continue;
    if (/^(?:managed-consumed|payload-source-set|context-owner|native-tool-source):/.test(value)) {
      const alias = aliases.get(value);
      if (!alias || !descendants.has(alias)) return false;
    } else if (value.startsWith("predicate-equivalent:")) {
      if (![...aliases.values()].includes(value)) return false;
    } else if (!/^(?:frozen-task-snapshot|scoped-task-reader|manual-child|native-project-owner):/.test(value) &&
      !/^[0-9a-f-]{36}:[0-9a-f-]{36}$/.test(value)) return false;
  }
  return true;
}
'''
rep('async function withNativeSourceGraphProof(',helper+'async function withNativeSourceGraphProof(')
rep('''  historicalDocumentDepthHint = 0, deferSourceSetReader = true): Promise<void> {
  if (scope.active.has(key))''','''  historicalDocumentDepthHint = 0, deferSourceSetReader = true, predicateAlias?: NativeSourcePredicateAlias): Promise<void> {
  const equivalent = nativeSourcePredicateAliasCurrent(scope, input.companyId, input.actor, predicateAlias)
    ? predicateAlias : undefined;
  if (scope.active.has(key) || equivalent && scope.active.has(equivalent.key))''')
rep('''  const readPassKey = JSON.stringify([key, historicalDocumentDepthHint]);''','''  const readPassKey = JSON.stringify([key, historicalDocumentDepthHint]);
  const equivalentKey = equivalent ? JSON.stringify([equivalent.key, historicalDocumentDepthHint]) : undefined;
  const predicateVisit = recordNativePredicateVisit(scope, input.companyId, input.actor, key, equivalent);''')
rep('''    for (const retained of [memoryLedger?.get(readPassKey), ancestryLedger?.get(readPassKey)]) {''','''    for (const [retained, predicateReuse] of [
      [memoryLedger?.get(readPassKey), false], [ancestryLedger?.get(readPassKey), false],
      [equivalentKey ? ancestryLedger?.get(equivalentKey) : undefined, true],
    ] as const) {''')
rep('''      if (retained && (sameContext || obligations) &&
        !nativeFrozenTaskMemoWouldIntersectActiveAncestry''','''      if (retained && (sameContext || obligations) &&
        (!predicateReuse || nativePredicateDescendantClosureComplete(retained.descendants) &&
          nativePredicateDescendantClosureComplete(scope.active)) &&
        !nativeFrozenTaskMemoWouldIntersectActiveAncestry''')
rep('''        (sameContext || obligations && await replayNativeSourceGraphObligations(scope, obligations, retained.readerSets))) {''','''        (sameContext || obligations && await replayNativeSourceGraphObligations(scope, obligations, retained.readerSets)) &&
        (!predicateReuse || nativeSourcePredicateAliasCurrent(scope, input.companyId, input.actor, equivalent))) {''')
rep('''        proof = retained;
        break;''','''        proof = retained;
        if (predicateReuse && nativeSourceMemoDiagnosticsEnabled()) nativeSourceMemoDiagnostics.equivalentPredicateHits += 1;
        break;''')
rep('''  addNativeSourceActiveVisit(scope, key);
  const frame:''','''  addNativeSourceActiveVisit(scope, key);
  if (equivalent) addNativeSourceActiveVisit(scope, equivalent.key);
  scope.active.add(predicateVisit);
  const frame:''')
rep('''    scope.active.delete(key);
    if (stack.at(-1) === frame)''','''    scope.active.delete(key);
    if (equivalent) scope.active.delete(equivalent.key);
    scope.active.delete(predicateVisit);
    if (stack.at(-1) === frame)''')
rep('''        if (ancestryLedger && !scope.context.ancestry.graphProofsDisabled && ancestryLedger.size < 512)
          ancestryLedger.set(readPassKey, completedProof);''','''        if (ancestryLedger && !scope.context.ancestry.graphProofsDisabled && ancestryLedger.size < 512)
          ancestryLedger.set(readPassKey, completedProof);
        if (ancestryLedger && equivalentKey && completedProof.mutableSources.compatible &&
          nativeSourcePredicateAliasCurrent(scope, input.companyId, input.actor, equivalent) &&
          nativePredicateDescendantClosureComplete(completedProof.descendants) && ancestryLedger.size < 512)
          ancestryLedger.set(equivalentKey, completedProof);''')
rep('''  siblingToolSourceProofHits: 0, documentNodeHits:''','''  equivalentPredicateHits: 0,
  siblingToolSourceProofHits: 0, documentNodeHits:''')
rep('''  nativeSourceMemoDiagnostics.siblingToolSourceProofHits = 0;''','''  nativeSourceMemoDiagnostics.equivalentPredicateHits = 0;
  nativeSourceMemoDiagnostics.siblingToolSourceProofHits = 0;''')
# Each alias derives from the FULL original binding; original keys are unchanged.
rep('''  const completeKey = `payload-source-set:${nativeSha256({ companyId: input.companyId, issueId: input.issueId,
    runId: input.runId, actor: input.actor, actorScope: scope.actorKey, memoryTemporalIdentity: scope.context.memoryTemporalIdentity,
    policy: policy.data, inputs: inputs.data })}`;''','''  const binding = { companyId: input.companyId, issueId: input.issueId,
    runId: input.runId, actor: input.actor, actorScope: scope.actorKey, memoryTemporalIdentity: scope.context.memoryTemporalIdentity,
    policy: policy.data, inputs: inputs.data };
  const completeKey = `payload-source-set:${nativeSha256(binding)}`;
  const predicateAlias = nativeSourcePredicateAlias(scope, input.companyId, input.actor, "payload-source-set", binding);''')
rep('''  }, historicalDocumentDepthHint);
}

/** Validate a newly returned Native read result''','''  }, historicalDocumentDepthHint, true, predicateAlias);
}

/** Validate a newly returned Native read result''')
rep('''  const visitKey = `managed-consumed:${nativeSha256({ companyId: input.companyId, issueId: input.issueId,
    runId: input.runId, actor: input.actor, actorScope: scope.actorKey, memoryTemporalIdentity: scope.context.memoryTemporalIdentity, components: input.components, sourceSet: input.sourceSet })}`;''','''  const binding = { companyId: input.companyId, issueId: input.issueId,
    runId: input.runId, actor: input.actor, actorScope: scope.actorKey, memoryTemporalIdentity: scope.context.memoryTemporalIdentity,
    components: input.components, sourceSet: input.sourceSet };
  const visitKey = `managed-consumed:${nativeSha256(binding)}`;
  const predicateAlias = nativeSourcePredicateAlias(scope, input.companyId, input.actor, "managed-consumed", binding);''')
rep('''  }, () => assertNativeManagedConsumedSourceSetCurrentUncached(db, input, scope, siblingToolSourceProofs, historicalDocumentDepthHint), historicalDocumentDepthHint);''','''  }, () => assertNativeManagedConsumedSourceSetCurrentUncached(db, input, scope, siblingToolSourceProofs, historicalDocumentDepthHint),
    historicalDocumentDepthHint, true, predicateAlias);''')
rep('''    const ownerKey = `context-owner:${nativeSha256({ companyId, actor, actorScope: scope.actorKey,
      memoryTemporalIdentity: scope.context.memoryTemporalIdentity, source: contextSource,
      manifest, items: manifestItems, roots: manifestRoots, taskBindings,
      alreadyValidatedMemoryIds: [...alreadyValidatedMemoryIds].sort() })}`;''','''    const binding = { companyId, actor, actorScope: scope.actorKey,
      memoryTemporalIdentity: scope.context.memoryTemporalIdentity, source: contextSource,
      manifest, items: manifestItems, roots: manifestRoots, taskBindings,
      alreadyValidatedMemoryIds: [...alreadyValidatedMemoryIds].sort() };
    const ownerKey = `context-owner:${nativeSha256(binding)}`;
    const predicateAlias = nativeSourcePredicateAlias(scope, companyId, actor, "context-owner", binding);''')
rep('''    }, 0, false);
    // A hit carries''','''    }, 0, false, predicateAlias);
    // A hit carries''')
# Tool's Memory-sensitive visit also needs a predicate cycle alias; no Tool cache sharing is added.
rep('''      const toolSourceVisitKey = `native-tool-source:${nativeSha256({ companyId: input.companyId,
        issueId: producerRun.nativeIssueId, runId: source.runId, actor: input.actor, actorScope: scope.actorKey,
        memoryTemporalIdentity: scope.context.memoryTemporalIdentity, source,
        captureHash: nativeSha256(capture), producerClosures })}`;
      if (scope.active.has(toolSourceVisitKey))''','''      const toolBinding = { companyId: input.companyId,
        issueId: producerRun.nativeIssueId, runId: source.runId, actor: input.actor, actorScope: scope.actorKey,
        memoryTemporalIdentity: scope.context.memoryTemporalIdentity, source,
        captureHash: nativeSha256(capture), producerClosures };
      const toolSourceVisitKey = `native-tool-source:${nativeSha256(toolBinding)}`;
      const toolPredicateAlias = nativeSourcePredicateAlias(scope, input.companyId, input.actor, "native-tool-source", toolBinding);
      const toolPredicateVisit = recordNativePredicateVisit(scope, input.companyId, input.actor, toolSourceVisitKey, toolPredicateAlias);
      if (scope.active.has(toolSourceVisitKey) || toolPredicateAlias && scope.active.has(toolPredicateAlias.key))''')
rep('''      addNativeSourceActiveVisit(scope, toolSourceVisitKey);
      const siblingFrame:''','''      addNativeSourceActiveVisit(scope, toolSourceVisitKey);
      if (toolPredicateAlias) addNativeSourceActiveVisit(scope, toolPredicateAlias.key);
      scope.active.add(toolPredicateVisit);
      const siblingFrame:''')
rep('''        scope.active.delete(toolSourceVisitKey);
        if (siblingProofKey''','''        scope.active.delete(toolSourceVisitKey);
        if (toolPredicateAlias) scope.active.delete(toolPredicateAlias.key);
        scope.active.delete(toolPredicateVisit);
        if (siblingProofKey''')
rep('''        workByFamily: diagnostic.workByFamily,
        graph:''','''        workByFamily: diagnostic.workByFamily,
        equivalentPredicateHits: nativeSourceMemoDiagnostics.equivalentPredicateHits,
        equivalentPredicateEntries: [...scope.context.ancestry.graphProofs.keys()].filter(key => key.startsWith('["predicate-equivalent:')).length,
        graph:''')
save(rel,a,s)
(out/'manifest.json').write_text(json.dumps(rows,indent=2))
