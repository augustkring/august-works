## Thinking Path

> - Paperclip manages AI agents, Tasks and company operations.
> - Blentera extends this fork through its V10 master build brief.
> - The brief requires governed execution and current source access across the product.
> - Runtime, privacy and user experience changes must use the existing domain owners.
> - This pull request implements the pinned V10 brief and records scoped evidence.
> - The draft keeps the diff and CI visible while remaining acceptance failures are fixed.

## Linked Issues or Issue Description

**Problem or motivation**

The fork needs the Blentera V10 behavior defined in the supplied master build brief, revision 4.0. Existing execution, source privacy, settings and user flows need integrated changes and verification.

**Proposed solution**

Implement the pinned brief through the existing authorization, execution, Memory, Context, workflow, account and company services. Keep migrations forward-only. Record the implementation and evidence in the dated recovery ledger and upstream integration register.

**Roadmap alignment**

ROADMAP.md was reviewed. This is user-requested work for the Blentera fork. It overlaps with the upstream Memory, organizational learning and connected app directions. It is not a proposal to merge those features into upstream Paperclip. No external discussion was sent.

**Additional context**

Related fork PR: https://github.com/augustkring/august-works/pull/1 covers an earlier onboarding flow. This branch starts from fork master at 81d3445b98b1cd80ff400ede6bd44ea71d88d735. The pinned brief is doc/reference/blentera-v10/Blentera_Master_Build_Brief_V10_FINAL_v4.0_2026-10-18.md, SHA-256 7f4387338e6c9ce82359801a92c802c55b9af5c92cd65d1b6271f8ae68970c22.

## What Changed

- Build the Blentera V10 fork through the existing authorization, Task, Project, Native execution, Context, Memory, workflow, account and company services.
- Bind platform procedures, operation contracts, Role Pack tools, policy, approvals, budgets and source access to their original execution owners.
- Add connection and model controls, account privacy and enterprise identity flows, Support-to-Task, Trust, release notices and English/Danish Help.
- Bind OpenShell CPU, memory and PID limits to observed containers. Bind broker credentials to the signed executable profile. Add a pinned vendor patch for identity-bound lifecycle, policy, execution and provider calls.
- Add forward migrations through 0566. Preserve historical SQL and the repository's generated snapshot-pruning rules. Add bounded Resource accounting, responsibility scans, Human contact settings and consented Feedback quality measures.
- Add scheduled GitHub access snapshots and bounded recovery. Use known-object ETag/updated_at semantics; do not invent an unavailable global provider cursor.
- Add a read-only member responsibility/credential preflight. An incomplete preflight never delays removal or security revocation.
- Keep responsibility contact reads and writes with current Human Board owners/admins. Hide stale contact data and acknowledgements after company, account, session or authority changes.
- Inventory 998 mounted write/unknown client operations, six tools and 159 API-only contracts. Inventory metadata creates no tools or permissions.
- Record all 169 V10 work IDs, source boundaries, migration phases and the 25 production hotspots. Source links and scoped receipts do not establish release acceptance.

## Verification

Status on 2026-10-30: **draft; remaining implementation and final integration checks are open**. The latest pushed commit is `2969c06fe`. Recovery checkpoint r50 preserves current unfinished source and private candidates. It is a recovery record, not an acceptance pass. No merge or deployment has occurred.

Recent scoped qualifications on separately pinned source:

- Responsibility 0565: PostgreSQL 17/17, generated migration apply, server/UI typechecks and settings UI 10/10.
- Feedback 0566: PostgreSQL 44/44, UI 37/37, shared contract checks and server/UI typechecks. Optional consented ratings have immutable source receipts, withdrawal and erasure handling.
- Member preflight: PostgreSQL 2/2, UI 2/2, complete Company Access cohort 36/36 and server/UI typechecks. A further denied-refetch cache guard is under qualification.
- GitHub reconciliation: access 11/11, lifecycle 16/16, webhook 3/3, known-object recovery 13/13, package builds and server/UI typechecks.
- Human contact authority and UI privacy: targeted route 14/14, UI/API 23/23 and server/UI typechecks. Ten unrelated route cases were excluded by the focused test filter.
- Platform Skill migration: 239 sections from 26 source files across four explicitly scoped profiles. Selected Native/OpenClaw/Hermes source conformance covers 24 assertions; no live provider evaluation is claimed.
- Managed starter composite: 119/119 on its recorded source. Runtime cleanup: five managed cases and 24 matching host-agent cases on recorded source/binary/provider-pack pins.
- OpenShell resource and broker changes: 30 host checks, 66 policy/authentication checks, one broker resolver check, 13 PostgreSQL bridge checks, eight backend cases with the verified official prover, and shared/server typechecks. These are scoped software checks.
- The pinned OpenShell R5.1 patch passes source verification, formatting, compilation of the server, CLI, Docker driver and sandbox, and all 15 exact tests on `af29df32d`. Dedicated workflow: https://github.com/augustkring/august-works/actions/runs/41044296826. Full raw logs and source pins are committed under `doc/operations/aw-v10-evidence/openshell-rt01-runtime-guards-source-qualified-2026-10-30/`. This includes quota parsing, syscall behavior and real CLI transport refusal to use the legacy API after UNIMPLEMENTED. Physical enforcement remains unqualified.
- The cumulative OpenShell R6.1 patch passes all four package compilation checks and all 18 exact tests at `4f7894452d67dc76d7349c940217bdb0be39fb40`: https://github.com/augustkring/august-works/actions/runs/41051549768. This adds canonical create request identity, string-encoded PID limits, memory-swap limits, disabled Docker log storage and bounded idle/resource helper checks. Full source pins and raw logs are committed under `doc/operations/aw-v10-evidence/openshell-rt01-provisioning-source-qualified-2026-10-30/`. Physical enforcement remains unqualified.
- Sandbox qualification timestamp handling: 51 selected policy/fault tests and full server typecheck passed on the recorded two-file overlay. The original and current attestations must both remain valid through completion.
- Updated company-access Help: 14 Node checks, metadata/link validation and generated search-catalog check.

Each receipt under `doc/operations/aw-v10-evidence/` names its exact source boundary. Older receipts remain historical evidence. Independent scoped passes are not a final unchanged-head pass.

Required work before review readiness:

- Pass all nine Native retained-source integration cases. Current attempts still stop during fixture setup; eight cases remain skipped. Observed failures include the graph work limit, the MCP request deadline and the Context preparation deadline. The fix must retain fresh mutable-source checks, nested reader obligations, exact Task pins, depth limits and runtime Skill checks.
- Finish Native graph validation and the remaining OpenShell preparation, qualification-target and disposable credential-fixture integration. The remaining changes include a protected preflight descriptor and a bounded probe policy applied at creation, plus exact target receipts and one-use canary credentials. Their corrected integration tests remain pending. Software checks do not qualify a physical host.
- Run the full two-case Project and 42-case Learning cohorts after Native source freeze.
- Complete the current requirement/inherited-register crosswalk and refresh Help, operation coverage, migration phases and Safe Change source pins.
- Run workspace typecheck, tests, build and required CI on the final unchanged head. These final checks have not passed yet.

Human, installed-runtime, live provider, production population and release approval evidence remains separate from software qualification. Unsupported legacy private-source paths remain refused.

## Risks

This change spans authorization, private retained data, execution, migrations and UI. Existing migration budgets stop unsafe admission; production volume, lock behavior and mixed-version rollout still require operator evidence. Runtime profile isolation does not establish physical host isolation. The open integration checks prevent a ready-for-review claim. No merge, deployment or package publication is part of this PR.

## Model Used

OpenAI Codex assisted with repository inspection, code execution and tests. The root runtime exposes GPT-6 family identity but no exact revision or context-window value. Current delegated work uses `gpt-6-luna` with high reasoning and `gpt-6.1-sol` with medium reasoning. No Astra agents are used for the current work. The user-requested Ponytail skill guides implementation.

## Checklist

- [x] I have included a thinking path that traces from project context to this change
- [x] I have specified the model used and stated unavailable version details
- [ ] I have checked ROADMAP.md and confirmed this PR does not duplicate planned core work
- [x] I have searched GitHub for duplicate or related PRs and linked them above
- [x] I have described the issue in-PR following the relevant issue template
- [x] I have not referenced internal/instance-local Paperclip issues or links
- [x] My branch name describes the change and contains no internal issue id
- [ ] I have run tests locally and they pass
- [x] I have added or updated tests where applicable
- [x] I have updated relevant documentation to reflect my changes
- [x] I have considered and documented risks above
- [ ] All Paperclip CI gates are green
- [ ] Greptile is 5/5 with no open P2s, recommendations, or follow-ups
- [x] I will address reviewer comments before requesting merge

