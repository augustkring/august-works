import { and, eq, sql } from "drizzle-orm";
import { authUsers, companies, companyMemberships, routines, type Db } from "@paperclipai/db";
import type { ExperienceCard } from "@paperclipai/shared";
import { authorizationService, type AuthorizationActor } from "../authorization.js";
import { routineService } from "../routines.js";
import { nativeSha256 } from "../native-runtime/canonical.js";
import { resolveCurrentDefaultResponsibleHuman } from "../company-responsibility.js";
import { HttpError } from "../../errors.js";

const ROUTINE_SCAN_CAP = 200;

/** Projection only. It reads only routines currently visible to this manager;
 * hidden private routines contribute no kind, count, identity, or existence. */
export async function readRoutineResponsibilityAttention(db: Db, actor: AuthorizationActor, companyId: string,
  signal: AbortSignal): Promise<{ needsYou: ExperienceCard[]; coverage?: { state: "partial"; reason: "overflow" } }> {
  const empty = { needsYou: [] as ExperienceCard[] };
  if (actor.type !== "board" || !actor.userId || actor.source === "local_implicit") return empty;
  const viewerId = actor.userId;
  const currentActor = { ...actor, isInstanceAdmin: false, ignoreInstanceAdmin: true };
  return db.transaction(async tx => {
    await tx.execute(sql`set local statement_timeout='1000ms'`);
    await tx.execute(sql`set local lock_timeout='200ms'`);
    const auth = authorizationService(tx as unknown as Db);
    const current = async (principal: string, needsManager: boolean) => {
      signal.throwIfAborted();
      const [member] = await tx.select({ id: companyMemberships.id }).from(companyMemberships)
        .innerJoin(authUsers, and(eq(authUsers.id, companyMemberships.principalId), eq(authUsers.emailVerified, true)))
        .innerJoin(companies, and(eq(companies.id, companyMemberships.companyId), eq(companies.status, "active")))
        .where(and(eq(companyMemberships.companyId, companyId), eq(companyMemberships.principalType, "user"),
          eq(companyMemberships.principalId, principal), eq(companyMemberships.status, "active"))).limit(1);
      if (!member) return false;
      const principalActor: AuthorizationActor = { type: "board", source: "session", userId: principal,
        isInstanceAdmin: false, ignoreInstanceAdmin: true };
      if (!(await auth.decide({ actor: principalActor, action: "company_scope:read", resource: { type: "company", companyId },
        enforceResponsibleUserIntersection: true })).allowed) return false;
      return !needsManager || (await auth.decide({ actor: principalActor, action: "users:manage_permissions",
        resource: { type: "company", companyId }, enforceResponsibleUserIntersection: true })).allowed;
    };
    if (!await current(viewerId, true)) return empty;

    const candidates = await tx.select({ id: routines.id, responsibleUserId: routines.responsibleUserId,
      originKind: routines.originKind, originId: routines.originId, createdByAgentId: routines.createdByAgentId,
      updatedAt: routines.updatedAt }).from(routines).where(and(eq(routines.companyId, companyId),
        and(sql`${routines.status} in ('active','paused')`, sql`(${routines.originKind} <> 'conversation_draft' or ${routines.responsibleUserId} = ${actor.userId})`))).orderBy(routines.id).limit(ROUTINE_SCAN_CAP + 1);
    // The row cap is an operation limit before source ACL evaluation. A hit
    // fails closed without returning any object-derived count or kind.
    if (candidates.length > ROUTINE_SCAN_CAP) return { ...empty, coverage: { state: "partial", reason: "overflow" } };
    const defaultOwner = await resolveCurrentDefaultResponsibleHuman(tx as unknown as Db, companyId);
    const visibleOrphans: Array<{ id: string; updatedAt: Date; responsibleUserId: string | null }> = [];
    let visibleRows = 0;
    const sourceReader = routineService(tx as unknown as Db, { sourceActor: currentActor });
    for (const row of candidates) {
      signal.throwIfAborted();
      let visible;
      try { visible = await sourceReader.get(row.id); }
      catch (error) {
        if (error instanceof HttpError && [403, 404].includes(error.status)) continue;
        throw error;
      }
      if (!visible || visible.companyId !== companyId) continue;
      if (++visibleRows > ROUTINE_SCAN_CAP) return { ...empty, coverage: { state: "partial", reason: "overflow" } };

      let responsible = false;
      if (row.responsibleUserId) {
        responsible = await current(row.responsibleUserId, false);
        if (responsible) {
          try {
            const ownerReader = routineService(tx as unknown as Db, { sourceActor: {
              type: "board", source: "session", userId: row.responsibleUserId,
              isInstanceAdmin: false, ignoreInstanceAdmin: true,
            } });
            responsible = Boolean(await ownerReader.get(row.id));
          } catch (error) {
            if (error instanceof HttpError && [403, 404].includes(error.status)) responsible = false;
            else throw error;
          }
        }
      }
      if (!responsible && defaultOwner && defaultOwner !== row.responsibleUserId && await current(defaultOwner, false)) {
        try {
          const fallbackReader = routineService(tx as unknown as Db, { sourceActor: {
            type: "board", source: "session", userId: defaultOwner,
            isInstanceAdmin: false, ignoreInstanceAdmin: true,
          } });
          responsible = Boolean(await fallbackReader.get(row.id));
        } catch (error) {
          if (error instanceof HttpError && [403, 404].includes(error.status)) responsible = false;
          else throw error;
        }
      }
      if (!responsible) visibleOrphans.push({ id: row.id, updatedAt: row.updatedAt, responsibleUserId: row.responsibleUserId });
    }
    if (!visibleOrphans.length || !await current(viewerId, true)) return empty;
    const changedAt = visibleOrphans.reduce((latest, item) => item.updatedAt > latest ? item.updatedAt : latest, visibleOrphans[0]!.updatedAt);
    const source = { domain: "routine" as const, companyId, resourceId: "responsibility",
      version: nativeSha256(visibleOrphans.map(item => [item.id, item.updatedAt.toISOString(), item.responsibleUserId]).sort()), observedAt: new Date().toISOString() };
    return { needsYou: [{ id: `routine-responsibility:${companyId}`, kind: "recovery", source, freshness: "fresh",
      title: "Review routine responsibility", whyYou: "You manage this company's people and access. This review covers routines you are currently authorized to read.",
      consequence: `${visibleOrphans.length} visible routine${visibleOrphans.length === 1 ? " has" : "s have"} no active authorized responsible Human. Resolve responsibility through the routine owner flow; keep affected work paused when continuity is unresolved.`,
      evidence: ["routine_responsibility_authorized_subset_review", changedAt.toISOString()], actions: [{ id: "review-members", label: "Review company members", labelKey: "review",
        operation: "open", href: "/company/settings/members", criticality: "C3", source, requiresCurrentAuthorization: true }] }] };
  });
}
