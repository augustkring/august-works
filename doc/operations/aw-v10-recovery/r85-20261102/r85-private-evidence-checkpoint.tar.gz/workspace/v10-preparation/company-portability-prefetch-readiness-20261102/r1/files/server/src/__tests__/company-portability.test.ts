import { execFileSync } from "node:child_process";
import { createHash, randomUUID } from "node:crypto";
import { promises as fs } from "node:fs";
import os from "node:os";
import path from "node:path";
import { Readable } from "node:stream";
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import { authSessions, authUsers, companies, companyMemberships, createDb, documentRevisions, documents, EMBEDDED_POSTGRES_TEST_TIMEOUT_MS, issueDocuments, issueRelations, issues, principalPermissionGrants, projectWorkspaces, projects } from "@paperclipai/db";
import { and, eq } from "drizzle-orm";
import { getEmbeddedPostgresTestSupport, startEmbeddedPostgresTestDatabase } from "./helpers/embedded-postgres.js";
import type { CompanyPortabilityFileEntry, CompanyPortabilityImportRequest } from "@paperclipai/shared";

const companySvc = {
  getById: vi.fn(),
  // Async-empty default (not a bare vi.fn()): every new-company import reads
  // the existing names for de-duplication, including describes that never
  // touch this mock.
  list: vi.fn(async () => []),
  create: vi.fn(),
  update: vi.fn(),
};

const agentSvc = {
  list: vi.fn(),
  create: vi.fn(),
  update: vi.fn(),
};

const accessSvc = {
  ensureMembership: vi.fn(),
  ensureRoleDefaultGrants: vi.fn(),
  listActiveUserMemberships: vi.fn(),
  copyActiveUserMemberships: vi.fn(),
  setPrincipalPermission: vi.fn(),
};

const projectSvc = {
  list: vi.fn(),
  create: vi.fn(),
  update: vi.fn(),
  createWorkspace: vi.fn(),
  listWorkspaces: vi.fn(),
};

const issueSvc = {
  list: vi.fn(),
  listComments: vi.fn(),
  getById: vi.fn(),
  getByIdentifier: vi.fn(),
  create: vi.fn(),
  addComment: vi.fn(),
  listLabels: vi.fn(),
  createLabel: vi.fn(),
  getRelationSummaries: vi.fn(),
  listAttachments: vi.fn(),
  createAttachment: vi.fn(),
  importIssues: vi.fn(),
  archiveImportedInbox: vi.fn(),
  addImportedComments: vi.fn(),
  addImportedAttachments: vi.fn(),
};

const documentSvc = {
  listIssueDocuments: vi.fn(),
  upsertIssueDocument: vi.fn(),
  createIssueDocumentsForImport: vi.fn(),
};

const workProductSvc = {
  listForIssue: vi.fn(),
  createForIssue: vi.fn(),
  createManyForImport: vi.fn(),
};

const routineSvc = {
  list: vi.fn(),
  getDetail: vi.fn(),
  create: vi.fn(),
  createTrigger: vi.fn(),
};

const companySkillSvc = {
  list: vi.fn(),
  listFull: vi.fn(),
  readFile: vi.fn(),
  importPackageFiles: vi.fn(),
};

const assetSvc = {
  getById: vi.fn(),
  create: vi.fn(),
};

const secretSvc = {
  create: vi.fn(async () => ({ id: "secret-created" })),
  remove: vi.fn(async () => true),
  normalizeAdapterConfigForPersistence: vi.fn(async (_companyId: string, config: Record<string, unknown>) => config),
  normalizeEnvBindingsForPersistence: vi.fn(async (_companyId: string, env: Record<string, unknown>) => env),
  syncEnvBindingsForTarget: vi.fn(async () => []),
  resolveAdapterConfigForRuntime: vi.fn(async (_companyId: string, config: Record<string, unknown>) => ({ config, secretKeys: new Set<string>() })),
};

const agentInstructionsSvc = {
  exportFiles: vi.fn(),
  materializeManagedBundle: vi.fn(),
};

const instanceSettingsSvc = {
  getExperimental: vi.fn(async () => ({ enableNativeRunner: false })),
};

const managedAgentProfileSvc = {
  requireQualified: vi.fn(),
};

const remoteAgentProfileSvc = {
  requireQualified: vi.fn(),
};

// Unit-import cases use the same database transaction owner as production
// when embedded PostgreSQL is available; domain services stay focused mocks.
const unitImportDb = {} as { transaction<T>(callback: (tx: unknown) => Promise<T>): Promise<T> };
unitImportDb.transaction = async callback => callback(unitImportDb);

vi.mock("../services/companies.js", () => ({
  companyService: () => companySvc,
}));

vi.mock("../services/agents.js", () => ({
  agentService: () => agentSvc,
}));

vi.mock("../services/access.js", () => ({
  accessService: () => accessSvc,
}));

vi.mock("../services/projects.js", () => ({
  projectService: () => projectSvc,
}));

vi.mock("../services/issues.js", () => ({
  issueService: () => issueSvc,
  lockIssuePrivacyTree: vi.fn(async () => undefined),
}));

vi.mock("../services/documents.js", () => ({
  documentService: () => documentSvc,
  extractLegacyPlanBody: () => null,
  mapIssueDocumentRow: (row: unknown) => row,
  issueDocumentSelect: {},
}));

vi.mock("../services/work-products.js", () => ({
  workProductService: () => workProductSvc,
  toIssueWorkProduct: (row: unknown) => row,
}));

vi.mock("../services/routines.js", () => ({
  routineService: () => routineSvc,
}));

vi.mock("../services/company-skills.js", () => ({
  companySkillService: () => companySkillSvc,
}));

vi.mock("../services/assets.js", () => ({
  assetService: () => assetSvc,
}));

vi.mock("../services/secrets.js", () => ({
  secretService: () => secretSvc,
}));

vi.mock("../services/agent-instructions.js", () => ({
  agentInstructionsService: () => agentInstructionsSvc,
  agentInstructionsBundleMode: (agent: { adapterConfig?: unknown }) => {
    const config = agent.adapterConfig as Record<string, unknown> | undefined;
    return config?.instructionsBundleMode === "external" ? "external" : "managed";
  },
}));

vi.mock("../services/instance-settings.js", () => ({
  instanceSettingsService: () => instanceSettingsSvc,
}));

vi.mock("../services/managed-agent-profiles.js", () => ({
  managedAgentProfileService: () => managedAgentProfileSvc,
}));

vi.mock("../services/remote-agent-profiles.js", () => ({
  remoteAgentProfileService: () => remoteAgentProfileSvc,
}));

vi.mock("../routes/org-chart-svg.js", () => ({
  renderOrgChartPng: vi.fn(async () => Buffer.from("png")),
}));

const { companyPortabilityService, ImportCancellationError, dedupeImportedCompanyName, parseGitHubSourceUrl, renderYamlBlock, renderFrontmatter } = await import("../services/company-portability.js");

const nativePostgresSupport = await getEmbeddedPostgresTestSupport();
const itNative = nativePostgresSupport.supported ? it : it.skip;

function asTextFile(entry: CompanyPortabilityFileEntry | undefined) {
  expect(typeof entry).toBe("string");
  return typeof entry === "string" ? entry : "";
}

describe("company portability", () => {
  const nativeCompanyId = "b7071652-fd3a-4a30-b755-7c3b5651371c";
  const nativeUserId = "portability-current-human";
  const nativeActor = { type: "board" as const, userId: nativeUserId, source: "session" as const };
  let nativeFixture: Awaited<ReturnType<typeof startEmbeddedPostgresTestDatabase>> | undefined;
  let nativeDb: ReturnType<typeof createDb>;

  function unitImportPortability() {
    return companyPortabilityService(nativePostgresSupport.supported ? nativeDb : unitImportDb as never);
  }

  // Formatting services stay mocked; source admission uses the real canonical
  // owner and current Human membership, without an implicit actor or auth mock.
  beforeAll(async () => {
    if (!nativePostgresSupport.supported) return;
    nativeFixture = await startEmbeddedPostgresTestDatabase("paperclip-portability-format-actor-");
    nativeDb = createDb(nativeFixture.connectionString);
    await nativeDb.insert(companies).values({ id: nativeCompanyId, name: "Paperclip", issuePrefix: "PAP" });
    await nativeDb.insert(authUsers).values({ id: nativeUserId, name: "Current exporter",
      email: "portability-current@example.test", emailVerified: true, createdAt: new Date(), updatedAt: new Date() });
    await nativeDb.insert(companyMemberships).values({ companyId: nativeCompanyId, principalType: "user",
      principalId: nativeUserId, status: "active", membershipRole: "owner" });
  }, EMBEDDED_POSTGRES_TEST_TIMEOUT_MS);
  afterAll(async () => { await nativeFixture?.cleanup(); });

  const paperclipKey = "paperclipai/paperclip/paperclip";
  const companyPlaybookKey = "company/company-1/company-playbook";
  function useNativeExportCompany(overrides: Record<string, unknown> = {}) {
    companySvc.getById.mockResolvedValue({
      id: nativeCompanyId,
      name: "Paperclip",
      description: null,
      issuePrefix: "PAP",
      logoAssetId: null,
      logoUrl: null,
      requireBoardApprovalForNewAgents: false,
      ...overrides,
    });
  }

  const sourceFixtureWrapper = Symbol("sourceFixtureWrapper");
  const nativeSourceIdAliases = new Map<string, string>();
  function nativeSourceUuid(kind: string, sourceId: string) {
    const raw = createHash("sha256").update(`${kind}:${sourceId}`).digest("hex").slice(0, 32).split("");
    raw[12] = "4";
    raw[16] = "8";
    const hex = raw.join("");
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
  }

  async function seedProjectSource(id: string) {
    await nativeDb.insert(projects).values({ id, companyId: nativeCompanyId, name: `Source ${id}`,
      visibility: "open", privacyOwnerUserId: nativeUserId, personalOwnerUserId: null,
      sourceIssueIds: [], sourceProjectIds: [], sourceProvenanceQualified: true }).onConflictDoNothing();
  }

  function nativeWorkspaceUuid(projectId: string, sourceWorkspaceId: string) {
    return nativeSourceUuid("workspace", `${projectId}:${sourceWorkspaceId}`);
  }

  async function seedProjectWorkspaceSource(projectId: string, workspace: Record<string, any>) {
    const id = nativeWorkspaceUuid(projectId, String(workspace.id));
    await nativeDb.insert(projectWorkspaces).values({ id, companyId: nativeCompanyId, projectId,
      name: String(workspace.name ?? "Source workspace"), sourceType: String(workspace.sourceType ?? "local_path"),
      cwd: typeof workspace.cwd === "string" ? workspace.cwd : null,
      repoUrl: typeof workspace.repoUrl === "string" ? workspace.repoUrl : null,
      repoRef: typeof workspace.repoRef === "string" ? workspace.repoRef : null,
      defaultRef: typeof workspace.defaultRef === "string" ? workspace.defaultRef : null,
      visibility: String(workspace.visibility ?? "default"), setupCommand: typeof workspace.setupCommand === "string" ? workspace.setupCommand : null,
      cleanupCommand: typeof workspace.cleanupCommand === "string" ? workspace.cleanupCommand : null,
      remoteProvider: typeof workspace.remoteProvider === "string" ? workspace.remoteProvider : null,
      remoteWorkspaceRef: typeof workspace.remoteWorkspaceRef === "string" ? workspace.remoteWorkspaceRef : null,
      sharedWorkspaceKey: typeof workspace.sharedWorkspaceKey === "string" ? workspace.sharedWorkspaceKey : null,
      metadata: workspace.metadata ?? null, isPrimary: workspace.isPrimary === true }).onConflictDoNothing();
    return id;
  }

  async function normalizeProjectExportSources(rows: unknown) {
    if (!Array.isArray(rows)) return [];
    const normalized = [];
    for (const source of rows as Array<Record<string, any>>) {
      const id = typeof source.id === "string" && /^[0-9a-f-]{36}$/i.test(source.id) ? source.id : nativeSourceUuid("project", String(source.id));
      if (typeof source.id === "string") nativeSourceIdAliases.set(id, source.id);
      await seedProjectSource(id);
      const sourceWorkspaces = Array.isArray(source.workspaces) ? source.workspaces as Array<Record<string, any>> : [];
      const normalizedWorkspaces = [];
      for (const workspace of sourceWorkspaces) {
        const workspaceId = await seedProjectWorkspaceSource(id, workspace);
        normalizedWorkspaces.push({ ...workspace, id: workspaceId, companyId: nativeCompanyId, projectId: id });
      }
      const policy = source.executionWorkspacePolicy && typeof source.executionWorkspacePolicy === "object"
        ? source.executionWorkspacePolicy as Record<string, any> : null;
      const defaultWorkspace = policy?.defaultProjectWorkspaceId;
      normalized.push({ ...source, id, companyId: nativeCompanyId, visibility: "open", privacyOwnerUserId: nativeUserId,
        personalOwnerUserId: null, sourceIssueIds: [], sourceProjectIds: [], sourceProvenanceQualified: true,
        executionWorkspacePolicy: policy && typeof defaultWorkspace === "string"
          ? { ...policy, defaultProjectWorkspaceId: nativeWorkspaceUuid(id, defaultWorkspace) } : source.executionWorkspacePolicy,
        workspaces: Array.isArray(source.workspaces) ? normalizedWorkspaces : source.workspaces });
    }
    return normalized;
  }

  async function normalizeIssueExportSources(rows: unknown) {
    if (!Array.isArray(rows)) return [];
    const normalized = [];
    for (const source of rows as Array<Record<string, any>>) {
      const id = typeof source.id === "string" && /^[0-9a-f-]{36}$/i.test(source.id) ? source.id : nativeSourceUuid("issue", String(source.id));
      if (typeof source.id === "string") nativeSourceIdAliases.set(id, source.id);
      const sourceProjectId = typeof source.projectId === "string" && source.projectId !== ""
        ? (/^[0-9a-f-]{36}$/i.test(source.projectId) ? source.projectId : nativeSourceUuid("project", source.projectId)) : null;
      if (sourceProjectId) await seedProjectSource(sourceProjectId);
      const rawParentId = typeof source.privacyParentIssueId === "string" ? source.privacyParentIssueId : source.parentId;
      const privacyParentIssueId = typeof rawParentId === "string"
        ? (/^[0-9a-f-]{36}$/i.test(rawParentId) ? rawParentId : nativeSourceUuid("issue", rawParentId)) : null;
      const privacyRootIssueId = typeof source.privacyRootIssueId === "string"
        ? (/^[0-9a-f-]{36}$/i.test(source.privacyRootIssueId) ? source.privacyRootIssueId : nativeSourceUuid("issue", source.privacyRootIssueId)) : id;
      const privacySources = Array.isArray(source.privacySources) ? source.privacySources.map((entry: any) => ({ ...entry,
        sourceId: typeof entry.sourceId === "string" && !/^[0-9a-f-]{36}$/i.test(entry.sourceId)
          ? nativeSourceUuid(entry.sourceKind === "project" ? "project" : "issue", entry.sourceId) : entry.sourceId })) : [];
      const projectWorkspaceId = sourceProjectId && typeof source.projectWorkspaceId === "string"
        ? nativeWorkspaceUuid(sourceProjectId, source.projectWorkspaceId) : source.projectWorkspaceId ?? null;
      const number = Number.parseInt(createHash("sha256").update(id).digest("hex").slice(0, 7), 16) % 900_000_000 + 1;
      await nativeDb.insert(issues).values({ id, companyId: nativeCompanyId, projectId: sourceProjectId, title: String(source.title ?? "Source task"),
        description: typeof source.description === "string" ? source.description : null, status: "todo", issueNumber: number,
        identifier: `SRC-${number}`, visibility: "open", privacyRootIssueId, privacyParentIssueId,
        createdByUserId: nativeUserId, responsibleUserId: nativeUserId }).onConflictDoUpdate({ target: issues.id,
          set: { projectId: sourceProjectId, privacyRootIssueId, privacyParentIssueId, visibility: "open",
            createdByUserId: nativeUserId, responsibleUserId: nativeUserId } });
      normalized.push({ ...source, id, companyId: nativeCompanyId, projectId: sourceProjectId, projectWorkspaceId,
        parentId: privacyParentIssueId, visibility: "open", privacyRootIssueId, privacyParentIssueId, privacySources,
        responsibleUserId: nativeUserId, createdByUserId: nativeUserId });
    }
    return normalized;
  }

  function installCurrentHumanSourceFixtures() {
    for (const [mock, normalize] of [[projectSvc.list, normalizeProjectExportSources], [issueSvc.list, normalizeIssueExportSources]] as const) {
      const configured = mock.getMockImplementation() as (typeof mock.getMockImplementation extends (...args: any[]) => infer T ? T : never) & { [sourceFixtureWrapper]?: unknown };
      const original = configured?.[sourceFixtureWrapper] ?? configured ?? (async () => []);
      const wrapped = async (...args: unknown[]) => normalize(await (original as (...args: unknown[]) => unknown)(...args));
      Object.defineProperty(wrapped, sourceFixtureWrapper, { value: original });
      mock.mockImplementation(wrapped as never);
    }
    for (const mock of [issueSvc.listComments, issueSvc.listAttachments,
      documentSvc.listIssueDocuments, workProductSvc.listForIssue] as const) {
      const configured = mock.getMockImplementation() as ((...args: any[]) => any) & { [sourceFixtureWrapper]?: unknown };
      const original = configured?.[sourceFixtureWrapper] ?? configured;
      if (!original) continue;
      const wrapped = async (...args: any[]) => {
        if (typeof args[0] === "string") args[0] = nativeSourceIdAliases.get(args[0]) ?? args[0];
        return original(...args);
      };
      Object.defineProperty(wrapped, sourceFixtureWrapper, { value: original });
      mock.mockImplementation(wrapped as never);
    }
    const relationConfigured = issueSvc.getRelationSummaries.getMockImplementation() as ((...args: any[]) => any) & { [sourceFixtureWrapper]?: unknown };
    const relationOriginal = relationConfigured?.[sourceFixtureWrapper] ?? relationConfigured;
    if (relationOriginal) {
      const wrapped = async (...args: any[]) => {
        if (typeof args[0] === "string") args[0] = nativeSourceIdAliases.get(args[0]) ?? args[0];
        const result = await relationOriginal(...args);
        if (!result || typeof result !== "object") return result;
        const normalize = (items: unknown) => Array.isArray(items) ? items.map((item: any) => ({ ...item,
          id: typeof item.id === "string" && /^[0-9a-f-]{36}$/i.test(item.id) ? item.id : nativeSourceUuid("issue", String(item.id)) })) : items;
        return { ...result, blockedBy: normalize(result.blockedBy), blocks: normalize(result.blocks) };
      };
      Object.defineProperty(wrapped, sourceFixtureWrapper, { value: relationOriginal });
      issueSvc.getRelationSummaries.mockImplementation(wrapped as never);
    }
    const routineConfigured = routineSvc.list.getMockImplementation() as ((...args: any[]) => any) & { [sourceFixtureWrapper]?: unknown };
    const routineOriginal = routineConfigured?.[sourceFixtureWrapper] ?? routineConfigured;
    if (routineOriginal) {
      const wrapped = async (...args: any[]) => {
        const rows = await routineOriginal(...args);
        return Array.isArray(rows) ? rows.map(row => ({ ...row, companyId: nativeCompanyId,
          projectId: typeof row.projectId === "string" ? nativeSourceUuid("project", row.projectId) : row.projectId,
          parentIssueId: typeof row.parentIssueId === "string" ? nativeSourceUuid("issue", row.parentIssueId) : row.parentIssueId })) : rows;
      };
      Object.defineProperty(wrapped, sourceFixtureWrapper, { value: routineOriginal });
      routineSvc.list.mockImplementation(wrapped as never);
    }
  }

  function currentHumanExportPortability(storage?: Parameters<typeof companyPortabilityService>[1]) {
    useNativeExportCompany();
    installCurrentHumanSourceFixtures();
    const service = companyPortabilityService(nativeDb, storage);
    return {
      ...service,
      exportBundle: (companyId: string, input: Parameters<typeof service.exportBundle>[1], options?: Parameters<typeof service.exportBundle>[2]) =>
        (installCurrentHumanSourceFixtures(), service.exportBundle(nativeCompanyId, input, { ...options, actor: nativeActor })),
      importBundle: async (input: Parameters<typeof service.importBundle>[0], actorUserId: string | null | undefined,
        options?: Parameters<typeof service.importBundle>[2]) => {
        const hasWork = (input.include?.projects ?? input.source.type === "inline")
          || (input.include?.issues ?? input.source.type === "inline");
        const request = hasWork && !input.sourceReleaseReview
          ? await reviewExactPackageAsCurrentHuman(service, input as CompanyPortabilityImportRequest) : input;
        return service.importBundle(request, actorUserId === null || actorUserId === undefined ? actorUserId : nativeUserId,
          { ...options, actor: nativeActor, privateWorkAdmission: "closed" });
      },
    };
  }

  async function reviewExactPackageAsCurrentHuman(portability: ReturnType<typeof companyPortabilityService>,
    request: CompanyPortabilityImportRequest) {
    const preview = await portability.previewImport(request, { actor: nativeActor });
    if (!preview.sourceFingerprint) throw new Error("Preview did not bind a source fingerprint");
    return { ...request, expectedSourceFingerprint: preview.sourceFingerprint,
      sourceReleaseReview: { confirmed: true as const, sourceFingerprint: preview.sourceFingerprint } };
  }

  async function seedNativeBoardProject(input: { id: string; name: string; description?: string }) {
    const [row] = await nativeDb.insert(projects).values({
      id: input.id,
      companyId: nativeCompanyId,
      name: input.name,
      description: input.description ?? null,
      status: "planned",
      visibility: "open",
      sourceIssueIds: [],
      sourceProjectIds: [],
      // A new human-created project is stamped qualified by the Board create
      // route. Its empty roots are meaningful for this newly created row only.
      sourceProvenanceQualified: true,
    }).returning();
    return row!;
  }

  async function seedNativeBoardTask(input: { id: string; number: number; title: string; projectId?: string | null; description?: string }) {
    const [row] = await nativeDb.insert(issues).values({
      id: input.id,
      companyId: nativeCompanyId,
      projectId: input.projectId ?? null,
      title: input.title,
      description: input.description ?? null,
      status: "todo",
      identifier: `PAP-${input.number}`,
      issueNumber: input.number,
      visibility: "open",
      privacyRootIssueId: input.id,
      privacyParentIssueId: null,
      createdByUserId: nativeUserId,
      responsibleUserId: nativeUserId,
    }).returning();
    return row!;
  }

  beforeEach(() => {
    vi.clearAllMocks();
    companySvc.create.mockReset();
    instanceSettingsSvc.getExperimental.mockResolvedValue({ enableNativeRunner: false });
    managedAgentProfileSvc.requireQualified.mockResolvedValue({
      id: "managed-primary",
      companyId: "company-1",
      enabled: true,
    });
    remoteAgentProfileSvc.requireQualified.mockResolvedValue({
      id: "agentcore-primary",
      companyId: "company-1",
      enabled: true,
    });
    secretSvc.create.mockResolvedValue({ id: "secret-created" });
    secretSvc.remove.mockResolvedValue(true);
    secretSvc.normalizeAdapterConfigForPersistence.mockImplementation(async (_companyId, config) => config);
    secretSvc.normalizeEnvBindingsForPersistence.mockImplementation(async (_companyId, env) => env);
    secretSvc.syncEnvBindingsForTarget.mockResolvedValue([]);
    secretSvc.resolveAdapterConfigForRuntime.mockImplementation(async (_companyId, config) => ({
      config,
      secretKeys: new Set<string>(),
    }));
    issueSvc.listComments.mockResolvedValue([]);
    issueSvc.addComment.mockResolvedValue({
      id: "comment-imported",
      body: "Imported comment",
      authorType: "system",
      presentation: null,
      metadata: null,
    });
    companySvc.list.mockResolvedValue([]);
    agentSvc.update.mockReset();
    agentSvc.update.mockImplementation(async (id: string, patch: Record<string, unknown>) => {
      const createdAgents = await Promise.all(agentSvc.create.mock.results
        .filter((result) => result.type === "return")
        .map((result) => Promise.resolve(result.value)));
      const current = createdAgents.find((agent) => agent?.id === id);
      return current ? { ...current, ...patch } : null;
    });
    companySvc.getById.mockResolvedValue({
      id: "company-1",
      name: "Paperclip",
      description: null,
      issuePrefix: "PAP",
      logoAssetId: null,
      logoUrl: null,
      requireBoardApprovalForNewAgents: false,
    });
    companySvc.create.mockResolvedValue({
      id: "company-imported",
      name: "Imported Paperclip",
      requireBoardApprovalForNewAgents: false,
    });
    agentSvc.list.mockResolvedValue([
      {
        id: "agent-1",
        name: "ClaudeCoder",
        status: "idle",
        role: "engineer",
        title: "Software Engineer",
        icon: "code",
        reportsTo: null,
        capabilities: "Writes code",
        adapterType: "claude_local",
        adapterConfig: {
          promptTemplate: "You are ClaudeCoder.",
          paperclipSkillSync: {
            desiredSkills: [paperclipKey],
          },
          instructionsFilePath: "/tmp/ignored.md",
          cwd: "/tmp/ignored",
          command: "/Users/dotta/.local/bin/claude",
          model: "claude-opus-4-6",
          env: {
            ANTHROPIC_API_KEY: {
              type: "secret_ref",
              secretId: "secret-1",
              version: "latest",
            },
            GH_TOKEN: {
              type: "secret_ref",
              secretId: "secret-2",
              version: "latest",
            },
            PATH: {
              type: "plain",
              value: "/usr/bin:/bin",
            },
          },
        },
        runtimeConfig: {
          heartbeat: {
            intervalSec: 3600,
          },
        },
        budgetMonthlyCents: 0,
        permissions: {
          canCreateAgents: false,
        },
        metadata: null,
      },
      {
        id: "agent-2",
        name: "CMO",
        status: "idle",
        role: "cmo",
        title: "Chief Marketing Officer",
        icon: "globe",
        reportsTo: null,
        capabilities: "Owns marketing",
        adapterType: "claude_local",
        adapterConfig: {
          promptTemplate: "You are CMO.",
        },
        runtimeConfig: {
          heartbeat: {
            intervalSec: 3600,
          },
        },
        budgetMonthlyCents: 0,
        permissions: {
          canCreateAgents: false,
        },
        metadata: null,
      },
    ]);
    projectSvc.list.mockResolvedValue([]);
    projectSvc.createWorkspace.mockResolvedValue(null);
    projectSvc.listWorkspaces.mockResolvedValue([]);
    issueSvc.list.mockResolvedValue([]);
    issueSvc.getById.mockResolvedValue(null);
    issueSvc.getByIdentifier.mockResolvedValue(null);
    issueSvc.listLabels.mockResolvedValue([]);
    issueSvc.createLabel.mockImplementation(async (_companyId: string, data: { name: string; color: string }) => ({
      id: `label-created-${data.name}`,
      companyId: "company-imported",
      name: data.name,
      color: data.color,
    }));
    issueSvc.getRelationSummaries.mockResolvedValue({ blockedBy: [], blocks: [] });
    issueSvc.listAttachments.mockResolvedValue([]);
    issueSvc.createAttachment.mockResolvedValue({ id: "attachment-imported" });
    documentSvc.listIssueDocuments.mockResolvedValue([]);
    documentSvc.upsertIssueDocument.mockResolvedValue({ created: true });
    workProductSvc.listForIssue.mockResolvedValue([]);
    workProductSvc.createForIssue.mockResolvedValue({ id: "work-product-imported" });
    routineSvc.list.mockResolvedValue([]);
    routineSvc.getDetail.mockImplementation(async (id: string) => {
      const rows = await routineSvc.list();
      return rows.find((row: { id: string }) => row.id === id) ?? null;
    });
    routineSvc.create.mockImplementation(async (_companyId: string, input: Record<string, unknown>) => ({
      id: "routine-created",
      companyId: "company-1",
      projectId: input.projectId,
      goalId: null,
      parentIssueId: null,
      title: input.title,
      description: input.description ?? null,
      assigneeAgentId: input.assigneeAgentId,
      priority: input.priority ?? "medium",
      status: input.status ?? "active",
      concurrencyPolicy: input.concurrencyPolicy ?? "coalesce_if_active",
      catchUpPolicy: input.catchUpPolicy ?? "skip_missed",
      createdByAgentId: null,
      createdByUserId: null,
      updatedByAgentId: null,
      updatedByUserId: null,
      lastTriggeredAt: null,
      lastEnqueuedAt: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    }));
    routineSvc.createTrigger.mockImplementation(async (_routineId: string, input: Record<string, unknown>) => ({
      id: "trigger-created",
      companyId: "company-1",
      routineId: "routine-created",
      kind: input.kind,
      label: input.label ?? null,
      enabled: input.enabled ?? true,
      cronExpression: input.kind === "schedule" ? input.cronExpression ?? null : null,
      timezone: input.kind === "schedule" ? input.timezone ?? null : null,
      nextRunAt: null,
      lastFiredAt: null,
      publicId: null,
      secretId: null,
      signingMode: input.kind === "webhook" ? input.signingMode ?? "bearer" : null,
      replayWindowSec: input.kind === "webhook" ? input.replayWindowSec ?? 300 : null,
      lastRotatedAt: null,
      lastResult: null,
      createdByAgentId: null,
      createdByUserId: null,
      updatedByAgentId: null,
      updatedByUserId: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    }));
    const companySkills = [
      {
        id: "skill-1",
        companyId: "company-1",
        key: paperclipKey,
        slug: "paperclip",
        name: "paperclip",
        description: "Paperclip coordination skill",
        markdown: "---\nname: paperclip\ndescription: Paperclip coordination skill\n---\n\n# Paperclip\n",
        sourceType: "github",
        sourceLocator: "https://github.com/paperclipai/paperclip/tree/master/skills/paperclip",
        sourceRef: "0123456789abcdef0123456789abcdef01234567",
        trustLevel: "markdown_only",
        compatibility: "compatible",
        fileInventory: [
          { path: "SKILL.md", kind: "skill" },
          { path: "references/api.md", kind: "reference" },
        ],
        metadata: {
          sourceKind: "github",
          owner: "paperclipai",
          repo: "paperclip",
          ref: "0123456789abcdef0123456789abcdef01234567",
          trackingRef: "master",
          repoSkillDir: "skills/paperclip",
        },
      },
      {
        id: "skill-2",
        companyId: "company-1",
        key: companyPlaybookKey,
        slug: "company-playbook",
        name: "company-playbook",
        description: "Internal company skill",
        markdown: "---\nname: company-playbook\ndescription: Internal company skill\n---\n\n# Company Playbook\n",
        sourceType: "local_path",
        sourceLocator: "/tmp/company-playbook",
        sourceRef: null,
        trustLevel: "markdown_only",
        compatibility: "compatible",
        fileInventory: [
          { path: "SKILL.md", kind: "skill" },
          { path: "references/checklist.md", kind: "reference" },
        ],
        metadata: {
          sourceKind: "local_path",
        },
      },
    ];
    companySkillSvc.list.mockResolvedValue(companySkills);
    companySkillSvc.listFull.mockResolvedValue(companySkills);
    companySkillSvc.readFile.mockImplementation(async (_companyId: string, skillId: string, relativePath: string) => {
      if (skillId === "skill-2") {
        return {
          skillId,
          path: relativePath,
          kind: relativePath === "SKILL.md" ? "skill" : "reference",
          content: relativePath === "SKILL.md"
            ? "---\nname: company-playbook\ndescription: Internal company skill\n---\n\n# Company Playbook\n"
            : "# Checklist\n",
          language: "markdown",
          markdown: true,
          editable: true,
        };
      }

      return {
        skillId,
        path: relativePath,
        kind: relativePath === "SKILL.md" ? "skill" : "reference",
        content: relativePath === "SKILL.md"
          ? "---\nname: paperclip\ndescription: Paperclip coordination skill\n---\n\n# Paperclip\n"
          : "# API\n",
        language: "markdown",
        markdown: true,
        editable: false,
      };
    });
    companySkillSvc.importPackageFiles.mockResolvedValue([]);
    assetSvc.getById.mockReset();
    assetSvc.getById.mockResolvedValue(null);
    assetSvc.create.mockReset();
    accessSvc.setPrincipalPermission.mockResolvedValue(undefined);
    assetSvc.create.mockResolvedValue({
      id: "asset-created",
    });
    accessSvc.listActiveUserMemberships.mockResolvedValue([
      {
        id: "membership-1",
        companyId: "company-1",
        principalType: "user",
        principalId: "user-1",
        membershipRole: "owner",
        status: "active",
      },
    ]);
    accessSvc.copyActiveUserMemberships.mockResolvedValue([]);
    agentInstructionsSvc.exportFiles.mockImplementation(async (agent: { name: string }) => ({
      files: { "AGENTS.md": agent.name === "CMO" ? "You are CMO." : "You are ClaudeCoder." },
      entryFile: "AGENTS.md",
      warnings: [],
    }));
    agentInstructionsSvc.materializeManagedBundle.mockImplementation(async (agent: { adapterConfig: Record<string, unknown> }) => ({
      bundle: null,
      adapterConfig: {
        ...agent.adapterConfig,
        instructionsBundleMode: "managed",
        instructionsRootPath: `/tmp/${agent.id}`,
        instructionsEntryFile: "AGENTS.md",
        instructionsFilePath: `/tmp/${agent.id}/AGENTS.md`,
      },
    }));
  });

  it("renders high-volume YAML blocks without overflowing the call stack", () => {
    const tasks = Array.from({ length: 130_000 }, (_, index) => `issue-${index}`);

    const lines = renderYamlBlock({ tasks }, 0);

    expect(lines[0]).toBe("tasks:");
    expect(lines[1]).toBe('  - "issue-0"');
    expect(lines.at(-1)).toBe('  - "issue-129999"');
  });

  it("renders high-volume frontmatter arrays without overflowing the call stack", () => {
    const tasks = Array.from({ length: 130_000 }, (_, index) => `issue-${index}`);

    const rendered = renderFrontmatter({ tasks });
    const lines = rendered.split("\n");

    expect(lines[0]).toBe("---");
    expect(lines[1]).toBe("tasks:");
    expect(lines[2]).toBe('  - "issue-0"');
    expect(lines[130_001]).toBe('  - "issue-129999"');
    expect(lines[130_002]).toBe("---");
  });

  it("parses canonical GitHub import URLs with explicit ref and package path", () => {
    expect(
      parseGitHubSourceUrl("https://github.com/paperclipai/companies?ref=feature%2Fdemo&path=gstack"),
    ).toEqual({
      hostname: "github.com",
      owner: "paperclipai",
      repo: "companies",
      ref: "feature/demo",
      basePath: "gstack",
      companyPath: "gstack/COMPANY.md",
    });
  });

  it("parses canonical GitHub import URLs with explicit companyPath", () => {
    expect(
      parseGitHubSourceUrl(
        "https://github.com/paperclipai/companies?ref=abc123&companyPath=gstack%2FCOMPANY.md",
      ),
    ).toEqual({
      hostname: "github.com",
      owner: "paperclipai",
      repo: "companies",
      ref: "abc123",
      basePath: "gstack",
      companyPath: "gstack/COMPANY.md",
    });
  });

  itNative("exports referenced skills as stubs by default with sanitized Paperclip extension data", async () => {
    const portability = companyPortabilityService(nativeDb);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
        skills: true,
      },
    }, { actor: nativeActor });

    expect(exported.files["blentera-support-cases-v1.json"]).toBeUndefined();
    expect(exported.manifest.includes.supportCases).not.toBe(true);
    expect(asTextFile(exported.files["COMPANY.md"])).toContain('name: "Paperclip"');
    expect(asTextFile(exported.files["COMPANY.md"])).toContain('schema: "agentcompanies/v1"');
    expect(asTextFile(exported.files["agents/claudecoder/AGENTS.md"])).toContain("You are ClaudeCoder.");
    expect(asTextFile(exported.files["agents/claudecoder/AGENTS.md"])).toContain("skills:");
    expect(asTextFile(exported.files["agents/claudecoder/AGENTS.md"])).toContain(`- "${paperclipKey}"`);
    expect(asTextFile(exported.files["agents/cmo/AGENTS.md"])).not.toContain("skills:");
    expect(asTextFile(exported.files["skills/paperclipai/paperclip/paperclip/SKILL.md"])).toContain("metadata:");
    expect(asTextFile(exported.files["skills/paperclipai/paperclip/paperclip/SKILL.md"])).toContain('kind: "github-dir"');
    expect(exported.files["skills/paperclipai/paperclip/paperclip/references/api.md"]).toBeUndefined();
    expect(asTextFile(exported.files["skills/company/PAP/company-playbook/SKILL.md"])).toContain("# Company Playbook");
    expect(asTextFile(exported.files["skills/company/PAP/company-playbook/references/checklist.md"])).toContain("# Checklist");

    const extension = asTextFile(exported.files[".paperclip.yaml"]);
    expect(extension).toContain('schema: "paperclip/v1"');
    expect(extension).not.toContain("promptTemplate");
    expect(extension).not.toContain("instructionsFilePath");
    expect(extension).not.toContain("command:");
    expect(extension).not.toContain("secretId");
    expect(extension).not.toContain('type: "secret_ref"');
    expect(extension).toContain("inputs:");
    expect(extension).toContain("ANTHROPIC_API_KEY:");
    expect(extension).toContain('requirement: "optional"');
    expect(extension).toContain('default: ""');
    expect(extension).not.toContain("paperclipSkillSync");
    expect(extension).not.toContain("PATH:");
    expect(extension).not.toContain("requireBoardApprovalForNewAgents: true");
    expect(extension).not.toContain("budgetMonthlyCents: 0");
    expect(exported.warnings).toContain("Agent claudecoder command /Users/dotta/.local/bin/claude was omitted from export because it is system-dependent.");
    expect(exported.warnings).toContain("Agent claudecoder PATH override was omitted from export because it is system-dependent.");
  });

  itNative("round-trips company locale and timezone defaults while preserving legacy package fallbacks", async () => {
    useNativeExportCompany({ locale: "da", timezone: "Europe/Copenhagen" });
    const portability = companyPortabilityService(nativeDb);
    const include = { company: true, agents: false, projects: false, issues: false, skills: false };
    const exported = await portability.exportBundle(nativeCompanyId, { include }, { actor: nativeActor });

    expect(exported.manifest.company).toMatchObject({ locale: "da", timezone: "Europe/Copenhagen" });
    expect(asTextFile(exported.files[".paperclip.yaml"]))
      .toContain('locale: "da"');
    expect(asTextFile(exported.files[".paperclip.yaml"]))
      .toContain('timezone: "Europe/Copenhagen"');

    agentSvc.list.mockResolvedValue([]);
    projectSvc.list.mockResolvedValue([]);
    companySvc.create.mockResolvedValue({ id: "company-imported-settings", name: "Imported settings" });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    accessSvc.ensureRoleDefaultGrants.mockResolvedValue(undefined);
    await portability.importBundle({
      source: { type: "inline", rootPath: exported.rootPath, files: exported.files },
      include,
      target: { mode: "new_company", newCompanyName: "Imported settings" },
      collisionStrategy: "rename",
      agents: "all",
    }, "user-1");
    expect(companySvc.create).toHaveBeenCalledWith(expect.objectContaining({
      locale: "da",
      timezone: "Europe/Copenhagen",
    }));

    companySvc.create.mockClear();
    await portability.importBundle({
      source: {
        type: "inline",
        files: { "COMPANY.md": ['---', 'schema: "agentcompanies/v1"', 'name: "Legacy settings"', "---", ""].join("\n") },
      },
      include,
      target: { mode: "new_company", newCompanyName: "Legacy settings" },
      collisionStrategy: "rename",
      agents: "all",
    }, "user-1");
    expect(companySvc.create).toHaveBeenCalledWith(expect.objectContaining({ locale: "en", timezone: "UTC" }));
  });

  itNative("does not load or emit skills when agents are included but skills are disabled", async () => {
    const portability = companyPortabilityService(nativeDb);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
        skills: false,
      },
    }, { actor: nativeActor });

    expect(companySkillSvc.listFull).not.toHaveBeenCalled();
    expect(Object.keys(exported.files).some((filePath) => filePath.startsWith("skills/"))).toBe(false);
    expect(exported.manifest.skills).toEqual([]);
    expect(asTextFile(exported.files["agents/claudecoder/AGENTS.md"])).toContain(`- "${paperclipKey}"`);
  });

  itNative("refuses to read external instruction roots without an instance-admin export grant", async () => {
    agentSvc.list.mockResolvedValue([{
      id: "external-agent",
      companyId: "company-1",
      name: "ExternalAgent",
      status: "idle",
      role: "engineer",
      title: null,
      icon: null,
      reportsTo: null,
      capabilities: null,
      adapterType: "codex_local",
      adapterConfig: {
        instructionsBundleMode: "external",
        instructionsRootPath: "/private/host/instructions",
      },
      runtimeConfig: {},
      budgetMonthlyCents: 0,
      permissions: { canCreateAgents: false },
      metadata: null,
    }]);

    await expect(companyPortabilityService(nativeDb).exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
    }, { actor: nativeActor })).rejects.toMatchObject({ status: 403 });
    expect(agentInstructionsSvc.exportFiles).not.toHaveBeenCalled();

    await expect(companyPortabilityService(nativeDb).exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
    }, { allowExternalInstructions: true, actor: nativeActor })).resolves.toMatchObject({
      manifest: { agents: [expect.objectContaining({ slug: "externalagent" })] },
    });
    expect(agentInstructionsSvc.exportFiles).toHaveBeenCalledTimes(1);
  });

  itNative("requires an explicit current actor for source-free export", async () => {
    await expect(companyPortabilityService(nativeDb).exportBundle(nativeCompanyId, {
      include: { company: true, agents: false, projects: false, issues: false, skills: false },
    })).rejects.toMatchObject({ status: 403 });
    expect(agentInstructionsSvc.exportFiles).not.toHaveBeenCalled();
  });

  itNative("withdraws source-free export after the current Human membership is suspended", async () => {
    await nativeDb.update(companyMemberships).set({ status: "suspended" })
      .where(eq(companyMemberships.principalId, nativeUserId));
    try {
      await expect(companyPortabilityService(nativeDb).exportBundle(nativeCompanyId, {
        include: { company: true, agents: false, projects: false, issues: false, skills: false },
      }, { actor: nativeActor })).rejects.toMatchObject({ status: 403 });
      expect(agentInstructionsSvc.exportFiles).not.toHaveBeenCalled();
    } finally {
      await nativeDb.update(companyMemberships).set({ status: "active" })
        .where(eq(companyMemberships.principalId, nativeUserId));
    }
  });

  itNative("stops a pending agent import when the current Human session or target membership is revoked", async () => {
    useNativeExportCompany();
    const portability = companyPortabilityService(nativeDb);
    const exported = await portability.exportBundle(nativeCompanyId, {
      include: { company: true, agents: true, projects: false, issues: false, skills: false },
    }, { actor: nativeActor });
    agentSvc.list.mockResolvedValue([]);
    const sessionId = randomUUID();
    const now = new Date();
    await nativeDb.insert(authSessions).values({ id: sessionId, userId: nativeUserId, token: randomUUID(),
      expiresAt: new Date(now.getTime() + 60_000), createdAt: now, updatedAt: now });
    const sessionActor = { ...nativeActor, sessionId };
    const request = {
      source: { type: "inline" as const, rootPath: exported.rootPath, files: exported.files },
      include: { company: false, agents: true, projects: false, issues: false, skills: false },
      target: { mode: "existing_company" as const, companyId: nativeCompanyId },
      agents: "all" as const,
      collisionStrategy: "rename" as const,
    };

    try {
      let membershipRevoked = false;
      await expect(portability.importBundle(request, nativeUserId, {
        actor: sessionActor,
        checkCancellation: async () => {
          if (!membershipRevoked) {
            membershipRevoked = true;
            await nativeDb.delete(companyMemberships).where(and(
              eq(companyMemberships.companyId, nativeCompanyId),
              eq(companyMemberships.principalType, "user"),
              eq(companyMemberships.principalId, nativeUserId),
            ));
          }
          return false;
        },
      })).rejects.toMatchObject({ status: 403 });
      expect(membershipRevoked).toBe(true);
      expect(agentSvc.create).not.toHaveBeenCalled();

      await nativeDb.insert(companyMemberships).values({ companyId: nativeCompanyId, principalType: "user",
        principalId: nativeUserId, status: "active", membershipRole: "owner" }).onConflictDoUpdate({
        target: [companyMemberships.companyId, companyMemberships.principalType, companyMemberships.principalId],
        set: { status: "active", membershipRole: "owner" },
      });
      await expect(portability.importBundle(request, nativeUserId, {
        actor: sessionActor,
        checkCancellation: async () => {
          await nativeDb.delete(authSessions).where(eq(authSessions.id, sessionId));
          return false;
        },
      })).rejects.toMatchObject({ status: 403 });
      expect(agentSvc.create).not.toHaveBeenCalled();
    } finally {
      await nativeDb.insert(companyMemberships).values({ companyId: nativeCompanyId, principalType: "user",
        principalId: nativeUserId, status: "active", membershipRole: "owner" }).onConflictDoUpdate({
        target: [companyMemberships.companyId, companyMemberships.principalType, companyMemberships.principalId],
        set: { status: "active", membershipRole: "owner" },
      });
      await nativeDb.delete(authSessions).where(eq(authSessions.id, sessionId));
    }
  });

  itNative("exports agent permission grants through the Paperclip extension and manifest", async () => {
    await nativeDb.insert(principalPermissionGrants).values([
      { companyId: nativeCompanyId, principalType: "agent", principalId: "agent-1", permissionKey: "agents:suggest-changes", scope: null },
      { companyId: nativeCompanyId, principalType: "agent", principalId: "agent-1", permissionKey: "skills:create", scope: { targetAgentIds: ["agent-1"] } },
    ]);
    useNativeExportCompany();
    const portability = companyPortabilityService(nativeDb);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
    }, { actor: nativeActor });

    const extension = asTextFile(exported.files[".paperclip.yaml"]);
    expect(extension).toContain("permissionGrants:");
    expect(extension).toContain('permissionKey: "agents:suggest-changes"');
    expect(extension).toContain('permissionKey: "skills:create"');
    expect(exported.manifest.agents.find((agent) => agent.slug === "claudecoder")?.permissionGrants).toEqual([
      {
        permissionKey: "agents:suggest-changes",
        scope: null,
      },
      {
        permissionKey: "skills:create",
        scope: { targetAgentIds: ["agent-1"] },
      },
    ]);
  });

  itNative("exports hire approval policy only when approval is required", async () => {
    const portability = companyPortabilityService(nativeDb);

    companySvc.getById.mockResolvedValueOnce({
      id: "company-1",
      name: "Paperclip",
      description: null,
      issuePrefix: "PAP",
      logoAssetId: null,
      logoUrl: null,
      requireBoardApprovalForNewAgents: true,
    });

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: false,
        projects: false,
        issues: false,
      },
    }, { actor: nativeActor });

    expect(asTextFile(exported.files[".paperclip.yaml"])).toContain("requireBoardApprovalForNewAgents: true");
  });

  itNative("exports legacy inline sensitive env values as declarations without values", async () => {
    const portability = companyPortabilityService(nativeDb);
    agentSvc.list.mockResolvedValue([
      {
        id: "agent-inline-secret",
        name: "InlineSecretAgent",
        status: "idle",
        role: "engineer",
        title: null,
        icon: null,
        reportsTo: null,
        capabilities: null,
        adapterType: "codex_local",
        adapterConfig: {
          env: {
            OPENAI_API_KEY: "sk-inline-secret-value",
            OPENAI_KEY: {
              type: "plain",
              value: "sk-short-key-secret-value",
            },
            MONKEY: {
              type: "plain",
              value: "banana",
            },
            NODE_ENV: {
              type: "plain",
              value: "development",
            },
          },
        },
        runtimeConfig: {},
        budgetMonthlyCents: 0,
        permissions: {
          canCreateAgents: false,
        },
        metadata: null,
      },
    ]);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
    }, { actor: nativeActor });

    const serialized = JSON.stringify(exported);
    expect(serialized).not.toContain("sk-inline-secret-value");
    expect(serialized).not.toContain("sk-short-key-secret-value");
    expect(exported.manifest.envInputs).toContainEqual({
      key: "OPENAI_API_KEY",
      description: "Optional default for OPENAI_API_KEY on agent inlinesecretagent",
      agentSlug: "inlinesecretagent",
      projectSlug: null,
      kind: "secret",
      requirement: "optional",
      defaultValue: "",
      portability: "portable",
    });
    expect(exported.manifest.envInputs).toContainEqual({
      key: "OPENAI_KEY",
      description: "Optional default for OPENAI_KEY on agent inlinesecretagent",
      agentSlug: "inlinesecretagent",
      projectSlug: null,
      kind: "secret",
      requirement: "optional",
      defaultValue: "",
      portability: "portable",
    });
    expect(exported.manifest.envInputs).toContainEqual({
      key: "MONKEY",
      description: "Optional default for MONKEY on agent inlinesecretagent",
      agentSlug: "inlinesecretagent",
      projectSlug: null,
      kind: "plain",
      requirement: "optional",
      defaultValue: "banana",
      portability: "portable",
    });
    expect(exported.manifest.envInputs).toContainEqual({
      key: "NODE_ENV",
      description: "Optional default for NODE_ENV on agent inlinesecretagent",
      agentSlug: "inlinesecretagent",
      projectSlug: null,
      kind: "plain",
      requirement: "optional",
      defaultValue: "development",
      portability: "portable",
    });
  });

  itNative("exports default sidebar order into the Paperclip extension and manifest", async () => {
    const portability = companyPortabilityService(nativeDb);
    useNativeExportCompany();
    const zulu = await seedNativeBoardProject({ id: "b7071652-fd3a-4a30-b755-7c3b56513720", name: "Zulu" });
    const alpha = await seedNativeBoardProject({ id: "b7071652-fd3a-4a30-b755-7c3b56513721", name: "Alpha" });

    projectSvc.list.mockResolvedValue([
      {
        ...zulu,
        id: "b7071652-fd3a-4a30-b755-7c3b56513720",
        companyId: nativeCompanyId,
        name: "Zulu",
        urlKey: "zulu",
        description: null,
        leadAgentId: null,
        targetDate: null,
        color: null,
        status: "planned",
        executionWorkspacePolicy: null,
        archivedAt: null,
        workspaces: [],
      },
      {
        ...alpha,
        id: "b7071652-fd3a-4a30-b755-7c3b56513721",
        companyId: nativeCompanyId,
        name: "Alpha",
        urlKey: "alpha",
        description: null,
        leadAgentId: null,
        targetDate: null,
        color: null,
        status: "planned",
        executionWorkspacePolicy: null,
        archivedAt: null,
        workspaces: [],
      },
    ]);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: true,
        issues: false,
      },
    }, { actor: nativeActor });

    expect(asTextFile(exported.files[".paperclip.yaml"])).toContain([
      "sidebar:",
      "  agents:",
      '    - "claudecoder"',
      '    - "cmo"',
      "  projects:",
      '    - "alpha"',
      '    - "zulu"',
    ].join("\n"));
    expect(exported.manifest.sidebar).toEqual({
      agents: ["claudecoder", "cmo"],
      projects: ["alpha", "zulu"],
    });
  });

  itNative("expands referenced skills when requested", async () => {
    companySvc.getById.mockResolvedValueOnce({
      id: nativeCompanyId,
      name: "Paperclip",
      description: null,
      issuePrefix: "PAP",
      logoAssetId: null,
      logoUrl: null,
      requireBoardApprovalForNewAgents: false,
    });
    const listedSkills = await companySkillSvc.listFull(nativeCompanyId);
    companySkillSvc.listFull.mockResolvedValueOnce(listedSkills.map((skill) => ({ ...skill, companyId: nativeCompanyId })));
    const portability = companyPortabilityService(nativeDb);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
        skills: true,
      },
      expandReferencedSkills: true,
    }, { actor: nativeActor });

    expect(asTextFile(exported.files["skills/paperclipai/paperclip/paperclip/SKILL.md"])).toContain("# Paperclip");
    expect(asTextFile(exported.files["skills/paperclipai/paperclip/paperclip/SKILL.md"])).toContain("metadata:");
    expect(asTextFile(exported.files["skills/paperclipai/paperclip/paperclip/references/api.md"])).toContain("# API");
  });

  itNative("exports catalog skill provenance in portable Paperclip frontmatter", async () => {
    const portability = companyPortabilityService(nativeDb);
    const catalogKey = "paperclipai/bundled/software-development/review";
    const originHash = "sha256:catalog-origin";
    const catalogSkill = {
      id: "skill-catalog",
      companyId: nativeCompanyId,
      key: catalogKey,
      slug: "review",
      name: "review",
      description: "Catalog review skill",
      markdown: "---\nname: review\ndescription: Catalog review skill\n---\n\n# Review\n",
      sourceType: "catalog",
      sourceLocator: "/tmp/paperclip/catalog/review",
      sourceRef: originHash,
      trustLevel: "markdown_only",
      compatibility: "compatible",
      fileInventory: [
        { path: "SKILL.md", kind: "skill" },
        { path: "references/checklist.md", kind: "reference" },
      ],
      metadata: {
        sourceKind: "catalog",
        skillKey: catalogKey,
        catalogId: "paperclipai:bundled:software-development:review",
        catalogKey,
        catalogKind: "bundled",
        catalogCategory: "software-development",
        catalogPath: "catalog/bundled/software-development/review",
        packageName: "@paperclipai/skills-catalog",
        packageVersion: "0.3.1",
        originHash,
        originVersion: "0.3.1",
        originSnapshotLocator: "/tmp/local-only-origin",
        installedHash: "sha256:installed",
        userModifiedAt: "2026-05-01T00:00:00.000Z",
        updateHoldReason: "local_modifications",
        auditVerdict: "warning",
        auditCodes: ["local_modifications"],
        auditScannedAt: "2026-05-02T00:00:00.000Z",
        auditScanVersion: "skills-audit-v1",
      },
    };
    companySkillSvc.listFull.mockResolvedValue([catalogSkill]);
    companySkillSvc.readFile.mockImplementation(async (_companyId: string, skillId: string, relativePath: string) => ({
      skillId,
      path: relativePath,
      kind: relativePath === "SKILL.md" ? "skill" : "reference",
      content: relativePath === "SKILL.md"
        ? "---\nname: review\ndescription: Catalog review skill\n---\n\n# Review\n"
        : "# Checklist\n",
      language: "markdown",
      markdown: true,
      editable: true,
    }));

    companySvc.getById.mockResolvedValueOnce({
      id: nativeCompanyId,
      name: "Paperclip",
      description: null,
      issuePrefix: "PAP",
      logoAssetId: null,
      logoUrl: null,
      requireBoardApprovalForNewAgents: false,
    });
    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: false,
        agents: false,
        projects: false,
        issues: false,
        skills: true,
      },
      expandReferencedSkills: true,
    }, { actor: nativeActor });

    const skillMarkdown = asTextFile(exported.files["skills/paperclipai/bundled/software-development/review/SKILL.md"]);
    expect(skillMarkdown).toContain("paperclip:");
    expect(skillMarkdown).toContain("catalog:");
    expect(skillMarkdown).toContain(`sourceRef: "${originHash}"`);
    expect(skillMarkdown).toContain('catalogId: "paperclipai:bundled:software-development:review"');
    expect(skillMarkdown).toContain(`catalogKey: "${catalogKey}"`);
    expect(skillMarkdown).toContain('catalogKind: "bundled"');
    expect(skillMarkdown).toContain('catalogPath: "catalog/bundled/software-development/review"');
    expect(skillMarkdown).toContain('packageName: "@paperclipai/skills-catalog"');
    expect(skillMarkdown).toContain('packageVersion: "0.3.1"');
    expect(skillMarkdown).toContain('installedHash: "sha256:installed"');
    expect(skillMarkdown).toContain('auditVerdict: "warning"');
    expect(skillMarkdown).not.toContain("originSnapshotLocator");
    expect(exported.manifest.skills[0]).toMatchObject({
      key: catalogKey,
      sourceType: "catalog",
      sourceRef: originHash,
      metadata: expect.objectContaining({
        sourceKind: "catalog",
        skillKey: catalogKey,
        originHash,
        catalogId: "paperclipai:bundled:software-development:review",
        catalogKey,
        catalogKind: "bundled",
        catalogPath: "catalog/bundled/software-development/review",
        packageName: "@paperclipai/skills-catalog",
        packageVersion: "0.3.1",
        installedHash: "sha256:installed",
        auditCodes: ["local_modifications"],
      }),
    });
  });

  itNative("exports only selected skills when skills filter is provided", async () => {
    useNativeExportCompany();
    const skills = await companySkillSvc.listFull(nativeCompanyId);
    companySkillSvc.listFull.mockResolvedValueOnce(skills.map((skill) => ({ ...skill, companyId: nativeCompanyId })));
    const portability = companyPortabilityService(nativeDb);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
      skills: ["company-playbook"],
    }, { actor: nativeActor });

    expect(exported.files["skills/company/PAP/company-playbook/SKILL.md"]).toBeDefined();
    expect(asTextFile(exported.files["skills/company/PAP/company-playbook/SKILL.md"])).toContain("# Company Playbook");
    expect(exported.files["skills/paperclipai/paperclip/paperclip/SKILL.md"]).toBeUndefined();
  });

  itNative("warns and exports all skills when skills filter matches nothing", async () => {
    useNativeExportCompany();
    const skills = await companySkillSvc.listFull(nativeCompanyId);
    companySkillSvc.listFull.mockResolvedValueOnce(skills.map((skill) => ({ ...skill, companyId: nativeCompanyId })));
    const portability = companyPortabilityService(nativeDb);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
      skills: ["nonexistent-skill"],
    }, { actor: nativeActor });

    expect(exported.warnings).toContainEqual(expect.stringContaining("nonexistent-skill"));
    expect(exported.files["skills/company/PAP/company-playbook/SKILL.md"]).toBeDefined();
    expect(exported.files["skills/paperclipai/paperclip/paperclip/SKILL.md"]).toBeDefined();
  });

  itNative("exports the company logo into images/ and references it from .paperclip.yaml", async () => {
    const storage = {
      getObject: vi.fn().mockResolvedValue({
        stream: Readable.from([Buffer.from("png-bytes")]),
      }),
    };
    useNativeExportCompany({
      name: "Paperclip",
      logoAssetId: "logo-1", logoUrl: "/api/assets/logo-1/content", requireBoardApprovalForNewAgents: true,
    });
    assetSvc.getById.mockResolvedValue({
      id: "logo-1",
      companyId: nativeCompanyId,
      objectKey: "assets/companies/logo-1",
      contentType: "image/png",
      originalFilename: "logo.png",
    });

    const portability = companyPortabilityService(nativeDb, storage as any);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: false,
        projects: false,
        issues: false,
      },
    }, { actor: nativeActor });

    expect(storage.getObject).toHaveBeenCalledWith(nativeCompanyId, "assets/companies/logo-1");
    expect(exported.files["images/company-logo.png"]).toEqual({
      encoding: "base64",
      data: Buffer.from("png-bytes").toString("base64"),
      contentType: "image/png",
    });
    expect(exported.files[".paperclip.yaml"]).toContain('logoPath: "images/company-logo.png"');
  });

  itNative("exports duplicate skill slugs into readable namespaced paths", async () => {
    useNativeExportCompany();
    const portability = companyPortabilityService(nativeDb);

    companySkillSvc.readFile.mockImplementation(async (_companyId: string, skillId: string, relativePath: string) => {
      if (skillId === "skill-local") {
        return {
          skillId,
          path: relativePath,
          kind: "skill",
          content: "---\nname: release-changelog\n---\n\n# Local Release Changelog\n",
          language: "markdown",
          markdown: true,
          editable: true,
        };
      }

      return {
        skillId,
        path: relativePath,
        kind: "skill",
        content: "---\nname: release-changelog\n---\n\n# Bundled Release Changelog\n",
        language: "markdown",
        markdown: true,
        editable: false,
      };
    });

    companySkillSvc.listFull.mockResolvedValue([
      {
        id: "skill-local",
        companyId: nativeCompanyId,
        key: "local/36dfd631da/release-changelog",
        slug: "release-changelog",
        name: "release-changelog",
        description: "Local release changelog skill",
        markdown: "---\nname: release-changelog\n---\n\n# Local Release Changelog\n",
        sourceType: "local_path",
        sourceLocator: "/tmp/release-changelog",
        sourceRef: null,
        trustLevel: "markdown_only",
        compatibility: "compatible",
        fileInventory: [{ path: "SKILL.md", kind: "skill" }],
        metadata: {
          sourceKind: "local_path",
        },
      },
      {
        id: "skill-paperclip",
        companyId: nativeCompanyId,
        key: "paperclipai/paperclip/release-changelog",
        slug: "release-changelog",
        name: "release-changelog",
        description: "Bundled release changelog skill",
        markdown: "---\nname: release-changelog\n---\n\n# Bundled Release Changelog\n",
        sourceType: "github",
        sourceLocator: "https://github.com/paperclipai/paperclip/tree/master/skills/release-changelog",
        sourceRef: "0123456789abcdef0123456789abcdef01234567",
        trustLevel: "markdown_only",
        compatibility: "compatible",
        fileInventory: [{ path: "SKILL.md", kind: "skill" }],
        metadata: {
          sourceKind: "paperclip_bundled",
          owner: "paperclipai",
          repo: "paperclip",
          ref: "0123456789abcdef0123456789abcdef01234567",
          trackingRef: "master",
          repoSkillDir: "skills/release-changelog",
        },
      },
    ]);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
        skills: true,
      },
    }, { actor: nativeActor });

    expect(asTextFile(exported.files["skills/local/release-changelog/SKILL.md"])).toContain("# Local Release Changelog");
    expect(asTextFile(exported.files["skills/paperclipai/paperclip/release-changelog/SKILL.md"])).toContain("metadata:");
    expect(asTextFile(exported.files["skills/paperclipai/paperclip/release-changelog/SKILL.md"])).toContain("paperclipai/paperclip/release-changelog");
  });

  itNative("builds export previews without tasks by default", async () => {
    const portability = companyPortabilityService(nativeDb);
    useNativeExportCompany();
    const projectId = "b7071652-fd3a-4a30-b755-7c3b56513722";
    const taskId = "b7071652-fd3a-4a30-b755-7c3b56513723";
    const project = await seedNativeBoardProject({ id: projectId, name: "Launch", description: "Ship it" });
    await seedNativeBoardTask({ id: taskId, number: 1, title: "Write launch task", description: "Task body", projectId });

    projectSvc.list.mockResolvedValue([
      {
        ...project,
        id: projectId,
        companyId: nativeCompanyId,
        name: "Launch",
        urlKey: "launch",
        description: "Ship it",
        leadAgentId: null,
        targetDate: null,
        color: null,
        status: "planned",
        executionWorkspacePolicy: null,
        archivedAt: null,
      },
    ]);
    issueSvc.list.mockResolvedValue([
      {
        id: taskId,
        identifier: "PAP-1",
        title: "Write launch task",
        description: "Task body",
        projectId,
        assigneeAgentId: null,
        createdByUserId: nativeUserId,
        responsibleUserId: nativeUserId,
        status: "todo",
        priority: "medium",
        labelIds: [],
        billingCode: null,
        executionWorkspaceSettings: null,
        assigneeAdapterOverrides: null,
      },
    ]);

    const preview = await portability.previewExport(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: true,
      },
    }, { actor: nativeActor });

    expect(preview.counts.issues).toBe(0);
    expect(preview.fileInventory.some((entry) => entry.path.startsWith("tasks/"))).toBe(false);
    expect(preview.fileInventory.some((entry) => entry.path === "images/org-chart.png")).toBe(false);

    const downloaded = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: true,
        issues: false,
      },
    }, { actor: nativeActor });
    expect(downloaded.files["images/org-chart.png"]).toMatchObject({
      encoding: "base64",
      contentType: "image/png",
    });
  });

  itNative("prefetches task export records with bounded concurrency", async () => {
    const portability = companyPortabilityService(nativeDb);
    const { seedCurrentHumanSourceActor } = await import("./helpers/current-human-source-fixture.js");
    const exportActor = await seedCurrentHumanSourceActor(nativeDb, [nativeCompanyId], nativeUserId);
    useNativeExportCompany();
    const issueIds = ["b7071652-fd3a-4a30-b755-7c3b56513724", "b7071652-fd3a-4a30-b755-7c3b56513725", "b7071652-fd3a-4a30-b755-7c3b56513726"];
    for (const [index, id] of issueIds.entries()) {
      await seedNativeBoardTask({ id, number: index + 2, title: `Task ${index + 1}` });
    }
    const taskRows = issueIds.map((id, index) => ({
      id,
      companyId: nativeCompanyId,
      visibility: "open",
      privacyRootIssueId: id,
      privacyParentIssueId: null,
      createdByUserId: nativeUserId,
      responsibleUserId: nativeUserId,
      identifier: `PAP-${index + 2}`,
      title: `Task ${index + 1}`,
      description: null,
      projectId: null,
      projectWorkspaceId: null,
      parentId: null,
      assigneeAgentId: null,
      status: "todo",
      priority: "medium",
      labelIds: [],
      billingCode: null,
      executionWorkspaceSettings: null,
      assigneeAdapterOverrides: null,
    }));
    issueSvc.list.mockResolvedValue(taskRows);

    let releaseFirstWave!: (comments: never[]) => void;
    const firstWave = new Promise<never[]>((resolve) => {
      releaseFirstWave = resolve;
    });
    issueSvc.listComments.mockImplementation(async (issueId: string) => {
      if (issueId === issueIds[0] || issueId === issueIds[1]) return firstWave;
      return [];
    });

    const exportPromise = portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: false,
        projects: false,
        issues: true,
        skills: false,
      },
    }, { actor: exportActor });

    let waitError: unknown;
    try {
      await vi.waitFor(() => {
        expect(issueSvc.listComments).toHaveBeenCalledTimes(2);
      }, { timeout: 10_000 });
      expect(issueSvc.listComments.mock.calls.map(([issueId]) => issueId)).toEqual(issueIds.slice(0, 2));
    } catch (error) {
      waitError = error;
    } finally {
      releaseFirstWave([]);
    }

    await exportPromise;
    if (waitError) throw waitError;
    expect(issueSvc.listComments).toHaveBeenCalledTimes(3);
  });

  it("exports portable project workspace metadata and remaps it on import", async () => {
    const portability = currentHumanExportPortability();

    projectSvc.list.mockResolvedValue([
      {
        id: "project-1",
        name: "Launch",
        urlKey: "launch",
        description: "Ship it",
        leadAgentId: "agent-1",
        targetDate: "2026-03-31",
        color: "#123456",
        icon: "rocket",
        status: "planned",
        executionWorkspacePolicy: {
          enabled: true,
          defaultMode: "shared_workspace",
          defaultProjectWorkspaceId: "workspace-1",
          workspaceStrategy: {
            type: "project_primary",
          },
        },
        workspaces: [
          {
            id: "workspace-1",
            companyId: "company-1",
            projectId: "project-1",
            name: "Main Repo",
            sourceType: "git_repo",
            cwd: "/Users/dotta/paperclip",
            repoUrl: "https://github.com/paperclipai/paperclip.git",
            repoRef: "main",
            defaultRef: "main",
            visibility: "default",
            setupCommand: "pnpm install",
            cleanupCommand: "rm -rf .paperclip-tmp",
            remoteProvider: null,
            remoteWorkspaceRef: null,
            sharedWorkspaceKey: null,
            metadata: {
              language: "typescript",
            },
            isPrimary: true,
            createdAt: new Date("2026-03-01T00:00:00Z"),
            updatedAt: new Date("2026-03-01T00:00:00Z"),
          },
          {
            id: "workspace-2",
            companyId: "company-1",
            projectId: "project-1",
            name: "Local Scratch",
            sourceType: "local_path",
            cwd: "/tmp/paperclip-local",
            repoUrl: null,
            repoRef: null,
            defaultRef: null,
            visibility: "advanced",
            setupCommand: null,
            cleanupCommand: null,
            remoteProvider: null,
            remoteWorkspaceRef: null,
            sharedWorkspaceKey: null,
            metadata: null,
            isPrimary: false,
            createdAt: new Date("2026-03-01T00:00:00Z"),
            updatedAt: new Date("2026-03-01T00:00:00Z"),
          },
        ],
        archivedAt: null,
      },
    ]);
    issueSvc.list.mockResolvedValue([
      {
        id: "issue-1",
        identifier: "PAP-1",
        title: "Write launch task",
        description: "Task body",
        projectId: "project-1",
        projectWorkspaceId: "workspace-1",
        assigneeAgentId: "agent-1",
        status: "todo",
        priority: "medium",
        labelIds: [],
        billingCode: null,
        executionWorkspaceSettings: {
          mode: "shared_workspace",
        },
        assigneeAdapterOverrides: null,
      },
    ]);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: false,
        projects: true,
        issues: true,
      },
    });

    const extension = asTextFile(exported.files[".paperclip.yaml"]);
    expect(extension).toContain('icon: "rocket"');
    expect(extension).toContain("workspaces:");
    expect(extension).toContain("main-repo:");
    expect(extension).toContain('repoUrl: "https://github.com/paperclipai/paperclip.git"');
    expect(extension).toContain('defaultProjectWorkspaceKey: "main-repo"');
    expect(extension).toContain('projectWorkspaceKey: "main-repo"');
    expect(extension).not.toContain("/Users/dotta/paperclip");
    expect(extension).not.toContain("workspace-1");
    expect(exported.warnings).toContain("Project launch workspace Local Scratch was omitted from export because it does not have a portable repoUrl.");

    companySvc.create.mockResolvedValue({
      id: "company-imported",
      name: "Imported Paperclip",
    });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.list.mockResolvedValue([]);
    projectSvc.list.mockResolvedValue([]);
    projectSvc.create.mockResolvedValue({
      id: "project-imported",
      name: "Launch",
      urlKey: "launch",
    });
    projectSvc.update.mockImplementation(async (projectId: string, data: Record<string, unknown>) => ({
      id: projectId,
      name: "Launch",
      urlKey: "launch",
      ...data,
    }));
    projectSvc.createWorkspace.mockImplementation(async (projectId: string, data: Record<string, unknown>) => ({
      id: "workspace-imported",
      companyId: "company-imported",
      projectId,
      name: `${data.name ?? "Workspace"}`,
      sourceType: `${data.sourceType ?? "git_repo"}`,
      cwd: null,
      repoUrl: typeof data.repoUrl === "string" ? data.repoUrl : null,
      repoRef: typeof data.repoRef === "string" ? data.repoRef : null,
      defaultRef: typeof data.defaultRef === "string" ? data.defaultRef : null,
      visibility: `${data.visibility ?? "default"}`,
      setupCommand: typeof data.setupCommand === "string" ? data.setupCommand : null,
      cleanupCommand: typeof data.cleanupCommand === "string" ? data.cleanupCommand : null,
      remoteProvider: null,
      remoteWorkspaceRef: null,
      sharedWorkspaceKey: null,
      metadata: (data.metadata as Record<string, unknown> | null | undefined) ?? null,
      isPrimary: Boolean(data.isPrimary),
      createdAt: new Date("2026-03-02T00:00:00Z"),
      updatedAt: new Date("2026-03-02T00:00:00Z"),
    }));
    issueSvc.create.mockResolvedValue({
      id: "issue-imported",
      title: "Write launch task",
    });

    const importRequest = await reviewExactPackageAsCurrentHuman(portability, {
      source: {
        type: "inline",
        rootPath: exported.rootPath,
        files: exported.files,
      },
      include: {
        company: true,
        agents: false,
        projects: true,
        issues: true,
      },
      target: {
        mode: "new_company",
        newCompanyName: "Imported Paperclip",
      },
      collisionStrategy: "rename",
    });
    await portability.importBundle(importRequest, nativeUserId, { actor: nativeActor, privateWorkAdmission: "closed" });

    expect(projectSvc.createWorkspace).toHaveBeenCalledWith("project-imported", expect.objectContaining({
      name: "Main Repo",
      sourceType: "git_repo",
      repoUrl: "https://github.com/paperclipai/paperclip.git",
      repoRef: "main",
      defaultRef: "main",
      visibility: "default",
    }));
    expect(projectSvc.update).toHaveBeenCalledWith("project-imported", expect.objectContaining({
      executionWorkspacePolicy: expect.objectContaining({
        enabled: true,
        defaultMode: "shared_workspace",
        defaultProjectWorkspaceId: "workspace-imported",
      }),
    }));
    expect(projectSvc.create).toHaveBeenCalledWith("company-imported", expect.objectContaining({
      icon: "rocket",
    }), expect.anything(), nativeActor);
    expect(issueSvc.importIssues).toHaveBeenCalledWith("company-imported", expect.arrayContaining([
      expect.objectContaining({
        projectId: "project-imported",
        projectWorkspaceId: "workspace-imported",
        title: "Write launch task",
      }),
    ]), expect.anything(), expect.objectContaining({ actor: nativeActor, privateWorkAdmission: "closed" }));
  });

  it("normalizes invalid imported project icon names to null", async () => {
    const portability = currentHumanExportPortability();

    companySvc.create.mockResolvedValue({
      id: "company-imported",
      name: "Imported Paperclip",
    });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.list.mockResolvedValue([]);
    projectSvc.list.mockResolvedValue([]);
    projectSvc.create.mockResolvedValue({
      id: "project-imported",
      name: "Launch",
      urlKey: "launch",
    });

    const files = {
      "COMPANY.md": [
        "---",
        'schema: "agentcompanies/v1"',
        'name: "Imported Paperclip"',
        "---",
        "",
      ].join("\n"),
      "projects/launch/PROJECT.md": [
        "---",
        'name: "Launch"',
        "---",
        "",
      ].join("\n"),
      ".paperclip.yaml": [
        'schema: "paperclip/v1"',
        "projects:",
        "  launch:",
        '    icon: "not-a-project-icon"',
        "",
      ].join("\n"),
    };

    const importRequest = await reviewExactPackageAsCurrentHuman(portability, {
      source: { type: "inline", rootPath: "paperclip-demo", files },
      include: { company: true, agents: false, projects: true, issues: false },
      target: { mode: "new_company", newCompanyName: "Imported Paperclip" },
      collisionStrategy: "rename",
    });
    await portability.importBundle(importRequest, nativeUserId, { actor: nativeActor, privateWorkAdmission: "closed" });

    expect(projectSvc.create).toHaveBeenCalledWith("company-imported", expect.objectContaining({
      icon: null,
    }), expect.anything(), nativeActor);
  });

  itNative("infers portable git metadata from a local checkout without task warning fan-out", async () => {
    const portability = companyPortabilityService(nativeDb);
    useNativeExportCompany();
    const projectId = "b7071652-fd3a-4a30-b755-7c3b56513730";
    const taskId = "b7071652-fd3a-4a30-b755-7c3b56513731";
    const project = await seedNativeBoardProject({ id: projectId, name: "Paperclip App", description: "Ship it" });
    const task = await seedNativeBoardTask({ id: taskId, number: 901, title: "Task one", description: "Task body", projectId });
    const repoDir = await fs.mkdtemp(path.join(os.tmpdir(), "paperclip-portability-git-"));
    execFileSync("git", ["init"], { cwd: repoDir, stdio: "ignore" });
    execFileSync("git", ["checkout", "-b", "main"], { cwd: repoDir, stdio: "ignore" });
    execFileSync("git", ["remote", "add", "origin", "https://github.com/paperclipai/paperclip.git"], {
      cwd: repoDir,
      stdio: "ignore",
    });

    projectSvc.list.mockResolvedValue([
      {
        ...project,
        id: projectId,
        name: "Paperclip App",
        urlKey: "paperclip-app",
        description: "Ship it",
        leadAgentId: null,
        targetDate: null,
        color: null,
        status: "planned",
        executionWorkspacePolicy: {
          enabled: true,
          defaultMode: "shared_workspace",
          defaultProjectWorkspaceId: "workspace-1",
        },
        workspaces: [
          {
            id: "workspace-1",
            companyId: "company-1",
            projectId: "project-1",
            name: "paperclip",
            sourceType: "local_path",
            cwd: repoDir,
            repoUrl: null,
            repoRef: null,
            defaultRef: null,
            visibility: "default",
            setupCommand: null,
            cleanupCommand: null,
            remoteProvider: null,
            remoteWorkspaceRef: null,
            sharedWorkspaceKey: null,
            metadata: null,
            isPrimary: true,
            createdAt: new Date("2026-03-01T00:00:00Z"),
            updatedAt: new Date("2026-03-01T00:00:00Z"),
          },
        ],
        archivedAt: null,
      },
    ]);
    issueSvc.list.mockResolvedValue([
      {
        ...task,
        id: taskId,
        identifier: "PAP-901",
        title: "Task one",
        description: "Task body",
        projectId,
        projectWorkspaceId: "workspace-1",
        assigneeAgentId: null,
        status: "todo",
        priority: "medium",
        labelIds: [],
        billingCode: null,
        executionWorkspaceSettings: null,
        assigneeAdapterOverrides: null,
      },
    ]);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: false,
        agents: false,
        projects: true,
        issues: true,
      },
    }, { actor: nativeActor });

    const extension = asTextFile(exported.files[".paperclip.yaml"]);
    expect(extension).toContain('repoUrl: "https://github.com/paperclipai/paperclip.git"');
    expect(extension).toContain('projectWorkspaceKey: "paperclip"');
    expect(exported.warnings).not.toContainEqual(expect.stringContaining("does not have a portable repoUrl"));
    expect(exported.warnings).not.toContainEqual(expect.stringContaining("reference workspace workspace-1"));
  });

  it("collapses repeated task workspace warnings into one summary per missing workspace", async () => {
    const portability = currentHumanExportPortability();

    projectSvc.list.mockResolvedValue([
      {
        id: "project-1",
        name: "Launch",
        urlKey: "launch",
        description: "Ship it",
        leadAgentId: null,
        targetDate: null,
        color: null,
        status: "planned",
        executionWorkspacePolicy: null,
        workspaces: [
          {
            id: "workspace-1",
            companyId: "company-1",
            projectId: "project-1",
            name: "Local Scratch",
            sourceType: "local_path",
            cwd: "/tmp/local-only",
            repoUrl: null,
            repoRef: null,
            defaultRef: null,
            visibility: "default",
            setupCommand: null,
            cleanupCommand: null,
            remoteProvider: null,
            remoteWorkspaceRef: null,
            sharedWorkspaceKey: null,
            metadata: null,
            isPrimary: true,
            createdAt: new Date("2026-03-01T00:00:00Z"),
            updatedAt: new Date("2026-03-01T00:00:00Z"),
          },
        ],
        archivedAt: null,
      },
    ]);
    issueSvc.list.mockResolvedValue([
      {
        id: "issue-1",
        identifier: "PAP-1",
        title: "Task one",
        description: null,
        projectId: "project-1",
        projectWorkspaceId: "workspace-1",
        assigneeAgentId: null,
        status: "todo",
        priority: "medium",
        labelIds: [],
        billingCode: null,
        executionWorkspaceSettings: null,
        assigneeAdapterOverrides: null,
      },
      {
        id: "issue-2",
        identifier: "PAP-2",
        title: "Task two",
        description: null,
        projectId: "project-1",
        projectWorkspaceId: "workspace-1",
        assigneeAgentId: null,
        status: "todo",
        priority: "medium",
        labelIds: [],
        billingCode: null,
        executionWorkspaceSettings: null,
        assigneeAdapterOverrides: null,
      },
      {
        id: "issue-3",
        identifier: "PAP-3",
        title: "Task three",
        description: null,
        projectId: "project-1",
        projectWorkspaceId: "workspace-1",
        assigneeAgentId: null,
        status: "todo",
        priority: "medium",
        labelIds: [],
        billingCode: null,
        executionWorkspaceSettings: null,
        assigneeAdapterOverrides: null,
      },
    ]);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: false,
        agents: false,
        projects: true,
        issues: true,
      },
    });

    expect(exported.warnings).toContain("Project launch workspace Local Scratch was omitted from export because it does not have a portable repoUrl.");
    const normalizedWorkspaceId = nativeWorkspaceUuid(nativeSourceUuid("project", "project-1"), "workspace-1");
    expect(exported.warnings).toContain(`Tasks pap-1, pap-2, pap-3 reference workspace ${normalizedWorkspaceId}, but that workspace could not be exported portably.`);
    expect(exported.warnings.filter((warning) => warning.includes(`workspace reference ${normalizedWorkspaceId} was omitted from export`))).toHaveLength(0);
    expect(exported.warnings.filter((warning) => warning.includes("could not be exported portably"))).toHaveLength(1);
  });

  itNative("round-trips the saved visual persona through the portable bundle", async () => {
    const appearance = { schemaVersion: 1, characterVersion: "cap-v1", paletteId: "arctic-blue" };
    const source = await agentSvc.list();
    agentSvc.list.mockResolvedValue(source.map((agent: Record<string, unknown>) => ({ ...agent, appearance })));
    useNativeExportCompany();
    const portability = companyPortabilityService(nativeDb);
    const include = { company: true, agents: true, projects: false, issues: false, skills: false };
    const exported = await portability.exportBundle(nativeCompanyId, { include }, { actor: nativeActor });
    expect(asTextFile(exported.files[".paperclip.yaml"])).toContain("arctic-blue");
    agentSvc.list.mockResolvedValue([]);
    agentSvc.create.mockImplementation(async (_companyId: string, input: Record<string, unknown>) => ({ ...input, id: `imported-${input.name}` }));
    await portability.importBundle({ source: { type: "inline", files: exported.files, rootPath: exported.rootPath }, include,
      target: { mode: "new_company", newCompanyName: "Imported personas" }, collisionStrategy: "rename", agents: "all" }, "user-1");
    expect(agentSvc.create).toHaveBeenCalled();
    for (const [, input] of agentSvc.create.mock.calls) expect(input).toMatchObject({ appearance });
  });

  itNative("reads env inputs back from .paperclip.yaml during preview import", async () => {
    useNativeExportCompany();
    const portability = companyPortabilityService(nativeDb);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
    }, { actor: nativeActor });

    const preview = await portability.previewImport({
      source: {
        type: "inline",
        rootPath: exported.rootPath,
        files: exported.files,
      },
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
      target: {
        mode: "new_company",
        newCompanyName: "Imported Paperclip",
      },
      agents: "all",
      collisionStrategy: "rename",
    });

    expect(preview.errors).toEqual([]);
    expect(preview.envInputs).toEqual([
      {
        key: "ANTHROPIC_API_KEY",
        description: "Provide ANTHROPIC_API_KEY for agent claudecoder",
        agentSlug: "claudecoder",
        projectSlug: null,
        kind: "secret",
        requirement: "optional",
        defaultValue: "",
        portability: "portable",
      },
      {
        key: "GH_TOKEN",
        description: "Provide GH_TOKEN for agent claudecoder",
        agentSlug: "claudecoder",
        projectSlug: null,
        kind: "secret",
        requirement: "optional",
        defaultValue: "",
        portability: "portable",
      },
    ]);
  });

  it("keeps support case archives reserved and informational during import", async () => {
    const portability = companyPortabilityService({} as any);
    const archivePath = "blentera-support-cases-v1.json";
    const source = {
      type: "inline" as const,
      files: {
        "COMPANY.md": "---\nname: Imported Support Archive\n---\n",
        [archivePath]: JSON.stringify({ schema: "blentera.support-cases.v1", cases: [{ description: "private support text" }] }),
      },
    };
    const requestBase = {
      source,
      include: { company: true, agents: false, projects: false, issues: false },
      target: { mode: "new_company" as const, newCompanyName: "Imported Support Archive" },
      collisionStrategy: "rename" as const,
    };

    await expect(portability.previewImport({
      ...requestBase,
      selectedFiles: ["COMPANY.md", archivePath],
    })).rejects.toMatchObject({ status: 422 });
    await expect(portability.previewImport({
      ...requestBase,
      include: { ...requestBase.include, supportCases: true },
      selectedFiles: ["COMPANY.md"],
    })).rejects.toMatchObject({ status: 422 });
    await expect(portability.importBundle({
      ...requestBase,
      selectedFiles: ["COMPANY.md", archivePath],
    }, "user-1")).rejects.toMatchObject({ status: 422 });
    expect(companySvc.create).not.toHaveBeenCalled();

    const imported = await portability.importBundle({
      ...requestBase,
      selectedFiles: ["COMPANY.md"],
    }, "user-1");
    expect(imported.company.action).toBe("created");
    expect(companySvc.create).toHaveBeenCalledTimes(1);
  });

  it("confirms cancellation before the first write and fences at later import checkpoints", async () => {
    const portability = companyPortabilityService({} as any);
    const request = {
      source: { type: "inline" as const, files: { "COMPANY.md": "---\nname: Import checkpoint\n---\n" } },
      include: { company: true, agents: false, projects: false, issues: false },
      target: { mode: "new_company" as const, newCompanyName: "Import checkpoint" },
      collisionStrategy: "rename" as const,
      selectedFiles: ["COMPANY.md"],
    };

    const beforeEffect = portability.importBundle(request, "user-1", {
      checkCancellation: async () => true,
    });
    await expect(beforeEffect).rejects.toBeInstanceOf(ImportCancellationError);
    await expect(beforeEffect).rejects.toMatchObject({ effectsStarted: false });
    expect(companySvc.create).not.toHaveBeenCalled();

    companySvc.create.mockResolvedValue({ id: "company-import-checkpoint", name: "Import checkpoint" });
    let checks = 0;
    const afterEffect = portability.importBundle(request, "user-1", {
      checkCancellation: async () => ++checks === 3,
    });
    await expect(afterEffect).rejects.toBeInstanceOf(ImportCancellationError);
    await expect(afterEffect).rejects.toMatchObject({ effectsStarted: true });
    expect(companySvc.create).toHaveBeenCalledTimes(1);
  });

  itNative("requires an exact current-Human review before manual cross-company work and denies private claims", async () => {
    const portability = companyPortabilityService(nativeDb);
    const request: CompanyPortabilityImportRequest = {
      source: { type: "inline", rootPath: "manual-source", files: {
        "COMPANY.md": "---\nname: Manual source\n---\n",
        "projects/review/PROJECT.md": "---\nname: Review\n---\n",
      } },
      include: { company: true, agents: false, projects: true, issues: false },
      target: { mode: "new_company", newCompanyName: "Reviewed destination" },
      collisionStrategy: "rename",
    };
    await expect(portability.importBundle(request, nativeUserId, { actor: nativeActor, privateWorkAdmission: "closed" }))
      .rejects.toMatchObject({ status: 422, message: expect.stringContaining("exact package") });
    expect(companySvc.create).not.toHaveBeenCalled();

    const reviewed = await reviewExactPackageAsCurrentHuman(portability, request);
    const changed = { ...reviewed, source: { ...reviewed.source, files: { ...reviewed.source.files,
      "projects/review/PROJECT.md": "---\nname: Changed after review\n---\n" } } };
    await expect(portability.importBundle(changed, nativeUserId, { actor: nativeActor, privateWorkAdmission: "closed" }))
      .rejects.toMatchObject({ status: 409, message: expect.stringContaining("changed after preview") });
    expect(companySvc.create).not.toHaveBeenCalled();

    const privateRequest: CompanyPortabilityImportRequest = { ...request, source: { ...request.source, files: {
      ...request.source.files,
      ".paperclip.yaml": "schema: \"paperclip/v1\"\nprojects:\n  review:\n    visibility: \"private\"\n",
    } } };
    const privateReview = await reviewExactPackageAsCurrentHuman(portability, privateRequest);
    await expect(portability.importBundle(privateReview, nativeUserId, { actor: nativeActor, privateWorkAdmission: "closed" }))
      .rejects.toMatchObject({ status: 422, message: expect.stringContaining("Private or restricted") });
    expect(companySvc.create).not.toHaveBeenCalled();

    const receipts: unknown[] = [];
    const targets: string[] = [];
    await portability.importBundle(reviewed, nativeUserId, { actor: nativeActor, privateWorkAdmission: "closed",
      onSourceReleaseReview: async receipt => { receipts.push(receipt); },
      onSourceReleaseTargetBound: async companyId => { targets.push(companyId); },
    });
    expect(receipts).toEqual([expect.objectContaining({
      sourceMode: "manual_open_content", sourceCompanyIds: [],
      sourceItems: [{ kind: "project", id: "external:review", slug: "review" }],
      sourceAccess: "reviewed_open_external", targetMode: "new_company", targetCompanyId: null,
      reviewedByUserId: nativeUserId,
    })]);
    expect(targets).toEqual(["company-imported"]);
    expect(projectSvc.create).toHaveBeenCalledWith("company-imported", expect.objectContaining({
      sourceIssueIds: [], sourceProjectIds: [], sourceProvenanceQualified: false,
      visibility: "open", privacyOwnerUserId: nativeUserId,
    }), expect.anything(), nativeActor);
  });

  it("materializes required agent env inputs from import secretValues as company secrets", async () => {
    const portability = unitImportPortability();
    agentSvc.list.mockResolvedValue([]);
    agentSvc.create.mockImplementation(async (_companyId: string, input: Record<string, unknown>) => ({
      id: "agent-imported",
      name: input.name,
      adapterType: input.adapterType,
      adapterConfig: input.adapterConfig,
      status: input.status,
    }));

    await portability.importBundle({
      source: {
        type: "inline",
        files: {
          "COMPANY.md": [
            "---",
            "name: Import",
            "includes:",
            "  - agents/coder/AGENTS.md",
            "---",
            "",
          ].join("\n"),
          "agents/coder/AGENTS.md": [
            "---",
            "name: Coder",
            "slug: coder",
            "kind: agent",
            "---",
            "",
            "# Coder",
            "",
          ].join("\n"),
          ".paperclip.yaml": [
            "schema: paperclip/v1",
            "agents:",
            "  coder:",
            "    adapter:",
            "      type: codex_local",
            "      config: {}",
            "    inputs:",
            "      env:",
            "        OPENAI_API_KEY:",
            "          kind: secret",
            "          requirement: required",
            "",
          ].join("\n"),
        },
      },
      include: {
        company: false,
        agents: true,
        projects: false,
        issues: false,
      },
      target: {
        mode: "existing_company",
        companyId: "company-1",
      },
      collisionStrategy: "rename",
      secretValues: {
        "agent:coder:OPENAI_API_KEY": "sk-imported",
      },
    }, "user-1");

    expect(secretSvc.create).toHaveBeenCalledWith(
      "company-1",
      expect.objectContaining({
        provider: "local_encrypted",
        value: "sk-imported",
        description: expect.stringContaining("OPENAI_API_KEY"),
      }),
      { userId: "user-1", agentId: null },
    );
    expect(secretSvc.normalizeAdapterConfigForPersistence).toHaveBeenCalledWith(
      "company-1",
      expect.objectContaining({
        env: {
          OPENAI_API_KEY: {
            type: "secret_ref",
            secretId: "secret-created",
            version: "latest",
          },
        },
      }),
      { strictMode: false, adapterType: "codex_local" },
    );
    expect(agentSvc.create).toHaveBeenCalledWith("company-1", expect.objectContaining({
      adapterConfig: expect.objectContaining({
        env: {
          OPENAI_API_KEY: {
            type: "secret_ref",
            secretId: "secret-created",
            version: "latest",
          },
        },
      }),
    }), expect.objectContaining({ transaction: expect.anything() }));
    expect(secretSvc.syncEnvBindingsForTarget).toHaveBeenCalledWith(
      "company-1",
      { targetType: "agent", targetId: "agent-imported" },
      expect.objectContaining({
        OPENAI_API_KEY: expect.objectContaining({ secretId: "secret-created" }),
      }),
    );
  });

  it("imports agent permission grants from package metadata", async () => {
    const portability = unitImportPortability();
    agentSvc.list.mockResolvedValue([]);
    agentSvc.create.mockImplementation(async (_companyId: string, input: Record<string, unknown>) => ({
      id: "agent-imported",
      name: input.name,
      adapterType: input.adapterType,
      adapterConfig: input.adapterConfig,
      runtimeConfig: input.runtimeConfig,
      status: input.status,
    }));

    await portability.importBundle({
      source: {
        type: "inline",
        files: {
          "COMPANY.md": [
            "---",
            "name: Import",
            "includes:",
            "  - agents/coder/AGENTS.md",
            "---",
            "",
          ].join("\n"),
          "agents/coder/AGENTS.md": [
            "---",
            "name: Coder",
            "slug: coder",
            "kind: agent",
            "---",
            "",
            "# Coder",
            "",
          ].join("\n"),
          ".paperclip.yaml": [
            "schema: paperclip/v1",
            "agents:",
            "  coder:",
            "    adapter:",
            "      type: process",
            "      config: {}",
            "    permissionGrants:",
            "      - permissionKey: agents:suggest-changes",
            "      - permissionKey: skills:create",
            "        scope:",
            "          targetAgentIds:",
            "            - agent-imported",
            "",
          ].join("\n"),
        },
      },
      include: {
        company: false,
        agents: true,
        projects: false,
        issues: false,
      },
      target: {
        mode: "existing_company",
        companyId: "company-1",
      },
      collisionStrategy: "rename",
    }, "user-1");

    expect(accessSvc.setPrincipalPermission).toHaveBeenCalledWith(
      "company-1",
      "agent",
      "agent-imported",
      "agents:suggest-changes",
      true,
      "user-1",
      null,
    );
    expect(accessSvc.setPrincipalPermission).toHaveBeenCalledWith(
      "company-1",
      "agent",
      "agent-imported",
      "skills:create",
      true,
      "user-1",
      { targetAgentIds: ["agent-imported"] },
    );
  });

  it("retains the completed secret receipt for reconciliation after a later import failure", async () => {
    const portability = unitImportPortability();
    agentSvc.list.mockResolvedValue([]);
    secretSvc.create.mockResolvedValueOnce({ id: "secret-created-for-failed-import" });
    agentSvc.create.mockRejectedValueOnce(new Error("agent create failed"));
    const checkpoints: Array<{ phase: string; key: string; kind: string; targetIds?: string[] }> = [];

    await expect(portability.importBundle({
      source: {
        type: "inline",
        files: {
          "COMPANY.md": [
            "---",
            "name: Import",
            "includes:",
            "  - agents/coder/AGENTS.md",
            "---",
            "",
          ].join("\n"),
          "agents/coder/AGENTS.md": [
            "---",
            "name: Coder",
            "slug: coder",
            "kind: agent",
            "---",
            "",
            "# Coder",
            "",
          ].join("\n"),
          ".paperclip.yaml": [
            "schema: paperclip/v1",
            "agents:",
            "  coder:",
            "    adapter:",
            "      type: codex_local",
            "      config: {}",
            "    inputs:",
            "      env:",
            "        OPENAI_API_KEY:",
            "          kind: secret",
            "          requirement: required",
            "",
          ].join("\n"),
        },
      },
      include: {
        company: false,
        agents: true,
        projects: false,
        issues: false,
      },
      target: {
        mode: "existing_company",
        companyId: "company-1",
      },
      collisionStrategy: "rename",
      secretValues: {
        "agent:coder:OPENAI_API_KEY": "sk-imported",
      },
    }, "user-1", { onEffectCheckpoint: async event => { checkpoints.push(event); } })).rejects.toThrow("agent create failed");

    expect(secretSvc.remove).not.toHaveBeenCalled();
    expect(checkpoints).toContainEqual(expect.objectContaining({
      phase: "completed", key: "environment:secret:0", kind: "environment_secret",
      targetIds: ["secret-created-for-failed-import"],
    }));
  });

  it("fails closed on an inline import that arrived with fewer files than declared", async () => {
    const portability = companyPortabilityService({} as any);
    agentSvc.list.mockResolvedValue([]);

    // The client declared four files, but the body was truncated in transit and
    // only three arrived. The import must reject the fragment before writing any
    // rows — not create a company and import a partial bundle.
    await expect(portability.importBundle({
      source: {
        type: "inline",
        expectedFileCount: 4,
        files: {
          "COMPANY.md": [
            "---",
            "name: Import",
            "includes:",
            "  - agents/coder/AGENTS.md",
            "---",
            "",
          ].join("\n"),
          "agents/coder/AGENTS.md": [
            "---",
            "name: Coder",
            "slug: coder",
            "kind: agent",
            "---",
            "",
            "# Coder",
            "",
          ].join("\n"),
          ".paperclip.yaml": [
            "schema: paperclip/v1",
            "agents:",
            "  coder:",
            "    adapter:",
            "      type: codex_local",
            "      config: {}",
            "",
          ].join("\n"),
        },
      },
      include: { company: true, agents: true, projects: false, issues: false },
      target: { mode: "new_company", newCompanyName: "Imported" },
      collisionStrategy: "rename",
    }, "user-1")).rejects.toMatchObject({
      status: 422,
      details: { code: "import_payload_incomplete", expectedFileCount: 4, receivedFileCount: 3 },
    });

    expect(companySvc.create).not.toHaveBeenCalled();
    expect(agentSvc.create).not.toHaveBeenCalled();
  });

  it("imports an inline bundle whose file count matches the declared count", async () => {
    const portability = unitImportPortability();
    agentSvc.list.mockResolvedValue([]);
    agentSvc.create.mockImplementation(async (_companyId: string, input: Record<string, unknown>) => ({
      id: "agent-imported",
      name: input.name,
      adapterType: input.adapterType,
      adapterConfig: input.adapterConfig,
      status: input.status,
    }));

    const files = {
      "COMPANY.md": [
        "---",
        "name: Import",
        "includes:",
        "  - agents/coder/AGENTS.md",
        "---",
        "",
      ].join("\n"),
      "agents/coder/AGENTS.md": [
        "---",
        "name: Coder",
        "slug: coder",
        "kind: agent",
        "---",
        "",
        "# Coder",
        "",
      ].join("\n"),
      ".paperclip.yaml": [
        "schema: paperclip/v1",
        "agents:",
        "  coder:",
        "    adapter:",
        "      type: codex_local",
        "      config: {}",
        "",
      ].join("\n"),
    };

    const result = await portability.importBundle({
      source: { type: "inline", expectedFileCount: Object.keys(files).length, files },
      include: { company: false, agents: true, projects: false, issues: false },
      target: { mode: "existing_company", companyId: "company-1" },
      collisionStrategy: "rename",
    }, "user-1");

    expect(result.company.id).toBe("company-1");
    expect(agentSvc.create).toHaveBeenCalledTimes(1);
  });

  it("reparents imported roots to pre-existing target managers before resolving imported hierarchy", async () => {
    const portability = unitImportPortability();
    agentSvc.list.mockResolvedValue([
      {
        id: "existing-ceo",
        name: "CEO",
        status: "idle",
        role: "ceo",
        adapterType: "claude_local",
        adapterConfig: {},
        runtimeConfig: {},
        budgetMonthlyCents: 0,
        permissions: {},
        metadata: null,
      },
    ]);
    agentSvc.create.mockImplementation(async (_companyId: string, input: Record<string, unknown>) => ({
      id: `${String(input.name).toLowerCase()}-created`,
      name: input.name,
      status: input.status,
      adapterType: input.adapterType,
      adapterConfig: input.adapterConfig,
      runtimeConfig: input.runtimeConfig,
    }));

    await portability.importBundle({
      source: {
        type: "inline",
        rootPath: "paperclip-demo",
        files: {
          "COMPANY.md": [
            "---",
            'schema: "agentcompanies/v1"',
            'name: "Imported Paperclip"',
            "includes:",
            "  - agents/cto/AGENTS.md",
            "  - agents/qa/AGENTS.md",
            "---",
            "",
          ].join("\n"),
          "agents/cto/AGENTS.md": [
            "---",
            'name: "CTO"',
            'slug: "cto"',
            'kind: "agent"',
            "---",
            "",
            "Lead engineering.",
            "",
          ].join("\n"),
          "agents/qa/AGENTS.md": [
            "---",
            'name: "QA"',
            'slug: "qa"',
            'kind: "agent"',
            'reportsTo: "cto"',
            "---",
            "",
            "Verify engineering work.",
            "",
          ].join("\n"),
          ".paperclip.yaml": [
            'schema: "paperclip/v1"',
            "agents:",
            "  cto:",
            '    reportsToExistingAgentId: "existing-ceo"',
            '    reportsToExistingAgentSlug: "ceo"',
            "    adapter:",
            '      type: "claude_local"',
            "  qa:",
            "    adapter:",
            '      type: "claude_local"',
            "",
          ].join("\n"),
        },
      },
      include: { company: false, agents: true, projects: false, issues: false, skills: false },
      target: { mode: "existing_company", companyId: "company-1" },
      collisionStrategy: "rename",
    }, "user-1");

    expect(agentSvc.update).toHaveBeenCalledWith("cto-created", { reportsTo: "existing-ceo" },
      expect.objectContaining({ transaction: expect.anything() }));
    expect(agentSvc.update).toHaveBeenCalledWith("qa-created", { reportsTo: "cto-created" },
      expect.objectContaining({ transaction: expect.anything() }));
  });

  itNative("exports project env as portable inputs without concrete values", async () => {
    const portability = companyPortabilityService(nativeDb);
    useNativeExportCompany();
    const projectId = "b7071652-fd3a-4a30-b755-7c3b56513732";
    const project = await seedNativeBoardProject({ id: projectId, name: "Launch", description: "Ship it" });

    projectSvc.list.mockResolvedValue([
      {
        ...project,
        id: projectId,
        name: "Launch",
        urlKey: "launch",
        description: "Ship it",
        leadAgentId: "agent-1",
        targetDate: null,
        color: null,
        status: "planned",
        env: {
          OPENAI_API_KEY: {
            type: "plain",
            value: "sk-project-secret",
          },
          DOCS_MODE: {
            type: "plain",
            value: "strict",
          },
          GITHUB_TOKEN: {
            type: "secret_ref",
            secretId: "11111111-1111-1111-1111-111111111111",
            version: "latest",
          },
        },
        executionWorkspacePolicy: null,
        workspaces: [],
        metadata: null,
      },
    ]);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: false,
        agents: false,
        projects: true,
        issues: false,
      },
    }, { actor: nativeActor });

    const extension = asTextFile(exported.files[".paperclip.yaml"]);
    expect(extension).toContain("OPENAI_API_KEY:");
    expect(extension).toContain("DOCS_MODE:");
    expect(extension).toContain("GITHUB_TOKEN:");
    expect(extension).not.toContain("sk-project-secret");
    expect(extension).not.toContain('type: "secret_ref"');
    expect(extension).not.toContain("11111111-1111-1111-1111-111111111111");
    expect(extension).toContain('default: "strict"');
    expect(extension).toContain('kind: "secret"');
    expect(extension).toContain('kind: "plain"');
  });

  it("reads project env inputs back from .paperclip.yaml during preview import", async () => {
    const portability = currentHumanExportPortability();

    projectSvc.list.mockResolvedValue([
      {
        id: "project-1",
        name: "Launch",
        urlKey: "launch",
        description: "Ship it",
        leadAgentId: "agent-1",
        targetDate: null,
        color: null,
        status: "planned",
        env: {
          OPENAI_API_KEY: {
            type: "plain",
            value: "sk-project-secret",
          },
        },
        executionWorkspacePolicy: null,
        workspaces: [],
        metadata: null,
      },
    ]);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: false,
        agents: false,
        projects: true,
        issues: false,
      },
    });

    const preview = await portability.previewImport({
      source: {
        type: "inline",
        rootPath: exported.rootPath,
        files: exported.files,
      },
      include: {
        company: false,
        agents: false,
        projects: true,
        issues: false,
      },
      target: {
        mode: "new_company",
        newCompanyName: "Imported Paperclip",
      },
      agents: "all",
      collisionStrategy: "rename",
    });

    expect(preview.errors).toEqual([]);
    expect(preview.envInputs).toContainEqual({
      key: "OPENAI_API_KEY",
      description: "Optional default for OPENAI_API_KEY on project launch",
      agentSlug: null,
      projectSlug: "launch",
      kind: "secret",
      requirement: "optional",
      defaultValue: "",
      portability: "portable",
    });
  });

  it("exports routines as recurring task packages with Paperclip routine extensions", async () => {
    const portability = currentHumanExportPortability();

    projectSvc.list.mockResolvedValue([
      {
        id: "project-1",
        name: "Launch",
        urlKey: "launch",
        description: "Ship it",
        leadAgentId: "agent-1",
        targetDate: null,
        color: null,
        status: "planned",
        executionWorkspacePolicy: null,
        archivedAt: null,
      },
    ]);
    routineSvc.list.mockResolvedValue([
      {
        id: "routine-1",
        companyId: "company-1",
        projectId: "project-1",
        goalId: null,
        parentIssueId: null,
        title: "Monday Review",
        description: "Review pipeline health",
        assigneeAgentId: "agent-1",
        priority: "high",
        status: "paused",
        concurrencyPolicy: "always_enqueue",
        catchUpPolicy: "enqueue_missed_with_cap",
        createdByAgentId: null,
        createdByUserId: null,
        updatedByAgentId: null,
        updatedByUserId: null,
        lastTriggeredAt: null,
        lastEnqueuedAt: null,
        createdAt: new Date(),
        updatedAt: new Date(),
        triggers: [
          {
            id: "trigger-1",
            companyId: "company-1",
            routineId: "routine-1",
            kind: "schedule",
            label: "Weekly cadence",
            enabled: true,
            cronExpression: "0 9 * * 1",
            timezone: "America/Chicago",
            nextRunAt: null,
            lastFiredAt: null,
            publicId: "public-1",
            secretId: "secret-1",
            signingMode: null,
            replayWindowSec: null,
            lastRotatedAt: null,
            lastResult: null,
            createdByAgentId: null,
            createdByUserId: null,
            updatedByAgentId: null,
            updatedByUserId: null,
            createdAt: new Date(),
            updatedAt: new Date(),
          },
          {
            id: "trigger-2",
            companyId: "company-1",
            routineId: "routine-1",
            kind: "webhook",
            label: "External nudge",
            enabled: false,
            cronExpression: null,
            timezone: null,
            nextRunAt: null,
            lastFiredAt: null,
            publicId: "public-2",
            secretId: "secret-2",
            signingMode: "hmac_sha256",
            replayWindowSec: 120,
            lastRotatedAt: null,
            lastResult: null,
            createdByAgentId: null,
            createdByUserId: null,
            updatedByAgentId: null,
            updatedByUserId: null,
            createdAt: new Date(),
            updatedAt: new Date(),
          },
        ],
        lastRun: null,
        activeIssue: null,
      },
    ]);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: true,
        issues: true,
        skills: false,
      },
    });

    expect(asTextFile(exported.files["tasks/monday-review/TASK.md"])).toContain('recurring: true');
    const extension = asTextFile(exported.files[".paperclip.yaml"]);
    expect(extension).toContain("routines:");
    expect(extension).toContain("monday-review:");
    expect(extension).toContain('cronExpression: "0 9 * * 1"');
    expect(extension).toContain('signingMode: "hmac_sha256"');
    expect(extension).not.toContain("secretId");
    expect(extension).not.toContain("publicId");
    expect(exported.manifest.issues).toEqual([
      expect.objectContaining({
        slug: "monday-review",
        recurring: true,
        status: "paused",
        priority: "high",
        routine: expect.objectContaining({
          concurrencyPolicy: "always_enqueue",
          catchUpPolicy: "enqueue_missed_with_cap",
          triggers: expect.arrayContaining([
            expect.objectContaining({ kind: "schedule", cronExpression: "0 9 * * 1", timezone: "America/Chicago" }),
            expect.objectContaining({ kind: "webhook", enabled: false, signingMode: "hmac_sha256", replayWindowSec: 120 }),
          ]),
        }),
      }),
    ]);
  });

  it("skips built-in managed agents and routines during export", async () => {
    const portability = currentHumanExportPortability();

    agentSvc.list.mockResolvedValue([
      {
        id: "agent-1",
        name: "ClaudeCoder",
        status: "idle",
        role: "engineer",
        title: "Software Engineer",
        icon: "code",
        reportsTo: null,
        capabilities: "Writes code",
        adapterType: "claude_local",
        adapterConfig: { promptTemplate: "You are ClaudeCoder." },
        runtimeConfig: { heartbeat: { intervalSec: 3600 } },
        budgetMonthlyCents: 0,
        permissions: { canCreateAgents: false },
        metadata: null,
      },
      {
        id: "agent-built-in",
        name: "Reflection Coach",
        status: "paused",
        role: "coach",
        title: "Reflection Coach",
        icon: "sparkles",
        reportsTo: null,
        capabilities: "Reviews trajectories",
        adapterType: "codex_local",
        adapterConfig: { promptTemplate: "You coach agents." },
        runtimeConfig: {},
        budgetMonthlyCents: 0,
        permissions: {},
        metadata: {
          paperclipBuiltInAgent: {
            key: "reflection-coach",
            featureKeys: ["recent-agent-reflection"],
          },
        },
      },
    ]);
    routineSvc.list.mockResolvedValue([
      {
        id: "routine-built-in",
        companyId: "company-1",
        projectId: null,
        goalId: null,
        parentIssueId: null,
        title: "Review recent agent trajectories for coaching proposals",
        description: "Review recent agent work and propose coaching follow-ups.",
        assigneeAgentId: "agent-built-in",
        priority: "medium",
        status: "paused",
        concurrencyPolicy: "coalesce_if_active",
        catchUpPolicy: "skip_missed",
        createdByAgentId: null,
        createdByUserId: null,
        updatedByAgentId: null,
        updatedByUserId: null,
        lastTriggeredAt: null,
        lastEnqueuedAt: null,
        createdAt: new Date(),
        updatedAt: new Date(),
        originKind: "built_in_agent_bundle",
        originId: "reflection-coach:recent-agent-reflection",
        originFingerprint: null,
        triggers: [
          {
            id: "trigger-built-in",
            companyId: "company-1",
            routineId: "routine-built-in",
            kind: "schedule",
            label: "Weekly review",
            enabled: false,
            cronExpression: "0 9 * * 1",
            timezone: "UTC",
            nextRunAt: null,
            lastFiredAt: null,
            publicId: "public-built-in",
            secretId: "secret-built-in",
            signingMode: null,
            replayWindowSec: null,
            lastRotatedAt: null,
            lastResult: null,
            createdByAgentId: null,
            createdByUserId: null,
            updatedByAgentId: null,
            updatedByUserId: null,
            createdAt: new Date(),
            updatedAt: new Date(),
          },
        ],
        lastRun: null,
        activeIssue: null,
      },
    ]);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: true,
        issues: true,
        skills: false,
      },
    });

    expect(exported.files["agents/claudecoder/AGENTS.md"]).toBeDefined();
    expect(exported.files["agents/reflection-coach/AGENTS.md"]).toBeUndefined();
    expect(exported.files["tasks/review-recent-agent-trajectories-for-coaching-proposals/TASK.md"]).toBeUndefined();
    expect(exported.manifest.agents.map((agent) => agent.slug)).toEqual(["claudecoder"]);
    expect(exported.manifest.issues).toEqual([]);
    expect(exported.warnings).toContain("Skipped 1 built-in managed agent from export.");
    expect(exported.warnings).toContain("Skipped 1 built-in managed routine from export.");
  });

  it("imports recurring task packages as routines instead of one-time issues", async () => {
    const portability = companyPortabilityService(nativeDb);

    companySvc.create.mockResolvedValue({
      id: "company-imported",
      name: "Imported Paperclip",
    });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.create.mockResolvedValue({
      id: "agent-created",
      name: "ClaudeCoder",
    });
    projectSvc.create.mockResolvedValue({
      id: "project-created",
      name: "Launch",
      urlKey: "launch",
    });
    agentSvc.list.mockResolvedValue([]);
    projectSvc.list.mockResolvedValue([]);

    const files = {
      "COMPANY.md": [
        "---",
        'schema: "agentcompanies/v1"',
        'name: "Imported Paperclip"',
        "---",
        "",
      ].join("\n"),
      "agents/claudecoder/AGENTS.md": [
        "---",
        'name: "ClaudeCoder"',
        "---",
        "",
        "You write code.",
        "",
      ].join("\n"),
      "projects/launch/PROJECT.md": [
        "---",
        'name: "Launch"',
        "---",
        "",
      ].join("\n"),
      "tasks/monday-review/TASK.md": [
        "---",
        'name: "Monday Review"',
        'project: "launch"',
        'assignee: "claudecoder"',
        "recurring: true",
        "---",
        "",
        "Review pipeline health.",
        "",
      ].join("\n"),
      ".paperclip.yaml": [
        'schema: "paperclip/v1"',
        "routines:",
        "  monday-review:",
        '    status: "paused"',
        '    priority: "high"',
        '    concurrencyPolicy: "always_enqueue"',
        '    catchUpPolicy: "enqueue_missed_with_cap"',
        "    triggers:",
        "      - kind: schedule",
        '        cronExpression: "0 9 * * 1"',
        '        timezone: "America/Chicago"',
        '      - kind: webhook',
        '        enabled: false',
        '        signingMode: "hmac_sha256"',
        '        replayWindowSec: 120',
        "",
      ].join("\n"),
    };

    const preview = await portability.previewImport({
      source: { type: "inline", rootPath: "paperclip-demo", files },
      include: { company: true, agents: true, projects: true, issues: true, skills: false },
      target: { mode: "new_company", newCompanyName: "Imported Paperclip" },
      agents: "all",
      collisionStrategy: "rename",
    });

    expect(preview.errors).toEqual([]);
    expect(preview.plan.issuePlans).toEqual([
      expect.objectContaining({
        slug: "monday-review",
        reason: "Recurring task will be imported as a routine.",
      }),
    ]);

    const importRequest = await reviewExactPackageAsCurrentHuman(portability, {
      source: { type: "inline", rootPath: "paperclip-demo", files },
      include: { company: true, agents: true, projects: true, issues: true, skills: false },
      target: { mode: "new_company", newCompanyName: "Imported Paperclip" },
      agents: "all",
      collisionStrategy: "rename",
    });
    const result = await portability.importBundle(importRequest, nativeUserId, { actor: nativeActor, privateWorkAdmission: "closed" });

    expect(routineSvc.create).toHaveBeenCalledWith("company-imported", expect.objectContaining({
      projectId: "project-created",
      title: "Monday Review",
      assigneeAgentId: "agent-created",
      priority: "high",
      status: "paused",
      concurrencyPolicy: "always_enqueue",
      catchUpPolicy: "enqueue_missed_with_cap",
    }), expect.any(Object));
    expect(result.warnings).not.toContain(
      "Task monday-review assignee claudecoder is pending_approval; imported work was left unassigned.",
    );
    expect(routineSvc.createTrigger).toHaveBeenCalledTimes(2);
    expect(routineSvc.createTrigger).toHaveBeenCalledWith("routine-created", expect.objectContaining({
      kind: "schedule",
      cronExpression: "0 9 * * 1",
      timezone: "America/Chicago",
    }), expect.any(Object));
    expect(routineSvc.createTrigger).toHaveBeenCalledWith("routine-created", expect.objectContaining({
      kind: "webhook",
      enabled: false,
      signingMode: "hmac_sha256",
      replayWindowSec: 120,
    }), expect.any(Object));
    expect(issueSvc.importIssues).not.toHaveBeenCalled();
    expect(result.routines).toEqual([
      { slug: "monday-review", id: "routine-created", action: "created", title: "Monday Review", status: "paused" },
    ]);
  });

  it("suffixes a manifest-derived company name that collides with an existing company", async () => {
    const portability = companyPortabilityService({} as any);

    companySvc.list.mockResolvedValue([
      { name: "Imported Paperclip" },
      // Case-insensitive: an existing "(2)" in any casing blocks that suffix.
      { name: "imported paperclip (2)" },
    ]);
    companySvc.create.mockResolvedValue({
      id: "company-imported",
      name: "Imported Paperclip (3)",
    });
    accessSvc.ensureMembership.mockResolvedValue(undefined);

    const files = {
      "COMPANY.md": ["---", 'schema: "agentcompanies/v1"', 'name: "Imported Paperclip"', "---", ""].join("\n"),
    };

    await portability.importBundle({
      source: { type: "inline", rootPath: "paperclip-demo", files },
      include: { company: true, agents: false, projects: false, issues: false },
      // No newCompanyName: the manifest name is used and must be de-duplicated.
      target: { mode: "new_company" },
      collisionStrategy: "rename",
    }, "user-1");

    expect(companySvc.create).toHaveBeenCalledWith(expect.objectContaining({
      name: "Imported Paperclip (3)",
      locale: "en",
      timezone: "UTC",
    }));
  });

  it("skips name de-duplication for agent-safe imports so collisions stay unobservable", async () => {
    const portability = companyPortabilityService({} as any);

    companySvc.list.mockResolvedValue([{ name: "Imported Paperclip" }]);
    companySvc.create.mockResolvedValue({
      id: "company-imported",
      name: "Imported Paperclip",
    });
    accessSvc.listActiveUserMemberships.mockResolvedValue([{ userId: "user-1" }]);
    accessSvc.copyActiveUserMemberships.mockResolvedValue([]);

    const files = {
      "COMPANY.md": ["---", 'schema: "agentcompanies/v1"', 'name: "Imported Paperclip"', "---", ""].join("\n"),
    };

    await portability.importBundle({
      source: { type: "inline", rootPath: "paperclip-demo", files },
      include: { company: true, agents: false, projects: false, issues: false },
      target: { mode: "new_company" },
      collisionStrategy: "rename",
    }, "user-1", { mode: "agent_safe", sourceCompanyId: "company-1" });

    // The instance-wide name list must never be consulted for a
    // company-scoped agent, and no suffix may reflect a collision back.
    expect(companySvc.list).not.toHaveBeenCalled();
    expect(companySvc.create).toHaveBeenCalledWith(expect.objectContaining({
      name: "Imported Paperclip",
    }));
  });

  it("honors an explicitly typed company name even when it collides", async () => {
    const portability = companyPortabilityService({} as any);

    companySvc.list.mockResolvedValue([{ name: "Imported Paperclip" }]);
    companySvc.create.mockResolvedValue({
      id: "company-imported",
      name: "Imported Paperclip",
    });
    accessSvc.ensureMembership.mockResolvedValue(undefined);

    const files = {
      "COMPANY.md": ["---", 'schema: "agentcompanies/v1"', 'name: "Imported Paperclip"', "---", ""].join("\n"),
    };

    await portability.importBundle({
      source: { type: "inline", rootPath: "paperclip-demo", files },
      include: { company: true, agents: false, projects: false, issues: false },
      target: { mode: "new_company", newCompanyName: "Imported Paperclip" },
      collisionStrategy: "rename",
    }, "user-1");

    expect(companySvc.create).toHaveBeenCalledWith(expect.objectContaining({
      name: "Imported Paperclip",
    }));
  });

  it("pauses imported agents and routines when pauseAutomations is requested", async () => {
    const portability = companyPortabilityService(nativeDb);

    companySvc.create.mockResolvedValue({
      id: "company-imported",
      name: "Imported Paperclip",
    });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.create.mockResolvedValue({
      id: "agent-created",
      name: "ClaudeCoder",
      status: "paused",
    });
    projectSvc.create.mockResolvedValue({
      id: "project-created",
      name: "Launch",
      urlKey: "launch",
    });
    agentSvc.list.mockResolvedValue([]);
    projectSvc.list.mockResolvedValue([]);

    const files = {
      "COMPANY.md": ['---', 'schema: "agentcompanies/v1"', 'name: "Imported Paperclip"', "---", ""].join("\n"),
      "agents/claudecoder/AGENTS.md": ['---', 'name: "ClaudeCoder"', "---", "", "You write code.", ""].join("\n"),
      "projects/launch/PROJECT.md": ['---', 'name: "Launch"', "---", ""].join("\n"),
      "tasks/monday-review/TASK.md": [
        "---",
        'name: "Monday Review"',
        'project: "launch"',
        'assignee: "claudecoder"',
        "recurring: true",
        "---",
        "",
        "Review pipeline health.",
        "",
      ].join("\n"),
      ".paperclip.yaml": [
        'schema: "paperclip/v1"',
        "routines:",
        "  monday-review:",
        "    triggers:",
        "      - kind: schedule",
        '        cronExpression: "0 9 * * 1"',
        '        timezone: "America/Chicago"',
        "",
      ].join("\n"),
    };

    const importRequest = await reviewExactPackageAsCurrentHuman(portability, {
      source: { type: "inline", rootPath: "paperclip-demo", files },
      include: { company: true, agents: true, projects: true, issues: true, skills: false },
      target: { mode: "new_company", newCompanyName: "Imported Paperclip" },
      agents: "all",
      collisionStrategy: "rename",
      pauseAutomations: true,
    });
    const result = await portability.importBundle(importRequest, nativeUserId,
      { actor: nativeActor, privateWorkAdmission: "closed", pauseAutomations: true });

    expect(agentSvc.create).toHaveBeenCalledWith("company-imported", expect.objectContaining({
      status: "paused",
      // The dedicated "import" reason lets the UI explain the pause and offer
      // a scoped resume; "system" stays for platform-managed pauses.
      pauseReason: "import",
      pausedAt: expect.any(Date),
    }), expect.objectContaining({ transaction: expect.anything() }));
    expect(routineSvc.create).toHaveBeenCalledWith("company-imported", expect.objectContaining({
      title: "Monday Review",
      status: "paused",
    }), expect.any(Object));
    expect(result.routines).toEqual([
      { slug: "monday-review", id: "routine-created", action: "created", title: "Monday Review", status: "paused" },
    ]);
  });

  it("leaves imported agents and routines active when pauseAutomations is absent", async () => {
    const portability = companyPortabilityService(nativeDb);

    companySvc.create.mockResolvedValue({
      id: "company-imported",
      name: "Imported Paperclip",
    });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.create.mockResolvedValue({
      id: "agent-created",
      name: "ClaudeCoder",
    });
    projectSvc.create.mockResolvedValue({
      id: "project-created",
      name: "Launch",
      urlKey: "launch",
    });
    agentSvc.list.mockResolvedValue([]);
    projectSvc.list.mockResolvedValue([]);

    const files = {
      "COMPANY.md": ['---', 'schema: "agentcompanies/v1"', 'name: "Imported Paperclip"', "---", ""].join("\n"),
      "agents/claudecoder/AGENTS.md": ['---', 'name: "ClaudeCoder"', "---", "", "You write code.", ""].join("\n"),
      "projects/launch/PROJECT.md": ['---', 'name: "Launch"', "---", ""].join("\n"),
      "tasks/monday-review/TASK.md": [
        "---",
        'name: "Monday Review"',
        'project: "launch"',
        'assignee: "claudecoder"',
        "recurring: true",
        "---",
        "",
        "Review pipeline health.",
        "",
      ].join("\n"),
      ".paperclip.yaml": [
        'schema: "paperclip/v1"',
        "routines:",
        "  monday-review:",
        "    triggers:",
        "      - kind: schedule",
        '        cronExpression: "0 9 * * 1"',
        '        timezone: "America/Chicago"',
        "",
      ].join("\n"),
    };

    const importRequest = await reviewExactPackageAsCurrentHuman(portability, {
      source: { type: "inline", rootPath: "paperclip-demo", files },
      include: { company: true, agents: true, projects: true, issues: true, skills: false },
      target: { mode: "new_company", newCompanyName: "Imported Paperclip" },
      agents: "all",
      collisionStrategy: "rename",
    });
    const result = await portability.importBundle(importRequest, nativeUserId, { actor: nativeActor, privateWorkAdmission: "closed" });

    expect(agentSvc.create).toHaveBeenCalledTimes(1);
    const [, createdAgentInput] = agentSvc.create.mock.calls[0]!;
    expect(createdAgentInput.status).toBe("idle");
    expect(createdAgentInput.pauseReason).toBeUndefined();
    expect(createdAgentInput.pausedAt).toBeUndefined();
    expect(routineSvc.create).toHaveBeenCalledWith("company-imported", expect.objectContaining({
      title: "Monday Review",
      status: "active",
    }), expect.any(Object));
    expect(result.routines).toEqual([
      { slug: "monday-review", id: "routine-created", action: "created", title: "Monday Review", status: "active" },
    ]);
  });

  it("migrates legacy schedule.recurrence imports into routine triggers", async () => {
    const portability = companyPortabilityService(nativeDb);

    companySvc.create.mockResolvedValue({
      id: "company-imported",
      name: "Imported Paperclip",
    });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.create.mockResolvedValue({
      id: "agent-created",
      name: "ClaudeCoder",
    });
    projectSvc.create.mockResolvedValue({
      id: "project-created",
      name: "Launch",
      urlKey: "launch",
    });
    agentSvc.list.mockResolvedValue([]);
    projectSvc.list.mockResolvedValue([]);

    const files = {
      "COMPANY.md": ['---', 'schema: "agentcompanies/v1"', 'name: "Imported Paperclip"', "---", ""].join("\n"),
      "agents/claudecoder/AGENTS.md": ['---', 'name: "ClaudeCoder"', "---", "", "You write code.", ""].join("\n"),
      "projects/launch/PROJECT.md": ['---', 'name: "Launch"', "---", ""].join("\n"),
      "tasks/monday-review/TASK.md": [
        "---",
        'name: "Monday Review"',
        'project: "launch"',
        'assignee: "claudecoder"',
        "schedule:",
        '  timezone: "America/Chicago"',
        '  startsAt: "2026-03-16T09:00:00-05:00"',
        "  recurrence:",
        '    frequency: "weekly"',
        "    interval: 1",
        "    weekdays:",
        '      - "monday"',
        "---",
        "",
        "Review pipeline health.",
        "",
      ].join("\n"),
    };

    const preview = await portability.previewImport({
      source: { type: "inline", rootPath: "paperclip-demo", files },
      include: { company: true, agents: true, projects: true, issues: true, skills: false },
      target: { mode: "new_company", newCompanyName: "Imported Paperclip" },
      agents: "all",
      collisionStrategy: "rename",
    });

    expect(preview.errors).toEqual([]);
    expect(preview.manifest.issues[0]).toEqual(expect.objectContaining({
      recurring: true,
      legacyRecurrence: expect.objectContaining({ frequency: "weekly" }),
    }));

    const importRequest = await reviewExactPackageAsCurrentHuman(portability, {
      source: { type: "inline", rootPath: "paperclip-demo", files },
      include: { company: true, agents: true, projects: true, issues: true, skills: false },
      target: { mode: "new_company", newCompanyName: "Imported Paperclip" },
      agents: "all",
      collisionStrategy: "rename",
    });
    await portability.importBundle(importRequest, nativeUserId, { actor: nativeActor, privateWorkAdmission: "closed" });

    expect(routineSvc.createTrigger).toHaveBeenCalledWith("routine-created", expect.objectContaining({
      kind: "schedule",
      cronExpression: "0 9 * * 1",
      timezone: "America/Chicago",
    }), expect.any(Object));
    expect(issueSvc.importIssues).not.toHaveBeenCalled();
  });

  it("imports recurring tasks without a project or assignee as paused routines", async () => {
    const portability = companyPortabilityService(nativeDb);

    companySvc.create.mockResolvedValue({
      id: "company-imported",
      name: "Imported Paperclip",
    });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.list.mockResolvedValue([]);
    projectSvc.list.mockResolvedValue([]);

    const files = {
      "COMPANY.md": ['---', 'schema: "agentcompanies/v1"', 'name: "Imported Paperclip"', "---", ""].join("\n"),
      "tasks/monday-review/TASK.md": [
        "---",
        'name: "Monday Review"',
        "recurring: true",
        "---",
        "",
        "Review pipeline health.",
        "",
      ].join("\n"),
    };
    const request = {
      source: { type: "inline" as const, rootPath: "paperclip-demo", files },
      include: { company: true, agents: false, projects: false, issues: true, skills: false },
      target: { mode: "new_company" as const, newCompanyName: "Imported Paperclip" },
      collisionStrategy: "rename" as const,
    };

    const preview = await portability.previewImport(request);
    expect(preview.errors).toEqual([]);
    expect(preview.warnings).toContain(
      "Recurring task monday-review has no assignee; the routine will stay paused until one is set.",
    );

    const importRequest = await reviewExactPackageAsCurrentHuman(portability, request);
    const result = await portability.importBundle(importRequest, nativeUserId, { actor: nativeActor, privateWorkAdmission: "closed" });
    expect(routineSvc.create).toHaveBeenCalledWith("company-imported", expect.objectContaining({
      projectId: null,
      assigneeAgentId: null,
      title: "Monday Review",
    }), expect.any(Object));
    expect(result.warnings).toContain(
      "Routine monday-review was imported without an assignee and will stay paused until one is set.",
    );
  });

  it("imports a vendor-neutral package without .paperclip.yaml", async () => {
    const portability = unitImportPortability();

    companySvc.create.mockResolvedValue({
      id: "company-imported",
      name: "Imported Paperclip",
    });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.create.mockResolvedValue({
      id: "agent-created",
      name: "ClaudeCoder",
    });

    const preview = await portability.previewImport({
      source: {
        type: "inline",
        rootPath: "paperclip-demo",
        files: {
          "COMPANY.md": [
            "---",
            'schema: "agentcompanies/v1"',
            'name: "Imported Paperclip"',
            'description: "Portable company package"',
            "---",
            "",
            "# Imported Paperclip",
            "",
          ].join("\n"),
          "agents/claudecoder/AGENTS.md": [
            "---",
            'name: "ClaudeCoder"',
            'title: "Software Engineer"',
            "---",
            "",
            "# ClaudeCoder",
            "",
            "You write code.",
            "",
          ].join("\n"),
        },
      },
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
      target: {
        mode: "new_company",
        newCompanyName: "Imported Paperclip",
      },
      agents: "all",
      collisionStrategy: "rename",
    });

    expect(preview.errors).toEqual([]);
    expect(preview.manifest.company?.name).toBe("Imported Paperclip");
    expect(preview.manifest.agents).toEqual([
      expect.objectContaining({
        slug: "claudecoder",
        name: "ClaudeCoder",
        adapterType: "process",
      }),
    ]);
    expect(preview.envInputs).toEqual([]);

    await portability.importBundle({
      source: {
        type: "inline",
        rootPath: "paperclip-demo",
        files: {
          "COMPANY.md": [
            "---",
            'schema: "agentcompanies/v1"',
            'name: "Imported Paperclip"',
            'description: "Portable company package"',
            "---",
            "",
            "# Imported Paperclip",
            "",
          ].join("\n"),
          "agents/claudecoder/AGENTS.md": [
            "---",
            'name: "ClaudeCoder"',
            'title: "Software Engineer"',
            "---",
            "",
            "# ClaudeCoder",
            "",
            "You write code.",
            "",
          ].join("\n"),
        },
      },
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
      target: {
        mode: "new_company",
        newCompanyName: "Imported Paperclip",
      },
      agents: "all",
      collisionStrategy: "rename",
    }, "user-1");

    expect(companySvc.create).toHaveBeenCalledWith(expect.objectContaining({
      name: "Imported Paperclip",
      description: "Portable company package",
    }));
    expect(agentSvc.create).toHaveBeenCalledWith("company-imported", expect.objectContaining({
      name: "ClaudeCoder",
      adapterType: "process",
    }), expect.objectContaining({ transaction: expect.anything() }));
  });

  it("preserves agent role from frontmatter when extension block omits it", async () => {
    const portability = companyPortabilityService({} as any);

    const preview = await portability.previewImport({
      source: {
        type: "inline",
        rootPath: "ceo-package",
        files: {
          "COMPANY.md": [
            "---",
            'schema: "agentcompanies/v1"',
            'name: "CEO Role Test"',
            "---",
            "",
          ].join("\n"),
          "agents/ceo/AGENTS.md": [
            "---",
            'name: "CEO"',
            'role: "ceo"',
            "---",
            "",
            "# CEO",
            "",
            "You run the company.",
            "",
          ].join("\n"),
        },
      },
      include: { company: true, agents: true, projects: false, issues: false },
      target: { mode: "new_company", newCompanyName: "CEO Role Test" },
      agents: "all",
      collisionStrategy: "rename",
    });

    expect(preview.errors).toEqual([]);
    expect(preview.manifest.agents).toEqual([
      expect.objectContaining({
        slug: "ceo",
        name: "CEO",
        role: "ceo",
      }),
    ]);
  });

  itNative("treats no-separator auth and api key env names as secrets during export", async () => {
    useNativeExportCompany();
    const portability = companyPortabilityService(nativeDb);

    agentSvc.list.mockResolvedValue([
      {
        id: "agent-1",
        name: "ClaudeCoder",
        status: "idle",
        role: "engineer",
        title: "Software Engineer",
        icon: "code",
        reportsTo: null,
        capabilities: "Writes code",
        adapterType: "claude_local",
        adapterConfig: {
          promptTemplate: "You are ClaudeCoder.",
          env: {
            APIKEY: {
              type: "plain",
              value: "sk-plain-api",
            },
            GITHUBAUTH: {
              type: "plain",
              value: "gh-auth-token",
            },
            PRIVATEKEY: {
              type: "plain",
              value: "private-key-value",
            },
          },
        },
        runtimeConfig: {},
        budgetMonthlyCents: 0,
        permissions: {},
        metadata: null,
      },
    ]);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
    }, { actor: nativeActor });

    const extension = asTextFile(exported.files[".paperclip.yaml"]);
    expect(extension).toContain("APIKEY:");
    expect(extension).toContain("GITHUBAUTH:");
    expect(extension).toContain("PRIVATEKEY:");
    expect(extension).not.toContain("sk-plain-api");
    expect(extension).not.toContain("gh-auth-token");
    expect(extension).not.toContain("private-key-value");
    expect(extension).toContain('kind: "secret"');
  });

  itNative("imports packaged skills and restores desired skill refs on agents", async () => {
    useNativeExportCompany();
    const portability = companyPortabilityService(nativeDb);

    companySvc.create.mockResolvedValue({
      id: "company-imported",
      name: "Imported Paperclip",
    });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.create.mockResolvedValue({
      id: "agent-created",
      name: "ClaudeCoder",
    });
    companySkillSvc.importPackageFiles.mockResolvedValueOnce([{
      skill: {
        id: "skill-imported",
        key: paperclipKey,
        slug: "paperclip",
      },
      action: "renamed",
      originalKey: "paperclip",
      originalSlug: "paperclip",
      requestedRefs: ["paperclip"],
      reason: "Existing skill matched; renamed to paperclip-2.",
    }]);

    const skills = await companySkillSvc.listFull(nativeCompanyId);
    companySkillSvc.listFull.mockResolvedValueOnce(skills.map((skill) => ({ ...skill, companyId: nativeCompanyId })));
    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
    }, { actor: nativeActor });

    agentSvc.list.mockResolvedValue([]);

    const result = await portability.importBundle({
      source: {
        type: "inline",
        rootPath: exported.rootPath,
        files: exported.files,
      },
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
      target: {
        mode: "new_company",
        newCompanyName: "Imported Paperclip",
      },
      agents: "all",
      collisionStrategy: "rename",
    }, "user-1");

    const textOnlyFiles = Object.fromEntries(Object.entries(exported.files).filter(([, v]) => typeof v === "string"));
    expect(companySkillSvc.importPackageFiles).toHaveBeenCalledWith("company-imported", textOnlyFiles, {
      onConflict: "rename",
    });
    expect(result.skills).toEqual([{
      originalKey: "paperclip",
      originalSlug: "paperclip",
      key: paperclipKey,
      slug: "paperclip",
      id: "skill-imported",
      action: "renamed",
      reason: "Existing skill matched; renamed to paperclip-2.",
    }]);
    expect(agentSvc.create).toHaveBeenCalledWith("company-imported", expect.objectContaining({
      adapterConfig: expect.objectContaining({
        paperclipSkillSync: {
          desiredSkills: [paperclipKey],
        },
      }),
    }), expect.objectContaining({ transaction: expect.anything() }));
  });

  itNative("imports a packaged company logo and attaches it to the target company", async () => {
    const storage = {
      putFile: vi.fn().mockResolvedValue({
        provider: "local_disk",
        objectKey: "assets/companies/imported-logo",
        contentType: "image/png",
        byteSize: 9,
        sha256: "logo-sha",
        originalFilename: "company-logo.png",
      }),
    };
    companySvc.create.mockResolvedValue({
      id: "company-imported",
      name: "Imported Paperclip",
      logoAssetId: null,
    });
    companySvc.update.mockResolvedValue({
      id: "company-imported",
      name: "Imported Paperclip",
      logoAssetId: "asset-created",
    });
    agentSvc.create.mockResolvedValue({
      id: "agent-created",
      name: "ClaudeCoder",
    });

    useNativeExportCompany();
    const portability = companyPortabilityService(nativeDb, storage as any);
    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
    }, { actor: nativeActor });

    exported.files["images/company-logo.png"] = {
      encoding: "base64",
      data: Buffer.from("png-bytes").toString("base64"),
      contentType: "image/png",
    };
    // Declare the packaged logo in the bundle's company block. The exported
    // company map is empty for this fixture, so the block is appended rather
    // than patched into an existing one.
    const paperclipYaml = `${exported.files[".paperclip.yaml"]}`;
    expect(paperclipYaml).not.toContain("company:");
    exported.files[".paperclip.yaml"] =
      `${paperclipYaml}company:\n  logoPath: "images/company-logo.png"\n`;

    agentSvc.list.mockResolvedValue([]);

    await portability.importBundle({
      source: {
        type: "inline",
        rootPath: exported.rootPath,
        files: exported.files,
      },
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
      target: {
        mode: "new_company",
        newCompanyName: "Imported Paperclip",
      },
      agents: "all",
      collisionStrategy: "rename",
    }, "user-1");

    expect(storage.putFile).toHaveBeenCalledWith(expect.objectContaining({
      companyId: "company-imported",
      namespace: "assets/companies",
      originalFilename: "company-logo.png",
      contentType: "image/png",
      body: Buffer.from("png-bytes"),
    }));
    expect(assetSvc.create).toHaveBeenCalledWith("company-imported", expect.objectContaining({
      objectKey: "assets/companies/imported-logo",
      contentType: "image/png",
      createdByUserId: "user-1",
    }));
    expect(companySvc.update).toHaveBeenCalledWith("company-imported", {
      logoAssetId: "asset-created",
    });
  });

  itNative("copies source company memberships for safe new-company imports", async () => {
    useNativeExportCompany();
    const portability = companyPortabilityService(nativeDb);

    companySvc.create.mockResolvedValue({
      id: "company-imported",
      name: "Imported Paperclip",
    });
    agentSvc.create.mockResolvedValue({
      id: "agent-created",
      name: "ClaudeCoder",
    });

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
    }, { actor: nativeActor });

    agentSvc.list.mockResolvedValue([]);

    await portability.importBundle({
      source: {
        type: "inline",
        rootPath: exported.rootPath,
        files: exported.files,
      },
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
      target: {
        mode: "new_company",
        newCompanyName: "Imported Paperclip",
      },
      agents: "all",
      collisionStrategy: "rename",
    }, null, {
      mode: "agent_safe",
      sourceCompanyId: nativeCompanyId,
    });

    expect(accessSvc.listActiveUserMemberships).toHaveBeenCalledWith(nativeCompanyId);
    expect(accessSvc.copyActiveUserMemberships).toHaveBeenCalledWith(nativeCompanyId, "company-imported");
    expect(accessSvc.ensureMembership).not.toHaveBeenCalledWith("company-imported", "user", expect.anything(), "owner", "active");
    const textOnlyFiles = Object.fromEntries(Object.entries(exported.files).filter(([, v]) => typeof v === "string"));
    expect(companySkillSvc.importPackageFiles).toHaveBeenCalledWith("company-imported", textOnlyFiles, {
      onConflict: "rename",
    });
  });

  itNative("disables timer heartbeats and strips raw provider tracing on created imports", async () => {
    useNativeExportCompany();
    const portability = companyPortabilityService(nativeDb);

    companySvc.create.mockResolvedValue({
      id: "company-imported",
      name: "Imported Paperclip",
    });
    agentSvc.create.mockImplementation(async (_companyId: string, input: Record<string, unknown>) => ({
      id: `agent-${String(input.name).toLowerCase()}`,
      name: input.name,
      adapterConfig: input.adapterConfig,
      runtimeConfig: input.runtimeConfig,
    }));

    const sourceAgents = (await agentSvc.list()) as Array<Record<string, unknown>>;
    agentSvc.list.mockResolvedValue(sourceAgents.map((agent) => ({
      ...agent,
      runtimeConfig: {
        ...((agent.runtimeConfig ?? {}) as Record<string, unknown>),
        debug: { providerTrace: "raw", retainedDebugSetting: true },
      },
    })));
    agentSvc.list.mockClear();

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
    }, { actor: nativeActor });

    agentSvc.list.mockResolvedValue([]);

    await portability.importBundle({
      source: {
        type: "inline",
        rootPath: exported.rootPath,
        files: exported.files,
      },
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
      target: {
        mode: "new_company",
        newCompanyName: "Imported Paperclip",
      },
      agents: "all",
      collisionStrategy: "rename",
    }, "user-1");

    const createdClaude = agentSvc.create.mock.calls.find(([, input]) => input.name === "ClaudeCoder");
    expect(createdClaude?.[1]).toMatchObject({
      runtimeConfig: {
        debug: {
          retainedDebugSetting: true,
        },
        heartbeat: {
          enabled: false,
          maxConcurrentRuns: 20,
        },
      },
    });
    const createdRuntimeConfig = createdClaude?.[1].runtimeConfig as
      | Record<string, unknown>
      | undefined;
    expect(createdRuntimeConfig?.debug).not.toHaveProperty("providerTrace");
  });

  itNative("imports only selected files and leaves unchecked company metadata alone", async () => {
    useNativeExportCompany();
    const portability = companyPortabilityService(nativeDb);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
    }, { actor: nativeActor });

    agentSvc.list.mockResolvedValue([]);
    projectSvc.list.mockResolvedValue([]);
    companySvc.getById.mockResolvedValueOnce({
      id: nativeCompanyId,
      name: "Paperclip",
      description: "Existing company",
      requireBoardApprovalForNewAgents: false,
    });
    agentSvc.create.mockResolvedValue({
      id: "agent-cmo",
      name: "CMO",
    });

    const result = await portability.importBundle({
      source: {
        type: "inline",
        rootPath: exported.rootPath,
        files: exported.files,
      },
      include: {
        company: true,
        agents: true,
        projects: true,
        issues: true,
      },
      selectedFiles: ["agents/cmo/AGENTS.md"],
      target: {
        mode: "existing_company",
        companyId: nativeCompanyId,
      },
      agents: "all",
      collisionStrategy: "rename",
    }, "user-1");

    expect(companySvc.update).not.toHaveBeenCalled();
    expect(companySkillSvc.importPackageFiles).toHaveBeenCalledWith(
      nativeCompanyId,
      expect.objectContaining({
        "COMPANY.md": expect.any(String),
        "agents/cmo/AGENTS.md": expect.any(String),
      }),
      {
        onConflict: "rename",
      },
    );
    expect(companySkillSvc.importPackageFiles).toHaveBeenCalledWith(
      nativeCompanyId,
      expect.not.objectContaining({
        "agents/claudecoder/AGENTS.md": expect.any(String),
      }),
      {
        onConflict: "rename",
      },
    );
    expect(agentSvc.create).toHaveBeenCalledTimes(1);
    expect(agentSvc.create).toHaveBeenCalledWith(nativeCompanyId, expect.objectContaining({
      name: "CMO",
      runtimeConfig: {
        heartbeat: {
          enabled: false,
          maxConcurrentRuns: 20,
        },
      },
    }), expect.objectContaining({ transaction: expect.anything() }));
    expect(result.company.action).toBe("unchanged");
    expect(result.agents).toEqual([
      {
        slug: "cmo",
        id: "agent-cmo",
        action: "created",
        name: "CMO",
        reason: null,
      },
    ]);
  });

  itNative("applies adapter overrides while keeping imported AGENTS content implicit", async () => {
    useNativeExportCompany();
    const portability = companyPortabilityService(nativeDb);

    companySvc.create.mockResolvedValue({
      id: "company-imported",
      name: "Imported Paperclip",
    });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.create.mockResolvedValue({
      id: "agent-created",
      name: "ClaudeCoder",
    });

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
    }, { actor: nativeActor });

    agentSvc.list.mockResolvedValue([]);

    await portability.importBundle({
      source: {
        type: "inline",
        rootPath: exported.rootPath,
        files: exported.files,
      },
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
      target: {
        mode: "new_company",
        newCompanyName: "Imported Paperclip",
      },
      agents: "all",
      collisionStrategy: "rename",
      adapterOverrides: {
        claudecoder: {
          adapterType: "codex_local",
          adapterConfig: {
            dangerouslyBypassApprovalsAndSandbox: true,
            instructionsFilePath: "/tmp/should-not-survive.md",
          },
        },
      },
    }, "user-1");

    expect(agentSvc.create).toHaveBeenCalledWith("company-imported", expect.objectContaining({
      adapterType: "codex_local",
      adapterConfig: expect.objectContaining({
        dangerouslyBypassApprovalsAndSandbox: true,
      }),
    }), expect.objectContaining({ transaction: expect.anything() }));
    expect(agentSvc.create).toHaveBeenCalledWith("company-imported", expect.objectContaining({
      adapterConfig: expect.not.objectContaining({
        instructionsFilePath: expect.anything(),
        promptTemplate: expect.anything(),
      }),
    }), expect.objectContaining({ transaction: expect.anything() }));
    expect(agentInstructionsSvc.materializeManagedBundle).toHaveBeenCalledWith(
      expect.objectContaining({ name: "ClaudeCoder" }),
      expect.objectContaining({
        "AGENTS.md": expect.stringContaining("You are ClaudeCoder."),
      }),
      expect.objectContaining({
        clearLegacyPromptTemplate: true,
        replaceExisting: true,
      }),
    );
    const materializedFiles = agentInstructionsSvc.materializeManagedBundle.mock.calls[0]?.[1] as Record<string, string>;
    expect(materializedFiles["AGENTS.md"]).not.toMatch(/^---\n/);
    expect(materializedFiles["AGENTS.md"]).not.toContain('name: "ClaudeCoder"');
  });

  itNative("does not implicitly add local adapter permission bypass defaults on import", async () => {
    useNativeExportCompany();
    const portability = companyPortabilityService(nativeDb);

    companySvc.create.mockResolvedValue({
      id: "company-imported",
      name: "Imported Paperclip",
    });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.create.mockImplementation(async (_companyId: string, input: Record<string, unknown>) => ({
      id: "agent-created",
      name: String(input.name),
      adapterType: input.adapterType,
      adapterConfig: input.adapterConfig,
    }));

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
    }, { actor: nativeActor });

    agentSvc.list.mockResolvedValue([]);

    await portability.importBundle({
      source: {
        type: "inline",
        rootPath: exported.rootPath,
        files: exported.files,
      },
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
      target: {
        mode: "new_company",
        newCompanyName: "Imported Paperclip",
      },
      agents: ["claudecoder"],
      collisionStrategy: "rename",
    }, "user-1");

    // Imports must preserve safe-by-default local adapter settings unless the package says otherwise.
    const firstCreateInput = agentSvc.create.mock.calls[0]?.[1] as Record<string, any>;
    expect(firstCreateInput?.adapterConfig).toBeTruthy();
    expect(firstCreateInput.adapterConfig?.dangerouslySkipPermissions).toBeUndefined();

    await portability.importBundle({
      source: {
        type: "inline",
        rootPath: exported.rootPath,
        files: exported.files,
      },
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
      target: {
        mode: "new_company",
        newCompanyName: "Imported Paperclip",
      },
      agents: ["claudecoder"],
      collisionStrategy: "rename",
      adapterOverrides: {
        claudecoder: {
          adapterType: "codex_local",
          adapterConfig: {
            extraArgs: [],
            args: ["--legacy-arg"],
          },
        },
      },
    }, "user-1");

    expect(agentSvc.create).toHaveBeenLastCalledWith("company-imported", expect.objectContaining({
      adapterType: "codex_local",
      adapterConfig: expect.objectContaining({
        extraArgs: ["--skip-git-repo-check"],
        args: ["--legacy-arg"],
      }),
    }), expect.objectContaining({ transaction: expect.anything() }));
    const lastCreateInput = agentSvc.create.mock.calls.at(-1)?.[1] as Record<string, any>;
    expect(lastCreateInput?.adapterConfig).toBeTruthy();
    expect(lastCreateInput.adapterConfig?.dangerouslyBypassApprovalsAndSandbox).toBeUndefined();
  });

  it("carries labels by name through export and import round-trip", async () => {
    const portability = currentHumanExportPortability();

    projectSvc.list.mockResolvedValue([
      {
        id: "project-1",
        name: "Launch",
        urlKey: "launch",
        description: null,
        status: "active",
        leadAgentId: null,
        metadata: null,
        defaultProjectWorkspaceId: null,
      },
    ]);
    projectSvc.listWorkspaces.mockResolvedValue([]);
    issueSvc.list.mockResolvedValue([
      {
        id: "issue-1",
        identifier: "PAP-1",
        title: "Labelled task",
        description: "Has labels",
        projectId: "project-1",
        projectWorkspaceId: null,
        assigneeAgentId: null,
        status: "todo",
        priority: "high",
        labelIds: ["label-a", "label-b"],
        billingCode: null,
        executionWorkspaceSettings: null,
        assigneeAdapterOverrides: null,
      },
    ]);
    issueSvc.listLabels.mockResolvedValueOnce([
      { id: "label-a", companyId: "company-1", name: "bug", color: "#ff0000" },
      { id: "label-b", companyId: "company-1", name: "urgent", color: "#00ff00" },
    ]);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: { company: true, agents: false, projects: true, issues: true },
    });

    const extension = asTextFile(exported.files[".paperclip.yaml"]);
    expect(extension).toContain("labels:");
    expect(extension).toContain('"bug"');
    expect(extension).toContain('"urgent"');
    expect(extension).toContain('"#ff0000"');
    expect(extension).toContain('"#00ff00"');
    expect(extension).not.toContain("labelIds");
    expect(extension).not.toContain("label-a");
    // Fresh exports declare the current bundle shape end-to-end.
    expect(extension).toContain("schemaVersion: 8");
    expect(exported.manifest.schemaVersion).toBe(8);
    expect(exported.manifest.labels).toEqual([
      { name: "bug", color: "#ff0000" },
      { name: "urgent", color: "#00ff00" },
    ]);
    expect(exported.manifest.issues[0]?.labelNames).toEqual(["bug", "urgent"]);

    companySvc.create.mockResolvedValue({ id: "company-imported", name: "Imported" });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.list.mockResolvedValue([]);
    projectSvc.list.mockResolvedValue([]);
    projectSvc.create.mockResolvedValue({ id: "project-imported", name: "Launch", urlKey: "launch" });
    issueSvc.create.mockResolvedValue({ id: "issue-imported", title: "Labelled task" });
    issueSvc.listLabels.mockResolvedValueOnce([]);

    const result = await portability.importBundle({
      source: { type: "inline", rootPath: exported.rootPath, files: exported.files },
      include: { company: true, agents: false, projects: true, issues: true },
      target: { mode: "new_company", newCompanyName: "Imported" },
      agents: "all",
      collisionStrategy: "rename",
    }, "user-1");

    expect(result.warnings.some((warning) => warning.includes("predates"))).toBe(false);
    expect(issueSvc.createLabel).toHaveBeenCalledWith("company-imported", { name: "bug", color: "#ff0000" });
    expect(issueSvc.createLabel).toHaveBeenCalledWith("company-imported", { name: "urgent", color: "#00ff00" });
    expect(issueSvc.createLabel).toHaveBeenCalledTimes(2);
    expect(issueSvc.importIssues).toHaveBeenCalledWith(
      "company-imported",
      expect.arrayContaining([
        expect.objectContaining({
          labelIds: ["label-created-bug", "label-created-urgent"],
        }),
      ]), expect.anything(), expect.objectContaining({ actor: nativeActor, privateWorkAdmission: "closed" }),
    );
  });

  it("reuses existing target labels on name collision and keeps the target color", async () => {
    const portability = currentHumanExportPortability();

    projectSvc.list.mockResolvedValue([]);
    projectSvc.listWorkspaces.mockResolvedValue([]);
    issueSvc.list.mockResolvedValue([
      {
        id: "issue-1",
        identifier: "PAP-1",
        title: "Labelled task",
        description: null,
        projectId: null,
        projectWorkspaceId: null,
        assigneeAgentId: null,
        status: "todo",
        priority: "medium",
        labelIds: ["label-a", "label-b"],
        billingCode: null,
        executionWorkspaceSettings: null,
        assigneeAdapterOverrides: null,
      },
    ]);
    issueSvc.listLabels.mockResolvedValueOnce([
      { id: "label-a", companyId: "company-1", name: "bug", color: "#ff0000" },
      { id: "label-b", companyId: "company-1", name: "urgent", color: "#00ff00" },
    ]);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: { company: true, agents: false, projects: false, issues: true },
    });

    agentSvc.list.mockResolvedValue([]);
    issueSvc.create.mockResolvedValue({ id: "issue-imported", title: "Labelled task" });
    // Import target already has a "bug" label with a different color.
    issueSvc.listLabels.mockResolvedValueOnce([
      { id: "target-bug", companyId: "company-1", name: "bug", color: "#123456" },
    ]);

    const result = await portability.importBundle({
      source: { type: "inline", rootPath: exported.rootPath, files: exported.files },
      include: { company: false, agents: false, projects: false, issues: true },
      target: { mode: "existing_company", companyId: "company-1" },
      agents: "all",
      collisionStrategy: "rename",
    }, "user-1");

    expect(issueSvc.createLabel).toHaveBeenCalledTimes(1);
    expect(issueSvc.createLabel).toHaveBeenCalledWith(nativeCompanyId, { name: "urgent", color: "#00ff00" });
    expect(issueSvc.importIssues).toHaveBeenCalledWith(
      nativeCompanyId,
      expect.arrayContaining([
        expect.objectContaining({
          labelIds: ["target-bug", "label-created-urgent"],
        }),
      ]), expect.anything(), expect.objectContaining({ actor: nativeActor, privateWorkAdmission: "closed" }),
    );
    expect(result.warnings).toContain(
      "Existing label color was kept for bug; the imported bundle used different colors.",
    );
  });

  it("drops unresolvable raw labelIds from old bundles with a warning instead of failing", async () => {
    const portability = currentHumanExportPortability();

    companySvc.create.mockResolvedValue({ id: "company-imported", name: "Legacy Import" });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.list.mockResolvedValue([]);
    issueSvc.create.mockResolvedValue({ id: "issue-imported", title: "Kickoff" });

    const result = await portability.importBundle({
      source: {
        type: "inline",
        rootPath: "legacy-package",
        files: {
          "COMPANY.md": [
            "---",
            'schema: "agentcompanies/v1"',
            'name: "Legacy Import"',
            "---",
            "",
          ].join("\n"),
          "tasks/kickoff/TASK.md": [
            "---",
            'name: "Kickoff"',
            "---",
            "",
            "Legacy labelled task.",
            "",
          ].join("\n"),
          ".paperclip.yaml": [
            'schema: "paperclip/v1"',
            "tasks:",
            "  kickoff:",
            '    status: "todo"',
            "    labelIds:",
            '      - "0a45b7de-9fb1-4c94-9c9d-3f61c2ab0001"',
            '      - "0a45b7de-9fb1-4c94-9c9d-3f61c2ab0002"',
            "",
          ].join("\n"),
        },
      },
      include: { company: true, agents: false, projects: false, issues: true },
      target: { mode: "new_company", newCompanyName: "Legacy Import" },
      agents: "all",
      collisionStrategy: "rename",
    }, "user-1");

    expect(issueSvc.createLabel).not.toHaveBeenCalled();
    expect(issueSvc.importIssues).toHaveBeenCalledWith(
      "company-imported",
      expect.arrayContaining([
        expect.objectContaining({ labelIds: [] }),
      ]), expect.anything(), expect.objectContaining({ actor: nativeActor, privateWorkAdmission: "closed" }),
    );
    expect(result.warnings).toContain(
      "Task kickoff dropped 2 label references because the bundle carries raw label ids that do not exist in the target company.",
    );
  });

  async function mockTaskFidelityExportSources() {
    const sourceIssueId = nativeSourceUuid("issue", "issue-1");
    const documentId = nativeSourceUuid("document", "document-1");
    const revisionId = nativeSourceUuid("revision", "revision-1");
    const [existingSourceIssue] = await nativeDb.select({ id: issues.id }).from(issues).where(eq(issues.id, sourceIssueId));
    if (!existingSourceIssue) await seedNativeBoardTask({ id: sourceIssueId, number: 9001, title: "Alpha task", description: null });
    await nativeDb.insert(documents).values({ id: documentId, companyId: nativeCompanyId, title: "Spec",
      format: "markdown", latestBody: "# Spec\n\nDetails.", latestRevisionId: revisionId, latestRevisionNumber: 1,
      createdByUserId: nativeUserId, updatedByUserId: nativeUserId }).onConflictDoNothing();
    await nativeDb.insert(documentRevisions).values({ id: revisionId, companyId: nativeCompanyId, documentId,
      revisionNumber: 1, title: "Spec", format: "markdown", body: "# Spec\n\nDetails.", createdByUserId: nativeUserId })
      .onConflictDoNothing();
    await nativeDb.insert(issueDocuments).values({ companyId: nativeCompanyId, issueId: sourceIssueId,
      documentId, key: "spec" }).onConflictDoNothing();
    projectSvc.list.mockResolvedValue([]);
    projectSvc.listWorkspaces.mockResolvedValue([]);
    issueSvc.list.mockResolvedValue([
      {
        id: "issue-1",
        identifier: "PAP-1",
        title: "Alpha task",
        description: "Carries documents, work products, and a monitor",
        projectId: null,
        projectWorkspaceId: null,
        assigneeAgentId: null,
        status: "todo",
        priority: "high",
        labelIds: [],
        billingCode: null,
        executionWorkspaceSettings: null,
        assigneeAdapterOverrides: null,
        monitorNotes: "Check deploy daily",
        monitorScheduledBy: "agent",
        monitorNextCheckAt: new Date("2026-07-01T00:00:00.000Z"),
      },
      {
        id: "issue-2",
        identifier: "PAP-2",
        title: "Beta task",
        description: "Blocked by Alpha",
        projectId: null,
        projectWorkspaceId: null,
        assigneeAgentId: null,
        status: "todo",
        priority: "medium",
        labelIds: [],
        billingCode: null,
        executionWorkspaceSettings: null,
        assigneeAdapterOverrides: null,
      },
    ]);
    const relationSummary = (id: string, identifier: string, title: string) => ({
      id,
      identifier,
      title,
      status: "todo",
      priority: "medium",
      assigneeAgentId: null,
      assigneeUserId: null,
    });
    issueSvc.getRelationSummaries.mockImplementation(async (issueId: string) => {
      if (issueId === "issue-1") {
        return {
          blockedBy: [relationSummary("issue-outside", "PAP-9", "Outside task")],
          blocks: [relationSummary("issue-2", "PAP-2", "Beta task")],
        };
      }
      if (issueId === "issue-2") {
        return {
          blockedBy: [relationSummary("issue-1", "PAP-1", "Alpha task")],
          blocks: [],
        };
      }
      return { blockedBy: [], blocks: [] };
    });
    documentSvc.listIssueDocuments.mockImplementation(async (issueId: string) => issueId === "issue-1"
      ? [
          {
            id: "document-1",
            companyId: "company-1",
            issueId: "issue-1",
            key: "spec",
            title: "Spec",
            format: "markdown",
            body: "# Spec\n\nDetails.",
            latestRevisionId: nativeSourceUuid("revision", "revision-1"),
            latestRevisionNumber: 1,
          },
        ]
      : []);
    workProductSvc.listForIssue.mockImplementation(async (issueId: string) => issueId === "issue-1"
      ? [
          {
            id: "work-product-1",
            companyId: "company-1",
            projectId: null,
            issueId: "issue-1",
            executionWorkspaceId: "ws-1",
            runtimeServiceId: null,
            type: "pull_request",
            provider: "github",
            externalId: "42",
            title: "Fix bug",
            url: "https://github.com/example/repo/pull/42",
            status: "merged",
            reviewState: "approved",
            isPrimary: true,
            healthStatus: "healthy",
            summary: "Fixes the bug",
            metadata: { repo: "example/repo" },
            sourceTrust: null,
            createdByRunId: "run-1",
            createdAt: new Date("2026-06-01T00:00:00.000Z"),
            updatedAt: new Date("2026-06-01T00:00:00.000Z"),
          },
        ]
      : []);
  }

  function fakeImportDb() {
    const insertedRelationValues: Array<Record<string, unknown>> = [];
    const monitorUpdates: Array<Record<string, unknown>> = [];
    const db = {
      insert: () => ({
        values: (rows: Array<Record<string, unknown>>) => ({
          onConflictDoNothing: async () => {
            insertedRelationValues.push(...rows);
          },
        }),
      }),
      update: () => ({
        set: (patch: Record<string, unknown>) => ({
          where: async () => {
            monitorUpdates.push(patch);
          },
        }),
      }),
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } as any;
    return { db, insertedRelationValues, monitorUpdates };
  }

  it("carries blockers, documents, work products, and monitors through export and import", async () => {
    const { monitorUpdates } = fakeImportDb();
    const portability = currentHumanExportPortability();
    await mockTaskFidelityExportSources();

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: { company: true, agents: false, projects: false, issues: true },
    });

    expect(asTextFile(exported.files["tasks/pap-1/documents/spec.md"])).toBe("# Spec\n\nDetails.");
    const extension = asTextFile(exported.files[".paperclip.yaml"]);
    expect(extension).toContain("blockedBy:");
    expect(extension).toContain('"pap-1"');
    expect(extension).toContain("workProducts:");
    expect(extension).toContain("monitor:");
    expect(extension).toContain('"Check deploy daily"');
    expect(extension).not.toContain("ws-1");
    expect(extension).not.toContain("run-1");
    // An inaccessible outside blocker is omitted without exposing whether the
    // referenced task exists; the visible in-package blocker below is retained.
    expect(exported.warnings.some((warning) => warning.includes("issue-outside"))).toBe(false);
    expect(exported.warnings).toContain(
      "1 work product references execution workspaces or runs that are not portable; those references were omitted from the export.",
    );
    const alphaEntry = exported.manifest.issues.find((issue) => issue.slug === "pap-1");
    const betaEntry = exported.manifest.issues.find((issue) => issue.slug === "pap-2");
    expect(alphaEntry?.documents).toEqual([
      { key: "spec", title: "Spec", format: "markdown", path: "tasks/pap-1/documents/spec.md" },
    ]);
    expect(alphaEntry?.workProducts).toEqual([
      expect.objectContaining({
        type: "pull_request",
        provider: "github",
        externalId: "42",
        title: "Fix bug",
        status: "merged",
        reviewState: "approved",
        isPrimary: true,
        healthStatus: "healthy",
      }),
    ]);
    expect(alphaEntry?.monitor).toEqual({
      notes: "Check deploy daily",
      scheduledBy: "agent",
      hadSchedule: true,
    });
    expect(alphaEntry?.blockedBy).toEqual([]);
    expect(betaEntry?.blockedBy).toEqual(["pap-1"]);

    const importedCompanyId = "f2bd2ca4-1ac8-4e75-9ea8-f54a8a0fa3a8";
    await nativeDb.insert(companies).values({ id: importedCompanyId, name: "Imported portability target", issuePrefix: "IMP" }).onConflictDoNothing();
    await nativeDb.insert(companyMemberships).values({ companyId: importedCompanyId, principalType: "user",
      principalId: nativeUserId, status: "active", membershipRole: "owner" }).onConflictDoNothing();
    companySvc.create.mockReset();
    companySvc.getById.mockReset().mockImplementation(async (id: string) =>
      id === importedCompanyId ? { id: importedCompanyId, name: "Imported" } : null);
    companySvc.update.mockReset().mockImplementation(async () => ({ id: importedCompanyId, name: "Imported" }));
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.list.mockResolvedValue([]);
    issueSvc.importIssues.mockImplementation(async (_companyId: string, rows: Array<Record<string, any>>) => {
      await nativeDb.insert(issues).values(rows.map((row, index) => ({
        id: row.id as string,
        companyId: importedCompanyId,
        title: row.title as string,
        status: String(row.status ?? "todo"),
        issueNumber: 910000000 + index,
        identifier: `IMP-${String(row.id).slice(0, 8)}`,
        visibility: "open",
        privacyRootIssueId: row.id as string,
        createdByUserId: nativeUserId,
        responsibleUserId: nativeUserId,
      })));
      return [];
    });

    const effectCheckpoints: Array<{ phase: "started" | "completed"; key: string; hasTransaction: boolean }> = [];
    const result = await portability.importBundle({
      source: { type: "inline", rootPath: exported.rootPath, files: exported.files },
      include: { company: true, agents: false, projects: false, issues: true },
      target: { mode: "existing_company", companyId: importedCompanyId },
      agents: "all",
      collisionStrategy: "rename",
    }, "user-1", { onEffectCheckpoint: async (event, tx) => {
      effectCheckpoints.push({ phase: event.phase, key: event.key, hasTransaction: Boolean(tx) });
    } });

    // Ids are pre-generated by the batched importer; correlate them by title.
    const importedIssues = issueSvc.importIssues.mock.calls[0]![1] as Array<{
      id: string;
      title: string;
      monitorNotes: string | null;
      monitorScheduledBy: string | null;
    }>;
    const alphaId = importedIssues.find((row) => row.title === "Alpha task")!.id;
    const betaId = importedIssues.find((row) => row.title === "Beta task")!.id;

    expect(documentSvc.createIssueDocumentsForImport).toHaveBeenCalledWith(
      expect.arrayContaining([
        expect.objectContaining({
          issueId: alphaId,
          key: "spec",
          title: "Spec",
          format: "markdown",
          body: "# Spec\n\nDetails.",
          createdByUserId: nativeUserId,
        }),
      ]), expect.anything(),
    );
    expect(workProductSvc.createManyForImport).toHaveBeenCalledWith(
      expect.arrayContaining([
        expect.objectContaining({
          issueId: alphaId,
          companyId: importedCompanyId,
          type: "pull_request",
          provider: "github",
          externalId: "42",
          title: "Fix bug",
          status: "merged",
          reviewState: "approved",
          isPrimary: true,
          healthStatus: "healthy",
          executionWorkspaceId: null,
          runtimeServiceId: null,
          createdByRunId: null,
          sourceTrust: null,
        }),
      ]), expect.anything(),
    );
    const importedRelations = await nativeDb.select().from(issueRelations)
      .where(eq(issueRelations.companyId, importedCompanyId));
    expect(importedRelations).toEqual([
      expect.objectContaining({
        companyId: importedCompanyId,
        issueId: alphaId,
        relatedIssueId: betaId,
        type: "blocks",
        createdByAgentId: null,
        createdByUserId: nativeUserId,
      }),
    ]);
    expect(effectCheckpoints).toContainEqual({ phase: "started", key: "tasks:relations", hasTransaction: false });
    expect(effectCheckpoints).toContainEqual({ phase: "completed", key: "tasks:relations", hasTransaction: true });
    // Monitor notes/provenance ride on the issue row itself now, so there is no
    // separate post-insert update. The monitor still lands un-armed.
    expect(monitorUpdates).toEqual([]);
    expect(importedIssues.find((row) => row.title === "Alpha task")).toEqual(
      expect.objectContaining({
        monitorNotes: "Check deploy daily",
        monitorScheduledBy: "agent",
      }),
    );
    expect(result.warnings).toContain(
      "1 monitor was imported un-armed; re-arm it from the task page to resume checks.",
    );
    // This test configures update to preserve the real target company identity;
    // don't leave that per-case implementation for later imports.
    companySvc.update.mockReset();
  });

  it("skips blockers and documents of tasks excluded from the import selection", async () => {
    const { db, insertedRelationValues } = fakeImportDb();
    const portability = currentHumanExportPortability();
    await mockTaskFidelityExportSources();

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: { company: true, agents: false, projects: false, issues: true },
    });

    companySvc.create.mockResolvedValue({ id: "company-imported", name: "Imported" });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.list.mockResolvedValue([]);
    issueSvc.create.mockResolvedValue({ id: "issue-imported-2", title: "Beta task", projectId: null });

    const result = await portability.importBundle({
      source: { type: "inline", rootPath: exported.rootPath, files: exported.files },
      include: { company: true, agents: false, projects: false, issues: true },
      target: { mode: "new_company", newCompanyName: "Imported" },
      agents: "all",
      collisionStrategy: "rename",
      selectedFiles: ["COMPANY.md", ".paperclip.yaml", "tasks/pap-2/TASK.md"],
    }, "user-1");

    expect(issueSvc.importIssues.mock.calls[0]![1]).toHaveLength(1);
    expect(issueSvc.importIssues).toHaveBeenCalledWith(
      "company-imported",
      expect.arrayContaining([
        expect.objectContaining({ title: "Beta task" }),
      ]), expect.anything(), expect.objectContaining({ actor: nativeActor, privateWorkAdmission: "closed" }),
    );
    expect(documentSvc.createIssueDocumentsForImport).not.toHaveBeenCalled();
    expect(workProductSvc.createManyForImport).not.toHaveBeenCalled();
    expect(insertedRelationValues).toEqual([]);
    expect(result.warnings).toContain(
      "Task pap-2 blocker pap-1 was skipped because that task was not imported.",
    );
  });

  async function mockTaskHierarchyExportSources() {
    projectSvc.list.mockResolvedValue([]);
    projectSvc.listWorkspaces.mockResolvedValue([]);
    const baseIssue = {
      description: null,
      projectId: null,
      projectWorkspaceId: null,
      assigneeAgentId: null,
      priority: "medium",
      labelIds: [],
      billingCode: null,
      executionWorkspaceSettings: null,
      assigneeAdapterOverrides: null,
    };
    issueSvc.list.mockResolvedValue([
      {
        ...baseIssue,
        id: "issue-1",
        identifier: "PAP-1",
        title: "Alpha task",
        status: "done",
        parentId: null,
        createdAt: new Date("2026-01-01T00:00:00.000Z"),
        updatedAt: new Date("2026-03-01T00:00:00.000Z"),
        startedAt: new Date("2026-01-02T00:00:00.000Z"),
        completedAt: new Date("2026-02-01T00:00:00.000Z"),
      },
      {
        ...baseIssue,
        id: "issue-2",
        identifier: "PAP-2",
        title: "Beta task",
        status: "todo",
        parentId: "issue-1",
        createdAt: new Date("2026-01-05T00:00:00.000Z"),
        updatedAt: new Date("2026-01-06T00:00:00.000Z"),
      },
      {
        ...baseIssue,
        id: "issue-3",
        identifier: "PAP-3",
        title: "Gamma task",
        status: "todo",
        parentId: "issue-2",
        createdAt: new Date("2026-01-07T00:00:00.000Z"),
        updatedAt: new Date("2026-01-08T00:00:00.000Z"),
      },
      {
        ...baseIssue,
        id: "issue-4",
        identifier: "PAP-4",
        title: "Delta task",
        status: "todo",
        parentId: "issue-outside",
        privacyRootIssueId: "issue-outside",
      },
    ]);
    const outsideParentId = nativeSourceUuid("issue", "issue-outside");
    await nativeDb.insert(issues).values({ id: outsideParentId, companyId: nativeCompanyId, title: "Outside parent",
      status: "todo", issueNumber: 990000001, identifier: "SRC-990000001", visibility: "open",
      privacyRootIssueId: outsideParentId, createdByUserId: nativeUserId, responsibleUserId: nativeUserId }).onConflictDoNothing();
  }

  it("carries task timestamps and parent links through export and import", async () => {
    const { db } = fakeImportDb();
    const portability = currentHumanExportPortability();
    await mockTaskHierarchyExportSources();

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: { company: true, agents: false, projects: false, issues: true },
    });

    const extension = asTextFile(exported.files[".paperclip.yaml"]);
    expect(extension).toContain("schemaVersion: 8");
    expect(extension).toContain('parent: "pap-1"');
    expect(extension).toContain('createdAt: "2026-01-01T00:00:00.000Z"');
    expect(exported.warnings).toContain(
      "1 parent relation references a task outside this export and was not included.",
    );

    const alphaEntry = exported.manifest.issues.find((issue) => issue.slug === "pap-1");
    const betaEntry = exported.manifest.issues.find((issue) => issue.slug === "pap-2");
    const gammaEntry = exported.manifest.issues.find((issue) => issue.slug === "pap-3");
    const deltaEntry = exported.manifest.issues.find((issue) => issue.slug === "pap-4");
    expect(alphaEntry).toEqual(expect.objectContaining({
      parentSlug: null,
      createdAt: "2026-01-01T00:00:00.000Z",
      updatedAt: "2026-03-01T00:00:00.000Z",
      startedAt: "2026-01-02T00:00:00.000Z",
      completedAt: "2026-02-01T00:00:00.000Z",
      cancelledAt: null,
    }));
    expect(betaEntry?.parentSlug).toBe("pap-1");
    expect(gammaEntry?.parentSlug).toBe("pap-2");
    // The unexported parent edge is dropped, not carried by raw id.
    expect(deltaEntry?.parentSlug).toBeNull();
    expect(extension).not.toContain("issue-outside");

    const importedCompanyId = "f2bd2ca4-1ac8-4e75-9ea8-f54a8a0fa3a8";
    await nativeDb.insert(companies).values({ id: importedCompanyId, name: "Imported hierarchy target", issuePrefix: "IMP" }).onConflictDoNothing();
    await nativeDb.insert(companyMemberships).values({ companyId: importedCompanyId, principalType: "user",
      principalId: nativeUserId, status: "active", membershipRole: "owner" }).onConflictDoNothing();
    companySvc.create.mockResolvedValue({ id: importedCompanyId, name: "Imported" });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.list.mockResolvedValue([]);

    await portability.importBundle({
      source: { type: "inline", rootPath: exported.rootPath, files: exported.files },
      include: { company: true, agents: false, projects: false, issues: true },
      target: { mode: "new_company", newCompanyName: "Imported" },
      agents: "all",
      collisionStrategy: "rename",
    }, "user-1");

    const importedRows = issueSvc.importIssues.mock.calls[0]![1] as Array<{
      id: string;
      title: string;
      parentId: string | null;
      createdAt: Date | null;
      updatedAt: Date | null;
      startedAt: Date | null;
      completedAt: Date | null;
      cancelledAt: Date | null;
    }>;
    const alphaRow = importedRows.find((row) => row.title === "Alpha task")!;
    const betaRow = importedRows.find((row) => row.title === "Beta task")!;
    const gammaRow = importedRows.find((row) => row.title === "Gamma task")!;
    const deltaRow = importedRows.find((row) => row.title === "Delta task")!;

    // Timestamps survive the round trip as concrete dates.
    expect(alphaRow.createdAt).toEqual(new Date("2026-01-01T00:00:00.000Z"));
    expect(alphaRow.updatedAt).toEqual(new Date("2026-03-01T00:00:00.000Z"));
    expect(alphaRow.startedAt).toEqual(new Date("2026-01-02T00:00:00.000Z"));
    expect(alphaRow.completedAt).toEqual(new Date("2026-02-01T00:00:00.000Z"));
    expect(alphaRow.cancelledAt).toBeNull();
    expect(betaRow.createdAt).toEqual(new Date("2026-01-05T00:00:00.000Z"));

    // The parent chain of three is intact against the pre-generated ids.
    expect(alphaRow.parentId).toBeNull();
    expect(betaRow.parentId).toBe(alphaRow.id);
    expect(gammaRow.parentId).toBe(betaRow.id);
    expect(deltaRow.parentId).toBeNull();

    // Rows arrive parents-first so chunked inserts satisfy the parent FK.
    expect(importedRows.indexOf(alphaRow)).toBeLessThan(importedRows.indexOf(betaRow));
    expect(importedRows.indexOf(betaRow)).toBeLessThan(importedRows.indexOf(gammaRow));
  });

  it("drops self-referencing and cyclic parent links from a hand-built bundle with warnings", async () => {
    const portability = currentHumanExportPortability();

    const taskFile = (name: string) => ["---", `name: "${name}"`, "kind: task", "---", "", `${name} body.`, ""].join("\n");
    const files = {
      "COMPANY.md": ["---", 'schema: "agentcompanies/v1"', 'name: "Tampered Import"', "---", ""].join("\n"),
      "tasks/task-a/TASK.md": taskFile("Task A"),
      "tasks/task-b/TASK.md": taskFile("Task B"),
      "tasks/task-c/TASK.md": taskFile("Task C"),
      ".paperclip.yaml": [
        'schema: "paperclip/v1"',
        "schemaVersion: 7",
        "tasks:",
        "  task-a:",
        '    status: "todo"',
        '    parent: "task-b"',
        "  task-b:",
        '    status: "todo"',
        '    parent: "task-a"',
        "  task-c:",
        '    status: "todo"',
        '    parent: "task-c"',
        '    createdAt: "not-a-timestamp"',
        "",
      ].join("\n"),
    };

    companySvc.create.mockResolvedValue({ id: "company-imported", name: "Tampered Import" });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.list.mockResolvedValue([]);

    const result = await portability.importBundle({
      source: { type: "inline", rootPath: "tampered-package", files },
      include: { company: true, agents: false, projects: false, issues: true },
      target: { mode: "new_company", newCompanyName: "Tampered Import" },
      agents: "all",
      collisionStrategy: "rename",
    }, "user-1");

    const importedRows = issueSvc.importIssues.mock.calls[0]![1] as Array<{
      title: string;
      parentId: string | null;
      createdAt: Date | null;
    }>;
    const rowA = importedRows.find((row) => row.title === "Task A")!;
    const rowB = importedRows.find((row) => row.title === "Task B")!;
    const rowC = importedRows.find((row) => row.title === "Task C")!;

    // One direction of the two-task cycle survives; the closing edge drops.
    expect([rowA.parentId, rowB.parentId].filter((parentId) => parentId !== null)).toHaveLength(1);
    expect(rowC.parentId).toBeNull();
    expect(rowC.createdAt).toBeNull();
    expect(result.warnings.filter((warning) => warning.includes("would create a parent cycle"))).toHaveLength(2);
    expect(result.warnings).toContain(
      "Task task-c parent task-c was skipped because it would create a parent cycle.",
    );
    expect(result.warnings).toContain(
      "Task task-c createdAt was ignored because it is not a valid timestamp.",
    );
  });

  const attachmentBytesByObjectKey: Record<string, string> = {
    "issues/issue-1/notes.bin": "png-bytes",
    "issues/issue-1/screenshot.png": "png-bytes",
    "issues/issue-1/big.bin": "twenty-byte-payload!",
    "assets/general/embed.png": "embedded-image-bytes",
  };

  function sha256Of(content: string) {
    return createHash("sha256").update(content).digest("hex");
  }

  function fakeAttachmentStorage() {
    return {
      getObject: vi.fn().mockImplementation(async (_companyId: string, objectKey: string) => {
        const content = attachmentBytesByObjectKey[objectKey];
        if (content === undefined) throw new Error(`missing object ${objectKey}`);
        return { stream: Readable.from([Buffer.from(content)]) };
      }),
      putFile: vi.fn().mockImplementation(async (input: {
        originalFilename: string | null;
        contentType: string;
        body: Buffer;
      }) => ({
        provider: "local_disk",
        objectKey: `stored/${input.originalFilename ?? "blob"}`,
        contentType: input.contentType,
        byteSize: input.body.length,
        sha256: sha256Of(input.body.toString()),
        originalFilename: input.originalFilename,
      })),
    };
  }

  function mockAttachmentExportSources(extraRows: Array<Record<string, unknown>> = []) {
    projectSvc.list.mockResolvedValue([]);
    projectSvc.listWorkspaces.mockResolvedValue([]);
    issueSvc.list.mockResolvedValue([
      {
        id: "issue-1",
        identifier: "PAP-1",
        title: "Attachment task",
        description: null,
        projectId: null,
        projectWorkspaceId: null,
        assigneeAgentId: null,
        status: "todo",
        priority: "medium",
        labelIds: [],
        billingCode: null,
        executionWorkspaceSettings: null,
        assigneeAdapterOverrides: null,
      },
    ]);
    issueSvc.listComments.mockResolvedValue([
      {
        id: "comment-1",
        body: "First comment",
        authorType: "system",
        authorAgentId: null,
        presentation: null,
        metadata: null,
        createdAt: new Date("2026-06-01T00:00:00.000Z"),
      },
      {
        id: "comment-2",
        body: "Screenshot attached",
        authorType: "system",
        authorAgentId: null,
        presentation: null,
        metadata: null,
        createdAt: new Date("2026-06-02T00:00:00.000Z"),
      },
    ]);
    // listAttachments returns newest-first like the real service; the export
    // re-sorts chronologically.
    issueSvc.listAttachments.mockResolvedValue([
      {
        id: "attachment-2",
        issueId: "issue-1",
        issueCommentId: "comment-2",
        provider: "local_disk",
        objectKey: "issues/issue-1/screenshot.png",
        contentType: "image/png",
        byteSize: 9,
        sha256: sha256Of("png-bytes"),
        originalFilename: "screenshot.png",
        createdAt: new Date("2026-06-03T00:00:00.000Z"),
      },
      {
        id: "attachment-1",
        issueId: "issue-1",
        issueCommentId: null,
        provider: "local_disk",
        objectKey: "issues/issue-1/notes.bin",
        contentType: "application/octet-stream",
        byteSize: 9,
        sha256: "stale-asset-row-hash",
        originalFilename: "notes.bin",
        createdAt: new Date("2026-06-02T12:00:00.000Z"),
      },
      ...extraRows,
    ]);
  }

  it("carries issue attachments as content-addressed blobs through export and import", async () => {
    const storage = fakeAttachmentStorage();
    const portability = currentHumanExportPortability(storage as any);
    mockAttachmentExportSources();
    const sha = sha256Of("png-bytes");

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: { company: true, agents: false, projects: false, issues: true },
    });

    // Both attachments share the same bytes, so the bundle holds one blob.
    expect(Object.keys(exported.files).filter((filePath) => filePath.startsWith("blobs/"))).toEqual([
      `blobs/${sha}`,
    ]);
    expect(exported.files[`blobs/${sha}`]).toEqual({
      encoding: "base64",
      data: Buffer.from("png-bytes").toString("base64"),
      contentType: "application/octet-stream",
    });
    expect(exported.manifest.blobs).toEqual([
      { sha256: sha, byteSize: 9, contentType: "application/octet-stream" },
    ]);
    const taskEntry = exported.manifest.issues.find((issue) => issue.slug === "pap-1");
    expect(taskEntry?.attachments).toEqual([
      {
        sha256: sha,
        contentType: "application/octet-stream",
        originalFilename: "notes.bin",
        byteSize: 9,
        commentIndex: null,
      },
      {
        sha256: sha,
        contentType: "image/png",
        originalFilename: "screenshot.png",
        byteSize: 9,
        commentIndex: 1,
      },
    ]);
    expect(exported.warnings).toContain(
      "Attachment notes.bin on task pap-1 was exported under its recomputed content hash because the stored hash did not match.",
    );

    companySvc.create.mockResolvedValue({ id: "company-imported", name: "Imported" });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.list.mockResolvedValue([]);
    issueSvc.create.mockResolvedValue({ id: "issue-imported", title: "Attachment task", projectId: null });

    const result = await portability.importBundle({
      source: { type: "inline", rootPath: exported.rootPath, files: exported.files },
      include: { company: true, agents: false, projects: false, issues: true },
      target: { mode: "new_company", newCompanyName: "Imported" },
      agents: "all",
      collisionStrategy: "rename",
    }, "user-1");

    // Ids are pre-generated, so capture them to resolve the storage namespace
    // and the comment-scoped attachment reference.
    const importedIssueId = (issueSvc.importIssues.mock.calls[0]![1] as Array<{ id: string }>)[0]!.id;
    const importedCommentIds = (issueSvc.addImportedComments.mock.calls[0]![0] as Array<{ id: string }>).map((row) => row.id);

    expect(storage.putFile).toHaveBeenCalledTimes(2);
    expect(storage.putFile).toHaveBeenCalledWith(expect.objectContaining({
      companyId: "company-imported",
      namespace: `issues/${importedIssueId}`,
      originalFilename: "screenshot.png",
      contentType: "image/png",
      body: Buffer.from("png-bytes"),
    }));
    const attachmentRows = issueSvc.addImportedAttachments.mock.calls[0]![0] as Array<Record<string, unknown>>;
    expect(attachmentRows).toHaveLength(2);
    expect(issueSvc.addImportedAttachments).toHaveBeenCalledWith(expect.arrayContaining([
      expect.objectContaining({
        issueId: importedIssueId,
        issueCommentId: null,
        originalFilename: "notes.bin",
        contentType: "application/octet-stream",
        sha256: sha,
        byteSize: 9,
        createdByUserId: nativeUserId,
      }),
    ]), expect.anything());
    expect(issueSvc.addImportedAttachments).toHaveBeenCalledWith(expect.arrayContaining([
      expect.objectContaining({
        issueId: importedIssueId,
        issueCommentId: importedCommentIds[1],
        originalFilename: "screenshot.png",
        contentType: "image/png",
      }),
    ]), expect.anything());
    expect(result.warnings.filter((warning) => warning.includes("attachment"))).toEqual([]);
  });

  it("skips attachment export with a per-task warning when storage is unavailable", async () => {
    const portability = currentHumanExportPortability();
    mockAttachmentExportSources();

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: { company: true, agents: false, projects: false, issues: true },
    });

    expect(exported.warnings).toContain(
      "Skipped 2 attachments on task pap-1 because storage is unavailable.",
    );
    expect(Object.keys(exported.files).some((filePath) => filePath.startsWith("blobs/"))).toBe(false);
    expect(asTextFile(exported.files[".paperclip.yaml"])).not.toContain("attachments:");
  });

  it("skips all attachment imports with one warning when the target has no storage", async () => {
    const storage = fakeAttachmentStorage();
    const exporting = currentHumanExportPortability(storage as any);
    mockAttachmentExportSources();
    const exported = await exporting.exportBundle(nativeCompanyId, {
      include: { company: true, agents: false, projects: false, issues: true },
    });

    const importing = currentHumanExportPortability();
    companySvc.create.mockResolvedValue({ id: "company-imported", name: "Imported" });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.list.mockResolvedValue([]);
    issueSvc.create.mockResolvedValue({ id: "issue-imported", title: "Attachment task", projectId: null });

    const result = await importing.importBundle({
      source: { type: "inline", rootPath: exported.rootPath, files: exported.files },
      include: { company: true, agents: false, projects: false, issues: true },
      target: { mode: "new_company", newCompanyName: "Imported" },
      agents: "all",
      collisionStrategy: "rename",
    }, "user-1");

    expect(issueSvc.addImportedAttachments).not.toHaveBeenCalled();
    expect(result.warnings).toContain("Skipped 2 attachments because storage is unavailable.");
  });

  it("fails closed when a bundle blob does not match its declared sha256", async () => {
    const storage = fakeAttachmentStorage();
    const portability = currentHumanExportPortability();
    mockAttachmentExportSources();
    const sha = sha256Of("png-bytes");

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: { company: true, agents: false, projects: false, issues: true },
    });
    exported.files[`blobs/${sha}`] = {
      encoding: "base64",
      data: Buffer.from("tampered-bytes").toString("base64"),
      contentType: "application/octet-stream",
    };

    companySvc.create.mockResolvedValue({ id: "company-imported", name: "Imported" });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.list.mockResolvedValue([]);
    issueSvc.create.mockResolvedValue({ id: "issue-imported", title: "Attachment task", projectId: null });

    await expect(portability.importBundle({
      source: { type: "inline", rootPath: exported.rootPath, files: exported.files },
      include: { company: true, agents: false, projects: false, issues: true },
      target: { mode: "new_company", newCompanyName: "Imported" },
      agents: "all",
      collisionStrategy: "rename",
    }, "user-1")).rejects.toThrow(/does not match its declared sha256/);
    expect(issueSvc.addImportedAttachments).not.toHaveBeenCalled();
    // Blob verification runs before any write, so a tampered package cannot
    // leave a partially imported company behind.
    expect(companySvc.create).not.toHaveBeenCalled();
    expect(issueSvc.importIssues).not.toHaveBeenCalled();
  });

  it("skips oversized and missing-blob attachments with warnings instead of failing", async () => {
    // The deployment-level cap is read once when the service module loads, so
    // this test re-imports the module under a 10-byte cap to reach the skip.
    const previousCap = process.env.PAPERCLIP_ATTACHMENT_MAX_BYTES;
    process.env.PAPERCLIP_ATTACHMENT_MAX_BYTES = "10";
    vi.resetModules();
    try {
      const { companyPortabilityService: cappedPortabilityService } =
        await import("../services/company-portability.js");
      const storage = fakeAttachmentStorage();
      const portability = cappedPortabilityService(nativeDb, storage as any);
      mockAttachmentExportSources([
        {
          id: "attachment-3",
          issueId: "issue-1",
          issueCommentId: null,
          provider: "local_disk",
          objectKey: "issues/issue-1/big.bin",
          contentType: "application/octet-stream",
          byteSize: 20,
          sha256: sha256Of("twenty-byte-payload!"),
          originalFilename: "big.bin",
          createdAt: new Date("2026-06-04T00:00:00.000Z"),
        },
      ]);
      installCurrentHumanSourceFixtures();
      const sha = sha256Of("png-bytes");

      const exported = await portability.exportBundle(nativeCompanyId, {
        include: { company: true, agents: false, projects: false, issues: true },
      }, { actor: nativeActor });
      delete exported.files[`blobs/${sha}`];

      companySvc.create.mockResolvedValue({ id: "company-imported", name: "Imported" });
      companySvc.update.mockResolvedValue({ id: "company-imported", name: "Imported" });
      accessSvc.ensureMembership.mockResolvedValue(undefined);
      agentSvc.list.mockResolvedValue([]);
      issueSvc.create.mockResolvedValue({ id: "issue-imported", title: "Attachment task", projectId: null });

      const importRequest = await reviewExactPackageAsCurrentHuman(portability, {
        source: { type: "inline", rootPath: exported.rootPath, files: exported.files },
        include: { company: true, agents: false, projects: false, issues: true },
        target: { mode: "new_company", newCompanyName: "Imported" },
        agents: "all",
        collisionStrategy: "rename",
      });
      const result = await portability.importBundle(importRequest, nativeUserId, { actor: nativeActor });

      expect(issueSvc.addImportedAttachments).not.toHaveBeenCalled();
      expect(result.warnings).toContain(
        `Task pap-1 attachment notes.bin was skipped because its blob is missing from the package: blobs/${sha}`,
      );
      expect(result.warnings).toContain(
        `Task pap-1 attachment screenshot.png was skipped because its blob is missing from the package: blobs/${sha}`,
      );
      expect(result.warnings).toContain(
        "Task pap-1 attachment big.bin was skipped because it exceeds this deployment's attachment size limit of 10 bytes.",
      );
    } finally {
      if (previousCap === undefined) {
        delete process.env.PAPERCLIP_ATTACHMENT_MAX_BYTES;
      } else {
        process.env.PAPERCLIP_ATTACHMENT_MAX_BYTES = previousCap;
      }
      vi.resetModules();
    }
  });

  const EMBEDDED_ASSET_ID = "0f9a4c9e-1b2d-4e3f-8a5b-6c7d8e9f0a1b";
  const embeddedAssetUrl = (assetId: string) => `/api/assets/${assetId}/content`;

  function mockEmbeddedAssetExportSources(description?: string) {
    projectSvc.list.mockResolvedValue([]);
    projectSvc.listWorkspaces.mockResolvedValue([]);
    issueSvc.list.mockResolvedValue([
      {
        id: "issue-1",
        identifier: "PAP-1",
        title: "Embedded image task",
        description: description ?? `Intro\n\n![shot](${embeddedAssetUrl(EMBEDDED_ASSET_ID)})`,
        projectId: null,
        projectWorkspaceId: null,
        assigneeAgentId: null,
        status: "todo",
        priority: "medium",
        labelIds: [],
        billingCode: null,
        executionWorkspaceSettings: null,
        assigneeAdapterOverrides: null,
      },
    ]);
    issueSvc.listComments.mockResolvedValue([
      {
        id: "comment-1",
        body: `Inline too: ![inline](${embeddedAssetUrl(EMBEDDED_ASSET_ID)})`,
        authorType: "system",
        authorAgentId: null,
        presentation: null,
        metadata: null,
        createdAt: new Date("2026-06-01T00:00:00.000Z"),
      },
    ]);
    documentSvc.listIssueDocuments.mockResolvedValue([
      {
        id: "document-1",
        key: "spec",
        title: "Spec",
        format: "markdown",
        body: `# Spec\n\n![shot](${embeddedAssetUrl(EMBEDDED_ASSET_ID)})`,
      },
    ]);
    assetSvc.getById.mockImplementation(async (assetId: string) => (
      assetId === EMBEDDED_ASSET_ID
        ? {
            id: EMBEDDED_ASSET_ID,
            companyId: nativeCompanyId,
            provider: "local_disk",
            objectKey: "assets/general/embed.png",
            contentType: "image/png",
            byteSize: 20,
            sha256: "stale-asset-row-hash",
            originalFilename: "embed.png",
          }
        : null
    ));
  }

  it("carries embedded asset images through export and import with rewritten references", async () => {
    const storage = fakeAttachmentStorage();
    const portability = currentHumanExportPortability(storage as any);
    mockEmbeddedAssetExportSources();
    const sha = sha256Of("embedded-image-bytes");

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: { company: true, agents: false, projects: false, issues: true },
    });

    // The description, a comment, and a document all reference the same
    // asset, so the bundle holds one blob and one embeddedAssets entry.
    expect(Object.keys(exported.files).filter((filePath) => filePath.startsWith("blobs/"))).toEqual([
      `blobs/${sha}`,
    ]);
    expect(exported.files[`blobs/${sha}`]).toEqual({
      encoding: "base64",
      data: Buffer.from("embedded-image-bytes").toString("base64"),
      contentType: "application/octet-stream",
    });
    expect(exported.manifest.blobs).toEqual([
      { sha256: sha, byteSize: 20, contentType: "application/octet-stream" },
    ]);
    expect(exported.manifest.embeddedAssets).toEqual([
      {
        assetId: EMBEDDED_ASSET_ID,
        sha256: sha,
        contentType: "image/png",
        originalFilename: "embed.png",
        ownedBy: ["tasks"],
      },
    ]);

    companySvc.create.mockResolvedValue({ id: "company-imported", name: "Imported" });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.list.mockResolvedValue([]);
    issueSvc.create.mockResolvedValue({ id: "issue-imported", title: "Embedded image task", projectId: null });
    assetSvc.create.mockResolvedValue({ id: "asset-imported-1" });

    const result = await portability.importBundle({
      source: { type: "inline", rootPath: exported.rootPath, files: exported.files },
      include: { company: true, agents: false, projects: false, issues: true },
      target: { mode: "new_company", newCompanyName: "Imported" },
      agents: "all",
      collisionStrategy: "rename",
    }, "user-1");

    // One asset row is recreated for the shared reference, from bytes that
    // hash to the exported blob's address.
    expect(storage.putFile).toHaveBeenCalledTimes(1);
    expect(storage.putFile).toHaveBeenCalledWith(expect.objectContaining({
      companyId: "company-imported",
      namespace: "assets/general",
      originalFilename: "embed.png",
      contentType: "image/png",
      body: Buffer.from("embedded-image-bytes"),
    }));
    expect(assetSvc.create).toHaveBeenCalledTimes(1);
    expect(assetSvc.create).toHaveBeenCalledWith("company-imported", expect.objectContaining({
      contentType: "image/png",
      originalFilename: "embed.png",
      sha256: sha,
      createdByAgentId: null,
      createdByUserId: nativeUserId,
    }));

    // Every reference now points at the minted asset id, not the source id.
    const importedDescription = (issueSvc.importIssues.mock.calls[0]![1] as Array<{ description: string }>)[0]!.description;
    expect(importedDescription).toContain(embeddedAssetUrl("asset-imported-1"));
    expect(importedDescription).not.toContain(EMBEDDED_ASSET_ID);
    const importedCommentBody = (issueSvc.addImportedComments.mock.calls[0]![0] as Array<{ body: string }>)[0]!.body;
    expect(importedCommentBody).toContain(embeddedAssetUrl("asset-imported-1"));
    expect(importedCommentBody).not.toContain(EMBEDDED_ASSET_ID);
    expect(documentSvc.createIssueDocumentsForImport).toHaveBeenCalledWith(expect.arrayContaining([
      expect.objectContaining({
        key: "spec",
        body: expect.stringContaining(embeddedAssetUrl("asset-imported-1")),
      }),
    ]), expect.anything());
    const importedDocumentBody = (documentSvc.createIssueDocumentsForImport.mock.calls[0]![0] as Array<{ body: string }>)[0]!.body;
    expect(importedDocumentBody).not.toContain(EMBEDDED_ASSET_ID);
    expect(result.warnings.filter((warning) => warning.includes("embedded"))).toEqual([]);
  });

  it("skips embedded image references that are foreign or dangling with one aggregate warning", async () => {
    const storage = fakeAttachmentStorage();
    const portability = currentHumanExportPortability(storage as any);
    const foreignAssetId = "aaaaaaaa-bbbb-4ccc-8ddd-eeeeeeeeeeee";
    const missingAssetId = "12345678-1234-4123-8123-123456789abc";
    mockEmbeddedAssetExportSources(
      `![theirs](${embeddedAssetUrl(foreignAssetId)})\n\n![gone](${embeddedAssetUrl(missingAssetId)})`,
    );
    issueSvc.listComments.mockResolvedValue([]);
    documentSvc.listIssueDocuments.mockResolvedValue([]);
    // A crafted reference naming another company's asset id must not pull
    // that asset's bytes into the bundle.
    assetSvc.getById.mockImplementation(async (assetId: string) => (
      assetId === foreignAssetId
        ? {
            id: foreignAssetId,
            companyId: "company-2",
            provider: "local_disk",
            objectKey: "assets/general/secret.png",
            contentType: "image/png",
            byteSize: 6,
            sha256: sha256Of("secret"),
            originalFilename: "secret.png",
          }
        : null
    ));

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: { company: true, agents: false, projects: false, issues: true },
    });

    expect(Object.keys(exported.files).some((filePath) => filePath.startsWith("blobs/"))).toBe(false);
    expect(storage.getObject).not.toHaveBeenCalled();
    expect(asTextFile(exported.files[".paperclip.yaml"])).not.toContain("embeddedAssets:");
    expect(exported.manifest.embeddedAssets).toEqual([]);
    expect(exported.warnings).toContain(
      "2 embedded image references point at assets that do not belong to this company or no longer exist; their images were not exported.",
    );
  });

  it("leaves embedded image references untouched when their blob is missing at import", async () => {
    const storage = fakeAttachmentStorage();
    const portability = currentHumanExportPortability(storage as any);
    mockEmbeddedAssetExportSources();
    const sha = sha256Of("embedded-image-bytes");

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: { company: true, agents: false, projects: false, issues: true },
    });
    delete exported.files[`blobs/${sha}`];

    companySvc.create.mockResolvedValue({ id: "company-imported", name: "Imported" });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.list.mockResolvedValue([]);
    issueSvc.create.mockResolvedValue({ id: "issue-imported", title: "Embedded image task", projectId: null });

    const result = await portability.importBundle({
      source: { type: "inline", rootPath: exported.rootPath, files: exported.files },
      include: { company: true, agents: false, projects: false, issues: true },
      target: { mode: "new_company", newCompanyName: "Imported" },
      agents: "all",
      collisionStrategy: "rename",
    }, "user-1");

    expect(assetSvc.create).not.toHaveBeenCalled();
    expect(result.warnings).toContain(
      `Embedded image asset embed.png was skipped because its blob is missing from the package: blobs/${sha}; its references were left unchanged.`,
    );
    const importedDescription = (issueSvc.importIssues.mock.calls[0]![1] as Array<{ description: string }>)[0]!.description;
    expect(importedDescription).toContain(embeddedAssetUrl(EMBEDDED_ASSET_ID));
    const importedCommentBody = (issueSvc.addImportedComments.mock.calls[0]![0] as Array<{ body: string }>)[0]!.body;
    expect(importedCommentBody).toContain(embeddedAssetUrl(EMBEDDED_ASSET_ID));
  });

  it("prunes embedded asset entries and blobs when the referencing files are excluded from the export selection", async () => {
    const storage = fakeAttachmentStorage();
    const portability = currentHumanExportPortability(storage as any);
    mockEmbeddedAssetExportSources();
    const sha = sha256Of("embedded-image-bytes");

    const kept = await portability.exportBundle(nativeCompanyId, {
      include: { company: true, agents: false, projects: false, issues: true },
      selectedFiles: ["COMPANY.md", ".paperclip.yaml", "tasks/pap-1/TASK.md", "tasks/pap-1/documents/spec.md", `blobs/${sha}`],
    });
    expect(kept.manifest.embeddedAssets).toHaveLength(1);
    expect(kept.files[`blobs/${sha}`]).toBeDefined();

    const pruned = await portability.exportBundle(nativeCompanyId, {
      include: { company: true, agents: false, projects: false, issues: true },
      selectedFiles: ["COMPANY.md", ".paperclip.yaml"],
    });
    expect(Object.keys(pruned.files).some((filePath) => filePath.startsWith("blobs/"))).toBe(false);
    const prunedYaml = asTextFile(pruned.files[".paperclip.yaml"]);
    expect(prunedYaml).not.toContain("blobs:");
    expect(pruned.manifest.embeddedAssets).toEqual([]);
  });

  function legacyPackageFiles(extensionLines: string[]) {
    return {
      "COMPANY.md": [
        "---",
        'schema: "agentcompanies/v1"',
        'name: "Legacy Import"',
        "---",
        "",
      ].join("\n"),
      "tasks/kickoff/TASK.md": [
        "---",
        'name: "Kickoff"',
        "---",
        "",
        "Legacy task.",
        "",
      ].join("\n"),
      ".paperclip.yaml": [
        'schema: "paperclip/v1"',
        ...extensionLines,
        "tasks:",
        "  kickoff:",
        '    status: "todo"',
        "",
      ].join("\n"),
    };
  }

  it("previews unstamped v5 task data and refuses unqualified source release", async () => {
    const portability = companyPortabilityService({} as any);
    const v5Warning =
      "This package declares schemaVersion 5 and predates label, blocker, document, work product, monitor, attachment, embedded image, task timestamp, and parent link transfer; that task data imports only if the bundle carries it.";

    companySvc.create.mockResolvedValue({ id: "company-imported", name: "Legacy Import" });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.list.mockResolvedValue([]);
    issueSvc.create.mockResolvedValue({ id: "issue-imported", title: "Kickoff", projectId: null });

    const request = {
      source: { type: "inline" as const, rootPath: "legacy-package", files: legacyPackageFiles([]) },
      include: { company: true, agents: false, projects: false, issues: true },
      target: { mode: "new_company" as const, newCompanyName: "Legacy Import" },
      agents: "all" as const,
      collisionStrategy: "rename" as const,
    };

    const preview = await portability.previewImport(request);
    expect(preview.manifest.schemaVersion).toBe(5);
    expect(preview.warnings).toContain(v5Warning);

    await expect(portability.importBundle(request, nativeUserId, { actor: nativeActor }))
      .rejects.toMatchObject({ status: 422, message: expect.stringContaining("current original-owner review") });
    expect(issueSvc.importIssues).not.toHaveBeenCalled();
    expect(companySvc.create).not.toHaveBeenCalled();
  });

  itNative("refuses same-company legacy task copies without current native source proof", async () => {
    await expect(companyPortabilityService(nativeDb).importBundle({
      source: { type: "inline", rootPath: "legacy-package", files: legacyPackageFiles([]) },
      include: { company: false, agents: false, projects: false, issues: true },
      target: { mode: "existing_company", companyId: nativeCompanyId },
      agents: "all", collisionStrategy: "rename",
    }, nativeUserId, { actor: nativeActor })).rejects.toMatchObject({ status: 422,
      message: expect.stringContaining("current original-owner review") });
    expect(issueSvc.importIssues).not.toHaveBeenCalled();
    expect(companySvc.create).not.toHaveBeenCalled();
  });

  it("keeps packages declaring schemaVersions below 5 importable", async () => {
    const portability = companyPortabilityService({} as any);

    const preview = await portability.previewImport({
      source: { type: "inline", rootPath: "legacy-package", files: legacyPackageFiles(["schemaVersion: 1"]) },
      include: { company: true, agents: false, projects: false, issues: true },
      target: { mode: "new_company", newCompanyName: "Legacy Import" },
      agents: "all",
      collisionStrategy: "rename",
    });

    expect(preview.errors).toEqual([]);
    expect(preview.manifest.schemaVersion).toBe(1);
    expect(preview.warnings.some((warning) => warning.startsWith("This package declares schemaVersion 1"))).toBe(true);
  });

  it("imports a legacy package carrying the retired brand color and attachment limit", async () => {
    const portability = companyPortabilityService(nativeDb);

    companySvc.create.mockResolvedValue({ id: "company-imported", name: "Legacy Import" });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.list.mockResolvedValue([]);
    issueSvc.create.mockResolvedValue({ id: "issue-imported", title: "Kickoff", projectId: null });

    const request = {
      source: {
        type: "inline" as const,
        rootPath: "legacy-package",
        files: legacyPackageFiles([
          "company:",
          '  brandColor: "#5c5fff"',
          "  attachmentMaxBytes: 25000000",
        ]),
      },
      include: { company: true, agents: false, projects: false, issues: false },
      target: { mode: "new_company" as const, newCompanyName: "Legacy Import" },
      agents: "all" as const,
      collisionStrategy: "rename" as const,
    };

    const preview = await portability.previewImport(request);
    expect(preview.errors).toEqual([]);
    expect(preview.manifest.company).not.toHaveProperty("brandColor");
    expect(preview.manifest.company).not.toHaveProperty("attachmentMaxBytes");

    await portability.importBundle(request, nativeUserId, { actor: nativeActor });

    expect(companySvc.create).toHaveBeenCalledWith(
      expect.not.objectContaining({ brandColor: expect.anything() }),
    );
    expect(companySvc.create).toHaveBeenCalledWith(
      expect.not.objectContaining({ attachmentMaxBytes: expect.anything() }),
    );
  });

  it("rejects packages produced by a newer Paperclip", async () => {
    const portability = companyPortabilityService({} as any);

    await expect(portability.importBundle({
      source: { type: "inline", rootPath: "future-package", files: legacyPackageFiles(["schemaVersion: 9"]) },
      include: { company: true, agents: false, projects: false, issues: true },
      target: { mode: "new_company", newCompanyName: "Future Import" },
      agents: "all",
      collisionStrategy: "rename",
    }, "user-1")).rejects.toThrow(/newer Paperclip/);
    expect(issueSvc.importIssues).not.toHaveBeenCalled();
  });

  it("preserves issue comment presentation fields through export and import", async () => {
    const portability = currentHumanExportPortability();
    const presentation = { kind: "system_notice", tone: "warning", detailsDefaultOpen: false };
    const metadata = {
      version: 1,
      sections: [{ rows: [{ type: "key_value", label: "Cause", value: "successful_run_missing_state" }] }],
    };

    projectSvc.list.mockResolvedValue([]);
    projectSvc.listWorkspaces.mockResolvedValue([]);
    issueSvc.list.mockResolvedValue([
      {
        id: "issue-1",
        identifier: "PAP-1",
        title: "Needs disposition",
        description: "System notice source",
        projectId: null,
        projectWorkspaceId: null,
        assigneeAgentId: null,
        status: "todo",
        priority: "high",
        labelIds: [],
        billingCode: null,
        executionWorkspaceSettings: null,
        assigneeAdapterOverrides: null,
      },
    ]);
    issueSvc.listComments.mockResolvedValue([
      {
        id: "comment-1",
        issueId: "issue-1",
        companyId: "company-1",
        authorType: "system",
        authorAgentId: null,
        authorUserId: null,
        body: "Paperclip needs a disposition before this issue can continue.",
        presentation,
        metadata,
        createdAt: new Date("2026-05-04T12:00:00.000Z"),
        updatedAt: new Date("2026-05-04T12:00:00.000Z"),
      },
    ]);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: { company: true, agents: false, projects: false, issues: true },
    });

    const extension = asTextFile(exported.files[".paperclip.yaml"]);
    expect(extension).toContain("comments:");
    expect(extension).toContain("system_notice");
    expect(extension).toContain("successful_run_missing_state");

    companySvc.create.mockResolvedValue({ id: "company-imported", name: "Imported" });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.list.mockResolvedValue([]);
    projectSvc.list.mockResolvedValue([]);
    issueSvc.create.mockResolvedValue({ id: "issue-imported", title: "Needs disposition" });

    await portability.importBundle({
      source: { type: "inline", rootPath: exported.rootPath, files: exported.files },
      include: { company: true, agents: false, projects: false, issues: true },
      target: { mode: "new_company", newCompanyName: "Imported" },
      agents: "all",
      collisionStrategy: "rename",
    }, "user-1");

    expect(issueSvc.addImportedComments).toHaveBeenCalledWith(expect.arrayContaining([
      expect.objectContaining({
        body: "Paperclip needs a disposition before this issue can continue.",
        authorType: "system",
        authorAgentId: null,
        authorUserId: null,
        presentation,
        metadata,
        createdAt: "2026-05-04T12:00:00.000Z",
      }),
    ]), expect.anything());
  });

  it("does not export raw comment author user ids", async () => {
    const portability = currentHumanExportPortability();

    projectSvc.list.mockResolvedValue([]);
    projectSvc.listWorkspaces.mockResolvedValue([]);
    issueSvc.list.mockResolvedValue([
      {
        id: "issue-1",
        identifier: "PAP-1",
        title: "Private board note",
        description: null,
        projectId: null,
        projectWorkspaceId: null,
        assigneeAgentId: null,
        status: "todo",
        priority: "medium",
        labelIds: [],
        billingCode: null,
        executionWorkspaceSettings: null,
        assigneeAdapterOverrides: null,
      },
    ]);
    issueSvc.listComments.mockResolvedValue([
      {
        id: "comment-1",
        issueId: "issue-1",
        companyId: "company-1",
        authorType: "user",
        authorAgentId: null,
        authorUserId: "local-board",
        body: "Need private follow-up.",
        presentation: null,
        metadata: null,
        createdAt: new Date("2026-05-04T12:00:00.000Z"),
        updatedAt: new Date("2026-05-04T12:00:00.000Z"),
      },
    ]);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: { company: true, agents: false, projects: false, issues: true },
    });

    const extension = asTextFile(exported.files[".paperclip.yaml"]);
    expect(extension).toContain('authorType: "user"');
    expect(extension).not.toContain("authorUserId: local-board");
  });

  it("downgrades user-authored imported comments to system when no importing user exists", async () => {
    const portability = currentHumanExportPortability();

    projectSvc.list.mockResolvedValue([]);
    projectSvc.listWorkspaces.mockResolvedValue([]);
    issueSvc.list.mockResolvedValue([
      {
        id: "issue-1",
        identifier: "PAP-1",
        title: "Private board note",
        description: null,
        projectId: null,
        projectWorkspaceId: null,
        assigneeAgentId: null,
        status: "todo",
        priority: "medium",
        labelIds: [],
        billingCode: null,
        executionWorkspaceSettings: null,
        assigneeAdapterOverrides: null,
      },
    ]);
    issueSvc.listComments.mockResolvedValue([
      {
        id: "comment-1",
        issueId: "issue-1",
        companyId: "company-1",
        authorType: "user",
        authorAgentId: null,
        authorUserId: "local-board",
        body: "Need private follow-up.",
        presentation: null,
        metadata: null,
        createdAt: new Date("2026-05-04T12:00:00.000Z"),
        updatedAt: new Date("2026-05-04T12:00:00.000Z"),
      },
    ]);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: { company: true, agents: false, projects: false, issues: true },
    });

    companySvc.create.mockResolvedValue({ id: "company-imported", name: "Imported" });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.list.mockResolvedValue([]);
    projectSvc.list.mockResolvedValue([]);
    issueSvc.create.mockResolvedValue({ id: "issue-imported", title: "Private board note" });

    const result = await portability.importBundle({
      source: { type: "inline", rootPath: exported.rootPath, files: exported.files },
      include: { company: true, agents: false, projects: false, issues: true },
      target: { mode: "new_company", newCompanyName: "Imported" },
      agents: "all",
      collisionStrategy: "rename",
    }, null);

    expect(issueSvc.addImportedComments).toHaveBeenCalledWith(expect.arrayContaining([
      expect.objectContaining({
        body: "Need private follow-up.",
        authorType: "system",
        authorAgentId: null,
        authorUserId: null,
        presentation: null,
        metadata: null,
        createdAt: "2026-05-04T12:00:00.000Z",
      }),
    ]), expect.anything());
    expect(result.warnings).toContain(
      "Comment on task pap-1 was imported as a system comment because no importing user was available.",
    );
  });

  itNative("strips root AGENTS frontmatter when importing a nested agent entry path", async () => {
    useNativeExportCompany();
    const portability = companyPortabilityService(nativeDb);

    companySvc.create.mockResolvedValue({
      id: "company-imported",
      name: "Imported Paperclip",
    });
    accessSvc.ensureMembership.mockResolvedValue(undefined);
    agentSvc.create.mockResolvedValue({
      id: "agent-created",
      name: "ClaudeCoder",
    });

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
    }, { actor: nativeActor });
    const originalAgentsMarkdown = exported.files["agents/claudecoder/AGENTS.md"];
    expect(typeof originalAgentsMarkdown).toBe("string");

    const files = {
      ...exported.files,
      "agents/claudecoder/nested/AGENTS.md": originalAgentsMarkdown!,
    };

    agentSvc.list.mockResolvedValue([]);

    await portability.importBundle({
      source: {
        type: "inline",
        rootPath: exported.rootPath,
        files,
      },
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
      target: {
        mode: "new_company",
        newCompanyName: "Imported Paperclip",
      },
      agents: ["claudecoder"],
      collisionStrategy: "rename",
      adapterOverrides: {
        claudecoder: {
          adapterType: "codex_local",
          adapterConfig: {
            dangerouslyBypassApprovalsAndSandbox: true,
          },
        },
      },
    }, "user-1");

    const nestedMaterializedFiles = agentInstructionsSvc.materializeManagedBundle.mock.calls
      .map(([, filesArg]) => filesArg as Record<string, string>)
      .find((filesArg) => typeof filesArg["nested/AGENTS.md"] === "string");

    expect(nestedMaterializedFiles).toBeDefined();
    expect(nestedMaterializedFiles?.["nested/AGENTS.md"]).toContain("You are ClaudeCoder.");
    expect(nestedMaterializedFiles?.["AGENTS.md"]).toContain("You are ClaudeCoder.");
    expect(nestedMaterializedFiles?.["AGENTS.md"]).not.toMatch(/^---\n/);
    expect(nestedMaterializedFiles?.["AGENTS.md"]).not.toContain('name: "ClaudeCoder"');
  });

  itNative("rejects dangerous adapter types on agent-safe imports", async () => {
    useNativeExportCompany();
    const portability = companyPortabilityService(nativeDb);
    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
    }, { actor: nativeActor });

    agentSvc.list.mockResolvedValue([]);

    await expect(portability.importBundle({
      source: {
        type: "inline",
        rootPath: exported.rootPath,
        files: exported.files,
      },
      include: {
        company: false,
        agents: true,
        projects: false,
        issues: false,
      },
      target: {
        mode: "existing_company",
        companyId: nativeCompanyId,
      },
      agents: ["claudecoder"],
      collisionStrategy: "rename",
      adapterOverrides: {
        claudecoder: {
          adapterType: "process",
          adapterConfig: {
            command: "/bin/sh",
            args: ["-c", "id"],
          },
        },
      },
    }, "user-1", {
      mode: "agent_safe",
      sourceCompanyId: nativeCompanyId,
    })).rejects.toThrow('Adapter type "process" is not allowed in safe imports');

    expect(agentSvc.create).not.toHaveBeenCalled();
  });

  it("reports unsafe project workspace commands on agent-safe import preview", async () => {
    const portability = companyPortabilityService({} as any);

    const preview = await portability.previewImport({
      source: {
        type: "inline",
        files: {
          "COMPANY.md": "---\nname: Import\nincludes:\n  - projects/app/PROJECT.md\n---\n",
          "projects/app/PROJECT.md": "---\nname: App\nslug: app\n---\n\n# App\n",
          ".paperclip.yaml": [
            "schema: paperclip/v1",
            "projects:",
            "  app:",
            "    workspaces:",
            "      default:",
            "        name: App",
            "        repoUrl: https://github.com/paperclipai/paperclip",
            "        setupCommand: pnpm install",
            "",
          ].join("\n"),
        },
      },
      include: {
        company: false,
        agents: false,
        projects: true,
        issues: false,
      },
      target: {
        mode: "existing_company",
        companyId: "company-1",
      },
      collisionStrategy: "rename",
    }, {
      mode: "agent_safe",
      sourceCompanyId: "company-1",
    });

    expect(preview.errors).toContain("Safe import does not allow project app workspace default setupCommand.");
  });

  it("reports invalid imported project env on agent-safe import preview", async () => {
    const portability = companyPortabilityService({} as any);
    secretSvc.normalizeEnvBindingsForPersistence.mockRejectedValueOnce(new Error("Secret must belong to same company"));

    const preview = await portability.previewImport({
      source: {
        type: "inline",
        files: {
          "COMPANY.md": "---\nname: Import\nincludes:\n  - projects/app/PROJECT.md\n---\n",
          "projects/app/PROJECT.md": "---\nname: App\nslug: app\n---\n\n# App\n",
          ".paperclip.yaml": [
            "schema: paperclip/v1",
            "projects:",
            "  app:",
            "    inputs:",
            "      env:",
            "        API_KEY:",
            "          kind: secret",
            "          requirement: required",
            "    env:",
            "      API_KEY:",
            "        type: secret_ref",
            "        secretId: 22222222-2222-4222-8222-222222222222",
            "        version: latest",
            "",
          ].join("\n"),
        },
      },
      include: {
        company: false,
        agents: false,
        projects: true,
        issues: false,
      },
      target: {
        mode: "existing_company",
        companyId: "company-1",
      },
      collisionStrategy: "rename",
    }, {
      mode: "agent_safe",
      sourceCompanyId: "company-1",
    });

    expect(preview.errors).toContain("Secret must belong to same company");
  });

  it("rejects unsafe routine and issue execution overrides on agent-safe import apply", async () => {
    const portability = companyPortabilityService({} as any);

    await expect(portability.importBundle({
      source: {
        type: "inline",
        files: {
          "COMPANY.md": "---\nname: Import\nincludes:\n  - agents/ceo/AGENTS.md\n  - projects/app/PROJECT.md\n  - tasks/review/TASK.md\n---\n",
          "agents/ceo/AGENTS.md": "---\nname: CEO\nslug: ceo\nrole: ceo\n---\n\nLead.",
          "projects/app/PROJECT.md": "---\nname: App\nslug: app\n---\n\n# App\n",
          "tasks/review/TASK.md": "---\nname: Review\nslug: review\nproject: app\nassignee: ceo\nrecurring: true\n---\n\nReview.",
          ".paperclip.yaml": [
            "schema: paperclip/v1",
            "tasks:",
            "  review:",
            "    executionWorkspaceSettings:",
            "      mode: isolated_workspace",
            "    assigneeAdapterOverrides:",
            "      adapterType: codex_local",
            "routines:",
            "  review:",
            "    triggers:",
            "      - kind: webhook",
            "        enabled: true",
            "",
          ].join("\n"),
        },
      },
      include: {
        company: false,
        agents: true,
        projects: true,
        issues: true,
      },
      target: {
        mode: "existing_company",
        companyId: "company-1",
      },
      collisionStrategy: "rename",
    }, "user-1", {
      mode: "agent_safe",
      sourceCompanyId: "company-1",
    })).rejects.toThrow("Safe import does not allow task review executionWorkspaceSettings.");

    expect(issueSvc.importIssues).not.toHaveBeenCalled();
    expect(routineSvc.createTrigger).not.toHaveBeenCalled();
  });

  itNative("imports new agents as active while preserving future hire approval settings", async () => {
    useNativeExportCompany();
    const portability = companyPortabilityService(nativeDb);
    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
    }, { actor: nativeActor });

    agentSvc.list.mockResolvedValue([]);
    secretSvc.normalizeAdapterConfigForPersistence.mockResolvedValueOnce({
      normalized: true,
      env: {
        OPENAI_API_KEY: {
          type: "secret_ref",
          secretId: "secret-1",
          version: "latest",
        },
      },
    });
    agentSvc.create.mockImplementation(async (_companyId: string, input: Record<string, unknown>) => ({
      id: "agent-created",
      name: String(input.name),
      adapterType: input.adapterType,
      adapterConfig: input.adapterConfig,
      status: input.status,
    }));

    await portability.importBundle({
      source: {
        type: "inline",
        rootPath: exported.rootPath,
        files: exported.files,
      },
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
      target: {
        mode: "new_company",
        newCompanyName: "Imported Paperclip",
      },
      agents: ["claudecoder"],
      collisionStrategy: "rename",
    }, "user-1");

    expect(secretSvc.normalizeAdapterConfigForPersistence).toHaveBeenCalledWith(
      "company-imported",
      expect.anything(),
      { strictMode: false, adapterType: "claude_local" },
    );
    expect(agentSvc.create).toHaveBeenCalledWith("company-imported", expect.objectContaining({
      adapterType: "claude_local",
      adapterConfig: expect.objectContaining({
        normalized: true,
      }),
      status: "idle",
    }), expect.objectContaining({ transaction: expect.anything() }));
    expect(companySvc.create).toHaveBeenCalledWith(expect.objectContaining({
      requireBoardApprovalForNewAgents: false,
    }));
  });

  itNative("normalizes adapter config on replace imports before updating existing agents", async () => {
    useNativeExportCompany();
    const portability = companyPortabilityService(nativeDb);
    const sourceAgents = (await agentSvc.list()) as Array<Record<string, unknown>>;
    agentSvc.list.mockResolvedValue(sourceAgents.map((agent) => ({
      ...agent,
      runtimeConfig: {
        ...((agent.runtimeConfig ?? {}) as Record<string, unknown>),
        debug: { providerTrace: "raw", retainedDebugSetting: true },
      },
    })));
    agentSvc.list.mockClear();
    const exported = await portability.exportBundle(nativeCompanyId, {
      include: {
        company: true,
        agents: true,
        projects: false,
        issues: false,
      },
    }, { actor: nativeActor });

    secretSvc.normalizeAdapterConfigForPersistence.mockResolvedValueOnce({
      normalized: "updated",
    });
    agentSvc.update.mockImplementation(async (id: string, patch: Record<string, unknown>) => ({
      id,
      name: "ClaudeCoder",
      adapterType: patch.adapterType,
      adapterConfig: patch.adapterConfig,
    }));

    await portability.importBundle({
      source: {
        type: "inline",
        rootPath: exported.rootPath,
        files: exported.files,
      },
      include: {
        company: false,
        agents: true,
        projects: false,
        issues: false,
      },
      target: {
        mode: "existing_company",
        companyId: nativeCompanyId,
      },
      agents: ["claudecoder"],
      collisionStrategy: "replace",
      adapterOverrides: {
        claudecoder: {
          adapterType: "codex_local",
          adapterConfig: {
            model: "gpt-5.4",
          },
        },
      },
    }, "user-1");

    expect(secretSvc.normalizeAdapterConfigForPersistence).toHaveBeenCalledWith(
      nativeCompanyId,
      expect.objectContaining({
        model: "gpt-5.4",
        extraArgs: ["--skip-git-repo-check"],
      }),
      { strictMode: false, adapterType: "codex_local" },
    );
    expect(agentSvc.update).toHaveBeenCalledWith("agent-1", expect.objectContaining({
      adapterType: "codex_local",
      adapterConfig: {
        normalized: "updated",
      },
      runtimeConfig: {
        debug: {
          retainedDebugSetting: true,
        },
        heartbeat: {
          enabled: false,
          maxConcurrentRuns: 20,
        },
      },
    }), expect.objectContaining({ transaction: expect.anything() }));
    const runtimeUpdate = agentSvc.update.mock.calls.find(
      ([, patch]) => patch.runtimeConfig !== undefined,
    )?.[1].runtimeConfig as Record<string, unknown> | undefined;
    expect(runtimeUpdate?.debug).not.toHaveProperty("providerTrace");
  });

  itNative("nameOverrides applied after collision detection do not re-validate uniqueness", async () => {
    useNativeExportCompany();
    const portability = companyPortabilityService(nativeDb);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: { company: false, agents: true, projects: false, issues: false },
    }, { actor: nativeActor });

    // Simulate existing agents so collision detection triggers rename
    agentSvc.list.mockResolvedValue([
      { id: "existing-1", name: "ClaudeCoder", status: "idle", role: "engineer", adapterType: "claude_local", adapterConfig: {}, runtimeConfig: {}, budgetMonthlyCents: 0, permissions: {}, metadata: null },
    ]);

    const preview = await portability.previewImport({
      source: { type: "inline", rootPath: exported.rootPath, files: exported.files },
      include: { company: false, agents: true, projects: false, issues: false },
      target: { mode: "existing_company", companyId: nativeCompanyId },
      agents: ["claudecoder"],
      collisionStrategy: "rename",
      nameOverrides: { claudecoder: "ClaudeCoder" },
    });

    // The override reverts the renamed agent back to its original collision name.
    // This is a known limitation: nameOverrides bypass collision checks.
    const plan = preview.plan.agentPlans.find((p) => p.slug === "claudecoder");
    expect(plan).toBeDefined();
    expect(plan!.action).toBe("create");
    expect(plan!.plannedName).toBe("ClaudeCoder");
  });

  itNative("handles circular reportsTo chains without infinite recursion during export", async () => {
    useNativeExportCompany();
    const portability = companyPortabilityService(nativeDb);

    agentSvc.list.mockResolvedValue([
      {
        id: "agent-a", name: "AgentA", status: "idle", role: "engineer", title: null, icon: null,
        reportsTo: "agent-b", capabilities: null, adapterType: "claude_local",
        adapterConfig: {}, runtimeConfig: {}, budgetMonthlyCents: 0, permissions: {}, metadata: null,
      },
      {
        id: "agent-b", name: "AgentB", status: "idle", role: "manager", title: null, icon: null,
        reportsTo: "agent-a", capabilities: null, adapterType: "claude_local",
        adapterConfig: {}, runtimeConfig: {}, budgetMonthlyCents: 0, permissions: {}, metadata: null,
      },
    ]);
    agentInstructionsSvc.exportFiles.mockResolvedValue({
      files: { "AGENTS.md": "Instructions" }, entryFile: "AGENTS.md", warnings: [],
    });

    // Export should complete without infinite recursion in org chart building
    const exported = await portability.exportBundle(nativeCompanyId, {
      include: { company: true, agents: true, projects: false, issues: false },
    }, { actor: nativeActor });

    expect(exported.manifest.agents).toHaveLength(2);
    // Both agents should appear in the export
    const slugs = exported.manifest.agents.map((a) => a.slug);
    expect(slugs).toContain("agenta");
    expect(slugs).toContain("agentb");
  });

  it("resolves issue assignee to existing agent when agent is skipped", async () => {
    const portability = currentHumanExportPortability();

    projectSvc.list.mockResolvedValue([{
      id: "project-1", companyId: "company-1", name: "TestProject", urlKey: "testproject",
      description: null, leadAgentId: null, targetDate: null, color: null, status: "planned",
      executionWorkspacePolicy: null, archivedAt: null, workspaces: [],
    }]);
    issueSvc.list.mockResolvedValue([{
      id: "issue-1", companyId: "company-1", title: "Test task", identifier: "PAP-1",
      description: "A test task", status: "todo", priority: "medium",
      assigneeAgentId: "agent-1", projectId: "project-1", projectWorkspaceId: null,
      goalId: null, parentId: null, billingCode: null, labelIds: [],
      executionWorkspaceSettings: null, assigneeAdapterOverrides: null, metadata: null,
    }]);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: { company: false, agents: true, projects: true, issues: true },
    });

    // Re-import into same company with skip collision strategy
    // Both agents exist so both will be skipped; the existing agent should resolve for issue assignment
    agentSvc.list.mockResolvedValue([
      { id: "agent-1", name: "ClaudeCoder", status: "idle", role: "engineer", adapterType: "claude_local", adapterConfig: {}, runtimeConfig: {}, budgetMonthlyCents: 0, permissions: {}, metadata: null },
      { id: "agent-2", name: "CMO", status: "idle", role: "cmo", adapterType: "claude_local", adapterConfig: {}, runtimeConfig: {}, budgetMonthlyCents: 0, permissions: {}, metadata: null },
    ]);
    projectSvc.list.mockResolvedValue([]);
    issueSvc.list.mockResolvedValue([]);
    projectSvc.create.mockResolvedValue({ id: "project-new", companyId: "company-1", urlKey: "testproject" });
    issueSvc.create.mockResolvedValue({ id: "issue-new", identifier: "PAP-100" });

    const result = await portability.importBundle({
      source: { type: "inline", rootPath: exported.rootPath, files: exported.files },
      include: { company: false, agents: true, projects: true, issues: true },
      target: { mode: "existing_company", companyId: "company-1" },
      agents: "all",
      collisionStrategy: "skip",
    }, "user-1");

    // Both agents should be skipped (already exist)
    const agentResult = result.agents.find((a) => a.slug === "claudecoder");
    expect(agentResult).toBeDefined();
    expect(agentResult!.action).toBe("skipped");

    // Issue should still be created and reference the existing agent
    expect(issueSvc.importIssues).toHaveBeenCalled();
    const issueImportCall = issueSvc.importIssues.mock.calls[0];
    // The assigneeAgentId should resolve to the existing agent via existingSlugToAgentId
    expect(issueImportCall[1]).toEqual(expect.arrayContaining([
      expect.objectContaining({
        assigneeAgentId: "agent-1",
      }),
    ]));
  });

  itNative("handles a package with only skills (no agents or projects)", async () => {
    useNativeExportCompany();
    const skills = await companySkillSvc.listFull(nativeCompanyId);
    companySkillSvc.listFull.mockResolvedValueOnce(skills.map((skill) => ({ ...skill, companyId: nativeCompanyId })));
    const portability = companyPortabilityService(nativeDb);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: { company: false, agents: false, projects: false, issues: false, skills: true },
      expandReferencedSkills: true,
    }, { actor: nativeActor });

    expect(exported.manifest.agents).toHaveLength(0);
    expect(exported.manifest.projects).toHaveLength(0);
    expect(exported.manifest.issues).toHaveLength(0);
    // Skills should still be exported
    expect(exported.manifest.skills.length).toBeGreaterThanOrEqual(0);
  });

  itNative("preview import detects no agents to import when agents are excluded", async () => {
    useNativeExportCompany();
    const portability = companyPortabilityService(nativeDb);

    const exported = await portability.exportBundle(nativeCompanyId, {
      include: { company: true, agents: true, projects: false, issues: false },
    }, { actor: nativeActor });

    agentSvc.list.mockResolvedValue([]);

    const preview = await portability.previewImport({
      source: { type: "inline", rootPath: exported.rootPath, files: exported.files },
      include: { company: false, agents: false, projects: false, issues: false },
      target: { mode: "existing_company", companyId: nativeCompanyId },
      agents: "all",
      collisionStrategy: "rename",
    });

    expect(preview.plan.agentPlans).toHaveLength(0);
    expect(preview.plan.projectPlans).toHaveLength(0);
    expect(preview.plan.issuePlans).toHaveLength(0);
  });

  itNative("rejects runner imports while disabled and accepts the same selection when enabled", async () => {
    useNativeExportCompany();
    managedAgentProfileSvc.requireQualified.mockResolvedValue({ id: "managed-primary", companyId: nativeCompanyId, enabled: true });
    const portability = companyPortabilityService(nativeDb);
    const exported = await portability.exportBundle(nativeCompanyId, {
      include: { company: false, agents: true, projects: false, issues: false },
    }, { actor: nativeActor });
    agentSvc.list.mockResolvedValue([]);
    agentSvc.create.mockImplementation(async (_companyId: string, input: Record<string, unknown>) => ({
      id: "agent-created",
      ...input,
    }));
    const request = {
      source: {
        type: "inline" as const,
        rootPath: exported.rootPath,
        files: exported.files,
      },
      include: { company: false, agents: true, projects: false, issues: false },
      target: { mode: "existing_company" as const, companyId: nativeCompanyId },
      agents: "all" as const,
      collisionStrategy: "rename" as const,
      adapterOverrides: {
        claudecoder: {
          adapterType: "paperclip_runner",
          adapterConfig: { provider: "codex" },
        },
      },
    };

    await expect(portability.importBundle(request, "user-1")).rejects.toMatchObject({
      status: 422,
      details: { code: "paperclip_runner_rollout_disabled" },
    });
    expect(agentSvc.create).not.toHaveBeenCalled();

    instanceSettingsSvc.getExperimental.mockResolvedValue({ enableNativeRunner: true });
    await portability.importBundle({
      ...request,
      adapterOverrides: {
        claudecoder: {
          adapterType: "paperclip_runner",
          adapterConfig: {
            provider: "opencode",
            model: "openrouter/deepseek/deepseek-v4-flash-0731",
          },
        },
      },
    }, "user-1");
    expect(agentSvc.create).toHaveBeenCalledWith(nativeCompanyId, expect.objectContaining({
      adapterType: "paperclip_runner",
      adapterConfig: expect.objectContaining({ provider: "opencode" }),
    }), expect.objectContaining({ transaction: expect.anything() }));

    await portability.importBundle(request, "user-1");
    expect(agentSvc.create).toHaveBeenCalledWith(nativeCompanyId, expect.objectContaining({
      adapterType: "paperclip_runner",
      adapterConfig: expect.objectContaining({ provider: "codex" }),
    }), expect.objectContaining({ transaction: expect.anything() }));

    await portability.importBundle({
      ...request,
      adapterOverrides: {
        claudecoder: {
          adapterType: "paperclip_runner",
          adapterConfig: {
            provider: "claude_managed",
            managedProfileId: "managed-primary",
            managedAgentsRetentionAcknowledged: true,
          },
        },
      },
    }, "user-1");
    expect(managedAgentProfileSvc.requireQualified).toHaveBeenCalledWith(
      nativeCompanyId,
      "managed-primary",
    );

    const createCallsBeforeInvalidProfile = agentSvc.create.mock.calls.length;
    const { notFound } = await import("../errors.js");
    managedAgentProfileSvc.requireQualified.mockRejectedValueOnce(
      notFound("Managed Agent profile not found"),
    );
    await expect(portability.importBundle({
      ...request,
      adapterOverrides: {
        claudecoder: {
          adapterType: "paperclip_runner",
          adapterConfig: {
            provider: "claude_managed",
            managedProfileId: "managed-other-company",
            managedAgentsRetentionAcknowledged: true,
          },
        },
      },
    }, "user-1")).rejects.toMatchObject({ status: 404 });
    expect(managedAgentProfileSvc.requireQualified).toHaveBeenLastCalledWith(
      nativeCompanyId,
      "managed-other-company",
    );
    expect(agentSvc.create).toHaveBeenCalledTimes(createCallsBeforeInvalidProfile);
  });
});

describe("dedupeImportedCompanyName", () => {
  it("returns the base name when nothing collides", () => {
    expect(dedupeImportedCompanyName("Paperclip", ["Other Co"])).toBe("Paperclip");
    expect(dedupeImportedCompanyName("Paperclip", [])).toBe("Paperclip");
  });

  it("suffixes past every taken candidate, case-insensitively", () => {
    expect(dedupeImportedCompanyName("Paperclip", ["paperclip"])).toBe("Paperclip (2)");
    expect(dedupeImportedCompanyName("Paperclip", ["Paperclip", "Paperclip (2)"])).toBe("Paperclip (3)");
    expect(dedupeImportedCompanyName("Paperclip", ["PAPERCLIP", "paperclip (2)"])).toBe("Paperclip (3)");
  });

  it("ignores surrounding whitespace in existing names", () => {
    expect(dedupeImportedCompanyName("Paperclip", ["  Paperclip  "])).toBe("Paperclip (2)");
  });
});
