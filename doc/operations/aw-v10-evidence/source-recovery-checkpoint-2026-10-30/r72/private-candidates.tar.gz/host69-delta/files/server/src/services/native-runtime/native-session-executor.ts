import {
  isSupportedRemoteCodexVersion,
  parseCodexCliVersion,
  REMOTE_CODEX_SUPPORTED_RANGE,
} from "./codex-runtime-compatibility.js";
import { createNativeToolTrace, type NativeToolTrace } from "./native-tool-trace.js";
import { createNativeGitHubAccess, type NativeGitHubAccess } from "./native-github-access.js";
import { resolveGitHubOperationCredentials } from "../github-operation-credentials.js";
import { bindManagedNativeCredentialTurn, completeManagedNativeCredentialTurn } from "./managed-native-credentials.js";
import { createLocalNativeQuestionBridge } from "./local-native-question-bridge.js";
import { readVerifiedRemoteWorkspaceFile } from "./remote-deliverable-file.js";
import { copyBackCodexAuth } from "@paperclipai/adapter-codex-local/server";
import { nativeCompletionFeedback } from "./native-completion-feedback.js";
import { V7_COMPLETION_SCHEMA } from "../orchestration/orchestration-contracts.js";
import { NATIVE_COMPLETION_CONTRACT_SCHEMA } from "./completion-contracts.js";
import { hasAcknowledgedNativeReassignmentStopIntent, hasAcknowledgedNativeStopIntent } from "../acknowledged-native-stop.js";
import { stoppedCodexTurnIsTextOnly } from "./stopped-codex-turn.js";
import { prepareVerifiedRemoteProviderPack } from "./remote-provider-pack.js";
import { assertNativePaidTransportAdmitted } from "./paid-transport-admission.js";
import { readNativeLocalProcessStop, PROCESS_START_REQUESTED } from "../native-local-process-stop.js";
import { REMOTE_NATIVE_ERASER_ENV, REMOTE_NATIVE_RUNTIME_ASSET_ERASURE_PROBE_SCRIPT, REMOTE_RUNNER_CHILD_LAUNCH_SCRIPT,
  REMOTE_RUNNER_FAILED_IDENTITY_CLEANUP_SCRIPT, REMOTE_RUNNER_IDENTITY_CHECK_SCRIPT,
  REMOTE_RUNNER_PROCESS_FINGERPRINT_SCRIPT, REMOTE_NATIVE_SESSION_FENCE_ACQUIRE_SCRIPT,
  REMOTE_NATIVE_SESSION_FENCE_RELEASE_SCRIPT } from "./remote-runner-identity.js";
export { REMOTE_RUNNER_CHILD_LAUNCH_SCRIPT };
import { remoteLeaseCleanupScope } from "../remote-execution-termination.js";
import {
  createRemoteRuntimeAssetLocator,
  isRemoteRuntimeAssetLocator,
  managedOpenCodeRuntimeDirectory,
  remoteRuntimeAssetLocatorDigest,
  type RemoteRuntimeAssetLocator,
} from "./runtime-asset-retention.js";
import { resolveConnectorAssignments, isConnectorSkill } from "../connector-runtime.js";
import {
  boundedExecutionCleanup,
  EXECUTION_CONTROL_DEADLINE_MS,
} from "../execution-control-deadline.js";
import { createHash, randomUUID } from "node:crypto";
import { isDeepStrictEqual } from "node:util";
import { execFileSync } from "node:child_process";
import {
  chmodSync,
  copyFileSync,
  closeSync,
  constants,
  existsSync,
  fstatSync,
  lstatSync,
  mkdirSync,
  mkdtempSync,
  openSync,
  opendirSync,
  readFileSync,
  readdirSync,
  readlinkSync,
  readSync,
  renameSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { DatabaseSync } from "node:sqlite";
import { basename, dirname, join, posix, resolve } from "node:path";
import type {
  AdapterExecutionResult,
  AdapterRuntimeEvent,
} from "../../adapters/index.js";
import { conversationModelBindingSchema, nativePayloadSourceInputSchema, nativePayloadSourcePolicySchema, nativePayloadSourceSnapshotSchema, nativeRunInputSourceReceiptSchema, unionNativePayloadSourceInputs,
  type NativeFinalizationResult, type NativePayloadSourceInput, type NativeRunInputSourceReceipt } from "@paperclipai/shared";
import type { NativeBootstrapSourceClosure, NativeConsumedSourceComponent, NativeModelOutputCapture, NativePayloadSourceSet } from "./native-execution-input.js";
import { exactNativeInteractionSourceInputs } from "./native-execution-input.js";
import { isCurrentWorkerConversationRoot } from "./worker-conversation-root.js";
import type {
  HarnessRuntimeRequestResolution,
  NativeExecutionInput,
  NativeRuntimeContextSnapshot,
  NativeSession,
  NativeSessionBackend,
  PaperclipQuestionSet,
  PersistedNativeSession,
  PrpEvent,
  PrpStructuredRunResult,
} from "../../vendor/paperclip-runner/index.js";
import {
  NativeProviderTerminalFailure,
  NativeSessionCleanupQuarantinedError,
  NativeSessionProtocolIntegrityError,
  completeRetainedNativeSessionCleanup,
  completeTerminatedLocalNativeSessionCleanup,
  acpxRuntimeSessionDirectoryName,
  createNativeSessionBackend,
  nativeMcpLaunchBinding,
  createRunnerdCodexTransport,
  executeNativeSession,
  nativeSystemInstructions,
  nativeTaskConstraints,
  createCodexTaskEnvelope,
  codexSemanticToolSpecs,
  applyNativeSessionGoalControl,
  buildNativeModelEnvelope,
  inspectWarmRunTransition,
  parseNativeExecutionInput,
  parsePaperclipQuestionSet,
  resolveSourceCodexHome,
  readRunnerdArtifactBinding,
  retainedRunnerdMaintenanceIsIdle,
  settleRetainedRunnerdSession,
  validatePrpEvent,
  validatePrpStructuredRunResult,
  type RunnerProcessHandle,
  type RunnerProcessLaunchSpec,
  type NativeSessionGoalControl,
} from "../../vendor/paperclip-runner/index.js";
import type { AdapterExecutionTarget } from "@paperclipai/adapter-utils/execution-target";
import { createNativeSshCommandRunner } from "./native-ssh-command-runner.js";
import type { CommandManagedRuntimeRunner } from "@paperclipai/adapter-utils/command-managed-runtime";
import {
  resolvePaperclipRunnerTransport,
  type PaperclipRunnerTransport,
} from "@paperclipai/adapter-utils/runner-connectivity";
import type { Db } from "@paperclipai/db";
import {
  and,
  desc,
  eq,
  gt,
  inArray,
  isNull,
  like,
  notInArray,
  or,
  sql,
} from "drizzle-orm";
import {
  agentWakeupRequests,
  documentRevisions,
  documents,
  environmentLeases,
  heartbeatRunEvents,
  heartbeatRuns,
  completionContracts,
  executionWorkspaces,
  assets,
  issueAttachments,
  issueComments,
  issueDocuments,
  issueThreadInteractions,
  issues,
  nativeRunFinalizations,
  nativeRunResults,
  memoryRecords,
  orchestrationPlans,
  orchestrationModelReservations,
  orchestrationWorkerAttempts,
  toolInvocations,
} from "@paperclipai/db";
import { PaperclipControlPlanePort } from "./paperclip-control-plane-port.js";
import { appendHeartbeatRunEvent } from "../heartbeat-run-events.js";
import { nativeSha256 } from "./canonical.js";
import { resolveDefaultAgentWorkspaceDir } from "../../home-paths.js";
import { assertAnalyticalContextPayloadAccess } from "../analytical-context-authority.js";
import { lockAnalyticalCompany } from "../analytical-privacy.js";
import { lockMemoryPrivacy } from "../memory/memory-privacy.js";
import { assembleNativeContextRead, assertNativeContextReadSourceSetCurrent, assertNativeManagedConsumedSourceSetCurrent, assertNativeMemorySourceInputCurrent,
  nativeMemoryReviewTransitionStateHash, assertNativeProjectSourceCurrent,
  assertNativePayloadSourceSetCurrent, assertNativeReadResultSourceSetOwnersCurrent, type NativeContextReadBinding } from "../native-direct-input.js";
import { canActorReadIssuePrivacy, type AuthorizationActor } from "../authorization.js";
import { assertNativeManagedProjectCreateReceiptCurrentInTransaction, managedNativeProjectArgumentsJsonSchema,
  managedNativeProjectArgumentsSchema, managedNativeProjectApiBodyJsonSchema, managedNativeProjectApiCallSchema,
  type NativeProjectCreateReceipt } from "../native-project-output.js";
import { PaperclipRunnerToolAuthority, resolveNativeInputDispatchReceiptIdentity, type NativeDocumentToolResultSource,
  type NativeInputToolResultSource, type NativeProjectToolResultSource,
  type NativeManagedProjectCreateCapture } from "./paperclip-runner-tool-authority.js";
import {nativeManagementToolsAvailable} from "./management-analytical-tools.js";
import { createAssignedMcpTools, getAssignedMcpGateway } from "./assigned-mcp-tools.js";
import { getNativeReviewAssignment, readNativeReviewAssignmentContext } from "./native-review-participant.js";
import { NativeChatAttachmentReadScope } from "./chat-attachment-read.js";
import {
  assertCurrentWakeCommentsRead,
  resolveCurrentWakeCommentsBinding,
} from "./current-wake-comments.js";
import {
  renderNativeRunnerStagedAttachmentPrompt,
  stageNativeRunnerWakeAttachments,
  type NativeRunnerAttachmentSourceCapture,
} from "./native-runner-file-handoff.js";
import { nativeToolContractFingerprintForTarget } from "./native-session-resume.js";
import { verifyRetainedMaintenanceNoLaunch } from "./native-maintenance-no-launch.js";
import { registerRunnerPrpAuthority } from "../../realtime/runner-prp-ws.js";
import { connectRunnerPrpIngress } from "../../realtime/runner-prp-outbound.js";
import { issueRecoveryActionService } from "../issue-recovery-actions.js";
import { reportRunFailure } from "../run-failure-report.js";
import { persistActivity, publishActivity } from "../activity-log.js";
import { commitNativeStatusDecision } from "./status-decision-committer.js";
import { resolvePaperclipInstanceRoot } from "../../home-paths.js";
import { assertRuntimeStorageDirectories } from "../runtime-skill-cache.js";
import { documentService, type DocumentRevisionSourceCapture } from "../documents.js";
import { issueThreadInteractionService } from "../issue-thread-interactions.js";
import { issueService } from "../issues.js";
import {
  NATIVE_STATUS_ARBITER_POLICY_VERSION,
  type NativeAuthoritativeIssueStatus,
  type NativeStatusDecision,
} from "./status-arbiter.js";
import { HttpError } from "../../errors.js";
import { assertNativeAnalyticalRunPayloadAccess } from "../analytical-context-authority.js";
import { redactSensitiveText } from "../../redaction.js";
import { resolvePaperclipRunnerBinary } from "./native-codex-runner.js";
import {
  createNativeRunTrace,
  isNativeRunRootHistoricalSpan,
  nativeRunPreparationStarts,
  type NativeRunHistoricalSpan,
  type NativeRunSpanScope,
  type NativeRunTrace,
} from "./native-run-trace.js";
import { createNativeHarnessBackupStamp } from "./native-harness-backup-stamp.js";
import { removeNativeHarnessBackup } from "./native-harness-backup-cleanup.js";
import { registerLiveRunnerGoalController } from "../runner-goal-control-broker.js";
import { applyRunnerGoalPrpEvent } from "../runner-goals.js";
import { readProcessStartedAt } from "../hot-restart.js";
import {
  NativeRunnerOwnershipUnverifiedError,
  isNativeRunnerOwnershipHeld,
  NATIVE_OWNERSHIP_UNVERIFIED_ERROR_CODE,
  NATIVE_ADOPTED_RUNNER_AUTHENTICATION_TIMEOUT,
} from "./native-runner-ownership.js";
import {
  currentNativeControllerIdentity,
  nextNativeProviderAttempt,
  type NativeControllerIdentity,
  type NativeRestartRecoveryClaim,
} from "./native-restart-recovery.js";

type ActiveNativeSession = {
  session: NativeSession;
  cancelRequested: boolean;
  restartDetach?: Promise<void>;
};

class NativeResultPendingFinalizationError extends Error {
  constructor() {
    super("native_result_pending_finalization");
    this.name = "NativeResultPendingFinalizationError";
  }
}

export class NativeCancellationPendingRecoveryError extends Error {
  constructor() {
    super("native_cancellation_pending_recovery");
    this.name = "NativeCancellationPendingRecoveryError";
  }
}

export class NativeControllerDetachedForRestartError extends Error {
  constructor() {
    super("native_controller_detached_for_restart");
    this.name = "NativeControllerDetachedForRestartError";
  }
}

const activeNativeSessions = new Map<string, ActiveNativeSession>();
type NativeCancelOriginTestFact = {
  stage: "cancel_native_session" | "lease_renewal_failed" | "startup_stop_requested" | "startup_gate" | "active_cancel_requested";
  reason: "analytical_source_access_lost" | "execution_lease_lost" | "stop_during_startup" | "run_stopped_during_startup" | "other" | null;
  runStatus?: "running" | "cancelled" | "failed" | "interrupted" | "succeeded" | "timed_out" | "other" | "missing";
  startupCancellationPresent?: boolean;
  cancellationScope?: "run" | "other" | "absent";
  cancellationDispatchState?: "pending" | "acknowledged" | "other" | "absent";
  frames: Array<{ functionName: string | null; sourceFile: string; line: number }>;
};
const nativeCancelOriginTestFacts = new Map<string, NativeCancelOriginTestFact[]>();

function nativeCancelOriginFrames(): NativeCancelOriginTestFact["frames"] {
  const stack = new Error().stack?.split("\n").slice(2) ?? [];
  const frames: NativeCancelOriginTestFact["frames"] = [];
  for (const line of stack) {
    const match = /^\s*at (?:(.*?) \()?(.+?):(\d+):\d+\)?$/.exec(line);
    if (!match) continue;
    const sourceFile = match[2]!.split(/[\\/]/).at(-1)!;
    const row = Number(match[3]);
    if (!/^[-\w.]+\.(?:ts|js|mjs|cjs)$/.test(sourceFile) || !Number.isSafeInteger(row)) continue;
    frames.push({ functionName: match[1] || null, sourceFile, line: row });
    if (frames.length >= 8) break;
  }
  return frames;
}

function recordNativeCancelOriginTestFact(runId: string, fact: Omit<NativeCancelOriginTestFact, "frames">) {
  if (process.env.PAPERCLIP_NATIVE_CANCEL_ORIGIN_TEST_DIAGNOSTICS !== "1") return;
  const values = nativeCancelOriginTestFacts.get(runId) ?? [];
  if (values.length >= 12) return;
  values.push({ ...fact, frames: nativeCancelOriginFrames() });
  nativeCancelOriginTestFacts.set(runId, values);
  while (nativeCancelOriginTestFacts.size > 64) {
    const oldest = nativeCancelOriginTestFacts.keys().next().value;
    if (!oldest) break;
    nativeCancelOriginTestFacts.delete(oldest);
  }
}

/** Bounded, opt-in fixture evidence; contains enum facts and source frames only. */
export function nativeCancelOriginTestFactsForRun(runId: string): NativeCancelOriginTestFact[] {
  return (nativeCancelOriginTestFacts.get(runId) ?? []).map(fact => ({ ...fact, frames: [...fact.frames] }));
}

function cancellationReasonClass(reason: string): NativeCancelOriginTestFact["reason"] {
  if (reason === "native analytical source access lost" || reason === "Analytical source access lost") return "analytical_source_access_lost";
  if (reason === "native session execution lease lost") return "execution_lease_lost";
  if (reason === "Stop requested during native startup") return "stop_during_startup";
  if (reason === "Run stopped during native session startup") return "run_stopped_during_startup";
  return "other";
}
// Shutdown can race provider startup before onSession publishes its handle.
// Retain the request for the remainder of this controller's lifetime so that
// the late publication detaches before it can dispatch another turn.
const nativeRunsDetachingForRestart = new Set<string>();

// A restart must not cut authority rotation between archiving the previous
// runner state and authenticating its replacement. Keep the startup owner
// alive until onSession can detach it, or until startup itself has settled.
type NativeSessionStartup = {
  promise: Promise<ActiveNativeSession | null>;
  resolve: (session: ActiveNativeSession | null) => void;
  stopRequested?: boolean;
  cancellationSettled?: Promise<void>;
};
const nativeSessionStartups = new Map<string, NativeSessionStartup>();

function detachActiveNativeSessionForRestart(active: ActiveNativeSession) {
  active.restartDetach ??= Promise.resolve().then(() => active.session.detachControllerForRestart!());
  return active.restartDetach;
}

async function waitForNativeSessionStartup(
  runId: string,
  timeoutError: () => Error = () => new Error("native_restart_startup_not_ready"),
) {
  const startup = nativeSessionStartups.get(runId);
  if (!startup) return null;
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      startup.promise,
      new Promise<never>((_resolve, reject) => {
        timer = setTimeout(() => reject(timeoutError()), 30_000);
      }),
    ]);
  } finally {
    if (timer !== undefined) clearTimeout(timer);
  }
}

export async function detachNativeSessionsForRestart(
  runIds: readonly string[],
): Promise<{
  detachedRunIds: string[];
  inactiveRunIds: string[];
  unsupportedRunIds: string[];
}> {
  const detachedRunIds: string[] = [];
  const inactiveRunIds: string[] = [];
  const unsupportedRunIds: string[] = [];
  for (const runId of new Set(runIds)) {
    nativeRunsDetachingForRestart.add(runId);
    const active = activeNativeSessions.get(runId) ?? await waitForNativeSessionStartup(runId);
    if (!active) {
      inactiveRunIds.push(runId);
      continue;
    }
    if (active.session.detachControllerForRestart === undefined) {
      unsupportedRunIds.push(runId);
      continue;
    }
    await detachActiveNativeSessionForRestart(active);
    detachedRunIds.push(runId);
  }
  return { detachedRunIds, inactiveRunIds, unsupportedRunIds };
}
const MAX_REMOTE_CHECKPOINT_ARCHIVE_BYTES = 64 * 1024 * 1024;
const MAX_REMOTE_CHECKPOINT_EXPANDED_BYTES = 64 * 1024 * 1024;
const MAX_REMOTE_CHECKPOINT_ENTRIES = 20_000;
const NATIVE_DURABLE_IDENTITY_MAX_BYTES = 2 * 1024 * 1024;
const NATIVE_RUNNER_STATE_MAX_BYTES = 16 * 1024 * 1024;
const NATIVE_WARM_CHECKPOINT_MAX_BYTES = 8 * 1024 * 1024;
const CODEX_HOME_NON_PERSISTENT_ENTRIES = [
  "tmp",
  ".tmp",
  "auth.json",
  "config.toml",
] as const;
const RUNNERD_CONTROL_PLANE_STATE_SCHEMA =
  "paperclip.runner.durable.control-plane-state.v1";
const RUNNERD_STATE_SCHEMA = "paperclip.runner.durable.state.v1";
const CODEX_PROVIDER_STATE_SCHEMA = "paperclip.runner.codex-provider-state.v1";
const ACPX_PROVIDER_STATE_SCHEMA = "paperclip.runner.acpx-provider-state.v3";
const MANAGED_PROVIDER_STATE_SCHEMA =
  "paperclip.runner.managed-provider-state.v1";
const RUNNERD_STATE_LIFECYCLES = new Set([
  "connecting",
  "ready",
  "backpressure",
  "recoverable_failure",
  "unrecoverable",
  "suspended",
  "stopped",
  "revoked",
]);
const TERMINAL_HEARTBEAT_RUN_STATUSES = new Set([
  "succeeded",
  "interrupted",
  "failed",
  "cancelled",
  "timed_out",
]);
const NATIVE_SESSION_EXECUTION_LEASE_TTL_MS = 20 * 60_000;
const NATIVE_SESSION_EXECUTION_LEASE_RENEW_INTERVAL_MS = 5 * 60_000;
const NATIVE_SESSION_CANCELLATION_CLEANUP_GRACE_MS = 2_000;
const NATIVE_RUNTIME_REQUEST_RESOLUTION_CACHE_MAX = 256;
type NativeRuntimeRequestResolution = {
  runId: string;
  fingerprint: string;
  commandId: string;
  pending: Promise<void>;
  completedAt: number | null;
};
const nativeRuntimeRequestResolutions = new Map<
  string,
  NativeRuntimeRequestResolution
>();

async function verifiedRecoveryProcessIsAlive(input: {
  pid: number;
  startedAt: string;
}): Promise<boolean> {
  try {
    process.kill(input.pid, 0);
  } catch (error) {
    if ((error as NodeJS.ErrnoException | undefined)?.code !== "EPERM")
      return false;
  }
  try {
    const observed = await readProcessStartedAt(input.pid);
    return (
      observed !== null &&
      new Date(observed).getTime() === new Date(input.startedAt).getTime()
    );
  } catch {
    return false;
  }
}

async function signalVerifiedRecoveryProcess(
  input: { pid: number; startedAt: string },
  signal: NodeJS.Signals,
): Promise<boolean> {
  if (!(await verifiedRecoveryProcessIsAlive(input))) return false;
  try {
    return process.kill(input.pid, signal);
  } catch {
    return false;
  }
}

function pruneNativeRuntimeRequestResolutionCache(): void {
  const completed = [...nativeRuntimeRequestResolutions.entries()]
    .filter(([, resolution]) => resolution.completedAt !== null)
    .sort(
      ([, left], [, right]) =>
        (left.completedAt ?? 0) - (right.completedAt ?? 0),
    );
  for (
    let index = 0;
    index < completed.length - NATIVE_RUNTIME_REQUEST_RESOLUTION_CACHE_MAX;
    index += 1
  ) {
    nativeRuntimeRequestResolutions.delete(completed[index]![0]);
  }
}

function clearNativeRuntimeRequestResolutions(runId: string): void {
  for (const [key, resolution] of nativeRuntimeRequestResolutions) {
    if (resolution.runId === runId) {
      nativeRuntimeRequestResolutions.delete(key);
    }
  }
}

type WarmNativeSession = {
  managedAiCredentialIdentity?: string;
  credentialRunId?: string;
  githubAccess?: NativeGitHubAccess;
  githubAuthenticationMode?: string;
  networkAccess: boolean;
  session: NativeSession;
  ownerToken: symbol;
  configDigest: string;
  companyId: string;
  runId: string;
  environmentId: string | null;
  busy: boolean;
  closeOnReleaseReason?: string;
  idleTimer: ReturnType<typeof setTimeout> | null;
  lastActivityAt: string;
};

async function closeWarmNativeSession(entry: WarmNativeSession, reason: string) {
  // Revoke before awaiting process retirement/checkpoint IO.
  const stopping = entry.githubAccess?.stop();
  try { await entry.session.close({ reason }); }
  finally { await stopping; }
}

const warmNativeSessions = new Map<string, WarmNativeSession>();
// Closing a remote owner saves its checkpoint asynchronously. A new turn must
// not inspect or quarantine that owner's state until the save has finished.
const closingWarmNativeSessions = new Map<string, Promise<void>>();

/**
 * Close idle native sessions before an operator destroys their remote
 * environment. A warm runner owns a long-lived sandbox command stream, so the
 * provider cannot safely delete that sandbox until the session has closed the
 * stream. Busy sessions are reported instead of interrupted; the environment
 * delete guard can then fail closed while their heartbeat run is still live.
 */
export async function closeWarmNativeSessionsForEnvironment(input: {
  environmentId: string;
  reason: string;
}): Promise<{ closed: number; busy: number; failed: number }> {
  return closeIdleWarmNativeSessions(input);
}

/** Source erasure closes the exact run-owned warm provider before its data home is removed. */
export async function closeWarmNativeSessionsForRun(input: {
  companyId: string;
  runId: string;
  reason: string;
}): Promise<{ closed: number; busy: number; failed: number }> {
  return closeIdleWarmNativeSessions({ ...input, closeBusyOnRelease: true });
}

/** Suspend idle owners and persist their remote backup before a controller
 * exits. Active turns keep their separate authenticated restart handoff. */
export async function closeIdleWarmNativeSessionsForRestart(): Promise<{
  closed: number; busy: number; failed: number;
}> {
  return closeIdleWarmNativeSessions({
    reason: "controller restart",
    closeBusyOnRelease: true,
  });
}

async function closeIdleWarmNativeSessions(input: {
  environmentId?: string;
  companyId?: string;
  runId?: string;
  reason: string;
  closeBusyOnRelease?: boolean;
}): Promise<{ closed: number; busy: number; failed: number }> {
  let closed = 0;
  let busy = 0;
  let failed = 0;
  for (const [sessionId, entry] of [...warmNativeSessions]) {
    if (input.environmentId !== undefined && entry.environmentId !== input.environmentId) {
      continue;
    }
    if ((input.companyId !== undefined && entry.companyId !== input.companyId) ||
      (input.runId !== undefined && entry.runId !== input.runId)) continue;
    if (entry.busy || executingRunnerdSessionScopes.has(sessionId)) {
      // A busy turn can complete while another idle session is checkpointing.
      // Fence that entry now so its eventual release cannot leave a new idle
      // owner behind after the shutdown sweep has already passed it.
      if (input.closeBusyOnRelease) entry.closeOnReleaseReason = input.reason;
      busy += 1;
      continue;
    }
    if (entry.idleTimer !== null) clearTimeout(entry.idleTimer);
    // Remove ownership before awaiting close so a racing continuation cannot
    // adopt a session whose transport is already shutting down.
    warmNativeSessions.delete(sessionId);
    const closing = Promise.resolve().then(() =>
      closeWarmNativeSession(entry, input.reason),
    );
    closingWarmNativeSessions.set(sessionId, closing);
    try {
      await closing;
      closed += 1;
    } catch {
      failed += 1;
    } finally {
      if (closingWarmNativeSessions.get(sessionId) === closing) {
        closingWarmNativeSessions.delete(sessionId);
      }
    }
  }
  return { closed, busy, failed };
}

function readBoundedNativeFile(
  path: string,
  maxBytes: number,
  errorCode: string,
): Buffer {
  const descriptor = openSync(path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const before = fstatSync(descriptor);
    if (!before.isFile() || before.size > maxBytes) throw new Error(errorCode);
    const output = Buffer.allocUnsafe(before.size);
    let offset = 0;
    while (offset < output.length) {
      const bytesRead = readSync(
        descriptor,
        output,
        offset,
        output.length - offset,
        offset,
      );
      if (bytesRead === 0) break;
      offset += bytesRead;
    }
    const after = fstatSync(descriptor);
    if (
      offset !== before.size ||
      after.size !== before.size ||
      after.mtimeMs !== before.mtimeMs ||
      after.ino !== before.ino
    ) {
      throw new Error("native_state_file_changed");
    }
    return output;
  } finally {
    closeSync(descriptor);
  }
}

const NATIVE_PROVIDER_HOST_ENV_KEYS = [
  "PATH",
  "HOME",
  "USER",
  "LOGNAME",
  "SHELL",
  "TMPDIR",
  "TEMP",
  "TMP",
  "CODEX_HOME",
  "XDG_CONFIG_HOME",
  "XDG_CACHE_HOME",
  "XDG_DATA_HOME",
  "SystemRoot",
  "PATHEXT",
] as const;

async function measureNativeRunnerSpan<T>(
  trace: NativeRunTrace | undefined,
  name: string,
  fn: () => Promise<T>,
  options:
    | string
    | {
        parentName?: string;
        attributes?: Record<string, string | number | boolean>;
      } = {},
): Promise<T> {
  return trace
    ? trace.measure(
        name,
        fn,
        typeof options === "string" ? { parentName: options } : options,
      )
    : fn();
}

/**
 * Provider bootstrap needs a small amount of host process context even when
 * the agent has no configured env. In particular, an empty environment makes
 * a bare `codex` command unresolvable. Agent-configured values remain
 * authoritative and may intentionally override the host defaults, while the
 * server-selected workspace remains an immutable containment boundary.
 */
export function buildNativeProviderEnvironment(
  configured: NodeJS.ProcessEnv,
  host: NodeJS.ProcessEnv = process.env,
  assignedWorkspaceCwd?: string,
): NodeJS.ProcessEnv {
  const inherited = Object.fromEntries(
    NATIVE_PROVIDER_HOST_ENV_KEYS.flatMap((key) => {
      const value = host[key];
      return typeof value === "string" && value.length > 0
        ? [[key, value]]
        : [];
    }),
  );
  const environment = { ...inherited, ...configured };
  if (assignedWorkspaceCwd?.trim()) {
    environment.PAPERCLIP_WORKSPACE_CWD = assignedWorkspaceCwd;
  }
  return environment;
}

type PlanSynchronization = {
  eventId: string;
  planId: string;
  providerRevision: number;
  status:
    | "synchronized"
    | "already_synchronized"
    | "conflict"
    | "invalid"
    | "approval_failed";
  baseRevisionId: string | null;
  digest: string;
  documentRevision: number | null;
  currentRevisionId: string | null;
  confirmationId: string | null;
};

type RuntimeQuestionFallback = {
  kind: "ask_user_questions";
  idempotencyKey: string;
  sourceRunId: string;
  title: string | null;
  summary: string | null;
  continuationPolicy: "wake_assignee";
  payload: {
    version: 1;
    title?: string;
    submitLabel?: string;
    supersedeOnUserComment: false;
    runtimeRequestId: string;
    questionSet: PaperclipQuestionSet;
    questions: Array<{
      id: string;
      prompt: string;
      helpText?: string;
      selectionMode: "single" | "multi";
      required: boolean;
      options: Array<{
        id: string;
        label: string;
        description?: string;
        freeText?: boolean;
      }>;
    }>;
  };
};

/** Translate non-replayable live-input expirations into one durable interaction. */
export function runtimeQuestionFallbackFromEvent(
  event: Pick<PrpEvent, "eventType" | "payload" | "runId">,
): RuntimeQuestionFallback | null {
  if (event.eventType !== "runtime_request.expired") return null;
  const payload = record(event.payload);
  if (
    !["durable_handoff", "provider_process_lost"].includes(
      String(payload.reason),
    ) ||
    payload.replayAllowed !== false
  )
    return null;
  const request = record(payload.request);
  if (
    payload.requestKind !== "runtime" ||
    payload.requestType !== "input" ||
    request.schema !== "paperclip.runtime_request.v2" ||
    request.requestKind !== "runtime" ||
    request.type !== "input" ||
    typeof request.requestId !== "string" ||
    payload.requestId !== request.requestId ||
    typeof request.turnId !== "string" ||
    typeof request.itemId !== "string"
  )
    return null;
  let questionSet: PaperclipQuestionSet;
  try {
    questionSet = parsePaperclipQuestionSet(request.input);
  } catch {
    return null;
  }
  const questions = questionSet.questions.map((question) => ({
    id: question.id,
    prompt: question.prompt,
    ...(question.helpText ? { helpText: question.helpText } : {}),
    selectionMode:
      question.answerMode === "multi_select"
        ? ("multi" as const)
        : ("single" as const),
    required: question.required,
    options:
      question.answerMode === "text"
        ? [
            {
              id: "__paperclip_text__",
              label:
                question.textValidation?.inputType === "integer"
                  ? "Enter an integer"
                  : question.textValidation?.inputType === "number"
                    ? "Enter a number"
                    : "Enter your answer",
              freeText: true,
            },
          ]
        : (question.options ?? []).map((option) => ({
            id: option.id,
            label: option.label,
            ...(option.description ? { description: option.description } : {}),
          })),
  }));
  return {
    kind: "ask_user_questions",
    idempotencyKey: `runtime-input-durable:v1:${event.runId}:${request.requestId}`,
    sourceRunId: event.runId,
    title: questionSet.title?.slice(0, 240) ?? null,
    summary: questionSet.description?.slice(0, 1000) ?? null,
    continuationPolicy: "wake_assignee",
    payload: {
      version: 1,
      ...(questionSet.title ? { title: questionSet.title.slice(0, 240) } : {}),
      ...(questionSet.submitLabel
        ? { submitLabel: questionSet.submitLabel.slice(0, 120) }
        : {}),
      supersedeOnUserComment: false,
      runtimeRequestId: request.requestId,
      questionSet,
      questions,
    },
  };
}

/**
 * Materialize the durable replacement for a non-replayable runtime question.
 *
 * The interaction service enforces the fallback's stable idempotency key, so
 * this is safe both immediately after the event commit and while recovering an
 * exact duplicate whose original post-commit callback did not finish.
 */
export async function materializeRuntimeQuestionFallback(input: {
  db: Db;
  binding: {
    companyId: string;
    issueId: string;
    runId: string;
    agentId: string;
  };
  event: Pick<PrpEvent, "eventType" | "payload" | "runId">;
}): Promise<{
  fallback: RuntimeQuestionFallback;
  interaction: { id: string };
} | null> {
  const fallback = runtimeQuestionFallbackFromEvent(input.event);
  if (!fallback) return null;
  const interaction = await issueThreadInteractionService(input.db).create(
    {
      id: input.binding.issueId,
      companyId: input.binding.companyId,
    },
    fallback as never,
    {
      agentId: input.binding.agentId,
      runId: input.binding.runId,
      systemId: "native-runtime-question-handoff",
    },
  );
  return { fallback, interaction };
}

export function runtimeInputLifecycleMetric(
  event: Pick<PrpEvent, "eventType" | "payload">,
): {
  outcome:
    | "normalized"
    | "rejected"
    | "resolved"
    | "expired"
    | "durable_handoff"
    | "provider_loss_handoff"
    | "cancelled";
  adapter: string;
  requestId: string | null;
} | null {
  const payload = record(event.payload);
  const request = record(payload.request);
  if (
    event.eventType === "runtime_request.created" &&
    request.type === "input"
  ) {
    const origin = record(request.origin);
    return {
      outcome: "normalized",
      adapter: typeof origin.adapter === "string" ? origin.adapter : "unknown",
      requestId:
        typeof request.requestId === "string" ? request.requestId : null,
    };
  }
  if (
    event.eventType === "harness.diagnostic" &&
    payload.code === "runtime_input_rejected"
  ) {
    return {
      outcome: "rejected",
      adapter:
        typeof payload.adapter === "string" ? payload.adapter : "unknown",
      requestId: null,
    };
  }
  const terminalOutcome =
    event.eventType === "runtime_request.resolved"
      ? "resolved"
      : event.eventType === "runtime_request.expired" &&
          payload.reason === "durable_handoff"
        ? "durable_handoff"
        : event.eventType === "runtime_request.expired" &&
            payload.reason === "provider_process_lost"
          ? "provider_loss_handoff"
          : event.eventType === "runtime_request.expired"
            ? "expired"
            : event.eventType === "runtime_request.cancelled"
              ? "cancelled"
              : null;
  const requestType = payload.requestType ?? request.type;
  if (!terminalOutcome || requestType !== "input") return null;
  const origin = record(request.origin);
  return {
    outcome: terminalOutcome,
    adapter:
      typeof payload.adapter === "string"
        ? payload.adapter
        : typeof origin.adapter === "string"
          ? origin.adapter
          : "unknown",
    requestId:
      typeof payload.requestId === "string"
        ? payload.requestId
        : typeof request.requestId === "string"
          ? request.requestId
          : null,
  };
}

export function providerPlanMarkdown(payload: Record<string, unknown>): string {
  const completedMarkdown =
    typeof payload.markdown === "string" ? payload.markdown.trim() : "";
  if (completedMarkdown) return completedMarkdown.slice(0, 256_000);
  const explanation =
    typeof payload.explanation === "string" ? payload.explanation.trim() : "";
  const steps = Array.isArray(payload.steps) ? payload.steps : [];
  const lines = steps.slice(0, 256).flatMap((value) => {
    if (!value || typeof value !== "object" || Array.isArray(value)) return [];
    const step = value as Record<string, unknown>;
    const body =
      typeof step.body === "string" ? step.body.trim().slice(0, 4_000) : "";
    if (!body) return [];
    const status = step.status === "completed" ? "x" : " ";
    const suffix =
      step.status === "blocked"
        ? " _(blocked)_"
        : step.status === "in_progress"
          ? " _(in progress)_"
          : "";
    return [`- [${status}] ${body}${suffix}`];
  });
  return [explanation, lines.join("\n")]
    .filter(Boolean)
    .join("\n\n")
    .slice(0, 256_000);
}

export function semanticProviderPlanMarkdown(
  result: Record<string, unknown>,
): string | null {
  const artifacts = Array.isArray(result.artifacts) ? result.artifacts : [];
  for (const value of artifacts) {
    const artifact = record(value);
    if (
      artifact.kind !== "native_provider_plan" ||
      typeof artifact.ref !== "string"
    )
      continue;
    const match = artifact.ref.match(
      /<proposed_plan>\s*([\s\S]*?)\s*<\/proposed_plan>/i,
    );
    const completedMarkdown = match?.[1]?.trim();
    if (completedMarkdown) return completedMarkdown.slice(0, 256_000);

    const embedded = artifact.ref.match(
      /^native-provider-plan:([^\n]+)\n([\s\S]+)$/i,
    );
    if (embedded) {
      const title = embedded[1]!
        .replace(/^(?:DOT-\d+-)?/i, "")
        .replace(/-v\d+$/i, "")
        .replace(/-/g, " ")
        .trim();
      const body = embedded[2]!.trim();
      if (title && body) {
        return [`# ${title.charAt(0).toUpperCase()}${title.slice(1)}`, "", body]
          .join("\n")
          .slice(0, 256_000);
      }
    }

    if (/^\s*1\.\s+/.test(artifact.ref)) {
      const numberedPlan = artifact.ref
        .split(/\s+\|\s+(?=\d+\.\s+)/)
        .join("\n")
        .trim();
      if (numberedPlan) return `# Plan\n\n${numberedPlan}`.slice(0, 256_000);
    }

    // Some qualified Codex builds use the artifact reference itself as a
    // compact, human-readable plan. Accept only an explicitly numbered form;
    // arbitrary opaque artifact references must never become plan documents.
    const inlineNumbered = artifact.ref.trim();
    if (/\(1\)\s+.+\(2\)\s+/s.test(inlineNumbered)) {
      const body = inlineNumbered
        .replace(/^DOT-\d+\s+plan:\s*/i, "")
        .replace(/^\(1\)\s*/, "1. ")
        .replace(/;\s*\((\d+)\)\s*/g, "\n$1. ")
        .trim();
      if (body) return `# Plan\n\n${body}`.slice(0, 256_000);
    }

    const compact =
      artifact.ref.match(/^native-provider-plan:([^#]+)#(.+)$/i) ??
      artifact.ref.match(/^native-plan:\/\/[^/]+\/([^#]+)#(.+)$/i);
    if (!compact) continue;
    const humanize = (slug: string) =>
      slug
        .replace(
          /\b(GET|POST|PUT|PATCH|DELETE)-([a-z0-9][a-z0-9-]*)/gi,
          (_whole, method: string, path: string) =>
            `${method.toUpperCase()} /${path}`,
        )
        .replace(/-/g, " ")
        .replace(/\bjson\b/gi, "JSON")
        .replace(/\bapi\b/gi, "API")
        .replace(/\s+/g, " ")
        .trim();
    const title = humanize(compact[1]!.replace(/-v\d+$/i, ""));
    const steps = compact[2]!.split(";").flatMap((encoded) => {
      const parsed = encoded.match(/^\d+-(.+)$/);
      const sentence = humanize(parsed?.[1] ?? encoded);
      return sentence
        ? [sentence.charAt(0).toUpperCase() + sentence.slice(1)]
        : [];
    });
    if (!title || steps.length === 0) continue;
    return [
      `# ${title.charAt(0).toUpperCase()}${title.slice(1)}`,
      "",
      ...steps.map((step, index) => `${index + 1}. ${step}`),
    ]
      .join("\n")
      .slice(0, 256_000);
  }
  const hasNativePlanArtifact = artifacts.some(
    (value) => record(value).kind === "native_provider_plan",
  );
  const summary =
    typeof result.summary === "string" ? result.summary.trim() : "";
  const summaryPlan = hasNativePlanArtifact
    ? summary.match(
        /(?:^|:\s*)(1\)\s+[\s\S]+;\s*2\)\s+[\s\S]+;\s*3\)\s+[\s\S]+)$/,
      )
    : null;
  if (summaryPlan) {
    const body = summaryPlan[1]!
      .replace(/^1\)\s*/, "1. ")
      .replace(/;\s*(\d+)\)\s*/g, "\n$1. ")
      .trim();
    if (body) return `# Plan\n\n${body}`.slice(0, 256_000);
  }
  return null;
}

/**
 * Convert a server-owned pending interaction into the semantic wait that a
 * provider omitted. This is not a fabricated final response: it records that
 * the current turn intentionally yielded to a durable governance surface.
 */
export function nativeGovernedWaitResult(input: {
  interaction: { id: string; title: string | null; summary: string | null };
  completionContract: NativeExecutionInput["completionContract"]["contract"];
}): PrpStructuredRunResult {
  const interactionRef = `interaction:${input.interaction.id}`;
  const label =
    input.interaction.title?.trim() ||
    input.interaction.summary?.trim() ||
    "the requested response";
  return {
    schema: "paperclip.run_result.v1",
    reportedWorkDisposition: "yielded",
    summary: `Waiting for ${label}.`,
    completionClaim: {
      contractRevision: input.completionContract.revision,
      objectiveSatisfied: false,
      criteria: input.completionContract.criteria.map((criterion) => ({
        criterionId: criterion.id,
        status: "unknown",
        evidenceRefs: [interactionRef],
      })),
      remainingWork: [
        {
          description: "Resume after the durable interaction is resolved.",
          blocksCompletion: true,
        },
      ],
    },
    evidence: [{ ref: interactionRef }],
    verification: [],
    attentionRequests: [],
    artifacts: [{ kind: "issue_thread_interaction", ref: interactionRef }],
    continuation: {
      kind: "response_wake",
      summary:
        "Resume from the resolved interaction response without repeating prior work.",
      idempotencyKey: `interaction-response:${input.interaction.id}`,
    },
  };
}

/** A completed chat reply yields to the next message without claiming task completion. */
export function nativeConversationReplyResult(input: {
  conversation: boolean;
  terminalEvent: PrpEvent;
  replyEvent: PrpEvent | null;
  completionContract: NativeExecutionInput["completionContract"]["contract"];
}): PrpStructuredRunResult | null {
  const reply = input.replyEvent;
  const payload = record(reply?.payload);
  const text = typeof payload.text === "string" ? payload.text.trim() : "";
  if (!input.conversation || input.terminalEvent.eventType !== "turn.completed" ||
      !reply || reply.eventType !== "item.completed" || payload.kind !== "agentMessage" ||
      payload.channel !== "final" || !text || reply.runId !== input.terminalEvent.runId ||
      reply.turnId !== input.terminalEvent.turnId ||
      reply.normalizedSessionId !== input.terminalEvent.normalizedSessionId) return null;
  const ref = `run-event:${reply.sourceEventId}`;
  return {
    schema: "paperclip.run_result.v1",
    reportedWorkDisposition: "yielded",
    summary: text.slice(0, 12_000),
    completionClaim: {
      contractRevision: input.completionContract.revision,
      objectiveSatisfied: false,
      criteria: input.completionContract.criteria.map((criterion) => ({
        criterionId: criterion.id, status: "unknown", evidenceRefs: [ref],
      })),
      remainingWork: [],
    },
    evidence: [{ ref }],
    verification: [],
    attentionRequests: [],
    artifacts: [],
    continuation: {
      kind: "response_wake",
      summary: "Wait for the next user message in this conversation.",
      idempotencyKey: `conversation-reply:${reply.sourceEventId}`,
    },
  };
}

/**
 * Bridge an asynchronous durable-interaction lookup to the runner package's
 * synchronous governed-wait boundary. Observations are single-use and bound
 * to one exact source event so a delayed or replayed lookup cannot leak into a
 * later provider event.
 */
export function createGovernedWaitEventObservation(
  resolvePending: () => Promise<PrpStructuredRunResult | null>,
) {
  const pendingTools = new Set<string>();
  let generation = 0;
  let observation: {
    sourceInstanceId: string;
    sourceEventId: string;
    sourceSeq: number;
    result: PrpStructuredRunResult;
  } | null = null;

  return {
    async observe(event: PrpEvent, eligible: boolean): Promise<void> {
      const currentGeneration = ++generation;
      observation = null;
      const payload = record(event.payload);
      const kind = payload.kind;
      const tool = ["dynamicToolCall", "mcpToolCall", "commandExecution"].includes(String(kind));
      if (event.itemId) {
        if (tool && event.eventType === "item.started") pendingTools.add(event.itemId);
        // Terminal error events can omit kind; the tracked ID owns cleanup.
        if (event.eventType === "item.completed" || event.eventType === "item.failed") {
          pendingTools.delete(event.itemId);
        }
      }
      // Usage/model messages can arrive while the tool creating the card is
      // still awaiting its response. Parking then interrupts that in-flight
      // response and cannot produce a durable suspension checkpoint.
      if (event.eventType === "item.completed" && (
        pendingTools.size > 0 || (!tool && !(kind === "agentMessage" && payload.channel === "final"))
      )) return;
      if (!eligible) return;
      const result = await resolvePending();
      if (generation !== currentGeneration || result === null) return;
      // If the interaction is answered after this read, parking remains the
      // fail-closed outcome: the durable answer owns the response-wake path.
      // Continuing provider work on a possibly stale authorization does not.
      observation = {
        sourceInstanceId: event.sourceInstanceId,
        sourceEventId: event.sourceEventId,
        sourceSeq: event.sourceSeq,
        result,
      };
    },
    consume(event: PrpEvent): PrpStructuredRunResult | null {
      generation += 1;
      const current = observation;
      observation = null;
      if (
        current === null ||
        current.sourceInstanceId !== event.sourceInstanceId ||
        current.sourceEventId !== event.sourceEventId ||
        current.sourceSeq !== event.sourceSeq
      ) {
        return null;
      }
      return current.result;
    },
  };
}

export function nativeToolsRefreshWaitResult(input: {
  wakeId: string;
  key: string;
  completionContract: NativeExecutionInput["completionContract"]["contract"];
}): PrpStructuredRunResult {
  const ref = `wakeup:${input.wakeId}`;
  return {
    schema: "paperclip.run_result.v1",
    reportedWorkDisposition: "yielded",
    summary: "Continuing with the newly installed connection tools.",
    completionClaim: {
      contractRevision: input.completionContract.revision,
      objectiveSatisfied: false,
      criteria: input.completionContract.criteria.map((criterion) => ({
        criterionId: criterion.id,
        status: "unknown",
        evidenceRefs: [ref],
      })),
      remainingWork: [
        {
          description: "Continue in the queued session with updated tools.",
          blocksCompletion: true,
        },
      ],
    },
    evidence: [{ ref }],
    verification: [],
    attentionRequests: [],
    artifacts: [],
    continuation: {
      kind: "same_agent",
      summary: "Use the updated connection tools in a fresh session.",
      idempotencyKey: input.key,
    },
  };
}

/**
 * Partial item-verdict responses deliberately leave their original durable
 * interaction pending. They are already authority-checked before entering the
 * closed native envelope, so that exact interaction may park the continuation
 * run without requiring the model to recreate a second request.
 */
export function continuingPendingInteractionIds(
  execution: NativeExecutionInput,
): string[] {
  return execution.interactionResponses
    .filter(
      (response) =>
        response.kind === "request_item_verdicts" &&
        response.response.status === "pending",
    )
    .map((response) => response.interactionId);
}

export async function synchronizeCompletedProviderPlan(input: {
  db: Db;
  execution: NativeExecutionInput;
  event: {
    sourceEventId: string;
    turnId?: string;
    eventType: string;
    payload: Record<string, unknown>;
  };
}): Promise<PlanSynchronization | null> {
  if (
    input.event.eventType !== "plan.updated" ||
    input.event.payload.complete !== true
  )
    return null;
  if (
    !("executionMode" in input.execution) ||
    input.execution.executionMode !== "plan"
  )
    return null;
  const planningContext = input.execution.planningContext;
  if (!planningContext) return null;
  const planId =
    typeof input.event.payload.planId === "string"
      ? input.event.payload.planId
      : "";
  const providerRevision = Number.isSafeInteger(input.event.payload.revision)
    ? Number(input.event.payload.revision)
    : 0;
  const body = providerPlanMarkdown(input.event.payload);
  const digest = createHash("sha256").update(body).digest("hex");
  if (!planId || providerRevision < 1 || !body) {
    return {
      eventId: input.event.sourceEventId,
      planId,
      providerRevision,
      status: "invalid",
      baseRevisionId: planningContext.baseRevisionId,
      digest,
      documentRevision: null,
      currentRevisionId: null,
      confirmationId: null,
    };
  }
  const provenance = `runner-plan-sync:v2 run=${input.execution.binding.runId} turn=${input.event.turnId ?? "unknown"} provider=${input.execution.provider.kind} plan=${planId} revision=${providerRevision} digest=${digest}`;
  const existingRevision = await input.db
    .select({
      revisionNumber: documentRevisions.revisionNumber,
      id: documentRevisions.id,
    })
    .from(documentRevisions)
    .innerJoin(
      issueDocuments,
      eq(issueDocuments.documentId, documentRevisions.documentId),
    )
    .where(
      and(
        eq(issueDocuments.issueId, input.execution.binding.issueId),
        eq(issueDocuments.key, "plan"),
        eq(documentRevisions.changeSummary, provenance),
      ),
    )
    .orderBy(desc(documentRevisions.revisionNumber))
    .limit(1)
    .then((rows) => rows[0] ?? null);
  const documents = documentService(input.db);
  let revision = existingRevision;
  let status: PlanSynchronization["status"] = existingRevision
    ? "already_synchronized"
    : "synchronized";
  if (!revision) {
    const latest = await documents.getIssueDocumentByKey(
      input.execution.binding.issueId,
      "plan",
    );
    if (latest?.latestRevisionId && latest.body === body) {
      const sameRunRevision = await input.db
        .select({
          id: documentRevisions.id,
          revisionNumber: documentRevisions.revisionNumber,
          createdByRunId: documentRevisions.createdByRunId,
        })
        .from(documentRevisions)
        .where(eq(documentRevisions.id, latest.latestRevisionId))
        .limit(1)
        .then((rows) => rows[0] ?? null);
      if (sameRunRevision?.createdByRunId === input.execution.binding.runId) {
        revision = sameRunRevision;
        status = "already_synchronized";
      }
    }
  }
  try {
    if (!revision) {
      const write = await documents.upsertIssueDocument({
        issueId: input.execution.binding.issueId,
        key: "plan",
        title: "Plan",
        format: "markdown",
        body,
        baseRevisionId: planningContext.baseRevisionId,
        changeSummary: provenance,
        createdByAgentId: input.execution.binding.agentId,
        createdByRunId: input.execution.binding.runId,
      });
      revision = {
        revisionNumber: write.document.latestRevisionNumber,
        id: write.document.latestRevisionId!,
      };
    }
  } catch (error) {
    if (!(error instanceof HttpError) || error.status !== 409) throw error;
    const latest = await documents.getIssueDocumentByKey(
      input.execution.binding.issueId,
      "plan",
    );
    return {
      eventId: input.event.sourceEventId,
      planId,
      providerRevision,
      status: "conflict",
      baseRevisionId: planningContext.baseRevisionId,
      digest,
      documentRevision: latest?.latestRevisionNumber ?? null,
      currentRevisionId: latest?.latestRevisionId ?? null,
      confirmationId: null,
    };
  }
  const current = await documents.getIssueDocumentByKey(
    input.execution.binding.issueId,
    "plan",
  );
  if (!current || !revision?.id || current.latestRevisionId !== revision.id) {
    return {
      eventId: input.event.sourceEventId,
      planId,
      providerRevision,
      status: "conflict",
      baseRevisionId: planningContext.baseRevisionId,
      digest,
      documentRevision: current?.latestRevisionNumber ?? null,
      currentRevisionId: current?.latestRevisionId ?? null,
      confirmationId: null,
    };
  }
  let confirmationId: string;
  let confirmationPending = false;
  try {
    const confirmation = await issueThreadInteractionService(input.db).create(
      {
        id: input.execution.binding.issueId,
        companyId: input.execution.binding.companyId,
      },
      {
        kind: "request_confirmation",
        idempotencyKey: `runner-plan-approval:v1:${input.execution.binding.runId}:${planId}:${providerRevision}:${digest}`,
        sourceRunId: input.execution.binding.runId,
        title: `Review plan revision ${revision.revisionNumber}`,
        summary: "Review the synchronized Paperclip plan.",
        continuationPolicy: "wake_assignee",
        payload: {
          version: 1,
          prompt: `Approve plan revision ${revision.revisionNumber}?`,
          detailsMarkdown:
            "The completed provider plan has been synchronized to the canonical Plan document.",
          acceptLabel: "Approve plan",
          rejectLabel: "Request changes",
          rejectRequiresReason: true,
          supersedeOnUserComment: false,
          target: {
            type: "issue_document",
            issueId: input.execution.binding.issueId,
            documentId: current.id,
            key: "plan",
            revisionId: revision.id,
            revisionNumber: revision.revisionNumber,
            label: `Plan v${revision.revisionNumber}`,
          },
        },
      } as never,
      {
        agentId: input.execution.binding.agentId,
        runId: input.execution.binding.runId,
      },
    );
    confirmationId = confirmation.id;
    confirmationPending = confirmation.status === "pending";
  } catch {
    return {
      eventId: input.event.sourceEventId,
      planId,
      providerRevision,
      status: "approval_failed",
      baseRevisionId: planningContext.baseRevisionId,
      digest,
      documentRevision: revision.revisionNumber,
      currentRevisionId: revision.id,
      confirmationId: null,
    };
  }
  if (confirmationPending) {
    try {
      const currentIssue = await input.db
        .select({ status: issues.status })
        .from(issues)
        .where(eq(issues.id, input.execution.binding.issueId))
        .limit(1)
        .then((rows) => rows[0] ?? null);
      if (currentIssue && currentIssue.status !== "in_review") {
        await issueService(input.db).update(input.execution.binding.issueId, {
          status: "in_review",
          actorAgentId: input.execution.binding.agentId,
        });
      }
    } catch {
      const settledIssue = await input.db
        .select({ status: issues.status })
        .from(issues)
        .where(eq(issues.id, input.execution.binding.issueId))
        .limit(1)
        .then((rows) => rows[0] ?? null);
      if (settledIssue?.status !== "in_review") {
        return {
          eventId: input.event.sourceEventId,
          planId,
          providerRevision,
          status: "approval_failed",
          baseRevisionId: planningContext.baseRevisionId,
          digest,
          documentRevision: revision.revisionNumber,
          currentRevisionId: revision.id,
          confirmationId,
        };
      }
    }
  }
  return {
    eventId: input.event.sourceEventId,
    planId,
    providerRevision,
    status,
    baseRevisionId: planningContext.baseRevisionId,
    digest,
    documentRevision: revision.revisionNumber,
    currentRevisionId: revision.id,
    confirmationId,
  };
}

class SessionToolAuthorityEpoch {
  readonly runId: string;
  #authority: PaperclipRunnerToolAuthority;
  #revoked = false;
  #managedToolCallChain: Promise<void> = Promise.resolve();

  constructor(runId: string, authority: PaperclipRunnerToolAuthority, private readonly toolTrace?: NativeToolTrace,
    private readonly onDocumentRead?: (source: NativeDocumentToolResultSource) => Promise<void>,
    private readonly onProjectToolResult?: (source: NativeProjectToolResultSource) => Promise<void>,
    private readonly onNativeInputToolResult?: (source: NativeInputToolResultSource) => Promise<void>,
    private readonly onNativeToolCall?: (call: { tool: string; callId: string; turnId: string; argumentsHash: string; arguments: unknown }) => Promise<void>,
    private readonly onManagedOpenCodeToolResult?: (call: { tool: "read_document" | "write_document" | "create_task" | "create_project" | "self_remember" | "read_context" | "call_api" | "get_task_context" | "get_task_history" | "read_chat_attachment" | "query_business_metric"; callId: string; turnId: string; argumentsHash: string; result: unknown; contextRead?: NativeContextReadBinding; projectRead?: NativeProjectToolResultSource; projectCreate?: NativeManagedProjectCreateCapture }) => Promise<void>,
    private readonly managedContextReadCapture?: { value: NativeContextReadBinding | null },
    private readonly serializeManagedOperation?: <T>(operation: () => Promise<T>) => Promise<T>) {
    this.runId = runId;
    this.#authority = authority;
  }

  revoke(): void {
    this.#revoked = true;
  }

  #assertCurrent(): void {
    if (this.#revoked) {
      throw new Error("native_tool_authority_epoch_revoked");
    }
  }

  definitions() {
    this.#assertCurrent();
    return this.#authority.definitions();
  }

  async execute(call: Parameters<PaperclipRunnerToolAuthority["execute"]>[0] & { turnId?: string }) {
    this.#assertCurrent();
    const phaseTool = ["self_remember", "read_context"].includes(call.tool) ? call.tool : "other";
    const phaseEnabled = process.env.PAPERCLIP_NATIVE_CONTEXT_PHASE_DIAGNOSTICS === "1";
    const phaseStart = phaseEnabled ? performance.now() : 0;
    let phasePrevious = phaseStart;
    const markPhase = (phase: string) => {
      if (!phaseEnabled) return;
      const now = performance.now();
      console.error("native_tool_source_phase_counts", JSON.stringify({ tool: phaseTool, phase,
        elapsedMs: now - phasePrevious, totalMs: now - phaseStart }));
      phasePrevious = now;
    };
    const execute = async () => {
      markPhase("queue_wait");
      this.#assertCurrent();
      const toolResultDiagnostics = process.env.PAPERCLIP_NATIVE_TEST_TOOL_RESULT_DIAGNOSTICS === "1";
      const reportContextToolFailure = (event: string, error: unknown) => {
        if (process.env.PAPERCLIP_MANAGED_OPENCODE_E2E_DIAGNOSTICS !== "1" || call.tool !== "get_task_context") return;
        const diagnostic = error && typeof error === "object"
          ? error as Error & { code?: unknown; status?: unknown; statusCode?: unknown; cause?: { code?: unknown } } : null;
        const safeCode = (value: unknown) => typeof value === "string" && /^[A-Z0-9_:-]{1,100}$/i.test(value) ? value : null;
        const frames = diagnostic?.stack?.split("\n").slice(1).flatMap(frame => {
          const match = /server\/src\/services\/([^\s():]+\.ts):(\d+):\d+/.exec(frame);
          return match ? [`${match[1]}:${match[2]}`] : [];
        }).slice(0, 5) ?? [];
        console.error(event, JSON.stringify({ name: diagnostic?.name ?? "UnknownError",
          code: safeCode(diagnostic?.code), causeCode: safeCode(diagnostic?.cause?.code),
          status: typeof diagnostic?.status === "number" ? diagnostic.status :
            typeof diagnostic?.statusCode === "number" ? diagnostic.statusCode : null, frames }));
      };
      const reportCreateTaskFailure = (event: string, error: unknown) => {
        const managedProjectApiCall = call.tool === "call_api" && projectCreateCapture?.value !== null &&
          projectCreateCapture?.value !== undefined;
        if (!toolResultDiagnostics || (!managedProjectApiCall && !["create_task", "create_project"].includes(call.tool))) return;
        const diagnostic = error && typeof error === "object"
          ? error as Error & { code?: unknown; status?: unknown; statusCode?: unknown; cause?: { code?: unknown; constraint_name?: unknown } } : null;
        const safeCode = (value: unknown) => typeof value === "string" && /^[A-Z0-9_:-]{1,100}$/i.test(value) ? value : null;
        const frames = diagnostic?.stack?.split("\n").slice(1).flatMap(frame => {
          const match = /server\/src\/services\/([^\s():]+\.ts):(\d+):\d+/.exec(frame);
          return match ? [`${match[1]}:${match[2]}`] : [];
        }).slice(0, 5) ?? [];
        console.error(event, JSON.stringify({ name: diagnostic?.name ?? "UnknownError",
          code: safeCode(diagnostic?.code), causeCode: safeCode(diagnostic?.cause?.code),
          causeConstraint: safeCode(diagnostic?.cause?.constraint_name),
          status: typeof diagnostic?.status === "number" ? diagnostic.status :
            typeof diagnostic?.statusCode === "number" ? diagnostic.statusCode : null, frames }));
      };
      if (toolResultDiagnostics && call.tool === "create_task")
        console.error("managed_create_task_callback_test_facts", JSON.stringify({
          turnIdPresent: typeof call.turnId === "string" && call.turnId.length > 0,
          nativeToolCallCallbackPresent: typeof this.onNativeToolCall === "function",
          managedResultCallbackPresent: typeof this.onManagedOpenCodeToolResult === "function",
        }));
      const argumentsHash = nativeSha256(call.arguments);
      if (this.onManagedOpenCodeToolResult && (call.tool === "call_api" || call.tool === "create_project" || call.tool === "get_task_context" ||
        call.tool === "get_task_history" || call.tool === "read_chat_attachment" || call.tool === "query_business_metric") && !call.turnId)
        throw new Error("managed_opencode_tool_call_source_binding_invalid");
      if (call.turnId) {
        try {
          await this.onNativeToolCall?.({ tool: call.tool, callId: call.callId,
            turnId: call.turnId, argumentsHash, arguments: call.arguments });
        } catch (error) {
          reportCreateTaskFailure("managed_create_task_dispatch_failure_test_facts", error);
          throw error;
        }
      }
      markPhase("dispatch_binding");
      const projectReadCapture: { value: NativeProjectToolResultSource | null } = { value: null };
      const projectCreateCapture: { value: NativeManagedProjectCreateCapture | null } = { value: null };
      let result: unknown;
      try {
        result = await this.#authority.execute(call, {
          onDocumentRead: this.onDocumentRead,
          onProjectToolResult: async source => {
            projectReadCapture.value = source;
            await this.onProjectToolResult?.(source);
          },
          onNativeInputToolResult: this.onNativeInputToolResult,
          onManagedProjectCreateToolResult: async capture => { projectCreateCapture.value = capture; },
          ...(call.turnId ? { nativeToolCallIdentity: { tool: call.tool, callId: call.callId, turnId: call.turnId } } : {}),
        });
      } catch (error) {
        reportContextToolFailure("managed_get_task_context_authority_failure_test_facts", error);
        reportCreateTaskFailure("managed_create_task_authority_failure_test_facts", error);
        throw error;
      }
      markPhase("authority_effect");
      if (call.turnId && (call.tool === "read_document" || call.tool === "write_document" ||
        call.tool === "create_task" || call.tool === "self_remember" || call.tool === "read_context" ||
        call.tool === "get_task_context" || call.tool === "get_task_history" || call.tool === "read_chat_attachment" || call.tool === "query_business_metric")) {
        if (toolResultDiagnostics && call.tool === "create_task")
          console.error("managed_create_task_result_callback_invoked", JSON.stringify({ turnIdPresent: true }));
        try {
          await this.onManagedOpenCodeToolResult?.({ tool: call.tool, callId: call.callId, turnId: call.turnId, argumentsHash, result,
            ...(call.tool === "read_context" && this.managedContextReadCapture?.value ? { contextRead: this.managedContextReadCapture.value } : {}) });
        } catch (error) {
          reportContextToolFailure("managed_get_task_context_result_capture_failure_test_facts", error);
          reportCreateTaskFailure("managed_create_task_result_callback_failure_test_facts", error);
          throw error;
        }
      }
      if (call.turnId && call.tool === "call_api" && (projectReadCapture.value?.source || projectCreateCapture.value))
        try {
          await this.onManagedOpenCodeToolResult?.({ tool: "call_api", callId: call.callId, turnId: call.turnId,
            argumentsHash, result,
            ...(projectReadCapture.value?.source ? { projectRead: projectReadCapture.value } : {}),
            ...(projectCreateCapture.value ? { projectCreate: projectCreateCapture.value } : {}) });
        } catch (error) {
          reportCreateTaskFailure("managed_project_api_result_callback_failure_test_facts", error);
          throw error;
        }
      if (call.turnId && call.tool === "create_project" && projectCreateCapture.value)
        try {
          await this.onManagedOpenCodeToolResult?.({ tool: "create_project", callId: call.callId, turnId: call.turnId,
            argumentsHash, result, projectCreate: projectCreateCapture.value });
        } catch (error) {
          reportCreateTaskFailure("managed_create_project_result_callback_failure_test_facts", error);
          throw error;
        }
      else if (call.turnId && call.tool === "create_project" && this.onManagedOpenCodeToolResult)
        throw new Error("managed_opencode_tool_result_binding_invalid");
      markPhase("result_capture");
      return result;
    };
    const run = async () => {
      try { return await (this.toolTrace ? this.toolTrace.execute(call, execute) : execute()); }
      finally { markPhase("trace_and_return"); }
    };
    let result: unknown;
    if (this.onManagedOpenCodeToolResult) {
      // OpenCode may dispatch parallel tool calls from one assistant message.
      // The source capture is mutable server state on this authority; serialize
      // the entire verify/effect/receipt path so one call cannot inherit the
      // next call's exact provider arguments or source set.
      if (this.serializeManagedOperation) result = await this.serializeManagedOperation(run);
      else {
        const pending = this.#managedToolCallChain.then(run, run);
        this.#managedToolCallChain = pending.then(() => undefined, () => undefined);
        result = await pending;
      }
    } else result = await run();
    if (call.tool === "read_document") this.#assertCurrent();
    return result;
  }
}

/** Runner diagnostics are best-effort output, but a failed current-source
 * check must still fence tools and stop the session. The onLog owner also
 * records the durable source-loss cancellation; this is the in-memory runner
 * stop needed to prevent another provider action while that settles. */
export function createRunnerDiagnosticLogSink(input: {
  runId: string;
  onLog?: (stream: "stdout" | "stderr", chunk: string) => Promise<void>;
  revokeToolAuthority: () => void;
  cancelSession?: (runId: string, reason: string) => Promise<unknown>;
}) {
  let cancellation: Promise<void> | null = null;
  let failedClosed = false;
  const failClosed = () => {
    if (failedClosed) return;
    failedClosed = true;
    input.revokeToolAuthority();
    if (!cancellation) {
      cancellation = Promise.resolve()
        .then(() => (input.cancelSession ?? cancelNativeSession)(input.runId, "Runner diagnostic output authorization failed"))
        .then(() => undefined, () => undefined);
    }
  };
  return (chunk: string) => {
    try {
      const delivery = input.onLog?.("stderr", chunk);
      if (delivery) void Promise.resolve(delivery).catch(failClosed);
    } catch {
      failClosed();
    }
  };
}

const sessionToolAuthorityEpochs = new Map<string, SessionToolAuthorityEpoch>();
const initializingSessionToolAuthorities = new Set<string>();
const executingRunnerdSessionScopes = new Map<string, string>();

function nativeSessionKey(execution: NativeExecutionInput): string {
  return (
    execution.session.normalizedSessionId ??
    `session-${execution.binding.runId}`
  );
}

function managedOpenCodeRuntimeDataIsolated(execution: NativeExecutionInput, environment: NodeJS.ProcessEnv) {
  return execution.provider.kind === "opencode" &&
    typeof environment.PAPERCLIP_MANAGED_MODEL_BROKER_ORIGIN === "string" &&
    environment.PAPERCLIP_MANAGED_MODEL_BROKER_ORIGIN.trim().length > 0;
}

async function persistRemoteNativeRuntimeAssetLocator(input: {
  db: Db;
  locator: RemoteRuntimeAssetLocator;
  normalizedSessionId: string;
  runnerInstanceId: string;
  remoteCwd: string;
}) {
  await input.db.transaction(async rawTx => {
    const tx = rawTx as unknown as Db;
    const [run] = await tx.select({
      id: heartbeatRuns.id,
      companyId: heartbeatRuns.companyId,
      status: heartbeatRuns.status,
      runtimeMode: heartbeatRuns.runtimeMode,
      driverKind: heartbeatRuns.driverKind,
      nativeSessionId: heartbeatRuns.nativeSessionId,
      runnerInstanceId: heartbeatRuns.runnerInstanceId,
      runnerProfileJson: heartbeatRuns.runnerProfileJson,
    }).from(heartbeatRuns).where(and(
      eq(heartbeatRuns.companyId, input.locator.companyId),
      eq(heartbeatRuns.id, input.locator.runId),
      eq(heartbeatRuns.status, "running"),
      eq(heartbeatRuns.runtimeMode, "native"),
      eq(heartbeatRuns.driverKind, "opencode_server"),
    )).for("update");
    const [lease] = await tx.select({
      id: environmentLeases.id,
      environmentId: environmentLeases.environmentId,
      heartbeatRunId: environmentLeases.heartbeatRunId,
      provider: environmentLeases.provider,
      providerLeaseId: environmentLeases.providerLeaseId,
      status: environmentLeases.status,
      expiresAt: environmentLeases.expiresAt,
      metadata: environmentLeases.metadata,
    }).from(environmentLeases).where(and(
      eq(environmentLeases.companyId, input.locator.companyId),
      eq(environmentLeases.id, input.locator.environmentLeaseId),
    )).for("update");
    const metadata = lease?.metadata && typeof lease.metadata === "object" && !Array.isArray(lease.metadata)
      ? lease.metadata as Record<string, unknown> : {};
    const profile = record(run?.runnerProfileJson);
    const previous = profile.nativeRemoteRuntimeAssetLocator;
    if (!run || run.nativeSessionId !== input.normalizedSessionId ||
      run.runnerInstanceId !== input.runnerInstanceId ||
      !lease || lease.heartbeatRunId !== run.id || lease.environmentId !== input.locator.environmentId ||
      lease.provider !== input.locator.provider || lease.providerLeaseId !== input.locator.providerLeaseId ||
      lease.status !== "active" || !lease.expiresAt || lease.expiresAt <= new Date() ||
      typeof metadata.remoteCwd !== "string" || metadata.remoteCwd.trim() !== input.remoteCwd ||
      !isRemoteRuntimeAssetLocator(input.locator, { companyId: run?.companyId ?? "", runId: run?.id ?? "" }) ||
      (previous !== undefined && (!isRemoteRuntimeAssetLocator(previous, { companyId: run?.companyId ?? "", runId: run?.id ?? "" }) ||
        remoteRuntimeAssetLocatorDigest(previous) !== remoteRuntimeAssetLocatorDigest(input.locator)))) {
      throw new Error("native_remote_runtime_asset_locator_binding_invalid");
    }
    if (previous === undefined) {
      await tx.update(heartbeatRuns).set({
        runnerProfileJson: { ...profile, nativeRemoteRuntimeAssetLocator: input.locator },
        updatedAt: new Date(),
      }).where(and(
        eq(heartbeatRuns.companyId, run.companyId),
        eq(heartbeatRuns.id, run.id),
        eq(heartbeatRuns.status, "running"),
      ));
    }
  });
}

function nativeSessionWorkspaceScope(execution: NativeExecutionInput) {
  // Projectless local runs use the heartbeat run id as a durable placeholder
  // rather than fabricating an execution_workspaces row. Do not let that
  // per-run placeholder break continuity for the same provider session; the
  // immutable workspace descriptor is the stable identity in that case.
  const transientWorkspace =
    execution.binding.executionWorkspaceId === execution.binding.runId;
  return transientWorkspace
    ? {
        kind: "transient" as const,
        cwd: execution.workspace.cwd,
        repoUrl: execution.workspace.repoUrl,
        repoRef: execution.workspace.repoRef,
        branchName: execution.workspace.branchName,
      }
    : {
        kind: "managed" as const,
        executionWorkspaceId: execution.binding.executionWorkspaceId,
      };
}

function nativeProviderSessionScope(execution: NativeExecutionInput) {
  switch (execution.provider.kind) {
    case "aw_text_only":
      return { kind: "aw_text_only", profileId: execution.provider.profileId };
    case "claude_managed":
      return {
        kind: execution.provider.kind,
        profileId: execution.provider.managedProfile.profileId,
      };
    case "aws_agentcore":
      return {
        kind: execution.provider.kind,
        profileId: execution.provider.agentCoreProfile.profileId,
      };
    case "acpx":
      return {
        kind: execution.provider.kind,
        agent: execution.provider.agent,
        profile: execution.provider.profile,
      };
    case "codex":
    case "opencode":
      // These local providers have no separate persisted profile id. Company,
      // agent, and workspace bind their credential/session context; mutable
      // model and permission settings remain in nativeSessionConfigDigest so
      // they rotate an incompatible warm session within the same scope.
      return { kind: execution.provider.kind };
  }
}

function nativeSessionScopeKey(execution: NativeExecutionInput): string {
  return canonicalJson({
    schema: "paperclip.native-session-scope.v2",
    companyId: execution.binding.companyId,
    agentId: execution.binding.agentId,
    workspace: nativeSessionWorkspaceScope(execution),
    provider: {
      driverKind: execution.session.driverKind,
      identity: nativeProviderSessionScope(execution),
    },
    normalizedSessionId: nativeSessionKey(execution),
  });
}

function legacyCompanyNativeSessionScopeKey(
  execution: NativeExecutionInput,
): string {
  return JSON.stringify([
    execution.binding.companyId,
    nativeSessionKey(execution),
  ]);
}

function runnerdStateBase(): string {
  return (
    process.env.PAPERCLIP_RUNNER_STATE_DIR ??
    resolve(
      resolvePaperclipInstanceRoot(),
      "runtime",
      "paperclip-runner",
      "durable-sessions",
    )
  );
}

function scopedRunnerdStateRoot(execution: NativeExecutionInput): string {
  return resolve(
    runnerdStateBase(),
    createHash("sha256").update(nativeSessionScopeKey(execution)).digest("hex"),
  );
}

function scrubRunnerdQuarantineLaunchState(root: string): void {
  const codexHome = resolve(root, "codex-home");
  const codexHomeStats = lstatSync(codexHome, { throwIfNoEntry: false });
  if (!codexHomeStats) return;
  if (!codexHomeStats.isDirectory() || codexHomeStats.isSymbolicLink()) {
    throw new Error("runner_state_directory_unsafe");
  }
  for (const name of CODEX_HOME_NON_PERSISTENT_ENTRIES) {
    const entry = resolve(codexHome, name);
    const stats = lstatSync(entry, { throwIfNoEntry: false });
    if (!stats) continue;
    // Remove symlinks themselves, never their targets. Real temporary
    // directories are safe to remove recursively inside the verified home.
    rmSync(entry, {
      recursive: stats.isDirectory() && !stats.isSymbolicLink(),
      force: true,
    });
  }
}

function quarantineRunnerdStateRoot(
  root: string,
  reason: "identity_indeterminate" | "identity_mismatch",
): string {
  const stateBase = resolve(runnerdStateBase());
  const resolvedRoot = resolve(root);
  const stateKey = basename(resolvedRoot);
  // Callers pass only roots derived by this module. Keep that boundary explicit
  // so a future call site cannot turn quarantine into an arbitrary filesystem
  // move, and never follow or move a symlink in place of the state directory.
  if (
    dirname(resolvedRoot) !== stateBase ||
    !/^[a-f0-9]{64}$/.test(stateKey) ||
    !isSafeNativeStateDirectory(resolvedRoot)
  ) {
    throw new Error("runner_state_directory_unsafe");
  }
  // Quarantine retains durable session history for diagnosis and recovery, but
  // launch credentials and transient files are re-materializable and must not
  // survive after this state loses authority.
  scrubRunnerdQuarantineLaunchState(resolvedRoot);
  const quarantineRoot = resolve(stateBase, "quarantine");
  mkdirSync(quarantineRoot, { recursive: true, mode: 0o700 });
  if (!isSafeNativeStateDirectory(quarantineRoot)) {
    throw new Error("runner_state_directory_unsafe");
  }
  const destination = resolve(
    quarantineRoot,
    `${stateKey}.${reason}.${Date.now()}.${process.pid}.${randomUUID()}`,
  );
  renameSync(resolvedRoot, destination);
  return destination;
}

function legacyCompanyRunnerdStateRoot(
  execution: NativeExecutionInput,
): string {
  return resolve(
    runnerdStateBase(),
    createHash("sha256")
      .update(legacyCompanyNativeSessionScopeKey(execution))
      .digest("hex"),
  );
}

function legacyRunnerdStateRoot(execution: NativeExecutionInput): string {
  return resolve(
    runnerdStateBase(),
    createHash("sha256").update(nativeSessionKey(execution)).digest("hex"),
  );
}

function migrateLegacyRunnerdStateRoot(input: {
  legacy: string;
  scoped: string;
  execution: NativeExecutionInput;
  verifiedPriorRunId?: string;
}): string | null {
  if (!existsSync(input.legacy)) return null;
  if (!isSafeNativeStateDirectory(input.legacy)) {
    throw new Error("runner_state_directory_unsafe");
  }
  const legacyIdentity = readRunnerdDurableIdentity(input.legacy);
  const exactRun = durableIdentityMatchesExecution(
    legacyIdentity,
    input.execution,
  );
  const verifiedSettledPriorRun = Boolean(
    input.verifiedPriorRunId &&
    legacyIdentity?.runId === input.verifiedPriorRunId &&
    durableIdentityMatchesSession(legacyIdentity, input.execution),
  );
  if (!exactRun && !verifiedSettledPriorRun) {
    // A legacy path does not encode the full session scope. A mismatch may be
    // valid live state owned by another agent/workspace, so refusing the claim
    // is safe but moving that ambiguous directory is not.
    throw new Error("runner_state_identity_mismatch");
  }
  if (
    exactRun &&
    legacyIdentity &&
    ["absent", "indeterminate"].includes(
      runnerdAuthorityLifecycle(
        input.legacy,
        legacyIdentity as RunnerdDurableIdentity,
      ),
    )
  ) {
    quarantineRunnerdStateRoot(input.legacy, "identity_indeterminate");
    throw new Error("runner_state_identity_mismatch");
  }
  try {
    renameSync(input.legacy, input.scoped);
  } catch (error) {
    // Another in-process recovery may have won the atomic rename. The scoped
    // directory is authoritative once it exists; otherwise preserve the
    // original migration failure rather than silently starting empty state.
    if (!isSafeNativeStateDirectory(input.scoped)) throw error;
    const scopedIdentity = readRunnerdDurableIdentity(input.scoped);
    const exactScopedRun = durableIdentityMatchesExecution(
      scopedIdentity,
      input.execution,
    );
    const sameVerifiedPriorRun = Boolean(
      input.verifiedPriorRunId &&
      scopedIdentity &&
      scopedIdentity.runId === input.verifiedPriorRunId &&
      scopedIdentity.runnerInstanceId === legacyIdentity?.runnerInstanceId &&
      scopedIdentity.environmentLeaseId ===
        legacyIdentity?.environmentLeaseId &&
      durableIdentityMatchesSession(scopedIdentity, input.execution),
    );
    if (!exactScopedRun && !sameVerifiedPriorRun) {
      throw new Error("runner_state_identity_mismatch");
    }
  }
  return input.scoped;
}

function runnerdAuthorityLifecycle(
  root: string,
  identity: RunnerdDurableIdentity,
): "absent" | "suspended" | "not_suspended" | "indeterminate" {
  const runnerRoot = resolve(root, "runner");
  if (!existsSync(runnerRoot)) return "absent";
  if (!isSafeNativeStateDirectory(runnerRoot)) return "indeterminate";
  const statePath = resolve(runnerRoot, "runner-state.json");
  if (!existsSync(statePath)) {
    try {
      // Older remote transports created this controller-side placeholder even
      // though runner state was owned by the sandbox. It carries no authority,
      // so a verified failover backup may be consulted. Any non-empty direct
      // directory remains indeterminate and therefore blocks fallback.
      return readdirSync(runnerRoot).length === 0 ? "absent" : "indeterminate";
    } catch {
      return "indeterminate";
    }
  }
  try {
    const state = record(
      JSON.parse(
        readBoundedNativeFile(
          statePath,
          NATIVE_RUNNER_STATE_MAX_BYTES,
          "runner_state_too_large",
        ).toString("utf8"),
      ),
    );
    if (
      state.schema !== RUNNERD_STATE_SCHEMA ||
      typeof state.lifecycle !== "string" ||
      !RUNNERD_STATE_LIFECYCLES.has(state.lifecycle)
    ) {
      return "indeterminate";
    }
    if (
      state.runnerInstanceId === identity.runnerInstanceId &&
      state.environmentLeaseId === identity.environmentLeaseId &&
      state.runId === identity.runId &&
      state.normalizedSessionId === identity.normalizedSessionId
    ) {
      if (state.lifecycle === "suspended") return "suspended";
      return "not_suspended";
    }
    return "indeterminate";
  } catch {
    return "indeterminate";
  }
}

function runnerdAuthorityLifecycleWithVerifiedBackup(input: {
  root: string;
  identity: RunnerdDurableIdentity;
  execution: NativeExecutionInput;
  allowVerifiedBackup: boolean;
}): "suspended" | "not_suspended" | "indeterminate" {
  const direct = runnerdAuthorityLifecycle(input.root, input.identity);
  if (direct !== "absent") return direct;
  if (!input.allowVerifiedBackup) return "indeterminate";
  const backup = verifyNativeHarnessBackup({
    root: input.root,
    execution: input.execution,
    runnerInstanceId: input.identity.runnerInstanceId,
  });
  if (!backup) return "indeterminate";
  const backupLifecycle = runnerdAuthorityLifecycle(
    backup.root,
    input.identity,
  );
  return backupLifecycle === "absent" ? "indeterminate" : backupLifecycle;
}

type PriorRunnerdStateVerification =
  | "verified"
  | "retained_warm_runner"
  | "active"
  | "authority_indeterminate"
  | "scope_mismatch"
  | "terminal_state_indeterminate"
  | "unavailable";

const CLEANUP_CANONICAL_FILES = [
  "control-plane/control-plane-state.json",
  "runner/runner-state.json",
  "runner/codex-provider-state.json",
] as const;
const CLEANUP_ACTIVATION_FILE = "cleanup-activation.json";

function cleanupStateSnapshot(root: string, providerFile = "codex-provider-state.json") {
  if (
    ![root, resolve(root, "runner"), resolve(root, "control-plane")].every(
      isSafeNativeStateDirectory,
    )
  ) {
    throw new Error("native_cleanup_maintenance_unproven");
  }
  const files = [...CLEANUP_CANONICAL_FILES.slice(0, 2), `runner/${providerFile}`];
  const bytes = files.map((file) =>
    readBoundedNativeFile(
      resolve(root, file),
      NATIVE_RUNNER_STATE_MAX_BYTES,
      "native_cleanup_maintenance_unproven",
    ),
  );
  const [control, runner, provider] = bytes.map((value) =>
    record(JSON.parse(value.toString("utf8"))),
  );
  const fileSha256 = bytes.map((value) =>
    createHash("sha256").update(value).digest("hex"),
  ) as [string, string, string];
  return {
    control: control!,
    runner: runner!,
    provider: provider!,
    fileSha256,
    fingerprint: createHash("sha256")
      .update(JSON.stringify(fileSha256))
      .digest("hex"),
  };
}

function cleanupProcessAbsent(pid: unknown): pid is number {
  if (
    process.platform === "win32" ||
    !Number.isSafeInteger(pid) ||
    Number(pid) <= 0
  )
    return false;
  return [Number(pid), -Number(pid)].every((target) => {
    try {
      process.kill(target, 0);
      return false;
    } catch (error) {
      return (error as NodeJS.ErrnoException).code === "ESRCH";
    }
  });
}

function cleanupCanonicalVacancy(root: string) {
  const stat = lstatSync(root, { throwIfNoEntry: false });
  if (!stat) return null;
  if (!isSafeNativeStateDirectory(root) || readdirSync(root).length !== 0) {
    throw new Error("native_cleanup_maintenance_unproven");
  }
  return {
    device: stat.dev,
    inode: stat.ino,
    mode: stat.mode,
    modifiedAt: stat.mtimeMs,
  };
}

function cleanupArchiveRootIdentity(root: string) {
  if (!isSafeNativeStateDirectory(root))
    throw new Error("native_cleanup_maintenance_unproven");
  const stat = lstatSync(root);
  return { device: stat.dev, inode: stat.ino, mode: stat.mode };
}

/** Raw runner events and normalized driver events are distinct streams. Bind
 * the retained raw journal to the server-accepted result, not a guessed shared
 * event identifier. This is read-only and never interprets a tool as a request. */
export function retainedNativeCleanupJournalMatches(input: {
  run: Pick<
    typeof heartbeatRuns.$inferSelect,
    | "id"
    | "companyId"
    | "agentId"
    | "nativeIssueId"
    | "nativeSessionId"
    | "runnerInstanceId"
    | "completionContractId"
    | "completionContractSha256"
  >;
  execution: NativeExecutionInput;
  accepted: Pick<
    typeof nativeRunResults.$inferSelect,
    | "schemaStatus"
    | "resultJson"
    | "turnId"
    | "canonicalSha256"
    | "serverFingerprint"
  >;
  control: Record<string, unknown>;
  providerSessionId: string;
  providerAccountSessionId?: string | null;
  persistedEvents: Array<
    Pick<
      typeof heartbeatRunEvents.$inferSelect,
      | "eventType"
      | "payload"
      | "sourceInstanceId"
      | "sourceEventId"
      | "sourceSeq"
      | "sourcePayloadSha256"
    >
  >;
}): boolean {
  const { run, accepted, control } = input;
  const envelope = record(accepted.resultJson);
  const terminal = record(envelope.terminal);
  if (
    accepted.schemaStatus !== "accepted" ||
    !accepted.turnId ||
    terminal.turnTerminalState !== "completed" ||
    terminal.runTerminalState !== "succeeded" ||
    !Array.isArray(control.committedEvents) ||
    !Array.isArray(control.commands)
  )
    return false;
  const canonical = {
    result: envelope.result,
    terminal: envelope.terminal,
    turnId: accepted.turnId,
  };
  const fingerprint = nativeSha256({
    runId: run.id,
    completionContractSha256: run.completionContractSha256,
    canonicalSha256: accepted.canonicalSha256,
  });
  const validPersisted = input.persistedEvents.filter((row) => {
    const parsed = validatePrpEvent(record(row.payload).prpEvent);
    return (
      parsed.ok &&
      parsed.event.runId === run.id &&
      parsed.event.normalizedSessionId === run.nativeSessionId &&
      parsed.event.sourceInstanceId === row.sourceInstanceId &&
      parsed.event.sourceEventId === row.sourceEventId &&
      parsed.event.sourceSeq === row.sourceSeq &&
      row.sourcePayloadSha256 === nativeSha256(parsed.event)
    );
  });
  const identities = validPersisted.filter(
    (row) =>
      ["session.started", "session.resumed"].includes(row.eventType) &&
      row.sourceInstanceId === run.runnerInstanceId,
  );
  if (identities.length !== 1) return false;
  const identityEvent = record(record(identities[0]!.payload).prpEvent);
  const identityPayload = record(identityEvent.payload);
  if (
    identityPayload.providerSessionId !==
      (input.providerAccountSessionId ?? input.providerSessionId) ||
    identityPayload.driverSessionId !== input.providerSessionId ||
    identityEvent.sourceKind !== "runner" ||
    identityEvent.eventType !== identities[0]!.eventType ||
    identityEvent.sourceEventId !==
      `${run.runnerInstanceId}:${run.id}:${identityEvent.sourceSeq}`
  )
    return false;
  const boundDigest = validPersisted.some((row) => {
    const event = record(record(row.payload).prpEvent);
    return (
      event.sourceKind === "control_plane" &&
      nativeSha256({
        binding: {
          companyId: run.companyId,
          issueId: run.nativeIssueId,
          agentId: run.agentId,
          runId: run.id,
          sessionId: run.nativeSessionId,
          sourceInstanceId: run.runnerInstanceId,
          controlPlaneSourceInstanceId: row.sourceInstanceId,
          completionContractId: run.completionContractId,
          completionContractSha256: run.completionContractSha256,
        },
        ...canonical,
      }) === accepted.canonicalSha256
    );
  });
  if (!(
    (accepted.canonicalSha256 === `sha256:${nativeSha256(canonical)}` &&
      accepted.serverFingerprint === `sha256:${fingerprint}`) ||
    (accepted.serverFingerprint === fingerprint && boundDigest)
  ))
    return false;
  const events = control.committedEvents.map((entry) =>
    record(record(record(entry).envelope).payload),
  );
  const durableIdentity = record(control.identity);
  const boundRaw = (event: Record<string, unknown>) =>
    validatePrpEvent(event).ok &&
    event.runId === run.id &&
    event.sourceInstanceId === run.runnerInstanceId &&
    event.sourceKind === "runner" &&
    event.normalizedSessionId === run.nativeSessionId &&
    event.turnId === durableIdentity.turnId &&
    event.itemId === durableIdentity.itemId;
  const commands = control.commands.map(record);
  const contract = input.execution.completionContract.contract;
  if (
    !commands.some(
      (command) =>
        ["run.prepare", "run.attach"].includes(String(command.type)) &&
        command.status === "completed" &&
        canonicalJson(record(command.payload).completionContract) ===
          canonicalJson({
            revision: contract.revision,
            criterionIds: contract.criteria.map((criterion) => criterion.id),
          }),
    )
  )
    return false;
  if (
    !commands.some(
      (command) =>
        command.type === "turn.start" &&
        command.status === "completed" &&
        record(record(command.result).result).providerTurnId ===
          accepted.turnId,
    )
  )
    return false;
  if (
    !events.some(
      (event) =>
        event.eventType === "turn.accepted" &&
        boundRaw(event) &&
        record(event.payload).providerTurnId === accepted.turnId &&
        record(event.payload).providerSessionId === input.providerSessionId,
    )
  )
    return false;
  const submissions = events.filter(
    (event) =>
      event.eventType === "semantic_tool.input" &&
      record(event.payload).semantic_tool &&
      record(record(event.payload).semantic_tool).operationId ===
        "paperclip_finish",
  );
  if (submissions.length !== 1) return false;
  const event = submissions[0]!;
  const semantic = record(record(event.payload).semantic_tool);
  const correlation = record(semantic.correlation);
  const result = validatePrpStructuredRunResult(semantic.input);
  if (
    !boundRaw(event) ||
    !result.ok ||
    canonicalJson(result.result) !== canonicalJson(envelope.result) ||
    semantic.schema !== "paperclip.prp.semantic_tool.v1" ||
    semantic.schemaVersion !== 1 ||
    semantic.phase !== "input" ||
    typeof semantic.callId !== "string" ||
    !semantic.callId ||
    record(semantic.content).digest !==
      `sha256:${nativeSha256(semantic.input)}` ||
    event.runId !== run.id ||
    event.sourceInstanceId !== run.runnerInstanceId ||
    event.normalizedSessionId !== run.nativeSessionId ||
    correlation.runId !== run.id ||
    correlation.normalizedSessionId !== run.nativeSessionId ||
    correlation.turnId !== event.turnId ||
    correlation.itemId !== event.itemId
  )
    return false;
  return (
    events.some((candidate) => {
      const outcome = record(record(candidate.payload).semantic_tool);
      return (
        candidate.eventType === "semantic_tool.result" &&
        boundRaw(candidate) &&
        candidate.runId === run.id &&
        candidate.sourceInstanceId === run.runnerInstanceId &&
        candidate.normalizedSessionId === run.nativeSessionId &&
        outcome.schema === semantic.schema &&
        outcome.schemaVersion === 1 &&
        outcome.phase === "result" &&
        outcome.operationId === semantic.operationId &&
        outcome.callId === semantic.callId &&
        outcome.outcome === "succeeded" &&
        outcome.code === "semantic_tool_succeeded" &&
        outcome.operationReceiptId === `operation_${semantic.callId}` &&
        canonicalJson(outcome.correlation) ===
          canonicalJson(semantic.correlation)
      );
    }) &&
    commands.some((command) => {
      const payload = record(command.payload);
      return (
        command.type === "semantic_tool.result" &&
        command.status === "completed" &&
        payload.callId === semantic.callId &&
        payload.operationId === semantic.operationId &&
        payload.isError === false &&
        payload.sourceEventId === event.sourceEventId &&
        payload.sourceEventType === event.eventType &&
        canonicalJson(payload.input) === canonicalJson(semantic.input) &&
        canonicalJson(payload.correlation) ===
          canonicalJson(semantic.correlation) &&
        record(record(command.result).result).callId === semantic.callId
      );
    })
  );
}

/** Durable, content-free evidence for an authenticated maintenance event.
 * Never feed raw cleanup output into the normal driver/progress namespace. */
export async function appendRetainedNativeCleanupEvent(
  db: Db,
  input: {
    companyId: string;
    agentId: string;
    runId: string;
    nativeSessionId: string;
    runnerInstanceId: string;
    requestId: string;
    event: PrpEvent;
  },
): Promise<void> {
  const parsed = validatePrpEvent(input.event);
  if (
    !parsed.ok ||
    parsed.event.runId !== input.runId ||
    parsed.event.normalizedSessionId !== input.nativeSessionId ||
    parsed.event.sourceInstanceId !== input.runnerInstanceId ||
    parsed.event.sourceKind !== "runner" ||
    !input.requestId
  ) {
    throw new Error("native_cleanup_maintenance_unproven");
  }
  const event = parsed.event;
  const receipt = {
    schema: "paperclip.native_cleanup_event.v1",
    requestId: input.requestId,
    rawSourceInstanceId: event.sourceInstanceId,
    rawSourceEventId: event.sourceEventId,
    rawSourceSeq: event.sourceSeq,
    rawEventType: event.eventType,
    rawCanonicalSha256: nativeSha256(event),
  };
  await appendHeartbeatRunEvent(db, {
    companyId: input.companyId,
    agentId: input.agentId,
    runId: input.runId,
    eventType: "native.cleanup.event",
    stream: "system",
    level: "info",
    payload: { nativeCleanupEvent: receipt },
    nativeSource: {
      sourceInstanceId: `${input.runnerInstanceId}:cleanup:${input.requestId}`,
      sourceEventId: `cleanup:${input.requestId}:${event.sourceEventId}`,
      sourceSeq: event.sourceSeq,
      protocolSchemaVersion: 1,
      canonicalPayload: receipt,
    },
  });
}

function cleanupProviderHomeSnapshot(home: string, content: boolean) {
  const entries: Array<{
    path: string;
    directory: boolean;
    dev: number;
    ino: number;
    size: number;
    mtimeMs: number;
    ctimeMs: number;
    sha256?: string;
  }> = [];
  let bytes = 0;
  const visit = (relative: string, depth: number) => {
    if (depth > 32 || entries.length >= MAX_REMOTE_CHECKPOINT_ENTRIES)
      throw new Error("native_cleanup_maintenance_unproven");
    const path = resolve(home, relative);
    const metadata = lstatSync(path);
    if (
      metadata.isSymbolicLink() ||
      (!metadata.isFile() && !metadata.isDirectory())
    )
      throw new Error("native_cleanup_maintenance_unproven");
    const entry = {
      path: relative,
      directory: metadata.isDirectory(),
      dev: metadata.dev,
      ino: metadata.ino,
      size: metadata.isDirectory() ? 0 : metadata.size,
      mtimeMs: metadata.mtimeMs,
      ctimeMs: metadata.ctimeMs,
    };
    entries.push(entry);
    if (entry.directory) {
      const directory = opendirSync(path);
      const children: string[] = [];
      try {
        for (
          let child = directory.readSync();
          child !== null;
          child = directory.readSync()
        ) {
          if (
            !relative &&
            (CODEX_HOME_NON_PERSISTENT_ENTRIES as readonly string[]).includes(
              child.name,
            )
          )
            continue;
          if (children.length + entries.length >= MAX_REMOTE_CHECKPOINT_ENTRIES)
            throw new Error("native_cleanup_maintenance_unproven");
          children.push(child.name);
        }
      } finally {
        directory.closeSync();
      }
      for (const name of children.sort())
        visit(relative ? `${relative}/${name}` : name, depth + 1);
    } else {
      bytes += metadata.size;
      if (bytes > MAX_REMOTE_CHECKPOINT_EXPANDED_BYTES)
        throw new Error("native_cleanup_maintenance_unproven");
      if (content) {
        const value = readBoundedNativeFile(
          path,
          metadata.size,
          "native_cleanup_maintenance_unproven",
        );
        (entry as (typeof entries)[number]).sha256 = createHash("sha256")
          .update(value)
          .digest("hex");
      }
    }
    const after = lstatSync(path);
    if (
      after.dev !== metadata.dev ||
      after.ino !== metadata.ino ||
      after.mtimeMs !== metadata.mtimeMs ||
      after.ctimeMs !== metadata.ctimeMs ||
      after.size !== metadata.size
    )
      throw new Error("native_cleanup_maintenance_unproven");
  };
  visit("", 0);
  return {
    entries,
    bytes,
    metadataFingerprint: nativeSha256(
      entries.map(({ sha256: _sha, ...entry }) => entry),
    ),
    fingerprint: content
      ? nativeSha256(
          entries.map(({ path, directory, size, sha256 }) => ({
            path,
            directory,
            size,
            ...(sha256 ? { sha256 } : {}),
          })),
        )
      : null,
  };
}

function copyCleanupProviderHome(
  source: string,
  destination: string,
  snapshot: ReturnType<typeof cleanupProviderHomeSnapshot>,
) {
  for (const entry of snapshot.entries) {
    const target = resolve(destination, entry.path);
    if (entry.directory) mkdirSync(target, { mode: 0o700 });
    else {
      const value = readBoundedNativeFile(
        resolve(source, entry.path),
        entry.size,
        "native_cleanup_maintenance_unproven",
      );
      if (createHash("sha256").update(value).digest("hex") !== entry.sha256)
        throw new Error("native_cleanup_maintenance_unproven");
      writeFileSync(target, value, { flag: "wx", mode: 0o600 });
    }
  }
  if (
    cleanupProviderHomeSnapshot(source, false).metadataFingerprint !==
      snapshot.metadataFingerprint ||
    cleanupProviderHomeSnapshot(destination, true).fingerprint !==
      snapshot.fingerprint
  )
    throw new Error("native_cleanup_maintenance_unproven");
}

export function rebaseRetainedNativeCleanupProviderHome(
  home: string,
  canonicalHome: string,
  threadId: string,
  destination: "staging" | "canonical",
) {
  if (resolve(home) === resolve(canonicalHome))
    throw new Error("native_cleanup_maintenance_unproven");
  const snapshot = cleanupProviderHomeSnapshot(home, true);
  const rollouts = snapshot.entries.filter(
    (entry) =>
      !entry.directory &&
      entry.path.startsWith("sessions/") &&
      entry.path.endsWith(`-${threadId}.jsonl`),
  );
  if (rollouts.length !== 1)
    throw new Error("native_cleanup_maintenance_unproven");
  const rollout = rollouts[0]!;
  const bytes = readBoundedNativeFile(
    resolve(home, rollout.path),
    rollout.size,
    "native_cleanup_maintenance_unproven",
  );
  const newline = bytes.indexOf(10);
  if (newline < 0 || newline > 64 * 1024)
    throw new Error("native_cleanup_maintenance_unproven");
  const first = record(JSON.parse(bytes.subarray(0, newline).toString("utf8")));
  if (first.type !== "session_meta" || record(first.payload).id !== threadId)
    throw new Error("native_cleanup_maintenance_unproven");
  // Only open the NEW private copy. Codex 0.153.4 deliberately does not fall
  // back to a filesystem scan for paginated threads: SQLite selects the exact
  // immutable rollout, which can differ after thread/revert. Relocate only
  // that already-proven path, never choose another rollout or change its mode.
  const sqlite = resolve(home, "state_5.sqlite");
  if (
    snapshot.entries.some(
      (entry) =>
        /^state_\d+\.sqlite$/.test(entry.path) &&
        entry.path !== "state_5.sqlite",
    )
  )
    throw new Error("native_cleanup_maintenance_unproven");
  if (!existsSync(sqlite)) return;
  const database = new DatabaseSync(sqlite);
  try {
    database.exec("BEGIN IMMEDIATE");
    // The pinned schema has insert and timestamp-only triggers. None fire
    // for this column-only update; unknown/general update triggers deny it.
    if (
      database
        .prepare(
          "SELECT sql FROM sqlite_schema WHERE type = 'trigger' AND tbl_name COLLATE NOCASE = 'threads'",
        )
        .all()
        .some(
          (trigger) =>
            typeof trigger.sql !== "string" ||
            !/^CREATE\s+TRIGGER\s+[a-z_][a-z0-9_]*\s+AFTER\s+(?:INSERT|UPDATE\s+OF\s+(?:created_at|updated_at))\s+ON\s+threads\s/i.test(
              trigger.sql,
            ),
        )
    )
      throw new Error("native_cleanup_maintenance_unproven");
    // Foreign-key actions can also mutate other tables without an explicit
    // trigger. Unknown cascading topology is not an exact path relocation.
    if (
      database
        .prepare(
          `SELECT 1 FROM sqlite_schema AS s
           JOIN pragma_foreign_key_list(s.name) AS f
           WHERE s.type = 'table' AND f."table" COLLATE NOCASE = 'threads'
             AND f.on_update NOT IN ('NO ACTION', 'RESTRICT') LIMIT 1`,
        )
        .get()
    )
      throw new Error("native_cleanup_maintenance_unproven");
    const row = database
      .prepare("SELECT * FROM threads WHERE id = ?")
      .get(threadId);
    if (
      !row ||
      typeof row.rollout_path !== "string" ||
      ![
        resolve(home, rollout.path),
        resolve(canonicalHome, rollout.path),
      ].includes(row.rollout_path) ||
      !["legacy", "paginated"].includes(String(row.history_mode)) ||
      (record(first.payload).history_mode ?? "legacy") !== row.history_mode
    )
      throw new Error("native_cleanup_maintenance_unproven");
    const target = resolve(
      destination === "staging" ? home : canonicalHome,
      rollout.path,
    );
    if (row.rollout_path !== target) {
      const changed = database
        .prepare(
          "UPDATE threads SET rollout_path = ? WHERE id = ? AND rollout_path = ? AND history_mode = ?",
        )
        .run(target, threadId, row.rollout_path, row.history_mode);
      if (changed.changes !== 1)
        throw new Error("native_cleanup_maintenance_unproven");
    }
    const after = database
      .prepare("SELECT * FROM threads WHERE id = ?")
      .get(threadId);
    if (nativeSha256(after) !== nativeSha256({ ...row, rollout_path: target }))
      throw new Error("native_cleanup_maintenance_unproven");
    database.exec("COMMIT");
  } catch (error) {
    if (database.isTransaction) database.exec("ROLLBACK");
    throw error;
  } finally {
    database.close();
  }
}

/** Physical cleanup for an explicitly authorized NEW conversation turn. Unlike
 * automatic replacement, this does not certify or replay the interrupted actions.
 * The caller holds the issue/controller/run locks and preserves their history.
 * Retain the old durable root permanently; only the exact in-memory cleanup
 * owner is retired, and the successor must use a fresh normalized session.
 */
export async function verifyStoppedNativeSessionForContinuation(
  db: Db,
  run: typeof heartbeatRuns.$inferSelect,
): Promise<{ evidence: Record<string, unknown>; retire: () => boolean } | null> {
  try {
    if (run.runtimeMode !== "native" || !["failed", "cancelled", "interrupted", "timed_out"].includes(run.status) ||
        !run.finishedAt || !run.nativeIssueId || !run.nativeSessionId || !run.runnerInstanceId) return null;
    const execution = parseNativeExecutionInput(record(run.runnerProfileJson).nativeExecutionInput);
    if (!(["codex", "acpx"] as string[]).includes(execution.provider.kind) ||
        execution.binding.runId !== run.id || execution.binding.companyId !== run.companyId ||
        execution.binding.agentId !== run.agentId || execution.binding.issueId !== run.nativeIssueId ||
        nativeSessionKey(execution) !== run.nativeSessionId ||
        record(run.runnerProfileJson).nativeToolContractFingerprint !== nativeToolContractFingerprintForTarget("local")) return null;
    const scope = nativeSessionScopeKey(execution);
    const idle = () => !activeNativeSessions.has(run.id) && !executingRunnerdSessionScopes.has(scope) &&
      !initializingSessionToolAuthorities.has(scope) && !warmNativeSessions.has(scope);
    if (!idle()) return null;
    const leases = await db.select().from(environmentLeases).where(and(
      eq(environmentLeases.companyId, run.companyId), eq(environmentLeases.heartbeatRunId, run.id)));
    if (leases.some(lease => lease.provider !== "local" || !lease.releasedAt || lease.cleanupStatus === "failed")) return null;
    const stopped = await readNativeLocalProcessStop(db, run.companyId, run.id);
    if (!stopped) return null;
    const root = scopedRunnerdStateRoot(execution);
    const providerFile = runnerProviderStateFilename(execution);
    const snapshot = cleanupStateSnapshot(root, providerFile);
    const identity = record(snapshot.control.identity);
    if (!durableIdentityMatchesExecution(identity, execution) || identity.runnerInstanceId !== run.runnerInstanceId ||
        !["runnerInstanceId", "environmentLeaseId", "runId", "normalizedSessionId", "turnId", "itemId"].every(key =>
          typeof identity[key] === "string" && identity[key] && snapshot.runner[key] === identity[key]) ||
        !Array.isArray(snapshot.control.committedEvents)) return null;
    // An incomplete provider launch can own a process that never emitted its
    // session identity. It cannot be certified from an earlier owner's receipt.
    if (snapshot.control.schema !== "paperclip.runner.durable.control-plane-state.v1" ||
        snapshot.runner.schema !== RUNNERD_STATE_SCHEMA ||
        snapshot.provider.schema !== (execution.provider.kind === "codex" ? "paperclip.runner.codex-provider-state.v1" : ACPX_PROVIDER_STATE_SCHEMA) ||
        !["turn_active", "prepared", "suspended"].includes(String(snapshot.provider.lifecycle)) ||
        snapshot.provider.startupAttempt != null) return null;
    const pending = JSON.stringify([snapshot.runner.outbox, snapshot.provider.pendingEvents, snapshot.provider.queuedEvents]);
    if (/session\.(started|resumed|reconciled)/.test(pending)) return null;
    const events = snapshot.control.committedEvents.map(entry => record(record(record(entry).envelope).payload));
    const providerEvents = events.filter(event => ["session.started", "session.resumed", "session.reconciled"].includes(String(event.eventType)));
    if (!providerEvents.length) return null;
    const receipts = await db.select().from(heartbeatRunEvents).where(and(
      eq(heartbeatRunEvents.companyId, run.companyId), eq(heartbeatRunEvents.runId, run.id),
      eq(heartbeatRunEvents.sourceInstanceId, run.runnerInstanceId),
      inArray(heartbeatRunEvents.eventType, ["session.started", "session.resumed", "session.reconciled", "harness.diagnostic"])));
    const providerPids = new Set<number>();
    for (const event of providerEvents) {
      const provider = record(event.payload);
      if (!validatePrpEvent(event).ok || event.sourceKind !== "runner" || event.sourceInstanceId !== run.runnerInstanceId ||
          event.runId !== run.id || event.normalizedSessionId !== run.nativeSessionId ||
          typeof provider.providerSessionId !== "string" || !provider.providerSessionId ||
          !cleanupProcessAbsent(provider.processId) || provider.processId === stopped.processPid) return null;
      if (event.eventType === "session.reconciled" &&
          (!providerPids.has(Number(provider.previousProcessId)) || !cleanupProcessAbsent(provider.previousProcessId))) return null;
      const receipt = receipts.find(row => row.sourceEventId === `${run.runnerInstanceId}:${run.id}:${event.sourceSeq}`);
      const durable = record(record(receipt?.payload).prpEvent);
      const durableProvider = record(durable.payload);
      if (!receipt || !validatePrpEvent(durable).ok || durable.sourceInstanceId !== event.sourceInstanceId ||
          durable.runId !== run.id || durable.normalizedSessionId !== run.nativeSessionId ||
          // Normalized session-open receipts omit turn/item IDs. Those belong
          // to the durable runner identity checked above, not the open event.
          durable.sourceSeq !== event.sourceSeq || durable.eventType !== event.eventType ||
          receipt.sourcePayloadSha256 !== nativeSha256(durable) ||
          (durableProvider.processId !== undefined && durableProvider.processId !== provider.processId) ||
          (durableProvider.driverSessionId ?? durableProvider.providerSessionId) !== provider.providerSessionId) return null;
      providerPids.add(provider.processId);
    }
    if (receipts.filter(row => record(record(row.payload).prpEvent).eventType !== "harness.diagnostic").length !== providerEvents.length) return null;
    // ACPX's sidecar is not its agent process. Include separately recorded
    // owners from both the durable journal and the independent DB/checkpoint.
    // Extra evidence can only add a stop requirement, never waive one.
    const owners: Record<string, unknown>[] = [record(record(run.runnerProfileJson?.sessionCheckpoint).process),
      snapshot.provider, record(snapshot.provider.identity), record(snapshot.provider.descriptor)];
    for (const event of [...events, ...receipts.map(row => record(record(row.payload).prpEvent))]) {
      const payload = record(event.payload);
      if (["session.started", "session.resumed", "session.reconciled"].includes(String(event.eventType))) {
        owners.push(payload, record(payload.providerDescriptor), record(payload.providerIdentity), record(payload.runtimeIdentity));
      } else if (event.eventType === "harness.diagnostic" && payload.providerMethod === "acpx/process") {
        owners.push({ agentPid: payload.pid });
      }
    }
    for (const owner of owners) for (const key of [
      "processId", "process_id", "processGroupId", "providerPid", "codexPid", "sidecarPid", "agentPid", "agentProcessId",
    ]) {
      const pid = owner[key];
      if (pid === null || pid === undefined) continue;
      if (!cleanupProcessAbsent(pid)) return null;
      providerPids.add(pid);
    }
    const unchanged = () => idle() && cleanupProcessAbsent(stopped.processPid) &&
      [...providerPids].every(cleanupProcessAbsent) && cleanupStateSnapshot(root, providerFile).fingerprint === snapshot.fingerprint;
    return {
      evidence: { schema: "paperclip.stopped_native_conversation.v1", runId: run.id,
        nativeSessionId: run.nativeSessionId, runnerInstanceId: run.runnerInstanceId,
        processPid: stopped.processPid, providerPids: [...providerPids], stateFingerprint: snapshot.fingerprint },
      retire: () => {
        try { return unchanged() && completeTerminatedLocalNativeSessionCleanup({
          companyId: run.companyId, runId: run.id, runnerInstanceId: run.runnerInstanceId!,
        }); } catch { return false; }
      },
    };
  } catch { return null; }
}

/** Prove that a crashed local Codex turn ended without external effects. No provider
 * is launched and no retained state is rewritten. The successor must use a fresh
 * normalized session; the old directory remains available for investigation. */
export async function verifyStoppedNativeSessionForReplacement(
  db: Db,
  run: typeof heartbeatRuns.$inferSelect,
): Promise<{ evidence: Record<string, unknown>; retire: () => boolean } | null> {
  try {
    if (run.runtimeMode !== "native" || run.status !== "failed" || !run.finishedAt ||
        !run.nativeIssueId || !run.nativeSessionId || !run.runnerInstanceId) return null;
    const execution = parseNativeExecutionInput(record(run.runnerProfileJson).nativeExecutionInput);
    if (execution.provider.kind !== "codex" || execution.session.driverKind !== "codex_app_server" ||
        execution.binding.runId !== run.id || execution.binding.companyId !== run.companyId ||
        execution.binding.agentId !== run.agentId || execution.binding.issueId !== run.nativeIssueId ||
        nativeSessionKey(execution) !== run.nativeSessionId ||
        record(run.runnerProfileJson).nativeToolContractFingerprint !== nativeToolContractFingerprintForTarget("local")) return null;
    const scope = nativeSessionScopeKey(execution);
    const idle = () => !activeNativeSessions.has(run.id) && !executingRunnerdSessionScopes.has(scope) &&
      !initializingSessionToolAuthorities.has(scope) && !warmNativeSessions.has(scope);
    if (!idle()) return null;
    const leases = await db.select().from(environmentLeases).where(and(
      eq(environmentLeases.companyId, run.companyId), eq(environmentLeases.heartbeatRunId, run.id)));
    if (leases.some(lease => lease.provider !== "local" || !lease.releasedAt)) return null;
    const stopped = await readNativeLocalProcessStop(db, run.companyId, run.id);
    if (!stopped) return null;
    const root = scopedRunnerdStateRoot(execution);
    const snapshot = cleanupStateSnapshot(root);
    const identity = record(snapshot.control.identity);
    if (!durableIdentityMatchesExecution(identity, execution) || identity.runnerInstanceId !== run.runnerInstanceId ||
        !["runnerInstanceId", "environmentLeaseId", "runId", "normalizedSessionId", "turnId", "itemId"].every(key =>
          typeof identity[key] === "string" && identity[key] && snapshot.runner[key] === identity[key]) ||
        snapshot.runner.lifecycle !== "ready" || snapshot.provider.lifecycle !== "turn_active" ||
        record(snapshot.provider.config).provider !== "codex" || record(snapshot.provider.config).cwd !== execution.workspace.cwd ||
        !Array.isArray(snapshot.control.committedEvents) || !Array.isArray(snapshot.control.commands)) return null;
    const events = snapshot.control.committedEvents.map(entry => record(record(record(entry).envelope).payload));
    const providerEvent = events.filter(event => ["session.started", "session.resumed"].includes(String(event.eventType))).at(-1);
    const provider = record(providerEvent?.payload);
    const bound = (event: Record<string, unknown>) => validatePrpEvent(event).ok && event.sourceKind === "runner" &&
      event.sourceInstanceId === run.runnerInstanceId && event.runId === run.id &&
      event.normalizedSessionId === run.nativeSessionId && event.turnId === identity.turnId && event.itemId === identity.itemId;
    if (!providerEvent || !bound(providerEvent) || !cleanupProcessAbsent(provider.processId) ||
        provider.processId === stopped.processPid || typeof provider.providerSessionId !== "string" ||
        snapshot.provider.threadId !== provider.providerSessionId ||
        typeof snapshot.provider.activeProviderTurnId !== "string") return null;
    const receipts = await db.select().from(heartbeatRunEvents).where(and(
      eq(heartbeatRunEvents.companyId, run.companyId), eq(heartbeatRunEvents.runId, run.id),
      eq(heartbeatRunEvents.sourceInstanceId, run.runnerInstanceId),
      inArray(heartbeatRunEvents.eventType, ["session.started", "session.resumed"]))).limit(2);
    const receipt = receipts.length === 1 ? receipts[0] : undefined;
    const durableEvent = record(record(receipt?.payload).prpEvent);
    // The persisted adapter enriches identity payloads with driverSessionId. Bind
    // the normalized and provider identities explicitly instead of comparing raw JSON.
    const durableProvider = record(durableEvent.payload);
    if (!receipt || !validatePrpEvent(durableEvent).ok || durableEvent.runId !== run.id ||
        durableEvent.sourceInstanceId !== run.runnerInstanceId || durableEvent.normalizedSessionId !== run.nativeSessionId ||
        receipt.sourceEventId !== `${run.runnerInstanceId}:${run.id}:${durableEvent.sourceSeq}` ||
        receipt.sourcePayloadSha256 !== nativeSha256(durableEvent) ||
        (durableProvider.processId !== undefined && durableProvider.processId !== provider.processId) ||
        (durableProvider.driverSessionId ?? durableProvider.providerSessionId) !== provider.providerSessionId) return null;
    const turnId = snapshot.provider.activeProviderTurnId;
    if (!snapshot.control.commands.map(record).some(command => command.type === "turn.start" && command.status === "completed" &&
        record(record(command.result).result).providerTurnId === turnId) ||
        !events.some(event => bound(event) && event.eventType === "turn.accepted" &&
          record(event.payload).providerTurnId === turnId && record(event.payload).providerSessionId === provider.providerSessionId)) return null;
    // Completion bookkeeping may precede the final answer. Its exact accepted
    // receipt is safe to preserve; arbitrary provider tools still prevent replay.
    const completedTaskControlCalls: Array<{ callId: string; input: unknown }> = [];
    for (const event of events.filter(event => event.eventType === "semantic_tool.input")) {
      const semantic = record(record(event.payload).semantic_tool);
      const correlation = record(semantic.correlation);
      if (!bound(event) || semantic.operationId !== "paperclip_finish" || semantic.phase !== "input" ||
          typeof semantic.callId !== "string" || !validatePrpStructuredRunResult(semantic.input).ok ||
          correlation.runId !== run.id || correlation.normalizedSessionId !== run.nativeSessionId ||
          correlation.turnId !== identity.turnId || correlation.itemId !== identity.itemId ||
          record(semantic.content).digest !== `sha256:${nativeSha256(semantic.input)}` ||
          !events.some(resultEvent => {
            const result = record(record(resultEvent.payload).semantic_tool);
            return bound(resultEvent) && resultEvent.eventType === "semantic_tool.result" &&
              result.operationId === semantic.operationId && result.callId === semantic.callId &&
              result.outcome === "succeeded" && result.operationReceiptId === `operation_${semantic.callId}` &&
              canonicalJson(result.correlation) === canonicalJson(semantic.correlation);
          }) || !snapshot.control.commands.map(record).some(command => {
            const payload = record(command.payload);
            return command.type === "semantic_tool.result" && command.status === "completed" &&
              payload.callId === semantic.callId && payload.operationId === semantic.operationId &&
              payload.sourceEventId === event.sourceEventId && payload.isError === false &&
              record(payload.result).success === true && canonicalJson(payload.input) === canonicalJson(semantic.input) &&
              canonicalJson(payload.correlation) === canonicalJson(semantic.correlation);
          })) return null;
      completedTaskControlCalls.push({ callId: semantic.callId, input: semantic.input });
    }
    if (completedTaskControlCalls.length > 1) return null;
    const pendingInventory = JSON.stringify([snapshot.runner.outbox, snapshot.provider.pendingEvents, snapshot.provider.queuedEvents]);
    if (/semantic_tool\.input|mcp_app\.tool_input|runtime\.input\.requested|runtime_request\.created/.test(pendingInventory) ||
        events.some(event => ["mcp_app.tool_input", "runtime.input.requested", "runtime_request.created"].includes(String(event.eventType)))) return null;
    if (snapshot.control.commands.map(record).some(command => command.status === "pending" &&
        !["turn.stop", "runner.drain", "runner.suspend"].includes(String(command.type)))) return null;
    const home = cleanupProviderHomeSnapshot(resolve(root, "codex-home"), false);
    const rollouts = home.entries.filter(entry => !entry.directory && entry.path.startsWith("sessions/") &&
      basename(entry.path).endsWith(`-${provider.providerSessionId}.jsonl`));
    if (rollouts.length !== 1 || rollouts[0]!.size > 32 * 1024 * 1024) return null;
    const rolloutPath = resolve(root, "codex-home", rollouts[0]!.path);
    const bytes = readBoundedNativeFile(rolloutPath, 32 * 1024 * 1024, "native_crash_inventory_unproven");
    // A partial final write is not a closed transcript.
    if (!bytes.toString("utf8").endsWith("\n")) return null;
    const rows = bytes.toString("utf8").trimEnd().split("\n").map(line => JSON.parse(line));
    if (!stoppedCodexTurnIsTextOnly({ rows, threadId: provider.providerSessionId, turnId, cwd: execution.workspace.cwd, completedTaskControlCalls })) return null;
    const rolloutSha256 = nativeSha256(bytes.toString("utf8"));
    const evidence = { schema: "paperclip.stopped_text_turn.v1", runId: run.id, nativeSessionId: run.nativeSessionId,
      runnerInstanceId: run.runnerInstanceId, processPid: stopped.processPid, providerPid: provider.processId,
      providerSessionId: provider.providerSessionId, providerTurnId: turnId,
      stateFingerprint: snapshot.fingerprint, rolloutSha256,
      completedTaskControlCallIds: completedTaskControlCalls.map(call => call.callId) };
    return {
      evidence,
      retire: () => idle() && cleanupProcessAbsent(stopped.processPid) && cleanupProcessAbsent(provider.processId) &&
        cleanupStateSnapshot(root).fingerprint === snapshot.fingerprint &&
        nativeSha256(readBoundedNativeFile(rolloutPath, 32 * 1024 * 1024, "native_crash_inventory_unproven").toString("utf8")) === rolloutSha256 &&
        completeTerminatedLocalNativeSessionCleanup({ companyId: run.companyId, runId: run.id, runnerInstanceId: run.runnerInstanceId! }),
    };
  } catch { return null; }
}

/** Exact local cleanup only: the accepted result and original quarantine are
 * never rewritten. A failed/interrupted maintenance attempt is retained for
 * inspection, not retried from an older snapshot with unknown process owners. */
export async function reconcileRetainedNativeSessionCleanup(
  db: Db,
  input: {
    companyId: string;
    runId: string;
  },
): Promise<{
  status: "settled" | "not_eligible" | "operator_required";
  runId: string;
}> {
  const denied = () => new Error("native_cleanup_maintenance_unproven");
  const leaseOwner = `native-cleanup:${randomUUID()}`;
  let reservedScope: string | null = null;
  const releaseScope = () => {
    if (
      reservedScope &&
      executingRunnerdSessionScopes.get(reservedScope) === leaseOwner
    ) {
      executingRunnerdSessionScopes.delete(reservedScope);
    }
  };
  let claim: {
    execution: NativeExecutionInput;
    run: typeof heartbeatRuns.$inferSelect;
    quarantine: string;
    root: string;
    emptyRoot: ReturnType<typeof cleanupCanonicalVacancy>;
    source: ReturnType<typeof cleanupStateSnapshot>;
    providerHome: ReturnType<typeof cleanupProviderHomeSnapshot>;
    sourceArchive: {
      intent: Record<string, unknown>;
      fromCanonical: boolean;
      completed: boolean;
    } | null;
    copySource: {
      directory: string;
      snapshot: ReturnType<typeof cleanupStateSnapshot>;
      requestId: string;
    } | null;
    providerPid: number;
    providerSessionId: string;
    identity: {
      runnerInstanceId: string;
      environmentLeaseId: string;
      runId: string;
      normalizedSessionId: string;
      turnId: string;
      itemId: string;
    };
    history: Array<Record<string, unknown>>;
  } | null = null;
  try {
    claim = await db.transaction(async (tx) => {
      const run = await tx
        .select()
        .from(heartbeatRuns)
        .where(
          and(
            eq(heartbeatRuns.id, input.runId),
            eq(heartbeatRuns.companyId, input.companyId),
          ),
        )
        .for("update", { noWait: true })
        .limit(1)
        .then((rows) => rows[0]);
      if (
        !run ||
        run.runtimeMode !== "native" ||
        !run.nativeIssueId ||
        !run.nativeSessionId ||
        !run.runnerInstanceId ||
        !["succeeded", "failed"].includes(run.status) ||
        !run.finishedAt ||
        !cleanupProcessAbsent(run.processPid) ||
        run.processGroupId !== run.processPid
      )
        return null;
      const execution = parseNativeExecutionInput(
        record(run.runnerProfileJson).nativeExecutionInput,
      );
      const failure = record(record(run.resultJson).recoveredExecutionFailure);
      const errorCode = run.errorCode ?? failure.errorCode;
      const error = run.error ?? failure.error;
      if (
        errorCode !== "adapter_failed" ||
        error !==
          "provider_transport_failed: runner did not durably suspend before checkpoint" ||
        execution.binding.companyId !== run.companyId ||
        execution.binding.agentId !== run.agentId ||
        execution.binding.issueId !== run.nativeIssueId ||
        execution.binding.runId !== run.id ||
        nativeSessionKey(execution) !== run.nativeSessionId ||
        execution.provider.kind !== "codex" ||
        execution.session.driverKind !== "codex_app_server" ||
        record(run.runnerProfileJson).nativeToolContractFingerprint !==
          nativeToolContractFingerprintForTarget("local")
      )
        return null;
      const scope = nativeSessionScopeKey(execution);
      if (
        activeNativeSessions.has(run.id) ||
        executingRunnerdSessionScopes.has(scope) ||
        initializingSessionToolAuthorities.has(scope) ||
        warmNativeSessions.has(scope)
      )
        return null;
      executingRunnerdSessionScopes.set(scope, leaseOwner);
      reservedScope = scope;
      const coordinator = await tx
        .select()
        .from(nativeRunFinalizations)
        .where(
          and(
            eq(nativeRunFinalizations.runId, run.id),
            eq(nativeRunFinalizations.companyId, run.companyId),
            eq(nativeRunFinalizations.issueId, run.nativeIssueId),
          ),
        )
        .for("update", { noWait: true })
        .limit(1)
        .then((rows) => rows[0]);
      if (
        !coordinator ||
        coordinator.phase !== "committed" ||
        !coordinator.resultId ||
        !coordinator.assessmentId ||
        !coordinator.decisionId ||
        coordinator.nextAttemptAt ||
        (coordinator.leaseOwner &&
          coordinator.leaseExpiresAt &&
          coordinator.leaseExpiresAt > new Date()) ||
        coordinator.recoveryHistory.some(
          (event) => event.kind === "native_cleanup_runner_epoch",
        )
      )
        return null;
      const result = await tx
        .select()
        .from(nativeRunResults)
        .where(
          and(
            eq(nativeRunResults.id, coordinator.resultId),
            eq(nativeRunResults.runId, run.id),
            eq(nativeRunResults.companyId, run.companyId),
            eq(nativeRunResults.issueId, run.nativeIssueId),
          ),
        )
        .for("share", { noWait: true })
        .limit(1)
        .then((rows) => rows[0]);
      if (!result || result.schemaStatus !== "accepted") return null;
      const environment = await tx
        .select({ id: environmentLeases.id })
        .from(environmentLeases)
        .where(
          and(
            eq(environmentLeases.companyId, run.companyId),
            eq(environmentLeases.heartbeatRunId, run.id),
            inArray(environmentLeases.status, ["active", "pending_cleanup"]),
          ),
        )
        .limit(1);
      if (environment.length) return null;
      const root = scopedRunnerdStateRoot(execution);
      const maintenanceHistory = coordinator.recoveryHistory.filter(
        (event) => event.kind === "native_cleanup_maintenance",
      );
      const archiveHistory = coordinator.recoveryHistory.filter(
        (event) => event.kind === "native_cleanup_source_archive",
      );
      const parent = resolve(runnerdStateBase(), "quarantine");
      if (existsSync(parent) && !isSafeNativeStateDirectory(parent))
        return null;
      const entries = existsSync(parent) ? readdirSync(parent) : [];
      if (entries.length > 4096) return null;
      const candidates = entries.filter((name) =>
        name.startsWith(`${basename(root)}.identity_indeterminate.`),
      );
      let emptyRoot: ReturnType<typeof cleanupCanonicalVacancy> = null;
      let sourceDirectory: string;
      let quarantine: string;
      let sourceArchive: NonNullable<typeof claim>["sourceArchive"] = null;
      const rootExists = !!lstatSync(root, { throwIfNoEntry: false });
      if (rootExists && !isSafeNativeStateDirectory(root)) return null;
      if (archiveHistory.length) {
        const prepared = archiveHistory[0]!;
        const archived = archiveHistory[1];
        if (
          maintenanceHistory.length ||
          archiveHistory.length > 2 ||
          prepared.version !== 1 ||
          prepared.phase !== "prepared" ||
          prepared.companyId !== run.companyId ||
          prepared.agentId !== run.agentId ||
          prepared.runId !== run.id ||
          prepared.nativeSessionId !== run.nativeSessionId ||
          prepared.runnerInstanceId !== run.runnerInstanceId ||
          prepared.stateKey !== basename(root) ||
          typeof prepared.requestId !== "string" ||
          !prepared.requestId.startsWith("native-cleanup:") ||
          typeof prepared.archiveName !== "string" ||
          prepared.archiveName.length > 192 ||
          basename(prepared.archiveName) !== prepared.archiveName ||
          !prepared.archiveName.startsWith(
            `${basename(root)}.identity_indeterminate.cleanup.`,
          ) ||
          typeof prepared.sourceFingerprint !== "string" ||
          !/^[0-9a-f]{64}$/.test(prepared.sourceFingerprint) ||
          typeof prepared.providerHomeFingerprint !== "string" ||
          !/^[0-9a-f]{64}$/.test(prepared.providerHomeFingerprint) ||
          (archived &&
            (archived.phase !== "archived" ||
              Object.entries(prepared).some(
                ([key, value]) =>
                  key !== "phase" &&
                  canonicalJson(archived[key]) !== canonicalJson(value),
              )))
        )
          return null;
        quarantine = resolve(parent, prepared.archiveName);
        if (rootExists) {
          if (archived || candidates.length || existsSync(quarantine))
            return null;
          sourceDirectory = root;
        } else {
          if (candidates.length !== 1 || candidates[0] !== prepared.archiveName)
            return null;
          sourceDirectory = quarantine;
        }
        sourceArchive = {
          intent: prepared,
          fromCanonical: rootExists,
          completed: !!archived,
        };
      } else if (rootExists && readdirSync(root).length) {
        if (maintenanceHistory.length || candidates.length) return null;
        sourceDirectory = root;
        quarantine = resolve(
          parent,
          `${basename(root)}.identity_indeterminate.cleanup.${randomUUID()}`,
        );
        sourceArchive = {
          intent: {},
          fromCanonical: true,
          completed: false,
        };
      } else {
        // A refused successor may create only the directory before admission
        // fails. Inventory that exact empty inode, never replace another owner.
        emptyRoot = cleanupCanonicalVacancy(root);
        if (candidates.length !== 1) return null;
        quarantine = resolve(parent, candidates[0]!);
        sourceDirectory = quarantine;
      }
      const archiveRootIdentity = sourceArchive
        ? cleanupArchiveRootIdentity(sourceDirectory)
        : null;
      if (sourceArchive) {
        const scopeEntries = readdirSync(runnerdStateBase());
        if (
          scopeEntries.length > 4096 ||
          scopeEntries.some((name) =>
            name.startsWith(`${basename(root)}.cleanup-`),
          )
        )
          return null;
      }
      const source = cleanupStateSnapshot(sourceDirectory);
      const identity = record(source.control.identity);
      if (
        !durableIdentityMatchesExecution(identity, execution) ||
        identity.runnerInstanceId !== run.runnerInstanceId ||
        ![
          "runnerInstanceId",
          "environmentLeaseId",
          "runId",
          "normalizedSessionId",
          "turnId",
          "itemId",
        ].every(
          (key) =>
            typeof identity[key] === "string" &&
            identity[key] &&
            source.runner[key] === identity[key],
        ) ||
        source.runner.lifecycle !== "ready" ||
        source.provider.lifecycle !== "turn_active" ||
        record(source.provider.config).provider !== "codex" ||
        record(source.provider.config).command !== "codex" ||
        record(source.provider.config).cwd !== execution.workspace.cwd ||
        !Array.isArray(source.control.committedEvents)
      )
        return null;
      const providerEvents = source.control.committedEvents
        .map((entry) => record(record(record(entry).envelope).payload))
        .filter((event) =>
          ["session.started", "session.resumed"].includes(
            String(event.eventType),
          ),
        );
      const providerEvent = providerEvents.at(-1);
      const provider = record(providerEvent?.payload);
      if (
        !providerEvent ||
        !validatePrpEvent(providerEvent).ok ||
        providerEvent.sourceKind !== "runner" ||
        providerEvent.turnId !== identity.turnId ||
        providerEvent.itemId !== identity.itemId ||
        !cleanupProcessAbsent(provider.processId) ||
        typeof provider.providerSessionId !== "string" ||
        source.provider.threadId !== provider.providerSessionId ||
        providerEvent.runId !== run.id ||
        providerEvent.sourceInstanceId !== run.runnerInstanceId ||
        providerEvent.normalizedSessionId !== run.nativeSessionId ||
        typeof providerEvent.sourceEventId !== "string"
      )
        return null;
      const persisted = await tx
        .select()
        .from(heartbeatRunEvents)
        .where(
          and(
            eq(heartbeatRunEvents.runId, run.id),
            eq(heartbeatRunEvents.companyId, run.companyId),
            or(
              and(
                eq(heartbeatRunEvents.sourceInstanceId, run.runnerInstanceId),
                inArray(heartbeatRunEvents.eventType, [
                  "session.started",
                  "session.resumed",
                ]),
              ),
              sql`${heartbeatRunEvents.payload}->'prpEvent'->>'sourceKind' = 'control_plane'`,
            ),
          ),
        )
        .limit(20);
      if (
        persisted.length >= 20 ||
        !retainedNativeCleanupJournalMatches({
          run,
          execution,
          accepted: result,
          control: source.control,
          providerSessionId: provider.providerSessionId,
          providerAccountSessionId:
            typeof provider.providerAccountSessionId === "string"
              ? provider.providerAccountSessionId
              : null,
          persistedEvents: persisted,
        })
      )
        return null;
      let copySource: {
        directory: string;
        snapshot: ReturnType<typeof cleanupStateSnapshot>;
        requestId: string;
      } | null = null;
      const providerHome = cleanupProviderHomeSnapshot(
        resolve(sourceDirectory, "codex-home"),
        true,
      );
      if (sourceArchive) {
        if (archiveHistory.length) {
          if (
            sourceArchive.intent.sourceFingerprint !== source.fingerprint ||
            sourceArchive.intent.providerHomeFingerprint !==
              providerHome.fingerprint ||
            canonicalJson(sourceArchive.intent.rootIdentity) !==
              canonicalJson(archiveRootIdentity)
          )
            return null;
        } else {
          sourceArchive.intent = {
            kind: "native_cleanup_source_archive",
            version: 1,
            phase: "prepared",
            requestId: leaseOwner,
            companyId: run.companyId,
            agentId: run.agentId,
            runId: run.id,
            nativeSessionId: run.nativeSessionId,
            runnerInstanceId: run.runnerInstanceId,
            stateKey: basename(root),
            archiveName: basename(quarantine),
            rootIdentity: archiveRootIdentity,
            sourceFingerprint: source.fingerprint,
            providerHomeFingerprint: providerHome.fingerprint,
          };
        }
      }
      if (maintenanceHistory.length) {
        if (
          maintenanceHistory.length !== 2 ||
          typeof maintenanceHistory[0]?.requestId !== "string"
        )
          return null;
        const priorRequestId = maintenanceHistory[0].requestId;
        const scopeEntries = readdirSync(runnerdStateBase());
        if (scopeEntries.length > 4096) return null;
        const attemptedNames = scopeEntries.filter((name) =>
          name.startsWith(`${basename(root)}.cleanup-`),
        );
        if (attemptedNames.length !== 1) return null;
        const directory = resolve(runnerdStateBase(), attemptedNames[0]!);
        if (
          !retainedRunnerdMaintenanceIsIdle(directory) ||
          lstatSync(resolve(directory, CLEANUP_ACTIVATION_FILE), {
            throwIfNoEntry: false,
          })
        )
          return null;
        const attempted = cleanupStateSnapshot(directory);
        const receipts = await tx
          .select()
          .from(heartbeatRunEvents)
          .where(
            and(
              eq(heartbeatRunEvents.companyId, run.companyId),
              eq(heartbeatRunEvents.runId, run.id),
              eq(heartbeatRunEvents.eventType, "native.cleanup.event"),
              eq(
                heartbeatRunEvents.sourceInstanceId,
                `${run.runnerInstanceId}:cleanup:${priorRequestId}`,
              ),
            ),
          )
          .limit(513);
        if (
          receipts.length > 512 ||
          !verifyRetainedMaintenanceNoLaunch({
            companyId: run.companyId,
            agentId: run.agentId,
            identity: identity as {
              runnerInstanceId: string;
              environmentLeaseId: string;
              runId: string;
              normalizedSessionId: string;
              turnId: string;
              itemId: string;
            },
            original: source,
            attempted,
            requestId: priorRequestId,
            requestHistory: coordinator.recoveryHistory,
            receipts,
            now: new Date(),
          })
        )
          return null;
        copySource = {
          directory,
          snapshot: attempted,
          requestId: priorRequestId,
        };
      }
      const history = [
        ...coordinator.recoveryHistory,
        ...(sourceArchive
          ? archiveHistory.length
            ? []
            : [sourceArchive.intent]
          : [
              {
                kind: "native_cleanup_maintenance",
                version: 1,
                phase: "started",
                requestId: leaseOwner,
                sourceFingerprint:
                  copySource?.snapshot.fingerprint ?? source.fingerprint,
                ...(copySource
                  ? {
                      originalFingerprint: source.fingerprint,
                      copiedFromRequestId: copySource.requestId,
                      copiedFromStagingName: basename(copySource.directory),
                    }
                  : {}),
                startedAt: new Date().toISOString(),
              },
            ]),
      ];
      await tx
        .update(nativeRunFinalizations)
        .set({
          leaseOwner,
          leaseExpiresAt: new Date(Date.now() + 60_000),
          recoveryHistory: history,
          updatedAt: new Date(),
        })
        .where(eq(nativeRunFinalizations.runId, run.id));
      return {
        execution,
        run,
        quarantine,
        root,
        emptyRoot,
        source,
        providerHome,
        sourceArchive,
        copySource,
        providerPid: provider.processId,
        providerSessionId: provider.providerSessionId,
        identity: identity as {
          runnerInstanceId: string;
          environmentLeaseId: string;
          runId: string;
          normalizedSessionId: string;
          turnId: string;
          itemId: string;
        },
        history,
      };
    });
  } catch {
    releaseScope();
    return { status: "not_eligible", runId: input.runId };
  }
  if (!claim) {
    releaseScope();
    return { status: "not_eligible", runId: input.runId };
  }
  const owned = claim;
  let stagingDirectory: string | null = null;
  let maintenanceStarted = !owned.sourceArchive;
  const archiveReference = owned.sourceArchive
    ? { sourceArchiveRequestId: owned.sourceArchive.intent.requestId }
    : {};
  const assertLease = async () => {
    const lease = await db
      .select({ runId: nativeRunFinalizations.runId })
      .from(nativeRunFinalizations)
      .where(
        and(
          eq(nativeRunFinalizations.runId, owned.run.id),
          eq(nativeRunFinalizations.companyId, owned.run.companyId),
          eq(nativeRunFinalizations.phase, "committed"),
          eq(nativeRunFinalizations.leaseOwner, leaseOwner),
          gt(nativeRunFinalizations.leaseExpiresAt, sql`now()`),
        ),
      )
      .limit(1);
    if (
      !lease.length ||
      !reservedScope ||
      executingRunnerdSessionScopes.get(reservedScope) !== leaseOwner ||
      !cleanupProcessAbsent(owned.run.processPid) ||
      !cleanupProcessAbsent(owned.providerPid)
    )
      throw denied();
  };
  const authorize = async () => {
    await assertLease();
    if (
      cleanupStateSnapshot(owned.quarantine).fingerprint !==
        owned.source.fingerprint ||
      cleanupProviderHomeSnapshot(
        resolve(owned.quarantine, "codex-home"),
        false,
      ).metadataFingerprint !== owned.providerHome.metadataFingerprint ||
      (owned.copySource &&
        (!retainedRunnerdMaintenanceIsIdle(owned.copySource.directory) ||
          cleanupStateSnapshot(owned.copySource.directory).fingerprint !==
            owned.copySource.snapshot.fingerprint ||
          lstatSync(
            resolve(owned.copySource.directory, CLEANUP_ACTIVATION_FILE),
            { throwIfNoEntry: false },
          ))) ||
      canonicalJson(cleanupCanonicalVacancy(owned.root)) !==
        canonicalJson(owned.emptyRoot)
    )
      throw denied();
  };
  const appendMaintenanceHistory = async (entry: Record<string, unknown>) => {
    const history = await db.transaction(async (tx) => {
      const current = await tx
        .select()
        .from(nativeRunFinalizations)
        .where(
          and(
            eq(nativeRunFinalizations.runId, owned.run.id),
            eq(nativeRunFinalizations.companyId, owned.run.companyId),
            eq(nativeRunFinalizations.phase, "committed"),
            eq(nativeRunFinalizations.leaseOwner, leaseOwner),
            gt(nativeRunFinalizations.leaseExpiresAt, sql`now()`),
          ),
        )
        .for("update")
        .limit(1)
        .then((rows) => rows[0]);
      if (!current || current.leaseOwner !== leaseOwner) throw denied();
      const next = [
        ...current.recoveryHistory,
        {
          ...entry,
          ...(entry.kind === "native_cleanup_source_archive"
            ? {}
            : archiveReference),
        },
      ];
      await tx
        .update(nativeRunFinalizations)
        .set({ recoveryHistory: next, updatedAt: new Date() })
        .where(eq(nativeRunFinalizations.runId, owned.run.id));
      return next;
    });
    owned.history = history;
  };
  try {
    if (owned.sourceArchive) {
      const archive = owned.sourceArchive;
      await assertLease();
      const sourceDirectory = archive.fromCanonical
        ? owned.root
        : owned.quarantine;
      if (
        canonicalJson(cleanupArchiveRootIdentity(sourceDirectory)) !==
          canonicalJson(archive.intent.rootIdentity) ||
        cleanupStateSnapshot(sourceDirectory).fingerprint !==
          owned.source.fingerprint ||
        cleanupProviderHomeSnapshot(
          resolve(sourceDirectory, "codex-home"),
          true,
        ).fingerprint !== owned.providerHome.fingerprint ||
        (archive.fromCanonical
          ? existsSync(owned.quarantine)
          : existsSync(owned.root))
      )
        throw denied();
      if (archive.fromCanonical) {
        const parent = dirname(owned.quarantine);
        mkdirSync(parent, { recursive: true, mode: 0o700 });
        if (!isSafeNativeStateDirectory(parent)) throw denied();
        // Preserve the original inode and every byte. In particular, do not
        // invoke ordinary quarantine scrubbing on this evidence-only archive.
        renameSync(owned.root, owned.quarantine);
        archive.fromCanonical = false;
      }
      const archivedHome = cleanupProviderHomeSnapshot(
        resolve(owned.quarantine, "codex-home"),
        true,
      );
      if (
        cleanupStateSnapshot(owned.quarantine).fingerprint !==
          owned.source.fingerprint ||
        archivedHome.fingerprint !== owned.providerHome.fingerprint ||
        canonicalJson(cleanupArchiveRootIdentity(owned.quarantine)) !==
          canonicalJson(archive.intent.rootIdentity) ||
        existsSync(owned.root)
      )
        throw denied();
      owned.providerHome = archivedHome;
      if (!archive.completed) {
        await appendMaintenanceHistory({
          ...archive.intent,
          phase: "archived",
        });
        archive.completed = true;
      }
      await authorize();
      await appendMaintenanceHistory({
        kind: "native_cleanup_maintenance",
        version: 1,
        phase: "started",
        requestId: leaseOwner,
        sourceFingerprint: owned.source.fingerprint,
        startedAt: new Date().toISOString(),
      });
      maintenanceStarted = true;
    }
    await authorize();
    const copy = mkdtempSync(
      resolve(runnerdStateBase(), `${basename(owned.root)}.cleanup-`),
    );
    stagingDirectory = copy;
    chmodSync(copy, 0o700);
    for (const folder of ["runner", "control-plane"])
      mkdirSync(resolve(copy, folder), { mode: 0o700 });
    for (const file of CLEANUP_CANONICAL_FILES) {
      copyFileSync(
        resolve(owned.copySource?.directory ?? owned.quarantine, file),
        resolve(copy, file),
        constants.COPYFILE_EXCL,
      );
      chmodSync(resolve(copy, file), 0o600);
    }
    copyCleanupProviderHome(
      resolve(owned.quarantine, "codex-home"),
      resolve(copy, "codex-home"),
      owned.providerHome,
    );
    rebaseRetainedNativeCleanupProviderHome(
      resolve(copy, "codex-home"),
      resolve(owned.root, "codex-home"),
      owned.providerSessionId,
      "staging",
    );
    await authorize();
    await appendMaintenanceHistory({
      kind: "native_cleanup_maintenance",
      version: 1,
      phase: "staged",
      requestId: leaseOwner,
      sourceFingerprint:
        owned.copySource?.snapshot.fingerprint ?? owned.source.fingerprint,
      stagingName: basename(copy),
      providerHomeFingerprint: owned.providerHome.fingerprint,
      providerHomeBytes: owned.providerHome.bytes,
      stagedProviderHomeFingerprint: cleanupProviderHomeSnapshot(
        resolve(copy, "codex-home"),
        true,
      ).fingerprint,
    });
    const proof = await settleRetainedRunnerdSession({
      requestId: leaseOwner,
      binding: {
        companyId: owned.run.companyId,
        issueId: owned.run.nativeIssueId!,
        agentId: owned.run.agentId,
        runId: owned.run.id,
        sessionId: owned.run.nativeSessionId!,
      },
      identity: owned.identity,
      backend: { kind: "runner", name: "codex_app_server" },
      stateDirectory: copy,
      activationDirectory: owned.root,
      sourceFingerprint:
        owned.copySource?.snapshot.fingerprint ?? owned.source.fingerprint,
      providerSessionId: owned.providerSessionId,
      originalRunnerPid: owned.run.processPid!,
      originalProviderPid: owned.providerPid,
      // The control-only provider resume still needs normal host discovery
      // and auth-file lookup. Inherit only the existing host allowlist.
      environment: buildNativeProviderEnvironment(
        {},
        process.env,
        owned.execution.workspace.cwd,
      ),
      authorize,
      recordEpoch: async (receipt) => {
        if (receipt.requestId !== leaseOwner || receipt.stateDirectory !== copy)
          throw denied();
        await appendMaintenanceHistory({
          kind: "native_cleanup_runner_epoch",
          version: 1,
          ...receipt,
        });
      },
      appendEvent: async (event) => {
        await appendRetainedNativeCleanupEvent(db, {
          companyId: owned.run.companyId,
          agentId: owned.run.agentId,
          runId: owned.run.id,
          nativeSessionId: owned.run.nativeSessionId!,
          runnerInstanceId: owned.run.runnerInstanceId!,
          requestId: leaseOwner,
          event,
        });
      },
    });
    // Commit intent before the filesystem handoff. A crash can then be
    // distinguished from an unattempted quarantine; never replay its source.
    if (
      cleanupProviderHomeSnapshot(resolve(owned.quarantine, "codex-home"), true)
        .fingerprint !== owned.providerHome.fingerprint
    )
      throw denied();
    rebaseRetainedNativeCleanupProviderHome(
      resolve(copy, "codex-home"),
      resolve(owned.root, "codex-home"),
      owned.providerSessionId,
      "canonical",
    );
    const settledHome = cleanupProviderHomeSnapshot(
      resolve(copy, "codex-home"),
      true,
    );
    const emptyRootArchive = owned.emptyRoot
      ? `${basename(owned.root)}.empty-before-cleanup.${leaseOwner}`
      : null;
    const preparedHistory = [
      ...owned.history,
      {
        kind: "native_cleanup_maintenance",
        version: 1,
        phase: "activation_prepared",
        ...archiveReference,
        requestId: leaseOwner,
        sourceFingerprint: proof.sourceFingerprint,
        settledFingerprint: proof.settledFingerprint,
        settledProviderHomeFingerprint: settledHome.fingerprint,
        stagingName: basename(copy),
        ...(emptyRootArchive
          ? { emptyRootArchive, emptyRoot: owned.emptyRoot }
          : {}),
        nativeSessionId: owned.run.nativeSessionId,
        runnerInstanceId: owned.run.runnerInstanceId,
        providerSessionId: owned.providerSessionId,
      },
    ];
    writeFileSync(
      resolve(copy, CLEANUP_ACTIVATION_FILE),
      JSON.stringify({
        schema: "paperclip.native_cleanup_activation.v1",
        companyId: owned.run.companyId,
        issueId: owned.run.nativeIssueId,
        runId: owned.run.id,
        requestId: leaseOwner,
        sourceFingerprint: proof.sourceFingerprint,
        settledFingerprint: proof.settledFingerprint,
        settledProviderHomeFingerprint: settledHome.fingerprint,
      }),
      { flag: "wx", mode: 0o600 },
    );
    const prepared = await db
      .update(nativeRunFinalizations)
      .set({ recoveryHistory: preparedHistory, updatedAt: new Date() })
      .where(
        and(
          eq(nativeRunFinalizations.runId, owned.run.id),
          eq(nativeRunFinalizations.leaseOwner, leaseOwner),
          gt(nativeRunFinalizations.leaseExpiresAt, sql`now()`),
        ),
      )
      .returning({ runId: nativeRunFinalizations.runId });
    if (!prepared.length) throw denied();
    owned.history = preparedHistory;
    await db.transaction(async (tx) => {
      const current = await tx
        .select()
        .from(nativeRunFinalizations)
        .where(
          and(
            eq(nativeRunFinalizations.runId, owned.run.id),
            eq(nativeRunFinalizations.leaseOwner, leaseOwner),
            gt(nativeRunFinalizations.leaseExpiresAt, sql`now()`),
          ),
        )
        .for("update")
        .limit(1)
        .then((rows) => rows[0]);
      if (!current || current.phase !== "committed") throw denied();
      await authorize();
      if (
        cleanupProviderHomeSnapshot(resolve(copy, "codex-home"), false)
          .metadataFingerprint !== settledHome.metadataFingerprint
      )
        throw denied();
      if (emptyRootArchive) {
        const archive = resolve(runnerdStateBase(), emptyRootArchive);
        if (lstatSync(archive, { throwIfNoEntry: false })) throw denied();
        // Preserve even an empty predecessor directory as evidence. The
        // scope reservation and durable prepared intent cover this handoff.
        renameSync(owned.root, archive);
      }
      renameSync(copy, owned.root);
      await tx
        .update(nativeRunFinalizations)
        .set({
          leaseOwner: null,
          leaseExpiresAt: null,
          recoveryHistory: [
            ...owned.history,
            {
              kind: "native_cleanup_maintenance",
              version: 1,
              phase: "settled",
              ...archiveReference,
              requestId: leaseOwner,
              sourceFingerprint: proof.sourceFingerprint,
              settledFingerprint: proof.settledFingerprint,
              settledProviderHomeFingerprint: settledHome.fingerprint,
              nativeSessionId: owned.run.nativeSessionId,
              runnerInstanceId: owned.run.runnerInstanceId,
              providerSessionId: owned.providerSessionId,
              settledAt: new Date().toISOString(),
            },
          ],
          updatedAt: new Date(),
        })
        .where(eq(nativeRunFinalizations.runId, owned.run.id));
    });
    if (
      cleanupProviderHomeSnapshot(resolve(owned.root, "codex-home"), true)
        .fingerprint !== settledHome.fingerprint
    )
      throw denied();
    completeRetainedNativeSessionCleanup(proof);
    rmSync(resolve(owned.root, CLEANUP_ACTIVATION_FILE));
    return { status: "settled", runId: input.runId };
  } catch {
    if (stagingDirectory && existsSync(stagingDirectory)) {
      // Keep the failed journal, not transient copied provider credentials.
      try {
        scrubRunnerdQuarantineLaunchState(stagingDirectory);
      } catch {
        /* retain fail-closed ownership */
      }
    }
    await db.transaction(async (tx) => {
      const current = await tx
        .select()
        .from(nativeRunFinalizations)
        .where(
          and(
            eq(nativeRunFinalizations.runId, owned.run.id),
            eq(nativeRunFinalizations.leaseOwner, leaseOwner),
          ),
        )
        .for("update")
        .limit(1)
        .then((rows) => rows[0]);
      if (!current || current.leaseOwner !== leaseOwner) return;
      await tx
        .update(nativeRunFinalizations)
        .set({
          leaseOwner: null,
          leaseExpiresAt: null,
          // A timed-out epoch callback may have committed before this lock.
          // Preserve its evidence rather than replacing it from a stale copy.
          recoveryHistory: [
            ...current.recoveryHistory,
            {
              kind: maintenanceStarted
                ? "native_cleanup_maintenance"
                : "native_cleanup_source_archive",
              version: 1,
              phase: "operator_required",
              requestId: leaseOwner,
              ...archiveReference,
              code: "native_cleanup_maintenance_unproven",
            },
          ],
          updatedAt: new Date(),
        })
        .where(
          and(
            eq(nativeRunFinalizations.runId, owned.run.id),
            eq(nativeRunFinalizations.leaseOwner, leaseOwner),
          ),
        );
    });
    return { status: "operator_required", runId: input.runId };
  } finally {
    releaseScope();
  }
}

/** Read-only scoped admission fence; never grants provider or recovery authority. */
export async function assertRetainedNativeSourceArchiveSettled(
  db: Db,
  input: { companyId: string; issueId: string; stateKey: string },
): Promise<void> {
  if (!/^[a-f0-9]{64}$/.test(input.stateKey))
    throw new NativeSessionCleanupQuarantinedError();
  const owners = await db
    .select()
    .from(nativeRunFinalizations)
    .where(
      and(
        eq(nativeRunFinalizations.companyId, input.companyId),
        eq(nativeRunFinalizations.issueId, input.issueId),
        sql`exists (
      select 1 from jsonb_array_elements(${nativeRunFinalizations.recoveryHistory}) prepared
      where prepared->>'kind' = 'native_cleanup_source_archive'
        and prepared->>'phase' = 'prepared'
        and jsonb_typeof(prepared->'stateKey') = 'string'
        and prepared->>'stateKey' = ${input.stateKey}
        and not coalesce(${nativeRunFinalizations.phase} = 'committed'
          and (select count(*) from jsonb_array_elements(${nativeRunFinalizations.recoveryHistory}) duplicate
            where duplicate->>'kind' = 'native_cleanup_source_archive'
              and duplicate->>'phase' = 'prepared'
              and duplicate->'stateKey' = prepared->'stateKey') = 1
          and prepared->'version' = '1'::jsonb
          and jsonb_typeof(prepared->'requestId') = 'string'
          and prepared->>'requestId' like 'native-cleanup:%'
          and jsonb_typeof(prepared->'sourceFingerprint') = 'string'
          and prepared->>'sourceFingerprint' ~ '^[a-f0-9]{64}$'
          and (
          select settled.value->>'phase' = 'settled'
            and jsonb_typeof(settled.value->'sourceArchiveRequestId') = 'string'
            and jsonb_typeof(settled.value->'sourceFingerprint') = 'string'
            and settled.value->>'sourceFingerprint' = prepared->>'sourceFingerprint'
          from jsonb_array_elements(${nativeRunFinalizations.recoveryHistory})
            with ordinality as settled(value, position)
          where settled.value->>'kind' = 'native_cleanup_maintenance'
            and settled.value->>'sourceArchiveRequestId' = prepared->>'requestId'
          order by settled.position desc limit 1
        ), false)
    )`,
      ),
    )
    .limit(1);
  for (const owner of owners) {
    const history = Array.isArray(owner.recoveryHistory)
      ? owner.recoveryHistory
      : [];
    const intents = history.filter(
      (entry) =>
        entry.kind === "native_cleanup_source_archive" &&
        entry.phase === "prepared" &&
        entry.stateKey === input.stateKey,
    );
    if (!intents.length) continue;
    const intent = intents[0]!;
    const settlement = history.findLast(
      (entry) =>
        entry.kind === "native_cleanup_maintenance" &&
        entry.sourceArchiveRequestId === intent.requestId,
    );
    if (
      intents.length !== 1 ||
      owner.phase !== "committed" ||
      intent.version !== 1 ||
      typeof intent.requestId !== "string" ||
      !intent.requestId.startsWith("native-cleanup:") ||
      typeof intent.sourceFingerprint !== "string" ||
      !/^[a-f0-9]{64}$/.test(intent.sourceFingerprint) ||
      settlement?.phase !== "settled" ||
      settlement.sourceFingerprint !== intent.sourceFingerprint
    )
      throw new NativeSessionCleanupQuarantinedError();
  }
}
async function assertCleanupActivationCommitted(
  db: Db,
  root: string,
  execution: NativeExecutionInput,
): Promise<void> {
  const path = resolve(root, CLEANUP_ACTIVATION_FILE);
  if (!lstatSync(path, { throwIfNoEntry: false })) return;
  const marker = record(
    JSON.parse(
      readBoundedNativeFile(
        path,
        4096,
        "native_cleanup_maintenance_unproven",
      ).toString("utf8"),
    ),
  );
  if (
    marker.schema !== "paperclip.native_cleanup_activation.v1" ||
    marker.companyId !== execution.binding.companyId ||
    marker.issueId !== execution.binding.issueId ||
    typeof marker.runId !== "string" ||
    typeof marker.requestId !== "string"
  ) {
    throw new NativeSessionCleanupQuarantinedError();
  }
  const coordinator = await db
    .select()
    .from(nativeRunFinalizations)
    .where(
      and(
        eq(nativeRunFinalizations.runId, marker.runId),
        eq(nativeRunFinalizations.companyId, execution.binding.companyId),
        eq(nativeRunFinalizations.issueId, execution.binding.issueId),
      ),
    )
    .limit(1)
    .then((rows) => rows[0]);
  const receipt = coordinator?.recoveryHistory.findLast(
    (entry) =>
      entry.kind === "native_cleanup_maintenance" &&
      entry.requestId === marker.requestId,
  );
  const snapshot = cleanupStateSnapshot(root);
  if (
    marker.settledProviderHomeFingerprint !== undefined ||
    receipt?.settledProviderHomeFingerprint !== undefined
  ) {
    if (
      typeof marker.settledProviderHomeFingerprint !== "string" ||
      !/^[0-9a-f]{64}$/.test(marker.settledProviderHomeFingerprint) ||
      receipt?.settledProviderHomeFingerprint !==
        marker.settledProviderHomeFingerprint ||
      cleanupProviderHomeSnapshot(resolve(root, "codex-home"), true)
        .fingerprint !== marker.settledProviderHomeFingerprint
    )
      throw new NativeSessionCleanupQuarantinedError();
  }
  if (
    coordinator?.phase !== "committed" ||
    receipt?.phase !== "settled" ||
    receipt.sourceFingerprint !== marker.sourceFingerprint ||
    receipt.settledFingerprint !== marker.settledFingerprint ||
    snapshot.fingerprint !== marker.settledFingerprint ||
    snapshot.runner.runId !== marker.runId ||
    snapshot.runner.lifecycle !== "suspended" ||
    snapshot.provider.lifecycle !== "prepared" ||
    !Array.isArray(snapshot.control.committedEvents)
  )
    throw new NativeSessionCleanupQuarantinedError();
  const owners = snapshot.control.committedEvents
    .map((entry) => record(record(record(entry).envelope).payload))
    .filter((event) =>
      ["session.started", "session.resumed"].includes(String(event.eventType)),
    )
    .map((event) => record(event.payload).processId);
  if (!owners.length || !owners.every(cleanupProcessAbsent))
    throw new NativeSessionCleanupQuarantinedError();
  // A committed receipt survived a crash after rename. Normal admission now
  // applies its existing exact old-owner/session fences; no process is started here.
  rmSync(path);
}

/** Read-only admission evidence for an explicit retry of a terminal failed
 * run. Never migrate/archive state, release an owner, or contact a provider.
 * Normal executor admission independently verifies the state again. */
export function nativeFailedRunRetryStateIsSafe(input: {
  execution: unknown;
  companyId: string;
  issueId: string;
  agentId: string;
  runId: string;
  nativeSessionId: string;
  runnerInstanceId: string;
  providerSessionId: string | null;
  providerBackendSessionId: string | null;
  processPid: number | null;
  processGroupId: number | null;
  recoveryMode: "bootstrap_retry" | "exact_checkpoint_resume";
  allowVerifiedBackup: boolean;
}): boolean {
  try {
    const execution = parseNativeExecutionInput(input.execution);
    if (
      execution.binding.companyId !== input.companyId ||
      execution.binding.issueId !== input.issueId ||
      execution.binding.agentId !== input.agentId ||
      execution.binding.runId !== input.runId ||
      nativeSessionKey(execution) !== input.nativeSessionId ||
      !input.runnerInstanceId
    )
      return false;
    const scope = nativeSessionScopeKey(execution);
    if (
      executingRunnerdSessionScopes.has(scope) ||
      initializingSessionToolAuthorities.has(scope) ||
      warmNativeSessions.has(scope)
    )
      return false;
    for (const [id, group] of [
      [input.processPid, false],
      [input.processGroupId, true],
    ] as const) {
      if (id === null) continue;
      if (!Number.isSafeInteger(id) || id <= 0) return false;
      try {
        process.kill(group ? -id : id, 0);
        return false;
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== "ESRCH") return false;
      }
    }
    const root = scopedRunnerdStateRoot(execution);
    if (!lstatSync(root, { throwIfNoEntry: false })) {
      if (
        input.recoveryMode !== "bootstrap_retry" ||
        lstatSync(legacyRunnerdStateRoot(execution), {
          throwIfNoEntry: false,
        }) ||
        lstatSync(legacyCompanyRunnerdStateRoot(execution), {
          throwIfNoEntry: false,
        })
      )
        return false;
      // A missing root after quarantine is not proof of a clean bootstrap.
      const quarantine = resolve(runnerdStateBase(), "quarantine");
      if (lstatSync(quarantine, { throwIfNoEntry: false })) {
        if (!isSafeNativeStateDirectory(quarantine)) return false;
        const directory = opendirSync(quarantine);
        try {
          const prefixes = [
            root,
            legacyRunnerdStateRoot(execution),
            legacyCompanyRunnerdStateRoot(execution),
          ].map((path) => `${basename(path)}.`);
          for (let count = 0; ; count++) {
            const entry = directory.readSync();
            if (!entry) break;
            if (
              count >= 4096 ||
              prefixes.some((prefix) => entry.name.startsWith(prefix))
            )
              return false;
          }
        } finally {
          directory.closeSync();
        }
      }
      return true;
    }
    const identity = readRunnerdDurableIdentity(root);
    if (
      !durableIdentityMatchesSession(identity, execution) ||
      !durableIdentityMatchesExecution(identity, execution) ||
      identity.runnerInstanceId !== input.runnerInstanceId
    )
      return false;
    let stateRoot = root;
    const direct = runnerdAuthorityLifecycle(root, identity);
    if (direct === "absent" && input.allowVerifiedBackup) {
      const backup = verifyNativeHarnessBackup({
        root,
        execution,
        runnerInstanceId: input.runnerInstanceId,
      });
      if (!backup) return false;
      stateRoot = backup.root;
    }
    if (runnerdAuthorityLifecycle(stateRoot, identity) !== "suspended")
      return false;
    const runnerState = record(
      JSON.parse(
        readBoundedNativeFile(
          resolve(stateRoot, "runner", "runner-state.json"),
          NATIVE_RUNNER_STATE_MAX_BYTES,
          "runner_state_too_large",
        ).toString("utf8"),
      ),
    );
    if (
      runnerState.schema !== RUNNERD_STATE_SCHEMA ||
      runnerState.lifecycle !== "suspended" ||
      runnerState.runId !== identity.runId ||
      runnerState.runnerInstanceId !== identity.runnerInstanceId ||
      runnerState.normalizedSessionId !== identity.normalizedSessionId ||
      runnerState.environmentLeaseId !== identity.environmentLeaseId ||
      !Array.isArray(runnerState.outbox) ||
      runnerState.outbox.length !== 0
    )
      return false;
    const providerFile = resolve(
      stateRoot,
      "runner",
      runnerProviderStateFilename(execution),
    );
    if (input.recoveryMode === "bootstrap_retry") return false;
    const providerState = record(
      JSON.parse(
        readBoundedNativeFile(
          providerFile,
          NATIVE_RUNNER_STATE_MAX_BYTES,
          "runner_provider_state_too_large",
        ).toString("utf8"),
      ),
    );
    if (
      !Array.isArray(providerState.pendingEvents) ||
      providerState.pendingEvents.length !== 0 ||
      !Array.isArray(providerState.queuedEvents) ||
      providerState.queuedEvents.length !== 0 ||
      Object.keys(record(record(providerState.toolBridge).pending)).length !==
        0 ||
      providerState.activeProviderResultFingerprint != null
    )
      return false;
    const providerIdentity = providerSessionIdentityFromDurableProviderState({
      execution,
      providerState,
    });
    return (
      !!input.providerSessionId &&
      providerIdentity.providerSessionId === input.providerSessionId &&
      providerIdentity.providerBackendSessionId ===
        input.providerBackendSessionId
    );
  } catch {
    return false;
  }
}

/** Physical half of retrying a request rejected before provider admission.
 * The caller separately proves the failed receipt/coordinator has no native
 * events or result and selects exactly one committed cleanup owner. */
export function nativePreProviderRetryAfterCleanupStateIsSafe(input: {
  failedExecution: unknown;
  retiredExecution: unknown;
  companyId: string;
  issueId: string;
  agentId: string;
  failedRunId: string;
  retiredRunId: string;
  nativeSessionId: string;
  runnerInstanceId: string;
  providerSessionId: string;
  providerBackendSessionId: string | null;
  processPid: number;
  processGroupId: number;
  receipt: Record<string, unknown>;
}): boolean {
  try {
    const failed = parseNativeExecutionInput(input.failedExecution);
    const retired = parseNativeExecutionInput(input.retiredExecution);
    if (
      input.failedRunId === input.retiredRunId ||
      failed.binding.runId !== input.failedRunId ||
      retired.binding.runId !== input.retiredRunId ||
      failed.binding.companyId !== input.companyId ||
      failed.binding.issueId !== input.issueId ||
      failed.binding.agentId !== input.agentId ||
      nativeSessionScopeKey(failed) !== nativeSessionScopeKey(retired) ||
      input.receipt.kind !== "native_cleanup_maintenance" ||
      input.receipt.version !== 1 ||
      input.receipt.phase !== "settled" ||
      input.receipt.nativeSessionId !== input.nativeSessionId ||
      input.receipt.runnerInstanceId !== input.runnerInstanceId ||
      input.receipt.providerSessionId !== input.providerSessionId ||
      typeof input.receipt.requestId !== "string" ||
      input.receipt.requestId.length === 0 ||
      typeof input.receipt.sourceFingerprint !== "string" ||
      !/^[a-f0-9]{64}$/.test(input.receipt.sourceFingerprint) ||
      typeof input.receipt.settledFingerprint !== "string" ||
      !/^[a-f0-9]{64}$/.test(input.receipt.settledFingerprint) ||
      !nativeFailedRunRetryStateIsSafe({
        execution: retired,
        companyId: input.companyId,
        issueId: input.issueId,
        agentId: input.agentId,
        runId: input.retiredRunId,
        nativeSessionId: input.nativeSessionId,
        runnerInstanceId: input.runnerInstanceId,
        providerSessionId: input.providerSessionId,
        processPid: input.processPid,
        processGroupId: input.processGroupId,
        providerBackendSessionId: input.providerBackendSessionId,
        recoveryMode: "exact_checkpoint_resume",
        allowVerifiedBackup: false,
      })
    )
      return false;
    const root = scopedRunnerdStateRoot(retired);
    const markerPath = resolve(root, CLEANUP_ACTIVATION_FILE);
    if (lstatSync(markerPath, { throwIfNoEntry: false })) {
      // A crash after receipt commit may leave the activation marker. This
      // read-only proof accepts only that exact committed handoff; normal
      // executor admission independently reconciles the marker before launch.
      const marker = record(
        JSON.parse(
          readBoundedNativeFile(
            markerPath,
            4096,
            "native_cleanup_maintenance_unproven",
          ).toString("utf8"),
        ),
      );
      if (
        marker.schema !== "paperclip.native_cleanup_activation.v1" ||
        marker.companyId !== input.companyId ||
        marker.issueId !== input.issueId ||
        marker.runId !== input.retiredRunId ||
        marker.requestId !== input.receipt.requestId ||
        marker.sourceFingerprint !== input.receipt.sourceFingerprint ||
        marker.settledFingerprint !== input.receipt.settledFingerprint
      )
        return false;
    }
    return (
      cleanupStateSnapshot(root).fingerprint ===
      input.receipt.settledFingerprint
    );
  } catch {
    return false;
  }
}

async function verifyPriorRunnerdStateForSessionScope(input: {
  db: Db;
  root: string;
  identity: RunnerdDurableIdentity;
  execution: NativeExecutionInput;
  allowVerifiedBackup: boolean;
  allowRetainedWarmRunner: boolean;
}): Promise<PriorRunnerdStateVerification> {
  let priorRun: {
    status: string;
    runnerProfileJson: unknown;
  } | null;
  try {
    priorRun = await input.db
      .select({
        status: heartbeatRuns.status,
        runnerProfileJson: heartbeatRuns.runnerProfileJson,
      })
      .from(heartbeatRuns)
      .where(
        and(
          eq(heartbeatRuns.id, input.identity.runId),
          eq(heartbeatRuns.companyId, input.execution.binding.companyId),
          eq(heartbeatRuns.agentId, input.execution.binding.agentId),
        ),
      )
      .limit(1)
      .then((rows) => rows[0] ?? null);
  } catch {
    return "unavailable";
  }
  if (!priorRun) return "authority_indeterminate";
  if (!TERMINAL_HEARTBEAT_RUN_STATUSES.has(priorRun.status)) {
    return "active";
  }
  const persistedInput = record(
    priorRun.runnerProfileJson,
  ).nativeExecutionInput;
  if (persistedInput === undefined) return "authority_indeterminate";
  try {
    const priorExecution = parseNativeExecutionInput(persistedInput);
    const sameScope =
      priorExecution.binding.runId === input.identity.runId &&
      nativeSessionScopeKey(priorExecution) ===
        nativeSessionScopeKey(input.execution);
    if (!sameScope) return "scope_mismatch";
    const lifecycle = runnerdAuthorityLifecycleWithVerifiedBackup(input);
    if (lifecycle === "suspended") return "verified";
    const directLifecycle = runnerdAuthorityLifecycle(
      input.root,
      input.identity,
    );
    if (
      input.allowRetainedWarmRunner &&
      (lifecycle === "not_suspended" ||
        // A remote runner keeps runner-state.json in the sandbox rather than
        // beside the controller's PRP journal. During a genuinely warm handoff
        // there is intentionally no suspended failover backup yet. The exact
        // idle in-memory session owner is the authority for this one case;
        // after a restart that owner is absent and this remains fail-closed.
        (input.allowVerifiedBackup && directLifecycle === "absent"))
    ) {
      return "retained_warm_runner";
    }
    return "terminal_state_indeterminate";
  } catch {
    return "authority_indeterminate";
  }
}

function hasRetainedWarmTransitionEvidence(root: string): boolean {
  for (const [directory, filename, maximum] of [
    [
      "control-plane",
      "control-plane-state.json",
      NATIVE_DURABLE_IDENTITY_MAX_BYTES,
    ],
    ["runner", "runner-state.json", NATIVE_RUNNER_STATE_MAX_BYTES],
  ] as const) {
    const path = resolve(root, directory, filename);
    if (!lstatSync(path, { throwIfNoEntry: false })) continue;
    let bytes: string;
    try {
      bytes = readBoundedNativeFile(
        path,
        maximum,
        "runner_state_too_large",
      ).toString("utf8");
    } catch {
      // The ordinary verifier still owns unreadable legacy state. Inspect the
      // other file before deciding whether this is a forward-protocol fence.
      continue;
    }
    try {
      const state = record(JSON.parse(bytes));
      if (
        Object.prototype.hasOwnProperty.call(state, "warmTransition") ||
        state.schema ===
          "paperclip.runner.durable.control-plane-state.warm-transition.v1" ||
        state.schema === "paperclip.runner.durable.state.warm-transition.v1"
      )
        return true;
    } catch {
      // This is detection only, never admission. A damaged forward receipt
      // must remain available to its owner rather than become legacy state.
      if (
        bytes.includes("warm-transition.v1") ||
        bytes.includes('"warmTransition"')
      )
        return true;
    }
  }
  return false;
}

type VerifiedWarmTransitionBinding = {
  runnerInstanceId: string;
  environmentLeaseId: string;
  transitionId: string;
  stateFingerprint: string;
};

function readWarmTransitionSnapshot(root: string) {
  if (
    ![root, resolve(root, "control-plane"), resolve(root, "runner")].every(
      isSafeNativeStateDirectory,
    )
  ) {
    throw new Error("native_runner_warm_transition_recovery_unproven");
  }
  const core = readBoundedNativeFile(
    resolve(root, "control-plane", "control-plane-state.json"),
    NATIVE_DURABLE_IDENTITY_MAX_BYTES,
    "native_runner_warm_transition_recovery_unproven",
  );
  const runner = readBoundedNativeFile(
    resolve(root, "runner", "runner-state.json"),
    NATIVE_RUNNER_STATE_MAX_BYTES,
    "native_runner_warm_transition_recovery_unproven",
  );
  try {
    return {
      controlPlaneState: JSON.parse(core.toString("utf8")) as unknown,
      runnerState: JSON.parse(runner.toString("utf8")) as unknown,
      stateFingerprint: nativeSha256([
        core.toString("base64"),
        runner.toString("base64"),
      ]),
    };
  } catch {
    throw new Error("native_runner_warm_transition_recovery_unproven");
  }
}

/** Forward receipts select a protocol boundary, never a process owner. */
async function verifyWarmTransitionRestart(input: {
  db: Db;
  execution: NativeExecutionInput;
  restartRecovery?: NativeRestartRecoveryClaim;
  runnerExecutionTarget?: AdapterExecutionTarget | null;
}): Promise<VerifiedWarmTransitionBinding> {
  const deny = (): never => {
    throw new Error("native_runner_warm_transition_recovery_unproven");
  };
  const claim = input.restartRecovery;
  // A surviving runner needs its own authenticated reattach path. Do not
  // reinterpret that claim, remote evidence, or an incomplete bootstrap as
  // permission to launch another process against a retained transition.
  if (
    claim?.kind !== "resume_dead_runner" ||
    input.runnerExecutionTarget?.kind === "remote" ||
    input.execution.provider.kind !== "codex" ||
    input.execution.session.driverKind !== "codex_app_server" ||
    claim.runId !== input.execution.binding.runId
  )
    return deny();
  const root = scopedRunnerdStateRoot(input.execution);
  const snapshot = readWarmTransitionSnapshot(root);
  const artifact = readRunnerdArtifactBinding(resolvePaperclipRunnerBinary());
  const controller = await currentNativeControllerIdentity();
  const binding = input.execution.binding;
  let finalAuthorityCheck: (() => boolean) | undefined;
  const verified = await input.db.transaction(async (tx) => {
    const current = await tx
      .select()
      .from(heartbeatRuns)
      .where(
        and(
          eq(heartbeatRuns.id, binding.runId),
          eq(heartbeatRuns.companyId, binding.companyId),
        ),
      )
      .for("update")
      .limit(1)
      .then((rows) => rows[0]);
    const coordinator = await tx
      .select()
      .from(nativeRunFinalizations)
      .where(
        and(
          eq(nativeRunFinalizations.runId, binding.runId),
          eq(nativeRunFinalizations.companyId, binding.companyId),
        ),
      )
      .for("update")
      .limit(1)
      .then((rows) => rows[0]);
    const issue = await tx
      .select()
      .from(issues)
      .where(
        and(
          eq(issues.id, binding.issueId),
          eq(issues.companyId, binding.companyId),
        ),
      )
      .for("update")
      .limit(1)
      .then((rows) => rows[0]);
    const now = new Date();
    if (
      !current ||
      !coordinator ||
      !issue ||
      issue.executionRunId !== binding.runId ||
      current.agentId !== binding.agentId ||
      current.nativeIssueId !== binding.issueId ||
      current.runtimeMode !== "native" ||
      current.status !== "running" ||
      current.finishedAt !== null ||
      current.nativeSessionId !== nativeSessionKey(input.execution) ||
      !current.runnerInstanceId ||
      isNativeRunnerOwnershipHeld(current) ||
      coordinator.issueId !== binding.issueId ||
      coordinator.phase !== "observed" ||
      coordinator.resultId !== null ||
      coordinator.leaseOwner !== claim.leaseOwner ||
      !coordinator.leaseExpiresAt ||
      coordinator.leaseExpiresAt <= now ||
      coordinator.controllerBootId !== controller.bootId ||
      coordinator.controllerPid !== controller.pid ||
      coordinator.controllerProcessStartedAt?.getTime() !==
        controller.processStartedAt.getTime() ||
      coordinator.controllerGeneration !== claim.controllerGeneration
    )
      return deny();
    const profile = record(current.runnerProfileJson);
    let frozen: NativeExecutionInput;
    try {
      frozen = parseNativeExecutionInput(profile.nativeExecutionInput);
    } catch {
      return deny();
    }
    if (nativeSha256(frozen) !== nativeSha256(input.execution)) return deny();
    const cancellation = record(record(current.resultJson).nativeCancellation);
    if (
      cancellation.scope === "run" &&
      ["pending", "acknowledged"].includes(String(cancellation.dispatchState))
    )
      return deny();
    let expectedEnvironmentLeaseId = binding.executionWorkspaceId;
    if (binding.executionWorkspaceId === binding.runId) {
      // Projectless runs retain the first run's lease while their workspace
      // placeholder changes. The receipt only SELECTS that origin: its frozen
      // DB execution, full scope and terminal ownership independently prove it.
      const selectedLease = record(
        record(record(snapshot.runnerState).warmTransition).receipt,
      ).newIdentity;
      const originId = record(selectedLease).environmentLeaseId;
      if (
        typeof originId !== "string" ||
        !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(
          originId,
        )
      )
        return deny();
      const origin = await tx
        .select()
        .from(heartbeatRuns)
        .where(
          and(
            eq(heartbeatRuns.id, originId),
            eq(heartbeatRuns.companyId, binding.companyId),
          ),
        )
        .for("update")
        .limit(1)
        .then((rows) => rows[0]);
      if (
        !origin ||
        origin.agentId !== binding.agentId ||
        origin.nativeIssueId !== binding.issueId ||
        origin.runtimeMode !== "native" ||
        !["succeeded", "failed", "cancelled", "timed_out"].includes(
          origin.status,
        ) ||
        origin.finishedAt === null ||
        isNativeRunnerOwnershipHeld(origin) ||
        origin.runnerInstanceId !== current.runnerInstanceId ||
        origin.nativeSessionId !== current.nativeSessionId
      )
        return deny();
      let originExecution: NativeExecutionInput;
      try {
        originExecution = parseNativeExecutionInput(
          record(origin.runnerProfileJson).nativeExecutionInput,
        );
      } catch {
        return deny();
      }
      if (
        originExecution.binding.runId !== origin.id ||
        originExecution.binding.executionWorkspaceId !== origin.id ||
        originExecution.binding.companyId !== binding.companyId ||
        originExecution.binding.agentId !== binding.agentId ||
        originExecution.binding.issueId !== binding.issueId ||
        nativeSessionScopeKey(originExecution) !==
          nativeSessionScopeKey(input.execution)
      )
        return deny();
      expectedEnvironmentLeaseId = origin.id;
    }
    const inspectionInput = {
      ...snapshot,
      expectedNewIdentity: {
        runnerInstanceId: current.runnerInstanceId,
        environmentLeaseId: expectedEnvironmentLeaseId,
        runId: binding.runId,
        normalizedSessionId: nativeSessionKey(input.execution),
        turnId: `turn-${binding.runId}`,
        itemId: `item-${binding.runId}`,
      },
      expectedRunnerVersion: artifact.version,
      expectedRunnerDigest: artifact.digest,
    };
    const proof = inspectWarmRunTransition({
      ...inspectionInput,
      now: Date.now(),
    });
    if (!proof) return deny();
    const prior = await tx
      .select()
      .from(heartbeatRuns)
      .where(
        and(
          eq(heartbeatRuns.id, proof.receipt.oldIdentity.runId),
          eq(heartbeatRuns.companyId, binding.companyId),
        ),
      )
      .for("update")
      .limit(1)
      .then((rows) => rows[0]);
    if (
      !prior ||
      prior.agentId !== binding.agentId ||
      prior.nativeIssueId !== binding.issueId ||
      prior.runtimeMode !== "native" ||
      !["succeeded", "failed", "cancelled", "timed_out"].includes(
        prior.status,
      ) ||
      prior.finishedAt === null ||
      isNativeRunnerOwnershipHeld(prior) ||
      prior.runnerInstanceId !== current.runnerInstanceId ||
      prior.nativeSessionId !== current.nativeSessionId ||
      proof.receipt.oldIdentity.runnerInstanceId !== prior.runnerInstanceId ||
      proof.receipt.oldIdentity.normalizedSessionId !== prior.nativeSessionId ||
      proof.receipt.oldIdentity.environmentLeaseId !==
        expectedEnvironmentLeaseId ||
      proof.receipt.oldIdentity.turnId !== `turn-${prior.id}` ||
      proof.receipt.oldIdentity.itemId !== `item-${prior.id}`
    )
      return deny();
    let previousExecution: NativeExecutionInput;
    try {
      previousExecution = parseNativeExecutionInput(
        record(prior.runnerProfileJson).nativeExecutionInput,
      );
    } catch {
      return deny();
    }
    if (
      previousExecution.binding.runId !== prior.id ||
      previousExecution.binding.companyId !== binding.companyId ||
      previousExecution.binding.agentId !== binding.agentId ||
      previousExecution.binding.issueId !== binding.issueId ||
      nativeSessionScopeKey(previousExecution) !==
        nativeSessionScopeKey(input.execution)
    )
      return deny();
    const history = coordinator.recoveryHistory.at(-1);
    const checkpoint = record(profile.sessionCheckpoint);
    const checkpointIdentity = record(checkpoint.identity);
    const processEvidence = record(checkpoint.process);
    if (
      !history ||
      history.disposition !== claim.kind ||
      history.controllerBootId !== controller.bootId ||
      history.controllerPid !== controller.pid ||
      history.controllerGeneration !== claim.controllerGeneration ||
      history.recoveryRequestId !== claim.recoveryRequestId ||
      history.providerAttempt !== claim.providerAttempt ||
      history.stateRootAction !== "reuse_exact_root" ||
      history.hasCheckpoint !== true ||
      history.checkpointIdentityMatches !== true ||
      history.hasProviderEvidence !== true ||
      checkpointIdentity.runId !== binding.runId ||
      checkpointIdentity.companyId !== binding.companyId ||
      checkpointIdentity.issueId !== binding.issueId ||
      checkpointIdentity.agentId !== binding.agentId ||
      checkpointIdentity.sessionId !== current.nativeSessionId ||
      history.processPid !== prior.processPid ||
      history.processStartedAt !== prior.processStartedAt?.toISOString() ||
      processEvidence.runnerPid !== prior.processPid ||
      processEvidence.runnerProcessGroupId !== prior.processGroupId ||
      prior.processGroupId !== prior.processPid ||
      !cleanupProcessAbsent(prior.processPid)
    )
      return deny();
    // Recheck every independently retained provider owner, including process
    // groups. These are DB/checkpoint facts, not claims in a copied journal.
    const known = history.knownProviderPids;
    if (
      !Array.isArray(known) ||
      known.length === 0 ||
      known.length > 16 ||
      ![
        history.liveProviderPids,
        history.ambiguousProviderPids,
        history.recycledProviderPids,
      ].every((pids) => Array.isArray(pids) && pids.length === 0)
    )
      return deny();
    const checkpointPids = new Set<number>();
    for (const [pidKey, startedKey] of [
      ["providerPid", "providerProcessStartedAt"],
      ["codexPid", "codexProcessStartedAt"],
      ["sidecarPid", "sidecarProcessStartedAt"],
      ["agentPid", "agentProcessStartedAt"],
    ] as const) {
      const pid = processEvidence[pidKey];
      if (pid === null || pid === undefined) continue;
      if (
        typeof processEvidence[startedKey] !== "string" ||
        !Number.isFinite(Date.parse(processEvidence[startedKey] as string)) ||
        !cleanupProcessAbsent(pid)
      )
        return deny();
      checkpointPids.add(pid);
    }
    if (
      checkpointPids.size === 0 ||
      new Set(known).size !== checkpointPids.size ||
      known.some(
        (pid) =>
          typeof pid !== "number" ||
          !checkpointPids.has(pid) ||
          !cleanupProcessAbsent(pid),
      )
    )
      return deny();
    // These fences remain relevant if maintenance evidence appears after
    // initial construction. Every later registration/launch/auth gate repeats
    // them; no settled receipt or pending transition bypasses quarantine.
    await assertRetainedNativeSourceArchiveSettled(tx as unknown as Db, {
      companyId: binding.companyId,
      issueId: binding.issueId,
      stateKey: basename(root),
    });
    await assertCleanupActivationCommitted(
      tx as unknown as Db,
      root,
      input.execution,
    );
    finalAuthorityCheck = () => {
      if (
        readWarmTransitionSnapshot(root).stateFingerprint !==
        snapshot.stateFingerprint
      )
        return false;
      const selected = readRunnerdArtifactBinding(
        resolvePaperclipRunnerBinary(),
      );
      if (
        selected.version !== artifact.version ||
        selected.digest !== artifact.digest
      )
        return false;
      const finalProof = inspectWarmRunTransition({
        ...inspectionInput,
        now: Date.now(),
      });
      return (
        coordinator.leaseExpiresAt!.getTime() > Date.now() &&
        finalProof?.receipt.transitionId === proof.receipt.transitionId &&
        finalProof.receipt.leaseExpiresAtUnixMs > Date.now()
      );
    };
    if (!finalAuthorityCheck()) return deny();
    return {
      runnerInstanceId: current.runnerInstanceId,
      environmentLeaseId: expectedEnvironmentLeaseId,
      transitionId: proof.receipt.transitionId,
      stateFingerprint: snapshot.stateFingerprint,
    };
  });
  // A lock wait or the transaction completion itself can outlive a lease.
  // Never carry a timestamp sampled before those awaits into admission.
  if (!finalAuthorityCheck?.()) return deny();
  return verified;
}

async function migrateRunnerdStateRootForExecution(input: {
  db: Db;
  execution: NativeExecutionInput;
  conversationMode?: boolean;
  allowVerifiedBackup: boolean;
  allowRetainedWarmRunner: boolean;
  allowLocalRecovery: boolean;
  onLog?: (stream: "stdout" | "stderr", chunk: string) => Promise<void>;
  restartRecovery?: NativeRestartRecoveryClaim;
  runnerExecutionTarget?: AdapterExecutionTarget | null;
}): Promise<VerifiedWarmTransitionBinding | undefined> {
  const scoped = scopedRunnerdStateRoot(input.execution);
  // A crash can leave a source archive intent before/after its rename. Until
  // that exact maintenance is settled, absence of a canonical root is not
  // permission to bootstrap a replacement provider session.
  await assertRetainedNativeSourceArchiveSettled(input.db, {
    companyId: input.execution.binding.companyId,
    issueId: input.execution.binding.issueId,
    stateKey: basename(scoped),
  });
  if (
    input.allowLocalRecovery &&
    !input.allowRetainedWarmRunner &&
    !input.restartRecovery
  ) {
    await recoverQuiescentRunnerdState({ ...input, scoped });
  }
  if (input.restartRecovery?.kind === "reattach_remote_runner" && !existsSync(scoped)) {
    throw new Error("runner_state_identity_mismatch");
  }
  if (existsSync(scoped)) {
    if (!isSafeNativeStateDirectory(scoped)) {
      throw new Error("runner_state_directory_unsafe");
    }
    if (hasRetainedWarmTransitionEvidence(scoped)) {
      // A copied receipt is not restart/process authority. Keep both valid
      // unsupported and invalid forward evidence out of destructive legacy
      // migration until the exact transition admission path proves its owner.
      const verified = await verifyWarmTransitionRestart(input);
      return verified;
    }
    await assertCleanupActivationCommitted(input.db, scoped, input.execution);
    const identity = readRunnerdDurableIdentity(scoped);
    if (!identity) {
      if (input.restartRecovery?.kind !== "reattach_existing_runner" &&
          input.restartRecovery?.kind !== "reattach_remote_runner") {
        quarantineRunnerdStateRoot(scoped, "identity_indeterminate");
      }
      throw new Error("runner_state_identity_mismatch");
    }
    if (!durableIdentityMatchesSession(identity, input.execution)) {
      if (input.restartRecovery?.kind !== "reattach_existing_runner" &&
          input.restartRecovery?.kind !== "reattach_remote_runner") {
        quarantineRunnerdStateRoot(scoped, "identity_mismatch");
      }
      throw new Error("runner_state_identity_mismatch");
    }
    if (input.restartRecovery?.kind === "bootstrap_incomplete") {
      if (runnerdStateProvesIncompleteBootstrap(scoped)) {
        quarantineRunnerdStateRoot(scoped, "identity_indeterminate");
        return;
      }
      // Database evidence alone cannot distinguish a never-connected runner
      // from a partially-persisted provider bootstrap. Only the durable PRP
      // root can authorize a fresh bootstrap; anything else stays fail-closed.
      throw new Error("runner_state_identity_mismatch");
    }
    if (input.restartRecovery?.kind === "reattach_remote_runner") {
      await verifyRemoteRunnerReattachment({
        claim: input.restartRecovery, target: input.runnerExecutionTarget, identity,
        runId: input.execution.binding.runId, normalizedSessionId: nativeSessionKey(input.execution),
        nativeHarnessState: input.conversationMode === true && input.execution.provider.kind === "opencode" &&
          input.runnerExecutionTarget?.kind === "remote" && input.runnerExecutionTarget.transport === "sandbox",
      });
      return;
    }
    if (durableIdentityMatchesExecution(identity, input.execution)) {
      if (
        runnerdAuthorityLifecycleWithVerifiedBackup({
          root: scoped,
          identity,
          execution: input.execution,
          allowVerifiedBackup: input.allowVerifiedBackup,
        }) === "indeterminate"
      ) {
        if (input.restartRecovery?.kind !== "reattach_existing_runner") {
          quarantineRunnerdStateRoot(scoped, "identity_indeterminate");
        }
        throw new Error("runner_state_identity_mismatch");
      }
    } else {
      const verification = await verifyPriorRunnerdStateForSessionScope({
        db: input.db,
        root: scoped,
        identity,
        execution: input.execution,
        allowVerifiedBackup: input.allowVerifiedBackup,
        allowRetainedWarmRunner: input.allowRetainedWarmRunner,
      });
      if (
        verification !== "verified" &&
        verification !== "retained_warm_runner"
      ) {
        if (verification !== "active" && verification !== "unavailable") {
          quarantineRunnerdStateRoot(
            scoped,
            verification === "scope_mismatch"
              ? "identity_mismatch"
              : "identity_indeterminate",
          );
        }
        throw new Error("runner_state_identity_mismatch");
      }
    }
    return;
  }
  for (const legacy of [
    legacyCompanyRunnerdStateRoot(input.execution),
    legacyRunnerdStateRoot(input.execution),
  ]) {
    if (!existsSync(legacy)) continue;
    const identity = readRunnerdDurableIdentity(legacy);
    if (
      !identity ||
      !durableIdentityMatchesSession(identity, input.execution)
    ) {
      // Unlike the full-scope target above, this legacy name can legitimately
      // belong to another scope. Leave it in place for its owner and fail the
      // attempted migration visibly.
      throw new Error("runner_state_identity_mismatch");
    }
    let verifiedPriorRunId: string | undefined;
    if (!durableIdentityMatchesExecution(identity, input.execution)) {
      const verification = await verifyPriorRunnerdStateForSessionScope({
        db: input.db,
        root: legacy,
        identity,
        execution: input.execution,
        allowVerifiedBackup: input.allowVerifiedBackup,
        allowRetainedWarmRunner: input.allowRetainedWarmRunner,
      });
      if (
        verification !== "verified" &&
        verification !== "retained_warm_runner"
      ) {
        if (verification === "terminal_state_indeterminate") {
          // The database proves this ambiguous legacy path belongs to the same
          // full session scope and its owner is terminal, so it is now safe to
          // move aside. Scope mismatches and active/unavailable owners remain
          // untouched because the legacy name may still belong to them.
          quarantineRunnerdStateRoot(legacy, "identity_indeterminate");
        }
        throw new Error("runner_state_identity_mismatch");
      }
      verifiedPriorRunId = identity.runId;
    }
    migrateLegacyRunnerdStateRoot({
      legacy,
      scoped,
      execution: input.execution,
      ...(verifiedPriorRunId ? { verifiedPriorRunId } : {}),
    });
    return;
  }
}

// A terminal warm run can lose its controller before session.suspend. Older
// controllers quarantined even fully settled state in that case. Recover the
// exact provider thread, never bootstrap a replacement from an ambiguous root.
async function recoverQuiescentRunnerdState(input: {
  db: Db;
  execution: NativeExecutionInput;
  scoped: string;
  onLog?: (stream: "stdout" | "stderr", chunk: string) => Promise<void>;
}): Promise<void> {
  if (input.execution.provider.kind !== "codex") return;
  const quarantine = resolve(runnerdStateBase(), "quarantine");
  const scopedExists = existsSync(input.scoped);
  if (scopedExists && !isSafeNativeStateDirectory(input.scoped)) return;
  // Never hide corrupt or contradictory current authority behind an older
  // checkpoint. Only an absent/empty root may recover from quarantine.
  const currentEmpty = !scopedExists || readdirSync(input.scoped).length === 0;
  const candidates = currentEmpty
    ? isSafeNativeStateDirectory(quarantine)
      ? readdirSync(quarantine)
          .filter((name) =>
            name.startsWith(
              `${basename(input.scoped)}.identity_indeterminate.`,
            ),
          )
          .map((name) => resolve(quarantine, name))
      : []
    : [input.scoped];
  if (
    currentEmpty &&
    candidates.filter(
      (root) =>
        isSafeNativeStateDirectory(root) && readdirSync(root).length > 0,
    ).length > 1
  ) {
    // Do not roll back to an older valid checkpoint when a newer quarantined
    // root contains unconfirmed work, even if the newer root is unreadable.
    throw new Error("runner_state_identity_mismatch");
  }
  const verified: Array<{
    root: string;
    runnerBytes: string;
    controlBytes: string;
    providerBytes: string;
    runner: Record<string, unknown>;
    runId: string;
    processPid: number;
    processGroupId: number;
  }> = [];
  for (const root of candidates) {
    if (!isSafeNativeStateDirectory(root)) continue;
    const identity = readRunnerdDurableIdentity(root);
    if (!durableIdentityMatchesSession(identity, input.execution)) continue;
    if (identity.runId === input.execution.binding.runId) continue;
    try {
      const readState = (directory: string, name: string) => {
        if (!isSafeNativeStateDirectory(resolve(root, directory)))
          throw new Error("unsafe_recovery_state");
        return readBoundedNativeFile(
          resolve(root, directory, name),
          NATIVE_RUNNER_STATE_MAX_BYTES,
          "recovery_state_too_large",
        ).toString("utf8");
      };
      const runnerBytes = readState("runner", "runner-state.json");
      const controlBytes = readState(
        "control-plane",
        "control-plane-state.json",
      );
      const providerBytes = readState("runner", "codex-provider-state.json");
      const runner = record(JSON.parse(runnerBytes));
      const control = record(JSON.parse(controlBytes));
      const provider = record(JSON.parse(providerBytes));
      const commands = control.commands;
      const events = control.committedEvents;
      const terminalEnvelope = record(
        record(Array.isArray(events) ? events.at(-1) : null).envelope,
      );
      if (
        runner.schema !== RUNNERD_STATE_SCHEMA ||
        !["ready", "suspended"].includes(String(runner.lifecycle)) ||
        (!currentEmpty && runner.lifecycle === "suspended") ||
        [
          "runId",
          "normalizedSessionId",
          "runnerInstanceId",
          "environmentLeaseId",
          "turnId",
          "itemId",
        ].some((key) => runner[key] !== identity[key]) ||
        !Array.isArray(runner.outbox) ||
        runner.outbox.length !== 0 ||
        runner.pendingTerminalDelivery !== null ||
        !Array.isArray(commands) ||
        commands.some((command) => record(command).status !== "completed") ||
        !Array.isArray(events) ||
        record(events.at(-1)).eventType !== "run.terminal" ||
        terminalEnvelope.runId !== identity.runId ||
        terminalEnvelope.normalizedSessionId !== identity.normalizedSessionId ||
        provider.completedTurnAuthoritative !== true
      )
        continue;
      const providerIdentity = providerSessionIdentityFromDurableProviderState({
        execution: input.execution,
        providerState: provider,
      });
      if (!providerIdentity.providerSessionId) continue;
      const prior = await input.db
        .select({
          status: heartbeatRuns.status,
          runnerProfileJson: heartbeatRuns.runnerProfileJson,
          processPid: heartbeatRuns.processPid,
          processGroupId: heartbeatRuns.processGroupId,
          contextSnapshot: heartbeatRuns.contextSnapshot,
        })
        .from(heartbeatRuns)
        .where(
          and(
            eq(heartbeatRuns.id, identity.runId),
            eq(heartbeatRuns.companyId, input.execution.binding.companyId),
            eq(heartbeatRuns.agentId, input.execution.binding.agentId),
          ),
        )
        .limit(1)
        .then((rows) => rows[0] ?? null);
      if (!prior || !TERMINAL_HEARTBEAT_RUN_STATUSES.has(prior.status))
        continue;
      const profile = record(prior.runnerProfileJson);
      const previous = parseNativeExecutionInput(profile.nativeExecutionInput);
      const checkpoint = record(profile.sessionCheckpoint);
      const checkpointIdentity = record(checkpoint.identity);
      const current = await input.db
        .select({ runnerProfileJson: heartbeatRuns.runnerProfileJson })
        .from(heartbeatRuns)
        .where(
          and(
            eq(heartbeatRuns.id, input.execution.binding.runId),
            eq(heartbeatRuns.companyId, input.execution.binding.companyId),
            eq(heartbeatRuns.agentId, input.execution.binding.agentId),
          ),
        )
        .limit(1)
        .then((rows) => rows[0] ?? null);
      const latestCheckpoint = record(
        record(current?.runnerProfileJson).sessionCheckpoint,
      );
      const latestIdentity = record(latestCheckpoint.identity);
      if (
        previous.binding.runId !== identity.runId ||
        previous.binding.issueId !== input.execution.binding.issueId ||
        nativeSessionScopeKey(previous) !==
          nativeSessionScopeKey(input.execution) ||
        nativeSessionConfigDigest(previous) !==
          nativeSessionConfigDigest(input.execution) ||
        record(record(prior.contextSnapshot).paperclipEnvironment).driver !==
          "local" ||
        checkpointIdentity.runId !== identity.runId ||
        checkpointIdentity.sessionId !== identity.normalizedSessionId ||
        checkpointIdentity.companyId !== previous.binding.companyId ||
        checkpointIdentity.agentId !== previous.binding.agentId ||
        checkpointIdentity.issueId !== previous.binding.issueId ||
        checkpoint.driverKind !== previous.session.driverKind ||
        checkpoint.providerSessionId !== providerIdentity.providerSessionId ||
        latestCheckpoint.providerSessionId !==
          providerIdentity.providerSessionId ||
        latestIdentity.sessionId !== identity.normalizedSessionId ||
        latestIdentity.companyId !== previous.binding.companyId ||
        latestIdentity.agentId !== previous.binding.agentId ||
        latestIdentity.issueId !== previous.binding.issueId ||
        checkpoint.activeTurnId !== null ||
        !Array.isArray(checkpoint.pendingRuntimeRequests) ||
        checkpoint.pendingRuntimeRequests.length !== 0 ||
        !localProcessDefinitelyGone(prior.processPid) ||
        !localProcessDefinitelyGone(prior.processGroupId, true)
      )
        continue;
      // Provider processes are normally inside the runner group. Check any
      // independently recorded child identities too, including detached ones.
      const processIds = [
        ...Object.entries(record(checkpoint.process))
          .filter(([key]) => /^(provider|codex|sidecar|agent)Pid$/.test(key))
          .map(([, value]) => value),
        ...events
          .map(
            (event) => record(record(record(event).envelope).payload).payload,
          )
          .map((payload) => record(payload).processId)
          .filter((pid) => pid !== undefined),
      ];
      if (processIds.some((pid) => !localProcessDefinitelyGone(pid))) continue;
      // No mutation if any evidence changed while the database was read.
      if (
        runnerBytes !== readState("runner", "runner-state.json") ||
        controlBytes !==
          readState("control-plane", "control-plane-state.json") ||
        providerBytes !== readState("runner", "codex-provider-state.json")
      )
        continue;
      verified.push({
        root,
        runnerBytes,
        controlBytes,
        providerBytes,
        runner,
        runId: identity.runId,
        processPid: prior.processPid!,
        processGroupId: prior.processGroupId!,
      });
    } catch {
      // Unreadable, unsafe, unscoped, or unprovable state stays quarantined.
    }
  }
  if (verified.length !== 1) {
    if (
      currentEmpty &&
      candidates.some(
        (root) =>
          isSafeNativeStateDirectory(root) && readdirSync(root).length > 0,
      )
    ) {
      // Known provider history is not permission to start a replacement when
      // recovery cannot prove a unique, settled owner.
      throw new Error("runner_state_identity_mismatch");
    }
    return;
  }
  const candidate = verified[0]!;
  // Candidate enumeration can await other database reads. Revalidate the
  // selected evidence and dead owner immediately before the atomic moves.
  for (const [relativePath, expected] of [
    ["runner/runner-state.json", candidate.runnerBytes],
    ["runner/codex-provider-state.json", candidate.providerBytes],
    ["control-plane/control-plane-state.json", candidate.controlBytes],
  ]) {
    if (
      readBoundedNativeFile(
        resolve(candidate.root, relativePath!),
        NATIVE_RUNNER_STATE_MAX_BYTES,
        "recovery_state_too_large",
      ).toString("utf8") !== expected
    ) {
      throw new Error("runner_state_identity_mismatch");
    }
  }
  if (
    !localProcessDefinitelyGone(candidate.processPid) ||
    !localProcessDefinitelyGone(candidate.processGroupId, true)
  ) {
    throw new Error("runner_state_identity_mismatch");
  }
  if (candidate.root !== input.scoped) {
    if (existsSync(input.scoped)) {
      if (
        !isSafeNativeStateDirectory(input.scoped) ||
        readdirSync(input.scoped).length !== 0
      )
        return;
      quarantineRunnerdStateRoot(input.scoped, "identity_indeterminate");
    }
    renameSync(candidate.root, input.scoped);
  }
  // The provider and its process group are gone and all work is settled. Seal
  // this old authority so the standard epoch rotation archives it before the
  // next run, retaining the provider's history and exact thread identity.
  const statePath = resolve(input.scoped, "runner", "runner-state.json");
  const temporary = `${statePath}.${randomUUID()}.tmp`;
  writeFileSync(
    temporary,
    JSON.stringify({ ...candidate.runner, lifecycle: "suspended" }),
    { encoding: "utf8", mode: 0o600, flag: "wx" },
  );
  renameSync(temporary, statePath);
  await input.onLog?.(
    "stdout",
    `[paperclip-runner] Automatically recovered settled session from run ${candidate.runId}; preserving the existing provider thread.\n`,
  );
}

function localProcessDefinitelyGone(value: unknown, group = false): boolean {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value <= 1)
    return false;
  try {
    process.kill(group ? -value : value, 0);
    return false;
  } catch (error) {
    return (error as NodeJS.ErrnoException).code === "ESRCH";
  }
}

export function runnerdStateProvesIncompleteBootstrap(root: string): boolean {
  try {
    const statePath = resolve(
      root,
      "control-plane",
      "control-plane-state.json",
    );
    const state = record(
      JSON.parse(
        readBoundedNativeFile(
          statePath,
          NATIVE_DURABLE_IDENTITY_MAX_BYTES,
          "runner_durable_identity_too_large",
        ).toString("utf8"),
      ),
    );
    const commands = Array.isArray(state.commands)
      ? state.commands.map(record)
      : [];
    const committedEvents = Array.isArray(state.committedEvents)
      ? state.committedEvents
      : [];
    const onlyUnconsumedBootstrapCommands = commands.every(
      (command) =>
        command.status === "pending" &&
        (command.type === "run.prepare" || command.type === "session.open"),
    );
    return (
      state.schema === RUNNERD_CONTROL_PLANE_STATE_SCHEMA &&
      state.connectionCount === 0 &&
      committedEvents.length === 0 &&
      onlyUnconsumedBootstrapCommands
    );
  } catch {
    return false;
  }
}

function isSafeNativeStateDirectory(path: string): boolean {
  if (!existsSync(path)) return false;
  const stats = lstatSync(path);
  return stats.isDirectory() && !stats.isSymbolicLink();
}

type RunnerdDurableIdentity = Record<string, unknown> & {
  runId: string;
  normalizedSessionId: string;
  runnerInstanceId: string;
  environmentLeaseId: string;
};

function readRunnerdDurableIdentity(
  root: string,
): Record<string, unknown> | null {
  if (!isSafeNativeStateDirectory(root)) return null;
  const controlPlaneRoot = resolve(root, "control-plane");
  if (!isSafeNativeStateDirectory(controlPlaneRoot)) return null;
  const statePath = resolve(controlPlaneRoot, "control-plane-state.json");
  if (!existsSync(statePath)) return null;
  try {
    const state = record(
      JSON.parse(
        readBoundedNativeFile(
          statePath,
          NATIVE_DURABLE_IDENTITY_MAX_BYTES,
          "runner_durable_identity_too_large",
        ).toString("utf8"),
      ),
    );
    if (state.schema !== RUNNERD_CONTROL_PLANE_STATE_SCHEMA) return null;
    return record(state.identity);
  } catch {
    return null;
  }
}

function durableIdentityMatchesExecution(
  identity: Record<string, unknown> | null,
  execution: NativeExecutionInput,
): boolean {
  return Boolean(
    identity &&
    identity.runId === execution.binding.runId &&
    durableIdentityMatchesSession(identity, execution),
  );
}

function durableIdentityMatchesSession(
  identity: Record<string, unknown> | null,
  execution: NativeExecutionInput,
): identity is RunnerdDurableIdentity {
  return Boolean(
    identity &&
    identity.normalizedSessionId === nativeSessionKey(execution) &&
    typeof identity.runId === "string" &&
    identity.runId.length > 0 &&
    typeof identity.runnerInstanceId === "string" &&
    identity.runnerInstanceId.length > 0 &&
    typeof identity.environmentLeaseId === "string" &&
    identity.environmentLeaseId.length > 0,
  );
}

/**
 * Pre-v2 state is migrated for an exact active run, or for a suspended prior
 * run whose persisted, validated execution input proves the same full native
 * session scope. Ambiguous company/session-only state can never be claimed by
 * another agent, workspace, or provider profile.
 */
function runnerdStateRoot(execution: NativeExecutionInput): string {
  const scoped = scopedRunnerdStateRoot(execution);
  if (existsSync(scoped)) {
    if (!isSafeNativeStateDirectory(scoped)) {
      throw new Error("runner_state_directory_unsafe");
    }
    return scoped;
  }
  for (const legacy of [
    legacyCompanyRunnerdStateRoot(execution),
    legacyRunnerdStateRoot(execution),
  ]) {
    const migrated = migrateLegacyRunnerdStateRoot({
      legacy,
      scoped,
      execution,
    });
    if (migrated) return migrated;
  }
  return scoped;
}

function loadRunnerdDurableBinding(
  execution: NativeExecutionInput,
  transition?: VerifiedWarmTransitionBinding,
): {
  runnerInstanceId: string;
  environmentLeaseId: string;
} | null {
  if (transition) {
    if (
      readWarmTransitionSnapshot(runnerdStateRoot(execution))
        .stateFingerprint !== transition.stateFingerprint
    ) {
      throw new Error("native_runner_warm_transition_recovery_unproven");
    }
    return transition;
  }
  const identity = readRunnerdDurableIdentity(runnerdStateRoot(execution));
  // The run id is intentionally different during a continuation. Reuse only
  // the verified runner/lease binding from the same company-scoped durable
  // session root; rotateLocalAuthorityEpoch then requires that exact binding
  // before it can archive the prior per-run authority.
  if (!durableIdentityMatchesSession(identity, execution)) return null;
  return {
    runnerInstanceId: identity.runnerInstanceId,
    environmentLeaseId: identity.environmentLeaseId,
  };
}

function nativeSessionConfigDigest(
  execution: NativeExecutionInput,
  executionTargetKind: "local" | "remote" = "local",
  legacyProjectlessRunId?: string,
): string {
  const executionLocation = {
    executionKind: "local_process",
    // Use the same workspace identity as the durable session scope. For a
    // projectless task, executionWorkspaceId is a per-run placeholder, not a
    // workspace change. Real workspace/provider/policy changes still fence
    // retained processes and checkpoints through the rest of this digest.
    workspaceId:
      execution.binding.executionWorkspaceId === execution.binding.runId
        ? (legacyProjectlessRunId ?? nativeSessionWorkspaceScope(execution))
        : execution.binding.executionWorkspaceId,
    cwd: execution.workspace.cwd,
  };
  return `sha256:${createHash("sha256")
    .update(
      JSON.stringify({
        companyId: execution.binding.companyId,
        normalizedSessionId: nativeSessionKey(execution),
        executionLocation,
        provider: execution.provider,
        driverKind: execution.session.driverKind,
        lifecyclePolicy: execution.session.lifecyclePolicy,
        executionMode:
          "executionMode" in execution ? execution.executionMode : "default",
        runtimeContextDigest:
          "runtimeContext" in execution
            ? execution.runtimeContext.aggregateDigest
            : null,
        // Provider threads retain their tool declarations across resume. Bump
        // this revision whenever the server-authorized native tool surface
        // changes so an older thread is rotated instead of falsely resuming
        // without newly required tools.
        nativeToolContractFingerprint:
          nativeToolContractFingerprintForTarget(executionTargetKind),
      }),
    )
    .digest("hex")}`;
}

function hasIdleWarmNativeSessionOwner(input: {
  execution: NativeExecutionInput;
  runnerExecutionTarget?: AdapterExecutionTarget | null;
  runnerEnvironment?: NodeJS.ProcessEnv;
}): boolean {
  if (managedOpenCodeRuntimeDataIsolated(input.execution, input.runnerEnvironment ?? process.env)) return false;
  if (input.execution.session.lifecyclePolicy.mode !== "warm") return false;
  const entry = warmNativeSessions.get(nativeSessionScopeKey(input.execution));
  if (!entry || entry.busy) return false;
  // A verified idle owner proves the checkpoint belongs to this session even
  // when its process must later rotate to a new run-scoped broker capability.
  // Local environments also have an id. Compare the same environment binding
  // stored at acquisition instead of treating every local target as unbound.
  const environmentId = input.runnerExecutionTarget?.environmentId ?? null;
  return (
    entry.companyId === input.execution.binding.companyId &&
    entry.environmentId === environmentId &&
    entry.configDigest ===
      nativeSessionConfigDigest(
        input.execution,
        input.runnerExecutionTarget?.kind ?? "local",
      )
  );
}

function nativeHarnessEnvironmentFingerprint(
  execution: NativeExecutionInput,
): string {
  return `sha256:${createHash("sha256")
    .update(
      canonicalJson({
        companyId: execution.binding.companyId,
        agentId: execution.binding.agentId,
        issueId: execution.binding.issueId,
        normalizedSessionId: nativeSessionKey(execution),
        workspace: {
          cwd: execution.workspace.cwd,
          repoUrl: execution.workspace.repoUrl,
          repoRef: execution.workspace.repoRef,
          branchName: execution.workspace.branchName,
        },
        provider: execution.provider,
        driverKind: execution.session.driverKind,
      }),
    )
    .digest("hex")}`;
}

type NativeProviderKind = NativeExecutionInput["provider"]["kind"];
type NativeDriverKind = NativeExecutionInput["session"]["driverKind"];

export interface NativeHarnessPersistenceDirectory {
  name: "runner" | "codex-home" | "opencode" | "acpx";
  location: "runner" | "filesystem";
  excludeEntries: readonly string[];
}

export interface NativeHarnessPersistenceProfile {
  providerKind: NativeProviderKind;
  driverKind: NativeDriverKind;
  directories: readonly NativeHarnessPersistenceDirectory[];
}

export interface NativeHarnessBackupManifest {
  schema: "paperclip.native-harness-backup.v1";
  normalizedSessionId: string;
  runnerInstanceId: string;
  providerKind: NativeProviderKind;
  driverKind: NativeDriverKind;
  providerSessionIdentity: unknown;
  sourceProviderLeaseId: string;
  environmentFingerprint: string;
  runnerContractVersion: number;
  directories: Array<{
    name: string;
    sha256: string;
    bytes: number;
  }>;
  completedAt: string;
}

export function resolveNativeHarnessPersistenceProfile(
  execution: NativeExecutionInput,
): NativeHarnessPersistenceProfile {
  const providerDirectory: NativeHarnessPersistenceDirectory | null =
    execution.provider.kind === "codex"
      ? {
          name: "codex-home",
          location: "filesystem",
          // Codex session history lives below this home, but these files are
          // launch-time material: auth.json is copied from the configured
          // credential source and config.toml can contain the native MCP
          // bearer token. Re-materialize both for a replacement sandbox
          // instead of putting credentials into the disaster-recovery copy.
          excludeEntries: CODEX_HOME_NON_PERSISTENT_ENTRIES,
        }
      : execution.provider.kind === "opencode"
        ? {
            name: "opencode",
            location: "filesystem",
            excludeEntries: [],
          }
        : execution.provider.kind === "acpx"
          ? {
              name: "acpx",
              location: "filesystem",
              // ACPX stores each provider beneath a stable session directory.
              // Codex creates process-local executable aliases in tmp/arg0;
              // they may point outside the runtime tree and are neither safe
              // nor necessary to restore. Credentials and launch-time config
              // are also re-materialized in the replacement sandbox.
              excludeEntries:
                execution.provider.agent === "codex"
                  ? CODEX_HOME_NON_PERSISTENT_ENTRIES.map(
                      (entry) =>
                        `acpx/${acpxRuntimeSessionDirectoryName(nativeSessionKey(execution))}/codex-home/${entry}`,
                    )
                  : [],
            }
          : null;
  return {
    providerKind: execution.provider.kind,
    driverKind: execution.session.driverKind,
    directories: [
      { name: "runner", location: "runner", excludeEntries: [] },
      ...(providerDirectory ? [providerDirectory] : []),
    ],
  };
}

function canonicalJson(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  if (value && typeof value === "object") {
    const entries = Object.entries(value as Record<string, unknown>).sort(
      ([left], [right]) => left.localeCompare(right),
    );
    return `{${entries.map(([key, entry]) => `${JSON.stringify(key)}:${canonicalJson(entry)}`).join(",")}}`;
  }
  return JSON.stringify(value) ?? "null";
}

function runnerProviderStateFilename(execution: NativeExecutionInput): string {
  switch (execution.provider.kind) {
    case "aw_text_only":
      throw new Error("aw_text_draft_has_no_runnerd_provider_state");
    case "codex":
    case "opencode":
      return "codex-provider-state.json";
    case "acpx":
      return "acpx-provider-state.json";
    case "claude_managed":
    case "aws_agentcore":
      return "managed-provider-state.json";
  }
}

/**
 * The v2 runner owns PRP identity/lifecycle in runner-state.json and keeps
 * provider recovery identity in a sibling provider state file. Never infer a
 * resumable provider from the outer PRP journal alone.
 */
export function providerSessionIdentityFromDurableProviderState(input: {
  execution: NativeExecutionInput;
  providerState: unknown;
}): Record<string, unknown> {
  const state = record(input.providerState);
  const expectedSessionId = nativeSessionKey(input.execution);
  const nonEmptyString = (value: unknown): value is string =>
    typeof value === "string" && value.trim().length > 0;
  const sha256 = (value: unknown): value is string =>
    typeof value === "string" && /^sha256:[0-9a-f]{64}$/.test(value);
  const emptyIdentity = () => ({
    providerSessionId: null,
    providerBackendSessionId: null,
    providerSessionIdentity: null,
  });
  switch (input.execution.provider.kind) {
    case "aw_text_only":
      return emptyIdentity();
    case "acpx": {
      const descriptor = record(state.descriptor);
      const identity = record(state.identity);
      const expectedModel = input.execution.provider.model;
      const requiredIdentityFields = [
        "kind",
        "normalizedSessionId",
        "acpxRecordId",
        "backendSessionId",
        "agentSessionId",
        "profileDigest",
        "workspaceDigest",
        "requestedModel",
        "effectiveModel",
      ] as const;
      if (
        state.schema !== ACPX_PROVIDER_STATE_SCHEMA ||
        state.lifecycle !== "suspended" ||
        state.providerExitUnconfirmed !== false ||
        state.activeTurnId !== null ||
        descriptor.kind !== "acpx" ||
        descriptor.provider !== "acpx" ||
        descriptor.driver !== "acpx_runtime" ||
        descriptor.agent !== input.execution.provider.agent ||
        descriptor.model !== expectedModel ||
        descriptor.normalizedSessionId !== expectedSessionId ||
        identity.kind !== "acpx" ||
        identity.normalizedSessionId !== expectedSessionId ||
        requiredIdentityFields.some(
          (field) => !nonEmptyString(identity[field]),
        ) ||
        !sha256(identity.profileDigest) ||
        !sha256(identity.workspaceDigest) ||
        identity.profileDigest !== descriptor.commandDigest ||
        identity.requestedModel !== expectedModel ||
        identity.effectiveModel !== expectedModel ||
        identity.permissionMode !== input.execution.provider.permissionMode ||
        !["approve-all", "approve-paperclip", "approve-reads", "deny-all"].includes(
          String(identity.permissionMode),
        ) ||
        !Array.isArray(identity.providerLifetimeFenceCandidates) ||
        identity.providerLifetimeFenceCandidates.length !== 3 ||
        new Set(identity.providerLifetimeFenceCandidates).size !== 3 ||
        identity.providerLifetimeFenceCandidates.some(
          (port) =>
            !Number.isInteger(port) ||
            Number(port) < 49_152 ||
            Number(port) > 65_535,
        )
      ) {
        return emptyIdentity();
      }
      return {
        providerSessionId: identity.acpxRecordId ?? null,
        providerBackendSessionId: identity.backendSessionId ?? null,
        providerSessionIdentity: structuredClone(identity),
      };
    }
    case "codex":
    case "opencode": {
      const config = record(state.config);
      const expectedDriver =
        input.execution.provider.kind === "codex"
          ? "codex_app_server"
          : "opencode_server";
      if (
        state.schema !== CODEX_PROVIDER_STATE_SCHEMA ||
        !["prepared", "session_open", "provider_exited"].includes(
          String(state.lifecycle),
        ) ||
        !nonEmptyString(state.threadId) ||
        (state.providerSessionId !== null &&
          state.providerSessionId !== undefined &&
          !nonEmptyString(state.providerSessionId)) ||
        state.activeProviderTurnId !== null ||
        state.ambiguousTurnStartPending === true ||
        config.provider !== input.execution.provider.kind ||
        config.driver !== expectedDriver
      ) {
        return emptyIdentity();
      }
      return {
        providerSessionId: state.threadId ?? null,
        providerBackendSessionId: state.providerSessionId ?? null,
        providerSessionIdentity: null,
      };
    }
    case "claude_managed":
    case "aws_agentcore": {
      const descriptor = record(state.descriptor);
      if (
        state.schema !== MANAGED_PROVIDER_STATE_SCHEMA ||
        state.lifecycle !== "suspended" ||
        state.normalizedSessionId !== expectedSessionId ||
        descriptor.kind !== input.execution.provider.kind ||
        !nonEmptyString(state.providerSessionId) ||
        state.activeTurnId !== null
      ) {
        return emptyIdentity();
      }
      return {
        providerSessionId: state.providerSessionId ?? null,
        providerBackendSessionId: state.providerSessionId ?? null,
        providerSessionIdentity: null,
      };
    }
  }
}

function providerSessionIdentityIsPresent(value: unknown): boolean {
  const identity = record(value);
  return (
    (identity.providerSessionId !== null &&
      identity.providerSessionId !== undefined) ||
    (identity.providerBackendSessionId !== null &&
      identity.providerBackendSessionId !== undefined) ||
    (identity.providerSessionIdentity !== null &&
      identity.providerSessionIdentity !== undefined)
  );
}

export function providerSessionIdentityTransitionIsAllowed(input: {
  execution: NativeExecutionInput;
  previous: unknown;
  current: unknown;
}): boolean {
  if (canonicalJson(input.previous) === canonicalJson(input.current)) {
    return true;
  }
  if (
    input.execution.provider.kind !== "acpx" ||
    input.execution.interactionResponses.length === 0
  ) {
    return false;
  }

  const previousOuter = record(input.previous);
  const currentOuter = record(input.current);
  const previous = record(previousOuter.providerSessionIdentity);
  const current = record(currentOuter.providerSessionIdentity);
  if (previous.kind !== "acpx" || current.kind !== "acpx") return false;

  const stableFields = [
    "normalizedSessionId",
    "profileDigest",
    "workspaceDigest",
    "requestedModel",
    "effectiveModel",
    "permissionMode",
  ] as const;
  if (
    current.normalizedSessionId !== nativeSessionKey(input.execution) ||
    stableFields.some(
      (field) =>
        typeof previous[field] !== "string" ||
        previous[field] !== current[field],
    )
  ) {
    return false;
  }

  return (
    typeof previous.acpxRecordId === "string" &&
    typeof previous.backendSessionId === "string" &&
    typeof previous.agentSessionId === "string" &&
    typeof current.acpxRecordId === "string" &&
    typeof current.backendSessionId === "string" &&
    typeof current.agentSessionId === "string" &&
    previousOuter.providerSessionId === previous.acpxRecordId &&
    previousOuter.providerBackendSessionId === previous.backendSessionId &&
    currentOuter.providerSessionId === current.acpxRecordId &&
    currentOuter.providerBackendSessionId === current.backendSessionId
  );
}

function digestBackupDirectory(directory: string): {
  sha256: string;
  bytes: number;
} {
  const hash = createHash("sha256");
  let bytes = 0;
  const visit = (current: string, relative: string) => {
    const entries = readdirSync(current, { withFileTypes: true }).sort(
      (left, right) => left.name.localeCompare(right.name),
    );
    if (entries.length === 0) hash.update(`directory:${relative}\0`);
    for (const entry of entries) {
      const entryPath = resolve(current, entry.name);
      const entryRelative = relative ? `${relative}/${entry.name}` : entry.name;
      const stats = lstatSync(entryPath);
      if (entry.isDirectory()) {
        hash.update(`directory:${entryRelative}:${stats.mode & 0o777}\0`);
        visit(entryPath, entryRelative);
      } else if (entry.isSymbolicLink()) {
        hash.update(`symlink:${entryRelative}:${readlinkSync(entryPath)}\0`);
      } else if (entry.isFile()) {
        const contents = readFileSync(entryPath);
        bytes += contents.byteLength;
        hash.update(
          `file:${entryRelative}:${stats.mode & 0o777}:${contents.byteLength}\0`,
        );
        hash.update(contents);
      } else {
        throw new Error(
          `runner_harness_backup_unsupported_entry:${entryRelative}`,
        );
      }
    }
  };
  visit(directory, "");
  return { sha256: `sha256:${hash.digest("hex")}`, bytes };
}

function harnessBackupRoot(root: string): string {
  return resolve(root, "failover-backups");
}

function harnessBackupCandidates(root: string): string[] {
  const backupRoot = harnessBackupRoot(root);
  return [resolve(backupRoot, "current"), resolve(backupRoot, "previous")];
}

type VerifiedHarnessBackup = {
  root: string;
  manifest: NativeHarnessBackupManifest;
  bytes: number;
};

export function shouldRestoreNativeHarnessBackupIntoSandbox(input: {
  acquisitionOutcome: "created" | "resumed" | "replacement" | null;
  reusableLeaseConfigured: boolean | null | undefined;
  backupAvailable: boolean;
}): boolean {
  return (
    input.acquisitionOutcome === "created" &&
    input.reusableLeaseConfigured === false &&
    input.backupAvailable
  );
}

function compatibleNativeHarnessBackupManifests(input: {
  root: string;
  execution: NativeExecutionInput;
  runnerInstanceId: string;
}): Array<{ root: string; manifest: NativeHarnessBackupManifest }> {
  const profile = resolveNativeHarnessPersistenceProfile(input.execution);
  const expectedNames = profile.directories
    .map((directory) => directory.name)
    .sort();
  const compatible: Array<{
    root: string;
    manifest: NativeHarnessBackupManifest;
  }> = [];
  for (const candidateRoot of harnessBackupCandidates(input.root)) {
    const manifestPath = resolve(candidateRoot, "manifest.json");
    if (!existsSync(manifestPath)) continue;
    let manifest: NativeHarnessBackupManifest;
    try {
      manifest = JSON.parse(
        readFileSync(manifestPath, "utf8"),
      ) as NativeHarnessBackupManifest;
    } catch {
      continue;
    }
    if (
      manifest.schema !== "paperclip.native-harness-backup.v1" ||
      manifest.normalizedSessionId !== nativeSessionKey(input.execution) ||
      manifest.runnerInstanceId !== input.runnerInstanceId ||
      manifest.providerKind !== profile.providerKind ||
      manifest.driverKind !== profile.driverKind ||
      manifest.environmentFingerprint !==
        nativeHarnessEnvironmentFingerprint(input.execution) ||
      manifest.runnerContractVersion !== RUNNERD_BINARY_CONTRACT_VERSION ||
      !providerSessionIdentityIsPresent(manifest.providerSessionIdentity) ||
      !Array.isArray(manifest.directories)
    )
      continue;
    const manifestNames = manifest.directories
      .map((directory) => directory.name)
      .sort();
    if (canonicalJson(expectedNames) !== canonicalJson(manifestNames)) continue;
    compatible.push({ root: candidateRoot, manifest });
  }
  return compatible;
}

export function buildNativeHarnessBackupManifest(input: {
  backupRoot: string;
  execution: NativeExecutionInput;
  runnerInstanceId: string;
  providerSessionIdentity: unknown;
  sourceProviderLeaseId: string;
  completedAt?: string;
}): NativeHarnessBackupManifest {
  if (!providerSessionIdentityIsPresent(input.providerSessionIdentity)) {
    throw new Error("runner_harness_state_mismatch");
  }
  const profile = resolveNativeHarnessPersistenceProfile(input.execution);
  const directories = profile.directories.map((directory) => {
    const path = resolve(input.backupRoot, directory.name);
    if (!existsSync(path)) throw new Error("runner_harness_state_mismatch");
    return { name: directory.name, ...digestBackupDirectory(path) };
  });
  return {
    schema: "paperclip.native-harness-backup.v1",
    normalizedSessionId: nativeSessionKey(input.execution),
    runnerInstanceId: input.runnerInstanceId,
    providerKind: profile.providerKind,
    driverKind: profile.driverKind,
    providerSessionIdentity: input.providerSessionIdentity,
    sourceProviderLeaseId: input.sourceProviderLeaseId,
    environmentFingerprint: nativeHarnessEnvironmentFingerprint(
      input.execution,
    ),
    runnerContractVersion: RUNNERD_BINARY_CONTRACT_VERSION,
    directories,
    completedAt: input.completedAt ?? new Date().toISOString(),
  };
}

export function verifyNativeHarnessBackup(input: {
  root: string;
  execution: NativeExecutionInput;
  runnerInstanceId: string;
}): VerifiedHarnessBackup | null {
  for (const {
    root: candidateRoot,
    manifest,
  } of compatibleNativeHarnessBackupManifests(input)) {
    let bytes = 0;
    let valid = true;
    for (const declared of manifest.directories) {
      const directoryPath = resolve(candidateRoot, declared.name);
      if (!existsSync(directoryPath)) {
        valid = false;
        break;
      }
      try {
        const digest = digestBackupDirectory(directoryPath);
        if (
          digest.sha256 !== declared.sha256 ||
          digest.bytes !== declared.bytes
        ) {
          valid = false;
          break;
        }
        bytes += digest.bytes;
      } catch {
        valid = false;
        break;
      }
    }
    if (valid) return { root: candidateRoot, manifest, bytes };
  }
  return null;
}

function nativeSessionCheckpointDirectory(): string {
  const directory = resolve(
    resolvePaperclipInstanceRoot(),
    "runtime",
    "paperclip-runner",
    "sessions",
  );
  mkdirSync(directory, { recursive: true, mode: 0o700 });
  chmodSync(directory, 0o700);
  return directory;
}

function nativeSessionCheckpointPath(execution: NativeExecutionInput): string {
  return resolve(
    nativeSessionCheckpointDirectory(),
    `${createHash("sha256")
      .update(nativeSessionScopeKey(execution))
      .digest("hex")}.json`,
  );
}

function legacyCompanyNativeSessionCheckpointPath(
  execution: NativeExecutionInput,
): string {
  return resolve(
    nativeSessionCheckpointDirectory(),
    `${createHash("sha256")
      .update(legacyCompanyNativeSessionScopeKey(execution))
      .digest("hex")}.json`,
  );
}

function legacyNativeSessionCheckpointPath(
  execution: NativeExecutionInput,
): string {
  return resolve(
    nativeSessionCheckpointDirectory(),
    `${createHash("sha256")
      .update(nativeSessionKey(execution))
      .digest("hex")}.json`,
  );
}

function persistWarmNativeCheckpoint(
  execution: NativeExecutionInput,
  configDigest: string,
  snapshot: PersistedNativeSession,
): void {
  const path = nativeSessionCheckpointPath(execution);
  const temporary = `${path}.${process.pid}.${randomUUID()}.tmp`;
  writeFileSync(
    temporary,
    JSON.stringify({
      schema: "paperclip.native-session-supervisor.v1",
      configDigest,
      updatedAt: new Date().toISOString(),
      snapshot,
    }),
    { encoding: "utf8", mode: 0o600 },
  );
  renameSync(temporary, path);
  chmodSync(path, 0o600);
}

function loadWarmNativeCheckpoint(
  execution: NativeExecutionInput,
  configDigest: string,
  executionTargetKind: "local" | "remote" = "local",
): PersistedNativeSession | null {
  const scopedPath = nativeSessionCheckpointPath(execution);
  const path = [
    scopedPath,
    legacyCompanyNativeSessionCheckpointPath(execution),
    legacyNativeSessionCheckpointPath(execution),
  ].find((candidate) => existsSync(candidate));
  if (!path) return null;
  const envelope = JSON.parse(
    readBoundedNativeFile(
      path,
      NATIVE_WARM_CHECKPOINT_MAX_BYTES,
      "native_session_supervisor_checkpoint_too_large",
    ).toString("utf8"),
  ) as {
    schema?: string;
    configDigest?: string;
    snapshot?: PersistedNativeSession;
  };
  if (
    envelope.schema !== "paperclip.native-session-supervisor.v1" ||
    !envelope.snapshot
  ) {
    throw new Error("native_session_supervisor_checkpoint_mismatch");
  }
  const persistedIdentity = record(envelope.snapshot.identity);
  if (
    persistedIdentity.sessionId !== nativeSessionKey(execution) ||
    persistedIdentity.companyId !== execution.binding.companyId ||
    persistedIdentity.agentId !== execution.binding.agentId
  ) {
    throw new Error("native_session_supervisor_checkpoint_mismatch");
  }
  // Upgrade old projectless checkpoints using their validated prior run id.
  // Every provider/model/runtime-context/permission field must still match;
  // only the old per-run workspace placeholder is normalized away.
  const legacyDigest =
    execution.binding.executionWorkspaceId === execution.binding.runId &&
    typeof persistedIdentity.runId === "string"
      ? nativeSessionConfigDigest(
          execution,
          executionTargetKind,
          persistedIdentity.runId,
        )
      : null;
  if (
    envelope.configDigest !== configDigest &&
    envelope.configDigest !== legacyDigest
  ) {
    return null;
  }
  const sameRunRecovery =
    persistedIdentity.runId === execution.binding.runId &&
    persistedIdentity.issueId === execution.binding.issueId;
  const resumed = sameRunRecovery
    ? structuredClone(envelope.snapshot)
    : {
        ...envelope.snapshot,
        identity: {
          runId: execution.binding.runId,
          sessionId: nativeSessionKey(execution),
          companyId: execution.binding.companyId,
          issueId: execution.binding.issueId,
          agentId: execution.binding.agentId,
        },
        // A warm provider can be rebound only after the previous run settled.
        // Its provider identity survives, but run-scoped turn, result, and
        // request authority must not cross into the new heartbeat run.
        semanticResult: null,
        terminal: null,
        activeTurnId: null,
        terminalTurns: [],
        pendingRuntimeRequests: [],
      };
  if (path !== scopedPath || envelope.configDigest !== configDigest) {
    // Upgrade the validated checkpoint atomically. When moving from a legacy
    // path, retain that file so an interrupted migration remains replayable.
    persistWarmNativeCheckpoint(execution, configDigest, resumed);
  }
  return resumed;
}

async function releaseWarmNativeSession(
  sessionId: string,
  ownerToken: symbol,
  idleTimeoutMs: number,
  failed: boolean,
): Promise<void> {
  const entry = warmNativeSessions.get(sessionId);
  // A late completion or cleanup callback from an older execution must never
  // release a replacement that has since claimed the same logical session.
  if (!entry || entry.ownerToken !== ownerToken) return;
  entry.busy = false;
  entry.lastActivityAt = new Date().toISOString();
  if (entry.idleTimer !== null) clearTimeout(entry.idleTimer);
  if (failed || entry.closeOnReleaseReason !== undefined) {
    warmNativeSessions.delete(sessionId);
    const closing = closeWarmNativeSession(entry,
      entry.closeOnReleaseReason ?? "warm native session failed");
    // Restart checkpointing is required to restore this successful session.
    // Surface failure instead of reporting a clean release without authority.
    if (entry.closeOnReleaseReason !== undefined) await closing;
    else await closing.catch(() => undefined);
    return;
  }
  entry.idleTimer = setTimeout(() => {
    const current = warmNativeSessions.get(sessionId);
    // clearTimeout cannot revoke an already-queued callback. The entry object
    // is the idle timer's ownership fence across a later warm acquisition.
    if (current !== entry || current.busy) return;
    warmNativeSessions.delete(sessionId);
    void closeWarmNativeSession(current, "warm native session idle timeout")
      .catch(() => undefined);
  }, idleTimeoutMs);
  entry.idleTimer.unref();
}

/** Classify only a committed provider terminal, never model prose or tool output. */
export function nativeProviderUsageLimitFromEvent(
  event: Pick<PrpEvent, "sourceKind" | "eventType" | "payload">,
): boolean {
  const payload = record(event.payload);
  return (
    event.sourceKind === "runner" &&
    event.eventType === "turn.failed" &&
    payload.status === "failed" &&
    record(payload.error).codexErrorInfo === "usageLimitExceeded"
  );
}

export function nativeSessionFailureDisposition(
  attempt: number,
  now = new Date(),
  sourceFailureCode?: ReturnType<typeof nativeSessionFailureSourceCode>,
) {
  const permanentFailure =
    sourceFailureCode === "native_provider_model_rejected" ||
    sourceFailureCode === "native_provider_approval_required" ||
    sourceFailureCode === "native_event_replay_conflict" ||
    sourceFailureCode === "runner_remote_provider_artifact_incompatible" ||
    sourceFailureCode === "native_provider_terminal_failed" ||
    sourceFailureCode === "native_current_wake_comments_unread" ||
    sourceFailureCode === "native_current_wake_comments_changed_after_read" ||
    sourceFailureCode === "native_session_cleanup_quarantined" ||
    sourceFailureCode === "native_adopted_runner_authentication_timeout" ||
    sourceFailureCode === "native_provider_usage_limit";
  const exhausted = permanentFailure || attempt >= 3;
  return {
    phase: exhausted
      ? ("terminal_failure" as const)
      : ("retryable_failure" as const),
    failureCode: permanentFailure
      ? sourceFailureCode!
      : exhausted
        ? ("native_session_retry_exhausted" as const)
        : ("native_session_interrupted" as const),
    nextAttemptAt: exhausted ? null : new Date(now.getTime() + 30_000),
  };
}

export function nativeSessionRecoveryProjection(input: {
  phase: "retryable_failure" | "terminal_failure";
  failureCode: string;
  agentId: string;
}) {
  const exhausted = input.phase === "terminal_failure";
  return {
    exhausted,
    issueStatus:
      exhausted &&
      input.failureCode !== NATIVE_ADOPTED_RUNNER_AUTHENTICATION_TIMEOUT
        ? ("blocked" as const)
        : null,
    recoveryOwner: exhausted
      ? { kind: "board" as const }
      : { kind: "agent" as const, agentId: input.agentId },
    recoveryActionOwnerType: exhausted
      ? ("board" as const)
      : ("agent" as const),
    recoveryActionOwnerAgentId: exhausted ? null : input.agentId,
    recoveryActionCause: input.failureCode,
    supersedeOnIdentityChange: true as const,
  };
}

export function nativeSessionFailureSourceCode(
  error: unknown,
):
  | "native_provider_terminal_failed"
  | "native_provider_approval_required"
  | "native_provider_usage_limit"
  | "native_session_cleanup_quarantined"
  | "native_adopted_runner_authentication_timeout"
  | "runner_remote_provider_artifact_incompatible"
  | "provider_process_exited"
  | "provider_stdout_closed"
  | "provider_process_output_closed"
  | "provider_process_status_failed"
  | "provider_initialize_timeout"
  | "provider_initialize_protocol_error"
  | "provider_request_timeout"
  | "provider_request_protocol_error"
  | "provider_frame_too_large"
  | "provider_transport_failed"
  | "native_runner_process_exited"
  | "planning_mode_unsupported"
  | "native_event_replay_conflict"
  | "native_provider_model_rejected"
  | "native_current_wake_comments_unread"
  | "native_current_wake_comments_changed_after_read"
  | "native_session_interrupted" {
  if (error instanceof NativeProviderTerminalFailure) {
    if (error.providerCode === "approval_required") return "native_provider_approval_required";
    // Failed terminals retain their security meaning across the provider facade.
    // A stopped process is insufficient evidence to recover an integrity breach.
    if (
      /(?:binding_mismatch|start_mismatch|replay_conflict|digest_mismatch|invalid_semantic_result|conflicting_semantic_result|provider_event_type_invalid)/.test(
        error.providerCode,
      )
    )
      return "native_event_replay_conflict";
    return "native_provider_terminal_failed";
  }
  if (error instanceof NativeSessionProtocolIntegrityError)
    return "native_event_replay_conflict";
  if (error instanceof NativeSessionCleanupQuarantinedError)
    return "native_session_cleanup_quarantined";
  const message = error instanceof Error ? error.message : String(error);
  if (/native_provider_model_rejected/i.test(message))
    return "native_provider_model_rejected";
  if (/native_adopted_runner_authentication_timeout/i.test(message)) {
    return "native_adopted_runner_authentication_timeout";
  }
  if (/runner_remote_provider_artifact_incompatible/i.test(message)) {
    return "runner_remote_provider_artifact_incompatible";
  }
  if (/provider_process_exited/i.test(message)) {
    return "provider_process_exited";
  }
  if (/provider_stdout_closed/i.test(message)) {
    return "provider_stdout_closed";
  }
  if (/provider_process_output_closed/i.test(message)) {
    return "provider_process_output_closed";
  }
  if (/provider_process_status_failed/i.test(message)) {
    return "provider_process_status_failed";
  }
  if (/provider_initialize_timeout/i.test(message)) {
    return "provider_initialize_timeout";
  }
  if (/provider_initialize_protocol_error/i.test(message)) {
    return "provider_initialize_protocol_error";
  }
  if (/provider_request_timeout/i.test(message)) {
    return "provider_request_timeout";
  }
  if (/provider_request_protocol_error/i.test(message)) {
    return "provider_request_protocol_error";
  }
  if (/provider_frame_too_large|stdout frame exceeded/i.test(message)) {
    return "provider_frame_too_large";
  }
  if (
    /provider_transport_failed|invalid JSON-RPC|provider failed/i.test(message)
  ) {
    return "provider_transport_failed";
  }
  if (
    /native_runner_process_exited|runnerd exited|runner process failed/i.test(
      message,
    )
  ) {
    return "native_runner_process_exited";
  }
  if (/planning_mode_unsupported/i.test(message)) {
    return "planning_mode_unsupported";
  }
  if (/native_event_replay_conflict/i.test(message)) {
    return "native_event_replay_conflict";
  }
  if (/native_current_wake_comments_changed_after_read/i.test(message)) {
    return "native_current_wake_comments_changed_after_read";
  }
  if (/native_current_wake_comments_unread/i.test(message)) {
    return "native_current_wake_comments_unread";
  }
  return "native_session_interrupted";
}

const NATIVE_CLEANUP_OPERATOR_RECOVERY_MESSAGE =
  "Send a new message to continue after Paperclip verifies that the previous provider and its tools have stopped. If cleanup cannot be verified, inspect the run and its environment. Clearing a task session does not resolve this quarantine. Automatic retries are stopped.";

const PROVIDER_DURABLE_EVENT_TYPES = new Set([
  "harness.ready",
  "session.started",
  "session.resumed",
  "session.updated",
  "turn.started",
  "provider.event",
  "provider.rpc_result",
]);

type NativeRecoveryMode =
  "bootstrap_retry" | "exact_checkpoint_resume" | "ambiguous_state";

export async function nativeProviderRecoveryEvidence(input: {
  db: Db;
  runId: string;
  sourceFailureCode: ReturnType<typeof nativeSessionFailureSourceCode>;
}): Promise<{
  recoveryMode: NativeRecoveryMode;
  providerSessionEstablished: boolean;
  providerEventsExist: boolean;
  checkpointExists: boolean;
}> {
  const run = await input.db
    .select({ runnerProfileJson: heartbeatRuns.runnerProfileJson })
    .from(heartbeatRuns)
    .where(eq(heartbeatRuns.id, input.runId))
    .limit(1)
    .then((rows) => rows[0] ?? null);
  const checkpoint = record(run?.runnerProfileJson).sessionCheckpoint;
  const checkpointRecord = record(checkpoint);
  const checkpointExists = Object.keys(checkpointRecord).length > 0;
  const providerSessionEstablished =
    (typeof checkpointRecord.providerSessionId === "string" &&
      checkpointRecord.providerSessionId.length > 0) ||
    Object.keys(record(checkpointRecord.providerIdentity)).length > 0;
  const durableEvents = await input.db
    .select({ eventType: heartbeatRunEvents.eventType })
    .from(heartbeatRunEvents)
    .where(
      and(
        eq(heartbeatRunEvents.runId, input.runId),
        inArray(heartbeatRunEvents.eventType, [
          ...PROVIDER_DURABLE_EVENT_TYPES,
        ]),
      ),
    )
    .limit(1);
  const providerEventsExist = durableEvents.some((event) =>
    PROVIDER_DURABLE_EVENT_TYPES.has(event.eventType),
  );
  if (
    checkpointExists &&
    providerSessionEstablished &&
    record(checkpointRecord.terminal).runTerminalState !== "failed"
  ) {
    return {
      recoveryMode: "exact_checkpoint_resume",
      providerSessionEstablished: true,
      providerEventsExist,
      checkpointExists,
    };
  }
  const definitelyPreSession = new Set<
    ReturnType<typeof nativeSessionFailureSourceCode>
  >([
    "runner_remote_provider_artifact_incompatible",
    "provider_process_exited",
    "provider_stdout_closed",
    "provider_process_output_closed",
    "provider_process_status_failed",
    "provider_initialize_timeout",
    "provider_initialize_protocol_error",
    "provider_request_timeout",
    "provider_request_protocol_error",
    "native_runner_process_exited",
  ]).has(input.sourceFailureCode);
  if (!checkpointExists && !providerEventsExist && definitelyPreSession) {
    return {
      recoveryMode: "bootstrap_retry",
      providerSessionEstablished: false,
      providerEventsExist: false,
      checkpointExists: false,
    };
  }
  return {
    recoveryMode: "ambiguous_state",
    providerSessionEstablished:
      providerSessionEstablished || providerEventsExist,
    providerEventsExist,
    checkpointExists,
  };
}

function record(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : {};
}

/** Unknown same-run Native reads are monotonic: a later qualified read cannot
 * repair an earlier result whose owner roots were unavailable. Check these
 * persisted observations at every managed output-capture boundary. */
export function assertNativeRunReadSourceHistoryQualified(profile: Record<string, unknown>, input: {
  runId: string; responsibleUserId: string | null;
}): void {
  const deny = () => { throw new Error("native_read_result_source_history_unavailable"); };
  const receipt = nativeRunInputSourceReceiptSchema.safeParse(profile.nativeInputSourceReceipt);
  const rawCaptures = profile.nativeToolResultSourceCaptures;
  if (rawCaptures !== undefined && !Array.isArray(rawCaptures)) deny();
  for (const raw of (rawCaptures as unknown[] | undefined) ?? []) {
    const capture = record(raw);
    const isReadTool = ["get_task_context", "get_task_history", "read_chat_attachment", "query_business_metric"].includes(String(capture.tool));
    if (isReadTool && capture.nativeReadResult !== true) deny();
    if (capture.nativeReadResult !== true) continue;
    const sourceResult = nativePayloadSourceInputSchema.safeParse(capture.source);
    const sourceSetValue = record(capture.sourceSet);
    const sourcePolicy = nativePayloadSourcePolicySchema.safeParse(sourceSetValue.policy);
    const sourceInputs = nativePayloadSourceInputSchema.array().safeParse(sourceSetValue.inputs);
    const capturedInputs = nativePayloadSourceInputSchema.array().safeParse(capture.sourceInputs);
    if (!raw || typeof raw !== "object" || Array.isArray(raw) || !receipt.success || !sourceResult.success ||
      sourceResult.data.kind !== "tool_result" || sourceResult.data.runId !== input.runId || sourceResult.data.invocationId !== null ||
      sourceResult.data.callId !== capture.callId || sourceResult.data.toolName !== capture.tool ||
      sourceResult.data.contentHash !== capture.resultDigest || !sourcePolicy.success || !sourceInputs.success ||
      !capturedInputs.success || !isDeepStrictEqual(capturedInputs.data, sourceInputs.data) ||
      !["get_task_context", "get_task_history", "read_chat_attachment", "query_business_metric"].includes(String(capture.tool)) ||
      typeof capture.turnId !== "string" || !/^[0-9a-f]{64}$/.test(String(capture.argumentsHash)) ||
      !receipt.data.additionalInputs.some(entry => entry.responsibleUserId === input.responsibleUserId &&
        isDeepStrictEqual(entry.policy, sourcePolicy.data) &&
        isDeepStrictEqual(entry.inputs, [sourceResult.data, ...sourceInputs.data]))) deny();
  }
  const rawProcedureReads = profile.nativeRuntimeProcedureReadObservations;
  if (rawProcedureReads !== undefined && !Array.isArray(rawProcedureReads)) deny();
  const procedureObservationIds = new Set<string>();
  for (const raw of (rawProcedureReads as unknown[] | undefined) ?? []) {
    const observation = record(raw);
    const source = nativePayloadSourceInputSchema.safeParse(observation.source);
    const exactReceiptCopy = receipt.success && source.success && receipt.data.additionalInputs.some(entry =>
      entry.responsibleUserId === input.responsibleUserId && entry.inputs.some(value => isDeepStrictEqual(value, source.data)));
    if (!raw || typeof raw !== "object" || Array.isArray(raw) ||
      Object.keys(observation).some(key => !["observationId", "kind", "resultDigest", "sourceQualified", "source"].includes(key)) ||
      observation.sourceQualified !== true ||
      typeof observation.observationId !== "string" || !/^[0-9a-f-]{36}$/i.test(observation.observationId) ||
      procedureObservationIds.has(observation.observationId) ||
      typeof observation.resultDigest !== "string" || !/^[0-9a-f]{64}$/.test(observation.resultDigest) ||
      (observation.kind !== "skill_version" && observation.kind !== "playbook_revision") ||
      !source.success || source.data.kind !== observation.kind || !exactReceiptCopy) deny();
    procedureObservationIds.add(observation.observationId as string);
  }
}

type FirstAgentEventKind =
  | "reasoning"
  | "agentMessage"
  | "toolCall"
  | "dynamicToolCall";

/** Returns the first provider activity worth measuring after turn.started. */
export function firstMeaningfulAgentEventKind(
  event: Pick<PrpEvent, "eventType" | "payload">,
): FirstAgentEventKind | null {
  const payload = record(event.payload);
  if (event.eventType === "tool.execution.started") {
    return typeof payload.executionId === "string" &&
      payload.executionId.trim()
      ? "toolCall"
      : null;
  }
  if (
    event.eventType !== "item.started" &&
    event.eventType !== "item.delta" &&
    event.eventType !== "item.completed"
  ) return null;
  const kind = payload.kind;
  if (
    kind !== "reasoning" &&
    kind !== "agentMessage" &&
    kind !== "toolCall" &&
    kind !== "dynamicToolCall"
  ) return null;
  if (event.eventType !== "item.delta") return kind;
  const text = [payload.text, payload.delta, payload.content].find(
    (value): value is string => typeof value === "string" && value.trim().length > 0,
  );
  return text ? kind : null;
}

export type NativeSessionSteeringState = {
  disposition: "available" | "unsupported" | "temporarily_unavailable";
  activeTurnId: string | null;
};

export class NativeSessionSteeringError extends Error {
  constructor(
    readonly code:
      | "steering_unsupported"
      | "steering_temporarily_unavailable"
      | "steering_stale_turn"
      | "steering_timeout"
      | "steering_rejected",
    message: string,
  ) {
    super(message);
    this.name = "NativeSessionSteeringError";
  }
}

export class NativeRuntimeRequestResolutionError extends Error {
  constructor(
    readonly code:
      | "native_session_not_active"
      | "runtime_request_resolution_unsupported"
      | "runtime_request_stale_turn"
      | "runtime_request_resolution_conflict",
    message: string,
  ) {
    super(message);
    this.name = "NativeRuntimeRequestResolutionError";
  }
}

/** Resolve a provider runtime request on an in-process native backend. */
export async function resolveNativeRuntimeRequest(input: {
  runId: string;
  requestId: string;
  turnId: string;
  resolution: HarnessRuntimeRequestResolution;
  /**
   * Revalidate the caller's durable lifecycle and authorization immediately
   * before the provider mutation. Capability and snapshot reads above this
   * edge are asynchronous, so route-level checks performed before entering
   * this helper are not sufficient to authorize the eventual dispatch.
   */
  authorizeBeforeDispatch: () => Promise<void>;
}): Promise<{ commandId: string }> {
  const active = activeNativeSessions.get(input.runId);
  if (!active) {
    throw new NativeRuntimeRequestResolutionError(
      "native_session_not_active",
      "The active native session is not attached.",
    );
  }
  const capabilities = await active.session.capabilities();
  if (
    !capabilities.runtimeRequestResolution ||
    active.session.resolveRuntimeRequest === undefined
  ) {
    throw new NativeRuntimeRequestResolutionError(
      "runtime_request_resolution_unsupported",
      "This native session does not resolve runtime requests in-process.",
    );
  }
  const snapshot = await active.session.snapshot();
  if (snapshot.activeTurnId !== input.turnId) {
    throw new NativeRuntimeRequestResolutionError(
      "runtime_request_stale_turn",
      "The runtime request belongs to a turn that is no longer active.",
    );
  }

  const key = `${input.runId}:${input.requestId}`;
  const fingerprint = JSON.stringify({
    turnId: input.turnId,
    resolution: input.resolution,
  });
  const prior = nativeRuntimeRequestResolutions.get(key);
  if (prior) {
    if (prior.fingerprint !== fingerprint) {
      throw new NativeRuntimeRequestResolutionError(
        "runtime_request_resolution_conflict",
        "A different response was already submitted for this runtime request.",
      );
    }
    await prior.pending;
    return { commandId: prior.commandId };
  }

  const commandId = `native-runtime-response:${randomUUID()}`;
  // Reserve the request key before yielding to authorization or provider I/O.
  // This makes duplicate retries join one dispatch and makes a conflicting
  // response fail closed even while the first authorization check is pending.
  const pending = Promise.resolve().then(async () => {
    await input.authorizeBeforeDispatch();
    if (activeNativeSessions.get(input.runId) !== active) {
      throw new NativeRuntimeRequestResolutionError(
        "native_session_not_active",
        "The active native session changed before the response was dispatched.",
      );
    }
    await active.session.resolveRuntimeRequest!({
      requestId: input.requestId,
      turnId: input.turnId,
      resolution: input.resolution,
    });
  });
  const resolution: NativeRuntimeRequestResolution = {
    runId: input.runId,
    fingerprint,
    commandId,
    pending,
    completedAt: null,
  };
  nativeRuntimeRequestResolutions.set(key, resolution);
  try {
    await pending;
    resolution.completedAt = Date.now();
    pruneNativeRuntimeRequestResolutionCache();
    return { commandId };
  } catch (error) {
    if (nativeRuntimeRequestResolutions.get(key) === resolution) {
      nativeRuntimeRequestResolutions.delete(key);
    }
    throw error;
  }
}

export async function getNativeSessionSteeringState(
  runId: string,
): Promise<NativeSessionSteeringState> {
  const active = activeNativeSessions.get(runId);
  if (!active)
    return { disposition: "temporarily_unavailable", activeTurnId: null };
  const capabilities = await active.session.capabilities();
  if (!capabilities.steering || !active.session.steer) {
    return { disposition: "unsupported", activeTurnId: null };
  }
  const snapshot = await active.session.snapshot();
  return {
    disposition: snapshot.activeTurnId
      ? "available"
      : "temporarily_unavailable",
    activeTurnId: snapshot.activeTurnId ?? null,
  };
}

// Receipts live as long as this controller process. Durable identity reservations
// hold credential acquisition after a restart until a provider receipt is known.
const steeringDeliveries = new Map<string, Promise<{ turnId: string }>>();
function clearSteeringDeliveries(runId: string) {
  for (const key of steeringDeliveries.keys())
    if (key.startsWith(`${runId}:`)) steeringDeliveries.delete(key);
}

/** Dispatches a true same-turn steering message and resolves only after ack. */
export async function steerNativeSession(input: {
  runId: string;
  message: string;
  correlationId: string;
  timeoutMs?: number;
  onAcknowledged?: () => Promise<void>;
}): Promise<{ turnId: string }> {
  const active = activeNativeSessions.get(input.runId);
  if (!active) {
    throw new NativeSessionSteeringError(
      "steering_temporarily_unavailable",
      "The active native session is not attached.",
    );
  }
  const capabilities = await active.session.capabilities();
  if (!capabilities.steering || !active.session.steer) {
    throw new NativeSessionSteeringError(
      "steering_unsupported",
      "This provider does not support same-turn steering.",
    );
  }
  const snapshot = await active.session.snapshot();
  const turnId = snapshot.activeTurnId ?? null;
  if (!turnId) {
    throw new NativeSessionSteeringError(
      "steering_stale_turn",
      "The target turn is no longer active.",
    );
  }

  const deliveryKey = `${input.runId}:${input.correlationId}`;
  let delivery = steeringDeliveries.get(deliveryKey);
  if (!delivery) {
    delivery = active.session
      .steer({
        turnId,
        message: { role: "user", text: input.message },
        correlationId: input.correlationId,
      })
      .then(() => ({ turnId }));
    steeringDeliveries.set(deliveryKey, delivery);
    void delivery.catch(() => {
      steeringDeliveries.delete(deliveryKey);
    });
  }
  // Do not await the persistence callback here: the route holds the run lock
  // until acknowledgement. After a timeout this callback can acquire that lock.
  if (input.onAcknowledged)
    void delivery.then(input.onAcknowledged).catch(() => undefined);
  let timeout: ReturnType<typeof setTimeout> | null = null;
  try {
    const acknowledged = await Promise.race([
      delivery,
      new Promise<never>((_resolve, reject) => {
        timeout = setTimeout(
          () =>
            reject(
              new NativeSessionSteeringError(
                "steering_timeout",
                "The provider did not acknowledge steering in time.",
              ),
            ),
          input.timeoutMs ?? 10_000,
        );
      }),
    ]);
    return acknowledged;
  } catch (error) {
    if (error instanceof NativeSessionSteeringError) throw error;
    const message = error instanceof Error ? error.message : String(error);
    if (/stale|terminal|active turn/i.test(message)) {
      throw new NativeSessionSteeringError(
        "steering_stale_turn",
        "The target turn is no longer active.",
      );
    }
    if (/unsupported|unavailable|capability/i.test(message)) {
      throw new NativeSessionSteeringError(
        "steering_unsupported",
        "This provider does not support same-turn steering.",
      );
    }
    throw new NativeSessionSteeringError(
      "steering_rejected",
      "The provider rejected the steering message.",
    );
  } finally {
    if (timeout) clearTimeout(timeout);
  }
}

export function cancelNativeSession(
  runId: string,
  reason: string,
): Promise<boolean>;
export function cancelNativeSession(
  runId: string,
  reason: string,
  options: {
    db: Db;
    scope?: "turn" | "run" | "issue";
    replacementAccepted?: boolean;
  },
): Promise<{
  dispatched: boolean;
  decision: NativeStatusDecision | null;
  decisionId: string | null;
  auditId: string | null;
}>;
export async function cancelNativeSession(
  runId: string,
  reason: string,
  options?: {
    db: Db;
    scope?: "turn" | "run" | "issue";
    replacementAccepted?: boolean;
  },
): Promise<
  | boolean
  | {
      dispatched: boolean;
      decision: NativeStatusDecision | null;
      decisionId: string | null;
      auditId: string | null;
    }
> {
  recordNativeCancelOriginTestFact(runId, {
    stage: "cancel_native_session",
    reason: cancellationReasonClass(reason),
  });
  const runStop = (options?.scope ?? "run") === "run";
  let decision: NativeStatusDecision | null = null;
  let decisionContext: {
    companyId: string;
    issueId: string;
    assessmentId: string | null;
    priorStatus: string;
    priorStatusVersion: number;
    priorDecisionId: string | null;
    coordinatorDecisionId: string | null;
    agentId: string;
  } | null = null;
  if (options) {
    const run = await options.db
      .select({
        agentId: heartbeatRuns.agentId,
        companyId: heartbeatRuns.companyId,
        nativeIssueId: heartbeatRuns.nativeIssueId,
        runtimeMode: heartbeatRuns.runtimeMode,
        status: heartbeatRuns.status,
        nativePhase: heartbeatRuns.nativePhase,
        errorCode: heartbeatRuns.errorCode,
      })
      .from(heartbeatRuns)
      .where(eq(heartbeatRuns.id, runId))
      .limit(1)
      .then((rows) => rows[0] ?? null);
    if (run?.runtimeMode === "native") {
      if (isNativeRunnerOwnershipHeld(run))
        throw new NativeRunnerOwnershipUnverifiedError();
      const issueId = run.nativeIssueId;
      if (!issueId) throw new Error("native_cancellation_binding_missing");
      const issue = await options.db
        .select({
          status: issues.status,
          statusVersion: issues.statusVersion,
          lastStatusDecisionId: issues.lastStatusDecisionId,
        })
        .from(issues)
        .where(and(eq(issues.id, issueId), eq(issues.companyId, run.companyId)))
        .limit(1)
        .then((rows) => rows[0] ?? null);
      if (!issue) throw new Error("native_cancellation_binding_missing");
      const coordinator = await options.db
        .select({
          assessmentId: nativeRunFinalizations.assessmentId,
          decisionId: nativeRunFinalizations.decisionId,
        })
        .from(nativeRunFinalizations)
        .where(
          and(
            eq(nativeRunFinalizations.runId, runId),
            eq(nativeRunFinalizations.companyId, run.companyId),
            eq(nativeRunFinalizations.issueId, issueId),
          ),
        )
        .limit(1)
        .then((rows) => rows[0] ?? null);
      if (!coordinator)
        throw new Error("native_cancellation_coordinator_missing");
      decision = resolveNativeCancellationStatus({
        scope: options.scope ?? "run",
        priorIssueStatus: issue.status as NativeAuthoritativeIssueStatus,
        agentId: run.agentId,
        replacementAccepted: options.replacementAccepted,
      });
      decisionContext = {
        companyId: run.companyId,
        issueId,
        assessmentId: coordinator.assessmentId ?? null,
        priorStatus: issue.status,
        priorStatusVersion: Number(issue.statusVersion),
        priorDecisionId: issue.lastStatusDecisionId,
        coordinatorDecisionId: coordinator.decisionId ?? null,
        agentId: run.agentId,
      };
    }
  }
  let decisionId: string | null = null;
  let auditId: string | null = null;
  let cancellationIntentId: string | null = null;
  let recoveringCancellationIntent = false;
  let priorCoordinatorDecisionIdAtIntent: string | null = null;
  if (options && decision && decisionContext) {
    const cancellationDecision = decision;
    const cancellationContext = decisionContext;
    const effects = cancellationDecision.effects.map((effect) => effect.kind);
    let intentPublication: Parameters<typeof publishActivity>[0] | null = null;
    const intent = await options.db.transaction(async (tx) => {
      const lockedRun = await tx
        .select({
          agentId: heartbeatRuns.agentId,
          companyId: heartbeatRuns.companyId,
          nativeIssueId: heartbeatRuns.nativeIssueId,
          resultJson: heartbeatRuns.resultJson,
          runtimeMode: heartbeatRuns.runtimeMode,
          status: heartbeatRuns.status,
          nativePhase: heartbeatRuns.nativePhase,
          errorCode: heartbeatRuns.errorCode,
        })
        .from(heartbeatRuns)
        .where(eq(heartbeatRuns.id, runId))
        .for("update")
        .limit(1)
        .then((rows) => rows[0] ?? null);
      if (
        !lockedRun ||
        lockedRun.runtimeMode !== "native" ||
        lockedRun.companyId !== cancellationContext.companyId ||
        lockedRun.agentId !== cancellationContext.agentId ||
        lockedRun.nativeIssueId !== cancellationContext.issueId
      ) {
        throw new Error("native_cancellation_binding_changed");
      }
      if (isNativeRunnerOwnershipHeld(lockedRun))
        throw new NativeRunnerOwnershipUnverifiedError();
      const coordinator = await tx
        .select({ runId: nativeRunFinalizations.runId })
        .from(nativeRunFinalizations)
        .where(
          and(
            eq(nativeRunFinalizations.runId, runId),
            eq(nativeRunFinalizations.companyId, cancellationContext.companyId),
            eq(nativeRunFinalizations.issueId, cancellationContext.issueId),
          ),
        )
        .limit(1)
        .then((rows) => rows[0] ?? null);
      if (!coordinator)
        throw new Error("native_cancellation_coordinator_missing");

      const resultJson = record(lockedRun.resultJson);
      const existing = record(resultJson.nativeCancellation);
      const existingIntentId =
        typeof existing.intentId === "string" && existing.intentId.length > 0
          ? existing.intentId
          : null;
      if (existingIntentId) {
        const matchingIntent =
          existing.schema === "paperclip.native-cancellation.v1" &&
          existing.companyId === cancellationContext.companyId &&
          existing.runId === runId &&
          existing.issueId === cancellationContext.issueId &&
          existing.scope === (options.scope ?? "run") &&
          existing.reasonCode === cancellationDecision.reasonCode &&
          JSON.stringify(existing.effects) === JSON.stringify(effects);
        if (!matchingIntent)
          throw new Error("native_cancellation_intent_conflict");
        const existingAuditId =
          typeof existing.intentAuditId === "string" &&
          existing.intentAuditId.length > 0
            ? existing.intentAuditId
            : null;
        if (!existingAuditId)
          throw new Error("native_cancellation_intent_audit_missing");
        return {
          intentId: existingIntentId,
          auditId: existingAuditId,
          acknowledged: existing.dispatchState === "acknowledged",
          dispatched: existing.dispatched === true,
          decisionId:
            typeof existing.decisionId === "string"
              ? existing.decisionId
              : null,
          priorCoordinatorDecisionId:
            typeof existing.priorCoordinatorDecisionId === "string"
              ? existing.priorCoordinatorDecisionId
              : null,
          existing: true,
        };
      }

      const intentId = `native-cancellation:${randomUUID()}`;
      const activity = await persistActivity(tx as unknown as Db, {
        companyId: cancellationContext.companyId,
        actorType: "system",
        actorId: "native-session-cancellation",
        action: "native.cancellation_intent_recorded",
        entityType: "heartbeat_run",
        entityId: runId,
        agentId: cancellationContext.agentId,
        runId,
        issueId: cancellationContext.issueId,
        details: {
          intentId,
          scope: options.scope ?? "run",
          reasonCode: cancellationDecision.reasonCode,
          effects,
        },
      });
      const intentAuditId = activity.activity?.id ?? null;
      if (!intentAuditId)
        throw new Error("native_cancellation_intent_audit_missing");
      const written = await tx
        .update(heartbeatRuns)
        .set({
          resultJson: {
            ...resultJson,
            nativeCancellation: {
              schema: "paperclip.native-cancellation.v1",
              intentId,
              intentAuditId,
              companyId: cancellationContext.companyId,
              runId,
              issueId: cancellationContext.issueId,
              scope: options.scope ?? "run",
              reasonCode: cancellationDecision.reasonCode,
              effects,
              dispatchState: "pending",
              dispatched: false,
              decisionId: null,
              priorCoordinatorDecisionId:
                cancellationContext.coordinatorDecisionId,
              recordedAt: new Date().toISOString(),
            },
          },
          updatedAt: new Date(),
        })
        .where(
          and(
            eq(heartbeatRuns.id, runId),
            eq(heartbeatRuns.companyId, cancellationContext.companyId),
            eq(heartbeatRuns.agentId, cancellationContext.agentId),
            eq(heartbeatRuns.nativeIssueId, cancellationContext.issueId),
          ),
        )
        .returning({ id: heartbeatRuns.id })
        .then((rows) => rows[0] ?? null);
      if (!written) throw new Error("native_cancellation_binding_changed");
      // Cancellation is also an authority fence for a durable retry whose
      // preceding provider has already failed. No in-memory session is needed.
      await tx
        .update(nativeRunFinalizations)
        .set({
          phase: "terminal_failure",
          nextAttemptAt: null,
          leaseOwner: null,
          leaseExpiresAt: null,
          recoveryState: "blocked",
          failureCode: "native_retry_cancelled",
          updatedAt: new Date(),
        })
        .where(
          and(
            eq(nativeRunFinalizations.runId, runId),
            eq(nativeRunFinalizations.companyId, cancellationContext.companyId),
            eq(nativeRunFinalizations.phase, "retryable_failure"),
          ),
        );
      intentPublication = activity.publication;
      return {
        intentId,
        auditId: intentAuditId,
        acknowledged: false,
        dispatched: false,
        decisionId: null,
        priorCoordinatorDecisionId: cancellationContext.coordinatorDecisionId,
        existing: false,
      };
    });
    if (intentPublication) publishActivity(intentPublication);
    cancellationIntentId = intent.intentId;
    auditId = intent.auditId;
    decisionId = intent.decisionId;
    recoveringCancellationIntent = intent.existing;
    priorCoordinatorDecisionIdAtIntent = intent.priorCoordinatorDecisionId;
    if (intent.acknowledged && (!runStop || intent.dispatched ||
        (!nativeSessionStartups.has(runId) && !activeNativeSessions.has(runId)))) {
      return {
        dispatched: intent.dispatched,
        decision,
        decisionId,
        auditId,
      };
    }
  }
  // Startup already owns a provider lifetime even before publishing its handle.
  // Do not acknowledge a no-op Stop and let that owner submit a turn afterwards.
  const startup = runStop && !activeNativeSessions.has(runId) ? nativeSessionStartups.get(runId) : undefined;
  let settleStartupCancellation: (() => void) | undefined;
  if (startup) {
    startup.stopRequested = true;
    startup.cancellationSettled = new Promise<void>(resolve => { settleStartupCancellation = resolve; });
  }
  try {
    const active = activeNativeSessions.get(runId) ??
      (startup ? await waitForNativeSessionStartup(runId, () => new NativeCancellationPendingRecoveryError()) : null);
    let dispatched = false;
    if (active) {
      dispatched = true;
      if (!active.cancelRequested) {
        active.cancelRequested = true;
        try {
          if (active.session.cancel) {
            const cancellationAbort = new AbortController();
            const cleanup = active.session.cancel({
              reason,
              signal: cancellationAbort.signal,
            }).cleanup;
            let cleanupTimer: ReturnType<typeof setTimeout> | undefined;
            const settled = await Promise.race([
              cleanup.then(
                () => true,
                () => true,
              ),
              new Promise<false>((resolve) => {
                cleanupTimer = setTimeout(
                  () => resolve(false),
                  NATIVE_SESSION_CANCELLATION_CLEANUP_GRACE_MS,
                );
              }),
            ]);
            if (cleanupTimer) clearTimeout(cleanupTimer);
            if (!settled) {
              cancellationAbort.abort(
                new Error("native session cancellation cleanup timed out"),
              );
              void cleanup.catch(() => undefined);
            }
          } else if (active.session.interrupt)
            await active.session.interrupt({ reason });
        } catch (error) {
          active.cancelRequested = false;
          throw error;
        }
      }
    }
    if (!options) return dispatched;

    if (decision && decisionContext) {
      const cancellationDecision = decision;
      const cancellationContext = decisionContext;
      if (!cancellationIntentId || !auditId)
        throw new Error("native_cancellation_intent_audit_missing");
      if (
        recoveringCancellationIntent &&
        cancellationContext.coordinatorDecisionId !==
          priorCoordinatorDecisionIdAtIntent
      ) {
        decisionId ??= cancellationContext.coordinatorDecisionId;
      }
      if (
        cancellationContext.assessmentId &&
        cancellationDecision.reasonCode !== null &&
        !decisionId
      ) {
        const committed = await commitNativeStatusDecision({
          db: options.db,
          companyId: cancellationContext.companyId,
          issueId: cancellationContext.issueId,
          runId,
          assessmentId: cancellationContext.assessmentId,
          priorStatus: cancellationContext.priorStatus,
          priorStatusVersion: cancellationContext.priorStatusVersion,
          priorDecisionId: cancellationContext.priorDecisionId,
          decision: cancellationDecision,
        });
        decisionId = committed.decision.id;
      }
      const acknowledgement = await options.db.transaction(async (tx) => {
        const lockedRun = await tx
          .select({
            agentId: heartbeatRuns.agentId,
            companyId: heartbeatRuns.companyId,
            nativeIssueId: heartbeatRuns.nativeIssueId,
            resultJson: heartbeatRuns.resultJson,
            runtimeMode: heartbeatRuns.runtimeMode,
          })
          .from(heartbeatRuns)
          .where(eq(heartbeatRuns.id, runId))
          .for("update")
          .limit(1)
          .then((rows) => rows[0] ?? null);
        if (
          !lockedRun ||
          lockedRun.runtimeMode !== "native" ||
          lockedRun.companyId !== cancellationContext.companyId ||
          lockedRun.agentId !== cancellationContext.agentId ||
          lockedRun.nativeIssueId !== cancellationContext.issueId
        ) {
          throw new Error("native_cancellation_binding_changed");
        }
        const coordinator = await tx
          .select({ runId: nativeRunFinalizations.runId })
          .from(nativeRunFinalizations)
          .where(
            and(
              eq(nativeRunFinalizations.runId, runId),
              eq(nativeRunFinalizations.companyId, cancellationContext.companyId),
              eq(nativeRunFinalizations.issueId, cancellationContext.issueId),
            ),
          )
          .limit(1)
          .then((rows) => rows[0] ?? null);
        if (!coordinator)
          throw new Error("native_cancellation_coordinator_missing");

        const resultJson = record(lockedRun.resultJson);
        const intent = record(resultJson.nativeCancellation);
        const matchingIntent =
          intent.schema === "paperclip.native-cancellation.v1" &&
          intent.intentId === cancellationIntentId &&
          intent.intentAuditId === auditId &&
          intent.companyId === cancellationContext.companyId &&
          intent.runId === runId &&
          intent.issueId === cancellationContext.issueId;
        if (!matchingIntent)
          throw new Error("native_cancellation_intent_conflict");
        if (intent.dispatchState === "acknowledged" && (intent.dispatched === true || !dispatched)) {
          return {
            publication: null,
            decisionId:
              typeof intent.decisionId === "string"
                ? intent.decisionId
                : decisionId,
          };
        }

        if (
          options.replacementAccepted &&
          cancellationDecision.effects.some(
            (effect) => effect.kind === "accept_replacement_turn",
          )
        ) {
          await tx
            .update(heartbeatRuns)
            .set({
              status: "running",
              continuationAttempt: sql`${heartbeatRuns.continuationAttempt} + 1`,
              nextAction: "Accept a replacement native turn on the existing run.",
              updatedAt: new Date(),
            })
            .where(
              and(
                eq(heartbeatRuns.id, runId),
                eq(heartbeatRuns.companyId, cancellationContext.companyId),
                eq(heartbeatRuns.agentId, cancellationContext.agentId),
                eq(heartbeatRuns.nativeIssueId, cancellationContext.issueId),
              ),
            );
        }
        const activity = await persistActivity(tx as unknown as Db, {
          companyId: cancellationContext.companyId,
          actorType: "system",
          actorId: "native-session-cancellation",
          action: "native.cancellation_dispatch_acknowledged",
          entityType: "heartbeat_run",
          entityId: runId,
          agentId: cancellationContext.agentId,
          runId,
          issueId: cancellationContext.issueId,
          details: {
            intentId: cancellationIntentId,
            intentAuditId: auditId,
            scope: options.scope ?? "run",
            reasonCode: cancellationDecision.reasonCode,
            effects: cancellationDecision.effects.map((effect) => effect.kind),
            dispatched,
            decisionId,
          },
        });
        const acknowledgementAuditId = activity.activity?.id ?? null;
        if (!acknowledgementAuditId)
          throw new Error("native_cancellation_ack_audit_missing");
        const cancellationWrite = await tx
          .update(heartbeatRuns)
          .set({
            resultJson: {
              ...resultJson,
              nativeCancellation: {
                ...intent,
                dispatchState: "acknowledged",
                dispatched,
                decisionId,
                acknowledgementAuditId,
                acknowledgedAt: new Date().toISOString(),
              },
            },
            updatedAt: new Date(),
          })
          .where(
            and(
              eq(heartbeatRuns.id, runId),
              eq(heartbeatRuns.companyId, cancellationContext.companyId),
              eq(heartbeatRuns.agentId, cancellationContext.agentId),
              eq(heartbeatRuns.nativeIssueId, cancellationContext.issueId),
            ),
          )
          .returning({ id: heartbeatRuns.id })
          .then((rows) => rows[0] ?? null);
        if (!cancellationWrite)
          throw new Error("native_cancellation_binding_changed");
        return { publication: activity.publication, decisionId };
      });
      decisionId = acknowledgement.decisionId;
      if (acknowledgement.publication)
        publishActivity(acknowledgement.publication);
    }
    return { dispatched, decision, decisionId, auditId };
  } finally {
    settleStartupCancellation?.();
  }
}

/** Authenticated cancellation scope projected through the shared arbiter. */
export function resolveNativeCancellationStatus(input: {
  scope: "turn" | "run" | "issue";
  priorIssueStatus: NativeAuthoritativeIssueStatus;
  agentId: string;
  replacementAccepted?: boolean;
}): NativeStatusDecision {
  if (input.scope === "turn") {
    return {
      policyVersion: NATIVE_STATUS_ARBITER_POLICY_VERSION,
      statusAction: "preserve",
      toStatus: input.priorIssueStatus,
      reasonCode: input.replacementAccepted ? null : "cancellation_turn_only",
      unblockDescriptor: null,
      effects: [{ kind: "accept_replacement_turn" }],
    };
  }
  if (input.scope === "run") {
    return {
      policyVersion: NATIVE_STATUS_ARBITER_POLICY_VERSION,
      statusAction: "preserve",
      toStatus: input.priorIssueStatus,
      reasonCode: "cancellation_run_only",
      unblockDescriptor: null,
      effects: [{ kind: "release_run_resources" }],
    };
  }
  return {
    policyVersion: NATIVE_STATUS_ARBITER_POLICY_VERSION,
    statusAction: "cancelled",
    toStatus: "cancelled",
    reasonCode: "cancellation_issue_authorized",
    unblockDescriptor: null,
    effects: [{ kind: "release_checkout" }, { kind: "cancel_continuations" }],
  };
}

export async function renewNativeSessionExecutionLease(input: {
  db: Db;
  runId: string;
  companyId: string;
  issueId: string;
  leaseOwner: string;
  attempt: number;
  controller?: NativeControllerIdentity;
  leaseTtlMs?: number;
}): Promise<void> {
  const controller =
    input.controller ?? (await currentNativeControllerIdentity());
  const leaseTtlMs = input.leaseTtlMs ?? NATIVE_SESSION_EXECUTION_LEASE_TTL_MS;
  if (
    !Number.isInteger(leaseTtlMs) ||
    leaseTtlMs < 1_000 ||
    leaseTtlMs > NATIVE_SESSION_EXECUTION_LEASE_TTL_MS
  ) {
    throw new Error("native_session_lease_ttl_invalid");
  }
  const [updated] = await input.db
    .update(nativeRunFinalizations)
    .set({
      leaseExpiresAt: sql`clock_timestamp() + (${leaseTtlMs} * interval '1 millisecond')`,
      updatedAt: sql`clock_timestamp()`,
    })
    .where(
      and(
        eq(nativeRunFinalizations.runId, input.runId),
        eq(nativeRunFinalizations.companyId, input.companyId),
        eq(nativeRunFinalizations.issueId, input.issueId),
        eq(nativeRunFinalizations.leaseOwner, input.leaseOwner),
        eq(nativeRunFinalizations.attempt, input.attempt),
        eq(nativeRunFinalizations.controllerBootId, controller.bootId),
        eq(nativeRunFinalizations.controllerPid, controller.pid),
        eq(
          nativeRunFinalizations.controllerProcessStartedAt,
          controller.processStartedAt,
        ),
        gt(nativeRunFinalizations.leaseExpiresAt, sql`clock_timestamp()`),
      ),
    )
    .returning({ runId: nativeRunFinalizations.runId });
  if (!updated) throw new Error("native_session_lease_lost");
}

type NativeAttachmentStageReceipt = {
  eventSeq: number;
  attempt: number;
  responsibleUserId: string | null;
  baseTaskDigest: string;
  finalTaskDigest: string;
  sourceCaptureHash: string;
  descriptorHash: string;
  stageHash: string;
  sourceCaptures: readonly NativeRunnerAttachmentSourceCapture[];
};

function nativeTaskDigest(task: unknown): string {
  // The persisted profile is JSONB, which does not preserve JavaScript key
  // insertion order. Use the same canonical encoding in the stage stamp and
  // its PostgreSQL verifier.
  return nativeSha256(task);
}

function nativeAttachmentStageRecord(profile: Record<string, unknown>, run: typeof heartbeatRuns.$inferSelect,
  attachmentInputs: readonly Extract<NativePayloadSourceInput, { kind: "attachment" }>[],
  identity?: { eventSeq: number; attempt: number }): NativeAttachmentStageReceipt | null | undefined {
  const captures = Array.isArray(profile.nativeAttachmentStageSources) ? profile.nativeAttachmentStageSources : [];
  if (!attachmentInputs.length) return captures.length === 0 ? undefined : null;
  if (captures.length !== 1) return null;
  const raw = record(captures[0]);
  if (identity && (raw.eventSeq !== identity.eventSeq || raw.attempt !== identity.attempt) ||
    (raw.responsibleUserId ?? null) !== (run.responsibleUserId ?? null) || !Array.isArray(raw.sourceCaptures)) return null;
  const sourceCaptures = raw.sourceCaptures as unknown[];
  if (sourceCaptures.some(capture => !capture || typeof capture !== "object" || Array.isArray(capture) ||
    !record(capture).input || typeof record(capture).input !== "object" || Array.isArray(record(capture).input))) return null;
  const typedSourceCaptures = sourceCaptures as NativeRunnerAttachmentSourceCapture[];
  const sourceInputs = typedSourceCaptures.map(capture => capture.input);
  if (!isDeepStrictEqual(sourceInputs, attachmentInputs) || typedSourceCaptures.some(capture =>
    capture.input.kind !== "attachment" || capture.input.disposition !== "delivered" ||
    !capture.input.assetId || !capture.input.sha256 || capture.input.byteSize === null)) return null;
  let execution: NativeExecutionInput;
  try { execution = parseNativeExecutionInput(profile.nativeExecutionInput); } catch { return null; }
  const baseTaskDigest = nativeTaskDigest(execution.task);
  const finalTaskDigest = typeof raw.finalTaskDigest === "string" ? raw.finalTaskDigest : "";
  const sourceCaptureHash = typeof raw.sourceCaptureHash === "string" ? raw.sourceCaptureHash : "";
  const descriptorHash = typeof raw.descriptorHash === "string" ? raw.descriptorHash : "";
  const stageHash = typeof raw.stageHash === "string" ? raw.stageHash : "";
  if (!Number.isSafeInteger(raw.eventSeq) || !Number.isSafeInteger(raw.attempt) ||
    !/^[0-9a-f]{64}$/.test(finalTaskDigest) ||
    raw.baseTaskDigest !== baseTaskDigest || sourceCaptureHash !== nativeSha256(sourceCaptures) ||
    !/^[0-9a-f]{64}$/.test(descriptorHash) ||
    stageHash !== nativeSha256({ eventSeq: raw.eventSeq, attempt: raw.attempt,
      responsibleUserId: raw.responsibleUserId ?? null, baseTaskDigest, finalTaskDigest, sourceCaptureHash, descriptorHash })) return null;
  return { eventSeq: raw.eventSeq as number, attempt: raw.attempt as number,
    responsibleUserId: (raw.responsibleUserId ?? null) as string | null, baseTaskDigest, finalTaskDigest,
    sourceCaptureHash, descriptorHash, stageHash, sourceCaptures: typedSourceCaptures };
}

function nativeAttachmentStageReceipt(profile: Record<string, unknown>, run: typeof heartbeatRuns.$inferSelect,
  closure: NativeBootstrapSourceClosure | null | undefined,
  identity: { eventSeq: number; attempt: number }): NativeAttachmentStageReceipt | null | undefined {
  const attachmentInputs = closure?.sourceSet.inputs.filter((source): source is Extract<NativePayloadSourceInput, { kind: "attachment" }> =>
    source.kind === "attachment") ?? [];
  const stage = nativeAttachmentStageRecord(profile, run, attachmentInputs, identity);
  if (!stage || !attachmentInputs.length) return stage;
  return closure?.taskEnvelopeDigest === stage.finalTaskDigest ? stage : null;
}

function nativeAttachmentStageAuthorityBinding(profile: Record<string, unknown>, run: typeof heartbeatRuns.$inferSelect,
  bootstrap: { inputs: NativePayloadSourceInput[] }, identity: { eventSeq: number; attempt: number }): { valid: boolean; stageHash: string | null } {
  const attachmentInputs = bootstrap.inputs.filter((source): source is Extract<NativePayloadSourceInput, { kind: "attachment" }> =>
    source.kind === "attachment");
  const stage = nativeAttachmentStageRecord(profile, run, attachmentInputs, identity);
  if (!attachmentInputs.length) return { valid: stage === undefined, stageHash: null };
  if (!stage) return { valid: false, stageHash: null };
  const dispatches = Array.isArray(profile.nativeModelInputDispatchIntents)
    ? profile.nativeModelInputDispatchIntents.map(record) : [];
  const matchingDispatches = dispatches.filter(dispatch => dispatch.eventSeq === identity.eventSeq && dispatch.attempt === identity.attempt &&
    (dispatch.responsibleUserId ?? null) === stage.responsibleUserId);
  return { valid: matchingDispatches.length > 0, stageHash: matchingDispatches.length > 0 ? stage.stageHash : null };
}

async function nativeTurnFrameMatchesSourceClosure(tx: Parameters<Parameters<Db["transaction"]>[0]>[0],
  run: typeof heartbeatRuns.$inferSelect, turnInput: Parameters<NativeSession["startTurn"]>[0],
  closure: NativeBootstrapSourceClosure | null | undefined, rawNativeExecutionInput: unknown,
  identity: { eventSeq: number; attempt: number }, onMismatch?: (reason: string) => void) {
  const no = (reason: string) => { onMismatch?.(reason); return false; };
  if (!closure || turnInput.continuation === true || turnInput.message.role !== "user") return no("frame_kind");
  let frame: Record<string, unknown>, parsedExecution: ReturnType<typeof parseNativeExecutionInput>, expected: unknown;
  try {
    frame = record(JSON.parse(turnInput.message.text));
    parsedExecution = parseNativeExecutionInput(rawNativeExecutionInput);
    expected = buildNativeModelEnvelope(parsedExecution);
  } catch {
    return no("frame_parse");
  }
  const task = record(frame.task);
  const frameWithoutTurnContext = { ...frame };
  delete frameWithoutTurnContext.turnContext;
  const attachmentStage = nativeAttachmentStageReceipt(record(run.runnerProfileJson), run, closure, identity);
  if (attachmentStage === null) return no("attachment_stage_binding");
  if (attachmentStage) {
    const expectedFrame = record(expected);
    const expectedTask = { ...record(expectedFrame.task) };
    const actualTask = { ...task };
    delete expectedTask.prompt;
    delete actualTask.prompt;
    if (!isDeepStrictEqual({ ...frameWithoutTurnContext, task: actualTask }, { ...expectedFrame, task: expectedTask }) ||
      nativeTaskDigest(frame.task) !== attachmentStage.finalTaskDigest) return no("staged_task_binding");
  } else if (!isDeepStrictEqual(frameWithoutTurnContext, expected)) return no("envelope_shape");
  if (closure.turnContext) {
    const turnContext = record(frame.turnContext);
    const manifestIds = closure.turnContext.manifestIds;
    const contextSourceIds = closure.sourceSet.inputs.filter((source): source is Extract<NativePayloadSourceInput, { kind: "context" }> =>
      source.kind === "context").map(source => source.manifestId);
    if (typeof turnContext.markdown !== "string" || typeof turnContext.digest !== "string" ||
      createHash("sha256").update(typeof turnContext.markdown === "string" ? turnContext.markdown : "", "utf8").digest("hex") !== turnContext.digest ||
      turnContext.digest !== closure.turnContext.markdownDigest ||
      !Array.isArray(turnContext.manifestIds) || !isDeepStrictEqual(turnContext.manifestIds, manifestIds) ||
      !Array.isArray(manifestIds) || new Set(manifestIds).size !== manifestIds.length ||
      new Set(contextSourceIds).size !== contextSourceIds.length || manifestIds.some(id => !contextSourceIds.includes(id)) ||
      turnContext.markdown.length > 256000)
      return no("turn_context_binding");
  } else if (Object.hasOwn(frame, "turnContext")) return no("turn_context_unqualified");
  if (frame.schema !== "paperclip.native-model-envelope.v2") return no("envelope_schema");
  if (nativeTaskDigest(frame.task) !== closure.taskEnvelopeDigest) return no("envelope_task_digest");
  const workspaceSource = closure.sourceSet.inputs.find((input): input is Extract<NativePayloadSourceInput, { kind: "workspace_metadata" }> =>
    input.kind === "workspace_metadata" && input.runId === run.id);
  if (!workspaceSource) return no("workspace_source_missing");
  if (workspaceSource.executionWorkspaceId !== parsedExecution.binding.executionWorkspaceId) return no("workspace_id_mismatch");
  const workspaceIsSerialized = parsedExecution.provider.kind !== "claude_managed" && parsedExecution.provider.kind !== "aws_agentcore";
  const workspaceTuple = { cwd: parsedExecution.workspace.cwd, repoUrl: parsedExecution.workspace.repoUrl,
    repoRef: parsedExecution.workspace.repoRef, branchName: parsedExecution.workspace.branchName };
  if (workspaceIsSerialized) {
    if (!frame.workspace || typeof frame.workspace !== "object" || Array.isArray(frame.workspace)) return no("workspace_frame_missing");
    if (!isDeepStrictEqual(frame.workspace, { cwd: parsedExecution.workspace.cwd })) return no("workspace_frame_shape");
  } else if (frame.workspace !== null) return no("workspace_frame_shape");
  if (createHash("sha256").update(JSON.stringify(workspaceTuple), "utf8").digest("hex") !== workspaceSource.contentHash)
    return no("workspace_digest");
  let workspaceProjectId: string | null = null;
  if (workspaceSource.origin === "agent_home") {
    if (workspaceSource.executionWorkspaceId !== run.id || workspaceSource.sourceVersion !== `agent-home:${run.agentId}:v1` ||
      !isDeepStrictEqual(workspaceTuple, { cwd: resolveDefaultAgentWorkspaceDir(run.agentId), repoUrl: null, repoRef: null, branchName: null }))
      return no("workspace_agent_home_binding");
    const [unexpectedRow] = await tx.select({ id: executionWorkspaces.id }).from(executionWorkspaces).where(and(
      eq(executionWorkspaces.companyId, run.companyId), eq(executionWorkspaces.id, workspaceSource.executionWorkspaceId)));
    if (unexpectedRow) return no("workspace_agent_home_row");
  } else if (workspaceSource.origin === "execution_workspace") {
    if (workspaceSource.executionWorkspaceId === run.id) return no("workspace_execution_identity");
    const [currentWorkspace] = await tx.select({ id: executionWorkspaces.id, projectId: executionWorkspaces.projectId,
      cwd: executionWorkspaces.cwd,
      repoUrl: executionWorkspaces.repoUrl, repoRef: executionWorkspaces.baseRef, branchName: executionWorkspaces.branchName,
      updatedAt: executionWorkspaces.updatedAt }).from(executionWorkspaces).where(and(
      eq(executionWorkspaces.companyId, run.companyId), eq(executionWorkspaces.id, workspaceSource.executionWorkspaceId)));
    if (!currentWorkspace || currentWorkspace.updatedAt.toISOString() !== workspaceSource.sourceVersion ||
      !isDeepStrictEqual({ id: currentWorkspace.id, cwd: currentWorkspace.cwd, repoUrl: currentWorkspace.repoUrl,
        repoRef: currentWorkspace.repoRef, branchName: currentWorkspace.branchName, updatedAt: currentWorkspace.updatedAt },
      { id: workspaceSource.executionWorkspaceId, ...workspaceTuple, updatedAt: currentWorkspace.updatedAt })) return no("workspace_current_binding");
    workspaceProjectId = currentWorkspace.projectId;
  } else if (workspaceSource.origin === "task_session") {
    // Ephemeral task-session directories have no execution_workspaces row;
    // the source is the exact immutable workspace tuple persisted in this run's
    // server-built NativeExecutionInput, bound to the assigned issue below.
    if (workspaceSource.runId !== run.id || workspaceSource.executionWorkspaceId !== parsedExecution.binding.executionWorkspaceId ||
      workspaceSource.sourceVersion !== `task-session:${run.id}`) return no("workspace_task_session_binding");
  } else return no("workspace_origin_unavailable");
  const [currentTask] = await tx.select({ id: issues.id, companyId: issues.companyId, identifier: issues.identifier,
    title: issues.title, description: issues.description, workMode: issues.workMode,
    ownerBodyHash: sql<string>`public.aw_native_payload_body_hash('issue',to_jsonb(${issues}))`,
    projectId: issues.projectId,
    executionWorkspaceId: issues.executionWorkspaceId, assigneeAgentId: issues.assigneeAgentId,
    executionRunId: issues.executionRunId }).from(issues).where(and(eq(issues.companyId, run.companyId),
      eq(issues.id, run.nativeIssueId!), eq(issues.executionRunId, run.id))).for("share");
  const taskAssignmentCurrent = currentTask?.assigneeAgentId === run.agentId;
  // A pending completion reviewer is intentionally not the Task assignee:
  // the source Agent remains assigned while the distinct reviewer Agent owns
  // this run. Reuse the existing exact interaction/decision/run authority;
  // this does not change the Task body, ACL, or dispatch source checks below.
  const assignedReviewCurrent = !!currentTask && !taskAssignmentCurrent && !!await getNativeReviewAssignment(tx as unknown as Db, {
    companyId: run.companyId, issueId: currentTask.id, agentId: run.agentId,
    contextSnapshot: run.contextSnapshot, actingRunId: run.id, issueExecutionRunId: currentTask.executionRunId,
  });
  const sourceActor: AuthorizationActor = { type: "agent", source: "none", companyId: run.companyId,
    agentId: run.agentId, runId: run.id, onBehalfOfUserId: run.responsibleUserId };
  if (!currentTask || (!taskAssignmentCurrent && !assignedReviewCurrent) || workspaceSource.origin === "execution_workspace" &&
    (currentTask.executionWorkspaceId !== workspaceSource.executionWorkspaceId || currentTask.projectId !== workspaceProjectId))
    return no("workspace_task_binding");
  if (!await canActorReadIssuePrivacy(tx, sourceActor, currentTask)) return no("workspace_task_acl");
  await assertAnalyticalContextPayloadAccess(tx as unknown as Db, run.companyId, sourceActor, { issueId: run.nativeIssueId! });
  if (attachmentStage) {
    for (const capture of attachmentStage.sourceCaptures) {
      const source = capture.input;
      if (source.disposition !== "delivered" || !source.assetId || !source.sha256 || source.byteSize === null)
        return no("attachment_not_delivered");
      const [owner] = await tx.select({ attachment: issueAttachments, asset: assets }).from(issueAttachments)
        .innerJoin(assets, and(eq(assets.companyId, issueAttachments.companyId), eq(assets.id, issueAttachments.assetId)))
        .where(and(eq(issueAttachments.companyId, run.companyId), eq(issueAttachments.issueId, source.issueId),
          eq(issueAttachments.id, source.attachmentId)));
      if (!owner || owner.attachment.payloadSourceSnapshotInvalidated ||
        !isDeepStrictEqual(owner.attachment.payloadSourceSnapshot, capture.payloadSourceSnapshot) ||
        owner.attachment.issueCommentId !== source.commentId || owner.asset.id !== source.assetId ||
        owner.asset.sha256 !== source.sha256 || owner.asset.byteSize !== source.byteSize)
        return no("attachment_source_changed");
      if (source.commentId) {
        const [comment] = await tx.select({ id: issueComments.id }).from(issueComments).where(and(
          eq(issueComments.companyId, run.companyId), eq(issueComments.issueId, source.issueId),
          eq(issueComments.id, source.commentId), isNull(issueComments.deletedAt)));
        if (!comment) return no("attachment_comment_erased");
      }
    }
  }
  if (frame.planningContext !== null) return no("envelope_planning_context");
  const interactionSources = closure.sourceSet.inputs.filter((source): source is Extract<NativePayloadSourceInput, { kind: "interaction" }> =>
    source.kind === "interaction");
  if (!exactNativeInteractionSourceInputs({ issueId: run.nativeIssueId ?? "", responses: parsedExecution.interactionResponses,
    sources: interactionSources })) return no("interaction_sources");
  if (parsedExecution.binding.companyId !== run.companyId) return no("envelope_company");
  if (parsedExecution.binding.runId !== run.id) return no("envelope_run");
  if (parsedExecution.binding.agentId !== run.agentId) return no("envelope_agent");
  if (parsedExecution.binding.issueId !== run.nativeIssueId || !run.nativeIssueId) return no("envelope_issue");

  const taskInput = closure.sourceSet.inputs.find((input): input is Extract<NativePayloadSourceInput, { kind: "task" }> =>
    input.kind === "task" && input.issueId === parsedExecution.binding.issueId);
  const renderedTaskProjection = { identifier: parsedExecution.task.identifier, title: parsedExecution.task.title,
    description: parsedExecution.task.description, workMode: parsedExecution.task.workMode };
  const currentTaskProjection = currentTask && { identifier: currentTask.identifier, title: currentTask.title,
    description: currentTask.description, workMode: currentTask.workMode };
  const legacyRenderedTaskHash = currentTask && nativeSha256({ id: currentTask.id, ...currentTaskProjection });
  if (!taskInput || !currentTask || taskInput.contentHash !== currentTask.ownerBodyHash &&
    taskInput.contentHash !== legacyRenderedTaskHash ||
    !isDeepStrictEqual(renderedTaskProjection, currentTaskProjection))
    return no("task_source");

  // Wake payload is rendered into task.prompt before the closed execution
  // input is built; it is intentionally not a second field in that contract.
  // The closure's taskEnvelopeDigest binds those final prompt bytes, while the
  // server-only wake capture preserves the exact source payload hash.
  const wakeInputs = closure.sourceSet.inputs.filter((input): input is Extract<NativePayloadSourceInput, { kind: "native_task_wake" }> =>
    input.kind === "native_task_wake");
  if (wakeInputs.length > 1 || wakeInputs.some(input => input.runId !== run.id || input.issueId !== run.nativeIssueId)) return no("wake_binding");
  // The Task source was checked against its current payload-only owner hash
  // immediately above. Bind the wake to that captured Task source version;
  // `issues.updatedAt` also changes for operational conversation activity.
  if (wakeInputs.length === 1 && (!taskInput || wakeInputs[0]!.sourceVersion !== taskInput.sourceVersion))
    return no("wake_version");

  if (!run.completionContractId || !run.completionContractSha256 ||
    parsedExecution.completionContract.id !== run.completionContractId ||
    parsedExecution.completionContract.sha256 !== run.completionContractSha256) return no("contract_binding");
  const [contract] = await tx.select({ id: completionContracts.id, revision: completionContracts.revision,
    schemaVersion: completionContracts.schemaVersion, policyVersion: completionContracts.policyVersion,
    risk: completionContracts.risk, completionAuthority: completionContracts.completionAuthority,
    canonicalSha256: completionContracts.canonicalSha256,
    contractJson: completionContracts.contractJson })
    .from(completionContracts).where(and(eq(completionContracts.companyId, run.companyId),
      eq(completionContracts.issueId, run.nativeIssueId), eq(completionContracts.id, run.completionContractId))).for("share");
  if (!contract || contract.canonicalSha256 !== parsedExecution.completionContract.sha256) return no("contract_source");
  const contractJson = record(contract.contractJson);
  const projectedContract = { revision: String(contractJson.revision), objective: String(contractJson.objective),
    criteria: Array.isArray(contractJson.criteria) ? contractJson.criteria : null };
  // V7 orchestration contracts predate the native contract policy columns and
  // are canonically hashed as {schemaVersion, contract}. Native v1 contracts
  // include the complete policy tuple. Keep the two retained wire formats
  // explicit; do not accept a caller-selected hash shape.
  const canonicalContractHash = contract.schemaVersion === V7_COMPLETION_SCHEMA
    ? nativeSha256({ schemaVersion: contract.schemaVersion, contract: contract.contractJson })
    : contract.schemaVersion === NATIVE_COMPLETION_CONTRACT_SCHEMA
      ? nativeSha256({ schemaVersion: contract.schemaVersion, policyVersion: contract.policyVersion,
        risk: contract.risk, completionAuthority: contract.completionAuthority, contract: contract.contractJson })
      : null;
  if (!canonicalContractHash || canonicalContractHash !== contract.canonicalSha256)
    return no("contract_digest");
  return isDeepStrictEqual(parsedExecution.completionContract.contract, projectedContract) || no("contract_projection");
}

const nativeTurnFrameSourceMismatchReasons = new Set([
  "frame_kind", "frame_parse", "attachment_stage_binding", "staged_task_binding", "envelope_shape",
  "turn_context_binding", "turn_context_unqualified", "envelope_schema", "envelope_task_digest",
  "workspace_source_missing", "workspace_id_mismatch", "workspace_frame_missing", "workspace_frame_shape",
  "workspace_digest", "workspace_agent_home_binding", "workspace_agent_home_row", "workspace_execution_identity",
  "workspace_current_binding", "workspace_task_session_binding", "workspace_origin_unavailable", "workspace_task_binding",
  "workspace_task_acl", "attachment_not_delivered", "attachment_source_changed", "attachment_comment_erased",
  "envelope_planning_context", "interaction_sources", "envelope_company", "envelope_run", "envelope_agent",
  "envelope_issue", "task_source", "wake_binding", "wake_version", "contract_binding", "contract_source",
  "contract_digest", "contract_projection",
]);

// Test-only attribution for the final first-dispatch source-owner check. Keep
// this as an exact message -> enum map: never include SQL, identifiers, or
// source values in a run error.
const nativeDispatchSourceOwnerDiagnosticReasons = new Map<string, string>([
  ["The Native source prefix is unavailable", "prefix_unavailable"],
  ["The Native source prefix owner is unavailable", "prefix_owner_unavailable"],
  ["The Native source prefix is not in its original receipt", "receipt_membership"],
  ["The Native source completion contract changed", "completion_contract_changed"],
  ["A Native source workspace tuple changed", "workspace_tuple_changed"],
  ["The Native output workspace tuple changed", "output_workspace_tuple_changed"],
  ["The Native output agent workspace changed", "output_agent_workspace_changed"],
  ["The Native task-session workspace source changed", "output_task_session_workspace_changed"],
  ["The Native output workspace owner changed", "output_workspace_owner_changed"],
  ["The Native document workspace source is unavailable", "document_workspace_source_unavailable"],
  ["The Native document workspace tuple changed", "document_workspace_tuple_changed"],
  ["The Native document agent workspace changed", "document_agent_workspace_changed"],
  ["The Native document task-session workspace source changed", "document_task_session_workspace_changed"],
  ["The Native document workspace owner changed", "document_workspace_owner_changed"],
  ["The Native source agent workspace changed", "agent_workspace_changed"],
  ["The Native source task-session workspace changed", "task_session_workspace_changed"],
  ["The Native source execution workspace changed", "execution_workspace_changed"],
  ["A Native source Foundation revision changed", "foundation_revision_changed"],
  ["A Native task wake source changed", "task_wake_changed"],
  ["A Native source Task changed", "task_changed"],
  ["A Native source Task is unavailable", "task_unavailable"],
  ["A Native Task source changed or was erased", "task_snapshot_changed_or_erased"],
  ["A Native Task source snapshot is unavailable", "task_snapshot_unavailable"],
  ["A Native Task source protocol is unsupported", "task_protocol_unsupported"],
  ["A Native source Comment changed or was erased", "comment_changed_or_erased"],
  ["A Native Task source changed or was erased", "task_source_changed_or_erased"],
  ["The Native conversation source witness is unavailable", "conversation_witness_unavailable"],
  ["A Native conversation source witness is unavailable", "conversation_witness_unavailable"],
  ["A Native Context Task source changed or was erased", "context_task_source_changed_or_erased"],
  ["The Native source Task is unavailable", "task_owner_unavailable"],
  ["A Native source Task is unavailable", "task_reader_unavailable"],
  ["A Native source Comment is unavailable", "comment_unavailable"],
  ["The Native Task source snapshot is unavailable", "task_snapshot_unavailable"],
  ["The frozen Native Task source closure has no retained dispatch receipt", "frozen_task_dispatch_missing"],
  ["The frozen Native Task source producer is unavailable", "frozen_task_producer_unavailable"],
  ["The frozen Native Task dispatch prefix is unavailable", "frozen_task_prefix_unavailable"],
  ["The frozen Native Task source closure exceeds its bound", "frozen_task_bound"],
  ["The frozen Native Task source graph contains a cycle", "frozen_task_cycle"],
  ["The Native source Run is unavailable", "source_run_unavailable"],
  ["The Native source reader recheck exceeds its work bound", "reader_recheck_bound"],
  ["The Native source issue reader recheck exceeds its work bound", "issue_reader_recheck_bound"],
  ["A Native source Comment is no longer readable", "comment_reader_unavailable"],
  ["The Native source Interaction changed or was erased", "interaction_changed_or_erased"],
  ["A Native source Attachment changed or was erased", "attachment_changed_or_erased"],
]);

function nativeDispatchSourceOwnerDiagnostic(error: unknown): string {
  const message = error instanceof Error ? error.message : "";
  const commentDiagnostic = /^native_source_comment_owner_diagnostic:(owner_version|snapshot_owner|projection_hash|reader_acl)$/.exec(message);
  if (commentDiagnostic) return `comment_${commentDiagnostic[1]}`;
  const known = nativeDispatchSourceOwnerDiagnosticReasons.get(message);
  if (known) return known;
  const value = error && typeof error === "object"
    ? error as Error & { code?: unknown; status?: unknown; cause?: { code?: unknown } } : null;
  const errorKind = value?.name === "HttpError" ? "http" : value?.name === "Error" ? "error" : "other";
  const status = typeof value?.status === "number" && Number.isInteger(value.status) && value.status >= 400 && value.status < 600
    ? String(value.status) : "none";
  const codeValue = value?.code ?? value?.cause?.code;
  const code = typeof codeValue === "string" && /^[A-Z0-9_:-]{1,32}$/.test(codeValue) ? codeValue : "none";
  const frames = value?.stack?.split("\n").slice(1).flatMap(frame => {
    const match = /server\/src\/services\/([^\s():]+\.ts):(\d+):\d+/.exec(frame);
    return match ? [`${match[1]}_${match[2]}`] : [];
  }).slice(0, 4) ?? [];
  return `unclassified_${errorKind}_${status}_${code}${frames.length ? `_${frames.join("_")}` : ""}`;
}

async function postgresJsonbSha256(tx: Parameters<Parameters<Db["transaction"]>[0]>[0], value: unknown): Promise<string> {
  const [row] = await tx.execute<{ digest: string }>(sql`select encode(sha256(convert_to((${JSON.stringify(value)}::jsonb)::text,'UTF8')),'hex') as digest`);
  if (!row || !/^[0-9a-f]{64}$/.test(row.digest)) throw new Error("native_input_source_receipt_persistence_failed");
  return row.digest;
}

/** Chosen backend-call bytes before I/O, not proof of delivery or complete
 * source provenance. Keep unknown sends and prior attempts as separate facts. */
function nativeSessionTaskEnvelope(execution: NativeExecutionInput) {
  return createCodexTaskEnvelope({
    objective: execution.completionContract.contract.objective,
    contractRevision: execution.completionContract.contract.revision,
    criteria: execution.completionContract.contract.criteria,
    constraints: [
      "Work only inside the supplied working directory.",
      ...nativeTaskConstraints(execution),
      "Return one semantic completion result through paperclip_finish or paperclip_block.",
    ],
  });
}

export async function recordNativeModelInputDispatchIntent(input: Parameters<typeof renewNativeSessionExecutionLease>[0] & {
  agentId: string;
  eventSeq: number;
  turnInput: Parameters<NativeSession["startTurn"]>[0];
  bootstrapSourceClosure?: NativeBootstrapSourceClosure | null;
}): Promise<string> {
  if (!Number.isSafeInteger(input.eventSeq) || input.eventSeq < 0)
    throw new Error("native_model_input_launch_binding_invalid");
  const dispatchId = randomUUID();
  const encoded = JSON.stringify(input.turnInput);
  let stage:
    | "lease_recheck_before"
    | "run_binding"
    | "launch_binding"
    | "source_closure_match"
    | "receipt_validation"
    | "prompt_binding"
    | "intent_persist"
    | "source_owner_recheck"
    | "lease_recheck_after" = "lease_recheck_before";
  await input.db.transaction(async tx => {
    // Source closure rechecks below use the company privacy locks. Take them
    // before the coordinator/run rows so event admission cannot hold those
    // advisory locks while waiting on this transaction's run row.
    await lockAnalyticalCompany(tx as unknown as Db, input.companyId);
    await lockMemoryPrivacy(tx as unknown as Db, input.companyId);
    // Preserve the original coordinator -> run order after source locks, and
    // repeat the actual lease check after intervening waits before commit.
    await renewNativeSessionExecutionLease({ ...input, db: tx as unknown as Db });
    stage = "run_binding";
    const [run] = await tx.select().from(heartbeatRuns).where(and(
      eq(heartbeatRuns.id, input.runId), eq(heartbeatRuns.companyId, input.companyId),
      eq(heartbeatRuns.agentId, input.agentId), eq(heartbeatRuns.nativeIssueId, input.issueId),
      eq(heartbeatRuns.runtimeMode, "native"), eq(heartbeatRuns.status, "running"),
    )).for("update");
    if (!run) throw new Error("native_model_input_run_binding_changed");
    stage = "launch_binding";
    const [launch] = await tx.select({ seq: heartbeatRunEvents.seq }).from(heartbeatRunEvents).where(and(
      eq(heartbeatRunEvents.companyId, input.companyId), eq(heartbeatRunEvents.runId, input.runId),
      eq(heartbeatRunEvents.agentId, input.agentId), eq(heartbeatRunEvents.seq, input.eventSeq),
      eq(heartbeatRunEvents.eventType, PROCESS_START_REQUESTED),
    )).for("share");
    if (!launch) throw new Error("native_model_input_launch_binding_changed");
    stage = "source_closure_match";
    const profile = record(run.runnerProfileJson);
    const previous = profile.nativeModelInputDispatchIntents ?? [];
    if (!Array.isArray(previous) || previous.length >= 64)
      throw new Error("native_model_input_dispatch_budget_exceeded");
    const intents = [...previous, {
      dispatchId,
      eventSeq: launch.seq, attempt: input.attempt, responsibleUserId: run.responsibleUserId ?? null,
      turnInputDigest: createHash("sha256").update(encoded).digest("hex"),
      byteSize: Buffer.byteLength(encoded), continuation: input.turnInput.continuation === true,
    }];
    if (Buffer.byteLength(JSON.stringify(intents)) > 2 * 1024 * 1024)
      throw new Error("native_model_input_dispatch_budget_exceeded");
    let receipt: NativeRunInputSourceReceipt | null = null;
    const sourceClosure = input.bootstrapSourceClosure;
    const attachmentStage = nativeAttachmentStageReceipt(profile, run, sourceClosure,
      { eventSeq: input.eventSeq, attempt: input.attempt });
    const noPriorNativeEffects = previous.length === 0 &&
      (!Array.isArray(profile.nativeToolCallDispatchAssociations) || profile.nativeToolCallDispatchAssociations.length === 0) &&
      (!Array.isArray(profile.nativeToolResultSourceCaptures) || profile.nativeToolResultSourceCaptures.length === 0) &&
      (attachmentStage === undefined || attachmentStage !== null);
    let sourceClosureMatches: boolean | null | undefined;
    let sourceClosureMismatchReason: string | null = null;
    sourceClosureMatches = sourceClosure && await nativeTurnFrameMatchesSourceClosure(tx, run, input.turnInput,
      sourceClosure, profile.nativeExecutionInput, { eventSeq: input.eventSeq, attempt: input.attempt },
      reason => { sourceClosureMismatchReason = reason; });
    const existingReceipt = nativeRunInputSourceReceiptSchema.safeParse(profile.nativeInputSourceReceipt);
    if (process.env.PAPERCLIP_NATIVE_SOURCE_CLOSURE_DIAGNOSTICS === "1" &&
      (run.nativeInputSourceProtocolVersion === 0 || !existingReceipt.success)) {
      console.warn("native_model_input_dispatch_closure_diagnostic", {
        closurePresent: Boolean(sourceClosure),
        closureMatches: sourceClosureMatches === true,
        mismatch: sourceClosureMismatchReason && nativeTurnFrameSourceMismatchReasons.has(sourceClosureMismatchReason)
          ? sourceClosureMismatchReason : sourceClosure ? "unclassified" : "closure_missing",
        sourceProtocolVersion: run.nativeInputSourceProtocolVersion,
        responsibleUserPresent: typeof run.responsibleUserId === "string" && run.responsibleUserId.length > 0,
        existingReceiptValid: existingReceipt.success,
        noPriorNativeEffects,
        priorIntentCount: previous.length,
        priorAssociationCount: Array.isArray(profile.nativeToolCallDispatchAssociations)
          ? profile.nativeToolCallDispatchAssociations.length : 0,
        priorResultCaptureCount: Array.isArray(profile.nativeToolResultSourceCaptures)
          ? profile.nativeToolResultSourceCaptures.length : 0,
        attachmentStagePresent: attachmentStage !== undefined,
      });
    }
    if (profile.nativeOpenCodeSourceAuthority && !sourceClosureMatches) {
      const reason = process.env.PAPERCLIP_NATIVE_SOURCE_CLOSURE_DIAGNOSTICS === "1" &&
        sourceClosureMismatchReason && nativeTurnFrameSourceMismatchReasons.has(sourceClosureMismatchReason)
        ? sourceClosureMismatchReason : null;
      throw new Error(reason
        ? `managed_opencode_source_prompt_closure_unavailable:${reason}`
        : "managed_opencode_source_prompt_closure_unavailable");
    }
    stage = "receipt_validation";
    if (sourceClosure && sourceClosureMatches === true && run.nativeInputSourceProtocolVersion === 0 && typeof run.responsibleUserId === "string" && run.responsibleUserId.length > 0 &&
      profile.nativeExecutionInput !== undefined && profile.nativeInputSourceReceipt === undefined && noPriorNativeEffects) {
      const bootstrap = {
        executionInputDigest: await postgresJsonbSha256(tx, profile.nativeExecutionInput),
        ...sourceClosure.sourceSet,
      };
      const unsigned: Omit<NativeRunInputSourceReceipt, "digest"> = {
        version: 1,
        binding: { companyId: run.companyId, runId: run.id, agentId: run.agentId,
          responsibleUserId: run.responsibleUserId, issueId: run.nativeIssueId ?? null },
        bootstrap,
        dispatches: [],
        additionalInputs: [],
      };
      const candidate = { ...unsigned, digest: await postgresJsonbSha256(tx, unsigned) };
      const parsed = nativeRunInputSourceReceiptSchema.safeParse(candidate);
      if (parsed.success) receipt = parsed.data;
    } else if (sourceClosure && sourceClosureMatches === true && existingReceipt.success && typeof run.responsibleUserId === "string" &&
      existingReceipt.data.binding.responsibleUserId === run.responsibleUserId) {
      const bootstrapSetHash = nativeSha256({ policy: existingReceipt.data.bootstrap.policy, inputs: existingReceipt.data.bootstrap.inputs });
      const preparedSetHash = nativeSha256(sourceClosure.sourceSet);
      if (preparedSetHash !== bootstrapSetHash && !existingReceipt.data.additionalInputs.some(entry =>
        entry.responsibleUserId === run.responsibleUserId && nativeSha256({ policy: entry.policy, inputs: entry.inputs }) === preparedSetHash)) {
        const { digest: _priorDigest, ...receiptBody } = existingReceipt.data;
        const nextBody = { ...receiptBody, additionalInputs: [...receiptBody.additionalInputs, {
          responsibleUserId: run.responsibleUserId, ...sourceClosure.sourceSet,
        }] };
        const candidate = { ...nextBody, digest: await postgresJsonbSha256(tx, nextBody) };
        const parsed = nativeRunInputSourceReceiptSchema.safeParse(candidate);
        if (!parsed.success) throw new Error("native_model_input_turn_source_receipt_invalid");
        receipt = parsed.data;
      } else receipt = existingReceipt.data;
    }
    let nativeOpenCodeSourceAuthority = profile.nativeOpenCodeSourceAuthority;
    if (nativeOpenCodeSourceAuthority && typeof nativeOpenCodeSourceAuthority === "object" && !Array.isArray(nativeOpenCodeSourceAuthority)) {
      stage = "prompt_binding";
      const sourceAuthority = record(nativeOpenCodeSourceAuthority);
      const priorPrompts = sourceAuthority.authorizedPromptHashes;
      const promptHash = nativeSha256(input.turnInput.message.text);
      const priorBindings = sourceAuthority.promptSourceBindings;
      if (!sourceClosure || sourceClosureMatches !== true || !receipt || !Array.isArray(priorPrompts) || priorPrompts.length >= 64 ||
        priorPrompts.some(hash => typeof hash !== "string" || !/^[0-9a-f]{64}$/.test(hash)) ||
        !Array.isArray(priorBindings) || priorBindings.length >= 64 ||
        priorBindings.some(value => !value || typeof value !== "object" || typeof record(value).promptHash !== "string" ||
          !/^[0-9a-f]{64}$/.test(record(value).promptHash as string) || typeof record(value).sourceSetHash !== "string" ||
          !/^[0-9a-f]{64}$/.test(record(value).sourceSetHash as string)))
        throw new Error("managed_opencode_source_prompt_budget_exceeded");
      const sourceSetHash = nativeSha256(sourceClosure.sourceSet);
      const existingPromptBinding = priorBindings.map(record).filter(value => value.promptHash === promptHash);
      if (process.env.PAPERCLIP_NATIVE_SOURCE_CLOSURE_DIAGNOSTICS === "1") {
        const wrappedPrompt = priorPrompts.length === 0
          ? JSON.stringify({ task: nativeSessionTaskEnvelope(parseNativeExecutionInput(profile.nativeExecutionInput)),
            message: input.turnInput.message.text })
          : null;
        console.warn("managed_model_prompt_source_diagnostic", {
          runId: input.runId,
          promptLength: input.turnInput.message.text.length,
          promptHash,
          firstTurnWrappedPromptLength: wrappedPrompt?.length ?? null,
          firstTurnWrappedPromptHash: wrappedPrompt ? nativeSha256(wrappedPrompt) : null,
          continuation: input.turnInput.continuation === true,
          sourceClosurePresent: Boolean(sourceClosure),
          sourceClosureMatches: sourceClosureMatches === true,
        });
      }
      if (existingPromptBinding.length > 1 || existingPromptBinding.length === 1 && existingPromptBinding[0]!.sourceSetHash !== sourceSetHash)
        throw new Error("managed_opencode_source_prompt_binding_ambiguous");
      const authorizedPromptHashes = priorPrompts.includes(promptHash) ? priorPrompts : [...priorPrompts, promptHash];
      const promptSourceBindings = existingPromptBinding.length ? priorBindings : [...priorBindings, { promptHash, sourceSetHash }];
      nativeOpenCodeSourceAuthority = { ...sourceAuthority, authorizedPromptHashes, promptSourceBindings };
    }
    const nextProfile = { ...profile, nativeModelInputDispatchIntents: intents,
      ...(nativeOpenCodeSourceAuthority ? { nativeOpenCodeSourceAuthority } : {}),
      ...(receipt ? { nativeInputSourceReceipt: receipt } : {}) };
    stage = "intent_persist";
    const [stored] = await tx.update(heartbeatRuns).set({
      runnerProfileJson: nextProfile,
      ...(receipt ? { nativeInputSourceProtocolVersion: 1 } : {}),
      updatedAt: new Date(),
    }).where(eq(heartbeatRuns.id, run.id)).returning({ profile: heartbeatRuns.runnerProfileJson });
    if (!stored) throw new Error("native_model_input_dispatch_row_not_returned");
    if (!stored.profile || typeof stored.profile !== "object" || Array.isArray(stored.profile))
      throw new Error("native_model_input_dispatch_profile_not_returned");
    const storedIntents = record(stored.profile).nativeModelInputDispatchIntents;
    if (!Array.isArray(storedIntents)) throw new Error("native_model_input_dispatch_intents_not_returned");
    if (nativeSha256(storedIntents) !== nativeSha256(intents))
      throw new Error("native_model_input_dispatch_profile_digest_mismatch");
    if (nativeOpenCodeSourceAuthority && sourceClosure && receipt) {
      stage = "source_owner_recheck";
      await assertNativePayloadSourceSetCurrent(tx as unknown as Db, {
        companyId: run.companyId, issueId: run.nativeIssueId!, runId: run.id,
        actor: { type: "agent", source: "none", companyId: run.companyId, agentId: run.agentId,
          runId: run.id, onBehalfOfUserId: run.responsibleUserId ?? undefined },
        policy: sourceClosure.sourceSet.policy, inputs: sourceClosure.sourceSet.inputs,
      });
    }
    stage = "lease_recheck_after";
    await renewNativeSessionExecutionLease({ ...input, db: tx as unknown as Db });
  }).catch((error: unknown) => {
    if (stage === "source_owner_recheck" && process.env.PAPERCLIP_NATIVE_SOURCE_CLOSURE_DIAGNOSTICS === "1") {
      const stack = error instanceof Error ? error.stack ?? "" : "";
      const frames = stack.split("\n").slice(1).flatMap(line => {
        const match = /\bat (?:(.{1,100}?) \()?[^\s():]*server\/src\/services\/([^\s():]+\.ts):(\d+):\d+\)?$/.exec(line.trim());
        if (!match) return [];
        const fn = /^[A-Za-z0-9_.$<>-]+$/.test(match[1] ?? "") ? match[1]! : "anonymous";
        return [`${fn} ${match[2]}:${match[3]}`];
      }).slice(0, 6);
      console.error("native_source_owner_failure_frames", JSON.stringify(frames));
    }
    // A driver's query/params can include the existing private run profile.
    // Keep only our finite control errors; never propagate raw DB diagnostics.
    const message = error instanceof Error ? error.message : "";
    const sourceClosureDiagnostic = [...nativeTurnFrameSourceMismatchReasons]
      .some(reason => message === `managed_opencode_source_prompt_closure_unavailable:${reason}`);
    const sourceOwnerDiagnostic = stage === "source_owner_recheck" &&
      process.env.PAPERCLIP_NATIVE_SOURCE_CLOSURE_DIAGNOSTICS === "1"
      ? nativeDispatchSourceOwnerDiagnostic(error) : undefined;
    throw new Error([
      "native_session_lease_lost", "native_session_lease_ttl_invalid",
      "native_model_input_run_binding_changed", "native_model_input_launch_binding_changed",
      "native_model_input_dispatch_budget_exceeded", "native_model_input_dispatch_persistence_failed",
      "native_model_input_dispatch_row_not_returned", "native_model_input_dispatch_profile_not_returned",
      "native_model_input_dispatch_intents_not_returned",
      "native_model_input_dispatch_profile_digest_mismatch",
      "native_input_source_receipt_persistence_failed",
      // These are closed internal state codes with no prompt/provider payload.
      // Preserve them for the actual managed provider path so the source seam
      // can be fixed without dumping request or private run data.
      "managed_opencode_source_prompt_closure_unavailable",
      "native_model_input_turn_source_receipt_invalid",
      "managed_opencode_source_prompt_budget_exceeded",
      "managed_opencode_source_prompt_binding_ambiguous",
    ].includes(message) || sourceClosureDiagnostic
      ? message : stage === "intent_persist" &&
      input.bootstrapSourceClosure?.sourceSet.inputs.some(source => source.kind === "attachment")
      ? "native_model_input_attachment_stage_rejected"
      : stage === "intent_persist"
      ? "native_model_input_dispatch_persistence_failed"
      : sourceOwnerDiagnostic
      ? `native_model_input_dispatch_source_owner_recheck_failed:${sourceOwnerDiagnostic}`
      : `native_model_input_dispatch_${stage}_failed`);
  });
  return dispatchId;
}

/** Attach the backend's returned turn id to the exact input intent. This is
 * an acknowledgement fact only; it does not establish delivery or provenance. */
export async function recordNativeModelInputDispatchAcknowledgement(input: Parameters<typeof renewNativeSessionExecutionLease>[0] & {
  agentId: string; eventSeq: number; dispatchId: string; turnInput: Parameters<NativeSession["startTurn"]>[0]; turnId: string;
  sourceClosure?: NativeBootstrapSourceClosure | null;
}): Promise<void> {
  if (!Number.isSafeInteger(input.eventSeq) || input.eventSeq < 0 ||
    !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(input.dispatchId) ||
    typeof input.turnId !== "string" || !/^[\x21-\x7e]{1,240}$/.test(input.turnId))
    throw new Error("native_model_input_ack_binding_invalid");
  const digest = createHash("sha256").update(JSON.stringify(input.turnInput)).digest("hex");
  let ackPhase = "privacy_locks";
  await input.db.transaction(async tx => {
    // This acknowledgement repeats source-closure validation while holding
    // the run row, so acquire the same company privacy locks first as intent
    // persistence and native event admission.
    await lockAnalyticalCompany(tx as unknown as Db, input.companyId);
    await lockMemoryPrivacy(tx as unknown as Db, input.companyId);
    ackPhase = "lease_before";
    await renewNativeSessionExecutionLease({ ...input, db: tx as unknown as Db });
    ackPhase = "run_lock";
    const [run] = await tx.select().from(heartbeatRuns).where(and(
      eq(heartbeatRuns.id, input.runId), eq(heartbeatRuns.companyId, input.companyId),
      eq(heartbeatRuns.agentId, input.agentId), eq(heartbeatRuns.nativeIssueId, input.issueId),
      eq(heartbeatRuns.runtimeMode, "native"), eq(heartbeatRuns.status, "running"),
    )).for("update");
    if (!run) throw new Error("native_model_input_ack_binding_invalid");
    const profile = record(run.runnerProfileJson);
    ackPhase = "intent_match";
    const intents = profile.nativeModelInputDispatchIntents;
    if (!Array.isArray(intents)) throw new Error("native_model_input_ack_binding_invalid");
    const matching = intents.map((raw, index) => ({ raw: record(raw), index })).filter(({ raw }) =>
      raw.dispatchId === input.dispatchId && raw.eventSeq === input.eventSeq &&
      raw.attempt === input.attempt && raw.turnInputDigest === digest);
    if (matching.length !== 1 || matching[0]!.raw.turnId !== undefined)
      throw new Error("native_model_input_ack_binding_invalid");
    const acknowledged = intents.map((raw, index) => index === matching[0]!.index
      ? { ...record(raw), turnId: input.turnId } : raw);
    if (Buffer.byteLength(JSON.stringify(acknowledged)) > 2 * 1024 * 1024)
      throw new Error("native_model_input_ack_budget_exceeded");
    const parsedReceipt = nativeRunInputSourceReceiptSchema.safeParse(profile.nativeInputSourceReceipt);
    ackPhase = "receipt_validation";
    let nextReceipt: NativeRunInputSourceReceipt | null = null;
    if (parsedReceipt.success && run.nativeInputSourceProtocolVersion === 1 &&
      typeof run.responsibleUserId === "string" && run.responsibleUserId.length > 0 &&
      matching[0]!.raw.responsibleUserId === run.responsibleUserId &&
      await nativeTurnFrameMatchesSourceClosure(tx, run, input.turnInput, input.sourceClosure, profile.nativeExecutionInput,
        { eventSeq: input.eventSeq, attempt: input.attempt })) {
      const { digest: _priorDigest, ...receiptBody } = parsedReceipt.data;
      const unsigned: Omit<NativeRunInputSourceReceipt, "digest"> = {
        ...receiptBody,
        dispatches: [...parsedReceipt.data.dispatches, {
          executionInputDigest: digest,
          responsibleUserId: run.responsibleUserId,
          ...input.sourceClosure!.sourceSet,
        }],
      };
      const candidate = { ...unsigned, digest: await postgresJsonbSha256(tx, unsigned) };
      const validated = nativeRunInputSourceReceiptSchema.safeParse(candidate);
      if (validated.success) nextReceipt = validated.data;
    }
    const nextProfile = { ...profile, nativeModelInputDispatchIntents: acknowledged,
      ...(nextReceipt ? { nativeInputSourceReceipt: nextReceipt } : {}) };
    const [stored] = await tx.update(heartbeatRuns).set({
      runnerProfileJson: nextProfile, updatedAt: new Date(),
    }).where(eq(heartbeatRuns.id, run.id)).returning({ profile: heartbeatRuns.runnerProfileJson });
    ackPhase = "retained_intent_check";
    const retained = record(stored?.profile).nativeModelInputDispatchIntents;
    const retainedMatches = Array.isArray(retained) && nativeSha256(retained) === nativeSha256(acknowledged);
    if (!retainedMatches) {
      if (process.env.PAPERCLIP_NATIVE_SOURCE_CLOSURE_DIAGNOSTICS === "1")
        console.warn("native_model_input_ack_diagnostic", { phase: "retained_intent_check",
          profileReturned: Boolean(stored?.profile && typeof stored.profile === "object" && !Array.isArray(stored.profile)),
          retainedArray: Array.isArray(retained), retainedCount: Array.isArray(retained) ? retained.length : -1,
          expectedCount: acknowledged.length, digestMatches: false });
      throw new Error("native_model_input_ack_persistence_failed");
    }
    ackPhase = "lease_after";
    await renewNativeSessionExecutionLease({ ...input, db: tx as unknown as Db });
  }).catch((error: unknown) => {
    const message = error instanceof Error ? error.message : "";
    if (process.env.PAPERCLIP_NATIVE_SOURCE_CLOSURE_DIAGNOSTICS === "1") {
      const details = error && typeof error === "object" ? error as Record<string, unknown> : {};
      const causes: Record<string, unknown>[] = [details];
      for (let depth = 0; depth < 3; depth++) {
        const cause = causes.at(-1)?.cause;
        if (!cause || typeof cause !== "object") break;
        causes.push(cause as Record<string, unknown>);
      }
      const sqlState = causes.map(value => value.code).find(value =>
        typeof value === "string" && /^[0-9A-Z]{5}$/.test(value)) ?? null;
      const constraint = causes.flatMap(value => [value.constraint, value.constraint_name]).find(value =>
        typeof value === "string" && /^[A-Za-z0-9_]{1,100}$/.test(value)) ?? null;
      const receiptFailureMessages = new Map([
        ["Native dispatch source capture requires one exact acknowledged input", "dispatch_ack_mismatch"],
        ["Native run input captures are append-only", "capture_not_append_only"],
        ["Native run input capture Human mismatch", "capture_human_mismatch"],
        ["Malformed native input policy vectors", "policy_shape"],
        ["Malformed native input policy vector", "policy_vector_shape"],
        ["Duplicate native input policy identity", "duplicate_policy_identity"],
        ["Malformed native policy identity", "policy_identity_shape"],
        ["Duplicate native captured input", "duplicate_captured_input"],
        ["Malformed native captured input", "captured_input_shape"],
        ["Malformed native input capture", "capture_shape"],
        ["Native run input receipt bounds or digest mismatch", "receipt_digest_or_bounds"],
        ["Native run bootstrap capture is immutable", "bootstrap_mutation"],
        ["Native run input receipt owner mismatch", "receipt_owner_mismatch"],
        ["Native run bootstrap input digest mismatch", "bootstrap_digest_mismatch"],
      ]);
      const databaseReason = causes.map(value => value.message).find(value =>
        typeof value === "string" && receiptFailureMessages.has(value));
      const exceptionName = error instanceof Error && ["Error", "TypeError", "RangeError", "DatabaseError", "PostgresError"].includes(error.name)
        ? error.name : "unknown";
      const safeCode = ["native_session_lease_lost", "native_session_lease_ttl_invalid",
        "native_model_input_ack_binding_invalid", "native_model_input_ack_budget_exceeded",
        "native_model_input_ack_persistence_failed", "native_input_source_receipt_persistence_failed"].includes(message)
        ? message : null;
      const internalMessageCode = /^[a-z][a-z0-9_]{1,100}$/.test(message) ? message : null;
      console.warn("native_model_input_ack_diagnostic", { phase: ackPhase, exceptionName, safeCode,
        internalMessageCode, sqlState, constraint,
        databaseReason: typeof databaseReason === "string" ? receiptFailureMessages.get(databaseReason) : null });
    }
    throw new Error(["native_session_lease_lost", "native_session_lease_ttl_invalid",
      "native_model_input_ack_binding_invalid", "native_model_input_ack_budget_exceeded",
      "native_model_input_ack_persistence_failed", "native_input_source_receipt_persistence_failed"].includes(message)
      ? message : "native_model_input_ack_persistence_failed");
  });
}

/** Link a backend-authenticated tool call to the one acknowledged turn whose
 * native turn ID exactly matches. No match or an ambiguous ID stays unknown. */
export async function recordNativeToolCallDispatchAssociation(input: Parameters<typeof renewNativeSessionExecutionLease>[0] & {
  agentId: string; turnId: string; callId: string; tool: string; argumentsHash?: string;
}): Promise<boolean> {
  if (!/^[\x21-\x7e]{1,240}$/.test(input.turnId) || !/^[\x21-\x7e]{1,240}$/.test(input.callId) ||
    !/^[\x21-\x7e]{1,240}$/.test(input.tool) || input.argumentsHash !== undefined && !/^[0-9a-f]{64}$/.test(input.argumentsHash)) return false;
  try {
    return await input.db.transaction(async tx => {
      await renewNativeSessionExecutionLease({ ...input, db: tx as unknown as Db });
      const [run] = await tx.select().from(heartbeatRuns).where(and(
        eq(heartbeatRuns.id, input.runId), eq(heartbeatRuns.companyId, input.companyId),
        eq(heartbeatRuns.agentId, input.agentId), eq(heartbeatRuns.nativeIssueId, input.issueId),
        eq(heartbeatRuns.runtimeMode, "native"), eq(heartbeatRuns.status, "running"),
      )).for("update");
      if (!run) throw new Error("native_tool_call_dispatch_binding_invalid");
      const profile = record(run.runnerProfileJson);
      const intents = profile.nativeModelInputDispatchIntents;
      if (!Array.isArray(intents) || intents.length > 64) return false;
      const matching = intents.map(value => record(value)).filter(value => value.turnId === input.turnId);
      if (matching.length !== 1) return false;
      const intent = matching[0]!;
      if (typeof intent.dispatchId !== "string" ||
        !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(intent.dispatchId) ||
        typeof intent.turnInputDigest !== "string" || !/^[0-9a-f]{64}$/.test(intent.turnInputDigest) ||
        !Number.isSafeInteger(intent.eventSeq) || (intent.eventSeq as number) < 0 ||
        !Number.isSafeInteger(intent.attempt) || (intent.attempt as number) < 1) return false;
      const prior = profile.nativeToolCallDispatchAssociations;
      if (prior !== undefined && (!Array.isArray(prior) || prior.length > 512))
        throw new Error("native_tool_call_dispatch_binding_invalid");
      const associations = Array.isArray(prior) ? prior.map(value => record(value)) : [];
      if (associations.some(value => typeof value.dispatchId !== "string" ||
          !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(value.dispatchId) ||
          !Number.isSafeInteger(value.eventSeq) || (value.eventSeq as number) < 0 ||
          !Number.isSafeInteger(value.attempt) || (value.attempt as number) < 1 ||
          typeof value.turnId !== "string" || !/^[\x21-\x7e]{1,240}$/.test(value.turnId) ||
          typeof value.callId !== "string" || !/^[\x21-\x7e]{1,240}$/.test(value.callId) ||
          typeof value.tool !== "string" || !/^[\x21-\x7e]{1,240}$/.test(value.tool) ||
          value.argumentsHash !== undefined && (typeof value.argumentsHash !== "string" || !/^[0-9a-f]{64}$/.test(value.argumentsHash))))
        throw new Error("native_tool_call_dispatch_binding_invalid");
      const existing = associations.filter(value => value.callId === input.callId && value.turnId === input.turnId);
      if (existing.length > 1) throw new Error("native_tool_call_dispatch_binding_invalid");
      if (existing.length === 1) {
        const priorAssociation = existing[0]!;
        return priorAssociation.dispatchId === intent.dispatchId && priorAssociation.eventSeq === intent.eventSeq &&
          priorAssociation.attempt === intent.attempt && priorAssociation.tool === input.tool &&
          priorAssociation.argumentsHash === input.argumentsHash;
      }
      if (associations.length >= 512) throw new Error("native_tool_call_dispatch_budget_exceeded");
      const next = [...associations, {
        dispatchId: intent.dispatchId, eventSeq: intent.eventSeq, attempt: intent.attempt,
        turnId: input.turnId, callId: input.callId, tool: input.tool,
        ...(input.argumentsHash ? { argumentsHash: input.argumentsHash } : {}),
      }];
      if (Buffer.byteLength(JSON.stringify(next)) > 2 * 1024 * 1024)
        throw new Error("native_tool_call_dispatch_budget_exceeded");
      const [stored] = await tx.update(heartbeatRuns).set({
        runnerProfileJson: { ...profile, nativeToolCallDispatchAssociations: next }, updatedAt: new Date(),
      }).where(eq(heartbeatRuns.id, run.id)).returning({ profile: heartbeatRuns.runnerProfileJson });
      const retained = record(stored?.profile).nativeToolCallDispatchAssociations;
      if (!Array.isArray(retained) || nativeSha256(retained) !== nativeSha256(next))
        throw new Error("native_tool_call_dispatch_persistence_failed");
      await renewNativeSessionExecutionLease({ ...input, db: tx as unknown as Db });
      return true;
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "";
    throw new Error(["native_session_lease_lost", "native_session_lease_ttl_invalid",
      "native_tool_call_dispatch_binding_invalid", "native_tool_call_dispatch_budget_exceeded",
      "native_tool_call_dispatch_persistence_failed"].includes(message)
      ? message : "native_tool_call_dispatch_persistence_failed");
  }
}

async function recordManagedOpenCodeToolResult(input: Parameters<typeof renewNativeSessionExecutionLease>[0] & {
  agentId: string; turnId: string; callId: string; argumentsHash: string;
  tool: "read_document" | "write_document" | "create_task" | "create_project" | "self_remember" | "read_context" | "call_api" |
    "get_task_context" | "get_task_history" | "read_chat_attachment" | "query_business_metric"; result: unknown;
  contextRead?: NativeContextReadBinding;
  projectRead?: NativeProjectToolResultSource;
  projectCreate?: NativeManagedProjectCreateCapture;
  outputCapture?: NativeModelOutputCapture | null;
}): Promise<void> {
  type CapturePhase = "capture_binding" | "transaction_locks" | "run_receipt" | "provider_dispatch" |
    "project_source" | "memory_source" | "context_source" | "document_task_source" | "receipt_build" | "receipt_persist" | "lease_renew";
  let diagnosticPhase: CapturePhase = "capture_binding";
  let phaseStarted = process.env.PAPERCLIP_NATIVE_CONTEXT_PHASE_DIAGNOSTICS === "1" ? performance.now() : null;
  const markResultPhase = (next: CapturePhase) => {
    if (phaseStarted !== null) {
      const now = performance.now();
      console.error("native_tool_capture_phase_counts", JSON.stringify({
        tool: ["self_remember", "read_context"].includes(input.tool) ? input.tool : "other",
        phase: diagnosticPhase, elapsedMs: now - phaseStarted }));
      phaseStarted = now;
    }
    diagnosticPhase = next;
  };
  const projectRead = input.tool === "call_api" ? input.projectRead : undefined;
  const projectCreate = input.tool === "create_project" ||
    (input.tool === "call_api" && input.projectCreate?.receipt.tool === "call_api") ? input.projectCreate : undefined;
  const projectOutput = input.tool === "call_api" ? record(input.result).data : input.result;
  if ((input.tool === "create_project" || projectCreate) && (!projectCreate ||
    projectCreate.receipt.tool !== (input.tool === "call_api" ? "call_api" : "create_project") ||
    projectCreate.receipt.callId !== input.callId || projectCreate.receipt.argumentsHash !== input.argumentsHash ||
    projectCreate.receipt.resultDigest !== nativeSha256(projectOutput) || !isDeepStrictEqual(projectCreate.project, projectOutput) ||
    !isDeepStrictEqual(projectCreate.sourceSet, projectCreate.outputCapture.sourceSet) ||
    projectCreate.outputCapture.managedOpenCodeToolUse?.callId !== input.callId ||
    projectCreate.outputCapture.managedOpenCodeToolUse?.toolName !== projectCreate.receipt.tool ||
    projectCreate.outputCapture.managedOpenCodeToolUse?.argumentsHash !== input.argumentsHash))
    throw new Error("managed_opencode_tool_result_binding_invalid");
  if (input.tool === "call_api" && !projectCreate && (!projectRead?.source || projectRead.tool !== "call_api" ||
    projectRead.operationId !== "GET /api/projects/{id}" || projectRead.callId !== input.callId ||
    projectRead.turnId !== input.turnId || !/^[0-9a-f]{64}$/.test(projectRead.requestHash) ||
    !/^[0-9a-f]{64}$/.test(projectRead.resultDigest))) throw new Error("managed_opencode_tool_result_binding_invalid");
  const digest = projectRead?.resultDigest ?? (projectCreate && input.tool === "call_api"
    ? nativeSha256({ ok: true, operationId: "call_api", callId: input.callId, result: input.result })
    : nativeSha256(input.result));
  try {
    await input.db.transaction(async tx => {
      markResultPhase("transaction_locks");
      await lockAnalyticalCompany(tx as unknown as Db, input.companyId);
      await lockMemoryPrivacy(tx as unknown as Db, input.companyId);
      await renewNativeSessionExecutionLease({ ...input, db: tx as unknown as Db });
      markResultPhase("run_receipt");
      const [run] = await tx.select().from(heartbeatRuns).where(and(
        eq(heartbeatRuns.companyId, input.companyId), eq(heartbeatRuns.id, input.runId),
        eq(heartbeatRuns.agentId, input.agentId), eq(heartbeatRuns.nativeIssueId, input.issueId),
        eq(heartbeatRuns.runtimeMode, "native"), eq(heartbeatRuns.status, "running"),
      )).for("update");
      const profile = record(run?.runnerProfileJson);
      if (run) assertNativeRunReadSourceHistoryQualified(profile, { runId: input.runId,
        responsibleUserId: run.responsibleUserId });
      const sourceAuthority = record(profile.nativeOpenCodeSourceAuthority);
      const parsed = nativeRunInputSourceReceiptSchema.safeParse(profile.nativeInputSourceReceipt);
      const associations = profile.nativeToolCallDispatchAssociations;
      const call = Array.isArray(associations) ? associations.map(record).filter(value =>
        value.callId === input.callId && value.turnId === input.turnId && value.tool === input.tool &&
        value.argumentsHash === input.argumentsHash) : [];
      if (projectCreate && input.tool === "call_api") {
        const effect = projectCreate.apiEffect;
        if (!effect || effect.operationId !== "POST /api/companies/{companyId}/projects" || effect.method !== "POST" ||
          effect.pathAndQuery !== `/api/companies/${input.companyId}/projects` || effect.turnId !== input.turnId ||
          effect.dispatchId !== call[0]?.dispatchId || effect.eventSeq !== call[0]?.eventSeq ||
          effect.attempt !== call[0]?.attempt || !/^[0-9a-f]{64}$/.test(effect.apiReceiptDigest) ||
          !/^[0-9a-f]{64}$/.test(effect.bodyHash))
          throw new Error("managed_opencode_tool_result_binding_invalid");
      }
      const invocationToolName = input.tool === "self_remember" ? "paperclip-self:remember" : input.tool;
      const nativeReadResultTool = input.tool === "get_task_context" || input.tool === "get_task_history" ||
        input.tool === "read_chat_attachment" || input.tool === "query_business_metric";
      const nativeReadTool = input.tool === "get_task_context" || input.tool === "get_task_history" ||
        (input.tool === "read_chat_attachment" || input.tool === "query_business_metric") ? input.tool : null;
      const nullInvocationTool = input.tool === "call_api" || input.tool === "create_project" || nativeReadResultTool;
      const [invocation] = nullInvocationTool ? [] : await tx.select().from(toolInvocations).where(and(
        eq(toolInvocations.companyId, input.companyId), eq(toolInvocations.runId, input.runId),
        eq(toolInvocations.agentId, input.agentId),
        eq(toolInvocations.idempotencyKey, `aw-native-tool:${input.runId}:${input.callId}`),
        eq(toolInvocations.toolName, invocationToolName), eq(toolInvocations.status, "succeeded"),
        eq(toolInvocations.argumentsHash, input.argumentsHash),
      )).for("share");
      const resultTaskCandidate = record(record(input.result).task);
      const conversationCreateTaskWireIntents = input.tool === "create_task" && resultTaskCandidate.parentId === null &&
        parsed.success && Array.isArray(profile.nativeAwModelWireIntents)
        ? profile.nativeAwModelWireIntents.map(record).filter(intent => {
            if (intent.sourcePolicyHash !== nativeSha256(parsed.data.bootstrap) ||
              intent.modelPurpose !== "conversation_model" || typeof intent.reservationId !== "string") return false;
            const uses = Array.isArray(intent.responseToolUses) ? intent.responseToolUses.map(record) : [];
            return uses.some(use => {
              let name = typeof use.name === "string" ? use.name : "";
              for (const prefix of ["paperclip__", "paperclip_", "paperclip."]) {
                if (name.startsWith(prefix)) { name = name.slice(prefix.length); break; }
              }
              const binding = conversationModelBindingSchema.safeParse(intent.conversationModelBinding);
              return use.id === input.callId && name === "create_task" && use.argumentsHash === input.argumentsHash &&
                binding.success && binding.data.issueId === input.issueId &&
                binding.data.conversationSessionGeneration === run?.contextSnapshot?.conversationSessionGeneration;
            });
          }) : [];
      const nullInvocationCreateTask = conversationCreateTaskWireIntents.length === 1;
      const contentHash = digest;
      let nativeReadCapture: { source: Extract<NativePayloadSourceInput, { kind: "tool_result" }>;
        sourceSet: NativePayloadSourceSet; additionalInput: NativeRunInputSourceReceipt["additionalInputs"][number] } | null = null;
      if (nativeReadResultTool) {
        const capturesRaw = profile.nativeToolResultSourceCaptures;
        const rawCaptures = Array.isArray(capturesRaw) ? capturesRaw.map(record) : [];
        if (capturesRaw !== undefined && !Array.isArray(capturesRaw)) throw new Error("managed_opencode_tool_result_binding_invalid");
        const matches = rawCaptures.filter(value => value.managedOpenCode !== true && value.nativeReadResult === true &&
          value.callId === input.callId && value.turnId === input.turnId && value.tool === input.tool &&
          value.eventSeq === call[0]?.eventSeq && value.attempt === call[0]?.attempt &&
          value.argumentsHash === input.argumentsHash && value.resultDigest === contentHash);
        if (matches.length !== 1) throw new Error("managed_opencode_tool_result_binding_invalid");
        const observed = matches[0]!;
        const sourceResult = nativePayloadSourceInputSchema.safeParse(observed.source);
        const sourceSetValue = record(observed.sourceSet);
        const sourcePolicy = nativePayloadSourcePolicySchema.safeParse(sourceSetValue.policy);
        const sourceInputs = nativePayloadSourceInputSchema.array().safeParse(sourceSetValue.inputs);
        const observedInputs = nativePayloadSourceInputSchema.array().safeParse(observed.sourceInputs);
        if (!sourceResult.success || sourceResult.data.kind !== "tool_result" || sourceResult.data.runId !== input.runId ||
          sourceResult.data.callId !== input.callId || sourceResult.data.toolName !== input.tool ||
          sourceResult.data.invocationId !== null || sourceResult.data.contentHash !== contentHash ||
          observed.resultDigest !== contentHash || !sourcePolicy.success || !sourceInputs.success || !observedInputs.success ||
          !isDeepStrictEqual(sourceInputs.data, observedInputs.data) ||
          new Set(sourceInputs.data.map(value => JSON.stringify(value))).size !== sourceInputs.data.length)
          throw new Error("managed_opencode_tool_result_binding_invalid");
        const entries = parsed.success ? parsed.data.additionalInputs.filter(entry => entry.responsibleUserId === run?.responsibleUserId &&
          isDeepStrictEqual(entry.policy, sourcePolicy.data) &&
          isDeepStrictEqual(entry.inputs, [sourceResult.data, ...sourceInputs.data])) : [];
        const exactCopies = parsed.success ? parsed.data.additionalInputs.reduce((count, entry) => count +
          entry.inputs.filter(value => value.kind === "tool_result" && isDeepStrictEqual(value, sourceResult.data)).length, 0) : 0;
        const conflictingCopies = parsed.success && parsed.data.additionalInputs.some(entry => entry.inputs.some(value =>
          value.kind === "tool_result" && value.callId === input.callId && !isDeepStrictEqual(value, sourceResult.data)));
        if (!parsed.success || entries.length !== 1 || exactCopies !== 1 || conflictingCopies)
          throw new Error("managed_opencode_tool_result_binding_invalid");
        const actor: AuthorizationActor = { type: "agent", source: "none", companyId: input.companyId,
          agentId: input.agentId, runId: input.runId, onBehalfOfUserId: run?.responsibleUserId ?? undefined };
        await assertNativeReadResultSourceSetOwnersCurrent(tx as unknown as Db, { companyId: input.companyId,
          issueId: input.issueId, runId: input.runId, actor, tool: nativeReadTool!, resultDigest: contentHash, sourceSet: { policy: sourcePolicy.data,
            inputs: sourceInputs.data } });
        nativeReadCapture = { source: sourceResult.data, sourceSet: { policy: sourcePolicy.data, inputs: sourceInputs.data },
          additionalInput: entries[0]! };
      }
      if (input.tool === "create_task" && process.env.PAPERCLIP_NATIVE_TEST_TOOL_RESULT_DIAGNOSTICS === "1")
        console.error("managed_create_task_run_receipt_test_facts", JSON.stringify({ runPresent: Boolean(run),
          sourceAuthorityVersion: sourceAuthority.version ?? null, receiptValid: parsed.success, callCount: call.length,
          resultDigestPresent: Boolean(contentHash), invocationPresent: Boolean(invocation),
          invocationResultMatches: invocation?.resultHash === contentHash, invocationIssueMatches: invocation?.issueId === input.issueId,
          receiptCompanyMatches: parsed.success && parsed.data.binding.companyId === input.companyId,
          receiptRunMatches: parsed.success && parsed.data.binding.runId === input.runId,
          receiptAgentMatches: parsed.success && parsed.data.binding.agentId === input.agentId,
          receiptHumanMatches: parsed.success && parsed.data.binding.responsibleUserId === run?.responsibleUserId }));
      if (!run || sourceAuthority.version !== 1 || !parsed.success || call.length !== 1 ||
        !contentHash || (!nullInvocationTool && !nullInvocationCreateTask && (!invocation || invocation.resultHash !== contentHash ||
          invocation.issueId !== input.issueId)) ||
        (input.tool === "self_remember" && nativeSha256(invocation?.workflowResultJson) !== contentHash) ||
        parsed.data.binding.companyId !== input.companyId ||
        parsed.data.binding.runId !== input.runId || parsed.data.binding.agentId !== input.agentId ||
        parsed.data.binding.responsibleUserId !== run.responsibleUserId)
        throw new Error("managed_opencode_tool_result_binding_invalid");
      markResultPhase("provider_dispatch");
      const matchingModelCalls = Array.isArray(profile.nativeAwModelWireIntents)
        ? profile.nativeAwModelWireIntents.map(record).filter(intent => {
            const uses = Array.isArray(intent.responseToolUses) ? intent.responseToolUses.map(record) : [];
            return intent.sourcePolicyHash === nativeSha256(parsed.data.bootstrap) &&
              uses.some(use => {
                let name = typeof use.name === "string" ? use.name : "";
                for (const prefix of ["paperclip__", "paperclip_", "paperclip."]) {
                  if (name.startsWith(prefix)) { name = name.slice(prefix.length); break; }
                }
                const expectedWireName = input.tool === "self_remember" ? "self_remember" : input.tool;
                return use.id === input.callId && name === expectedWireName && use.argumentsHash === input.argumentsHash;
              });
          }) : [];
      if (matchingModelCalls.length !== 1 || typeof matchingModelCalls[0]!.reservationId !== "string")
        throw new Error("managed_opencode_tool_result_binding_invalid");
      const managedOutputCapture = input.outputCapture;
      const managedUse = managedOutputCapture?.managedOpenCodeToolUse;
      const outputCaptureMatchesCall = Boolean(managedOutputCapture && managedOutputCapture.runId === input.runId &&
        managedUse?.callId === input.callId && managedUse.toolName === input.tool &&
        managedUse.argumentsHash === input.argumentsHash && managedUse.responseContentHash === matchingModelCalls[0]!.responseContentHash &&
        managedOutputCapture.dispatch.kind === "worker_model_dispatch" &&
        managedOutputCapture.dispatch.runId === input.runId &&
        managedOutputCapture.dispatch.reservationId === matchingModelCalls[0]!.reservationId &&
        managedOutputCapture.dispatch.callId === matchingModelCalls[0]!.callId &&
        managedOutputCapture.dispatch.requestHash === matchingModelCalls[0]!.requestHash &&
        managedOutputCapture.dispatch.wireBodyHash === matchingModelCalls[0]!.wireBodyHash);
      let returnedProjectSource: Extract<NativePayloadSourceInput, { kind: "project" }> | null = null;
      let createdProjectSource: Extract<NativePayloadSourceInput, { kind: "project" }> | null = null;
      let createdProjectWorkspaceSources: Extract<NativePayloadSourceInput, { kind: "project_workspace" }>[] = [];
      let projectCreateSourceSet: NativePayloadSourceSet | null = null;
      if (input.tool === "call_api" && projectRead) {
        markResultPhase("project_source");
        const source = projectRead?.source;
        const response = record(input.result);
        const { apiOperationId: _apiOperationId, ...responseBody } = response;
        const responseDigest = createHash("sha256").update(JSON.stringify({ ...responseBody,
          apiOperationId: "GET /api/projects/{id}" }), "utf8").digest("hex");
        const projectDto = record(response.data);
        const projectSource = source ? nativePayloadSourceInputSchema.safeParse(source) : null;
        const apiReceipts = record(record(run.resultJson).apiToolReceipts);
        const receiptKey = createHash("sha256").update(input.callId).digest("hex");
        const apiReceipt = record(apiReceipts[receiptKey]);
        const associations = profile.nativeToolCallDispatchAssociations;
        const matchingCaptures = Array.isArray(profile.nativeToolResultSourceCaptures)
          ? profile.nativeToolResultSourceCaptures.map(record).filter(capture => capture.callId === input.callId &&
            capture.turnId === input.turnId && capture.tool === "call_api" && capture.operationId === "GET /api/projects/{id}" &&
            capture.resultDigest === digest && capture.requestHash === projectRead!.requestHash &&
            capture.pathAndQuery === projectRead!.pathAndQuery && isDeepStrictEqual(capture.source, source)) : [];
        const matchingAssociation = Array.isArray(associations) ? associations.map(record).filter(value =>
          value.callId === input.callId && value.turnId === input.turnId && value.tool === "call_api" &&
          value.argumentsHash === input.argumentsHash && value.dispatchId === call[0]!.dispatchId &&
          value.eventSeq === call[0]!.eventSeq && value.attempt === call[0]!.attempt) : [];
        if (!source || !projectSource?.success || projectSource.data.kind !== "project" ||
          projectSource.data.projectId !== projectRead!.projectId || projectRead!.resultDigest !== digest ||
          matchingCaptures.length !== 1 || matchingAssociation.length !== 1 ||
          responseDigest !== digest || response.apiOperationId !== "GET /api/projects/{id}" || response.ok !== true ||
          response.status !== 200 || projectDto.id !== projectSource.data.projectId ||
          createHash("sha256").update(JSON.stringify(projectDto), "utf8").digest("hex") !== projectSource.data.contentHash ||
          apiReceipt.callId !== input.callId || apiReceipt.turnId !== input.turnId ||
          apiReceipt.eventSeq !== call[0]!.eventSeq || apiReceipt.attempt !== call[0]!.attempt ||
          apiReceipt.operationId !== "GET /api/projects/{id}" || apiReceipt.method !== "GET" ||
          apiReceipt.pathAndQuery !== `/api/projects/${projectSource.data.projectId}` ||
          apiReceipt.pathAndQuery !== projectRead!.pathAndQuery ||
          apiReceipt.requestHash !== projectRead!.requestHash || apiReceipt.argumentsHash !== input.argumentsHash ||
          apiReceipt.state !== "completed" || apiReceipt.status !== 200 || apiReceipt.resultDigest !== digest)
          throw new Error("managed_opencode_tool_result_binding_invalid");
        const projectActor: AuthorizationActor = { type: "agent", source: "none", companyId: input.companyId,
          agentId: input.agentId, runId: input.runId, onBehalfOfUserId: run.responsibleUserId ?? undefined };
        await assertNativeProjectSourceCurrent(tx as unknown as Db, { companyId: input.companyId,
          actor: projectActor, source: projectSource.data });
        returnedProjectSource = projectSource.data;
      }
      if (input.tool === "call_api" && projectCreate) {
        markResultPhase("project_source");
        const response = record(input.result);
        const { apiOperationId, ...providerResponse } = response;
        const expectedApiResult = { ...providerResponse,
          operationId: "POST /api/companies/{companyId}/projects" };
        const apiReceipts = record(record(run.resultJson).apiToolReceipts);
        const apiReceipt = record(apiReceipts[createHash("sha256").update(input.callId).digest("hex")]);
        const matchingAssociation = Array.isArray(profile.nativeToolCallDispatchAssociations)
          ? profile.nativeToolCallDispatchAssociations.map(record).filter(value => value.callId === input.callId &&
            value.turnId === input.turnId && value.tool === "call_api" && value.argumentsHash === input.argumentsHash &&
            value.dispatchId === call[0]!.dispatchId && value.eventSeq === call[0]!.eventSeq && value.attempt === call[0]!.attempt)
          : [];
        if (apiOperationId !== "POST /api/companies/{companyId}/projects" || response.ok !== true || response.status !== 201 ||
          !isDeepStrictEqual(response.data, projectCreate.project) || matchingAssociation.length !== 1 ||
          apiReceipt.callId !== input.callId || apiReceipt.turnId !== input.turnId ||
          apiReceipt.eventSeq !== call[0]!.eventSeq || apiReceipt.attempt !== call[0]!.attempt ||
          apiReceipt.operationId !== "POST /api/companies/{companyId}/projects" || apiReceipt.method !== "POST" ||
          apiReceipt.pathAndQuery !== `/api/companies/${input.companyId}/projects` ||
          apiReceipt.argumentsHash !== input.argumentsHash || apiReceipt.state !== "completed" ||
          !/^[0-9a-f]{64}$/.test(String(apiReceipt.digest)) || !isDeepStrictEqual(apiReceipt.result, expectedApiResult) ||
          apiReceipt.providerResultDigest !== nativeSha256({ ok: true, operationId: "call_api", callId: input.callId,
            result: response }))
          throw new Error("managed_opencode_tool_result_binding_invalid");
      }
      if (input.tool === "create_project" || (input.tool === "call_api" && projectCreate)) {
        markResultPhase("project_source");
        const created = projectCreate!;
        const sourcePolicyParse = nativePayloadSourcePolicySchema.safeParse(created.sourceSet.policy);
        const sourceInputsParse = nativePayloadSourceInputSchema.array().safeParse(created.sourceSet.inputs);
        const sourceSetParse = sourcePolicyParse.success && sourceInputsParse.success
          ? { success: true as const, data: { policy: sourcePolicyParse.data, inputs: sourceInputsParse.data } }
          : { success: false as const };
        const projectSourceParse = nativePayloadSourceInputSchema.safeParse(created.receipt.projectSource);
        const workspaceSourcesParse = nativePayloadSourceInputSchema.array().safeParse(created.receipt.workspaceSources);
        if (!sourceSetParse.success || !projectSourceParse.success || projectSourceParse.data.kind !== "project" ||
          !workspaceSourcesParse.success || workspaceSourcesParse.data.some(source => source.kind !== "project_workspace"))
          throw new Error("managed_opencode_tool_result_binding_invalid");
        await assertNativeManagedProjectCreateReceiptCurrentInTransaction(tx, { companyId: input.companyId,
          issueId: input.issueId, runId: input.runId,
          actor: { type: "agent", source: "none", companyId: input.companyId, agentId: input.agentId,
            runId: input.runId, onBehalfOfUserId: run.responsibleUserId ?? undefined },
          receipt: created.receipt, sourceSet: sourceSetParse.data, outputCapture: created.outputCapture, result: projectOutput });
        createdProjectSource = projectSourceParse.data;
        createdProjectWorkspaceSources = workspaceSourcesParse.data as Extract<NativePayloadSourceInput, { kind: "project_workspace" }>[];
        projectCreateSourceSet = sourceSetParse.data;
      }
      const inputSource = nativeReadCapture?.source ?? nativePayloadSourceInputSchema.parse({ kind: "tool_result", runId: input.runId,
        callId: input.callId, toolName: invocationToolName, invocationId: invocation?.id ?? null, contentHash });
      const resultDocument = record(record(input.result).document);
      const documentRevision = input.tool === "write_document" && typeof resultDocument.id === "string" &&
        typeof resultDocument.latestRevisionId === "string"
        ? { issueId: input.issueId, documentId: resultDocument.id, revisionId: resultDocument.latestRevisionId }
        : null;
      let returnedMemorySource: Extract<NativePayloadSourceInput, { kind: "memory" }> | null = null;
      if (input.tool === "self_remember") {
        markResultPhase("memory_source");
        const resultData = record(record(input.result).data);
        const resultMemory = record(resultData.record);
        const memoryId = resultMemory.id;
        const resultScope = record(resultMemory.scope);
        if ((resultData.status !== "accepted" && resultData.status !== "pending" &&
          resultData.status !== "duplicate" && resultData.status !== "corroborated") ||
          typeof memoryId !== "string" || typeof resultMemory.content !== "string")
          throw new Error("managed_opencode_tool_result_binding_invalid");
        const [memory] = await tx.select().from(memoryRecords).where(and(eq(memoryRecords.companyId, input.companyId), eq(memoryRecords.id, memoryId)));
        if (!memory || memory.payloadSourceProtocolVersion !== 1 || memory.payloadSourceSnapshotInvalidated ||
          memory.revokedAt || memory.supersededByRecordId || memory.content !== resultMemory.content ||
          memory.scopeType !== resultScope.type || (memory.scopeId ?? null) !== (resultScope.id ?? null) ||
          memory.ownerAgentId !== (resultMemory.ownerAgentId ?? null) || memory.reviewState !== resultMemory.reviewState ||
          memory.verificationState !== resultMemory.verificationState ||
          (memory.supersedesRecordId ?? null) !== (resultMemory.supersedesRecordId ?? null) ||
          (memory.supersededByRecordId ?? null) !== (resultMemory.supersededByRecordId ?? null))
          throw new Error("managed_opencode_tool_result_binding_invalid");
        const memorySource = nativePayloadSourceInputSchema.parse({ kind: "memory", memoryId: memory.id,
          sourceVersion: memory.updatedAt.toISOString(), contentHash: nativeSha256(memory.content),
          reviewStateAtCapture: memory.reviewState, verificationStateAtCapture: memory.verificationState,
          reviewTransitionStateHash: nativeMemoryReviewTransitionStateHash(memory) });
        if (memorySource.kind !== "memory") throw new Error("managed_opencode_tool_result_binding_invalid");
        await assertNativeMemorySourceInputCurrent(tx as unknown as Db, { companyId: input.companyId,
          actor: { type: "agent", source: "none", companyId: input.companyId, agentId: input.agentId,
            runId: input.runId, onBehalfOfUserId: run.responsibleUserId ?? undefined }, source: memorySource });
        returnedMemorySource = memorySource;
      }
      let contextReadCapture: Record<string, unknown> | null = null;
      if (input.tool === "read_context") {
        markResultPhase("context_source");
        const visible = record(input.result);
        const context = input.contextRead;
        const contextInputs = context?.sourceSet.inputs.filter(source => source.kind === "context") ?? [];
        const currentManifestId = context?.manifestIds[0]?.contextManifestId;
        const currentContextInputs = contextInputs.filter(source => source.kind === "context" && source.manifestId === currentManifestId);
        const contextSourceReferenceCount = context
          ? context.sourceSet.inputs.length + Object.values(context.sourceSet.policy).reduce((sum, ids) => sum + ids.length, 0)
          : Number.POSITIVE_INFINITY;
        if (!context || typeof visible.markdown !== "string" || visible.markdown !== context.markdown ||
          Object.keys(visible).length !== 1 || contextInputs.length === 0 || contextInputs.length > 64 ||
          new Set(contextInputs.map(source => source.manifestId)).size !== contextInputs.length || currentContextInputs.length !== 1 ||
          contextSourceReferenceCount > 256 || context.manifestIds.length !== 1 ||
          context.manifestIds[0]?.companyId !== input.companyId || context.markdown.length > 64_000)
          throw new Error("managed_opencode_tool_result_binding_invalid");
        await assertNativeContextReadSourceSetCurrent(tx as unknown as Db, { companyId: input.companyId,
          agentId: input.agentId, runId: input.runId, issueId: input.issueId,
          actor: { type: "agent", source: "none", companyId: input.companyId, agentId: input.agentId,
            runId: input.runId, onBehalfOfUserId: run.responsibleUserId ?? undefined },
          sourceSet: context.sourceSet, manifestIds: context.manifestIds });
        contextReadCapture = { manifestIds: context.manifestIds, sourceSet: context.sourceSet, contentDigest: digest };
      }
      let returnedDocumentSource: Extract<NativePayloadSourceInput, { kind: "document_revision" }> | null = null;
      if (input.tool === "read_document") {
        markResultPhase("document_task_source");
        const readCaptures = Array.isArray(profile.nativeToolResultSourceCaptures)
          ? profile.nativeToolResultSourceCaptures.map(record).filter(value => value.managedOpenCode !== true &&
              value.callId === input.callId && value.tool === input.tool && value.resultDigest === digest)
          : [];
        const readSource = record(readCaptures[0]?.source);
        const sourceInput = nativePayloadSourceInputSchema.safeParse(readSource.input);
        if (readCaptures.length !== 1 || readSource.returnedResultDigest !== digest || !sourceInput.success ||
          sourceInput.data.kind !== "document_revision" || sourceInput.data.issueId !== input.issueId)
          throw new Error("managed_opencode_tool_result_binding_invalid");
        returnedDocumentSource = sourceInput.data;
      } else if (documentRevision) {
        const [revision] = await tx.select({ body: documentRevisions.body }).from(issueDocuments)
          .innerJoin(documents, and(eq(documents.companyId, issueDocuments.companyId), eq(documents.id, issueDocuments.documentId)))
          .innerJoin(documentRevisions, and(eq(documentRevisions.companyId, documents.companyId),
            eq(documentRevisions.documentId, documents.id), eq(documentRevisions.id, documentRevision.revisionId)))
          .where(and(eq(issueDocuments.companyId, input.companyId), eq(issueDocuments.issueId, input.issueId),
            eq(issueDocuments.documentId, documentRevision.documentId)));
        if (!revision) throw new Error("managed_opencode_tool_result_binding_invalid");
        const parsedDocumentSource = nativePayloadSourceInputSchema.parse({ kind: "document_revision",
          issueId: input.issueId, documentId: documentRevision.documentId, revisionId: documentRevision.revisionId,
          contentHash: createHash("sha256").update(revision.body, "utf8").digest("hex") });
        if (parsedDocumentSource.kind !== "document_revision") throw new Error("managed_opencode_tool_result_binding_invalid");
        returnedDocumentSource = parsedDocumentSource;
      }
      let createdTask: { id: string; source: Extract<NativePayloadSourceInput, { kind: "task" }> } | null = null;
      if (input.tool === "create_task") {
        const resultTask = record(record(input.result).task);
        const conversationBinding = conversationModelBindingSchema.safeParse(matchingModelCalls[0]!.conversationModelBinding);
        const conversationTask = matchingModelCalls[0]!.modelPurpose === "conversation_model" && conversationBinding.success &&
          conversationBinding.data.issueId === input.issueId &&
          conversationBinding.data.conversationSessionGeneration === run.contextSnapshot?.conversationSessionGeneration;
        // A Worker plan may use a Human-sealed conversation as its source root,
        // but its C0 draft Tasks stay detached because conversations cannot gain child edges.
        const workerConversationRootCall = matchingModelCalls[0]!.modelPurpose === "worker_model";
        const [workerConversationRoot] = workerConversationRootCall ? await tx.select({
          conversationAgentId: issues.conversationAgentId, conversationUserId: issues.conversationUserId,
          conversationState: issues.conversationState, conversationSessionGeneration: issues.conversationSessionGeneration,
          conversationRetiredAt: issues.conversationRetiredAt, parentId: issues.parentId,
          assigneeAgentId: issues.assigneeAgentId, executionRunId: issues.executionRunId,
          payloadSourceProtocolVersion: issues.payloadSourceProtocolVersion,
          payloadSourceSnapshot: issues.payloadSourceSnapshot,
          payloadSourceSnapshotInvalidated: issues.payloadSourceSnapshotInvalidated,
        }).from(issues).where(and(eq(issues.companyId, input.companyId), eq(issues.id, input.issueId)))
          .for("share") : [];
        // Human-authored conversation roots remain current in either live
        // state; this Worker path still requires every exact owner/run/snapshot
        // binding below and does not grant ordinary conversation-model use.
        const workerConversationRootCurrent = workerConversationRootCall && isCurrentWorkerConversationRoot({
          scope: "worker_model", root: workerConversationRoot, contextSnapshot: run.contextSnapshot,
          companyId: input.companyId, issueId: input.issueId, agentId: input.agentId,
          responsibleUserId: run.responsibleUserId, runId: input.runId,
        });
        const planBackedDraftCall = matchingModelCalls[0]!.modelPurpose === "worker_model" &&
          resultTask.parentId === null && resultTask.status === "backlog" && outputCaptureMatchesCall;
        const [draftPlan] = planBackedDraftCall ? await tx.select().from(orchestrationPlans).where(and(
          eq(orchestrationPlans.companyId, input.companyId), eq(orchestrationPlans.issueId, input.issueId),
          eq(orchestrationPlans.status, "running"), eq(orchestrationPlans.actionClass, "internal_draft"),
          eq(orchestrationPlans.riskClass, "C0"), isNull(orchestrationPlans.erasedAt),
        )).for("share") : [];
        const planBackedStandaloneDraft = planBackedDraftCall && Boolean(draftPlan);
        const unparentedConversationTask = resultTask.parentId === null && (conversationTask || workerConversationRootCurrent);
        const managedTaskParentBindingValid = typeof resultTask.id === "string" &&
          (typeof resultTask.parentId === "string" || resultTask.parentId === null) &&
          (resultTask.parentId === input.issueId || unparentedConversationTask || planBackedStandaloneDraft);
        if (!managedTaskParentBindingValid && process.env.PAPERCLIP_NATIVE_TEST_TOOL_RESULT_DIAGNOSTICS === "1") {
          const workerConversationSnapshot = nativePayloadSourceSnapshotSchema.safeParse(workerConversationRoot?.payloadSourceSnapshot);
          const workerConversationInputs = workerConversationSnapshot.success ? workerConversationSnapshot.data.inputs : [];
          const workerContext = record(run.contextSnapshot);
          const workerSnapshotOwner = workerConversationSnapshot.success ? workerConversationSnapshot.data.owner : null;
          console.info("managed-create-task-output-binding-miss", JSON.stringify({
            resultIdPresent: typeof resultTask.id === "string",
            resultParentIdNull: resultTask.parentId === null,
            resultParentIsCurrentIssue: resultTask.parentId === input.issueId,
            workerConversationRootCall,
            conversationTask,
            conversationBindingValid: conversationBinding.success,
            conversationBindingIssueCurrent: conversationBinding.success && conversationBinding.data.issueId === input.issueId,
            conversationBindingGenerationCurrent: conversationBinding.success && conversationBinding.data.conversationSessionGeneration === run.contextSnapshot?.conversationSessionGeneration,
            workerConversationRootPresent: workerConversationRoot !== undefined,
            rootAgentCurrent: workerConversationRoot?.conversationAgentId === input.agentId,
            rootHumanCurrent: workerConversationRoot?.conversationUserId === run.responsibleUserId,
            rootStateActive: workerConversationRoot?.conversationState === "active",
            rootStateWaiting: workerConversationRoot?.conversationState === "waiting",
            rootNotRetired: workerConversationRoot?.conversationRetiredAt === null,
            rootHasNoParent: workerConversationRoot?.parentId === null,
            rootAssigneeCurrent: workerConversationRoot?.assigneeAgentId === input.agentId,
            rootExecutionRunCurrent: workerConversationRoot?.executionRunId === input.runId,
            rootProtocolCurrent: workerConversationRoot?.payloadSourceProtocolVersion === 1,
            rootSnapshotNotInvalidated: workerConversationRoot?.payloadSourceSnapshotInvalidated === false,
            rootGenerationCurrent: typeof workerContext.conversationSessionGeneration === "number" &&
              workerConversationRoot?.conversationSessionGeneration === workerContext.conversationSessionGeneration,
            rootSnapshotValid: workerConversationSnapshot.success,
            rootSnapshotOwnerCurrent: workerSnapshotOwner?.kind === "issue" && workerSnapshotOwner.companyId === input.companyId &&
              workerSnapshotOwner.id === input.issueId,
            rootSnapshotHasSingleComment: workerConversationInputs.length === 1 && workerConversationInputs[0]?.kind === "comment" &&
              workerConversationInputs[0].issueId === input.issueId,
            rootSnapshotPolicyEmpty: workerConversationSnapshot.success &&
              Object.values(workerConversationSnapshot.data.policy).every(values => values.length === 0),
            unparentedConversationTask, planBackedDraftCall, draftPlanCurrent: Boolean(draftPlan), outputCaptureMatchesCall,
          }));
        }
        if (!managedTaskParentBindingValid)
          throw new Error("managed_opencode_tool_result_binding_invalid");
        // The predicate above is a composite boolean, so retain its exact
        // validation while making the proven ID type explicit to Drizzle.
        const createdTaskId = resultTask.id as string;
        const [child] = await tx.select({ id: issues.id, identifier: issues.identifier, title: issues.title,
          description: issues.description, status: issues.status, priority: issues.priority, parentId: issues.parentId,
          createdByAgentId: issues.createdByAgentId, originRunId: issues.originRunId, responsibleUserId: issues.responsibleUserId,
          originKind: issues.originKind, originId: issues.originId,
          sourceVersion: sql<string>`extract(epoch from ${issues.updatedAt})::text`,
          ownerBodyHash: sql<string>`public.aw_native_payload_body_hash('issue',to_jsonb(${issues}))`,
        }).from(issues).where(and(eq(issues.companyId, input.companyId), eq(issues.id, createdTaskId),
          unparentedConversationTask || planBackedStandaloneDraft ? isNull(issues.parentId) : eq(issues.parentId, input.issueId)));
        if (!child) throw new Error("managed_opencode_tool_result_binding_invalid");
        if (planBackedStandaloneDraft && (child.createdByAgentId !== input.agentId || child.originRunId !== input.runId ||
          child.responsibleUserId !== run.responsibleUserId || child.status !== "backlog" || child.originKind !== "manual" ||
          typeof child.originId !== "string" || !child.originId.startsWith(`paperclip-runner:create-task:${input.issueId}:`)))
          throw new Error("managed_opencode_tool_result_binding_invalid");
        const taskInput = nativePayloadSourceInputSchema.parse({ kind: "task", issueId: child.id,
          sourceVersion: child.sourceVersion, contentHash: child.ownerBodyHash });
        if (taskInput.kind !== "task") throw new Error("managed_opencode_tool_result_binding_invalid");
        createdTask = { id: child.id, source: taskInput };
      }
      const capturesRaw = profile.nativeToolResultSourceCaptures;
      if (capturesRaw !== undefined && !Array.isArray(capturesRaw))
        throw new Error("managed_opencode_tool_result_budget_exceeded");
      const captures = Array.isArray(capturesRaw) ? capturesRaw : [];
      if (captures.some(value => {
        const item = record(value);
        return item.callId === input.callId && item.turnId === input.turnId && item.tool === input.tool && item.managedOpenCode === true;
      })) throw new Error("managed_opencode_tool_result_duplicate");
      // Replace the provisional original-owner read observation with the
      // provider-settled capture so later validators see one exact source row.
      const priorCaptures = nativeReadCapture ? captures.filter(value => {
        const item = record(value);
        return !(item.managedOpenCode !== true && item.nativeReadResult === true && item.callId === input.callId &&
          item.turnId === input.turnId && item.tool === input.tool && item.resultDigest === contentHash);
      }) : captures;
      if (priorCaptures.length >= 256) throw new Error("managed_opencode_tool_result_budget_exceeded");
      const nextCaptures = [...priorCaptures, { eventSeq: call[0]!.eventSeq, attempt: call[0]!.attempt,
        turnId: input.turnId, callId: input.callId, tool: input.tool, argumentsHash: input.argumentsHash, resultDigest: contentHash,
        source: { kind: "tool_result", runId: input.runId, callId: input.callId, toolName: invocationToolName,
          invocationId: invocation?.id ?? null, contentHash }, documentRevision,
        ...(nativeReadCapture ? { nativeReadResult: true, sourceSet: nativeReadCapture.sourceSet,
          sourceInputs: nativeReadCapture.sourceSet.inputs } : {}),
        ...(returnedProjectSource ? { projectSource: returnedProjectSource } : {}),
        ...(projectCreateSourceSet ? { projectCreate: { receipt: projectCreate!.receipt,
          sourceSet: projectCreateSourceSet, workspaceSources: createdProjectWorkspaceSources,
          outputCapture: projectCreate!.outputCapture,
          ...(projectCreate!.apiEffect ? { apiEffect: projectCreate!.apiEffect } : {}) } } : {}),
        taskRef: createdTask ? { issueId: createdTask.id } : null,
        ...(contextReadCapture ? { contextRead: contextReadCapture } : {}), managedOpenCode: true }];
      const { digest: _receiptDigest, ...body } = parsed.data;
      const createdProjectPolicy = projectCreateSourceSet && createdProjectSource ? {
        ...projectCreateSourceSet.policy,
        projectIds: [...new Set([...projectCreateSourceSet.policy.projectIds, createdProjectSource.projectId])].sort(),
      } : null;
      const updatedReceiptBody = { ...body, additionalInputs: nativeReadCapture
        ? parsed.data.additionalInputs
        : [...parsed.data.additionalInputs, {
          responsibleUserId: run.responsibleUserId,
          ...(projectCreateSourceSet && createdProjectSource && createdProjectPolicy ? {
            policy: createdProjectPolicy,
            inputs: unionNativePayloadSourceInputs([[inputSource], projectCreateSourceSet.inputs,
              [createdProjectSource, ...createdProjectWorkspaceSources]]),
          } : input.tool === "read_context" && input.contextRead ? {
            policy: input.contextRead.sourceSet.policy,
            inputs: [inputSource, ...input.contextRead.sourceSet.inputs],
          } : {
            // The tool_result.runId is provenance for this invocation, not a consumed
            // retained_run source. Only returned Task/document owners add source policy.
            policy: { issueIds: [...new Set([...(createdTask ? [createdTask.id] : []),
              ...(returnedDocumentSource?.issueId ? [returnedDocumentSource.issueId] : [])])],
              projectIds: returnedProjectSource ? [returnedProjectSource.projectId] : [],
              runIds: [], memoryIds: returnedMemorySource ? [returnedMemorySource.memoryId] : [], foundationRevisionIds: [] },
            inputs: [inputSource, ...(returnedDocumentSource ? [returnedDocumentSource] : []),
              ...(createdTask ? [createdTask.source] : []), ...(returnedMemorySource ? [returnedMemorySource] : []),
              ...(returnedProjectSource ? [returnedProjectSource] : [])],
          }),
        }] };
      markResultPhase("receipt_build");
      const receipt = { ...updatedReceiptBody, digest: await postgresJsonbSha256(tx, updatedReceiptBody) };
      if (!nativeRunInputSourceReceiptSchema.safeParse(receipt).success || Buffer.byteLength(JSON.stringify(nextCaptures)) > 2 * 1024 * 1024)
        throw new Error("managed_opencode_tool_result_budget_exceeded");
      const [stored] = await tx.update(heartbeatRuns).set({ runnerProfileJson: {
        ...profile, nativeInputSourceReceipt: receipt, nativeToolResultSourceCaptures: nextCaptures,
      }, updatedAt: new Date() }).where(and(eq(heartbeatRuns.companyId, input.companyId), eq(heartbeatRuns.id, input.runId), eq(heartbeatRuns.status, "running")))
        .returning({ profile: heartbeatRuns.runnerProfileJson });
      markResultPhase("receipt_persist");
      const retained = record(stored?.profile);
      if (!nativeRunInputSourceReceiptSchema.safeParse(retained.nativeInputSourceReceipt).success ||
        !Array.isArray(retained.nativeToolResultSourceCaptures) || nativeSha256(retained.nativeToolResultSourceCaptures) !== nativeSha256(nextCaptures))
        throw new Error("managed_opencode_tool_result_persistence_failed");
      markResultPhase("lease_renew");
      await renewNativeSessionExecutionLease({ ...input, db: tx as unknown as Db });
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "";
    if (process.env.PAPERCLIP_NATIVE_TEST_TOOL_RESULT_DIAGNOSTICS === "1") {
      const diagnostic = error && typeof error === "object" ? error as Error & { code?: unknown; cause?: { code?: unknown }; status?: unknown } : null;
      const safeCode = (value: unknown) => typeof value === "string" && /^[A-Z0-9_:-]{1,80}$/i.test(value) ? value : null;
      const frames = diagnostic?.stack?.split("\n").slice(1).flatMap(frame => {
        const match = /server\/src\/services\/([^\s():]+\.ts):(\d+):\d+/.exec(frame);
        return match ? [`${match[1]}:${match[2]}`] : [];
      }).slice(0, 6) ?? [];
      console.error("managed_opencode_tool_result_test_failure", JSON.stringify({
        name: diagnostic?.name ?? "UnknownError", code: safeCode(diagnostic?.code), causeCode: safeCode(diagnostic?.cause?.code),
        status: typeof diagnostic?.status === "number" && Number.isInteger(diagnostic.status) ? diagnostic.status : null,
        mappedCode: ["native_session_lease_lost", "native_session_lease_ttl_invalid",
          "managed_opencode_tool_result_binding_invalid", "managed_opencode_tool_result_budget_exceeded",
          "managed_opencode_tool_result_duplicate", "managed_opencode_tool_result_persistence_failed"].includes(message)
          ? message : "managed_opencode_tool_result_persistence_failed",
        phase: diagnosticPhase,
        frames,
      }));
    }
    throw new Error(["native_session_lease_lost", "native_session_lease_ttl_invalid",
      "managed_opencode_tool_result_binding_invalid", "managed_opencode_tool_result_budget_exceeded",
      "managed_opencode_tool_result_duplicate", "managed_opencode_tool_result_persistence_failed"].includes(message)
      ? message : "managed_opencode_tool_result_persistence_failed");
  } finally { markResultPhase(diagnosticPhase); }
}

async function assertManagedOpenCodeToolCallCurrent(input: Parameters<typeof renewNativeSessionExecutionLease>[0] & {
  agentId: string; eventSeq: number; turnId: string; callId: string; tool: string; argumentsHash: string; arguments: unknown;
}): Promise<void> {
  await assertNativeAnalyticalRunPayloadAccess(input.db, input.companyId, input.runId);
  const [run] = await input.db.select().from(heartbeatRuns).where(and(
    eq(heartbeatRuns.companyId, input.companyId), eq(heartbeatRuns.id, input.runId),
    eq(heartbeatRuns.agentId, input.agentId), eq(heartbeatRuns.nativeIssueId, input.issueId),
    eq(heartbeatRuns.runtimeMode, "native"), eq(heartbeatRuns.status, "running"),
  ));
  const profile = record(run?.runnerProfileJson);
  const authority = record(profile.nativeOpenCodeSourceAuthority);
  const receipt = nativeRunInputSourceReceiptSchema.safeParse(profile.nativeInputSourceReceipt);
  const attachmentStage = run && receipt.success
    ? nativeAttachmentStageAuthorityBinding(profile, run, receipt.data.bootstrap,
      { eventSeq: input.eventSeq, attempt: input.attempt }) : { valid: false, stageHash: null };
  if (!run || !receipt.success || authority.version !== 1 ||
    authority.executionInputHash !== nativeSha256(profile.nativeExecutionInput) || !attachmentStage.valid ||
    (authority.attachmentStageHash ?? null) !== attachmentStage.stageHash)
    throw new Error("managed_opencode_tool_call_source_binding_invalid");
  const bootstrapHash = nativeSha256(receipt.data.bootstrap);
  const sourceIntents = Array.isArray(profile.nativeAwModelWireIntents)
    ? profile.nativeAwModelWireIntents.map(record).filter(intent => intent.sourcePolicyHash === bootstrapHash) : [];
  const matchingCallId = sourceIntents.flatMap(intent =>
    Array.isArray(intent.responseToolUses) ? intent.responseToolUses.map(record).map(use => ({ intent, use })) : [])
    .filter(value => value.use.id === input.callId);
  if (matchingCallId.length !== 1) throw new Error(matchingCallId.length === 0
    ? "managed_opencode_tool_call_response_id_unmatched" : "managed_opencode_tool_call_response_id_ambiguous");
  const callName = typeof matchingCallId[0]!.use.name === "string" ? matchingCallId[0]!.use.name : "";
  let normalizedName = callName;
  for (const prefix of ["paperclip__", "paperclip_", "paperclip."]) {
    if (normalizedName.startsWith(prefix)) { normalizedName = normalizedName.slice(prefix.length); break; }
  }
  if (normalizedName !== input.tool) throw new Error("managed_opencode_tool_call_response_tool_mismatch");
  if (matchingCallId[0]!.use.argumentsHash !== input.argumentsHash)
    throw new Error("managed_opencode_tool_call_response_arguments_mismatch");
  if (input.tool === "call_api") {
    const args = record(input.arguments), pathParams = record(args.pathParams);
    const uuid = typeof pathParams.id === "string" &&
      /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/.test(pathParams.id) && pathParams.id === pathParams.id.toLowerCase();
    const projectRead = isDeepStrictEqual(Object.keys(args).sort(), ["operationId", "pathParams"]) &&
      args.operationId === "GET /api/projects/{id}" && isDeepStrictEqual(Object.keys(pathParams), ["id"]) && uuid;
    const projectCreate = managedNativeProjectApiCallSchema.safeParse(input.arguments);
    if (!projectRead && (!projectCreate.success || projectCreate.data.pathParams.companyId !== input.companyId))
      throw new Error("managed_opencode_project_api_operation_not_supported");
  }
  if (input.tool === "create_project") {
    if (!managedNativeProjectArgumentsSchema.safeParse(input.arguments).success)
      throw new Error("managed_opencode_project_create_arguments_not_supported");
  }
  const matchedIntent = matchingCallId[0]!.intent;
  if (typeof matchedIntent.responseContentHash !== "string" || typeof matchedIntent.reservationId !== "string")
    throw new Error("managed_opencode_tool_call_response_receipt_missing");
  const purpose = matchedIntent.modelPurpose === "conversation_model" ? "conversation_model" :
    matchedIntent.modelPurpose === "worker_model" ? "worker_model" : null;
  const [reservation] = purpose ? await input.db.select().from(orchestrationModelReservations).where(and(
    eq(orchestrationModelReservations.companyId, input.companyId),
    eq(orchestrationModelReservations.id, matchedIntent.reservationId),
    eq(orchestrationModelReservations.purpose, purpose),
    eq(orchestrationModelReservations.status, "completed"),
  )) : [];
  const binding = purpose === "conversation_model"
    ? conversationModelBindingSchema.safeParse(matchedIntent.conversationModelBinding) : null;
  if (!reservation || reservation.status !== "completed" || typeof reservation.providerResponseHash !== "string" ||
    (purpose === "conversation_model" && (!binding?.success || reservation.conversationAgentId !== input.agentId ||
      reservation.conversationRunId !== input.runId || reservation.conversationIssueId !== input.issueId ||
      reservation.conversationSessionGeneration !== binding?.data.conversationSessionGeneration ||
      reservation.executionManifestId !== binding?.data.executionManifestId ||
      reservation.executionManifestHash !== binding?.data.executionManifestHash)))
    throw new Error("managed_opencode_tool_call_response_unsettled");
}

async function prepareManagedOpenCodeOutputCapture(input: Parameters<typeof renewNativeSessionExecutionLease>[0] & {
  agentId: string; eventSeq: number; turnId: string; callId: string; tool: string; argumentsHash: string; arguments: unknown;
}): Promise<NativeModelOutputCapture> {
  await assertManagedOpenCodeToolCallCurrent(input);
  const [run] = await input.db.select().from(heartbeatRuns).where(and(
    eq(heartbeatRuns.companyId, input.companyId), eq(heartbeatRuns.id, input.runId),
    eq(heartbeatRuns.agentId, input.agentId), eq(heartbeatRuns.nativeIssueId, input.issueId),
    eq(heartbeatRuns.runtimeMode, "native"), eq(heartbeatRuns.status, "running"),
  ));
  const profile = record(run?.runnerProfileJson);
  if (run) assertNativeRunReadSourceHistoryQualified(profile, { runId: input.runId,
    responsibleUserId: run.responsibleUserId });
  const receipt = nativeRunInputSourceReceiptSchema.safeParse(profile.nativeInputSourceReceipt);
  if (!run || !receipt.success) throw new Error("managed_opencode_output_capture_source_unavailable");
  const bootstrapHash = nativeSha256(receipt.data.bootstrap);
  const matching = Array.isArray(profile.nativeAwModelWireIntents)
    ? profile.nativeAwModelWireIntents.map(record).filter(intent => {
        const calls = Array.isArray(intent.responseToolUses) ? intent.responseToolUses.map(record) : [];
        return intent.sourcePolicyHash === bootstrapHash && calls.some(call => {
          let name = typeof call.name === "string" ? call.name : "";
          for (const prefix of ["paperclip__", "paperclip_", "paperclip."]) {
            if (name.startsWith(prefix)) { name = name.slice(prefix.length); break; }
          }
          return call.id === input.callId && name === input.tool && call.argumentsHash === input.argumentsHash;
        });
      }) : [];
  if (matching.length !== 1 || typeof matching[0]!.reservationId !== "string" ||
    typeof matching[0]!.responseContentHash !== "string")
    throw new Error("managed_opencode_output_capture_tool_use_ambiguous");
  const intent = matching[0]!;
  const purpose = intent.modelPurpose === "conversation_model" ? "conversation_model" :
    intent.modelPurpose === "worker_model" ? "worker_model" : null;
  const [reservation] = purpose ? await input.db.select().from(orchestrationModelReservations).where(and(
    eq(orchestrationModelReservations.companyId, input.companyId),
    eq(orchestrationModelReservations.id, intent.reservationId as string),
    eq(orchestrationModelReservations.purpose, purpose), eq(orchestrationModelReservations.status, "completed"),
  )) : [];
  const conversationBinding = purpose === "conversation_model"
    ? conversationModelBindingSchema.safeParse(intent.conversationModelBinding) : null;
  const conversationBindingData = conversationBinding?.success ? conversationBinding.data : null;
  if (!reservation || reservation.status !== "completed" || typeof reservation.providerResponseHash !== "string" ||
    reservation.inputHash !== intent.requestHash || (purpose === "conversation_model" &&
      (!conversationBinding?.success || reservation.conversationAgentId !== input.agentId ||
        reservation.conversationRunId !== input.runId || reservation.conversationIssueId !== input.issueId ||
        reservation.conversationSessionGeneration !== conversationBindingData?.conversationSessionGeneration ||
        reservation.executionManifestId !== conversationBindingData?.executionManifestId ||
        reservation.executionManifestHash !== conversationBindingData?.executionManifestHash)))
    throw new Error("managed_opencode_output_capture_reservation_unavailable");
  const parsedDispatchInput = nativePayloadSourceInputSchema.parse(purpose === "conversation_model" ? {
    kind: "conversation_model_dispatch", runId: input.runId, agentId: input.agentId, issueId: input.issueId,
    conversationSessionGeneration: conversationBindingData!.conversationSessionGeneration,
    executionManifestId: conversationBindingData!.executionManifestId,
    executionManifestHash: conversationBindingData!.executionManifestHash, reservationId: reservation.id,
    callId: intent.callId, requestHash: intent.requestHash, wireBodyHash: intent.wireBodyHash,
    responseHash: reservation.providerResponseHash,
  } : { kind: "worker_model_dispatch", runId: input.runId, reservationId: reservation.id,
    callId: intent.callId, requestHash: intent.requestHash, wireBodyHash: intent.wireBodyHash,
    responseHash: reservation.providerResponseHash });
  if (parsedDispatchInput.kind !== "worker_model_dispatch" && parsedDispatchInput.kind !== "conversation_model_dispatch")
    throw new Error("managed_opencode_output_capture_dispatch_unavailable");
  const dispatchInput: Extract<NativePayloadSourceInput, { kind: "worker_model_dispatch" | "conversation_model_dispatch" }> = parsedDispatchInput;
  const dispatches = receipt.data.dispatches;
  const matchingDispatches = dispatches.filter(dispatch => dispatch.inputs.some(source => source.kind === dispatchInput.kind &&
    source.reservationId === reservation.id && source.callId === intent.callId && source.requestHash === intent.requestHash &&
    source.wireBodyHash === intent.wireBodyHash && source.responseHash === reservation.providerResponseHash));
  if (matchingDispatches.length < 1) throw new Error("managed_opencode_output_capture_dispatch_unavailable");
  const consumedRaw = record(intent.consumedSourceSet);
  const consumedPolicy = nativePayloadSourcePolicySchema.safeParse(consumedRaw.policy);
  const consumedInputs = nativePayloadSourceInputSchema.array().safeParse(consumedRaw.inputs);
  const sourceComponents = intent.consumedSourceComponents;
  if (!consumedPolicy.success || !consumedInputs.success || !Array.isArray(sourceComponents) ||
    intent.consumedSourceSetHash !== nativeSha256({ policy: consumedPolicy.data, inputs: consumedInputs.data }))
    throw new Error("managed_opencode_output_capture_consumed_sources_invalid");
  const sourceSet: NativePayloadSourceSet = { policy: consumedPolicy.data, inputs: consumedInputs.data };
  const typedComponents = sourceComponents as NativeConsumedSourceComponent[];
  if (input.tool !== "self_remember") {
    await assertNativeManagedConsumedSourceSetCurrent(input.db, { companyId: input.companyId, issueId: input.issueId,
      runId: input.runId, actor: { type: "agent", source: "none", companyId: input.companyId,
        agentId: input.agentId, runId: input.runId, onBehalfOfUserId: run.responsibleUserId ?? undefined },
      components: typedComponents, sourceSet });
  }
  // Managed self_remember rechecks the complete captured source closure after
  // its canonical Memory detail read and before the creating transaction commits;
  // the succeeded-result sealing pass rechecks it again after the Gateway settles.
  return {
    runId: input.runId,
    sourceSet,
    consumedSourceComponents: typedComponents,
    dispatch: dispatchInput,
    managedOpenCodeToolUse: {
      callId: input.callId,
      toolName: input.tool === "self_remember" ? "paperclip-self:remember" : input.tool,
      argumentsHash: input.argumentsHash,
      responseContentHash: intent.responseContentHash as string,
    },
  };
}

/** A fact about one document result selected for return, not delivery,
 * source permission or a complete model-input receipt. */
async function persistNativeToolResultSourceCapture(input: Parameters<typeof renewNativeSessionExecutionLease>[0] & {
  agentId: string; eventSeq: number;
}, capture: NativeDocumentToolResultSource | NativeProjectToolResultSource, family: "document" | "project"): Promise<void> {
  const bindingError = `native_${family}_tool_capture_binding_invalid`;
  const budgetError = `native_${family}_tool_capture_budget_exceeded`;
  const persistenceError = `native_${family}_tool_capture_persistence_failed`;
  try {
    await input.db.transaction(async tx => {
      if (family === "project") {
        await lockAnalyticalCompany(tx as unknown as Db, input.companyId);
        await lockMemoryPrivacy(tx as unknown as Db, input.companyId);
      }
      // Same owned coordinator -> run -> launch order as selected turn inputs.
      await renewNativeSessionExecutionLease({ ...input, db: tx as unknown as Db });
      const [run] = await tx.select().from(heartbeatRuns).where(and(
        eq(heartbeatRuns.id, input.runId), eq(heartbeatRuns.companyId, input.companyId),
        eq(heartbeatRuns.agentId, input.agentId), eq(heartbeatRuns.nativeIssueId, input.issueId),
        eq(heartbeatRuns.runtimeMode, "native"), eq(heartbeatRuns.status, "running"),
      )).for("update");
      if (!run) throw new Error(bindingError);
      const [launch] = await tx.select({ seq: heartbeatRunEvents.seq }).from(heartbeatRunEvents).where(and(
        eq(heartbeatRunEvents.companyId, input.companyId), eq(heartbeatRunEvents.runId, input.runId),
        eq(heartbeatRunEvents.agentId, input.agentId), eq(heartbeatRunEvents.seq, input.eventSeq),
        eq(heartbeatRunEvents.eventType, PROCESS_START_REQUESTED),
      )).for("share");
      if (!launch) throw new Error(bindingError);
      const profile = record(run.runnerProfileJson);
      if (family === "project") {
        const projectCapture = capture as NativeProjectToolResultSource;
        if (projectCapture.source) {
          const source = nativePayloadSourceInputSchema.parse(projectCapture.source);
          if (source.kind !== "project" || source.projectId !== projectCapture.projectId ||
            !/^[0-9a-f]{64}$/.test(projectCapture.requestHash)) throw new Error(bindingError);
          const projectActor: AuthorizationActor = {
            type: "agent", source: "none", companyId: input.companyId, agentId: input.agentId,
            runId: input.runId, onBehalfOfUserId: run.responsibleUserId ?? undefined,
          };
          if (projectCapture.projectId !== source.projectId) throw new Error(bindingError);
          await assertNativeProjectSourceCurrent(tx as unknown as Db, { companyId: input.companyId,
            actor: projectActor, source });
        }
      }
      const legacy = profile.nativeDocumentToolResultSources;
      const current = profile.nativeToolResultSourceCaptures;
      if ((legacy !== undefined && !Array.isArray(legacy)) || (current !== undefined && !Array.isArray(current)))
        throw new Error(bindingError);
      // During a rolling deploy, an older node may still append to the legacy
      // document-only field while this writer appends to the shared field.
      // Preserve both histories and collapse only exact duplicate facts.
      const previous: unknown[] = [];
      const seenFacts = new Set<string>();
      for (const fact of [...(legacy as unknown[] | undefined ?? []), ...(current as unknown[] | undefined ?? [])]) {
        const factHash = nativeSha256(fact);
        if (!seenFacts.has(factHash)) {
          seenFacts.add(factHash);
          previous.push(fact);
        }
      }
      if (previous.length >= 256) throw new Error(budgetError);
      const selectedDispatch = resolveNativeInputDispatchReceiptIdentity(profile,
        capture.turnId === null ? null : { turnId: capture.turnId, callId: capture.callId, tool: capture.tool }, capture.tool);
      const nativeInputDispatch = selectedDispatch?.eventSeq === launch.seq && selectedDispatch.attempt === input.attempt
        ? selectedDispatch : null;
      const projectBinding = capture.tool === "call_api"
        ? { operationId: capture.operationId, projectId: capture.projectId, requestHash: capture.requestHash,
          pathAndQuery: capture.pathAndQuery } : {};
      const captures = [...previous, { eventSeq: launch.seq, attempt: input.attempt, turnId: capture.turnId,
        nativeInputDispatch, responsibleUserId: run.responsibleUserId ?? null, callId: capture.callId,
        tool: capture.tool, ...projectBinding, resultDigest: capture.resultDigest, source: capture.source }];
      if (Buffer.byteLength(JSON.stringify(captures)) > 2 * 1024 * 1024) throw new Error(budgetError);
      const nextProfile: Record<string, unknown> = { ...profile, nativeToolResultSourceCaptures: captures };
      delete nextProfile.nativeDocumentToolResultSources;
      const [stored] = await tx.update(heartbeatRuns).set({
        runnerProfileJson: nextProfile, updatedAt: new Date(),
      }).where(eq(heartbeatRuns.id, run.id)).returning({ profile: heartbeatRuns.runnerProfileJson });
      const retained = record(stored?.profile).nativeToolResultSourceCaptures;
      if (!Array.isArray(retained) || nativeSha256(retained) !== nativeSha256(captures)) throw new Error(persistenceError);
      await renewNativeSessionExecutionLease({ ...input, db: tx as unknown as Db });
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "";
    throw new Error(["native_session_lease_lost", "native_session_lease_ttl_invalid", bindingError, budgetError].includes(message)
      ? message : persistenceError);
  }
}

export async function recordNativeDocumentToolResultIntent(input: Parameters<typeof renewNativeSessionExecutionLease>[0] & {
  agentId: string; eventSeq: number; capture: NativeDocumentToolResultSource;
}): Promise<void> {
  try {
    const capture = input.capture;
    if (!Number.isSafeInteger(input.eventSeq) || input.eventSeq < 0 || capture.tool !== "read_document" ||
      !/^[\x21-\x7e]{1,240}$/.test(capture.callId) || !/^[0-9a-f]{64}$/.test(capture.resultDigest) ||
      capture.turnId !== null && (typeof capture.turnId !== "string" || !/^[\x21-\x7e]{1,240}$/.test(capture.turnId)))
      throw new Error("native_document_tool_capture_binding_invalid");
    let source: DocumentRevisionSourceCapture | null = null;
    if (capture.source !== null) {
      const inputSource = nativePayloadSourceInputSchema.parse(capture.source.input);
      const snapshot = capture.source.payloadSourceSnapshot === null ? null
        : nativePayloadSourceSnapshotSchema.parse(capture.source.payloadSourceSnapshot);
      if (inputSource.kind !== "document_revision" || inputSource.issueId !== input.issueId ||
      capture.source.returnedResultDigest !== capture.resultDigest ||
        snapshot && (snapshot.owner.kind !== "document_revision" || snapshot.owner.companyId !== input.companyId ||
          snapshot.owner.id !== inputSource.revisionId))
        throw new Error("native_document_tool_capture_binding_invalid");
    source = { input: inputSource, payloadSourceSnapshot: snapshot, returnedResultDigest: capture.source.returnedResultDigest };
    }
    await persistNativeToolResultSourceCapture(input, { ...capture, source }, "document");
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "";
    throw new Error(["native_session_lease_lost", "native_session_lease_ttl_invalid",
      "native_document_tool_capture_binding_invalid", "native_document_tool_capture_budget_exceeded"].includes(message)
      ? message : "native_document_tool_capture_persistence_failed");
  }
}

/** Retains a Native tool result and, only when its original owner supplied a
 * complete source set and the acknowledged provider dispatch association is
 * exact, appends that result plus its source inputs to the run receipt. */
export async function recordNativeInputToolResultIntent(input: Parameters<typeof renewNativeSessionExecutionLease>[0] & {
  agentId: string; eventSeq: number; capture: NativeInputToolResultSource;
}): Promise<void> {
  const bindingError = "native_tool_result_capture_binding_invalid";
  const budgetError = "native_tool_result_capture_budget_exceeded";
  try {
    const capture = input.capture;
    const readTool = capture.tool === "get_task_context" || capture.tool === "get_task_history" ||
      (capture.tool === "read_chat_attachment" || capture.tool === "query_business_metric") ? capture.tool : null;
    const supportedNativeRead = readTool !== null;
    if (!Number.isSafeInteger(input.eventSeq) || input.eventSeq < 0 || !supportedNativeRead ||
      !/^[\x21-\x7e]{1,240}$/.test(capture.callId) || !/^[\x21-\x7e]{1,240}$/.test(capture.tool) ||
      !/^[0-9a-f]{64}$/.test(capture.argumentsHash) ||
      !/^[0-9a-f]{64}$/.test(capture.resultDigest) || nativeSha256(capture.result) !== capture.resultDigest ||
      capture.turnId !== null && !/^[\x21-\x7e]{1,240}$/.test(capture.turnId)) throw new Error(bindingError);
    const observedInputs = nativePayloadSourceInputSchema.array().safeParse(capture.observedSourceInputs);
    const capturedSourceSet = capture.sourceSet;
    const sourcePolicy = capturedSourceSet ? nativePayloadSourcePolicySchema.safeParse(capturedSourceSet.policy) : null;
    const sourceInputs = capturedSourceSet ? nativePayloadSourceInputSchema.array().safeParse(capturedSourceSet.inputs) : null;
    const sourceSetContainsObservedInputs = observedInputs.success && sourceInputs?.success &&
      new Set(sourceInputs.data.map(value => JSON.stringify(value))).size === sourceInputs.data.length &&
      new Set(observedInputs.data.map(value => JSON.stringify(value))).size === observedInputs.data.length &&
      observedInputs.data.every(observed => sourceInputs.data.filter(value => isDeepStrictEqual(value, observed)).length === 1);
    if (!observedInputs.success || capturedSourceSet && (!sourcePolicy?.success || !sourceInputs?.success ||
      !sourceSetContainsObservedInputs)) throw new Error(bindingError);
    const qualifiedSourceSet = capturedSourceSet && sourcePolicy?.success && sourceInputs?.success
      ? { policy: sourcePolicy.data, inputs: sourceInputs.data }
      : null;

    await input.db.transaction(async tx => {
      await lockAnalyticalCompany(tx as unknown as Db, input.companyId);
      await lockMemoryPrivacy(tx as unknown as Db, input.companyId);
      await renewNativeSessionExecutionLease({ ...input, db: tx as unknown as Db });
      const [run] = await tx.select().from(heartbeatRuns).where(and(
        eq(heartbeatRuns.id, input.runId), eq(heartbeatRuns.companyId, input.companyId),
        eq(heartbeatRuns.agentId, input.agentId), eq(heartbeatRuns.nativeIssueId, input.issueId),
        eq(heartbeatRuns.runtimeMode, "native"), eq(heartbeatRuns.status, "running"),
      )).for("update");
      const [launch] = await tx.select({ seq: heartbeatRunEvents.seq }).from(heartbeatRunEvents).where(and(
        eq(heartbeatRunEvents.companyId, input.companyId), eq(heartbeatRunEvents.runId, input.runId),
        eq(heartbeatRunEvents.agentId, input.agentId), eq(heartbeatRunEvents.seq, input.eventSeq),
        eq(heartbeatRunEvents.eventType, PROCESS_START_REQUESTED),
      )).for("share");
      if (!run || !launch || launch.seq !== input.eventSeq) throw new Error(bindingError);
      const profile = record(run.runnerProfileJson);
      const capturesRaw = profile.nativeToolResultSourceCaptures;
      if (capturesRaw !== undefined && !Array.isArray(capturesRaw)) throw new Error(bindingError);
      const captures = (capturesRaw as unknown[] | undefined) ?? [];
      if (captures.some(value => {
        const row = record(value);
        return !value || typeof value !== "object" || Array.isArray(value) ||
          typeof row.callId !== "string" || typeof row.tool !== "string" ||
          typeof row.resultDigest !== "string" || !/^[0-9a-f]{64}$/.test(row.resultDigest);
      })) throw new Error(bindingError);
      if (captures.length >= 256 || Buffer.byteLength(JSON.stringify(captures)) > 2 * 1024 * 1024)
        throw new Error(budgetError);
      const dispatch = capture.turnId ? resolveNativeInputDispatchReceiptIdentity(profile,
        { tool: capture.tool, callId: capture.callId, turnId: capture.turnId }, capture.tool) : null;
      const nativeInputDispatch = dispatch?.eventSeq === input.eventSeq && dispatch.attempt === input.attempt
        ? dispatch : null;
      const associations = Array.isArray(profile.nativeToolCallDispatchAssociations)
        ? profile.nativeToolCallDispatchAssociations.map(record).filter(value => value.callId === capture.callId &&
          value.turnId === capture.turnId && value.tool === capture.tool && value.argumentsHash === capture.argumentsHash &&
          value.dispatchId === nativeInputDispatch?.dispatchId && value.eventSeq === input.eventSeq && value.attempt === input.attempt)
        : [];
      let source: Extract<NativePayloadSourceInput, { kind: "tool_result" }> | null = null;
      let nextReceipt: NativeRunInputSourceReceipt | null = null;
      const parsedReceipt = nativeRunInputSourceReceiptSchema.safeParse(profile.nativeInputSourceReceipt);
      if (qualifiedSourceSet && nativeInputDispatch && associations.length === 1 && parsedReceipt.success &&
        typeof run.responsibleUserId === "string" && parsedReceipt.data.binding.companyId === input.companyId &&
        parsedReceipt.data.binding.runId === input.runId && parsedReceipt.data.binding.agentId === input.agentId &&
        parsedReceipt.data.binding.issueId === input.issueId &&
        parsedReceipt.data.binding.responsibleUserId === run.responsibleUserId) {
        const parsedSource = nativePayloadSourceInputSchema.safeParse({ kind: "tool_result", runId: input.runId,
          callId: capture.callId, toolName: capture.tool, invocationId: null, contentHash: capture.resultDigest });
        if (parsedSource.success && parsedSource.data.kind === "tool_result") {
            // Validate exact source rows while holding the same privacy and run
            // transaction locks used to append the additional-input receipt.
            await assertNativeReadResultSourceSetOwnersCurrent(tx as unknown as Db, { companyId: input.companyId,
              issueId: input.issueId, runId: input.runId,
              tool: readTool!, resultDigest: capture.resultDigest,
              actor: { type: "agent", source: "none", companyId: input.companyId, agentId: input.agentId,
                runId: input.runId, onBehalfOfUserId: run.responsibleUserId },
              sourceSet: qualifiedSourceSet });
            source = parsedSource.data;
            const existing = parsedReceipt.data.additionalInputs.filter(entry => entry.responsibleUserId === run.responsibleUserId &&
              isDeepStrictEqual(entry.policy, qualifiedSourceSet.policy) &&
              isDeepStrictEqual(entry.inputs, [source, ...qualifiedSourceSet.inputs]));
            if (existing.length > 1) throw new Error(bindingError);
            if (existing.length === 0) {
              const { digest: _previousDigest, ...body } = parsedReceipt.data;
              const nextBody = { ...body, additionalInputs: [...body.additionalInputs, {
                responsibleUserId: run.responsibleUserId, policy: qualifiedSourceSet.policy,
                inputs: [source, ...qualifiedSourceSet.inputs],
              }] };
              const candidate = { ...nextBody, digest: await postgresJsonbSha256(tx, nextBody) };
              const parsed = nativeRunInputSourceReceiptSchema.safeParse(candidate);
              if (!parsed.success) throw new Error(bindingError);
              nextReceipt = parsed.data;
            } else nextReceipt = parsedReceipt.data;
        }
      }
      if (captures.some(value => {
        const row = record(value);
        return row.callId === capture.callId && row.tool === capture.tool && row.resultDigest === capture.resultDigest;
      })) throw new Error(bindingError);
      const nextCaptures = [...captures, { eventSeq: launch.seq, attempt: input.attempt,
        turnId: capture.turnId, nativeInputDispatch, callId: capture.callId, tool: capture.tool,
        argumentsHash: capture.argumentsHash, resultDigest: capture.resultDigest, source,
        sourceInputs: qualifiedSourceSet?.inputs ?? observedInputs.data,
        ...(qualifiedSourceSet ? { sourceSet: qualifiedSourceSet } : {}), nativeReadResult: true }];
      if (Buffer.byteLength(JSON.stringify(nextCaptures)) > 2 * 1024 * 1024) throw new Error(budgetError);
      const nextProfile = { ...profile, nativeToolResultSourceCaptures: nextCaptures,
        ...(nextReceipt ? { nativeInputSourceReceipt: nextReceipt } : {}) };
      const [stored] = await tx.update(heartbeatRuns).set({ runnerProfileJson: nextProfile, updatedAt: new Date() })
        .where(and(eq(heartbeatRuns.companyId, input.companyId), eq(heartbeatRuns.id, input.runId), eq(heartbeatRuns.status, "running")))
        .returning({ profile: heartbeatRuns.runnerProfileJson });
      const retained = record(stored?.profile);
      if (!Array.isArray(retained.nativeToolResultSourceCaptures) ||
        nativeSha256(retained.nativeToolResultSourceCaptures) !== nativeSha256(nextCaptures) ||
        nextReceipt && !nativeRunInputSourceReceiptSchema.safeParse(retained.nativeInputSourceReceipt).success)
        throw new Error("native_tool_result_capture_persistence_failed");
      await renewNativeSessionExecutionLease({ ...input, db: tx as unknown as Db });
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "";
    throw new Error(["native_session_lease_lost", "native_session_lease_ttl_invalid", bindingError, budgetError].includes(message)
      ? message : "native_tool_result_capture_persistence_failed");
  }
}

/** Records the exact public Project projection returned by one authenticated
 * Native API tool result. It does not assert provider consumption, source
 * permission after this read, or closure completeness. */
export async function recordNativeProjectToolResultIntent(input: Parameters<typeof renewNativeSessionExecutionLease>[0] & {
  agentId: string; eventSeq: number; capture: NativeProjectToolResultSource;
}): Promise<void> {
  try {
    const capture = input.capture;
    if (!Number.isSafeInteger(input.eventSeq) || input.eventSeq < 0 || capture.tool !== "call_api" ||
      capture.operationId !== "GET /api/projects/{id}" || !/^[\x21-\x7e]{1,240}$/.test(capture.callId) ||
      !/^[0-9a-f]{64}$/.test(capture.resultDigest) ||
      !/^[0-9a-f]{64}$/.test(capture.requestHash) ||
      !/^\/api\/projects\/[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/.test(capture.pathAndQuery) ||
      capture.pathAndQuery !== `/api/projects/${capture.projectId}` ||
      capture.turnId !== null && !/^[\x21-\x7e]{1,240}$/.test(capture.turnId) ||
      capture.projectId !== null && !/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/.test(capture.projectId))
      throw new Error("native_project_tool_capture_binding_invalid");
    let source: Extract<NativePayloadSourceInput, { kind: "project" }> | null = null;
    if (capture.source !== null) {
      const parsed = nativePayloadSourceInputSchema.parse(capture.source);
      if (parsed.kind !== "project" || parsed.projectId !== capture.projectId)
        throw new Error("native_project_tool_capture_binding_invalid");
      source = parsed;
    }
    await persistNativeToolResultSourceCapture(input, { ...capture, source }, "project");
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "";
    throw new Error(["native_session_lease_lost", "native_session_lease_ttl_invalid",
      "native_project_tool_capture_binding_invalid", "native_project_tool_capture_budget_exceeded"].includes(message)
      ? message : "native_project_tool_capture_persistence_failed");
  }
}

function startNativeSessionExecutionLeaseRenewal(input: {
  db: Db;
  runId: string;
  companyId: string;
  issueId: string;
  leaseOwner: string;
  attempt: number;
  controller: NativeControllerIdentity;
}): { stop: () => Promise<void> } {
  let leaseLost: Error | null = null;
  let renewal = Promise.resolve();
  const renew = () => {
    if (leaseLost) return;
    renewal = renewal
      .then(async () => {
        await assertNativeAnalyticalRunPayloadAccess(input.db, input.companyId, input.runId);
        await renewNativeSessionExecutionLease(input);
      })
      .then(() => undefined)
      .catch(async (error: unknown) => {
        leaseLost =
          error instanceof Error
            ? error
            : new Error("native_session_lease_lost");
        recordNativeCancelOriginTestFact(input.runId, {
          stage: "lease_renewal_failed",
          reason: leaseLost instanceof HttpError && (leaseLost.details as {code?:unknown}|undefined)?.code === "analytical_source_access_lost"
            ? "analytical_source_access_lost" : "execution_lease_lost",
        });
        await cancelNativeSession(
          input.runId,
          leaseLost instanceof HttpError && (leaseLost.details as {code?:unknown}|undefined)?.code === "analytical_source_access_lost"
            ? "native analytical source access lost" : "native session execution lease lost",
        ).catch(() => undefined);
      });
  };
  const timer = setInterval(
    renew,
    NATIVE_SESSION_EXECUTION_LEASE_RENEW_INTERVAL_MS,
  );
  timer.unref?.();
  return {
    stop: async () => {
      clearInterval(timer);
      await renewal;
      if (leaseLost) throw leaseLost;
    },
  };
}

export async function executePaperclipNativeSession(input: {
  db: Db;
  execution: NativeExecutionInput;
  /** Canonical immutable Heartbeat input hash, before per-run staged descriptors are appended. */
  nativeBootstrapExecutionInputHash?: string;
  /** Compiler-owned closed bootstrap source set; NULL means unknown. */
  bootstrapSourceClosure?: NativeBootstrapSourceClosure | null;
  /** Rebuild the exact bootstrap closure after inbound files are verified and staged. */
  prepareBootstrapSourceClosure?: (input: {
    execution: NativeExecutionInput;
    attachmentStage: Awaited<ReturnType<typeof stageNativeRunnerWakeAttachments>>;
  }) => NativeBootstrapSourceClosure | null;
  /** Trusted Heartbeat-owned per-turn source refresh. The returned turnInput
   * is the exact value passed to startTurn and its closure is bound at dispatch. */
  prepareTurnSourceClosure?: (turnInput: Parameters<NativeSession["startTurn"]>[0],
    bootstrapSourceClosure?: NativeBootstrapSourceClosure | null) => Promise<{
    turnInput: Parameters<NativeSession["startTurn"]>[0];
    sourceClosure?: NativeBootstrapSourceClosure;
  }>;
  runnerInstanceId: string;
  /** Trusted task identity from the heartbeat orchestration. */
  conversationMode?: boolean;
  /** Configured total turn bound; zero/unset is unlimited. */
  turnTimeoutMs?: number;
  leaseOwner?: string;
  restartRecovery?: NativeRestartRecoveryClaim;
  onSpawn?: (meta: {
    pid: number;
    processGroupId: number | null;
    startedAt: string;
    identitySource?: "remote_marker";
    remoteRunnerInstanceId?: string;
  }) => Promise<void>;
  /** Test seam at the provider boundary; production uses a qualified package backend. */
  backend?: NativeSessionBackend;
  useRunnerd?: boolean;
  /** Paperclip adapter identity used to scope the durable goal projection. */
  adapterType?: string;
  /** Internal, run-owned file inspection lifetime; never supplied by tool arguments. */
  chatAttachmentReadScope?: NativeChatAttachmentReadScope;
  onLog?: (stream: "stdout" | "stderr", chunk: string) => Promise<void>;
  onEvent?: (event: AdapterRuntimeEvent) => Promise<void>;
  /** Persist task-level continuity before a durable goal can outlive this run. */
  onGoalCheckpoint?: (snapshot: PersistedNativeSession) => Promise<void>;
  sessionGoalControl?: NativeSessionGoalControl | null;
  resumeSessionGoalHeartbeat?: boolean;
  preparationSpans?: NativeRunHistoricalSpan[];
  /** Use a session-owned GitHub broker, rebound only after run ownership is acquired. */
  managedGitHub?: boolean;
  /** Test fixture only: pause at the original Project owner before mutation. */
  testBeforeManagedProjectCreate?: (capture: NativeModelOutputCapture) => Promise<void>;
  /** Test fixture only: exercise same-call replay after the original Project transaction commits. */
  testAfterManagedProjectCreate?: (input: { actor: AuthorizationActor; companyId: string; issueId: string; capture: NativeModelOutputCapture; callId: string;
    arguments: Record<string, unknown>; result: { project: Record<string, unknown>; receipt: NativeProjectCreateReceipt;
      sourceSet: NativePayloadSourceSet } }) => Promise<void>;
  /** Resolved adapter env; the runner transport applies a provider allowlist before spawn. */
  runnerEnvironment?: NodeJS.ProcessEnv;
  /** Private grant materialization; never a user-configured host path. */
  managedAiCredentialHome?: string;
  managedAiCredentialIdentity?: string;
  runnerExecutionTarget?: AdapterExecutionTarget | null;
  /** Resolved per-run authorization; not an independent instance setting. */
  runnerIngressAuthorized?: boolean;
  runnerPublicUrl?: string | null;
  runnerCaBundlePath?: string | null;
  runnerRemoteBinaryPath?: string | null;
  runnerRemoteCodexPath?: string | null;
  runnerRemoteCodexNpmSpec?: string | null;
  runnerRemoteProviderPackPath?: string | null;
  stopTaskForReassignment?: (target: { companyId: string; issueId: string; agentId: string; runId: string | null }) => Promise<void>;
  enqueueWakeup?: (
    agentId: string,
    options: {
      source: "assignment";
      triggerDetail: "system";
      reason: "issue_assigned";
      payload: Record<string, unknown>;
      idempotencyKey: string;
      requestedByActorType: "agent";
      requestedByActorId: string;
      contextSnapshot: Record<string, unknown>;
    },
  ) => Promise<unknown>;
}): Promise<AdapterExecutionResult> {
  assertNativePaidTransportAdmitted({
    provider: input.execution.provider.kind,
    adapterType: input.adapterType,
    companyId: input.execution.binding.companyId,
    agentId: input.execution.binding.agentId,
    serverOwnedDraft:
      input.execution.provider.kind === "aw_text_only" && input.backend !== undefined && input.useRunnerd !== true,
    useRunnerd: input.useRunnerd,
    backendDriverKind: input.execution.session.driverKind,
    executionTarget: input.runnerExecutionTarget,
  });
  const runId = input.execution.binding.runId;
  if (nativeSessionStartups.has(runId)) {
    throw new Error("native_session_supervisor_busy");
  }
  // Register before the first asynchronous operation on either backend path.
  // A duplicate execution must not replace the original startup handoff.
  let resolveStartup!: (session: ActiveNativeSession | null) => void;
  const startup: NativeSessionStartup = {
    promise: new Promise<ActiveNativeSession | null>(resolve => { resolveStartup = resolve; }),
    resolve: session => resolveStartup(session),
  };
  nativeSessionStartups.set(runId, startup);
  let preparedInput: typeof input = input;
  let cleanupStagedAttachments: () => Promise<void> = async () => undefined;
  let sessionScopeId: string | null = null;
  let ownsSessionScope = false;
  let executionFailure: unknown;
  try {
    await assertNativeAnalyticalRunPayloadAccess(input.db, input.execution.binding.companyId, runId);
    if (!input.useRunnerd) {
      const [wake] = await input.db.select({ contextSnapshot: heartbeatRuns.contextSnapshot }).from(heartbeatRuns).where(and(
        eq(heartbeatRuns.companyId, input.execution.binding.companyId), eq(heartbeatRuns.id, runId),
      )).limit(1);
      const savedSources = record(wake?.contextSnapshot).selectedSavedSources;
      if (Array.isArray(savedSources) && savedSources.length > 0) {
        throw new Error("native_reconstruction_selected_saved_source_staging_unavailable");
      }
      return await executePaperclipNativeSessionWithinScope(input);
    }
    // The session scope is unaffected by appending server-staged attachment
    // descriptors. Claim it before any workspace scrub/write so a duplicate
    // execution cannot truncate or replace the active turn's staging inode.
    sessionScopeId = nativeSessionScopeKey(input.execution);
    if (executingRunnerdSessionScopes.has(sessionScopeId)) {
      throw new Error("native_session_supervisor_busy");
    }
    executingRunnerdSessionScopes.set(
      sessionScopeId,
      input.execution.binding.runId,
    );
    ownsSessionScope = true;
    // The shutdown sweep can have removed an idle owner while its remote
    // checkpoint is still being saved. The scope reservation also prevents
    // a later sweep from closing an owner this turn is about to acquire.
    await closingWarmNativeSessions.get(sessionScopeId);

    const targetKind = input.runnerExecutionTarget?.kind ?? "local";
    const chatAttachmentReadScope = new NativeChatAttachmentReadScope({
      db: input.db,
      binding: input.execution.binding,
      workspaceRoot: input.execution.workspace.cwd,
      executionTargetKind: targetKind,
    });
    preparedInput = { ...input, nativeBootstrapExecutionInputHash: nativeSha256(input.execution), chatAttachmentReadScope };
    cleanupStagedAttachments = () => chatAttachmentReadScope.close();
    const attachmentStage = await stageNativeRunnerWakeAttachments({
      db: input.db,
      binding: {
        companyId: input.execution.binding.companyId,
        issueId: input.execution.binding.issueId,
        runId: input.execution.binding.runId,
        agentId: input.execution.binding.agentId,
        workspaceRoot: input.execution.workspace.cwd,
        executionTargetKind: targetKind,
      },
    });
    cleanupStagedAttachments = async () => {
      const cleanupResults = await Promise.allSettled([
        chatAttachmentReadScope.close(),
        attachmentStage.cleanup(),
      ]);
      if (cleanupResults.some((result) => result.status === "rejected")) {
        throw new Error("paperclip_runner_attachment_staging_cleanup_failed");
      }
    };
    for (const requiredSource of attachmentStage.requiredSavedSources ?? []) {
      const capture = attachmentStage.sourceCaptures.find(item => item.input.attachmentId === requiredSource.attachmentId);
      if (capture?.input.disposition === "remote_workspace_staging_unsupported") {
        throw new Error("native_reconstruction_remote_workspace_staging_unsupported");
      }
      if (capture?.input.disposition !== "delivered" || !capture.input.sha256) {
        throw new Error("native_reconstruction_selected_saved_source_unavailable");
      }
      if (capture.input.sha256.toLowerCase() !== requiredSource.sha256) {
        throw new Error("native_reconstruction_selected_saved_source_hash_mismatch");
      }
    }
    const stagedPrompt = renderNativeRunnerStagedAttachmentPrompt(
      attachmentStage.attachments,
    );
    if (stagedPrompt) {
      preparedInput = {
        ...preparedInput,
        execution: parseNativeExecutionInput({
          ...input.execution,
          task: {
            ...input.execution.task,
            prompt: `${input.execution.task.prompt}\n\n${stagedPrompt}`,
          },
        }),
      };
    }
    if (input.prepareBootstrapSourceClosure) {
      preparedInput = { ...preparedInput,
        bootstrapSourceClosure: input.prepareBootstrapSourceClosure({
          execution: preparedInput.execution,
          attachmentStage,
        }) };
    }
    return await executePaperclipNativeSessionWithinScope(preparedInput, attachmentStage.sourceCaptures,
      attachmentStage.attachments, input.execution);
  } catch (error) {
    executionFailure = error;
    throw error;
  } finally {
    startup.resolve(null);
    if (nativeSessionStartups.get(runId) === startup) {
      nativeSessionStartups.delete(runId);
    }
    if (
      ownsSessionScope &&
      sessionScopeId !== null &&
      executingRunnerdSessionScopes.get(sessionScopeId) ===
        input.execution.binding.runId
    ) {
      executingRunnerdSessionScopes.delete(sessionScopeId);
    }
    try {
      await cleanupStagedAttachments();
    } catch (cleanupError) {
      // Cleanup is a confidentiality incident, but it occurs after the native
      // provider may already have completed the turn. Reclassifying that turn
      // as failed could replay provider side effects. Emit a private runtime
      // health event while preserving the provider result/error disposition.
      await input
        .onEvent?.({
          eventType: "native.attachment_staging_cleanup_failed",
          level: "error",
          message: "Native inbound attachment staging cleanup failed.",
          payload: {
            runId: input.execution.binding.runId,
            issueId: input.execution.binding.issueId,
            executionAlreadyFailed: executionFailure !== undefined,
          },
        })
        .catch(() => undefined);
    }
  }
}

async function executePaperclipNativeSessionWithinScope(
  input: Parameters<typeof executePaperclipNativeSession>[0],
  stagedAttachmentSources?: readonly NativeRunnerAttachmentSourceCapture[],
  stagedAttachments?: Awaited<ReturnType<typeof stageNativeRunnerWakeAttachments>>["attachments"],
  baseExecution?: NativeExecutionInput,
): Promise<AdapterExecutionResult> {
  const runId = input.execution.binding.runId;
  if (
    input.execution.provider.kind !== "codex" &&
    input.execution.provider.kind !== "opencode" &&
    input.execution.provider.kind !== "claude_managed" &&
    input.execution.provider.kind !== "aws_agentcore" &&
    input.execution.provider.kind !== "acpx"
    && input.execution.provider.kind !== "aw_text_only"
  ) {
    throw new Error("paperclip_runner_provider_unsupported");
  }
  if (input.execution.provider.kind === "aw_text_only" && (!input.backend || input.useRunnerd))
    throw new Error("aw_text_draft_requires_private_controller_backend");
  if (
    input.execution.provider.kind === "acpx" &&
    input.execution.provider.agent === "pi"
  ) {
    throw new Error(
      "paperclip_runner_provider_unsupported: ACPX Pi is unavailable until descriptor-confined verified launch is implemented",
    );
  }
  const preparationSpans = input.preparationSpans ?? [];
  const preparationStarts = nativeRunPreparationStarts(
    preparationSpans,
    Date.now(),
  );
  const trace = createNativeRunTrace({
    runId: input.execution.binding.runId,
    startedAtMs: preparationStarts.runStartedAtMs,
    onEvent: input.onEvent,
  });
  const toolTrace = createNativeToolTrace(trace);
  const taskPrepareScope = trace.start("task.prepare", {
    parentName: "task.run",
    startedAtMs: preparationStarts.preparationStartedAtMs,
  });
  const environmentSpans = preparationSpans.filter(
    (span) =>
      span.name === "environment.acquire" ||
      span.name === "environment.workspace.realize",
  );
  const environmentStartedAtMs = environmentSpans.reduce(
    (earliest, span) => Math.min(earliest, span.startedAtMs),
    Date.now(),
  );
  const environmentEndedAtMs = environmentSpans.reduce(
    (latest, span) => Math.max(latest, span.endedAtMs),
    environmentStartedAtMs,
  );
  const environmentScope =
    environmentSpans.length > 0
      ? trace.start("environment.startup", {
          parentName: "task.prepare",
          startedAtMs: environmentStartedAtMs,
        })
      : null;
  for (const span of preparationSpans) {
    const rootMilestone = isNativeRunRootHistoricalSpan(span.name);
    await trace.record({
      ...span,
      parentName: rootMilestone
        ? "task.run"
        : environmentSpans.includes(span)
          ? "environment.startup"
          : "task.prepare",
    });
  }
  if (environmentScope) {
    await trace.end(environmentScope, { endedAtMs: environmentEndedAtMs });
  }
  let retainedTransition: VerifiedWarmTransitionBinding | undefined;
  if (input.useRunnerd) {
    retainedTransition = await migrateRunnerdStateRootForExecution({
      db: input.db,
      execution: input.execution,
      allowVerifiedBackup:
        input.runnerExecutionTarget?.kind === "remote" &&
        input.runnerExecutionTarget.transport === "sandbox",
      // A retained warm runner is deliberately still ready rather than
      // suspended. Only the exact idle in-process owner may rotate that
      // prior-run authority; after a hard restart the map is empty and the
      // durable-state verifier continues to require a suspended runner.
      allowRetainedWarmRunner: hasIdleWarmNativeSessionOwner(input),
      allowLocalRecovery: input.runnerExecutionTarget?.kind !== "remote",
      onLog: input.onLog,
      restartRecovery: input.restartRecovery,
      runnerExecutionTarget: input.runnerExecutionTarget,
      conversationMode: input.conversationMode,
    });
  }
  const durableRunnerBinding = input.useRunnerd
    ? loadRunnerdDurableBinding(input.execution, retainedTransition)
    : null;
  const effectiveRunnerInstanceId =
    durableRunnerBinding?.runnerInstanceId ?? input.runnerInstanceId;
  if (effectiveRunnerInstanceId !== input.runnerInstanceId) {
    await input.db
      .update(heartbeatRuns)
      .set({
        runnerInstanceId: effectiveRunnerInstanceId,
        updatedAt: new Date(),
      })
      .where(
        and(
          eq(heartbeatRuns.id, input.execution.binding.runId),
          eq(heartbeatRuns.companyId, input.execution.binding.companyId),
          eq(heartbeatRuns.agentId, input.execution.binding.agentId),
        ),
      );
  }
  const leaseOwner =
    input.leaseOwner ?? `${effectiveRunnerInstanceId}:${randomUUID()}`;
  const controller = await currentNativeControllerIdentity();
  const leaseNow = new Date();
  const leaseExpiresAt = new Date(leaseNow.getTime() + 20 * 60_000);
  let attempt: number;
  try {
    attempt = await trace.measure(
      "native.coordinator.claim",
      () =>
        input.db.transaction(async (tx) => {
          const coordinator = await tx
            .select()
            .from(nativeRunFinalizations)
            .where(
              and(
                eq(nativeRunFinalizations.runId, input.execution.binding.runId),
                eq(
                  nativeRunFinalizations.companyId,
                  input.execution.binding.companyId,
                ),
                eq(
                  nativeRunFinalizations.issueId,
                  input.execution.binding.issueId,
                ),
              ),
            )
            .for("update")
            .limit(1)
            .then((rows) => rows[0] ?? null);
          if (!coordinator)
            throw new Error("native_finalization_coordinator_missing");
          const leaseNow = new Date();
          const leaseExpiresAt = new Date(
            leaseNow.getTime() + NATIVE_SESSION_EXECUTION_LEASE_TTL_MS,
          );
          // A durable result means provider execution already completed. The
          // recovery/finalization path must reconcile it; never reacquire a
          // provider session and execute the turn a second time.
          if (coordinator.resultId)
            throw new NativeResultPendingFinalizationError();
          const boundRun = await tx
            .select({
              retryOfRunId: heartbeatRuns.retryOfRunId,
              scheduledRetryReason: heartbeatRuns.scheduledRetryReason,
              agentId: heartbeatRuns.agentId,
              companyId: heartbeatRuns.companyId,
              nativeIssueId: heartbeatRuns.nativeIssueId,
              resultJson: heartbeatRuns.resultJson,
              runtimeMode: heartbeatRuns.runtimeMode,
              status: heartbeatRuns.status,
            })
            .from(heartbeatRuns)
            .where(eq(heartbeatRuns.id, input.execution.binding.runId))
            .for("update")
            .limit(1)
            .then((rows) => rows[0] ?? null);
          if (
            !boundRun ||
            boundRun.runtimeMode !== "native" ||
            boundRun.companyId !== input.execution.binding.companyId ||
            boundRun.agentId !== input.execution.binding.agentId ||
            boundRun.nativeIssueId !== input.execution.binding.issueId
          ) {
            throw new Error("native_execution_binding_changed");
          }
          // A cancellation can win after heartbeat dispatch admission but
          // before this claim. Never revive a terminal run or a settled startup.
          if (boundRun.status !== "running" || boundRun.resultJson?.startupCancellation ||
              coordinator.phase === "terminal_failure") {
            throw new NativeCancellationPendingRecoveryError();
          }
          const cancellationIntent = record(
            record(boundRun.resultJson).nativeCancellation,
          );
          if (
            cancellationIntent.scope === "run" &&
            (cancellationIntent.dispatchState === "pending" ||
              cancellationIntent.dispatchState === "acknowledged")
          ) {
            const intentMatchesBinding =
              cancellationIntent.schema ===
                "paperclip.native-cancellation.v1" &&
              cancellationIntent.companyId ===
                input.execution.binding.companyId &&
              cancellationIntent.runId === input.execution.binding.runId &&
              cancellationIntent.issueId === input.execution.binding.issueId;
            if (!intentMatchesBinding)
              throw new Error("native_cancellation_intent_conflict");
            // Run cancellation remains a claim fence after dispatch ack until
            // the heartbeat cancellation path terminalizes the run.
            throw new NativeCancellationPendingRecoveryError();
          }
          if (["committed", "applied"].includes(coordinator.phase))
            throw new Error("native_run_already_committed");
          if (
            coordinator.leaseOwner &&
            coordinator.leaseOwner !== leaseOwner &&
            coordinator.leaseExpiresAt &&
            coordinator.leaseExpiresAt > leaseNow
          )
            throw new Error("native_finalization_lease_busy");
          const recovering = input.restartRecovery;
          if (
            recovering &&
            (recovering.runId !== coordinator.runId ||
              recovering.leaseOwner !== leaseOwner ||
              coordinator.leaseOwner !== leaseOwner ||
              coordinator.controllerBootId !== controller.bootId ||
              coordinator.controllerPid !== controller.pid ||
              coordinator.controllerGeneration !==
                recovering.controllerGeneration)
          ) {
            throw new Error("native_restart_recovery_claim_changed");
          }
          let incidentAttempts = coordinator.attempt;
          if (
            boundRun.retryOfRunId &&
            boundRun.scheduledRetryReason === "native_safe_replacement"
          ) {
            const [predecessor] = await tx
              .select()
              .from(nativeRunFinalizations)
              .where(
                and(
                  eq(nativeRunFinalizations.runId, boundRun.retryOfRunId),
                  eq(
                    nativeRunFinalizations.companyId,
                    input.execution.binding.companyId,
                  ),
                  eq(
                    nativeRunFinalizations.issueId,
                    input.execution.binding.issueId,
                  ),
                ),
              );
            if (
              !predecessor ||
              predecessor.failureDetail?.successorRunId !==
                input.execution.binding.runId ||
              predecessor.phase !== "terminal_failure"
            )
              throw new Error("native_replacement_lineage_invalid");
            incidentAttempts = Math.max(incidentAttempts, predecessor.attempt);
          }
          const nextAttempt = nextNativeProviderAttempt(
            incidentAttempts,
            recovering?.kind,
          );
          if (nextAttempt > 3)
            throw new Error("native_session_retry_exhausted");
          const nextControllerGeneration = recovering
            ? recovering.controllerGeneration
            : coordinator.controllerBootId === controller.bootId
              ? Math.max(1, coordinator.controllerGeneration)
              : coordinator.controllerGeneration + 1;
          const claimed = await tx
            .update(nativeRunFinalizations)
            .set({
              phase: "observed",
              attempt: nextAttempt,
              leaseOwner,
              leaseExpiresAt,
              controllerBootId: controller.bootId,
              controllerPid: controller.pid,
              controllerProcessStartedAt: controller.processStartedAt,
              controllerGeneration: nextControllerGeneration,
              failureCode: null,
              failureDetail: null,
              nextAttemptAt: null,
              updatedAt: leaseNow,
            })
            .where(
              and(
                eq(nativeRunFinalizations.runId, coordinator.runId),
                eq(
                  nativeRunFinalizations.companyId,
                  input.execution.binding.companyId,
                ),
                eq(
                  nativeRunFinalizations.issueId,
                  input.execution.binding.issueId,
                ),
                eq(nativeRunFinalizations.attempt, coordinator.attempt),
                eq(nativeRunFinalizations.phase, coordinator.phase),
              ),
            )
            .returning({ runId: nativeRunFinalizations.runId })
            .then((rows) => rows[0] ?? null);
          if (!claimed) throw new Error("native_session_lease_lost");
          await tx
            .update(heartbeatRuns)
            .set({
              nativePhase: "observed",
              nativePhaseUpdatedAt: leaseNow,
              updatedAt: leaseNow,
            })
            .where(eq(heartbeatRuns.id, coordinator.runId));
          return nextAttempt;
        }),
      { parentName: "task.prepare" },
    );
    await trace.end(taskPrepareScope);
  } catch (error) {
    await trace.end(taskPrepareScope, { outcome: "failed" });
    await trace.finish("failed");
    throw error;
  }
  const controlPlaneInstanceId = `${effectiveRunnerInstanceId}:control`;
  const planSynchronizations: PlanSynchronization[] = [];
  const upsertPlanSynchronization = (
    synchronization: PlanSynchronization,
  ): void => {
    const existingIndex = planSynchronizations.findIndex(
      (candidate) => candidate.eventId === synchronization.eventId,
    );
    if (existingIndex >= 0) {
      planSynchronizations[existingIndex] = synchronization;
      return;
    }
    planSynchronizations.push(synchronization);
  };
  const recordPlanSynchronization = async (event: {
    sourceEventId: string;
    turnId?: string;
    eventType: string;
    payload: Record<string, unknown>;
  }) => {
    const synchronization = await synchronizeCompletedProviderPlan({
      db: input.db,
      execution: input.execution,
      event,
    });
    if (!synchronization) return;
    upsertPlanSynchronization(synchronization);
    const activity = await persistActivity(input.db, {
      companyId: input.execution.binding.companyId,
      actorType: "agent",
      actorId: input.execution.binding.agentId,
      agentId: input.execution.binding.agentId,
      runId: input.execution.binding.runId,
      issueId: input.execution.binding.issueId,
      action: "issue.document_updated",
      entityType: "issue",
      entityId: input.execution.binding.issueId,
      details: {
        key: "plan",
        source: "native_plan_synchronization",
        synchronization,
      },
    });
    publishActivity(activity.publication);
    if (input.onLog)
      await input.onLog(
        "stdout",
        `${JSON.stringify({ type: "paperclip.plan.synchronization", synchronization })}\n`,
      );
  };
  let nativeSessionExecuteStartedAtMs = Date.now();
  let sessionStartedAtMs: number | null = null;
  let sessionStartupMode: "bootstrap" | "resume" | null = null;
  let turnSubmittedAtMs: number | null = null;
  let turnStartedAtMs: number | null = null;
  let firstAgentEventRecorded = false;
  let providerUsageLimitObserved = false;
  let turnCompletedAtMs: number | null = null;
  let runnerSessionStartupScope: NativeRunSpanScope | null = null;
  let agentTurnScope: NativeRunSpanScope | null = null;
  let taskSettleScope: NativeRunSpanScope | null = null;
  const governedWaitObservation = createGovernedWaitEventObservation(
    resolvePendingGovernedWait,
  );
  const projectSessionGoalEvent = (event: PrpEvent) =>
    applyRunnerGoalPrpEvent(
      input.db,
      {
        companyId: input.execution.binding.companyId,
        issueId: input.execution.binding.issueId,
        agentId: input.execution.binding.agentId,
        adapterType:
          input.adapterType ??
          (input.useRunnerd ? "paperclip_runner" : "codex_local"),
      },
      {
        eventType: event.eventType,
        sourceInstanceId: event.sourceInstanceId,
        sourceRunId: event.runId,
        sourceSeq: event.sourceSeq,
        payload: event.payload,
      },
    );
  const liveQuestions = createLocalNativeQuestionBridge({
    db: input.db,
    binding: { ...input.execution.binding, normalizedSessionId: nativeSessionKey(input.execution), runnerSourceInstanceId: effectiveRunnerInstanceId },
    resolve: resolveNativeRuntimeRequest,
  });
  // Event source reviews and managed tool effects update the same Run. Keep
  // their transactions ordered from startup; post-commit callbacks run outside.
  let sourceOperationChain: Promise<void> = Promise.resolve();
  const serializeSourceOperation = <T>(operation: () => Promise<T>): Promise<T> => {
    const pending = sourceOperationChain.then(operation, operation);
    sourceOperationChain = pending.then(() => undefined, () => undefined);
    return pending;
  };
  let completedConversationReply: PrpEvent | null = null;
  const controlPlane = new PaperclipControlPlanePort(
    input.db,
    {
      companyId: input.execution.binding.companyId,
      issueId: input.execution.binding.issueId,
      runId: input.execution.binding.runId,
      agentId: input.execution.binding.agentId,
      sessionId: nativeSessionKey(input.execution),
      completionContractId: input.execution.completionContract.id,
      completionContractSha256: input.execution.completionContract.sha256,
      sourceInstanceId: effectiveRunnerInstanceId,
      controlPlaneSourceInstanceId: controlPlaneInstanceId,
      ...(input.execution.provider.kind === "aw_text_only"
        ? { internalDraftSourceInstanceId: `aw-draft:${input.execution.binding.runId}` }
        : {}),
    },
    {
      serializeTransaction: serializeSourceOperation,
      onCommittedEvent: async (event, markAppendDiagnosticStage) => {
        markAppendDiagnosticStage?.("callback_tool_trace_observe");
        await toolTrace.observe(event);
        if (event.eventType === "item.completed" &&
            record(event.payload).kind === "agentMessage" &&
            record(event.payload).channel === "final") {
          completedConversationReply = event;
        }
        markAppendDiagnosticStage?.("callback_live_questions_observe");
        await liveQuestions.observe(event);
        markAppendDiagnosticStage?.("callback_runner_goal_projection");
        await projectSessionGoalEvent(event);
        markAppendDiagnosticStage?.("callback_event_accounting");
        providerUsageLimitObserved ||= nativeProviderUsageLimitFromEvent(event);
        const eventAtMs = Date.parse(event.emittedAt);
        const milestoneAtMs = Number.isFinite(eventAtMs)
          ? eventAtMs
          : Date.now();
        if (
          event.eventType === "session.started" &&
          sessionStartedAtMs === null
        ) {
          sessionStartedAtMs = milestoneAtMs;
          sessionStartupMode = "bootstrap";
          await trace.record({
            name: "runner.session.bootstrap",
            parentName: "runner.session.startup",
            startedAtMs: nativeSessionExecuteStartedAtMs,
            endedAtMs: milestoneAtMs,
          });
        }
        if (
          event.eventType === "turn.submitted" &&
          turnSubmittedAtMs === null
        ) {
          turnSubmittedAtMs = milestoneAtMs;
          // A recovered provider session does not emit session.started again. In
          // that case the first durable turn.submitted event is the earliest
          // transport-neutral proof that runnerd reattached to the exact
          // provider session and is ready for work. Keep that startup time out of
          // runner.turn.submit so cold-resume latency is visible as its own span.
          if (sessionStartedAtMs === null) {
            await trace.record({
              name: "runner.session.resume",
              parentName: "runner.session.startup",
              startedAtMs: nativeSessionExecuteStartedAtMs,
              endedAtMs: milestoneAtMs,
              attributes: {
                provider: input.execution.provider.kind,
                strategy: "exact_provider_session",
              },
            });
            sessionStartedAtMs = milestoneAtMs;
            sessionStartupMode = "resume";
          }
          await trace.record({
            name: "runner.turn.submit",
            parentName: "runner.session.startup",
            startedAtMs: sessionStartedAtMs,
            endedAtMs: milestoneAtMs,
          });
          if (runnerSessionStartupScope) {
            trace.annotate(runnerSessionStartupScope, {
              mode: sessionStartupMode ?? "bootstrap",
            });
            await trace.end(runnerSessionStartupScope, {
              endedAtMs: milestoneAtMs,
            });
          }
          agentTurnScope = trace.start("agent.turn", {
            parentName: "native.session.execute",
            startedAtMs: milestoneAtMs,
            attributes: { provider: input.execution.provider.kind },
          });
          trace.activate(agentTurnScope);
        }
        if (event.eventType === "turn.started" && turnStartedAtMs === null) {
          turnStartedAtMs = milestoneAtMs;
          await trace.record({
            name: "provider.turn.queue",
            parentName: "agent.turn",
            startedAtMs: turnSubmittedAtMs ?? milestoneAtMs,
            endedAtMs: milestoneAtMs,
          });
        }
        if (!firstAgentEventRecorded && turnStartedAtMs !== null) {
          const kind = firstMeaningfulAgentEventKind(event);
          if (kind) {
            firstAgentEventRecorded = true;
            await trace.record({
              name: "provider.time_to_first_agent_event",
              parentName: "agent.turn",
              startedAtMs: turnStartedAtMs,
              endedAtMs: milestoneAtMs,
              attributes: { eventKind: kind },
            });
          }
        }
        if (
          [
            "turn.completed",
            "turn.failed",
            "turn.interrupted",
            "turn.cancelled",
          ].includes(event.eventType) &&
          turnCompletedAtMs === null
        ) {
          turnCompletedAtMs = milestoneAtMs;
          if (!agentTurnScope) {
            agentTurnScope = trace.start("agent.turn", {
              parentName: "native.session.execute",
              startedAtMs:
                turnSubmittedAtMs ??
                turnStartedAtMs ??
                nativeSessionExecuteStartedAtMs,
              attributes: { provider: input.execution.provider.kind },
            });
            trace.activate(agentTurnScope);
          }
          const outcome =
            event.eventType === "turn.completed" ? "ok" : "failed";
          await trace.end(agentTurnScope, {
            endedAtMs: milestoneAtMs,
            outcome,
          });
          taskSettleScope = trace.start("task.settle", {
            parentName: "task.run",
            startedAtMs: milestoneAtMs,
          });
          trace.activate(taskSettleScope);
        }
        // appendEvent commits this canonical event to heartbeat_run_events
        // before entering the callback. Native transcript consumers read that
        // retained event stream directly, so copying the full structured
        // provider payload into stdout would duplicate private content and
        // trigger a second source check/log write for every event.
        if (
          input.onEvent &&
          [
            "session.capabilities.updated",
            "session.goal.snapshot",
            "session.goal.updated",
            "session.goal.cleared",
            "turn.started",
            "turn.completed",
            "turn.failed",
            "turn.interrupted",
            "turn.cancelled",
          ].includes(event.eventType)
        ) {
          await input.onEvent({
            eventType: event.eventType,
            stream: "system",
            level: event.eventType.includes("failed") ? "error" : "info",
            payload: {
              ...(event.payload as Record<string, unknown>),
              prpSourceSeq: event.sourceSeq,
              prpSourceInstanceId: event.sourceInstanceId,
            },
          });
        }
        const inputMetric = runtimeInputLifecycleMetric(event);
        if (inputMetric && input.onLog) {
          await input.onLog(
            "stdout",
            `${JSON.stringify({
              type: "paperclip.runtime_input.metric",
              ...inputMetric,
            })}\n`,
          );
        }
        const questionFallback = await materializeRuntimeQuestionFallback({
          db: input.db,
          binding: input.execution.binding,
          event,
        });
        if (questionFallback) {
          if (input.onLog) {
            const origin = record(record(record(event.payload).request).origin);
            await input.onLog(
              "stdout",
              `${JSON.stringify({
                type: "paperclip.runtime_input.metric",
                outcome:
                  record(event.payload).reason === "durable_handoff"
                    ? "durable_handoff_materialized"
                    : "provider_loss_materialized",
                requestId: record(event.payload).requestId,
                interactionId: questionFallback.interaction.id,
                adapter:
                  typeof origin.adapter === "string"
                    ? origin.adapter
                    : "unknown",
              })}\n`,
            );
          }
        }
        await governedWaitObservation.observe(
          event,
          event.eventType === "item.completed" || questionFallback !== null,
        );
        await recordPlanSynchronization(
          event as {
            sourceEventId: string;
            turnId?: string;
            eventType: string;
            payload: Record<string, unknown>;
          },
        );
      },
      onDuplicateEvent: async (event) => {
        // A crash can happen after the event commit but before its callback
        // finishes. Recover only idempotent durable projections here; activity,
        // publication, logging, trace, and metric effects remain committed-only.
        await liveQuestions.observe(event);
        await projectSessionGoalEvent(event);
        providerUsageLimitObserved ||= nativeProviderUsageLimitFromEvent(event);
        const questionFallback = await materializeRuntimeQuestionFallback({
          db: input.db,
          binding: input.execution.binding,
          event,
        });
        await governedWaitObservation.observe(
          event,
          event.eventType === "item.completed" || questionFallback !== null,
        );
        const planSynchronization = await synchronizeCompletedProviderPlan({
          db: input.db,
          execution: input.execution,
          event: event as {
            sourceEventId: string;
            turnId?: string;
            eventType: string;
            payload: Record<string, unknown>;
          },
        });
        if (planSynchronization) {
          upsertPlanSynchronization(planSynchronization);
        }
      },
    },
  );
  let native: Awaited<ReturnType<typeof executeNativeSession>>;
  let releaseGoalController: (() => void) | null = null;
  const releaseRegisteredGoalController = () => {
    // The controller is assigned from the asynchronous onSession callback.
    // Keep release idempotent without relying on TypeScript's synchronous
    // control-flow model for that callback assignment.
    const release: unknown = releaseGoalController;
    if (typeof release === "function") release();
    releaseGoalController = null;
  };
  const lifecyclePolicy = input.execution.session?.lifecyclePolicy ?? {
    mode: "per_turn" as const,
    idleTimeoutMs: null,
  };
  const managedOpenCodeDataHome = managedOpenCodeRuntimeDataIsolated(
    input.execution,
    input.runnerEnvironment ?? process.env,
  );
  const warmSessionId =
    lifecyclePolicy.mode === "warm" && !managedOpenCodeDataHome
      ? nativeSessionScopeKey(input.execution)
      : null;
  const warmConfigDigest =
    lifecyclePolicy.mode === "warm"
      ? nativeSessionConfigDigest(
          input.execution,
          input.runnerExecutionTarget?.kind ?? "local",
        )
      : null;
  const warmSessionOwnerToken = Symbol(
    `native-warm-session:${input.execution.binding.runId}`,
  );
  let existingWarmSession: NativeSession | undefined;
  let managedCredentialSession: NativeSession | undefined;
  let githubAccess: NativeGitHubAccess | undefined;
  let releaseGitHubRun: (() => void) | undefined;
  let persistedWarmSession: PersistedNativeSession | null | undefined;
  if (warmSessionId !== null && warmConfigDigest !== null) {
    const entry = warmNativeSessions.get(warmSessionId);
    if (entry) {
      // Old run-scoped environments still require process replacement. A
      // session-owned broker can change run authority without replacing it.
      const hasBrokerCapability = Boolean(
        !input.managedGitHub && input.runnerEnvironment?.PAPERCLIP_GITHUB_BROKER_TOKEN,
      );
      const credentialRunChanged =
        Boolean(entry.credentialRunId) !== hasBrokerCapability ||
        (hasBrokerCapability &&
          entry.credentialRunId !== input.execution.binding.runId);
      if (
        entry.configDigest !== warmConfigDigest ||
        entry.managedAiCredentialIdentity !== input.managedAiCredentialIdentity ||
        credentialRunChanged ||
        Boolean(entry.githubAccess) !== Boolean(input.managedGitHub) ||
        entry.githubAccess?.ready === false ||
        entry.githubAuthenticationMode !==
          input.runnerEnvironment?.PAPERCLIP_GITHUB_AUTH_MODE ||
        entry.networkAccess !==
          (input.runnerEnvironment?.PAPERCLIP_RUNNER_NETWORK_ACCESS ===
            "enabled")
      ) {
        if (entry.busy) throw new Error("native_session_supervisor_busy");
        if (entry.idleTimer !== null) clearTimeout(entry.idleTimer);
        warmNativeSessions.delete(warmSessionId);
        await closeWarmNativeSession(entry, "warm native session configuration changed");
        persistedWarmSession = loadWarmNativeCheckpoint(
          input.execution,
          warmConfigDigest,
          input.runnerExecutionTarget?.kind ?? "local",
        );
      } else {
        if (entry.busy) throw new Error("native_session_supervisor_busy");
        entry.busy = true;
        entry.ownerToken = warmSessionOwnerToken;
        entry.environmentId =
          input.runnerExecutionTarget?.environmentId ?? null;
        if (entry.idleTimer !== null) clearTimeout(entry.idleTimer);
        entry.idleTimer = null;
        existingWarmSession = entry.session;
        githubAccess = entry.githubAccess;
      }
    } else {
      persistedWarmSession = loadWarmNativeCheckpoint(
        input.execution,
        warmConfigDigest,
        input.runnerExecutionTarget?.kind ?? "local",
      );
    }
  }
  // Provider history survives across warm-session runs, but no exact prior-run
  // history receipt is available at this owner. Keep ordinary warm execution
  // intact while withholding any closure that would claim the fresh envelope
  // is the complete provider input.
  const retainedSessionHistoryUnknown = existingWarmSession !== undefined || persistedWarmSession != null;
  async function resolvePendingGovernedWait() {
    const continuingInteractionIds = continuingPendingInteractionIds(
      input.execution,
    );
    const interaction = await input.db
      .select({
        id: issueThreadInteractions.id,
        title: issueThreadInteractions.title,
        summary: issueThreadInteractions.summary,
      })
      .from(issueThreadInteractions)
      .where(
        and(
          eq(
            issueThreadInteractions.companyId,
            input.execution.binding.companyId,
          ),
          eq(issueThreadInteractions.issueId, input.execution.binding.issueId),
          or(
            eq(
              issueThreadInteractions.sourceRunId,
              input.execution.binding.runId,
            ),
            and(
              eq(issueThreadInteractions.kind, "connection_intent"),
              eq(
                issueThreadInteractions.createdByAgentId,
                input.execution.binding.agentId,
              ),
            ),
            ...(continuingInteractionIds.length > 0
              ? [inArray(issueThreadInteractions.id, continuingInteractionIds)]
              : []),
          ),
          eq(issueThreadInteractions.status, "pending"),
          // Live provider questions resume their current turn; only durable
          // wake-based cards park it. A timeout creates a separate fallback.
          sql`not (${issueThreadInteractions.kind} = 'ask_user_questions' and ${issueThreadInteractions.continuationPolicy} = 'none' and coalesce(${issueThreadInteractions.idempotencyKey}, '') like 'paperclip-runner-question:%')`,
        ),
      )
      .orderBy(
        desc(issueThreadInteractions.createdAt),
        desc(issueThreadInteractions.id),
      )
      .limit(1)
      .then((rows) => rows[0] ?? null);
    if (interaction)
      return nativeGovernedWaitResult({
        interaction,
        completionContract: input.execution.completionContract.contract,
      });
    // A ready connection can become installed after the provider snapshot was
    // pinned. Its already-durable wake is also a valid reason to end this turn.
    const [refresh] = await input.db
      .select({
        id: agentWakeupRequests.id,
        key: agentWakeupRequests.idempotencyKey,
      })
      .from(agentWakeupRequests)
      .where(
        and(
          eq(agentWakeupRequests.companyId, input.execution.binding.companyId),
          eq(agentWakeupRequests.agentId, input.execution.binding.agentId),
          like(
            agentWakeupRequests.idempotencyKey,
            `connection-intent:tools:${input.execution.binding.runId}:%`,
          ),
          notInArray(agentWakeupRequests.status, [
            "skipped",
            "failed",
            "cancelled",
          ]),
        ),
      )
      .limit(1);
    return refresh?.key
      ? nativeToolsRefreshWaitResult({
          wakeId: refresh.id,
          key: refresh.key,
          completionContract: input.execution.completionContract.contract,
        })
      : null;
  }
  const runnerExecution =
    input.useRunnerd && input.runnerExecutionTarget?.kind === "remote"
      ? {
          ...input.execution,
          workspace: {
            ...input.execution.workspace,
            cwd: input.runnerExecutionTarget.remoteCwd,
          },
        }
      : input.execution;
  const leaseRenewal = startNativeSessionExecutionLeaseRenewal({
    db: input.db,
    runId: input.execution.binding.runId,
    companyId: input.execution.binding.companyId,
    issueId: input.execution.binding.issueId,
    leaseOwner,
    attempt,
    controller,
  });
  try {
    if (input.managedGitHub) {
      githubAccess ??= await createNativeGitHubAccess({
        scope: input.execution.binding,
        target: input.runnerExecutionTarget,
        cwd: input.execution.workspace.cwd,
        env: input.runnerEnvironment ?? process.env,
        resolveCredentials: (binding) => resolveGitHubOperationCredentials(input.db, binding),
        onLog: input.onLog,
      });
      releaseGitHubRun = githubAccess.activate(input.execution.binding);
      input = { ...input, runnerEnvironment: { ...input.runnerEnvironment, ...githubAccess.env } };
    }
    const expectedCurrentWakeComments = await resolveCurrentWakeCommentsBinding(
      input.db,
      input.execution.binding,
    );
    // Staging, warm-session cleanup and the claim may all wait after the
    // initial source admission. Recheck before preparing a provider backend.
    await assertNativeAnalyticalRunPayloadAccess(input.db, input.execution.binding.companyId, input.execution.binding.runId);
    let launchEventSeq: number | null = null;
    const managedOpenCodeOutputCaptureRef = input.execution.provider.kind === "opencode" &&
      (input.runnerEnvironment ?? process.env).PAPERCLIP_MANAGED_MODEL_BROKER_ORIGIN?.trim()
      ? { value: null as NativeModelOutputCapture | null } : undefined;
    const managedContextReadCaptureRef = managedOpenCodeOutputCaptureRef ? { value: null as NativeContextReadBinding | null } : undefined;
    if (managedOpenCodeDataHome) {
      await assertRuntimeStorageDirectories(
        managedOpenCodeRuntimeDirectory({ companyId: input.execution.binding.companyId, runId }),
        resolvePaperclipInstanceRoot(),
        true,
      );
    }
    const runnerdBackend =
      input.useRunnerd && input.backend === undefined
        ? await createRunnerdBackend({
            ...input,
            // Durable scope and prior-run verification use the controller's
            // canonical workspace identity. createRunnerdBackend separately
            // projects remoteCwd into the provider execution boundary.
            execution: input.execution,
            runnerInstanceId: effectiveRunnerInstanceId,
            durableEnvironmentLeaseId: durableRunnerBinding?.environmentLeaseId,
            nativeModelOutputCapture: managedOpenCodeOutputCaptureRef,
            managedNativeContextReadCapture: managedContextReadCaptureRef,
            trace,
            toolTrace,
            serializeManagedOperation: serializeSourceOperation,
            onDocumentRead: async capture => {
              if (launchEventSeq === null) throw new Error("native_document_tool_capture_binding_invalid");
              await assertNativeAnalyticalRunPayloadAccess(input.db, input.execution.binding.companyId, runId);
              await recordNativeDocumentToolResultIntent({ db: input.db, runId,
                companyId: input.execution.binding.companyId, issueId: input.execution.binding.issueId,
                agentId: input.execution.binding.agentId, leaseOwner, attempt, controller, eventSeq: launchEventSeq, capture });
              await assertNativeAnalyticalRunPayloadAccess(input.db, input.execution.binding.companyId, runId);
              await renewNativeSessionExecutionLease({ db: input.db, runId,
                companyId: input.execution.binding.companyId, issueId: input.execution.binding.issueId,
                leaseOwner, attempt, controller });
            },
            onNativeInputToolResult: async capture => {
              if (launchEventSeq === null) throw new Error("native_tool_result_capture_binding_invalid");
              await assertNativeAnalyticalRunPayloadAccess(input.db, input.execution.binding.companyId, runId);
              await recordNativeInputToolResultIntent({ db: input.db, runId,
                companyId: input.execution.binding.companyId, issueId: input.execution.binding.issueId,
                agentId: input.execution.binding.agentId, leaseOwner, attempt, controller,
                eventSeq: launchEventSeq, capture });
              await assertNativeAnalyticalRunPayloadAccess(input.db, input.execution.binding.companyId, runId);
              await renewNativeSessionExecutionLease({ db: input.db, runId,
                companyId: input.execution.binding.companyId, issueId: input.execution.binding.issueId,
                leaseOwner, attempt, controller });
            },
            onProjectToolResult: async capture => {
              if (launchEventSeq === null) throw new Error("native_project_tool_capture_binding_invalid");
              await assertNativeAnalyticalRunPayloadAccess(input.db, input.execution.binding.companyId, runId);
              await recordNativeProjectToolResultIntent({ db: input.db, runId,
                companyId: input.execution.binding.companyId, issueId: input.execution.binding.issueId,
                agentId: input.execution.binding.agentId, leaseOwner, attempt, controller, eventSeq: launchEventSeq, capture });
              await assertNativeAnalyticalRunPayloadAccess(input.db, input.execution.binding.companyId, runId);
              await renewNativeSessionExecutionLease({ db: input.db, runId,
                companyId: input.execution.binding.companyId, issueId: input.execution.binding.issueId,
                leaseOwner, attempt, controller });
            },
            onNativeToolCall: async call => {
              try {
                if (managedOpenCodeOutputCaptureRef) {
                  managedOpenCodeOutputCaptureRef.value = null;
                  if (managedContextReadCaptureRef) managedContextReadCaptureRef.value = null;
                  if (launchEventSeq === null) throw new Error("managed_opencode_tool_call_source_binding_invalid");
                  await assertManagedOpenCodeToolCallCurrent({ db: input.db, runId, companyId: input.execution.binding.companyId,
                    issueId: input.execution.binding.issueId, agentId: input.execution.binding.agentId,
                    leaseOwner, attempt, controller, eventSeq: launchEventSeq, ...call });
                }
                const associationRecorded = await recordNativeToolCallDispatchAssociation({
                  db: input.db, runId, companyId: input.execution.binding.companyId,
                  issueId: input.execution.binding.issueId, agentId: input.execution.binding.agentId,
                  leaseOwner, attempt, controller, ...call,
                });
                const managedProjectApiCreate = call.tool === "call_api" &&
                  managedNativeProjectApiCallSchema.safeParse(call.arguments).success;
                if (managedOpenCodeOutputCaptureRef && (["write_document", "create_task", "create_project", "self_remember"].includes(call.tool) || managedProjectApiCreate)) {
                  if (launchEventSeq === null) throw new Error("managed_opencode_tool_call_source_binding_invalid");
                  managedOpenCodeOutputCaptureRef.value = await prepareManagedOpenCodeOutputCapture({
                    db: input.db, runId, companyId: input.execution.binding.companyId,
                    issueId: input.execution.binding.issueId, agentId: input.execution.binding.agentId,
                    leaseOwner, attempt, controller, eventSeq: launchEventSeq, ...call,
                  });
                }
              } catch (error) {
                throw error;
              }
            },
            ...(input.execution.provider.kind === "opencode" && (input.runnerEnvironment ?? process.env).PAPERCLIP_MANAGED_MODEL_BROKER_ORIGIN?.trim()
              ? { onManagedOpenCodeToolResult: async call => {
                  if (launchEventSeq === null) throw new Error("managed_opencode_tool_result_binding_invalid");
                  await assertNativeAnalyticalRunPayloadAccess(input.db, input.execution.binding.companyId, runId);
                  try {
                    await recordManagedOpenCodeToolResult({ db: input.db, runId,
                      companyId: input.execution.binding.companyId, issueId: input.execution.binding.issueId,
                      agentId: input.execution.binding.agentId, leaseOwner, attempt, controller,
                      outputCapture: managedOpenCodeOutputCaptureRef?.value ?? null,
                      ...call });
                  } finally {
                    if (managedOpenCodeOutputCaptureRef) managedOpenCodeOutputCaptureRef.value = null;
                    if (managedContextReadCaptureRef) managedContextReadCaptureRef.value = null;
                  }
                  await assertNativeAnalyticalRunPayloadAccess(input.db, input.execution.binding.companyId, runId);
                  await renewNativeSessionExecutionLease({ db: input.db, runId,
                    companyId: input.execution.binding.companyId, issueId: input.execution.binding.issueId,
                    leaseOwner, attempt, controller });
                } }
              : {}),
          })
        : null;
    const remoteCleanupLease = input.runnerExecutionTarget?.kind === "remote" &&
        input.runnerExecutionTarget.transport === "sandbox" && input.runnerExecutionTarget.leaseId
      ? await input.db.select({ provider: environmentLeases.provider, providerLeaseId: environmentLeases.providerLeaseId })
          .from(environmentLeases).where(and(
            eq(environmentLeases.companyId, input.execution.binding.companyId),
            eq(environmentLeases.id, input.runnerExecutionTarget.leaseId),
          )).then(rows => rows[0])
      : null;
    nativeSessionExecuteStartedAtMs = Date.now();
    native = await trace.measure(
      "native.session.execute",
      async () => {
        runnerSessionStartupScope = trace.start("runner.session.startup", {
          parentName: "native.session.execute",
          startedAtMs: nativeSessionExecuteStartedAtMs,
        });
        trace.activate(runnerSessionStartupScope);
        const result = await trace.run(runnerSessionStartupScope, () =>
          executeNativeSession({
            onSessionAdmission: async () => {
              // Invalidate prior stop evidence before a backend can spawn.
              const launchIntent = await appendHeartbeatRunEvent(input.db, {
                companyId: input.execution.binding.companyId,
                runId: input.execution.binding.runId,
                agentId: input.execution.binding.agentId,
                eventType: PROCESS_START_REQUESTED,
                stream: "system",
                level: "info",
                message: "Native execution requested; prior local stop evidence no longer applies.",
              });
              launchEventSeq = launchIntent.row.seq;
              // The launch-intent transaction can wait on the run row too.
              // A committed intent never substitutes for current source access.
              await assertNativeAnalyticalRunPayloadAccess(input.db, input.execution.binding.companyId, input.execution.binding.runId);
              if (stagedAttachmentSources?.length) {
                await input.db.transaction(async (tx) => {
                  // Reuse the exact coordinator lease fence, then the original
                  // run lock order. This partial capture grants no source access.
                  await renewNativeSessionExecutionLease({ db: tx as unknown as Db,
                    runId, companyId: input.execution.binding.companyId, issueId: input.execution.binding.issueId,
                    leaseOwner, attempt, controller });
                  const [run] = await tx.select().from(heartbeatRuns).where(and(
                    eq(heartbeatRuns.id, runId), eq(heartbeatRuns.companyId, input.execution.binding.companyId),
                    eq(heartbeatRuns.agentId, input.execution.binding.agentId),
                    eq(heartbeatRuns.nativeIssueId, input.execution.binding.issueId),
                    eq(heartbeatRuns.runtimeMode, "native"), eq(heartbeatRuns.status, "running"),
                  )).for("update");
                  if (!run) throw new Error("native_attachment_stage_capture_binding_changed");
                  const profile = record(run.runnerProfileJson);
                  const previous = profile.nativeAttachmentStageSources ?? [];
                  if (!Array.isArray(previous) || previous.length >= 64)
                    throw new Error("native_attachment_stage_capture_budget_exceeded");
                  if (launchEventSeq === null || !stagedAttachments)
                    throw new Error("native_attachment_stage_capture_binding_changed");
                  const immutableExecution = baseExecution ?? input.execution;
                  const baseTaskDigest = nativeTaskDigest(immutableExecution.task);
                  const finalTaskDigest = nativeTaskDigest(input.execution.task);
                  const closureAttachmentInputs = input.bootstrapSourceClosure?.sourceSet.inputs.filter(
                    (source): source is Extract<NativePayloadSourceInput, { kind: "attachment" }> => source.kind === "attachment") ?? [];
                  // Ordinary historical staging remains an observation. Only a
                  // new qualified source closure requires the immutable profile binding.
                  if (previous.length === 0 && closureAttachmentInputs.length &&
                    nativeSha256(immutableExecution) !== nativeSha256(parseNativeExecutionInput(profile.nativeExecutionInput)))
                    throw new Error("native_attachment_stage_capture_binding_changed");
                  const sourceInputs = stagedAttachmentSources.map(capture => capture.input);
                  if (closureAttachmentInputs.length && (!isDeepStrictEqual(closureAttachmentInputs, sourceInputs) ||
                    input.bootstrapSourceClosure?.taskEnvelopeDigest !== finalTaskDigest))
                    throw new Error("native_attachment_stage_capture_binding_changed");
                  const sourceCaptureHash = nativeSha256(stagedAttachmentSources);
                  // The descriptor hash excludes workspace paths. The final task digest binds those exact paths
                  // without retaining temporary filesystem paths in the run profile.
                  const descriptorHash = nativeSha256(stagedAttachments.map(({ id, filename, contentType, byteSize, unavailableReason }) =>
                    ({ id, filename, contentType, byteSize, unavailableReason })));
                  const stageHash = nativeSha256({ eventSeq: launchIntent.row.seq, attempt,
                    responsibleUserId: run.responsibleUserId ?? null, baseTaskDigest, finalTaskDigest,
                    sourceCaptureHash, descriptorHash });
                  const currentCapture = { eventSeq: launchIntent.row.seq, attempt,
                    responsibleUserId: run.responsibleUserId ?? null, baseTaskDigest, finalTaskDigest,
                    sourceCaptureHash, descriptorHash, stageHash, sourceCaptures: stagedAttachmentSources };
                  const captures = [...previous, currentCapture];
                  if (Buffer.byteLength(JSON.stringify(captures)) > 2 * 1024 * 1024)
                    throw new Error("native_attachment_stage_capture_budget_exceeded");
                  const authority = record(profile.nativeOpenCodeSourceAuthority);
                  const nextAuthority = authority.version === 1 && previous.length === 0 && closureAttachmentInputs.length
                    ? { ...authority, attachmentStageHash: stageHash } : profile.nativeOpenCodeSourceAuthority;
                  await tx.update(heartbeatRuns).set({
                    runnerProfileJson: { ...profile, nativeAttachmentStageSources: captures,
                      ...(nextAuthority ? { nativeOpenCodeSourceAuthority: nextAuthority } : {}) }, updatedAt: new Date(),
                  }).where(eq(heartbeatRuns.id, runId));
                });
                // Capture persistence may itself wait; it is never a grant.
                await assertNativeAnalyticalRunPayloadAccess(input.db, input.execution.binding.companyId, runId);
              }
            },
            prepareTurn: async turnInput => {
              const prepared = input.prepareTurnSourceClosure
                ? await input.prepareTurnSourceClosure(turnInput, input.bootstrapSourceClosure)
                : { turnInput, sourceClosure: input.bootstrapSourceClosure ?? undefined };
              return retainedSessionHistoryUnknown
                ? { turnInput: prepared.turnInput, sourceClosure: undefined }
                : prepared;
            },
            onTurnInput: async (turnInput, sourceClosure) => {
              if (launchEventSeq === null) throw new Error("native_model_input_launch_binding_invalid");
              await assertNativeAnalyticalRunPayloadAccess(input.db, input.execution.binding.companyId, runId);
              const preparedClosure = sourceClosure && typeof sourceClosure === "object" && !Array.isArray(sourceClosure)
                ? sourceClosure as NativeBootstrapSourceClosure : null;
              const dispatchId = await recordNativeModelInputDispatchIntent({
                db: input.db, runId, companyId: input.execution.binding.companyId,
                issueId: input.execution.binding.issueId, agentId: input.execution.binding.agentId,
                leaseOwner, attempt, controller, eventSeq: launchEventSeq, turnInput,
                bootstrapSourceClosure: preparedClosure,
              });
              await assertNativeAnalyticalRunPayloadAccess(input.db, input.execution.binding.companyId, runId);
              await renewNativeSessionExecutionLease({
                db: input.db, runId, companyId: input.execution.binding.companyId,
                issueId: input.execution.binding.issueId, leaseOwner, attempt, controller,
              });
              return dispatchId;
            },
            onTurnStarted: async (turnInput, turnId, dispatchId, sourceClosure) => {
              if (launchEventSeq === null || !dispatchId) throw new Error("native_model_input_ack_binding_invalid");
              const preparedClosure = sourceClosure && typeof sourceClosure === "object" && !Array.isArray(sourceClosure)
                ? sourceClosure as NativeBootstrapSourceClosure : null;
              await recordNativeModelInputDispatchAcknowledgement({
                db: input.db, runId, companyId: input.execution.binding.companyId,
                issueId: input.execution.binding.issueId, agentId: input.execution.binding.agentId,
                leaseOwner, attempt, controller, eventSeq: launchEventSeq, dispatchId, turnInput, turnId,
                sourceClosure: preparedClosure,
              });
            },
            input: runnerExecution,
            remoteCleanupScope: remoteCleanupLease ? remoteLeaseCleanupScope(remoteCleanupLease) : undefined,
            turnTimeoutMs: input.turnTimeoutMs,
            backend:
              input.backend ??
              runnerdBackend ??
              createNativeSessionBackend(input.execution, {
                runnerInstanceId: input.runnerInstanceId,
                onSpawn: input.onSpawn,
                opencodeEnvironment: input.runnerEnvironment ?? process.env,
                acpxEnvironment: input.runnerEnvironment ?? process.env,
                opencodeRuntimeDirectory: managedOpenCodeDataHome
                  ? managedOpenCodeRuntimeDirectory({ companyId: input.execution.binding.companyId,
                    runId: input.execution.binding.runId })
                  : resolve(
                      resolvePaperclipInstanceRoot(),
                      "runtime",
                      "paperclip-runner",
                      "opencode",
                    ),
                acpxRuntimeDirectory: resolve(
                  resolvePaperclipInstanceRoot(),
                  "runtime",
                  "paperclip-runner",
                  "acpx",
                ),
              }),
            controlPlane,
            runnerInstanceId: effectiveRunnerInstanceId,
            controlPlaneInstanceId,
            resolveGovernedWait: ({ event }) =>
              governedWaitObservation.consume(event),
            resolveMissingResult: async ({ terminalEvent }) => {
              // Governed waits take precedence over an ordinary chat reply.
              // Execution tasks still require their normal semantic finish.
              if (terminalEvent.eventType !== "turn.completed") return null;
              const governedWait = await resolvePendingGovernedWait();
              if (governedWait) return governedWait;
              const [conversation] = await input.db
                .select({ agentId: issues.conversationAgentId })
                .from(issues)
                .where(and(
                  eq(issues.id, input.execution.binding.issueId),
                  eq(issues.companyId, input.execution.binding.companyId),
                ))
                .limit(1);
              const [activeWorkerAttempt] = await input.db
                .select({ id: orchestrationWorkerAttempts.id })
                .from(orchestrationWorkerAttempts)
                .where(and(
                  eq(orchestrationWorkerAttempts.companyId, input.execution.binding.companyId),
                  eq(orchestrationWorkerAttempts.agentId, input.execution.binding.agentId),
                  eq(orchestrationWorkerAttempts.runId, runId),
                  eq(orchestrationWorkerAttempts.status, "running"),
                ))
                .limit(1);
              const [currentRunProfile] = await input.db
                .select({ runnerProfileJson: heartbeatRuns.runnerProfileJson })
                .from(heartbeatRuns)
                .where(and(
                  eq(heartbeatRuns.companyId, input.execution.binding.companyId),
                  eq(heartbeatRuns.agentId, input.execution.binding.agentId),
                  eq(heartbeatRuns.id, runId),
                ))
                .limit(1);
              const modelWireIntents = record(currentRunProfile?.runnerProfileJson).nativeAwModelWireIntents;
              const workerModelPurposeWasUsed = Array.isArray(modelWireIntents) &&
                modelWireIntents.some(value => record(value).modelPurpose === "worker_model");
              const replyResult = nativeConversationReplyResult({
                // A Worker plan may run against a sealed conversation root,
                // but it still needs its ordinary semantic finish. Only a
                // conversation turn without an active Worker attempt may use
                // the plain-reply completion path.
                conversation: conversation?.agentId === input.execution.binding.agentId &&
                  !activeWorkerAttempt && !workerModelPurposeWasUsed,
                terminalEvent,
                replyEvent: completedConversationReply,
                completionContract: input.execution.completionContract.contract,
              });
              if (!replyResult && process.env.PAPERCLIP_MANAGED_OPENCODE_E2E_DIAGNOSTICS === "1") {
                const reply = completedConversationReply;
                const payload = record(reply?.payload);
                const replyText = typeof payload.text === "string" ? payload.text.trim() : "";
                await input.onLog?.("stderr", `[paperclip-runner] conversation reply result predicates: ${JSON.stringify({
                  conversationAgentMatches: conversation?.agentId === input.execution.binding.agentId,
                  terminalIsCompleted: terminalEvent.eventType === "turn.completed",
                  replyExists: reply !== null,
                  replyIsCompletedItem: reply?.eventType === "item.completed",
                  replyIsAgentMessage: payload.kind === "agentMessage",
                  replyIsFinalChannel: payload.channel === "final",
                  replyHasText: replyText.length > 0,
                  replyRunMatches: reply?.runId === terminalEvent.runId,
                  replyTurnMatches: reply?.turnId === terminalEvent.turnId,
                  replySessionMatches: reply?.normalizedSessionId === terminalEvent.normalizedSessionId,
                })}\n`);
              }
              return replyResult;
            },
            existingSession: existingWarmSession,
            persistedSession: persistedWarmSession,
            keepSessionOpen: warmSessionId !== null,
            sessionGoalControl: input.sessionGoalControl,
            resumeSessionGoalHeartbeat: input.resumeSessionGoalHeartbeat,
            // Every durable runner must finish its bounded suspension before
            // the next run verifies and rotates the saved authority.
            requireSessionCloseBeforeReturn: runnerdBackend !== null,
            onCheckpoint: async (snapshot) => {
              if (warmSessionId !== null && warmConfigDigest !== null) {
                await persistWarmNativeCheckpoint(
                  input.execution,
                  warmConfigDigest,
                  snapshot,
                );
              }
              if (
                snapshot.goal ||
                input.sessionGoalControl ||
                input.resumeSessionGoalHeartbeat
              ) {
                await input.onGoalCheckpoint?.(snapshot);
              }
            },
            onPostCompletionEnrichmentFailure: async ({ stage, error }) => {
              const detail = redactSensitiveText(
                error instanceof Error ? error.message : String(error),
              ).slice(-4_096);
              await input.onLog?.(
                "stderr",
                `[paperclip-runner] post-completion ${stage} enrichment failed: ${detail}\n`,
              );
            },
            onSessionQuarantined: async (reason) => {
              await input.onLog?.(
                "stderr",
                `[paperclip-runner] warm native session quarantined: ${redactSensitiveText(reason).slice(-1_000)}\n`,
              );
            },
            onContinuityBreak: async (continuity) => {
              const atMs = Date.now();
              await trace.record({
                name: "provider.session.continuity_break",
                parentName: "native.session.execute",
                startedAtMs: atMs,
                endedAtMs: atMs,
                outcome: "failed",
                attributes: {
                  reason: continuity.reason,
                  previousDriverSessionId: continuity.previousDriverSessionId,
                  previousProviderSessionId:
                    continuity.previousProviderSessionId ?? "unavailable",
                  replacementDriverSessionId:
                    continuity.replacementDriverSessionId,
                  replacementProviderSessionId:
                    continuity.replacementProviderSessionId ?? "unavailable",
                },
              });
              await input.onLog?.(
                "stderr",
                `[paperclip-runner] provider session continuity break: exact resume failed (${continuity.reason}); old driver session=${continuity.previousDriverSessionId}, old provider session=${continuity.previousProviderSessionId ?? "unavailable"}, replacement driver session=${continuity.replacementDriverSessionId}, replacement provider session=${continuity.replacementProviderSessionId ?? "unavailable"}\n`,
              );
            },
            onSession: async (session) => {
              if (session && input.managedAiCredentialHome) {
                managedCredentialSession = runnerdBackend?.bindManagedSession(session) ?? session;
              }
              releaseRegisteredGoalController();
              liveQuestions.close();
              if (session?.goal) {
                releaseGoalController = registerLiveRunnerGoalController(
                  {
                    companyId: input.execution.binding.companyId,
                    issueId: input.execution.binding.issueId,
                    agentId: input.execution.binding.agentId,
                    runId: input.execution.binding.runId,
                  },
                  {
                    control: async (control) => {
                      await applyNativeSessionGoalControl(session, control);
                    },
                  },
                );
              }
              if (
                session &&
                warmSessionId !== null &&
                warmConfigDigest !== null
              ) {
                const existing = warmNativeSessions.get(warmSessionId);
                if (existing) {
                  if (existing.ownerToken !== warmSessionOwnerToken) {
                    throw new Error("native_session_supervisor_busy");
                  }
                  existing.session = session;
                } else
                  warmNativeSessions.set(warmSessionId, {
                    managedAiCredentialIdentity: input.managedAiCredentialIdentity,
                    githubAuthenticationMode:
                      input.runnerEnvironment?.PAPERCLIP_GITHUB_AUTH_MODE,
                    networkAccess:
                      input.runnerEnvironment
                        ?.PAPERCLIP_RUNNER_NETWORK_ACCESS === "enabled",
                    githubAccess,
                    credentialRunId: !input.managedGitHub && input.runnerEnvironment
                      ?.PAPERCLIP_GITHUB_BROKER_TOKEN
                      ? input.execution.binding.runId
                      : undefined,
                    session,
                    ownerToken: warmSessionOwnerToken,
                    configDigest: warmConfigDigest,
                    companyId: input.execution.binding.companyId,
                    runId: input.execution.binding.runId,
                    environmentId:
                      input.runnerExecutionTarget?.environmentId ?? null,
                    busy: true,
                    idleTimer: null,
                    lastActivityAt: new Date().toISOString(),
                  });
              } else if (!session && warmSessionId !== null) {
                const existing = warmNativeSessions.get(warmSessionId);
                // onSession(null) quarantines a transport that can no longer
                // be reused. Remove only this execution's generation so a
                // late failure cannot evict a successor session.
                if (existing?.ownerToken === warmSessionOwnerToken) {
                  if (existing.idleTimer !== null) {
                    clearTimeout(existing.idleTimer);
                  }
                  warmNativeSessions.delete(warmSessionId);
                }
              }
              if (session) {
                const active: ActiveNativeSession = { session, cancelRequested: false };
                activeNativeSessions.set(input.execution.binding.runId, active);
                const startup = nativeSessionStartups.get(input.execution.binding.runId);
                startup?.resolve(active);
                if (startup?.stopRequested) {
                  recordNativeCancelOriginTestFact(input.execution.binding.runId, {
                    stage: "startup_stop_requested",
                    reason: "stop_during_startup",
                  });
                  // Publication wakes the Stop caller; wait for its durable ACK
                  // before unwinding. No provider turn may be submitted between
                  // session startup and the execution-owned cleanup below.
                  await startup.cancellationSettled;
                  // If startup exceeded the caller's deadline, its late handle
                  // must still be cancelled instead of escaping the Stop fence.
                  await cancelNativeSession(input.execution.binding.runId, "Stop requested during native startup");
                  throw new Error("native_finalization_missing: session returned no semantic result");
                }
                // Stop can win after the coordinator claim while the provider
                // session is still opening. Publishing the handle before this
                // read closes both sides of the race: earlier Stop is durable;
                // later Stop can cancel this exact active session.
                const [currentRun] = await input.db.select({
                  status: heartbeatRuns.status,
                  resultJson: heartbeatRuns.resultJson,
                }).from(heartbeatRuns).where(and(
                  eq(heartbeatRuns.id, input.execution.binding.runId),
                  eq(heartbeatRuns.companyId, input.execution.binding.companyId),
                  eq(heartbeatRuns.agentId, input.execution.binding.agentId),
                )).limit(1);
                const cancellation = record(currentRun?.resultJson?.nativeCancellation);
                if (!currentRun || currentRun.status !== "running" ||
                    currentRun.resultJson?.startupCancellation ||
                    (cancellation.scope === "run" &&
                      ["pending", "acknowledged"].includes(String(cancellation.dispatchState)))) {
                  const status = currentRun?.status;
                  recordNativeCancelOriginTestFact(input.execution.binding.runId, {
                    stage: "startup_gate",
                    reason: "run_stopped_during_startup",
                    runStatus: status === "running" || status === "cancelled" || status === "failed" ||
                      status === "interrupted" || status === "succeeded" || status === "timed_out"
                      ? status : currentRun ? "other" : "missing",
                    startupCancellationPresent: Boolean(currentRun?.resultJson?.startupCancellation),
                    cancellationScope: cancellation.scope === "run" ? "run" : cancellation.scope ? "other" : "absent",
                    cancellationDispatchState: cancellation.dispatchState === "pending" || cancellation.dispatchState === "acknowledged"
                      ? cancellation.dispatchState : cancellation.dispatchState ? "other" : "absent",
                  });
                  await cancelNativeSession(input.execution.binding.runId, "Run stopped during native session startup");
                  // The execution-owned finally closes the session when this
                  // callback fails; no provider turn may follow publication.
                  throw new NativeCancellationPendingRecoveryError();
                }
                if (session.resolveRuntimeRequest) await liveQuestions.attach();
                if (nativeRunsDetachingForRestart.has(input.execution.binding.runId)) {
                  if (session.detachControllerForRestart) await detachActiveNativeSessionForRestart(active);
                }
                if (active.cancelRequested) {
                  recordNativeCancelOriginTestFact(input.execution.binding.runId, {
                    stage: "active_cancel_requested",
                    reason: null,
                  });
                  throw new NativeCancellationPendingRecoveryError();
                }
              } else {
                liveQuestions.close();
                activeNativeSessions.delete(input.execution.binding.runId);
                clearSteeringDeliveries(input.execution.binding.runId);
                clearNativeRuntimeRequestResolutions(
                  input.execution.binding.runId,
                );
              }
            },
          }),
        );
        await trace.end(runnerSessionStartupScope, {
          outcome:
            result.terminal.runTerminalState === "succeeded" ? "ok" : "failed",
        });
        return result;
      },
      { parentName: "task.run" },
    );
    try {
      await completeManagedNativeCredentialTurn(managedCredentialSession);
    } catch {
      // A durable result remains successful if optional credential refresh
      // fails. Retire this owner so it cannot keep stale auth on a warm turn.
      if (warmSessionId !== null && lifecyclePolicy.mode === "warm") {
        await releaseWarmNativeSession(warmSessionId, warmSessionOwnerToken, lifecyclePolicy.idleTimeoutMs, true);
      }
      await input.onLog?.("stderr", "[paperclip-runner] managed credential refresh failed; provider session retired.\n");
    }
    if (native.terminal.runTerminalState === "succeeded") {
      // A truncated, verified external-chat wake cannot settle from the
      // provider's partial inline prompt. The run-scoped reader records a
      // durable complete-page receipt; this fence revalidates that exact
      // current snapshot before any native finalization can become authoritative.
      await assertCurrentWakeCommentsRead(
        input.db,
        input.execution.binding,
        expectedCurrentWakeComments,
      );
    }
    await leaseRenewal.stop();
    await trace.record({
      name: "native.result.finalize",
      parentName: "task.settle",
      startedAtMs: turnCompletedAtMs ?? nativeSessionExecuteStartedAtMs,
      endedAtMs: Date.now(),
    });
    liveQuestions.close();
    activeNativeSessions.delete(input.execution.binding.runId);
    clearSteeringDeliveries(input.execution.binding.runId);
    clearNativeRuntimeRequestResolutions(input.execution.binding.runId);
  } catch (error) {
    if (nativeRunsDetachingForRestart.has(input.execution.binding.runId)) {
      await leaseRenewal.stop().catch(() => undefined);
      liveQuestions.close();
      activeNativeSessions.delete(input.execution.binding.runId);
      // Disconnecting deliberately ends the old event consumer. It is not a
      // provider failure and must not overwrite the shutdown adoption record
      // with a retry or release the still-live runner's lease.
      throw new NativeControllerDetachedForRestartError();
    }
    const protocolIntegrityFailure =
      error instanceof NativeSessionProtocolIntegrityError ? error : null;
    const ownershipUnverified =
      nativeSessionFailureSourceCode(error) ===
      NATIVE_ADOPTED_RUNNER_AUTHENTICATION_TIMEOUT;
    const attemptFailureStep = async (operation: () => unknown) => {
      try {
        await operation();
      } catch (secondaryError) {
        if (protocolIntegrityFailure === null) throw secondaryError;
      }
    };
    const stoppedLeaseRenewal = leaseRenewal.stop().catch(() => undefined);
    try {
      await input.db
        .update(nativeRunFinalizations)
        .set({
          controlDeadlineAt: new Date(
            Date.now() + EXECUTION_CONTROL_DEADLINE_MS,
          ),
        })
        .where(
          and(
            eq(nativeRunFinalizations.runId, input.execution.binding.runId),
            eq(nativeRunFinalizations.leaseOwner, leaseOwner),
          ),
        );

      const failedAtMs = Date.now();
      const executionFailureMessage = redactSensitiveText(
        error instanceof Error ? error.message : String(error),
      ).slice(-4_096);
      if (!taskSettleScope) {
        taskSettleScope = trace.start("task.settle", {
          parentName: "task.run",
          startedAtMs: failedAtMs,
        });
      }
      trace.activate(taskSettleScope);
      liveQuestions.close();
      activeNativeSessions.delete(input.execution.binding.runId);
      clearSteeringDeliveries(input.execution.binding.runId);
      clearNativeRuntimeRequestResolutions(input.execution.binding.runId);
      // Stop before paperclip_finish is normal. Bounded provider teardown has
      // finished; a missing result must not overwrite cancellation or trigger
      // another turn to perform completion bookkeeping.
      const stoppedBeforeFirstTurn = error instanceof Error && error.message === "native_session_cancelled";
      if (protocolIntegrityFailure === null && error instanceof Error &&
          (stoppedBeforeFirstTurn || error.message === "native_finalization_missing: session returned no semantic result")) {
        const [stoppedRun] = await input.db.select().from(heartbeatRuns).where(and(
          eq(heartbeatRuns.id, input.execution.binding.runId),
          eq(heartbeatRuns.companyId, input.execution.binding.companyId),
          eq(heartbeatRuns.agentId, input.execution.binding.agentId),
          eq(heartbeatRuns.nativeIssueId, input.execution.binding.issueId),
        )).limit(1);
        const stopIntent = record(stoppedRun?.resultJson?.nativeCancellation);
        // The backend can reject the first turn while the Stop API is still
        // recording its acknowledgement. Preserve that audited, exactly bound
        // cancellation instead of racing it with a generic provider failure.
        const pendingStartupStop = stoppedBeforeFirstTurn &&
          stopIntent.schema === "paperclip.native-cancellation.v1" &&
          stopIntent.companyId === input.execution.binding.companyId &&
          stopIntent.runId === input.execution.binding.runId &&
          stopIntent.issueId === input.execution.binding.issueId &&
          stopIntent.scope === "run" &&
          typeof stopIntent.intentAuditId === "string" && stopIntent.intentAuditId.length > 0 &&
          ["pending", "acknowledged"].includes(String(stopIntent.dispatchState));
        if (stoppedRun && (pendingStartupStop || hasAcknowledgedNativeStopIntent(stoppedRun) || hasAcknowledgedNativeReassignmentStopIntent(stoppedRun))) {
          const [settled] = await input.db.update(nativeRunFinalizations).set({
            phase: "terminal_failure", failureCode: "native_retry_cancelled", nextAttemptAt: null,
            leaseOwner: null, leaseExpiresAt: null, controlDeadlineAt: null, recoveryState: null,
            updatedAt: new Date(),
          }).where(and(
            eq(nativeRunFinalizations.runId, input.execution.binding.runId),
            eq(nativeRunFinalizations.companyId, input.execution.binding.companyId),
            eq(nativeRunFinalizations.leaseOwner, leaseOwner),
            eq(nativeRunFinalizations.attempt, attempt),
            isNull(nativeRunFinalizations.resultId),
          )).returning({ runId: nativeRunFinalizations.runId });
          if (settled) {
            await stoppedLeaseRenewal;
            if (warmSessionId !== null && lifecyclePolicy.mode === "warm") {
              await releaseWarmNativeSession(warmSessionId, warmSessionOwnerToken, lifecyclePolicy.idleTimeoutMs, true);
            }
            error = new NativeCancellationPendingRecoveryError();
          }
        }
      }
      if (
        error instanceof NativeResultPendingFinalizationError ||
        error instanceof NativeCancellationPendingRecoveryError
      ) {
        // This is not a provider failure and must not overwrite the durable
        // result/coordinator state. The heartbeat boundary will either hand an
        // already-materialized result to the finalizer or retain the durable
        // cancellation intent for cancellation recovery.
        if (taskSettleScope) {
          await trace.end(taskSettleScope, { outcome: "ok" });
        }
        await trace.finish("ok");
        throw error;
      }
      const now = new Date();
      const classifiedFailureCode = nativeSessionFailureSourceCode(error);
      const sourceFailureCode =
        classifiedFailureCode === "native_event_replay_conflict"
          ? classifiedFailureCode
          : providerUsageLimitObserved
            ? "native_provider_usage_limit"
            : classifiedFailureCode;
      const recoveryEvidence = await nativeProviderRecoveryEvidence({
        db: input.db,
        runId: input.execution.binding.runId,
        sourceFailureCode,
      });
      const disposition = nativeSessionFailureDisposition(
        attempt,
        now,
        sourceFailureCode,
      );
      const phase =
        recoveryEvidence.recoveryMode === "ambiguous_state"
          ? ("terminal_failure" as const)
          : disposition.phase;
      const failureCode =
        recoveryEvidence.recoveryMode === "ambiguous_state"
          ? sourceFailureCode
          : disposition.failureCode;
      const nextAttemptAt =
        recoveryEvidence.recoveryMode === "ambiguous_state"
          ? null
          : disposition.nextAttemptAt;
      const recoveryProjection = nativeSessionRecoveryProjection({
        phase,
        failureCode,
        agentId: input.execution.binding.agentId,
      });
      const { exhausted } = recoveryProjection;
      const integrityFailure =
        sourceFailureCode === "native_event_replay_conflict";
      const message =
        error instanceof Error
          ? error.message.slice(0, 2_000)
          : String(error).slice(0, 2_000);
      const sanitizedStderrTail = redactSensitiveText(message).slice(-4_096);
      // Set inside the transaction only when the write below genuinely
      // transitions the run into "failed". Read after the transaction
      // commits, so a rolled-back write never reports a false failure.
      let terminalRunToReport: typeof heartbeatRuns.$inferSelect | null = null;
      // Preserve the execution error even if recording its state later fails
      // on a separate database lock or storage error.
      await attemptFailureStep(() =>
        input.onLog?.(
          "stderr",
          `[paperclip-runner] native session execution failed: ${executionFailureMessage}\n`,
        ),
      );
      if (process.env.PAPERCLIP_MANAGED_OPENCODE_E2E_DIAGNOSTICS === "1" ||
          process.env.PAPERCLIP_NATIVE_SOURCE_MEMO_DIAGNOSTICS === "1") {
        const originalError = error instanceof Error ? error as Error & { code?: unknown; cause?: { code?: unknown } } : null;
        const safeCode = (value: unknown) => typeof value === "string" && /^[A-Z0-9_]{1,32}$/.test(value)
          ? value : undefined;
        const frames = originalError?.stack?.split("\n").slice(1).flatMap(line => {
          const match = /\/server\/src\/services\/([^():]+\.ts):(\d+):\d+/.exec(line);
          return match ? [`${match[1]}:${match[2]}`] : [];
        }).slice(0, 4) ?? [];
        const failureFacts = { name: originalError?.name ?? "UnknownError",
          code: safeCode(originalError?.code), causeCode: safeCode(originalError?.cause?.code), frames };
        await attemptFailureStep(() => input.onLog?.("stderr",
          `[paperclip-runner] native session original failure facts: ${JSON.stringify(failureFacts)}\n`));
      }
      await input.db.transaction(async (tx) => {
        await tx.execute(
          sql`select set_config('statement_timeout', '15000', true), set_config('lock_timeout', '1000', true)`,
        );
        // Use the same issue-before-run lock order as admission. A late failure
        // can terminalize its own run, but cannot change a reassigned task.
        const [failureTask] = await tx
          .select()
          .from(issues)
          .where(
            and(
              eq(issues.id, input.execution.binding.issueId),
              eq(issues.companyId, input.execution.binding.companyId),
            ),
          )
          .for("update");
        const updated = await tx
          .update(nativeRunFinalizations)
          .set({
            phase,
            controlDeadlineAt: null,
            leaseOwner: null,
            leaseExpiresAt: null,
            recoveryState:
              phase === "retryable_failure" ? "resuming_session" : "blocked",
            failureCode,
            failureDetail: {
              message,
              originalFailureCode:
                error instanceof NativeProviderTerminalFailure
                  ? error.providerCode
                  : sourceFailureCode,
              recoverable:
                error instanceof NativeProviderTerminalFailure
                  ? error.recoverable
                  : phase === "retryable_failure",
              recoveryMode: recoveryEvidence.recoveryMode,
              providerSessionEstablished:
                recoveryEvidence.providerSessionEstablished,
              providerEventsExist: recoveryEvidence.providerEventsExist,
              checkpointExists: recoveryEvidence.checkpointExists,
              recoveryOwner: recoveryProjection.recoveryOwner,
              nextAction:
                sourceFailureCode === "native_provider_approval_required"
                  ? "Approval required. Review the operation and update the agent's permission setting before retrying. This runner has no interactive approval handler."
                  : sourceFailureCode === "native_session_cleanup_quarantined"
                  ? NATIVE_CLEANUP_OPERATOR_RECOVERY_MESSAGE
                  : sourceFailureCode === "native_provider_terminal_failed"
                    ? "The provider session is permanently unusable. Verify stopped execution, completed actions, and task context before starting a linked continuation."
                    : recoveryEvidence.recoveryMode === "ambiguous_state"
                      ? "Inspect the original provider failure and durable events; state is ambiguous and a replacement provider session is forbidden."
                      : integrityFailure
                        ? "Inspect the persisted runner events and checkpoint for a source-sequence integrity conflict; automatic recovery is stopped."
                        : sourceFailureCode === "native_provider_usage_limit"
                          ? "Restore model provider usage capacity, then explicitly retry the task. Automatic retries cannot resolve an exhausted provider allowance."
                          : ownershipUnverified
                            ? "Inspect the retained runner's executable and authenticated connection. Do not replace its provider until ownership is safely resolved."
                            : exhausted
                              ? "Inspect the persisted native session after its bounded resume budget was exhausted."
                              : recoveryEvidence.recoveryMode ===
                                  "bootstrap_retry"
                                ? "Retry provider bootstrap on this same run; durable evidence proves no provider session or provider event was created."
                                : "Resume this same run from its exact persisted native provider checkpoint after the retry delay.",
            },
            nextAttemptAt,
            recoveryHistory: sql`(
              select coalesce(jsonb_agg(item order by ordinal), '[]'::jsonb)
              from jsonb_array_elements(
                coalesce(${nativeRunFinalizations.recoveryHistory}, '[]'::jsonb)
                || jsonb_build_array(${JSON.stringify({
                  at: now.toISOString(),
                  disposition: phase,
                  reason: sourceFailureCode,
                  controllerBootId: controller.bootId,
                  controllerGeneration:
                    input.restartRecovery?.controllerGeneration ?? null,
                  providerAttempt: attempt,
                  stderrTail: sanitizedStderrTail,
                  providerSessionEstablished:
                    recoveryEvidence.providerSessionEstablished,
                  checkpointExists: recoveryEvidence.checkpointExists,
                })}::jsonb)
              ) with ordinality as history(item, ordinal)
              where ordinal > greatest(
                jsonb_array_length(
                  coalesce(${nativeRunFinalizations.recoveryHistory}, '[]'::jsonb)
                  || jsonb_build_array(${JSON.stringify({
                    at: now.toISOString(),
                    disposition: phase,
                    reason: sourceFailureCode,
                    controllerBootId: controller.bootId,
                    controllerGeneration:
                      input.restartRecovery?.controllerGeneration ?? null,
                    providerAttempt: attempt,
                    stderrTail: sanitizedStderrTail,
                    providerSessionEstablished:
                      recoveryEvidence.providerSessionEstablished,
                    checkpointExists: recoveryEvidence.checkpointExists,
                  })}::jsonb)
                ) - 20,
                0
              )
            )`,
            updatedAt: now,
          })
          .where(
            and(
              eq(nativeRunFinalizations.runId, input.execution.binding.runId),
              eq(
                nativeRunFinalizations.companyId,
                input.execution.binding.companyId,
              ),
              eq(
                nativeRunFinalizations.issueId,
                input.execution.binding.issueId,
              ),
              eq(nativeRunFinalizations.leaseOwner, leaseOwner),
              eq(nativeRunFinalizations.attempt, attempt),
              eq(nativeRunFinalizations.controllerBootId, controller.bootId),
              eq(nativeRunFinalizations.controllerPid, controller.pid),
              eq(
                nativeRunFinalizations.controllerProcessStartedAt,
                controller.processStartedAt,
              ),
              gt(nativeRunFinalizations.leaseExpiresAt, sql`now()`),
            ),
          )
          .returning({ runId: nativeRunFinalizations.runId })
          .then((rows) => rows[0] ?? null);
        if (!updated) throw new Error("native_session_lease_lost");
        const [runBeforeWrite] = await tx
          .select({ status: heartbeatRuns.status })
          .from(heartbeatRuns)
          .where(eq(heartbeatRuns.id, input.execution.binding.runId))
          .for("update");
        const [updatedRun] = await tx
          .update(heartbeatRuns)
          .set({
            // An authentication timeout does not prove the retained runner or
            // its provider stopped. Preserve physical ownership until verified.
            ...(!ownershipUnverified
              ? {
                  status: "failed",
                  executionStatusDeliveryId: randomUUID(),
                  finishedAt: now,
                }
              : {}),
            nativePhase: phase,
            nativePhaseUpdatedAt: now,
            error: message,
            errorCode: ownershipUnverified
              ? NATIVE_OWNERSHIP_UNVERIFIED_ERROR_CODE
              : sourceFailureCode,
            updatedAt: now,
          })
          .where(eq(heartbeatRuns.id, input.execution.binding.runId))
          .returning();
        if (
          updatedRun &&
          runBeforeWrite &&
          updatedRun.status !== runBeforeWrite.status
        ) {
          terminalRunToReport = updatedRun;
        }
        const stillOwnsTask =
          failureTask?.assigneeAgentId === input.execution.binding.agentId &&
          ["in_progress", "in_review"].includes(failureTask.status) &&
          (!failureTask.executionRunId ||
            failureTask.executionRunId === input.execution.binding.runId) &&
          (!failureTask.checkoutRunId ||
            failureTask.checkoutRunId === input.execution.binding.runId);
        let failureBlockStatusVersion: number | undefined;
        if (stillOwnsTask && recoveryProjection.issueStatus) {
          const projected = await issueService(tx as unknown as Db).update(
            input.execution.binding.issueId,
            { status: recoveryProjection.issueStatus },
            tx,
          );
          if (projected?.status === "blocked") failureBlockStatusVersion = projected.statusVersion;
        }
        if (
          !ownershipUnverified &&
          stillOwnsTask &&
          phase === "terminal_failure"
        ) {
          await tx
            .update(issues)
            .set({ executionRunId: null, checkoutRunId: null, updatedAt: now })
            .where(eq(issues.id, input.execution.binding.issueId));
        }
        if (!stillOwnsTask) return;
        await issueRecoveryActionService(
          tx as unknown as Db,
        ).upsertSourceScoped({
          companyId: input.execution.binding.companyId,
          sourceIssueId: input.execution.binding.issueId,
          kind: "active_run_watchdog",
          ownerType: recoveryProjection.recoveryActionOwnerType,
          ownerAgentId: recoveryProjection.recoveryActionOwnerAgentId,
          returnOwnerAgentId: input.execution.binding.agentId,
          cause: recoveryProjection.recoveryActionCause,
          fingerprint: createHash("sha256")
            .update(`${input.execution.binding.runId}:${failureCode}`)
            .digest("hex"),
          evidence: {
            runId: input.execution.binding.runId,
            ...(failureBlockStatusVersion !== undefined ? { nativeFailureBlock: {
              runId: input.execution.binding.runId,
              statusVersion: failureBlockStatusVersion,
            } } : {}),
            coordinatorAttempt: attempt,
            sourceFailureCode,
            recoveryDisposition: failureCode,
            recoveryMode: recoveryEvidence.recoveryMode,
            providerSessionEstablished:
              recoveryEvidence.providerSessionEstablished,
          },
          nextAction:
            sourceFailureCode === "native_provider_approval_required"
              ? "Approval required. Review the operation and update the agent's permission setting before retrying. This runner has no interactive approval handler."
              : sourceFailureCode === "native_session_cleanup_quarantined"
              ? NATIVE_CLEANUP_OPERATOR_RECOVERY_MESSAGE
              : sourceFailureCode === "native_provider_terminal_failed"
                ? "Verify that the failed provider stopped and reconcile its action outcomes. A linked continuation can proceed only after these checks succeed."
                : recoveryEvidence.recoveryMode === "ambiguous_state"
                  ? "Inspect the original provider failure and explicitly resolve the ambiguous session state; do not open a replacement provider session."
                  : integrityFailure
                    ? "Inspect the persisted runner event collision and explicitly repair or replace the run; automatic retries are disabled."
                    : sourceFailureCode === "native_provider_usage_limit"
                      ? "Restore model provider usage capacity, then explicitly retry the task; automatic retries are stopped."
                      : ownershipUnverified
                        ? "Resolve the retained runner's authentication or executable compatibility before an explicit recovery; do not blindly restart, cancel, or replace its provider session."
                        : exhausted
                          ? "Inspect the provider trace and explicitly choose a replacement run or provider configuration; automatic provider work is stopped."
                          : recoveryEvidence.recoveryMode === "bootstrap_retry"
                            ? "Retry bootstrap on the same run without manufacturing a provider checkpoint."
                            : "Resume the exact persisted native session on the same heartbeat run.",
          wakePolicy: nextAttemptAt
            ? {
                kind: "resume_native_run",
                runId: input.execution.binding.runId,
                notBefore: nextAttemptAt.toISOString(),
              }
            : null,
          maxAttempts: 3,
          supersedeOnIdentityChange:
            recoveryProjection.supersedeOnIdentityChange,
        });
      });
      if (terminalRunToReport) void reportRunFailure(input.db, terminalRunToReport);
      await boundedExecutionCleanup(async () => {
        await stoppedLeaseRenewal;
        if (runnerSessionStartupScope) {
          await attemptFailureStep(() =>
            trace.end(runnerSessionStartupScope!, {
              endedAtMs: failedAtMs,
              outcome: "failed",
            }),
          );
        }
        if (agentTurnScope) {
          await attemptFailureStep(() =>
            trace.end(agentTurnScope!, {
              endedAtMs: failedAtMs,
              outcome: "failed",
            }),
          );
        }
        if (
          !ownershipUnverified &&
          warmSessionId !== null &&
          lifecyclePolicy.mode === "warm"
        ) {
          await attemptFailureStep(() =>
            releaseWarmNativeSession(
              warmSessionId!,
              warmSessionOwnerToken,
              lifecyclePolicy.idleTimeoutMs,
              true,
            ),
          );
        }
        if (taskSettleScope)
          await trace.end(taskSettleScope, { outcome: "failed" });
        await trace.finish("failed");
      });
      throw error;
    } finally {
      // Even a secondary logging/recovery-write failure cannot authorize
      // heartbeat to release the retained process or its task ownership.
      if (ownershipUnverified) throw new NativeRunnerOwnershipUnverifiedError();
      if (protocolIntegrityFailure !== null) throw protocolIntegrityFailure;
    }
  } finally {
    releaseGitHubRun?.();
    // A startup failure or onSession(null) must not leak a transport. A warm
    // owner retains only the inactive broker until its normal retirement.
    if (githubAccess && (!warmSessionId || warmNativeSessions.get(warmSessionId)?.githubAccess !== githubAccess)) {
      await githubAccess.stop();
    }
  }
  if (
    planSynchronizations.length === 0 &&
    "executionMode" in input.execution &&
    input.execution.executionMode === "plan"
  ) {
    const markdown = semanticProviderPlanMarkdown(
      native.result as unknown as Record<string, unknown>,
    );
    if (markdown) {
      const digest = createHash("sha256").update(markdown).digest("hex");
      await recordPlanSynchronization({
        sourceEventId: `semantic-plan:${input.execution.binding.runId}:${digest}`,
        ...(native.turnId ? { turnId: native.turnId } : {}),
        eventType: "plan.updated",
        payload: {
          schema: "paperclip.plan.updated.v1",
          planId: `semantic:${native.turnId ?? input.execution.binding.runId}`,
          revision: 1,
          complete: true,
          markdown,
          source: "semantic_result_artifact",
        },
      });
    }
  }
  const releaseNow = new Date();
  const released = await input.db
    .update(nativeRunFinalizations)
    .set({
      leaseOwner: null,
      leaseExpiresAt: null,
      recoveryState: null,
      recoveryRequestId: null,
      updatedAt: releaseNow,
    })
    .where(
      and(
        eq(nativeRunFinalizations.runId, input.execution.binding.runId),
        eq(nativeRunFinalizations.companyId, input.execution.binding.companyId),
        eq(nativeRunFinalizations.issueId, input.execution.binding.issueId),
        eq(nativeRunFinalizations.leaseOwner, leaseOwner),
        eq(nativeRunFinalizations.attempt, attempt),
        eq(nativeRunFinalizations.controllerBootId, controller.bootId),
        eq(nativeRunFinalizations.controllerPid, controller.pid),
        eq(
          nativeRunFinalizations.controllerProcessStartedAt,
          controller.processStartedAt,
        ),
        gt(nativeRunFinalizations.leaseExpiresAt, sql`now()`),
      ),
    )
    .returning({ runId: nativeRunFinalizations.runId })
    .then((rows) => rows[0] ?? null);
  if (!released) throw new Error("native_session_lease_lost");
  const finalization: NativeFinalizationResult = {
    schema: "paperclip.native-finalization.v1",
    runtimeMode: "native",
    runId: input.execution.binding.runId,
    issueId: input.execution.binding.issueId,
    companyId: input.execution.binding.companyId,
    result: native.result as unknown as Record<string, unknown>,
    terminal: native.terminal,
    turnId: native.turnId,
    sourceInstanceId: effectiveRunnerInstanceId,
    normalizedSessionId: native.normalizedSessionId,
    providerSessionId: native.providerSessionId,
    driverKind: native.driverKind,
    driverVersion: native.driverVersion,
    nativeEventCount: native.nativeEventCount,
    highestContiguousSourceSeq: native.highestContiguousSourceSeq,
    workspaceFinalizeStatus: "pending",
  };
  // A following run cannot attach until the prior run's durable finalization
  // is committed. Provider completion alone is not an authority boundary.
  if (warmSessionId !== null && lifecyclePolicy.mode === "warm") {
    await releaseWarmNativeSession(
      warmSessionId,
      warmSessionOwnerToken,
      lifecyclePolicy.idleTimeoutMs,
      false,
    );
  }
  const adapterResult: AdapterExecutionResult = {
    exitCode: native.terminal.runTerminalState === "succeeded" ? 0 : 1,
    signal: null,
    timedOut: false,
    errorMessage:
      native.terminal.runTerminalState === "succeeded"
        ? null
        : `Native session ${native.terminal.runTerminalState}`,
    resultJson: {
      nativeResult: native.result as unknown as Record<string, unknown>,
      nativeTerminal: native.terminal as unknown as Record<string, unknown>,
      ...(native.goalRolloverRequired ? { goalRolloverRequired: true } : {}),
      planSynchronizations,
    },
    summary: native.result.summary,
    sessionId: native.normalizedSessionId,
    sessionDisplayId: native.providerSessionId ?? native.normalizedSessionId,
    provider: input.execution.provider.kind === "aw_text_only" ? "anthropic" : "openai",
    model: input.execution.provider.model,
    usage: normalizeNativeUsage(native.usage),
    costUsd: nativeUsageCostUsd(native.usage),
    usageBasis: "per_run",
    nativeFinalization: finalization,
  };
  if (taskSettleScope) {
    await trace.end(taskSettleScope, {
      outcome:
        native.terminal.runTerminalState === "succeeded" ? "ok" : "failed",
    });
  }
  await trace.finish(
    native.terminal.runTerminalState === "succeeded" ? "ok" : "failed",
  );
  return adapterResult;
}

function numericUsageField(
  usage: Record<string, unknown> | null,
  keys: string[],
): number | undefined {
  if (!usage) return undefined;
  for (const key of keys) {
    const value = usage[key];
    if (typeof value === "number" && Number.isFinite(value) && value >= 0)
      return value;
  }
  return undefined;
}

function nativeUsageMeasurement(usage: Record<string, unknown>) {
  const nestedUsage = record(usage.usage);
  const candidates = [
    record(usage.runDelta),
    record(nestedUsage.runDelta),
    record(usage.total),
    record(nestedUsage.total),
    record(usage.cumulative),
    record(nestedUsage.cumulative),
    nestedUsage,
    usage,
  ];
  return (
    candidates.find(
      (candidate) =>
        numericUsageField(candidate, [
          "inputTokens",
          "input",
          "promptTokens",
          "outputTokens",
          "output",
          "completionTokens",
        ]) !== undefined,
    ) ?? usage
  );
}

export function nativeUsageCostUsd(usage: Record<string, unknown> | null) {
  if (!usage) return undefined;
  const measurement = nativeUsageMeasurement(usage);
  const direct =
    numericUsageField(usage, [
      "providerCostUsd",
      "cacheAdjustedCostUsd",
      "costUsd",
    ]) ??
    numericUsageField(measurement, [
      "providerCostUsd",
      "cacheAdjustedCostUsd",
      "costUsd",
    ]);
  if (direct !== undefined) return direct;
  const cost = record(usage.cost);
  const currency =
    typeof cost.currency === "string" ? cost.currency.toUpperCase() : "USD";
  if (currency !== "USD") return undefined;
  return numericUsageField(cost, ["amount", "total"]);
}

export function normalizeNativeUsage(usage: Record<string, unknown> | null) {
  if (!usage) return undefined;
  const measurement = nativeUsageMeasurement(usage);
  const cache = record(measurement.cache);
  const cachedInputTokens =
    numericUsageField(measurement, [
      "cachedInputTokens",
      "cacheReadInputTokens",
      "cacheReadTokens",
      "cachedReadTokens",
    ]) ?? numericUsageField(cache, ["read"]);
  return {
    inputTokens:
      numericUsageField(measurement, [
        "inputTokens",
        "input",
        "promptTokens",
      ]) ?? 0,
    outputTokens:
      numericUsageField(measurement, [
        "outputTokens",
        "output",
        "completionTokens",
      ]) ?? 0,
    ...(cachedInputTokens === undefined ? {} : { cachedInputTokens }),
  };
}

function processEnvironment(
  environment: NodeJS.ProcessEnv,
): Record<string, string> {
  return Object.fromEntries(
    Object.entries(environment).filter(
      (entry): entry is [string, string] => typeof entry[1] === "string",
    ),
  );
}

function sandboxRunnerProcessEnvironment(
  environment: NodeJS.ProcessEnv,
): Record<string, string> {
  const result = processEnvironment(environment);
  // These values belong to RuntimeControl's typed broker credentials. The
  // runner transport keeps its selected environment, while sandboxExec
  // receives none of the caller-controlled reserved keys and injects the
  // current server-issued tuple into the launched process itself.
  for (const key of [
    "PAPERCLIP_SANDBOX_BROKER_TOKEN",
    "PAPERCLIP_SANDBOX_BROKER_ENDPOINT_ORIGIN",
    "PAPERCLIP_SANDBOX_BROKER_SESSION_ID",
    "PAPERCLIP_MANAGED_MODEL_BROKER_ORIGIN",
    "PAPERCLIP_MANAGED_MODEL_INPUT_TOKENS_UPPER_BOUND",
    "PAPERCLIP_MANAGED_MODEL_MAX_OUTPUT_TOKENS",
  ]) delete result[key];
  return result;
}

/** Preserve package-manager shims that resolve dependencies relative to argv[0]. */
export function buildRemoteCodexLauncherCommand(
  sourcePath: string,
  targetPath: string,
): string {
  if (sourcePath === targetPath)
    throw new Error("runner_remote_preinstalled_source_conflict");
  const quote = (value: string) => "'" + value.replaceAll("'", "'\\''") + "'";
  const launcher = `#!/bin/sh\nexec ${quote(sourcePath)} "$@"\n`;
  // Replace atomically: writing through an existing symlink would corrupt the
  // image's shared CLI, and another run may be executing this launcher already.
  return (
    `umask 077; mkdir -p ${quote(posix.dirname(targetPath))} && ` +
    `[ ! -d ${quote(targetPath)} ] && ` +
    `paperclip_codex_launcher_tmp=$(mktemp ${quote(targetPath + ".tmp.XXXXXX")}) && ` +
    `trap 'rm -f "$paperclip_codex_launcher_tmp"' 0 && ` +
    `printf '%s' ${quote(launcher)} > "$paperclip_codex_launcher_tmp" && ` +
    `chmod 700 "$paperclip_codex_launcher_tmp" && ` +
    `mv -f "$paperclip_codex_launcher_tmp" ${quote(targetPath)}`
  );
}

export function parseRemoteExecutableCandidate(stdout: string): string | null {
  const lines = stdout
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
  if (lines.length !== 1) return null;
  const candidate = lines[0]!;
  if (
    !candidate.startsWith("/") ||
    candidate.length > 4_096 ||
    !/^\/[A-Za-z0-9_./+@-]+$/.test(candidate)
  ) {
    return null;
  }
  return posix.normalize(candidate);
}

export function mayUsePreinstalledRunnerArtifact(
  configuredRemoteBinaryPath: string | null | undefined,
): boolean {
  return !configuredRemoteBinaryPath?.trim();
}

const RUNNERD_BUILD_METADATA_SCHEMA =
  "paperclip-runner/runnerd-build-metadata/v1";
const RUNNERD_BINARY_CONTRACT_VERSION = 2;

const REMOTE_PROVIDER_PACK_SCHEMA = "paperclip-runner/remote-provider-pack/v1";
const REMOTE_PROVIDER_PACK_PINS = {
  nodeMinimum: "24.11.0",
  codex: "0.156.0",
  opencode: "1.18.32",
  acpx: "0.13.1",
  claudeAcp: "0.73.0",
  codexAcp: "1.6.2",
} as const;
const REMOTE_PROVIDER_PACK_PROFILE_DIGESTS = {
  claude:
    "sha256:9d73d1f0f121fb96cc8badb28c22d5bff02d8582eb2e40360a81c189e1b9422a",
  codex:
    "sha256:c4538599d1ab767db5dff50934f13bb5ba313a59d9c4a83e993fac4617ea63d3",
} as const;
const REMOTE_PROVIDER_PACK_ARTIFACT_PATHS = {
  nodeCommand: "node_modules/node/bin/node",
  productionLock: "pnpm-lock.yaml",
  opencodeCommand: "node_modules/.bin/opencode",
  opencodeExecutable: "node_modules/opencode-ai/bin/opencode.exe",
  opencodeProxy: "dist/cli/opencode-app-server-proxy.cjs",
  acpxSidecar: "dist/cli/acpx-runtime-sidecar.cjs",
} as const;

type RemoteProviderPackManifest = {
  schema: typeof REMOTE_PROVIDER_PACK_SCHEMA;
  digest: string;
  payload: {
    pins: typeof REMOTE_PROVIDER_PACK_PINS;
    target: { platform: string; architecture: string };
    runnerSourceRevision: string;
    distDigest: string;
    bridgeDigest: string;
    acpxProfileDigests: typeof REMOTE_PROVIDER_PACK_PROFILE_DIGESTS;
    artifacts: {
      nodeCommand: { path: string; sha256: string };
      productionLock: { path: string; sha256: string };
      opencodeCommand: { path: string; sha256: string };
      opencodeExecutable: { path: string; sha256: string };
      opencodeProxy: { path: string; sha256: string };
      acpxSidecar: { path: string; sha256: string };
    };
  };
};

function sha256File(path: string): string {
  return `sha256:${createHash("sha256").update(readFileSync(path)).digest("hex")}`;
}

export function sha256DirectoryTree(root: string): string {
  const hash = createHash("sha256");
  const visit = (directory: string, prefix = "") => {
    const entries = readdirSync(directory, { withFileTypes: true }).sort(
      (left, right) => left.name.localeCompare(right.name),
    );
    for (const entry of entries) {
      const relativePath = prefix ? `${prefix}/${entry.name}` : entry.name;
      const absolutePath = join(directory, entry.name);
      if (entry.isDirectory()) {
        hash.update(`directory\0${relativePath}\n`);
        visit(absolutePath, relativePath);
      } else if (entry.isFile()) {
        hash.update(`file\0${relativePath}\0${sha256File(absolutePath)}\n`);
      } else if (entry.isSymbolicLink()) {
        hash.update(
          `symlink\0${relativePath}\0${readlinkSync(absolutePath)}\n`,
        );
      } else {
        throw new Error(
          `runner_remote_provider_artifact_incompatible: unsupported dist entry ${relativePath}`,
        );
      }
    }
  };
  visit(root);
  return `sha256:${hash.digest("hex")}`;
}

function providerPackRelativePath(value: unknown, field: string): string {
  if (
    typeof value !== "string" ||
    value.length === 0 ||
    value.startsWith("/") ||
    value.includes("\\") ||
    posix.normalize(value) !== value ||
    value.split("/").includes("..")
  ) {
    throw new Error(
      `runner_remote_provider_artifact_incompatible: invalid ${field}`,
    );
  }
  return value;
}

export function readRemoteProviderPackManifest(
  packRoot: string,
): RemoteProviderPackManifest {
  let manifest: RemoteProviderPackManifest;
  try {
    manifest = JSON.parse(
      readFileSync(resolve(packRoot, "provider-pack.json"), "utf8"),
    ) as RemoteProviderPackManifest;
  } catch (error) {
    throw new Error(
      "runner_remote_provider_artifact_incompatible: provider-pack.json is unreadable",
      { cause: error },
    );
  }
  const payload = manifest?.payload;
  if (
    manifest.schema !== REMOTE_PROVIDER_PACK_SCHEMA ||
    !payload ||
    canonicalJson(payload.pins) !== canonicalJson(REMOTE_PROVIDER_PACK_PINS) ||
    canonicalJson(payload.acpxProfileDigests) !==
      canonicalJson(REMOTE_PROVIDER_PACK_PROFILE_DIGESTS) ||
    typeof payload.target?.platform !== "string" ||
    typeof payload.target?.architecture !== "string" ||
    !/^[0-9a-f]{40}(?:-dirty)?$/.test(payload.runnerSourceRevision) ||
    !/^sha256:[0-9a-f]{64}$/.test(payload.distDigest)
  ) {
    throw new Error(
      "runner_remote_provider_artifact_incompatible: provider pack pins or source revision do not match",
    );
  }
  const digest = `sha256:${createHash("sha256")
    .update(canonicalJson(payload))
    .digest("hex")}`;
  if (manifest.digest !== digest) {
    throw new Error(
      "runner_remote_provider_artifact_incompatible: provider pack manifest digest mismatch",
    );
  }
  const artifactEntries = [
    [
      "provider Node",
      payload.artifacts?.nodeCommand,
      REMOTE_PROVIDER_PACK_ARTIFACT_PATHS.nodeCommand,
    ],
    [
      "production lockfile",
      payload.artifacts?.productionLock,
      REMOTE_PROVIDER_PACK_ARTIFACT_PATHS.productionLock,
    ],
    [
      "OpenCode command",
      payload.artifacts?.opencodeCommand,
      REMOTE_PROVIDER_PACK_ARTIFACT_PATHS.opencodeCommand,
    ],
    [
      "OpenCode executable",
      payload.artifacts?.opencodeExecutable,
      REMOTE_PROVIDER_PACK_ARTIFACT_PATHS.opencodeExecutable,
    ],
    [
      "OpenCode proxy",
      payload.artifacts?.opencodeProxy,
      REMOTE_PROVIDER_PACK_ARTIFACT_PATHS.opencodeProxy,
    ],
    [
      "ACPX sidecar",
      payload.artifacts?.acpxSidecar,
      REMOTE_PROVIDER_PACK_ARTIFACT_PATHS.acpxSidecar,
    ],
  ] as const;
  for (const [label, artifact, expectedPath] of artifactEntries) {
    const artifactPath = providerPackRelativePath(
      artifact?.path,
      `${label} path`,
    );
    if (artifactPath !== expectedPath) {
      throw new Error(
        `runner_remote_provider_artifact_incompatible: ${label} path must be ${expectedPath}`,
      );
    }
    if (
      typeof artifact?.sha256 !== "string" ||
      sha256File(resolve(packRoot, artifactPath)) !== artifact.sha256
    ) {
      throw new Error(
        `runner_remote_provider_artifact_incompatible: ${label} digest mismatch`,
      );
    }
  }
  if (sha256DirectoryTree(resolve(packRoot, "dist")) !== payload.distDigest) {
    throw new Error(
      "runner_remote_provider_artifact_incompatible: provider dist tree digest mismatch",
    );
  }
  const bridgeDigest = `sha256:${createHash("sha256")
    .update(payload.artifacts.opencodeProxy.sha256)
    .update("\n")
    .update(payload.artifacts.acpxSidecar.sha256)
    .update("\n")
    .update(payload.distDigest)
    .digest("hex")}`;
  if (payload.bridgeDigest !== bridgeDigest) {
    throw new Error(
      "runner_remote_provider_artifact_incompatible: provider bridge digest mismatch",
    );
  }
  return structuredClone(manifest);
}

export function assertRemoteRunnerBuildMetadata(
  value: unknown,
  requiredMode: "dial_wss" | "listen_ws",
): void {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error("runner_remote_artifact_metadata_invalid");
  }
  const metadata = value as Record<string, unknown>;
  if (
    metadata.schema !== RUNNERD_BUILD_METADATA_SCHEMA ||
    metadata.binaryName !== "paperclip-runnerd" ||
    metadata.packageName !== "@paperclipai/paperclip-runner" ||
    metadata.binaryContractVersion !== RUNNERD_BINARY_CONTRACT_VERSION
  ) {
    throw new Error("runner_remote_artifact_contract_incompatible");
  }
  // Older sandbox images share binary contract v2, but reject the zero
  // lifetime now used by the controller and cannot renew connection leases.
  // Reject them before launch so preparation stages the bundled runner instead.
  const sessionCapabilities = Array.isArray(metadata.durableSessionCapabilities)
    ? metadata.durableSessionCapabilities
    : [];
  for (const capability of ["unlimited_runtime", "connection_lease_renewal"]) {
    if (!sessionCapabilities.includes(capability)) {
      throw new Error(`runner_remote_session_capability_missing:${capability}`);
    }
  }
  const modes = Array.isArray(metadata.prpTransportModes)
    ? metadata.prpTransportModes
    : [];
  if (!modes.includes(requiredMode)) {
    throw new Error(
      `runner_remote_transport_capability_missing:${requiredMode}`,
    );
  }
}

export async function stageRemoteRunnerFile(input: {
  target: Extract<AdapterExecutionTarget, { kind: "remote" }>;
  runner: CommandManagedRuntimeRunner;
  sourcePath: string;
  targetPath: string;
  mode: number;
  nativePreparationPurpose?: "provider_artifact" | "native_runtime_context_prepare" | "native_provider_data_erasure_probe";
  forceRelayChunking?: boolean;
}): Promise<void> {
  const runner = input.runner;
  if ((input.forceRelayChunking || input.target.transport === "sandbox") && input.nativePreparationPurpose === "provider_artifact") {
    const bytes = readFileSync(input.sourcePath);
    await stageRemoteArtifactBytesInChunks({
      runner,
      cwd: input.target.remoteCwd,
      targetPath: input.targetPath,
      mode: input.mode,
      bytes,
    });
    return;
  }
  if (runner.syncIn && input.nativePreparationPurpose !== "native_runtime_context_prepare") {
    await runner.syncIn([
      {
        operationId: `runner-stage-${randomUUID()}`,
        files: [
          {
            sourcePath: input.sourcePath,
            targetPath: input.targetPath,
            kind: "file",
            mode: input.mode,
          },
        ],
      },
    ]);
    return;
  }
  const bytes = readFileSync(input.sourcePath);
  const directory = posix.dirname(input.targetPath);
  const script =
    `umask 077; mkdir -p '${directory.replaceAll("'", "'\\''")}' && ` +
    `base64 -d > '${input.targetPath.replaceAll("'", "'\\''")}' && ` +
    `chmod ${input.mode.toString(8)} '${input.targetPath.replaceAll("'", "'\\''")}'`;
  const result = await runner.execute({
    command: "sh",
    args: ["-c", script],
    stdin: bytes.toString("base64"),
    bypassSession: true,
    nativePreparationPurpose: input.nativePreparationPurpose,
  });
  if (result.exitCode !== 0 || result.timedOut) {
    throw new Error("runner_remote_staging_failed");
  }
}

function archiveExcludeArgs(entries: readonly string[]): string[] {
  for (const entry of entries) {
    const segments = entry.split("/");
    if (
      entry.length === 0 ||
      entry.startsWith("/") ||
      segments.some(
        (segment) =>
          segment === "" ||
          segment === "." ||
          segment === ".." ||
          !/^[A-Za-z0-9._-]+$/.test(segment),
      )
    ) {
      throw new Error("runner_remote_checkpoint_exclusion_invalid");
    }
  }
  return entries.map((entry) => `--exclude=./${entry}`);
}

export async function stageRemoteRunnerDirectory(input: {
  target: Extract<AdapterExecutionTarget, { kind: "remote" }>;
  runner: CommandManagedRuntimeRunner;
  sourcePath: string;
  targetPath: string;
  mode: number;
  excludeEntries?: readonly string[];
  nativePreparationPurpose?: "provider_artifact" | "native_runtime_context_prepare" | "native_harness_state" | "native_provider_data_erasure_probe";
}): Promise<void> {
  const excludeArgs = archiveExcludeArgs(input.excludeEntries ?? []);
  // Runtime context is a source-pinned, server-owned preparation phase. Route
  // it through the signed execute relay so RuntimeControl can bind the exact
  // run/profile and private context target; native provider sync has no owner
  // field and cannot prove those bindings.
  if (input.runner.syncIn && input.nativePreparationPurpose !== "native_runtime_context_prepare" &&
    input.nativePreparationPurpose !== "native_harness_state") {
    let stagingRoot: string | null = null;
    let sourcePath = input.sourcePath;
    try {
      if (excludeArgs.length > 0) {
        stagingRoot = mkdtempSync(join(tmpdir(), "paperclip-runner-restore-"));
        const archive = execFileSync(
          "tar",
          [...excludeArgs, "-czf", "-", "-C", input.sourcePath, "."],
          { encoding: "buffer", maxBuffer: 64 * 1024 * 1024 },
        );
        execFileSync("tar", ["-xzf", "-", "-C", stagingRoot], {
          input: archive,
          maxBuffer: 64 * 1024 * 1024,
        });
        sourcePath = stagingRoot;
      }
      await input.runner.syncIn([
        {
          operationId: `runner-stage-dir-${randomUUID()}`,
          files: [
            {
              sourcePath,
              targetPath: input.targetPath,
              kind: "directory",
              mode: input.mode,
            },
          ],
        },
      ]);
    } finally {
      if (stagingRoot) rmSync(stagingRoot, { recursive: true, force: true });
    }
    return;
  }
  const archive = execFileSync(
    "tar",
    [...excludeArgs, "-czf", "-", "-C", input.sourcePath, "."],
    { encoding: "buffer", maxBuffer: 64 * 1024 * 1024 },
  );
  const escapedTarget = input.targetPath.replaceAll("'", "'\\''");
  const script =
    `umask 077; mkdir -p '${escapedTarget}' && ` +
    `base64 -d | tar -xzf - -C '${escapedTarget}' && ` +
    `chmod ${input.mode.toString(8)} '${escapedTarget}'`;
  const result = await input.runner.execute({
    command: "sh",
    args: ["-c", script],
    stdin: archive.toString("base64"),
    bypassSession: true,
    nativePreparationPurpose: input.nativePreparationPurpose,
  });
  if (result.exitCode !== 0 || result.timedOut) {
    throw new Error("runner_remote_directory_staging_failed");
  }
}

/**
 * Transfer trusted, build-owned artifacts through the existing bounded signed
 * exec relay. Each stdin is small enough for the relay's nested base64 request
 * envelope; the target and temporary path remain inside the task's private
 * runtime directory and RuntimeControl checks the exact command forms.
 */
async function stageRemoteArtifactBytesInChunks(input: {
  runner: CommandManagedRuntimeRunner;
  cwd: string;
  targetPath: string;
  mode: number;
  bytes: Buffer;
}): Promise<void> {
  const MAX_ARTIFACT_BYTES = 64 * 1024 * 1024;
  const CHUNK_BYTES = 256 * 1024;
  if (input.bytes.length === 0 || input.bytes.length > MAX_ARTIFACT_BYTES) {
    throw new Error("runner_remote_provider_artifact_incompatible: artifact size is outside the bounded relay transfer");
  }
  const quote = (value: string) => `'${value.replaceAll("'", "'\\''")}'`;
  const parent = posix.dirname(input.targetPath);
  const tempPath = `${input.targetPath}.paperclip-upload.${randomUUID()}`;
  const run = async (script: string, stdin = "") => {
    const result = await input.runner.execute({
      command: "sh",
      args: ["-c", script],
      cwd: input.cwd,
      stdin,
      bypassSession: true,
      nativePreparationPurpose: "provider_artifact",
    });
    if (result.exitCode !== 0 || result.timedOut) {
      throw new Error("runner_remote_provider_artifact_incompatible: bounded relay staging failed");
    }
  };
  await run(`umask 077; mkdir -p ${quote(parent)} && rm -f ${quote(tempPath)} && : > ${quote(tempPath)}`);
  for (let offset = 0; offset < input.bytes.length; offset += CHUNK_BYTES) {
    const chunk = input.bytes.subarray(offset, Math.min(input.bytes.length, offset + CHUNK_BYTES));
    const append = `current=$(wc -c < ${quote(tempPath)}); test "$current" -le ${MAX_ARTIFACT_BYTES} && test $((current + ${chunk.length})) -le ${MAX_ARTIFACT_BYTES} && base64 -d >> ${quote(tempPath)}`;
    await run(append, chunk.toString("base64"));
  }
  await run(`chmod ${input.mode.toString(8)} ${quote(tempPath)} && mv -f ${quote(tempPath)} ${quote(input.targetPath)}`);
}

export async function remoteRunnerPathExists(input: {
  runner: CommandManagedRuntimeRunner;
  path: string;
  kind: "file" | "directory";
  nativeHarnessState?: boolean;
}): Promise<boolean> {
  const escapedPath = input.path.replaceAll("'", "'\\''");
  const result = await input.runner.execute({
    command: "sh",
    args: ["-c", `test -${input.kind === "file" ? "f" : "d"} '${escapedPath}'`],
    bypassSession: true,
    timeoutMs: 10_000,
    ...(input.nativeHarnessState ? { nativePreparationPurpose: "native_harness_state" as const } : {}),
  });
  return result.exitCode === 0 && !result.timedOut;
}

function assertSafeRemoteCheckpointArchive(archive: Buffer): void {
  if (archive.length > MAX_REMOTE_CHECKPOINT_ARCHIVE_BYTES) {
    throw new Error("runner_remote_checkpoint_archive_too_large");
  }
  let names: string[];
  let verboseEntries: string[];
  try {
    names = execFileSync("tar", ["-tzf", "-"], {
      input: archive,
      encoding: "utf8",
      maxBuffer: 8 * 1024 * 1024,
      timeout: 30_000,
    })
      .split("\n")
      .filter((line) => line.length > 0);
    verboseEntries = execFileSync("tar", ["-tvzf", "-"], {
      input: archive,
      encoding: "utf8",
      maxBuffer: 8 * 1024 * 1024,
      timeout: 30_000,
    })
      .split("\n")
      .filter((line) => line.length > 0);
  } catch {
    throw new Error("runner_remote_checkpoint_archive_invalid");
  }
  if (
    names.length === 0 ||
    names.length > MAX_REMOTE_CHECKPOINT_ENTRIES ||
    verboseEntries.length !== names.length
  ) {
    throw new Error("runner_remote_checkpoint_archive_invalid");
  }
  for (const name of names) {
    const normalized = name.replace(/^\.\//, "");
    if (
      name.includes("\0") ||
      name.startsWith("/") ||
      normalized.split("/").some((part) => part === "..")
    ) {
      throw new Error("runner_remote_checkpoint_archive_unsafe_path");
    }
  }
  for (const entry of verboseEntries) {
    const type = entry.trimStart()[0];
    if (type !== "-" && type !== "d") {
      throw new Error("runner_remote_checkpoint_archive_unsafe_entry");
    }
  }
  try {
    execFileSync("tar", ["-xOzf", "-"], {
      input: archive,
      stdio: ["pipe", "pipe", "pipe"],
      maxBuffer: MAX_REMOTE_CHECKPOINT_EXPANDED_BYTES,
      timeout: 60_000,
    });
  } catch {
    throw new Error("runner_remote_checkpoint_archive_expanded_too_large");
  }
}

function assertSafeExtractedCheckpoint(root: string): void {
  const pending = [root];
  let entries = 0;
  let totalBytes = 0;
  while (pending.length > 0) {
    const directory = pending.pop()!;
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      entries += 1;
      if (entries > MAX_REMOTE_CHECKPOINT_ENTRIES) {
        throw new Error("runner_remote_checkpoint_too_many_entries");
      }
      const path = join(directory, entry.name);
      const metadata = lstatSync(path);
      if (
        metadata.isSymbolicLink() ||
        (!metadata.isDirectory() && !metadata.isFile())
      ) {
        throw new Error("runner_remote_checkpoint_unsafe_entry");
      }
      if (metadata.isDirectory()) {
        pending.push(path);
      } else {
        totalBytes += metadata.size;
        if (totalBytes > MAX_REMOTE_CHECKPOINT_EXPANDED_BYTES) {
          throw new Error("runner_remote_checkpoint_expanded_too_large");
        }
      }
    }
  }
}

/**
 * Copy a remote runner directory into durable local state.
 *
 * Some provider homes contain process-local scratch trees (for example Codex's
 * `tmp/arg0` executable aliases). Those aliases can point outside the directory
 * and are neither portable nor required to resume a provider session. When a
 * provider supplies a native syncOut implementation, create a sibling snapshot
 * first so the live runtime remains untouched and the provider's archive safety
 * checks still apply to every persisted entry.
 */
export async function syncRemoteRunnerDirectoryOut(input: {
  runner: CommandManagedRuntimeRunner;
  sourcePath: string;
  targetPath: string;
  mode: number;
  excludeEntries?: readonly string[];
  nativeHarnessState?: boolean;
}): Promise<void> {
  if (
    !(await remoteRunnerPathExists({
      runner: input.runner,
      path: input.sourcePath,
      kind: "directory",
      nativeHarnessState: input.nativeHarnessState,
    }))
  )
    return;
  mkdirSync(resolve(input.targetPath, ".."), { recursive: true, mode: 0o700 });
  const excluded = input.excludeEntries ?? [];
  const excludeArgs = archiveExcludeArgs(excluded)
    .map((argument) => `'${argument}'`)
    .join(" ");
  if (input.runner.syncOut) {
    let syncSourcePath = input.sourcePath;
    let snapshotPath: string | null = null;
    if (excluded.length > 0) {
      const checkpointId = randomUUID();
      snapshotPath = posix.join(
        posix.dirname(input.sourcePath),
        `.paperclip-checkpoint-${checkpointId}`,
      );
      const archivePath = `${snapshotPath}.tar`;
      const escapedSource = input.sourcePath.replaceAll("'", "'\\''");
      const escapedSnapshot = snapshotPath.replaceAll("'", "'\\''");
      const escapedArchive = archivePath.replaceAll("'", "'\\''");
      const snapshotResult = await input.runner.execute({
        command: "sh",
        args: [
          "-c",
          `set -e; umask 077; mkdir -p '${escapedSnapshot}'; ` +
            `trap "rm -f '${escapedArchive}'" EXIT; ` +
            `tar ${excludeArgs} -cf '${escapedArchive}' -C '${escapedSource}' .; ` +
            `tar -xf '${escapedArchive}' -C '${escapedSnapshot}'`,
        ],
        bypassSession: true,
        timeoutMs: 120_000,
        ...(input.nativeHarnessState ? { nativePreparationPurpose: "native_harness_state" as const } : {}),
      });
      if (snapshotResult.exitCode !== 0 || snapshotResult.timedOut) {
        throw new Error("runner_remote_checkpoint_snapshot_failed");
      }
      syncSourcePath = snapshotPath;
    }
    try {
      await input.runner.syncOut([
        {
          operationId: `runner-checkpoint-dir-${randomUUID()}`,
          files: [
            {
              sourcePath: syncSourcePath,
              targetPath: input.targetPath,
              kind: "directory",
              mode: input.mode,
            },
          ],
        },
      ]);
    } finally {
      if (snapshotPath) {
        const escapedSnapshot = snapshotPath.replaceAll("'", "'\\''");
        await input.runner
          .execute({
            command: "sh",
            args: ["-c", `rm -rf -- '${escapedSnapshot}'`],
            bypassSession: true,
            timeoutMs: 30_000,
            ...(input.nativeHarnessState ? { nativePreparationPurpose: "native_harness_state" as const } : {}),
          })
          .catch(() => undefined);
      }
    }
    return;
  }
  const escapedSource = input.sourcePath.replaceAll("'", "'\\''");
  const exclusionPrefix = excludeArgs.length > 0 ? `${excludeArgs} ` : "";
  const result = await input.runner.execute({
    command: "sh",
    args: ["-c", `tar ${exclusionPrefix}-czf - -C '${escapedSource}' . | base64`],
    bypassSession: true,
    timeoutMs: 120_000,
    ...(input.nativeHarnessState ? { nativePreparationPurpose: "native_harness_state" as const } : {}),
  });
  if (result.exitCode !== 0 || result.timedOut) {
    throw new Error("runner_remote_checkpoint_failed");
  }
  const archive = Buffer.from(result.stdout.replace(/\s+/g, ""), "base64");
  assertSafeRemoteCheckpointArchive(archive);
  const parent = resolve(input.targetPath, "..");
  const stagingRoot = mkdtempSync(join(parent, ".paperclip-checkpoint-"));
  const stagedTarget = join(stagingRoot, "payload");
  const previousTarget = join(
    parent,
    `.paperclip-checkpoint-previous-${randomUUID()}`,
  );
  let previousMoved = false;
  let replacementInstalled = false;
  try {
    mkdirSync(stagedTarget, { recursive: true, mode: input.mode });
    execFileSync(
      "tar",
      [
        "--no-same-owner",
        "--no-same-permissions",
        "-xzf",
        "-",
        "-C",
        stagedTarget,
      ],
      { input: archive, maxBuffer: 8 * 1024 * 1024, timeout: 60_000 },
    );
    assertSafeExtractedCheckpoint(stagedTarget);
    chmodSync(stagedTarget, input.mode);
    if (existsSync(input.targetPath)) {
      renameSync(input.targetPath, previousTarget);
      previousMoved = true;
    }
    renameSync(stagedTarget, input.targetPath);
    replacementInstalled = true;
    if (previousMoved) {
      rmSync(previousTarget, { recursive: true, force: true });
      previousMoved = false;
    }
  } catch (error) {
    if (
      previousMoved &&
      !replacementInstalled &&
      !existsSync(input.targetPath)
    ) {
      try {
        renameSync(previousTarget, input.targetPath);
        previousMoved = false;
      } catch {
        // Leave the last durable checkpoint at previousTarget. Deleting it in
        // finally would turn a failed replacement into irreversible data loss.
      }
    }
    throw error;
  } finally {
    if (previousMoved && replacementInstalled) {
      rmSync(previousTarget, { recursive: true, force: true });
    }
    rmSync(stagingRoot, { recursive: true, force: true });
  }
}

async function readRemoteRunnerState(input: {
  runner: CommandManagedRuntimeRunner;
  stateDirectory: string;
  nativeHarnessState?: boolean;
}): Promise<Record<string, unknown>> {
  const statePath = posix.join(input.stateDirectory, "runner-state.json");
  const escapedPath = statePath.replaceAll("'", "'\\''");
  const result = await input.runner.execute({
    command: "sh",
    args: ["-c", `test -f '${escapedPath}' && base64 < '${escapedPath}'`],
    bypassSession: true,
    timeoutMs: 10_000,
    ...(input.nativeHarnessState ? { nativePreparationPurpose: "native_harness_state" as const } : {}),
  });
  if (result.exitCode !== 0 || result.timedOut) {
    throw new Error(
      `runner_remote_state_unavailable: exit=${result.exitCode} timedOut=${result.timedOut}${result.stderr.trim() ? ` ${redactSensitiveText(result.stderr).trim().slice(-512)}` : ""}`,
    );
  }
  return record(
    JSON.parse(
      Buffer.from(result.stdout.replace(/\s+/g, ""), "base64").toString("utf8"),
    ),
  );
}

async function readRemoteRunnerProviderState(input: {
  runner: CommandManagedRuntimeRunner;
  stateDirectory: string;
  execution: NativeExecutionInput;
  nativeHarnessState?: boolean;
}): Promise<Record<string, unknown>> {
  const statePath = posix.join(
    input.stateDirectory,
    runnerProviderStateFilename(input.execution),
  );
  const escapedPath = statePath.replaceAll("'", "'\\''");
  const result = await input.runner.execute({
    command: "sh",
    args: ["-c", `test -f '${escapedPath}' && base64 < '${escapedPath}'`],
    bypassSession: true,
    timeoutMs: 10_000,
    ...(input.nativeHarnessState ? { nativePreparationPurpose: "native_harness_state" as const } : {}),
  });
  if (result.exitCode !== 0 || result.timedOut) {
    throw new Error("runner_remote_provider_state_unavailable");
  }
  return record(
    JSON.parse(
      Buffer.from(result.stdout.replace(/\s+/g, ""), "base64").toString("utf8"),
    ),
  );
}

const REMOTE_RUNNER_PROCESS_IDENTITY_WAIT_MS = 20_000;
const REMOTE_RUNNER_PROCESS_POLL_MS = 1_000;

export function parseRemoteRunnerProcessIdentity(
  value: string,
  expected: { nonce: string; runnerInstanceId: string },
): { pid: number; startedAt: string; processStartFingerprint?: string } | null {
  const [nonce, rawPid, startedAt, runnerInstanceId, processStartFingerprint, ...remainder] = value
    .trim()
    .split("\n");
  const pid = Number(rawPid);
  if (
    remainder.length > 0 ||
    nonce !== expected.nonce ||
    runnerInstanceId !== expected.runnerInstanceId ||
    !Number.isSafeInteger(pid) ||
    pid <= 0 ||
    !startedAt ||
    Number.isNaN(new Date(startedAt).getTime()) ||
    (processStartFingerprint !== undefined && !/^linux:[0-9a-f-]+:[0-9]+$/.test(processStartFingerprint))
  ) {
    return null;
  }
  return { pid, startedAt, ...(processStartFingerprint ? { processStartFingerprint } : {}) };
}

/** Verify remote ownership before exposing the transport's authenticated adoption path. */
export async function verifyRemoteRunnerReattachment(input: {
  claim: Extract<
    NativeRestartRecoveryClaim,
    { kind: "reattach_remote_runner" }
  >;
  target: AdapterExecutionTarget | null | undefined;
  identity: Record<string, unknown>;
  runId: string;
  normalizedSessionId: string;
  nativeHarnessState?: boolean;
}) {
  const { claim, target, identity } = input;
  if (
    target?.kind !== "remote" ||
    target.transport !== "sandbox" ||
    !target.runner ||
    claim.runId !== input.runId ||
    identity.runId !== input.runId ||
    identity.normalizedSessionId !== input.normalizedSessionId ||
    claim.remote.providerLeaseId !==
      target.sandboxLeaseAcquisition?.providerLeaseId ||
    target.sandboxLeaseAcquisition.outcome === "replacement" ||
    claim.remote.remoteCwd !== target.remoteCwd
  ) {
    throw new Error("native_remote_recovery_lease_mismatch");
  }
  const runner = target.runner;
  const stateDirectory = posix.join(
    target.remoteCwd,
    ".paperclip-runtime",
    "paperclip-runner",
    "sessions",
    createHash("sha256").update(input.normalizedSessionId).digest("hex"),
    "runner",
  );
  const runnerState = await readRemoteRunnerState({ runner, stateDirectory, nativeHarnessState: input.nativeHarnessState });
  for (const field of [
    "runId",
    "normalizedSessionId",
    "runnerInstanceId",
    "environmentLeaseId",
    "turnId",
    "itemId",
  ]) {
    if (
      typeof identity[field] !== "string" ||
      !identity[field] ||
      runnerState[field] !== identity[field]
    ) {
      throw new Error("runner_remote_recovery_identity_mismatch");
    }
  }
  const identityPath = posix.join(stateDirectory, "runner-process.identity");
  const marker = await runner.execute({
    command: "sh",
    args: [
      "-c",
      'test -f "$1" && test ! -L "$1" && cat -- "$1"',
      "paperclip-runner-recovery-identity",
      identityPath,
    ],
    bypassSession: true,
    timeoutMs: 10_000,
    ...(input.nativeHarnessState ? { nativePreparationPurpose: "native_harness_state" as const } : {}),
  });
  const nonce = marker.stdout.split("\n")[0] ?? "";
  const runnerInstanceId = identity.runnerInstanceId as string;
  const processIdentity =
    marker.exitCode === 0 && !marker.timedOut && /^[a-zA-Z0-9_-]+$/.test(nonce)
      ? parseRemoteRunnerProcessIdentity(marker.stdout, {
          nonce,
          runnerInstanceId,
        })
      : null;
  if (!processIdentity?.processStartFingerprint)
    throw new Error("runner_remote_process_identity_unavailable");
  const expectedStartFingerprint = processIdentity.processStartFingerprint;
  const check = async (signal?: NodeJS.Signals) => {
    const result = await runner.execute({
      command: "sh",
      args: [
        "-c",
        `${REMOTE_RUNNER_IDENTITY_CHECK_SCRIPT}; ${REMOTE_RUNNER_PROCESS_FINGERPRINT_SCRIPT}; test "$process_fingerprint" = "$5" || exit 4` +
          (signal ? '; kill -"$6" "$pid"' : ""),
        "paperclip-runner-recovery-check",
        identityPath,
        nonce,
        runnerInstanceId,
        String(processIdentity.pid),
        expectedStartFingerprint,
        ...(signal ? [signal.slice(3)] : []),
      ],
      bypassSession: true,
      timeoutMs: 10_000,
      ...(input.nativeHarnessState ? { nativePreparationPurpose: "native_harness_state" as const } : {}),
    });
    return result.exitCode === 0 && !result.timedOut;
  };
  if (!(await check()))
    throw new Error("runner_remote_process_identity_unavailable");
  // These checks authorize an attempt to reconnect, not the task itself. The
  // transport still requires authentication against the exact durable PRP key.
  return {
    ...processIdentity,
    processGroupId: null,
    isAlive: () => check(),
    signal: check,
  };
}

async function waitForRemoteRunnerProcessIdentity(input: {
  runner: CommandManagedRuntimeRunner;
  identityPath: string;
  nonce: string;
  runnerInstanceId: string;
  nativeHarnessState?: boolean;
}): Promise<{ pid: number; startedAt: string; processStartFingerprint?: string }> {
  const deadline = Date.now() + REMOTE_RUNNER_PROCESS_IDENTITY_WAIT_MS;
  while (Date.now() < deadline) {
    const result = await input.runner
      .execute({
        command: "sh",
        args: [
          "-c",
          'test -f "$1" && test ! -L "$1" && cat -- "$1"',
          "paperclip-runner-process-identity",
          input.identityPath,
        ],
        bypassSession: true,
        timeoutMs: 2_000,
        ...(input.nativeHarnessState ? { nativePreparationPurpose: "native_harness_state" as const } : {}),
      })
      .catch(() => null);
    const identity =
      result && result.exitCode === 0 && !result.timedOut
        ? parseRemoteRunnerProcessIdentity(result.stdout, input)
        : null;
    if (identity) return identity;
    await new Promise<void>((resolve) => setTimeout(resolve, 100));
  }
  throw new Error("runner_remote_process_identity_unavailable");
}

async function cleanupRemoteRunnerAfterIdentityFailure(input: {
  runner: CommandManagedRuntimeRunner;
  identityPath: string;
  nonce: string;
  runnerInstanceId: string;
  nativeHarnessState?: boolean;
}): Promise<boolean> {
  const result = await input.runner
    .execute({
      command: "sh",
      args: [
        "-c",
        REMOTE_RUNNER_FAILED_IDENTITY_CLEANUP_SCRIPT,
        "paperclip-runner-identity-failure-cleanup",
        input.identityPath,
        input.nonce,
        input.runnerInstanceId,
        REMOTE_RUNNER_IDENTITY_CHECK_SCRIPT,
      ],
      bypassSession: true,
      timeoutMs: 20_000,
      ...(input.nativeHarnessState ? { nativePreparationPurpose: "native_harness_state" as const } : {}),
    })
    .catch(() => null);
  return result?.exitCode === 0 && result.timedOut === false;
}

export function createRemoteRunnerProcessLauncher(input: {
  target: Extract<AdapterExecutionTarget, { kind: "remote" }>;
  runner: CommandManagedRuntimeRunner;
  /** Exact server-selected conversation OpenCode startup phase, never user supplied. */
  nativeSessionStart?: boolean;
  /** Server-selected managed OpenCode session provider lifecycle, never user supplied. */
  managedModelSession?: boolean;
  /** Exact read-only Runner state owner; never user or model supplied. */
  nativeHarnessState?: boolean;
  remoteBinary: string;
  processIdentityPath: string;
  stateDirectory: string;
  diagnosticsDirectory: string;
  runnerInstanceId: string;
  ensureArtifact?: () => Promise<void>;
  onSpawn?: (meta: {
    pid: number;
    processGroupId: number | null;
    startedAt: string;
    identitySource?: "remote_marker";
    remoteRunnerInstanceId?: string;
  }) => Promise<void>;
  onLog?: (stream: "stdout" | "stderr", chunk: string) => Promise<void>;
  trace?: NativeRunTrace;
  onRunnerProcessSpawned?: () => void;
}): (spec: RunnerProcessLaunchSpec) => RunnerProcessHandle {
  const runner = input.runner;
  return (spec) => {
    let launchedIdentity: {
      nonce: string;
      pid: number;
      startedAt: string;
    } | null = null;
    const child: RunnerProcessHandle["child"] = {
      pid: undefined,
      exitCode: null,
      signalCode: null,
      kill: (requestedSignal) => {
        const identity = launchedIdentity;
        if (!identity) return false;
        const signal =
          requestedSignal === "SIGKILL" || requestedSignal === 9
            ? "KILL"
            : requestedSignal === "SIGINT" || requestedSignal === 2
              ? "INT"
              : "TERM";
        // The durable marker, nonce, exact pid, and runner-id command line are
        // revalidated in the sandbox immediately before signalling. A recycled
        // pid or replaced marker therefore fails closed instead of killing an
        // unrelated process.
        void runner.execute({
          command: "sh",
          args: [
            "-c",
            `${REMOTE_RUNNER_IDENTITY_CHECK_SCRIPT}; kill -${signal} "$expected_pid"`,
            "paperclip-runner-signal",
            input.processIdentityPath,
            identity.nonce,
            input.runnerInstanceId,
            String(identity.pid),
            "require-fingerprint",
          ],
          bypassSession: true,
          timeoutMs: 10_000,
          ...(input.nativeHarnessState ? { nativePreparationPurpose: "native_harness_state" as const } : {}),
        }).catch(async () => {
          // kill() follows Node's synchronous child-process contract. A deleted
          // sandbox or failed signal RPC must not reject outside that boundary
          // and crash the controller. This is not a termination receipt: the
          // monitor and cleanup verification still decide whether work stopped.
          await input.onLog?.(
            "stderr",
            "Remote runner signal failed; process termination is not confirmed.\n",
          );
        }).catch(() => undefined);
        return true;
      },
    };
    const completion = (async () => {
      if (input.ensureArtifact) {
        if (input.trace) {
          await input.trace.measure(
            "runner.runtime.stage",
            input.ensureArtifact,
            { parentName: "runner.session.startup" },
          );
        } else {
          await input.ensureArtifact();
        }
      }
      const launchStartedAtMs = Date.now();
      // The provider's onSpawn callback is optional and some sandbox command
      // runners cannot report a remote pid until after the command has begun
      // streaming. Signal as soon as staging is complete and the launch RPC is
      // dispatched; this is late enough to avoid preview retries during staging
      // and early enough to avoid a callback-dependent deadlock.
      input.onRunnerProcessSpawned?.();
      await input.trace?.record({
        name: "runner.process.dispatch",
        parentName: "runner.session.startup",
        startedAtMs: launchStartedAtMs,
        endedAtMs: Date.now(),
        attributes: { target: "remote" },
      });
      const identityNonce = randomUUID();
      const remoteArgs = [...spec.args];
      const diagnosticsArgumentIndex = remoteArgs.indexOf(
        "--diagnostics-directory",
      );
      if (diagnosticsArgumentIndex >= 0) {
        remoteArgs[diagnosticsArgumentIndex + 1] = input.diagnosticsDirectory;
      } else {
        remoteArgs.push("--diagnostics-directory", input.diagnosticsDirectory);
      }
      // Do not keep runnerd as the foreground command of a provider RPC. Some
      // sandbox command/session transports impose a provider-side lifetime on
      // that RPC even when Paperclip requests a longer timeout. Detach runnerd
      // into its own session instead; its own bounded diagnostics directory and
      // durable PRP state remain the authorities, and the controller monitors
      // the exact persisted process identity below.
      const launchResult = await runner.execute({
        command: "sh",
        args: [
          "-c",
          'set -eu; identity_path=$1; identity_nonce=$2; runner_instance_id=$3; child_script=$4; shift 4; umask 077; identity_dir=$(dirname -- "$identity_path"); mkdir -p -- "$identity_dir"; if command -v setsid >/dev/null 2>&1; then nohup setsid sh -c "$child_script" paperclip-runner-child "$identity_path" "$identity_nonce" "$runner_instance_id" "$@" </dev/null >/dev/null 2>&1 & else nohup sh -c "$child_script" paperclip-runner-child "$identity_path" "$identity_nonce" "$runner_instance_id" "$@" </dev/null >/dev/null 2>&1 & fi',
          "paperclip-runner-launch",
          input.processIdentityPath,
          identityNonce,
          input.runnerInstanceId,
          REMOTE_RUNNER_CHILD_LAUNCH_SCRIPT,
          input.diagnosticsDirectory,
          input.remoteBinary,
          ...remoteArgs,
        ],
        cwd: input.target.remoteCwd,
        env: sandboxRunnerProcessEnvironment(spec.environment),
        timeoutMs: 20_000,
        bypassSession: true,
        ...(input.nativeSessionStart ? { nativePreparationPurpose: "native_session_start" as const } : {}),
        ...(input.managedModelSession ? { modelBrokerSessionPhase: "start" as const } : {}),
        onLog: input.onLog,
      });
      if (launchResult.exitCode !== 0 || launchResult.timedOut) {
        throw new Error(
          launchResult.timedOut
            ? "runner_remote_process_launch_timed_out"
            : "runner_remote_process_launch_failed",
        );
      }
      let identity: { pid: number; startedAt: string; processStartFingerprint?: string };
      try {
        identity = await waitForRemoteRunnerProcessIdentity({
          runner,
          identityPath: input.processIdentityPath,
          nonce: identityNonce,
          runnerInstanceId: input.runnerInstanceId,
          nativeHarnessState: input.nativeHarnessState,
        });
      } catch {
        const cleanupStartedAtMs = Date.now();
        const cleaned = await cleanupRemoteRunnerAfterIdentityFailure({
          runner,
          identityPath: input.processIdentityPath,
          nonce: identityNonce,
          runnerInstanceId: input.runnerInstanceId,
          nativeHarnessState: input.nativeHarnessState,
        });
        await input.trace?.record({
          name: "runner.process.identity_failure_cleanup",
          parentName: "runner.session.startup",
          startedAtMs: cleanupStartedAtMs,
          endedAtMs: Date.now(),
          attributes: { cleaned },
        });
        if (!cleaned) {
          throw new Error(
            "runner_remote_process_identity_unavailable_cleanup_failed",
          );
        }
        throw new Error("runner_remote_process_identity_unavailable");
      }
      launchedIdentity = { nonce: identityNonce, ...identity };
      child.pid = identity.pid;
      await input.onSpawn?.({
        pid: identity.pid,
        processGroupId: null,
        startedAt: identity.startedAt,
        identitySource: "remote_marker",
        remoteRunnerInstanceId: input.runnerInstanceId,
      });
      await input.trace?.record({
        name: "runner.process.launch",
        parentName: "runner.session.startup",
        startedAtMs: launchStartedAtMs,
        endedAtMs: Date.now(),
        attributes: { identitySource: "remote_marker", detached: true },
      });

      let statusObservationFailures = 0;
      while (true) {
        let observed: Awaited<ReturnType<CommandManagedRuntimeRunner["execute"]>>;
        try {
          observed = await runner.execute({
            command: "sh",
            args: [
              "-c",
              REMOTE_RUNNER_IDENTITY_CHECK_SCRIPT,
              "paperclip-runner-monitor",
              input.processIdentityPath,
              identityNonce,
              input.runnerInstanceId,
              String(identity.pid),
            ],
            bypassSession: true,
            timeoutMs: 10_000,
            ...(input.nativeHarnessState ? { nativePreparationPurpose: "native_harness_state" as const } : {}),
            ...(input.managedModelSession ? { modelBrokerSessionPhase: "refresh" as const } : {}),
          });
        } catch (error) {
          if (!input.nativeHarnessState || !(error instanceof Error) ||
            error.message !== "runner_process_status_unavailable" || statusObservationFailures >= 3) throw error;
          statusObservationFailures++;
          await new Promise<void>(resolve => setTimeout(resolve, REMOTE_RUNNER_PROCESS_POLL_MS));
          continue;
        }
        statusObservationFailures = 0;
        if (observed.exitCode === 0 && !observed.timedOut) {
          await new Promise<void>((resolve) =>
            setTimeout(resolve, REMOTE_RUNNER_PROCESS_POLL_MS),
          );
          continue;
        }
        child.exitCode = null;
        const identityMismatch = observed.exitCode === 4;
        if (input.managedModelSession && !identityMismatch) {
          const stopped = await runner.execute({
            command: "sh",
            args: ["-c", REMOTE_RUNNER_IDENTITY_CHECK_SCRIPT, "paperclip-runner-monitor", input.processIdentityPath,
              identityNonce, input.runnerInstanceId, String(identity.pid)],
            bypassSession: true,
            timeoutMs: 10_000,
            ...(input.nativeHarnessState ? { nativePreparationPurpose: "native_harness_state" as const } : {}),
            modelBrokerSessionPhase: "stop",
          });
          if (stopped.exitCode === 0 || stopped.timedOut)
            throw new Error("runner_model_provider_session_stop_unconfirmed");
        }
        const diagnostic = await runner
          .execute({
            command: "sh",
            args: [
              "-c",
              'set -eu; directory=$1; file="$directory/runnerd.stderr.log"; test -d "$directory" && test ! -L "$directory" && test -f "$file" && test ! -L "$file"; tail -c 65536 -- "$file"',
              "paperclip-runner-diagnostics",
              input.diagnosticsDirectory,
            ],
            bypassSession: true,
            timeoutMs: 10_000,
            ...(input.nativeHarnessState ? { nativePreparationPurpose: "native_harness_state" as const } : {}),
          })
          .catch(() => null);
        const diagnosticTail =
          diagnostic && diagnostic.exitCode === 0 && !diagnostic.timedOut
            ? redactSensitiveText(diagnostic.stdout).slice(-16_384).trim()
            : "";
        const durableState = await readRemoteRunnerState({
          runner,
          stateDirectory: input.stateDirectory,
          nativeHarnessState: input.nativeHarnessState,
        }).catch(() => null);
        const lifecycle =
          typeof durableState?.lifecycle === "string"
            ? durableState.lifecycle
            : "unavailable";
        const recoverableFailure =
          typeof durableState?.recoverableFailure === "string"
            ? durableState.recoverableFailure
            : typeof durableState?.recoverable_failure === "string"
              ? durableState.recoverable_failure
              : null;
        const stateDiagnostics = Array.isArray(durableState?.diagnostics)
          ? durableState.diagnostics
              .filter((value): value is string => typeof value === "string")
              .slice(-4)
              .map((value) => redactSensitiveText(value).slice(-1_000))
          : [];
        if (process.env.PAPERCLIP_MANAGED_OPENCODE_E2E_DIAGNOSTICS === "1") {
          const recoveryReasons: ReadonlySet<string> = new Set([
            "transport_reconnect_grace_exceeded",
            "transport_reconnect_deadline_exceeded",
            "lease_expired_requires_bootstrap",
          ]);
          const knownLifecycles: readonly string[] = [
            "connecting", "ready", "terminal", "backpressure", "draining", "revoked", "stopped",
            "recoverable_failure", "unrecoverable",
          ];
          const knownFailureMarkers = [
            ["transport reconnect grace exceeded; durable state is preserved", "transport_reconnect_grace_exceeded"],
            ["transport reconnect deadline elapsed; durable state is preserved", "transport_reconnect_deadline_exceeded"],
            ["connection lease expired; a fresh bootstrap is required", "lease_expired_requires_bootstrap"],
            ["active connection lease expired", "active_connection_lease_expired"],
          ] as const;
          const classify = (value: string) => knownFailureMarkers
            .find(([marker]) => value.includes(marker))?.[1] ?? null;
          const ownerFrames = (new Error().stack?.split("\n").slice(1, 6) ?? [])
            .flatMap((line) => {
              const match = /^\s*at (?:(.*?) \()?(.+?):(\d+):\d+\)?$/.exec(line);
              return match && /^[-\w.]+\.(?:ts|js|mjs|cjs)$/.test(match[2]!.split(/[\\/]/).at(-1)!)
                ? [{ functionName: match[1] || null, sourceFile: match[2]!.split(/[\\/]/).at(-1), line: Number(match[3]) }]
                : [];
            }).slice(0, 4);
          console.info("native remote runner exit facts", JSON.stringify({
            runnerInstanceId: input.runnerInstanceId,
            pid: identity.pid,
            phase: input.nativeSessionStart ? "native_session_start" : "remote_process_monitor",
            ownerFrames,
            processStartFingerprintRecorded: Boolean(identity.processStartFingerprint),
            monitorExitCode: observed.exitCode,
            monitorTimedOut: observed.timedOut,
            monitorSignal: observed.signal,
            identityMismatch,
            remoteProcessSignal: child.signalCode ?? null,
            signalObservation: "remote_identity_probe_does_not_report_process_signal",
            lifecycle: knownLifecycles.includes(lifecycle) ? lifecycle : "unavailable",
            durableStateAvailable: Boolean(durableState),
            runnerDiagnosticAvailable: diagnostic?.exitCode === 0 && !diagnostic.timedOut,
            recoverableFailure: typeof recoverableFailure === "string" && recoveryReasons.has(recoverableFailure)
              ? recoverableFailure : null,
            stderrFailureMarker: classify(diagnosticTail),
            stateFailureMarkers: stateDiagnostics.flatMap((value) => {
              const marker = classify(value);
              return marker ? [marker] : [];
            }),
          }));
        }
        const stateSummary = `runner_remote_process_exited lifecycle=${lifecycle}${recoverableFailure ? ` recoverableFailure=${redactSensitiveText(recoverableFailure).slice(-1_000)}` : ""}${stateDiagnostics.length > 0 ? ` diagnostics=${JSON.stringify(stateDiagnostics)}` : ""}`;
        return {
          code: null,
          signal: null,
          stdout: "",
          stderr: identityMismatch
            ? "runner_remote_process_identity_mismatch"
            : diagnosticTail || stateSummary,
        };
      }
    })();
    return { child, completion };
  };
}

/**
 * Select the remote runner transport before any artifact is staged or provider
 * endpoint is acquired. Sandbox ingress is available only to a run already
 * authorized by native runtime selection.
 */
export function resolveRemoteRunnerTransportMode(input: {
  target: AdapterExecutionTarget;
  runnerIngressAuthorized: boolean;
}): "listen_ws" | "dial_wss" {
  if (input.target.kind !== "remote") {
    throw new Error("runner_transport_ineligible: remote target is required");
  }
  const requiredMode =
    input.target.transport === "sandbox" &&
    input.target.effectiveCapabilities?.runnerWebSocketIngress === true
      ? "listen_ws"
      : "dial_wss";
  if (requiredMode === "listen_ws" && !input.runnerIngressAuthorized) {
    throw new Error("runner_ingress_unavailable");
  }
  return requiredMode;
}

export function remoteCheckpointIncompleteFailure(
  settlement: "settled" | "unsettled",
  incompleteReason: "unavailable" | "not_suspended" | null,
): Error | null {
  // A transport that never completed provider bootstrap has no provider state
  // to preserve; its original launch failure remains authoritative. Once
  // runnerd has proved suspension, however, an unreadable or incomplete
  // checkpoint must fail the required close so outer sandbox release is
  // withheld. Process containment still happens in the transport finally.
  if (settlement === "unsettled") return null;
  return new Error(
    `runner_remote_checkpoint_incomplete: exact suspended harness state unavailable (${incompleteReason ?? "unknown"})`,
  );
}

/** Production runnerd backend seam, exported so provider wiring can be regression tested. */
export async function createRunnerdBackend(input: {
  db: Db;
  execution: NativeExecutionInput;
  /** Trusted Heartbeat-owned route-created conversation owner context. */
  conversationMode?: boolean;
  nativeBootstrapExecutionInputHash?: string;
  bootstrapSourceClosure?: NativeBootstrapSourceClosure | null;
  runnerInstanceId: string;
  chatAttachmentReadScope?: NativeChatAttachmentReadScope;
  restartRecovery?: NativeRestartRecoveryClaim;
  durableEnvironmentLeaseId?: string;
  nativeModelOutputCapture?: { readonly value: NativeModelOutputCapture | null };
  testBeforeManagedProjectCreate?: (capture: NativeModelOutputCapture) => Promise<void>;
  testAfterManagedProjectCreate?: (input: { actor: AuthorizationActor; companyId: string; issueId: string; capture: NativeModelOutputCapture; callId: string;
    arguments: Record<string, unknown>; result: { project: Record<string, unknown>; receipt: NativeProjectCreateReceipt;
      sourceSet: NativePayloadSourceSet } }) => Promise<void>;
  managedNativeContextReadCapture?: { value: NativeContextReadBinding | null };
  onSpawn?: (meta: {
    pid: number;
    processGroupId: number | null;
    startedAt: string;
    identitySource?: "remote_marker";
    remoteRunnerInstanceId?: string;
  }) => Promise<void>;
  runnerEnvironment?: NodeJS.ProcessEnv;
  /** Private grant materialization; never a user-configured host path. */
  managedAiCredentialHome?: string;
  runnerExecutionTarget?: AdapterExecutionTarget | null;
  /** Resolved per-run authorization; not an independent instance setting. */
  runnerIngressAuthorized?: boolean;
  runnerPublicUrl?: string | null;
  runnerCaBundlePath?: string | null;
  runnerRemoteBinaryPath?: string | null;
  runnerRemoteCodexPath?: string | null;
  runnerRemoteCodexNpmSpec?: string | null;
  runnerRemoteProviderPackPath?: string | null;
  trace?: NativeRunTrace;
  toolTrace?: NativeToolTrace;
  serializeManagedOperation?: <T>(operation: () => Promise<T>) => Promise<T>;
  onDocumentRead?: (source: NativeDocumentToolResultSource) => Promise<void>;
  onProjectToolResult?: (source: NativeProjectToolResultSource) => Promise<void>;
  onNativeInputToolResult?: (source: NativeInputToolResultSource) => Promise<void>;
  onNativeToolCall?: (call: { tool: string; callId: string; turnId: string; argumentsHash: string; arguments: unknown }) => Promise<void>;
  onManagedOpenCodeToolResult?: (call: { tool: "read_document" | "write_document" | "create_task" | "create_project" | "self_remember" | "read_context" | "call_api" | "get_task_context" | "get_task_history" | "read_chat_attachment" | "query_business_metric"; callId: string; turnId: string; argumentsHash: string; result: unknown; contextRead?: NativeContextReadBinding; projectRead?: NativeProjectToolResultSource; projectCreate?: NativeManagedProjectCreateCapture }) => Promise<void>;
  onLog?: (stream: "stdout" | "stderr", chunk: string) => Promise<void>;
  stopTaskForReassignment?: (target: { companyId: string; issueId: string; agentId: string; runId: string | null }) => Promise<void>;
  enqueueWakeup?: (
    agentId: string,
    options: {
      source: "assignment";
      triggerDetail: "system";
      reason: "issue_assigned";
      payload: Record<string, unknown>;
      idempotencyKey: string;
      requestedByActorType: "agent";
      requestedByActorId: string;
      contextSnapshot: Record<string, unknown>;
    },
  ) => Promise<unknown>;
}): Promise<NativeSessionBackend & { bindManagedSession(session: NativeSession): NativeSession }> {
  const sessionScopeId = nativeSessionScopeKey(input.execution);
  const scopeOwner = executingRunnerdSessionScopes.get(sessionScopeId);
  if (scopeOwner && scopeOwner !== input.execution.binding.runId) {
    throw new Error("native_session_supervisor_busy");
  }
  if (initializingSessionToolAuthorities.has(sessionScopeId)) {
    throw new Error("native_session_supervisor_busy");
  }
  initializingSessionToolAuthorities.add(sessionScopeId);
  try {
    let retainedTransition: VerifiedWarmTransitionBinding | undefined;
    // executePaperclipNativeSession holds the full session-scope claim and
    // verifies/migrates the durable root before it acquires the coordinator
    // lease. Avoid reclassifying the same root after that path has marked its
    // retained warm owner busy for this run. Direct backend construction still
    // performs the complete fail-closed verification here.
    if (
      executingRunnerdSessionScopes.get(sessionScopeId) !==
        input.execution.binding.runId ||
      hasRetainedWarmTransitionEvidence(scopedRunnerdStateRoot(input.execution))
    ) {
      retainedTransition = await migrateRunnerdStateRootForExecution({
        db: input.db,
        execution: input.execution,
        allowVerifiedBackup:
          input.runnerExecutionTarget?.kind === "remote" &&
          input.runnerExecutionTarget.transport === "sandbox",
        allowRetainedWarmRunner: false,
        allowLocalRecovery: input.runnerExecutionTarget?.kind !== "remote",
        onLog: input.onLog,
        restartRecovery: input.restartRecovery,
        runnerExecutionTarget: input.runnerExecutionTarget,
        conversationMode: input.conversationMode,
      });
    }
    return await createRunnerdBackendWithinSessionClaim(
      input,
      sessionScopeId,
      retainedTransition,
    );
  } finally {
    initializingSessionToolAuthorities.delete(sessionScopeId);
  }
}

async function createRunnerdBackendWithinSessionClaim(
  input: Parameters<typeof createRunnerdBackend>[0],
  sessionScopeId: string,
  retainedTransition?: VerifiedWarmTransitionBinding,
): Promise<NativeSessionBackend & { bindManagedSession(session: NativeSession): NativeSession }> {
  const managedOpenCodeDataHome = managedOpenCodeRuntimeDataIsolated(
    input.execution,
    input.runnerEnvironment ?? process.env,
  );
  let recoveryPending = retainedTransition !== undefined;
  const target = input.runnerExecutionTarget ?? { kind: "local" as const };
  const remoteTarget = target.kind === "remote" ? target : null;
  const remoteRuntimeRoot = remoteTarget
    ? posix.join(remoteTarget.remoteCwd, ".paperclip-runtime", "paperclip-runner")
    : null;
  const remoteSessionDigest = createHash("sha256")
    .update(nativeSessionKey(input.execution))
    .digest("hex");
  const remoteSessionRoot = remoteRuntimeRoot
    ? posix.join(remoteRuntimeRoot, "sessions", remoteSessionDigest)
    : null;
  const nativeConversationHarnessState = input.conversationMode === true && remoteTarget?.transport === "sandbox" &&
    input.execution.provider.kind === "opencode" && input.execution.session.driverKind === "opencode_server";
  const remoteCommandRunner = remoteTarget
    ? remoteTarget.transport === "ssh"
      ? createNativeSshCommandRunner({
          spec: remoteTarget.spec,
          defaultCwd: remoteTarget.remoteCwd,
        })
      : remoteTarget.runner
    : null;
  if (remoteTarget && !remoteCommandRunner) {
    throw new Error(
      "runner_transport_ineligible: remote process runner is unavailable",
    );
  }
  const withRemoteSessionFilesystemFence = async <T>(
    purpose: "native_harness_state" | "native_runtime_context_prepare",
    work: () => Promise<T>,
  ): Promise<T> => {
    if (!managedOpenCodeDataHome || remoteTarget?.transport !== "sandbox" ||
      !remoteCommandRunner || !remoteSessionRoot) return await work();
    const nonce = randomUUID();
    const fenceCommand = async (action: "acquire" | "release") => remoteCommandRunner.execute({
      command: "sh",
      args: ["-c", action === "acquire" ? REMOTE_NATIVE_SESSION_FENCE_ACQUIRE_SCRIPT : REMOTE_NATIVE_SESSION_FENCE_RELEASE_SCRIPT,
        `paperclip-native-session-fence-${action}`, remoteTarget.remoteCwd, remoteSessionDigest, nonce],
      cwd: remoteTarget.remoteCwd,
      bypassSession: true,
      timeoutMs: 10_000,
      nativePreparationPurpose: purpose,
    });
    const acquired = await fenceCommand("acquire");
    if (acquired.exitCode !== 0 || acquired.timedOut)
      throw new Error("runner_remote_session_filesystem_fence_unavailable");
    let workFailed = false;
    try {
      return await work();
    } catch (error) {
      workFailed = true;
      throw error;
    } finally {
      const released = await fenceCommand("release").catch(() => null);
      if (!workFailed && (!released || released.exitCode !== 0 || released.timedOut))
        throw new Error("runner_remote_session_filesystem_fence_release_failed");
    }
  };
  const currentWakeComments = await resolveCurrentWakeCommentsBinding(
    input.db,
    input.execution.binding,
  );
  const pinnedSkills = new Set("runtimeContext" in input.execution ? input.execution.runtimeContext.skills.map((skill) => skill.key) : []);
  const connectorAssignments = [...pinnedSkills].some(isConnectorSkill)
    ? await resolveConnectorAssignments(input.db, input.execution.binding) : [];
  const reviewRun = await input.db.select({ contextSnapshot: heartbeatRuns.contextSnapshot, responsibleUserId: heartbeatRuns.responsibleUserId })
    .from(heartbeatRuns).where(and(
      eq(heartbeatRuns.id, input.execution.binding.runId),
      eq(heartbeatRuns.companyId, input.execution.binding.companyId),
    )).limit(1).then((rows) => rows[0]);
  const nativeReview = readNativeReviewAssignmentContext(reviewRun?.contextSnapshot);
  if (nativeReview && !await getNativeReviewAssignment(input.db, {
    ...input.execution.binding, contextSnapshot: nativeReview,
  })) throw new Error("native_review_assignment_no_longer_available");
  // Remote Codex already sends dynamic tool calls over authenticated PRP. Keep
  // the assigned gateway on the control plane instead of asking the sandbox to
  // reach the host's HTTP origin (which may be private or loopback-only).
  const relayAssignedMcp = remoteTarget !== null && input.execution.provider.kind === "codex";
  const assignedMcpUrl = input.runnerEnvironment?.PAPERCLIP_NATIVE_MCP_URL;
  const assignedMcpToken = input.runnerEnvironment?.PAPERCLIP_NATIVE_MCP_TOKEN;
  const assignedMcpName = input.runnerEnvironment?.PAPERCLIP_NATIVE_MCP_NAME;
  const hasAssignedMcp = Boolean(assignedMcpName || assignedMcpUrl || assignedMcpToken);
  if (relayAssignedMcp && hasAssignedMcp && (!assignedMcpName?.trim() || !assignedMcpUrl?.trim() || !assignedMcpToken?.trim())) {
    throw new Error("assigned native MCP launch binding is incomplete");
  }
  const assignedGatewayPublicId = relayAssignedMcp && assignedMcpUrl
    ? new URL(assignedMcpUrl).pathname.match(/^\/mcp\/gateways\/([a-zA-Z0-9_-]+)$/)?.[1]
    : undefined;
  if (relayAssignedMcp && hasAssignedMcp && !assignedGatewayPublicId) {
    throw new Error("assigned native MCP gateway path is invalid");
  }
  const assignedMcpTools = relayAssignedMcp && !nativeReview && assignedMcpUrl && assignedMcpToken
    ? await createAssignedMcpTools({
        gateway: getAssignedMcpGateway(input.db),
        gatewayPublicId: assignedGatewayPublicId!,
        bearerToken: assignedMcpToken,
        workMode: input.execution.task.workMode,
      })
    : undefined;
  const sandboxOpenCodeMcp = remoteTarget?.transport === "sandbox"
    && input.execution.provider.kind === "opencode"
    ? nativeMcpLaunchBinding(input.runnerEnvironment ?? {})
    : null;
  const authority = new PaperclipRunnerToolAuthority(input.db, {
    managementToolsEnabled: !nativeReview && await nativeManagementToolsAvailable(input.db,input.execution.binding,reviewRun?.responsibleUserId??null),
    ...(nativeReview ? { nativeReview } : {}),
    connectorAssignments: connectorAssignments.filter((assignment) => pinnedSkills.has(assignment.skillKey)),
    assignedMcpTools,
    companyId: input.execution.binding.companyId,
    issueId: input.execution.binding.issueId,
    runId: input.execution.binding.runId,
    agentId: input.execution.binding.agentId,
    normalizedSessionId: nativeSessionKey(input.execution),
    pinnedMcpDigest:
      "runtimeContext" in input.execution
        ? input.execution.runtimeContext.mcp.digest
        : undefined,
    workMode: input.execution.task.workMode,
    workspaceRoot: remoteTarget?.remoteCwd ?? input.execution.workspace.cwd,
    executionTargetKind: target.kind,
    readRemoteWorkspaceFile: remoteTarget && remoteCommandRunner
      ? (file) => readVerifiedRemoteWorkspaceFile({ runner: remoteCommandRunner, workspaceRoot: remoteTarget.remoteCwd, ...file })
      : undefined,
    currentWakeComments: currentWakeComments ?? undefined,
    chatAttachmentReadScope: input.chatAttachmentReadScope,
    nativeModelOutputCapture: input.nativeModelOutputCapture,
    managedNativeContextReadCapture: input.managedNativeContextReadCapture,
    testBeforeManagedProjectCreate: input.testBeforeManagedProjectCreate,
    testAfterManagedProjectCreate: input.testAfterManagedProjectCreate,
    ...(input.managedNativeContextReadCapture ? { managedNativeContextRead: async (query: string, callId?: string) => {
      const [current] = await input.db.select({ projectId: issues.projectId, responsibleUserId: heartbeatRuns.responsibleUserId })
        .from(heartbeatRuns).innerJoin(issues, and(eq(issues.companyId, heartbeatRuns.companyId),
          eq(issues.id, input.execution.binding.issueId))).where(and(
          eq(heartbeatRuns.companyId, input.execution.binding.companyId),
          eq(heartbeatRuns.id, input.execution.binding.runId),
          eq(heartbeatRuns.agentId, input.execution.binding.agentId),
        ));
      if (!current) throw new Error("managed_native_context_read_binding_invalid");
      let binding: NativeContextReadBinding;
      binding = await assembleNativeContextRead(input.db, {
        companyId: input.execution.binding.companyId, agentId: input.execution.binding.agentId,
        runId: input.execution.binding.runId, issueId: input.execution.binding.issueId,
        projectId: current.projectId ?? null, responsibleUserId: current.responsibleUserId ?? null,
        actor: { type: "agent", source: "none", companyId: input.execution.binding.companyId,
          agentId: input.execution.binding.agentId, runId: input.execution.binding.runId,
          onBehalfOfUserId: current.responsibleUserId ?? undefined }, query,
      });
      input.managedNativeContextReadCapture!.value = binding;
      return { markdown: binding.markdown };
    } } : {}),
    stopTaskForReassignment: input.stopTaskForReassignment,
    enqueueWakeup: input.enqueueWakeup,
  });
  const authorityEpoch = new SessionToolAuthorityEpoch(
    input.execution.binding.runId,
    authority,
    input.toolTrace,
    input.onDocumentRead,
    input.onProjectToolResult,
    input.onNativeInputToolResult,
    input.onNativeToolCall,
    input.onManagedOpenCodeToolResult,
    input.managedNativeContextReadCapture,
    input.serializeManagedOperation,
  );
  const logRunnerDiagnostic = createRunnerDiagnosticLogSink({
    runId: input.execution.binding.runId,
    onLog: input.onLog,
    revokeToolAuthority: () => authorityEpoch.revoke(),
  });
  let dynamicTools: Awaited<
    ReturnType<SessionToolAuthorityEpoch["definitions"]>
  >;
  try {
    dynamicTools = await authorityEpoch.definitions();
  } catch (error) {
    authorityEpoch.revoke();
    throw error;
  }
  // Persist the managed OpenCode source authority for an authenticated
  // conversation before any model credential exists. Runtime-context bundles
  // are staged in this pre-receipt phase, so source pinning must derive from
  // the server-owned conversation mode and current Run/manifest binding, not
  // from whether this particular setup command carries broker credentials.
  const managedOpenCode = input.execution.provider.kind === "opencode" &&
    (input.conversationMode === true ||
      Boolean((input.runnerEnvironment ?? process.env).PAPERCLIP_MANAGED_MODEL_BROKER_ORIGIN?.trim()));
  let managedOpenCodeTools: Readonly<Record<string, unknown>>[] | null = null;
  let managedOpenCodeDynamicTools: Readonly<Record<string, unknown>>[] | null = null;
  if (managedOpenCode) {
    const allowedNames = new Set(["read_document", "write_document", "create_task", "create_project", "self_remember", "read_context",
      "call_api", "get_task_context", "get_task_history", "read_chat_attachment", "query_business_metric", "paperclip_finish", "paperclip_block"]);
    const schemas: Array<Record<string, unknown>> = dynamicTools.flatMap((raw): Array<Record<string, unknown>> => {
      if (typeof raw.name !== "string") return [];
      let name = raw.name;
      for (const prefix of ["paperclip__", "paperclip_", "paperclip."]) {
        if (name.startsWith(prefix)) { name = name.slice(prefix.length); break; }
      }
      if (!allowedNames.has(name)) return [];
      if (name === "create_project" && !input.nativeModelOutputCapture) return [];
      const schema = structuredClone(raw);
      if (name === "call_api") {
        // Keep the existing Project GET and add only the exact existing Project
        // POST whose server owner verifies the managed call capture, signed
        // Native effect claim, current task source, and Human-bound Project
        // receipt. No other API operation becomes provider-visible.
        schema.description = "Read one current Project, or create one private internal Project, through the existing authenticated API routes. Supported operations are exactly GET /api/projects/{id} and POST /api/companies/{companyId}/projects.";
        schema.inputSchema = {
          type: "object",
          additionalProperties: false,
          properties: {
            operationId: { type: "string", enum: [
              "GET /api/projects/{id}", "POST /api/companies/{companyId}/projects",
            ] },
            pathParams: { type: "object", additionalProperties: false,
              properties: { id: { type: "string", format: "uuid" }, companyId: { type: "string", format: "uuid" } } },
            body: managedNativeProjectApiBodyJsonSchema(),
          },
          required: ["operationId", "pathParams"],
        };
      }
      if (name === "create_project") {
        // Managed OpenCode may create only an internal private Project from a
        // minimal name/description/local-workspace label and optional explicit
        // GitHub repository URLs. Repo IDs, fetches, credentials, publication,
        // environment, and execution policy remain unavailable.
        schema.description = "Create one private internal Project from the current governed task context with a required server-managed local workspace name. Optionally register HTTPS GitHub owner/repository URLs as additional workspaces; URLs are normalized and duplicates collapse. This does not select repository IDs, fetch repositories, provide credentials, or configure execution policy.";
        schema.inputSchema = managedNativeProjectArgumentsJsonSchema();
      }
      return [{ ...schema, name }];
    });
    // The pinned OpenCode MCP bridge appends these canonical terminal tools at
    // discovery time. Include the same server-owned definitions in the
    // immutable tool catalog/hash so the broker can verify that exact list.
    // Runnerd's OpenCode path appends this canonical semantic catalog from the
    // Codex driver values. Hash those exact bridge-owned definitions so the
    // managed broker validates the actual provider-visible list.
    schemas.push(...codexSemanticToolSpecs().map(tool => {
      const providerTool = structuredClone(tool) as Record<string, unknown>;
      const inputSchema = record(providerTool.inputSchema);
      if (inputSchema.type !== "object" || inputSchema.additionalProperties !== true)
        throw new Error("managed_opencode_terminal_tool_schema_invalid");
      // Pinned OpenCode 1.18.32's Anthropic conversion sets this root flag to
      // false for these two terminal schemas. Model the exact provider-visible
      // projection; server-side terminal parsing still enforces the complete
      // canonical completion contract after the tool call returns.
      providerTool.inputSchema = { ...inputSchema, additionalProperties: false };
      return providerTool;
    }));
    const names = schemas.map((tool) => tool.name);
    if (!names.includes("read_document") || !names.includes("write_document") || !names.includes("create_task") ||
      (input.nativeModelOutputCapture && !names.includes("self_remember")) ||
      (input.nativeModelOutputCapture && !names.includes("read_context")) ||
      !names.includes("paperclip_finish") || !names.includes("paperclip_block") || new Set(names).size !== names.length)
      throw new Error("managed_opencode_source_profile_tools_incomplete");
    managedOpenCodeTools = schemas;
    // Runnerd's original MCP bridge owns and appends the two canonical
    // terminal controls. Keep them in the broker's exact catalog proof, but
    // pass only Paperclip CRUD tools to the bridge to avoid duplicate names.
    managedOpenCodeDynamicTools = schemas.filter((tool) =>
      ["read_document", "write_document", "create_task", "create_project", "self_remember", "read_context", "call_api",
        "get_task_context", "get_task_history", "read_chat_attachment", "query_business_metric"].includes(String(tool.name)));
    const resumeToolNames = managedOpenCodeDynamicTools.map((tool) => String(tool.name));
    if (new Set(resumeToolNames).size !== resumeToolNames.length ||
      !["read_document", "write_document", "create_task"].every(name => resumeToolNames.includes(name)) ||
      (input.nativeModelOutputCapture && !resumeToolNames.includes("create_project")) ||
      (input.nativeModelOutputCapture && !resumeToolNames.includes("self_remember")) ||
      (input.nativeModelOutputCapture && !resumeToolNames.includes("read_context")) ||
      resumeToolNames.some(name => !["read_document", "write_document", "create_task", "create_project", "self_remember", "read_context", "call_api",
        "get_task_context", "get_task_history", "read_chat_attachment", "query_business_metric"].includes(name)))
      throw new Error("managed_opencode_resume_tool_catalog_invalid");
    const taskEnvelope = nativeSessionTaskEnvelope(input.execution);
    const sourceContextForAuthority = "runtimeContext" in input.execution ? input.execution.runtimeContext : null;
    const remoteInstructionRootForAuthority = remoteSessionRoot && sourceContextForAuthority
      ? posix.join(remoteSessionRoot, "filesystem", "context", "instructions")
      : null;
    const systemInstructions = nativeSystemInstructions(input.execution);
    // Runnerd replaces the local source bundle root with this exact staged
    // root before the provider sees system instructions. Bind that resulting
    // text so the broker verifies the actual remote prompt without relaxing
    // its equality check.
    const sourceBoundSystemInstructions = remoteInstructionRootForAuthority && sourceContextForAuthority
      ? systemInstructions.replaceAll(sourceContextForAuthority.instructions.bundle.rootPath,
        remoteInstructionRootForAuthority)
      : systemInstructions;
    const sourceAuthority = {
      version: 1,
      executionInputHash: input.nativeBootstrapExecutionInputHash ?? nativeSha256(input.execution),
      attachmentStageHash: null as string | null,
      systemInstructionsHash: nativeSha256(sourceBoundSystemInstructions),
      toolSchemasHash: nativeSha256(schemas),
      toolSchemas: schemas,
      // A prompt becomes authorized only from the exact prepared turn passed
      // through onTurnInput and persisted as a dispatch intent. In particular,
      // do not pre-authorize a guessed wrapper that the managed driver does not
      // send on the wire.
      authorizedPromptHashes: [],
      promptSourceBindings: [],
    };
    await input.db.transaction(async (tx) => {
      const [run] = await tx.select().from(heartbeatRuns).where(and(
        eq(heartbeatRuns.companyId, input.execution.binding.companyId),
        eq(heartbeatRuns.id, input.execution.binding.runId),
        eq(heartbeatRuns.agentId, input.execution.binding.agentId),
        eq(heartbeatRuns.status, "running"),
      )).for("update");
      const profile = run?.runnerProfileJson && typeof run.runnerProfileJson === "object" && !Array.isArray(run.runnerProfileJson)
        ? run.runnerProfileJson as Record<string, unknown> : null;
      if (!run || !profile || nativeSha256(profile.nativeExecutionInput) !== sourceAuthority.executionInputHash)
        throw new Error("managed_opencode_source_authority_input_changed");
      const previous = profile?.nativeOpenCodeSourceAuthority;
      const previousAuthority = previous && typeof previous === "object" && !Array.isArray(previous)
        ? previous as Record<string, unknown> : null;
      const priorPrompts = previousAuthority?.authorizedPromptHashes;
      const priorBindings = previousAuthority?.promptSourceBindings;
      const priorPromptSet = Array.isArray(priorPrompts) ? new Set(priorPrompts) : null;
      const previousAuthorityMatches = previous === undefined || Boolean(previousAuthority &&
        isDeepStrictEqual({
          version: previousAuthority.version,
          executionInputHash: previousAuthority.executionInputHash,
          systemInstructionsHash: previousAuthority.systemInstructionsHash,
          toolSchemasHash: previousAuthority.toolSchemasHash,
          toolSchemas: previousAuthority.toolSchemas,
        }, {
          version: sourceAuthority.version,
          executionInputHash: sourceAuthority.executionInputHash,
          systemInstructionsHash: sourceAuthority.systemInstructionsHash,
          toolSchemasHash: sourceAuthority.toolSchemasHash,
          toolSchemas: sourceAuthority.toolSchemas,
        }) && Array.isArray(priorPrompts) && priorPrompts.length <= 64 &&
        priorPrompts.every(hash => typeof hash === "string" && /^[0-9a-f]{64}$/.test(hash)) &&
        priorPromptSet?.size === priorPrompts.length && Array.isArray(priorBindings) &&
        priorBindings.length === priorPrompts.length && priorBindings.every(binding => {
          const value = record(binding);
          return typeof value.promptHash === "string" && priorPromptSet.has(value.promptHash) &&
            typeof value.sourceSetHash === "string" && /^[0-9a-f]{64}$/.test(value.sourceSetHash);
        }));
      if (!run || !profile || nativeSha256(profile.nativeExecutionInput) !== sourceAuthority.executionInputHash ||
        !previousAuthorityMatches)
        throw new Error("managed_opencode_source_profile_binding_changed");
      await tx.update(heartbeatRuns).set({
        runnerProfileJson: { ...profile, nativeOpenCodeSourceAuthority: previousAuthority ?? sourceAuthority }, updatedAt: new Date(),
      }).where(and(eq(heartbeatRuns.companyId, run.companyId), eq(heartbeatRuns.id, run.id), eq(heartbeatRuns.status, "running")));
    });
  }
  const root = runnerdStateRoot(input.execution);
  const durableIdentity = readRunnerdDurableIdentity(root);
  const durableBinding = retainedTransition
    ? loadRunnerdDurableBinding(input.execution, retainedTransition)
    : durableIdentityMatchesSession(durableIdentity, input.execution)
      ? durableIdentity
      : null;
  const effectiveRunnerInstanceId =
    durableBinding?.runnerInstanceId ?? input.runnerInstanceId;
  const effectiveEnvironmentLeaseId =
    durableBinding?.environmentLeaseId ??
    input.durableEnvironmentLeaseId ??
    (remoteTarget?.transport === "sandbox" && remoteTarget.leaseId
      ? remoteTarget.leaseId
      : input.execution.binding.executionWorkspaceId);
  if (managedOpenCodeDataHome && remoteTarget?.transport === "sandbox") {
    const environmentLeaseId = remoteTarget.leaseId;
    const environmentId = remoteTarget.environmentId;
    const [lease] = environmentLeaseId && environmentId
      ? await input.db.select({ provider: environmentLeases.provider, providerLeaseId: environmentLeases.providerLeaseId })
          .from(environmentLeases).where(and(
            eq(environmentLeases.companyId, input.execution.binding.companyId),
            eq(environmentLeases.id, environmentLeaseId),
            eq(environmentLeases.heartbeatRunId, input.execution.binding.runId),
          )).limit(1)
      : [];
    if (!environmentLeaseId || !environmentId || !lease?.provider || lease.provider === "local" || !lease.providerLeaseId ||
      environmentLeaseId !== effectiveEnvironmentLeaseId) {
      throw new Error("native_remote_runtime_asset_locator_binding_invalid");
    }
    const locator = createRemoteRuntimeAssetLocator({
      companyId: input.execution.binding.companyId,
      runId: input.execution.binding.runId,
      environmentId,
      environmentLeaseId,
      provider: lease.provider!,
      providerLeaseId: lease.providerLeaseId!,
      runnerInstanceId: effectiveRunnerInstanceId,
      normalizedSessionId: nativeSessionKey(input.execution),
      remoteCwd: remoteTarget.remoteCwd,
    });
    await persistRemoteNativeRuntimeAssetLocator({
      db: input.db,
      locator,
      normalizedSessionId: nativeSessionKey(input.execution),
      runnerInstanceId: effectiveRunnerInstanceId,
      remoteCwd: remoteTarget.remoteCwd,
    });
  }
  mkdirSync(root, { recursive: true, mode: 0o700 });
  const requiresRemoteProviderPack =
    remoteTarget !== null &&
    (input.execution.provider.kind === "opencode" ||
      input.execution.provider.kind === "acpx");
  const configuredProviderPackRoot =
    input.runnerRemoteProviderPackPath?.trim() || null;
  let expectedProviderPackManifest: RemoteProviderPackManifest | null = null;
  if (requiresRemoteProviderPack) {
    if (
      !configuredProviderPackRoot ||
      !existsSync(configuredProviderPackRoot) ||
      !lstatSync(configuredProviderPackRoot).isDirectory()
    ) {
      throw new Error(
        "runner_remote_provider_artifact_incompatible: configure PAPERCLIP_RUNNER_REMOTE_PROVIDER_PACK_PATH with the build-owned provider pack",
      );
    }
    expectedProviderPackManifest = readRemoteProviderPackManifest(
      configuredProviderPackRoot,
    );
  }
  const stagedRemoteProviderPackRoot = remoteRuntimeRoot
    ? posix.join(remoteRuntimeRoot, "provider-pack")
    : null;
  let activeRemoteProviderPackRoot: string | null = null;
  const remoteBinary = remoteRuntimeRoot
    ? posix.join(remoteRuntimeRoot, "bin", "paperclip-runnerd")
    : null;
  // The transport hashes runnerBinary on the controller before an external
  // launcher starts runnerd. Keep that artifact identity in the controller's
  // filesystem; the remote launcher separately owns the sandbox command path.
  // When an explicit remote artifact is configured, prepareRemoteRunner stages
  // these exact bytes at remoteBinary before launch.
  const controllerRunnerBinary = remoteTarget
    ? input.runnerRemoteBinaryPath?.trim() || resolvePaperclipRunnerBinary()
    : resolvePaperclipRunnerBinary();
  const explicitRemoteCodex = input.runnerRemoteCodexPath?.trim() || null;
  const remoteCodexNpmSpec = input.runnerRemoteCodexNpmSpec?.trim() || null;
  if (explicitRemoteCodex && remoteCodexNpmSpec) {
    throw new Error("runner_remote_codex_source_conflict");
  }
  const remoteCodexBinary =
    remoteRuntimeRoot && input.execution.provider.kind === "codex"
      ? remoteCodexNpmSpec
        ? posix.join(
            remoteRuntimeRoot,
            "harnesses",
            "codex",
            "node_modules",
            ".bin",
            "codex",
          )
        : posix.join(remoteRuntimeRoot, "bin", "codex")
      : null;
  const remoteStateDirectory = remoteSessionRoot
    ? posix.join(remoteSessionRoot, "runner")
    : undefined;
  const remoteRunnerFilesystemRoot = remoteSessionRoot
    ? posix.join(remoteSessionRoot, "filesystem")
    : null;
  if (managedOpenCodeDataHome && remoteRunnerFilesystemRoot) {
    if (remoteTarget?.transport !== "sandbox" || !remoteCommandRunner)
      throw new Error("Managed OpenCode provider data erasure is not qualified for remote runner storage");
    const probeNonce = randomUUID();
    const probe = await remoteCommandRunner.execute({
      command: "/bin/sh",
      args: ["-c", REMOTE_NATIVE_RUNTIME_ASSET_ERASURE_PROBE_SCRIPT,
        "paperclip-native-asset-erasure-probe", remoteTarget.remoteCwd, remoteSessionDigest,
        input.execution.binding.runId, probeNonce],
      env: { ...REMOTE_NATIVE_ERASER_ENV },
      cwd: remoteTarget.remoteCwd,
      timeoutMs: 15_000,
      bypassSession: true,
      nativePreparationPurpose: "native_provider_data_erasure_probe",
    });
    if (probe.exitCode !== 0 || probe.timedOut || probe.stdout.trim() !== "qualified")
      throw new Error("Managed OpenCode provider data erasure is not qualified for remote runner storage");
  }
  const persistenceProfile = resolveNativeHarnessPersistenceProfile(
    input.execution,
  );
  const sandboxLeaseAcquisition =
    remoteTarget?.transport === "sandbox"
      ? (remoteTarget.sandboxLeaseAcquisition ?? null)
      : null;
  const remotePersistencePath = (
    directory: NativeHarnessPersistenceDirectory,
  ): string | null =>
    directory.location === "runner"
      ? (remoteStateDirectory ?? null)
      : remoteRunnerFilesystemRoot
        ? posix.join(remoteRunnerFilesystemRoot, directory.name)
        : null;
  const sourceRuntimeContext =
    "runtimeContext" in input.execution ? input.execution.runtimeContext : null;
  const remoteRuntimeContext: NativeRuntimeContextSnapshot | null =
    remoteRunnerFilesystemRoot && sourceRuntimeContext
      ? {
          ...sourceRuntimeContext,
          instructions: {
            ...sourceRuntimeContext.instructions,
            bundle: {
              ...sourceRuntimeContext.instructions.bundle,
              rootPath: posix.join(
                remoteRunnerFilesystemRoot,
                "context",
                "instructions",
              ),
            },
          },
          skills: sourceRuntimeContext.skills.map((skill, index) => ({
            ...skill,
            bundle: {
              ...skill.bundle,
              rootPath: posix.join(
                remoteRunnerFilesystemRoot,
                "context",
                "skills",
                `${index}-${skill.bundle.digest.slice(0, 12)}`,
              ),
            },
          })),
        }
      : sourceRuntimeContext;
  let remotePrepared = false;
  let remoteHarnessStatePrepared = false;
  let selectedRemoteMode: "dial_wss" | "listen_ws" | null = null;
  let remoteCaBundleMapping: { sourcePath: string; targetPath: string } | null =
    null;
  let resolveRemoteRunnerProcessSpawned: (() => void) | null = null;
  const remoteRunnerProcessSpawned = remoteTarget
    ? new Promise<void>((resolveSpawned) => {
        resolveRemoteRunnerProcessSpawned = resolveSpawned;
      })
    : Promise.resolve();

  const verifyRemoteRunner = async (
    requiredMode: "dial_wss" | "listen_ws",
    executable = remoteBinary,
  ) => {
    if (!remoteTarget || !remoteCommandRunner || !executable) return;
    const metadataResult = await remoteCommandRunner.execute({
      command: executable,
      args: ["--build-metadata"],
      cwd: remoteTarget.remoteCwd,
      bypassSession: true,
      timeoutMs: 30_000,
      nativePreparationPurpose: "provider_artifact",
    });
    if (metadataResult.exitCode !== 0 || metadataResult.timedOut) {
      throw new Error("runner_remote_artifact_verification_failed");
    }
    let metadata: Record<string, unknown>;
    try {
      metadata = JSON.parse(metadataResult.stdout) as Record<string, unknown>;
    } catch (error) {
      throw new Error("runner_remote_artifact_metadata_invalid", {
        cause: error,
      });
    }
    assertRemoteRunnerBuildMetadata(metadata, requiredMode);
  };

  const reportedCodexVersions = new Set<string>();
  const verifyRemoteCodex = async (executable = remoteCodexBinary) => {
    if (!remoteTarget || !remoteCommandRunner || !executable) return;
    const versionResult = await remoteCommandRunner.execute({
      command: executable,
      args: ["--version"],
      cwd: remoteTarget.remoteCwd,
      bypassSession: true,
      timeoutMs: 30_000,
      nativePreparationPurpose: "provider_artifact",
    });
    if (versionResult.exitCode !== 0 || versionResult.timedOut) {
      throw new Error("runner_remote_codex_artifact_verification_failed");
    }
    const versionOutput = `${versionResult.stdout}\n${versionResult.stderr}`;
    const version = parseCodexCliVersion(versionOutput);
    if (!version || !isSupportedRemoteCodexVersion(version)) {
      throw new Error(
        `runner_remote_provider_artifact_incompatible: supported Codex versions ${REMOTE_CODEX_SUPPORTED_RANGE}, received ${version ?? "an unrecognized or prerelease version"}; install a supported stable Codex release or configure PAPERCLIP_RUNNER_REMOTE_CODEX_NPM_SPEC=@openai/codex@${REMOTE_PROVIDER_PACK_PINS.codex}`,
      );
    }
    if (version !== REMOTE_PROVIDER_PACK_PINS.codex && !reportedCodexVersions.has(version)) {
      reportedCodexVersions.add(version);
      await input.onLog?.(
        "stderr",
        `[paperclip-runner] using compatible Codex ${version} (supported ${REMOTE_CODEX_SUPPORTED_RANGE}; install pin ${REMOTE_PROVIDER_PACK_PINS.codex})\n`,
      );
    }
  };

  const verifyRemoteProviderPack = async (packRoot: string) => {
    if (!remoteTarget || !remoteCommandRunner || !expectedProviderPackManifest)
      return;
    const expected = Buffer.from(
      canonicalJson(expectedProviderPackManifest),
      "utf8",
    ).toString("base64");
    const providerNodeCommand = posix.join(
      packRoot,
      expectedProviderPackManifest.payload.artifacts.nodeCommand.path,
    );
    const verifyScript = [
      "const fs=require('node:fs')",
      "const crypto=require('node:crypto')",
      "const path=require('node:path')",
      "const root=process.argv[1]",
      "const expected=Buffer.from(process.argv[2],'base64').toString('utf8')",
      "const actual=fs.readFileSync(path.join(root,'provider-pack.json'),'utf8').trim()",
      "const canonical=(v)=>Array.isArray(v)?'['+v.map(canonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+canonical(v[k])).join(',')+'}':JSON.stringify(v)",
      "const manifest=JSON.parse(actual)",
      "if(canonical(manifest)!==expected)throw new Error('manifest mismatch')",
      "const hash=(p)=>'sha256:'+crypto.createHash('sha256').update(fs.readFileSync(path.join(root,p))).digest('hex')",
      "const tree=(treeRoot)=>{const digest=crypto.createHash('sha256');const visit=(directory,prefix='')=>{for(const entry of fs.readdirSync(directory,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))){const relative=prefix?prefix+'/'+entry.name:entry.name;const absolute=path.join(directory,entry.name);if(entry.isDirectory()){digest.update('directory\\0'+relative+'\\n');visit(absolute,relative)}else if(entry.isFile()){digest.update('file\\0'+relative+'\\0'+'sha256:'+crypto.createHash('sha256').update(fs.readFileSync(absolute)).digest('hex')+'\\n')}else if(entry.isSymbolicLink()){digest.update('symlink\\0'+relative+'\\0'+fs.readlinkSync(absolute)+'\\n')}else throw new Error('unsupported dist entry '+relative)}};visit(treeRoot);return 'sha256:'+digest.digest('hex')}",
      "for(const name of ['nodeCommand','productionLock','opencodeCommand','opencodeExecutable','opencodeProxy','acpxSidecar']){const artifact=manifest.payload.artifacts[name];if(hash(artifact.path)!==artifact.sha256)throw new Error(name+' digest mismatch')}",
      "if(tree(path.join(root,'dist'))!==manifest.payload.distDigest)throw new Error('dist tree digest mismatch')",
      "const version=process.versions.node.split('.').map(Number)",
      "const minimum=manifest.payload.pins.nodeMinimum.split('.').map(Number)",
      "if(version[0]<minimum[0]||(version[0]===minimum[0]&&(version[1]<minimum[1]||(version[1]===minimum[1]&&version[2]<minimum[2]))))throw new Error('Node version incompatible')",
      "if(process.platform!==manifest.payload.target.platform||process.arch!==manifest.payload.target.architecture)throw new Error('provider pack target mismatch')",
      "const packageVersion=(pkg)=>JSON.parse(fs.readFileSync(path.join(root,'node_modules',...pkg.split('/'),'package.json'),'utf8')).version",
      "const expectedPackages={acpx:manifest.payload.pins.acpx,'@agentclientprotocol/claude-agent-acp':manifest.payload.pins.claudeAcp,'@agentclientprotocol/codex-acp':manifest.payload.pins.codexAcp,'opencode-ai':manifest.payload.pins.opencode}",
      "for(const [pkg,version] of Object.entries(expectedPackages))if(packageVersion(pkg)!==version)throw new Error(pkg+' version mismatch')",
    ].join(";");
    const verified = await remoteCommandRunner.execute({
      command: providerNodeCommand,
      args: ["-e", verifyScript, packRoot, expected],
      cwd: remoteTarget.remoteCwd,
      bypassSession: true,
      timeoutMs: 30_000,
      nativePreparationPurpose: "provider_artifact",
    });
    if (verified.exitCode !== 0 || verified.timedOut) {
      throw new Error(
        `runner_remote_provider_artifact_incompatible: provider pack verification failed (${verified.stderr.trim().slice(-1_024)})`,
      );
    }
    const opencodeCommand = posix.join(
      packRoot,
      expectedProviderPackManifest.payload.artifacts.opencodeCommand.path,
    );
    const opencodeVersion = await remoteCommandRunner.execute({
      command: opencodeCommand,
      args: ["--version"],
      cwd: remoteTarget.remoteCwd,
      bypassSession: true,
      timeoutMs: 30_000,
      nativePreparationPurpose: "provider_artifact",
    });
    if (
      opencodeVersion.exitCode !== 0 ||
      opencodeVersion.timedOut ||
      opencodeVersion.stdout.trim() !== REMOTE_PROVIDER_PACK_PINS.opencode
    ) {
      throw new Error(
        "runner_remote_provider_artifact_incompatible: OpenCode version mismatch",
      );
    }
  };

  const discoverPreinstalledProviderPack = async () => {
    if (!remoteTarget || !remoteCommandRunner) return null;
    const result = await remoteCommandRunner.execute({
      command: "sh",
      args: [
        "-c",
        'for candidate in /opt/paperclip-runner/provider-pack "$HOME/.local/share/paperclip-runner/provider-pack"; do if [ -f "$candidate/provider-pack.json" ]; then printf \'%s\\n\' "$candidate"; break; fi; done',
      ],
      cwd: remoteTarget.remoteCwd,
      bypassSession: true,
      timeoutMs: 10_000,
      nativePreparationPurpose: "provider_artifact",
    });
    if (result.exitCode !== 0 || result.timedOut) return null;
    return parseRemoteExecutableCandidate(result.stdout);
  };

  // Image policy: keep one latest stable CLI installation shared by native and
  // local adapters. Preferred bin entries must point to that same installation;
  // never bake an older global CLI alongside a private runner-only version.
  const discoverPreinstalledExecutable = async (
    name: "paperclip-runnerd" | "codex",
  ) => {
    if (!remoteTarget || !remoteCommandRunner) return null;
    const result = await remoteCommandRunner.execute({
      command: "sh",
      args: [
        "-c",
        `for candidate in /opt/paperclip-runner/bin/${name} "$HOME/.local/bin/${name}"; do ` +
          `if [ -x "$candidate" ]; then printf '%s\\n' "$candidate"; exit 0; fi; done; ` +
          `command -v ${name} 2>/dev/null || true`,
      ],
      cwd: remoteTarget.remoteCwd,
      bypassSession: true,
      timeoutMs: 10_000,
      nativePreparationPurpose: "provider_artifact",
    });
    if (result.exitCode !== 0 || result.timedOut) return null;
    return parseRemoteExecutableCandidate(result.stdout);
  };

  const linkPreinstalledExecutable = async (
    sourcePath: string,
    targetPath: string,
  ) => {
    if (!remoteTarget || !remoteCommandRunner) return;
    const escapedSource = sourcePath.replaceAll("'", "'\\''");
    const escapedTarget = targetPath.replaceAll("'", "'\\''");
    const escapedDirectory = posix.dirname(targetPath).replaceAll("'", "'\\''");
    const result = await remoteCommandRunner.execute({
      command: "sh",
      args: [
        "-c",
        targetPath === remoteCodexBinary
          ? buildRemoteCodexLauncherCommand(sourcePath, targetPath)
          : `umask 077; mkdir -p '${escapedDirectory}' && ` +
            `ln -sfn '${escapedSource}' '${escapedTarget}'`,
      ],
      cwd: remoteTarget.remoteCwd,
      bypassSession: true,
      timeoutMs: 10_000,
      nativePreparationPurpose: "provider_artifact",
    });
    if (result.exitCode !== 0 || result.timedOut) {
      throw new Error("runner_remote_preinstalled_link_failed");
    }
  };

  const prepareRemoteRunnerUnlocked = async (
    requiredMode: "dial_wss" | "listen_ws",
  ) => {
    if (
      !remoteTarget ||
      !remoteCommandRunner ||
      !remoteBinary ||
      remotePrepared
    )
      return;
    selectedRemoteMode = requiredMode;
    if (input.restartRecovery?.kind === "reattach_remote_runner") {
      await verifyRemoteRunner(requiredMode);
      if (requiresRemoteProviderPack && stagedRemoteProviderPackRoot) {
        await verifyRemoteProviderPack(stagedRemoteProviderPackRoot);
        activeRemoteProviderPackRoot = stagedRemoteProviderPackRoot;
      }
      remotePrepared = true;
      return;
    }
    // Compatibility metadata does not prove artifact identity. Reuse only the
    // exact controller-owned bytes when the controller artifact is available.
    const matchesControllerRunnerArtifact = async (executable: string): Promise<boolean> => {
      const expected = createHash("sha256")
        .update(readFileSync(controllerRunnerBinary))
        .digest("hex");
      try {
        const probe = await remoteCommandRunner.execute({
          command: "sh",
          args: [
            "-c",
            'test -x "$1" || exit 1; if command -v sha256sum >/dev/null 2>&1; then sha256sum "$1"; else shasum -a 256 "$1"; fi',
            "paperclip-runner-artifact",
            executable,
          ],
          cwd: remoteTarget.remoteCwd,
          bypassSession: true,
          timeoutMs: 10_000,
          nativePreparationPurpose: "provider_artifact",
        });
        return probe.exitCode === 0 && !probe.timedOut &&
          /^[a-f0-9]{64}\s/.test(probe.stdout) &&
          probe.stdout.trim().split(/\s+/)[0] === expected;
      } catch {
        // An unavailable checksum uses the verified staging path.
        return false;
      }
    };
    let runnerArtifactPrepared = false;
    if (
      sandboxLeaseAcquisition?.outcome === "resumed" &&
      existsSync(controllerRunnerBinary)
    ) {
      runnerArtifactPrepared = await measureNativeRunnerSpan(
        input.trace,
        "runner.artifact.verify_retained",
        () => matchesControllerRunnerArtifact(remoteBinary),
      );
    }
    const explicitRemoteBinary = input.runnerRemoteBinaryPath?.trim() || null;
    if (!runnerArtifactPrepared && mayUsePreinstalledRunnerArtifact(explicitRemoteBinary)) {
      const preinstalledRunner = await measureNativeRunnerSpan(
        input.trace,
        "runner.artifact.discover",
        () => discoverPreinstalledExecutable("paperclip-runnerd"),
      );
      if (preinstalledRunner) {
        try {
          await measureNativeRunnerSpan(
            input.trace,
            "runner.artifact.verify_preinstalled",
            () => verifyRemoteRunner(requiredMode, preinstalledRunner),
          );
          if (existsSync(controllerRunnerBinary) &&
              !await matchesControllerRunnerArtifact(preinstalledRunner)) {
            throw new Error("runner_remote_preinstalled_artifact_mismatch");
          }
          await measureNativeRunnerSpan(
            input.trace,
            "runner.artifact.link",
            () => linkPreinstalledExecutable(preinstalledRunner, remoteBinary),
          );
          runnerArtifactPrepared = true;
          await input.onLog?.(
            "stderr",
            "[paperclip-runner] using preinstalled runnerd from the sandbox image\n",
          );
        } catch {
          runnerArtifactPrepared = false;
        }
      }
    }
    if (!runnerArtifactPrepared) {
      // Upload the same artifact used for the controller identity. The server
      // vendors the runner under vendor/paperclip-runner/bin, so the package
      // development fallback cannot locate it in a deployed server.
      const sourceBinary = controllerRunnerBinary;
      if (!existsSync(sourceBinary)) {
        throw new Error("runner_remote_artifact_unavailable");
      }
      if (!explicitRemoteBinary) {
        const platform = await remoteCommandRunner.execute({
          command: "sh",
          args: ["-c", "uname -s; uname -m"],
          cwd: remoteTarget.remoteCwd,
          bypassSession: true,
          timeoutMs: 10_000,
          nativePreparationPurpose: "provider_artifact",
        });
        const [remoteOs = "", remoteArch = ""] = platform.stdout
          .trim()
          .split(/\r?\n/);
        const localOs =
          process.platform === "darwin"
            ? "Darwin"
            : process.platform === "linux"
              ? "Linux"
              : process.platform;
        const localArch =
          process.arch === "x64"
            ? "x86_64"
            : process.arch === "arm64"
              ? "aarch64"
              : process.arch;
        const archMatches =
          remoteArch === localArch ||
          (localArch === "aarch64" && remoteArch === "arm64");
        if (
          platform.exitCode !== 0 ||
          platform.timedOut ||
          remoteOs !== localOs ||
          !archMatches
        ) {
          throw new Error(
            "runner_remote_artifact_platform_mismatch: configure PAPERCLIP_RUNNER_REMOTE_BINARY_PATH for the remote OS and architecture",
          );
        }
      }
      await stageRemoteRunnerFile({
        target: remoteTarget,
        runner: remoteCommandRunner,
        sourcePath: sourceBinary,
        targetPath: remoteBinary,
        mode: 0o700,
        nativePreparationPurpose: "provider_artifact",
        forceRelayChunking: nativeConversationHarnessState,
      });
    }
    await measureNativeRunnerSpan(input.trace, "runner.artifact.verify", () =>
      verifyRemoteRunner(requiredMode),
    );
    if (remoteCodexBinary && explicitRemoteCodex) {
      if (!existsSync(explicitRemoteCodex)) {
        throw new Error("runner_remote_codex_artifact_unavailable");
      }
      await stageRemoteRunnerFile({
        target: remoteTarget,
        runner: remoteCommandRunner,
        sourcePath: explicitRemoteCodex,
        targetPath: remoteCodexBinary,
        mode: 0o700,
        nativePreparationPurpose: "provider_artifact",
        forceRelayChunking: nativeConversationHarnessState,
      });
      await verifyRemoteCodex();
    }
    if (remoteCodexBinary && remoteCodexNpmSpec) {
      let usedPreinstalledCodex = false;
      const preinstalledCodex = await measureNativeRunnerSpan(
        input.trace,
        "harness.artifact.discover",
        () => discoverPreinstalledExecutable("codex"),
      );
      if (preinstalledCodex) {
        try {
          await measureNativeRunnerSpan(
            input.trace,
            "harness.artifact.verify_preinstalled",
            () => verifyRemoteCodex(preinstalledCodex),
          );
          await measureNativeRunnerSpan(
            input.trace,
            "harness.artifact.link",
            () =>
              linkPreinstalledExecutable(preinstalledCodex, remoteCodexBinary),
          );
          usedPreinstalledCodex = true;
          await input.onLog?.(
            "stderr",
            "[paperclip-runner] using preinstalled Codex from the sandbox image\n",
          );
        } catch {
          usedPreinstalledCodex = false;
        }
      }
      if (!usedPreinstalledCodex) {
        const installRoot = posix.join(
          remoteRuntimeRoot!,
          "harnesses",
          "codex",
        );
        const installResult = await remoteCommandRunner.execute({
          command: "npm",
          args: [
            "install",
            "--prefix",
            installRoot,
            "--no-audit",
            "--no-fund",
            remoteCodexNpmSpec,
          ],
          cwd: remoteTarget.remoteCwd,
          bypassSession: true,
          timeoutMs: 180_000,
        });
        if (installResult.exitCode !== 0 || installResult.timedOut) {
          throw new Error("runner_remote_codex_install_failed");
        }
      }
      await measureNativeRunnerSpan(
        input.trace,
        "harness.artifact.verify",
        () => verifyRemoteCodex(),
      );
    }
    if (remoteCodexBinary && !explicitRemoteCodex && !remoteCodexNpmSpec) {
      const preinstalledCodex = await measureNativeRunnerSpan(
        input.trace,
        "harness.artifact.discover",
        () => discoverPreinstalledExecutable("codex"),
      );
      if (!preinstalledCodex) {
        throw new Error(
          "runner_remote_codex_artifact_unavailable: install codex in the sandbox image or configure PAPERCLIP_RUNNER_REMOTE_CODEX_NPM_SPEC",
        );
      }
      await measureNativeRunnerSpan(
        input.trace,
        "harness.artifact.verify_preinstalled",
        () => verifyRemoteCodex(preinstalledCodex),
      );
      await measureNativeRunnerSpan(input.trace, "harness.artifact.link", () =>
        linkPreinstalledExecutable(preinstalledCodex, remoteCodexBinary),
      );
      await measureNativeRunnerSpan(
        input.trace,
        "harness.artifact.verify",
        () => verifyRemoteCodex(),
      );
      await input.onLog?.(
        "stderr",
        "[paperclip-runner] using preinstalled Codex from the sandbox image\n",
      );
    }
    if (
      requiresRemoteProviderPack &&
      configuredProviderPackRoot &&
      stagedRemoteProviderPackRoot
    ) {
      const packSource = await prepareVerifiedRemoteProviderPack({
        verifyStaged: () => measureNativeRunnerSpan(
          input.trace,
          "provider_pack.verify",
          () => verifyRemoteProviderPack(stagedRemoteProviderPackRoot),
        ),
        usePreinstalled: async () => {
          let preinstalledProviderPack = await discoverPreinstalledProviderPack();
          if (preinstalledProviderPack) {
            try {
              await measureNativeRunnerSpan(
                input.trace,
                "provider_pack.verify_preinstalled",
                () => verifyRemoteProviderPack(preinstalledProviderPack!),
              );
              const escapedSource = preinstalledProviderPack.replaceAll(
                "'",
                "'\\''",
              );
              const escapedTarget = stagedRemoteProviderPackRoot.replaceAll(
                "'",
                "'\\''",
              );
              const escapedParent = posix
                .dirname(stagedRemoteProviderPackRoot)
                .replaceAll("'", "'\\''");
              const linked = await remoteCommandRunner.execute({
                command: "sh",
                args: [
                  "-c",
                  `umask 077; mkdir -p '${escapedParent}' && rm -rf '${escapedTarget}' && ln -s '${escapedSource}' '${escapedTarget}'`,
                ],
                cwd: remoteTarget.remoteCwd,
                bypassSession: true,
                timeoutMs: 10_000,
                nativePreparationPurpose: "provider_artifact",
              });
              if (linked.exitCode !== 0 || linked.timedOut) {
                throw new Error(
                  "runner_remote_provider_artifact_incompatible: preinstalled provider pack could not be linked",
                );
              }
              activeRemoteProviderPackRoot = stagedRemoteProviderPackRoot;
              await input.onLog?.(
                "stderr",
                "[paperclip-runner] using manifest-matched provider pack from the sandbox image\n",
              );
            } catch (error) {
              const reason = error instanceof Error && error.message.includes("preinstalled provider pack could not be linked")
                ? "preinstalled_link_failed"
                : error instanceof Error && error.message.includes("OpenCode version mismatch")
                  ? "opencode_version_mismatch"
                  : error instanceof Error && error.message.includes("provider pack verification failed")
                    ? "pack_verification_failed"
                    : "preinstalled_pack_rejected";
              await input.onLog?.("stderr", `[paperclip-runner] preinstalled provider pack rejected: ${reason}\n`);
              preinstalledProviderPack = null;
            }
          }
          return preinstalledProviderPack !== null;
        },
        stageAndVerify: async () => {
          if (!remoteCommandRunner.syncIn) {
            throw new Error(
              "runner_remote_provider_artifact_incompatible: this remote transport cannot stage a provider pack; preinstall the exact manifest-matched pack",
            );
          }
          const escapedPackRoot = stagedRemoteProviderPackRoot.replaceAll(
            "'",
            "'\\''",
          );
          const cleared = await remoteCommandRunner.execute({
            command: "sh",
            args: ["-c", `rm -rf '${escapedPackRoot}'`],
            cwd: remoteTarget.remoteCwd,
            bypassSession: true,
            timeoutMs: 10_000,
            nativePreparationPurpose: "provider_artifact",
          });
          if (cleared.exitCode !== 0 || cleared.timedOut) {
            throw new Error(
              "runner_remote_provider_artifact_incompatible: stale provider pack could not be replaced",
            );
          }
          await stageRemoteRunnerDirectory({
            target: remoteTarget,
            runner: remoteCommandRunner,
            sourcePath: configuredProviderPackRoot,
            targetPath: stagedRemoteProviderPackRoot,
            mode: 0o700,
            nativePreparationPurpose: "provider_artifact",
          });
          await measureNativeRunnerSpan(input.trace, "provider_pack.verify", () =>
            verifyRemoteProviderPack(stagedRemoteProviderPackRoot),
          );
          activeRemoteProviderPackRoot = stagedRemoteProviderPackRoot;
        },
      });
      activeRemoteProviderPackRoot = stagedRemoteProviderPackRoot;
      if (packSource === "staged") {
        await input.onLog?.(
          "stderr",
          "[paperclip-runner] reusing manifest-matched provider pack from the workspace\n",
        );
      }
    }
    remotePrepared = true;
  };

  const prepareRemoteRunner = async (
    requiredMode: "dial_wss" | "listen_ws",
  ) => withRemoteSessionFilesystemFence("native_harness_state", () =>
    prepareRemoteRunnerUnlocked(requiredMode));

  const inspectRemoteHarnessState = async (): Promise<{
    complete: boolean;
    runnerState: Record<string, unknown> | null;
    providerSessionIdentity: Record<string, unknown> | null;
    incompleteReason: "unavailable" | "not_suspended" | null;
  }> => {
    if (!remoteCommandRunner || !remoteStateDirectory) {
      return {
        complete: false,
        runnerState: null,
        providerSessionIdentity: null,
        incompleteReason: "unavailable",
      };
    }
    const requirements = persistenceProfile.directories.flatMap((directory) => {
      const path = remotePersistencePath(directory);
      if (!path) return [];
      const escaped = path.replaceAll("'", "'\\''");
      return directory.name === "runner"
        ? [`test -f '${escaped}/runner-state.json'`]
        : [`test -d '${escaped}'`];
    });
    const escapedRunnerState = posix
      .join(remoteStateDirectory, "runner-state.json")
      .replaceAll("'", "'\\''");
    const escapedProviderState = posix
      .join(remoteStateDirectory, runnerProviderStateFilename(input.execution))
      .replaceAll("'", "'\\''");
    const inspected = await remoteCommandRunner.execute({
      command: "sh",
      args: [
        "-c",
        `${requirements.join(" && ")} && test -f '${escapedProviderState}' && base64 < '${escapedRunnerState}'`,
      ],
      bypassSession: true,
      timeoutMs: 10_000,
      ...(nativeConversationHarnessState ? { nativePreparationPurpose: "native_harness_state" as const } : {}),
    });
    if (inspected.exitCode !== 0 || inspected.timedOut) {
      return {
        complete: false,
        runnerState: null,
        providerSessionIdentity: null,
        incompleteReason: "unavailable",
      };
    }
    let runnerState: Record<string, unknown>;
    try {
      runnerState = record(
        JSON.parse(
          Buffer.from(inspected.stdout.replace(/\s+/g, ""), "base64").toString(
            "utf8",
          ),
        ),
      );
    } catch {
      throw new Error("runner_harness_state_mismatch: runner_state_invalid_json");
    }
    if (
      runnerState.runnerInstanceId !== input.runnerInstanceId ||
      runnerState.normalizedSessionId !== nativeSessionKey(input.execution)
    ) {
      throw new Error("runner_harness_state_mismatch: runner_identity");
    }
    if (runnerState.lifecycle !== "suspended") {
      return {
        complete: false,
        runnerState: null,
        providerSessionIdentity: null,
        incompleteReason: "not_suspended",
      };
    }
    let providerState: Record<string, unknown>;
    try {
      providerState = await readRemoteRunnerProviderState({
        runner: remoteCommandRunner,
        stateDirectory: remoteStateDirectory,
        execution: input.execution,
        nativeHarnessState: nativeConversationHarnessState,
      });
    } catch {
      throw new Error("runner_harness_state_mismatch: provider_state_unreadable");
    }
    const providerSessionIdentity =
      providerSessionIdentityFromDurableProviderState({
        execution: input.execution,
        providerState,
      });
    if (!providerSessionIdentityIsPresent(providerSessionIdentity)) {
      throw new Error("runner_harness_state_mismatch: provider_identity_incomplete");
    }
    const previousManifest = compatibleNativeHarnessBackupManifests({
      root,
      execution: input.execution,
      runnerInstanceId: input.runnerInstanceId,
    })[0]?.manifest;
    if (
      previousManifest &&
      !providerSessionIdentityTransitionIsAllowed({
        execution: input.execution,
        previous: previousManifest.providerSessionIdentity,
        current: providerSessionIdentity,
      })
    ) {
      throw new Error("runner_harness_state_mismatch: provider_identity_changed");
    }
    return {
      complete: true,
      runnerState,
      providerSessionIdentity,
      incompleteReason: null,
    };
  };

  const claimUntouchedSessionInResumedLease = async (): Promise<boolean> => {
    if (!remoteCommandRunner || !remoteRuntimeRoot || !remoteSessionRoot) return false;
    const identity = readRunnerdDurableIdentity(root);
    if (!durableIdentityMatchesExecution(identity, input.execution) ||
        identity?.runnerInstanceId !== effectiveRunnerInstanceId ||
        identity?.environmentLeaseId !== effectiveEnvironmentLeaseId ||
        !runnerdStateProvesIncompleteBootstrap(root)) return false;
    // A reusable workspace may have failed before any harness was created.
    // Claim this exact new session atomically under readable real directories.
    // Missing files inside an existing session never authorize a fresh start.
    const probe = await remoteCommandRunner.execute({
      command: "sh",
      args: ["-c",
        'set -eu; umask 077; test -d "$1" && test ! -L "$1" && test -r "$1" && test -x "$1" || exit 1; if test ! -e "$2" && test ! -L "$2"; then mkdir -- "$2"; fi; test -d "$2" && test ! -L "$2" && test -r "$2" && test -x "$2" || exit 1; mkdir -- "$3"',
        "paperclip-runner-claim-unstarted-session", remoteRuntimeRoot,
        posix.dirname(remoteSessionRoot), remoteSessionRoot],
      bypassSession: true,
      timeoutMs: 10_000,
    });
    return probe.exitCode === 0 && !probe.timedOut;
  };

  const recordInPlaceHarnessReuse = async (
    providerSessionIdentity: Record<string, unknown>,
    startedAtMs = Date.now(),
  ) => {
    const now = Date.now();
    const attributes = {
      provider: input.execution.provider.kind,
      harness: input.execution.session.driverKind,
      lifecycleMode: input.execution.session.lifecyclePolicy.mode,
      stateSource: "sandbox_filesystem",
      bytesTransferred: 0,
    };
    await input.trace?.record({
      name: "harness_state.reuse",
      startedAtMs,
      endedAtMs: now,
      attributes,
    });
    await input.trace?.record({
      name: "provider.session.resume",
      startedAtMs: now,
      endedAtMs: now,
      attributes: {
        provider: input.execution.provider.kind,
        harness: input.execution.session.driverKind,
        identityPresent: providerSessionIdentityIsPresent(
          providerSessionIdentity,
        ),
      },
    });
  };

  const recordHarnessBackupStampForCurrentLease = async (
    backup: VerifiedHarnessBackup,
  ) => {
    if (remoteTarget?.transport !== "sandbox" || !remoteTarget.leaseId) {
      return;
    }
    const leaseRow = await input.db
      .select({
        metadata: environmentLeases.metadata,
        providerLeaseId: environmentLeases.providerLeaseId,
      })
      .from(environmentLeases)
      .where(eq(environmentLeases.id, remoteTarget.leaseId))
      .limit(1)
      .then((rows) => rows[0] ?? null);
    if (!leaseRow?.providerLeaseId) {
      throw new Error("runner_harness_backup_lease_missing");
    }
    if (
      sandboxLeaseAcquisition?.providerLeaseId &&
      sandboxLeaseAcquisition.providerLeaseId !== leaseRow.providerLeaseId
    ) {
      throw new Error("runner_harness_backup_lease_mismatch");
    }
    const stamp = createNativeHarnessBackupStamp({
      manifestPath: resolve(backup.root, "manifest.json"),
      sessionScopeId,
      authorizedProviderLeaseId: leaseRow.providerLeaseId,
      normalizedSessionId: backup.manifest.normalizedSessionId,
      runnerInstanceId: backup.manifest.runnerInstanceId,
      completedAt: backup.manifest.completedAt,
    });
    const updated = await input.db
      .update(environmentLeases)
      .set({
        metadata: {
          ...(leaseRow.metadata ?? {}),
          nativeHarnessBackup: stamp,
        },
        updatedAt: new Date(),
      })
      .where(eq(environmentLeases.id, remoteTarget.leaseId))
      .returning({ id: environmentLeases.id })
      .then((rows) => rows[0] ?? null);
    if (!updated) throw new Error("runner_harness_backup_lease_missing");
  };

  const restoreVerifiedHarnessBackup = async () => {
    if (!remoteTarget || !remoteCommandRunner) {
      throw new Error("runner_harness_backup_unavailable");
    }
    const backup = verifyNativeHarnessBackup({
      root,
      execution: input.execution,
      runnerInstanceId: input.runnerInstanceId,
    });
    if (!backup) throw new Error("runner_harness_backup_unavailable");
    await measureNativeRunnerSpan(
      input.trace,
      "harness_state.failover_restore",
      async () => {
        for (const directory of persistenceProfile.directories) {
          const targetPath = remotePersistencePath(directory);
          if (!targetPath) throw new Error("runner_harness_state_mismatch");
          await stageRemoteRunnerDirectory({
            target: remoteTarget,
            runner: remoteCommandRunner,
            sourcePath: resolve(backup.root, directory.name),
            targetPath,
            mode: 0o700,
            ...(nativeConversationHarnessState ? { nativePreparationPurpose: "native_harness_state" as const } : {}),
          });
        }
      },
      {
        attributes: {
          provider: input.execution.provider.kind,
          harness: input.execution.session.driverKind,
          lifecycleMode: input.execution.session.lifecyclePolicy.mode,
          stateSource: "verified_failover_backup",
          bytesTransferred: backup.bytes,
        },
      },
    );
    const restored = await inspectRemoteHarnessState();
    if (
      !restored.complete ||
      !restored.runnerState ||
      !restored.providerSessionIdentity ||
      canonicalJson(restored.providerSessionIdentity) !==
        canonicalJson(backup.manifest.providerSessionIdentity)
    ) {
      throw new Error("runner_harness_state_mismatch");
    }
    // A deliberately non-reusable environment receives a fresh provider lease
    // for every turn. Stamp that new lease as soon as the verified host backup
    // has been restored so a later provider/bootstrap failure can still clean
    // the ephemeral sandbox up without discarding the only durable copy.
    await recordHarnessBackupStampForCurrentLease(backup);
    return backup;
  };

  const materializeRemoteHarnessLaunchState = async () => {
    if (!remoteTarget || !remoteCommandRunner) return;
    for (const directory of persistenceProfile.directories) {
      if (directory.location !== "filesystem") continue;
      const targetPath = remotePersistencePath(directory);
      if (!targetPath) throw new Error("runner_harness_state_mismatch");
      const escapedTarget = targetPath.replaceAll("'", "'\\''");
      const created = await remoteCommandRunner.execute({
        command: "sh",
        args: ["-c", `umask 077; install -d -m 0700 '${escapedTarget}'`],
        bypassSession: true,
        timeoutMs: 10_000,
        ...(nativeConversationHarnessState ? { nativePreparationPurpose: "native_harness_state" as const } : {}),
      });
      if (created.exitCode !== 0 || created.timedOut) {
        throw new Error("runner_remote_directory_staging_failed");
      }

      // Codex launch credentials are intentionally excluded from failover
      // backups. Re-materialize only those launch-time files into a fresh or
      // replacement sandbox after the durable history has been restored.
      if (directory.name !== "codex-home") continue;
      const localDirectory = resolve(root, directory.name);
      for (const name of ["auth.json", "config.toml"] as const) {
        const sourcePath = resolve(localDirectory, name);
        if (!existsSync(sourcePath)) continue;
        await stageRemoteRunnerFile({
          target: remoteTarget,
          runner: remoteCommandRunner,
          sourcePath,
          targetPath: posix.join(targetPath, name),
          mode: 0o600,
        });
      }
    }
  };

  const ensureRemoteRunnerUnlocked = async (stageLaunchAssets = true) => {
    await measureNativeRunnerSpan(
      input.trace,
      "stage.sync",
      async () => {
        if (!selectedRemoteMode) {
          throw new Error("runner_remote_transport_mode_unresolved");
        }
        try {
          await verifyRemoteRunner(selectedRemoteMode);
          await verifyRemoteCodex();
          if (requiresRemoteProviderPack) {
            if (!activeRemoteProviderPackRoot) {
              throw new Error(
                "runner_remote_provider_artifact_incompatible: provider pack was not prepared",
              );
            }
            await verifyRemoteProviderPack(activeRemoteProviderPackRoot);
          }
        } catch {
          remotePrepared = false;
          await prepareRemoteRunnerUnlocked(selectedRemoteMode);
        }
        if (!remoteHarnessStatePrepared) {
          await measureNativeRunnerSpan(input.trace, "stage.asset.home", () =>
            measureNativeRunnerSpan(
              input.trace,
              "session.checkpoint.restore",
              async () => {
                if (
                  remoteTarget?.transport === "sandbox" &&
                  remoteCommandRunner
                ) {
                  const acquisitionRecordedAtMs = Date.now();
                  const backupAvailable = harnessBackupCandidates(root).some(
                    (candidate) =>
                      existsSync(resolve(candidate, "manifest.json")),
                  );
                  const restoreIntoCreatedSandbox =
                    shouldRestoreNativeHarnessBackupIntoSandbox({
                      acquisitionOutcome:
                        sandboxLeaseAcquisition?.outcome ?? null,
                      reusableLeaseConfigured:
                        remoteTarget.reusableLeaseConfigured,
                      backupAvailable,
                    });
                  await input.trace?.record({
                    name: "sandbox.lease.acquisition",
                    startedAtMs: acquisitionRecordedAtMs,
                    endedAtMs: acquisitionRecordedAtMs,
                    attributes: {
                      provider: remoteTarget.providerKey ?? "sandbox",
                      harness: input.execution.session.driverKind,
                      lifecycleMode:
                        input.execution.session.lifecyclePolicy.mode,
                      outcome: sandboxLeaseAcquisition?.outcome ?? "unknown",
                      stateSource:
                        sandboxLeaseAcquisition?.outcome === "replacement" ||
                        restoreIntoCreatedSandbox
                          ? "verified_failover_backup"
                          : sandboxLeaseAcquisition?.outcome === "resumed"
                            ? "sandbox_filesystem"
                            : "new_sandbox",
                      bytesTransferred: 0,
                    },
                  });
                  if (sandboxLeaseAcquisition?.outcome === "resumed") {
                    const reuseStartedAtMs = Date.now();
                    const state = await measureNativeRunnerSpan(
                      input.trace,
                      "sandbox.lease.resume",
                      inspectRemoteHarnessState,
                      {
                        attributes: {
                          provider: remoteTarget.providerKey ?? "sandbox",
                          harness: input.execution.session.driverKind,
                          lifecycleMode:
                            input.execution.session.lifecyclePolicy.mode,
                          outcome: "resumed",
                        },
                      },
                    );
                    if (
                      !state.complete ||
                      !state.runnerState ||
                      !state.providerSessionIdentity
                    ) {
                      if (state.incompleteReason !== "unavailable" || backupAvailable ||
                          !(await claimUntouchedSessionInResumedLease())) {
                        throw new Error(`runner_harness_state_mismatch: resumed_${state.incompleteReason}`);
                      }
                    } else {
                      await recordInPlaceHarnessReuse(
                        state.providerSessionIdentity,
                        reuseStartedAtMs,
                      );
                    }
                  } else if (
                    sandboxLeaseAcquisition?.outcome === "replacement"
                  ) {
                    await measureNativeRunnerSpan(
                      input.trace,
                      "sandbox.lease.replacement",
                      restoreVerifiedHarnessBackup,
                      {
                        attributes: {
                          provider: remoteTarget.providerKey ?? "sandbox",
                          harness: input.execution.session.driverKind,
                          lifecycleMode:
                            input.execution.session.lifecyclePolicy.mode,
                          outcome: "replacement",
                          reason: sandboxLeaseAcquisition.reason ?? "unknown",
                        },
                      },
                    );
                  } else if (restoreIntoCreatedSandbox) {
                    await measureNativeRunnerSpan(
                      input.trace,
                      "sandbox.lease.replacement",
                      restoreVerifiedHarnessBackup,
                      {
                        attributes: {
                          provider: remoteTarget.providerKey ?? "sandbox",
                          harness: input.execution.session.driverKind,
                          lifecycleMode:
                            input.execution.session.lifecyclePolicy.mode,
                          outcome: "created",
                          reason: "reuse_disabled",
                        },
                      },
                    );
                  } else {
                    const reuseStartedAtMs = Date.now();
                    const state = await inspectRemoteHarnessState();
                    if (
                      state.complete &&
                      state.runnerState &&
                      state.providerSessionIdentity
                    ) {
                      // Re-entry while this newly-created lease is already running (for
                      // example a transport reconnect) still uses the in-place state.
                      await recordInPlaceHarnessReuse(
                        state.providerSessionIdentity,
                        reuseStartedAtMs,
                      );
                    } else if (backupAvailable) {
                      // A continuation that has a durable backup but no recorded reusable
                      // lease was not provider-confirmed lost. Never silently create a new
                      // provider session from that ambiguous state.
                      throw new Error("runner_harness_state_mismatch");
                    }
                  }
                } else if (remoteTarget && remoteCommandRunner) {
                  // Local and generic SSH execution retain their existing checkpoint
                  // behavior. The manifest-only failover gate applies to managed sandbox
                  // replacement, where provider lease provenance is available.
                  for (const directory of persistenceProfile.directories) {
                    const localDirectory = resolve(root, directory.name);
                    const remoteDirectory = remotePersistencePath(directory);
                    if (
                      remoteDirectory &&
                      existsSync(localDirectory) &&
                      !(await remoteRunnerPathExists({
                        runner: remoteCommandRunner,
                        path:
                          directory.name === "runner"
                            ? posix.join(remoteDirectory, "runner-state.json")
                            : remoteDirectory,
                        kind:
                          directory.name === "runner" ? "file" : "directory",
                        nativeHarnessState: nativeConversationHarnessState,
                      }))
                    ) {
                      await stageRemoteRunnerDirectory({
                        target: remoteTarget,
                        runner: remoteCommandRunner,
                        sourcePath: localDirectory,
                        targetPath: remoteDirectory,
                        mode: 0o700,
                        excludeEntries: directory.excludeEntries,
                        ...(nativeConversationHarnessState ? { nativePreparationPurpose: "native_harness_state" as const } : {}),
                      });
                    }
                  }
                }
              },
              {
                attributes: {
                  mode: remoteTarget?.transport ?? "local",
                  lifecycleMode: input.execution.session.lifecyclePolicy.mode,
                },
              },
            ),
          );
          remoteHarnessStatePrepared = true;
        }
        // Authority rotation needs durable history, before the transport writes
        // this turn's launch files. Stage assets only at the actual launch so we
        // neither upload stale context nor transfer every bundle twice on resume.
        if (!stageLaunchAssets) return;
        // Resume can prepare/rotate durable state before the transport creates
        // this invocation's isolated Codex auth/config. The later launch must
        // still stage those fresh files even when history was already restored.
        // Launch material is never recovered from a failover backup.
        await materializeRemoteHarnessLaunchState();
        if (
          remoteTarget &&
          remoteCommandRunner &&
          remoteRunnerFilesystemRoot &&
          sourceRuntimeContext &&
          remoteRuntimeContext
        ) {
          await measureNativeRunnerSpan(
            input.trace,
            "stage.asset.runtime_context",
            async () => {
              await stageRemoteRunnerDirectory({
                target: remoteTarget,
                runner: remoteCommandRunner,
                sourcePath: sourceRuntimeContext.instructions.bundle.rootPath,
                targetPath: remoteRuntimeContext.instructions.bundle.rootPath,
                mode: 0o555,
                nativePreparationPurpose: "native_runtime_context_prepare",
              });
              for (
                let index = 0;
                index < sourceRuntimeContext.skills.length;
                index += 1
              ) {
                await stageRemoteRunnerDirectory({
                  target: remoteTarget,
                  runner: remoteCommandRunner,
                  sourcePath:
                    sourceRuntimeContext.skills[index]!.bundle.rootPath,
                  targetPath:
                    remoteRuntimeContext.skills[index]!.bundle.rootPath,
                  mode: 0o555,
                  nativePreparationPurpose: "native_runtime_context_prepare",
                });
              }
              await stageRemoteRunnerFile({
                target: remoteTarget,
                runner: remoteCommandRunner,
                sourcePath: resolve(root, "runtime-context.json"),
                targetPath: posix.join(
                  remoteRunnerFilesystemRoot,
                  "runtime-context.json",
                ),
                mode: 0o600,
                nativePreparationPurpose: "native_runtime_context_prepare",
              });
            },
          );
        }
        if (remoteTarget && remoteCommandRunner && remoteCaBundleMapping) {
          const caBundleMapping = remoteCaBundleMapping;
          await measureNativeRunnerSpan(
            input.trace,
            "stage.asset.ca_bundle",
            () =>
              stageRemoteRunnerFile({
                target: remoteTarget,
                runner: remoteCommandRunner,
                sourcePath: caBundleMapping.sourcePath,
                targetPath: caBundleMapping.targetPath,
                mode: 0o600,
              }),
          );
        }
      },
      {
        attributes: {
          target: remoteTarget?.transport ?? "local",
          lifecycleMode: input.execution.session.lifecyclePolicy.mode,
        },
      },
    );
  };

  const ensureRemoteRunner = async (stageLaunchAssets = true) =>
    withRemoteSessionFilesystemFence("native_harness_state", () =>
      ensureRemoteRunnerUnlocked(stageLaunchAssets));

  const checkpointRemoteRunnerUnlocked = async (
    settlement: "settled" | "unsettled",
  ) => {
    if (
      !remoteCommandRunner ||
      !remoteStateDirectory ||
      !remoteRunnerFilesystemRoot
    )
      return;
    // Transport release also runs when provider bootstrap failed. In that case
    // runnerd has no durable provider identity (and may not have created the
    // provider persistence directory at all), so attempting a failover backup
    // would replace the original provider error with
    // `runner_harness_state_mismatch`. Only checkpoint a harness that runnerd
    // has proved complete. A malformed or identity-conflicting state still
    // throws from inspectRemoteHarnessState and therefore fails closed.
    let checkpointable = await inspectRemoteHarnessState();
    // The remote runner writes its suspended lifecycle and provider state
    // before the outer process-owner RPC necessarily observes completion.
    // Allow a very small bounded visibility window without ever accepting an
    // active, incomplete, malformed, or identity-conflicting checkpoint.
    for (let attempt = 1; !checkpointable.complete && attempt < 3; attempt++) {
      await new Promise<void>((resolve) => setTimeout(resolve, 100));
      checkpointable = await inspectRemoteHarnessState();
    }
    if (!checkpointable.complete) {
      const incompleteFailure = remoteCheckpointIncompleteFailure(
        settlement,
        checkpointable.incompleteReason,
      );
      await input.onLog?.(
        "stderr",
        `[paperclip-runner] remote checkpoint ${incompleteFailure ? "failed" : "skipped"}: exact suspended harness state unavailable (process=${settlement} reason=${checkpointable.incompleteReason})\n`,
      );
      if (incompleteFailure) throw incompleteFailure;
      return;
    }
    const backupSpanAttributes = {
      provider: input.execution.provider.kind,
      harness: input.execution.session.driverKind,
      lifecycleMode: input.execution.session.lifecyclePolicy.mode,
      stateSource: "sandbox_filesystem",
      bytesTransferred: 0,
    };
    try {
      await measureNativeRunnerSpan(
        input.trace,
        "session.checkpoint.persist",
        () =>
          measureNativeRunnerSpan(
            input.trace,
            "harness_state.backup.persist",
            async () => {
              const verified = await inspectRemoteHarnessState();
              if (
                !verified.complete ||
                !verified.runnerState ||
                !verified.providerSessionIdentity
              ) {
                throw new Error("runner_harness_state_mismatch");
              }
              const providerSessionIdentity = verified.providerSessionIdentity;

              const backupRoot = harnessBackupRoot(root);
              mkdirSync(backupRoot, { recursive: true, mode: 0o700 });
              const pendingRoot = resolve(
                backupRoot,
                `.pending-${randomUUID()}`,
              );
              mkdirSync(pendingRoot, { recursive: true, mode: 0o700 });
              try {
                for (const directory of persistenceProfile.directories) {
                  const sourcePath = remotePersistencePath(directory);
                  if (!sourcePath)
                    throw new Error("runner_harness_state_mismatch");
                  const targetPath = resolve(pendingRoot, directory.name);
                  await syncRemoteRunnerDirectoryOut({
                    runner: remoteCommandRunner,
                    sourcePath,
                    targetPath,
                    mode: 0o700,
                    excludeEntries: directory.excludeEntries,
                    nativeHarnessState: nativeConversationHarnessState,
                  });
                  if (!existsSync(targetPath)) {
                    throw new Error("runner_harness_state_mismatch");
                  }
                }
                const manifest = buildNativeHarnessBackupManifest({
                  backupRoot: pendingRoot,
                  execution: input.execution,
                  runnerInstanceId: input.runnerInstanceId,
                  providerSessionIdentity,
                  sourceProviderLeaseId:
                    sandboxLeaseAcquisition?.providerLeaseId ??
                    remoteTarget?.leaseId ??
                    input.durableEnvironmentLeaseId ??
                    "unknown",
                });
                backupSpanAttributes.bytesTransferred =
                  manifest.directories.reduce(
                    (total, directory) => total + directory.bytes,
                    0,
                  );
                const temporaryManifest = resolve(
                  pendingRoot,
                  "manifest.json.tmp",
                );
                const manifestPath = resolve(pendingRoot, "manifest.json");
                writeFileSync(temporaryManifest, JSON.stringify(manifest), {
                  encoding: "utf8",
                  mode: 0o600,
                });
                renameSync(temporaryManifest, manifestPath);

                const currentRoot = resolve(backupRoot, "current");
                const previousRoot = resolve(backupRoot, "previous");
                removeNativeHarnessBackup(previousRoot);
                let movedCurrent = false;
                if (existsSync(currentRoot)) {
                  renameSync(currentRoot, previousRoot);
                  movedCurrent = true;
                }
                try {
                  renameSync(pendingRoot, currentRoot);
                  if (
                    remoteTarget?.transport === "sandbox" &&
                    remoteTarget.leaseId
                  ) {
                    await recordHarnessBackupStampForCurrentLease({
                      root: currentRoot,
                      manifest,
                      bytes: backupSpanAttributes.bytesTransferred,
                    });
                  }
                } catch (error) {
                  if (existsSync(currentRoot)) {
                    removeNativeHarnessBackup(currentRoot);
                  }
                  if (
                    movedCurrent &&
                    existsSync(previousRoot) &&
                    !existsSync(currentRoot)
                  ) {
                    renameSync(previousRoot, currentRoot);
                  }
                  throw error;
                }
                removeNativeHarnessBackup(previousRoot);
              } finally {
                removeNativeHarnessBackup(pendingRoot);
              }
            },
            {
              attributes: backupSpanAttributes,
            },
          ),
        { parentName: "task.settle" },
      );
    } catch (error) {
      const detail = redactSensitiveText(
        error instanceof Error ? error.message : String(error),
      )
        .replace(/[\r\n]+/g, " ")
        .slice(0, 512);
      await input.onLog?.(
        "stderr",
        `[paperclip-runner] remote checkpoint failed: ${detail || "unknown failure"}\n`,
      );
      throw error;
    }
  };

  const checkpointRemoteRunner = async (
    settlement: "settled" | "unsettled",
  ) => withRemoteSessionFilesystemFence("native_harness_state", () =>
    checkpointRemoteRunnerUnlocked(settlement));

  const prepareExternalRunnerState =
    remoteTarget && remoteCommandRunner
      ? async () => {
          selectedRemoteMode ??= resolveRemoteRunnerTransportMode({
            target: remoteTarget,
            runnerIngressAuthorized: input.runnerIngressAuthorized === true,
          });
          await ensureRemoteRunner(false);
        }
      : undefined;
  const archiveExternalRunnerStateUnlocked =
    remoteCommandRunner && remoteStateDirectory && remoteSessionRoot
      ? async (archive: { archiveKey: string }) => {
          if (!/^[0-9a-f]{24}$/.test(archive.archiveKey)) {
            throw new Error("runner_remote_authority_archive_invalid");
          }
          const sourcePath = posix.join(
            remoteStateDirectory,
            "runner-state.json",
          );
          const archiveDirectory = posix.join(
            remoteSessionRoot,
            "authority-epochs",
            `epoch-${archive.archiveKey}`,
          );
          const archivedStatePath = posix.join(
            archiveDirectory,
            "runner-state.json",
          );
          const result = await remoteCommandRunner.execute({
            command: "sh",
            args: [
              "-c",
              'set -eu; if test -L "$2" || { test -e "$2" && test ! -d "$2"; }; then exit 1; fi; if test -f "$1" && test ! -L "$1" && test ! -e "$3" && test ! -L "$3"; then umask 077; install -d -m 0700 "$2"; mv -- "$1" "$3"; elif test ! -e "$1" && test ! -L "$1" && test -f "$3" && test ! -L "$3"; then :; else exit 1; fi; base64 < "$3"',
              "paperclip-runner-authority-archive",
              sourcePath,
              archiveDirectory,
              archivedStatePath,
            ],
            bypassSession: true,
            timeoutMs: 10_000,
          });
          if (result.exitCode !== 0 || result.timedOut) {
            throw new Error("runner_remote_authority_archive_failed");
          }
          try {
            return record(
              JSON.parse(
                Buffer.from(
                  result.stdout.replace(/\s+/g, ""),
                  "base64",
                ).toString("utf8"),
              ),
            );
          } catch {
            throw new Error("runner_remote_authority_archive_failed");
          }
        }
      : undefined;

  const archiveExternalRunnerState = archiveExternalRunnerStateUnlocked
    ? async (archive: { archiveKey: string }) => withRemoteSessionFilesystemFence(
        "native_harness_state", () => archiveExternalRunnerStateUnlocked(archive))
    : undefined;

  const remoteProcessLauncher =
    remoteTarget && remoteCommandRunner && remoteBinary && remoteStateDirectory
      ? createRemoteRunnerProcessLauncher({
          target: remoteTarget,
          runner: remoteCommandRunner,
          nativeHarnessState: nativeConversationHarnessState,
          nativeSessionStart: remoteTarget.transport === "sandbox" && input.execution.provider.kind === "opencode" &&
            input.execution.session.driverKind === "opencode_server",
          managedModelSession: remoteTarget.transport === "sandbox" && input.execution.provider.kind === "opencode" &&
            input.execution.session.driverKind === "opencode_server",
          remoteBinary,
          processIdentityPath: posix.join(
            remoteStateDirectory,
            "runner-process.identity",
          ),
          stateDirectory: remoteStateDirectory,
          diagnosticsDirectory: posix.join(remoteSessionRoot!, "diagnostics"),
          runnerInstanceId: input.runnerInstanceId,
          ensureArtifact: ensureRemoteRunner,
          onSpawn: input.onSpawn,
          onLog: input.onLog,
          trace: input.trace,
          onRunnerProcessSpawned: () => resolveRemoteRunnerProcessSpawned?.(),
        })
      : undefined;
  const runnerExecution: NativeExecutionInput = remoteTarget
    ? {
        ...input.execution,
        workspace: {
          ...input.execution.workspace,
          cwd: remoteTarget.remoteCwd,
        },
      }
    : input.execution;
  const effectiveRunnerEnvironmentBase: NodeJS.ProcessEnv = {
    ...(input.runnerEnvironment ?? process.env),
  };
  if (relayAssignedMcp || (remoteTarget?.transport === "sandbox" && input.execution.provider.kind === "opencode")) {
    // The server-held tool authority owns this credential. Do not deliver a
    // duplicate HTTP MCP server or its bearer token to the remote provider.
    delete effectiveRunnerEnvironmentBase.PAPERCLIP_NATIVE_MCP_NAME;
    delete effectiveRunnerEnvironmentBase.PAPERCLIP_NATIVE_MCP_URL;
    delete effectiveRunnerEnvironmentBase.PAPERCLIP_NATIVE_MCP_TOKEN;
  }
  // This authority bit is derived only from the selected execution target.
  // Never let an agent, environment binding, or host variable disable the
  // Codex sandbox for a local runner by supplying the same key.
  delete effectiveRunnerEnvironmentBase.PAPERCLIP_RUNNER_EXTERNAL_SANDBOX;
  const effectiveRunnerEnvironment: NodeJS.ProcessEnv = remoteRuntimeRoot
    ? {
        ...effectiveRunnerEnvironmentBase,
        // The provider home is runner-owned state, not the execution workspace.
        // Codex's permission profile explicitly denies HOME and CODEX_HOME. If
        // either points at remoteCwd, that deny rule shadows the workspace write
        // grant and the provider cannot initialize its shell sandbox or edit.
        HOME: posix.join(remoteRunnerFilesystemRoot!, "codex-home"),
        CODEX_HOME: posix.join(remoteRunnerFilesystemRoot!, "codex-home"),
        PAPERCLIP_WORKSPACE_CWD: remoteTarget!.remoteCwd,
        ...(remoteTarget!.transport === "sandbox"
          ? { PAPERCLIP_RUNNER_EXTERNAL_SANDBOX: "1" }
          : {}),
      }
    : {
        ...effectiveRunnerEnvironmentBase,
        PAPERCLIP_WORKSPACE_CWD: input.execution.workspace.cwd,
      };
  const archiveContinuityState = async () => {
    if (hasRetainedWarmTransitionEvidence(root)) {
      throw new Error("native_runner_warm_transition_recovery_unproven");
    }
    const archiveToken = `${Date.now()}-${randomUUID()}`;
    const archiveRoot = resolve(root, "continuity-breaks", archiveToken);
    mkdirSync(archiveRoot, { recursive: true, mode: 0o700 });
    for (const name of [
      "control-plane",
      "runner",
      "codex-home",
      "opencode",
      "acpx",
    ]) {
      const source = resolve(root, name);
      if (existsSync(source)) renameSync(source, resolve(archiveRoot, name));
    }
    if (remoteCommandRunner && remoteSessionRoot) {
      const escapedSource = remoteSessionRoot.replaceAll("'", "'\\''");
      const archivedRemote = `${remoteSessionRoot}.continuity-break-${archiveToken}`;
      const escapedArchive = archivedRemote.replaceAll("'", "'\\''");
      await withRemoteSessionFilesystemFence("native_harness_state", async () => {
        const result = await remoteCommandRunner.execute({
          command: "sh",
          args: [
            "-c",
            `if test -d '${escapedSource}'; then mv '${escapedSource}' '${escapedArchive}'; fi`,
          ],
          bypassSession: true,
          timeoutMs: 30_000,
          ...(nativeConversationHarnessState ? { nativePreparationPurpose: "native_harness_state" as const } : {}),
        });
        if (result.exitCode !== 0 || result.timedOut) {
          throw new Error("runner_continuity_break_archive_failed");
        }
      });
    }
    remotePrepared = false;
  };
  const localRecoveryProcess =
    input.restartRecovery?.kind === "reattach_existing_runner"
      ? input.restartRecovery.process
      : null;
  const adoptedProcess =
    input.restartRecovery?.kind === "reattach_remote_runner"
      ? await verifyRemoteRunnerReattachment({
          claim: input.restartRecovery,
          target,
          identity: durableIdentity ?? {},
          runId: input.execution.binding.runId,
          normalizedSessionId: nativeSessionKey(input.execution),
          nativeHarnessState: input.conversationMode === true && input.execution.provider.kind === "opencode" &&
            target.kind === "remote" && target.transport === "sandbox",
        })
      : target.kind === "local" && localRecoveryProcess
        ? {
            ...localRecoveryProcess,
            isAlive: () => verifiedRecoveryProcessIsAlive(localRecoveryProcess),
            signal: (signal: NodeJS.Signals) =>
              signalVerifiedRecoveryProcess(localRecoveryProcess, signal),
          }
        : undefined;
  if (adoptedProcess && remoteTarget) {
    const markSpawned = resolveRemoteRunnerProcessSpawned as (() => void) | null;
    markSpawned?.();
  }
  const executeCurrentToolAuthority = (
    call: Parameters<SessionToolAuthorityEpoch["execute"]>[0] & { turnId?: string },
  ) => {
    const current = sessionToolAuthorityEpochs.get(sessionScopeId);
    if (!current) throw new Error("native_session_tool_authority_unavailable");
    return current.execute(call);
  };
  const backend = createNativeSessionBackend(runnerExecution, {
    runnerInstanceId:
      retainedTransition?.runnerInstanceId ?? input.runnerInstanceId,
    environment: effectiveRunnerEnvironment,
    opencodeEnvironment: effectiveRunnerEnvironment,
    opencodeAssignedMcp: sandboxOpenCodeMcp,
    workingDirectoryAuthority: remoteTarget
      ? "remote_runner"
      : "local_filesystem",
    onSpawn: input.onSpawn,
    dynamicTools: managedOpenCodeDynamicTools ?? dynamicTools,
    completionFeedback: async (result) => {
      const current = sessionToolAuthorityEpochs.get(sessionScopeId);
      if (!current) throw new Error("native_session_tool_authority_unavailable");
      await current.definitions(); // Reject a revoked run authority before reading task state.
      return nativeCompletionFeedback(input.db, current.runId, result);
    },
    dynamicToolHandler: executeCurrentToolAuthority,
    acpxDynamicToolHandler: executeCurrentToolAuthority,
    opencodeRuntimeDirectory: managedOpenCodeDataHome
      ? managedOpenCodeRuntimeDirectory({ companyId: input.execution.binding.companyId,
          runId: input.execution.binding.runId })
      : resolve(resolvePaperclipInstanceRoot(), "runtime", "paperclip-runner", "opencode"),
    acpxRuntimeDirectory: resolve(
      resolvePaperclipInstanceRoot(),
      "runtime",
      "paperclip-runner",
      "acpx",
    ),
    codexTransportFactory: (recoveryContext) =>
      createRunnerdCodexTransport({
        // This factory owns the remote provider process environment; it must
        // receive the exact server-selected managed-model tuple.
        environment: effectiveRunnerEnvironment,
        onSpawn: input.onSpawn,
        provider:
          input.execution.provider.kind === "codex"
            ? "codex"
            : input.execution.provider.kind === "opencode"
              ? "opencode"
              : input.execution.provider.kind === "claude_managed"
                ? "claude_managed"
                : input.execution.provider.kind === "aws_agentcore"
                  ? "aws_agentcore"
                  : input.execution.provider.kind === "acpx"
                    ? "acpx"
                    : undefined,
        ...(input.execution.provider.kind === "acpx"
          ? {
              acpxAgent: input.execution.provider.agent,
              acpxPermissionMode: input.execution.provider.permissionMode,
              acpxPermissionModePinned:
                input.execution.schema ===
                "paperclip.native-execution-input.v4",
              acpxRuntimeDirectory: remoteRunnerFilesystemRoot
                ? posix.join(remoteRunnerFilesystemRoot, "acpx")
                : resolve(
                    resolvePaperclipInstanceRoot(),
                    "runtime",
                    "paperclip-runner",
                    "acpx",
                  ),
            }
          : {}),
        ...(input.execution.provider.kind === "opencode"
          ? {
              opencodePermissionMode: input.execution.provider.permissionMode,
            }
          : {}),
        ...(input.execution.provider.kind === "claude_managed"
          ? {
              managedProfile: {
                ...input.execution.provider.managedProfile,
                maxSessionListCostUsd:
                  input.execution.provider.maxSessionListCostUsd,
                model: input.execution.provider.model,
              },
            }
          : {}),
        ...(input.execution.provider.kind === "aws_agentcore"
          ? {
              agentCoreProfile: {
                ...input.execution.provider.agentCoreProfile,
                maxEstimatedSessionCostUsd:
                  input.execution.provider.maxEstimatedSessionCostUsd,
                maxIterations:
                  input.execution.provider.invocationLimits.maxIterations,
                maxOutputTokens:
                  input.execution.provider.invocationLimits.maxOutputTokens,
                timeoutSeconds:
                  input.execution.provider.invocationLimits.timeoutSeconds,
                model: input.execution.provider.model,
              },
            }
          : {}),
        ...(expectedProviderPackManifest && stagedRemoteProviderPackRoot
          ? {
              providerNodeCommand: posix.join(
                stagedRemoteProviderPackRoot,
                expectedProviderPackManifest.payload.artifacts.nodeCommand.path,
              ),
              providerNodeCommandSha256:
                expectedProviderPackManifest.payload.artifacts.nodeCommand
                  .sha256,
              providerPackAuthorityDigest: expectedProviderPackManifest.digest,
              opencodeCommand: posix.join(
                stagedRemoteProviderPackRoot,
                expectedProviderPackManifest.payload.artifacts
                  .opencodeExecutable.path,
              ),
              opencodeCommandSha256:
                expectedProviderPackManifest.payload.artifacts
                  .opencodeExecutable.sha256,
              opencodeProxyPath: posix.join(
                stagedRemoteProviderPackRoot,
                expectedProviderPackManifest.payload.artifacts.opencodeProxy
                  .path,
              ),
              opencodeProxySha256:
                expectedProviderPackManifest.payload.artifacts.opencodeProxy
                  .sha256,
              acpxSidecarPath: posix.join(
                stagedRemoteProviderPackRoot,
                expectedProviderPackManifest.payload.artifacts.acpxSidecar.path,
              ),
              acpxSidecarSha256:
                expectedProviderPackManifest.payload.artifacts.acpxSidecar
                  .sha256,
            }
          : {}),
        stateDirectory: root,
        runnerStateDirectory: remoteStateDirectory,
        readRunnerState:
          remoteStateDirectory && remoteCommandRunner
            ? () =>
                readRemoteRunnerState({
                  runner: remoteCommandRunner,
                  stateDirectory: remoteStateDirectory,
                  nativeHarnessState: nativeConversationHarnessState,
                })
            : undefined,
        prepareExternalRunnerState,
        archiveExternalRunnerState,
        runnerBinary: controllerRunnerBinary,
        codexCommand: remoteCodexBinary ?? undefined,
        sourceCodexHome: remoteTarget
          ? resolveSourceCodexHome(input.runnerEnvironment ?? process.env)
          : undefined,
        runnerProcessLauncher: remoteProcessLauncher,
        runnerReconnectGraceMs: remoteTarget ? 120_000 : undefined,
        adoptExistingRunner: adoptedProcess,
        onDiagnostic: (message) => {
          logRunnerDiagnostic(
            `[paperclip-runner] runnerd diagnostic: ${redactSensitiveText(message).slice(-4_096)}\n`,
          );
        },
        lifecyclePolicy: input.execution.session.lifecyclePolicy,
        runtimeContext:
          "runtimeContext" in input.execution
            ? input.execution.runtimeContext
            : null,
        runnerRuntimeContext: remoteRuntimeContext,
        runnerFilesystemRoot: remoteRunnerFilesystemRoot ?? undefined,
        resumeWorkingDirectory: runnerExecution.workspace.cwd,
        externallySandboxed: remoteTarget?.transport === "sandbox",
        opencodeRuntimeDirectory: managedOpenCodeDataHome
          ? managedOpenCodeRuntimeDirectory({ companyId: input.execution.binding.companyId,
              runId: input.execution.binding.runId })
          : remoteRunnerFilesystemRoot
            ? posix.join(remoteRunnerFilesystemRoot, "opencode")
            : undefined,
        // A warm attach must retain the same qualified CRUD catalog as the
        // original managed session; terminal tools are appended by Runnerd's
        // trusted bridge. Never restore the generic Native tool inventory.
        resumeDynamicTools: managedOpenCodeDynamicTools ?? dynamicTools,
        resumeCompletionContract: {
          revision: input.execution.completionContract.contract.revision,
          criterionIds:
            input.execution.completionContract.contract.criteria.map(
              (criterion) => criterion.id,
            ),
        },
        resumeActiveTurnId:
          recoveryContext?.persistedSession?.activeTurnId ?? null,
        resumeProviderSession: recoveryContext?.persistedSession,
        providerRecoveryPolicy:
          recoveryContext?.providerRecoveryPolicy ??
          (input.execution.provider.kind === "acpx" &&
          input.execution.interactionResponses.length > 0
            ? "allow_replacement_after_governed_wait"
            : undefined),
        prpIdentity: {
          runnerInstanceId: effectiveRunnerInstanceId,
          environmentLeaseId: effectiveEnvironmentLeaseId,
          runId: input.execution.binding.runId,
          normalizedSessionId:
            input.execution.session.normalizedSessionId ??
            `session-${input.execution.binding.runId}`,
          turnId: `turn-${input.execution.binding.runId}`,
          itemId: `item-${input.execution.binding.runId}`,
        },
        warmTransitionRegistrationMode: retainedTransition
          ? "routed_connect"
          : undefined,
        authorizeWarmTransitionRecovery: retainedTransition
          ? async (
              stage:
                "before_bootstrap" | "before_spawn" | "before_authentication",
            ) => {
              if (!recoveryPending) return;
              const current = await verifyWarmTransitionRestart(input);
              if (
                current.transitionId !== retainedTransition.transitionId ||
                (stage === "before_bootstrap" &&
                  current.stateFingerprint !==
                    retainedTransition.stateFingerprint)
              ) {
                throw new Error(
                  "native_runner_warm_transition_recovery_unproven",
                );
              }
            }
          : undefined,
        onWarmTransitionRecoveryCompleted: retainedTransition
          ? (completed: { transitionId: string }) => {
              // Only the package's fresh completed new-authority snapshot can
              // reach this callback. A tombstone or caller hint cannot retire
              // the server's pending-recovery admission checks.
              if (completed?.transitionId !== retainedTransition.transitionId) {
                throw new Error(
                  "native_runner_warm_transition_recovery_unproven",
                );
              }
              recoveryPending = false;
            }
          : undefined,
        controlPlaneRegistration: async (authority, attachmentIdentity) => {
          if (retainedTransition && recoveryPending) {
            const current = await verifyWarmTransitionRestart(input);
            if (
              current.stateFingerprint !== retainedTransition.stateFingerprint
            ) {
              throw new Error(
                "native_runner_warm_transition_recovery_unproven",
              );
            }
          }
          return measureNativeRunnerSpan(
            input.trace,
            "runner.transport.connect",
            async () => {
              if (target.kind === "local") {
                const selectedAtMs = Date.now();
                await input.trace?.record({
                  name: "runner.transport.selected",
                  parentName: "runner.transport.connect",
                  startedAtMs: selectedAtMs,
                  endedAtMs: selectedAtMs,
                  attributes: {
                    mode: "local_loopback",
                    connectionOwner: "runnerd",
                  },
                });
                await input.onLog?.(
                  "stderr",
                  "[paperclip-runner] transport mode=local_loopback state=connecting\n",
                );
                const registration = await measureNativeRunnerSpan(
                  input.trace,
                  "runner.prp.route.register",
                  () =>
                    registerRunnerPrpAuthority({
                      companyId: input.execution.binding.companyId,
                      issueId: input.execution.binding.issueId,
                      agentId: input.execution.binding.agentId,
                      runId:
                        attachmentIdentity?.runId ??
                        input.execution.binding.runId,
                      authority,
                    }),
                );
                return {
                  ...registration,
                  startupFailureCode: "runner_local_connect_failed" as const,
                };
              }

              const requiredMode = resolveRemoteRunnerTransportMode({
                target,
                runnerIngressAuthorized: input.runnerIngressAuthorized === true,
              });
              let transport: PaperclipRunnerTransport;
              if (requiredMode === "dial_wss") {
                // Validate eligibility before staging any artifact.
                transport = await measureNativeRunnerSpan(
                  input.trace,
                  "runner.transport.resolve",
                  () =>
                    resolvePaperclipRunnerTransport({
                      target,
                      runId:
                        attachmentIdentity?.runId ??
                        input.execution.binding.runId,
                      localConnectUrl: "ws://127.0.0.1/unused",
                      runnerPublicUrl: input.runnerPublicUrl,
                      runnerCaBundlePath: input.runnerCaBundlePath,
                      runnerIngressAuthorized:
                        input.runnerIngressAuthorized === true,
                    }),
                );
                if (
                  transport.mode === "direct_outbound" &&
                  transport.caBundlePath &&
                  !existsSync(transport.caBundlePath)
                ) {
                  throw new Error(
                    "runner_direct_wss_failed: configured runner CA bundle is unavailable",
                  );
                }
                await measureNativeRunnerSpan(
                  input.trace,
                  "runner.artifact.prepare",
                  () => prepareRemoteRunner(requiredMode),
                );
              } else {
                await measureNativeRunnerSpan(
                  input.trace,
                  "runner.artifact.prepare",
                  () => prepareRemoteRunner(requiredMode),
                );
                // Provider endpoint acquisition happens only after runnerd is staged
                // and its listener capability has been verified.
                transport = await measureNativeRunnerSpan(
                  input.trace,
                  "runner.ingress.acquire",
                  () =>
                    resolvePaperclipRunnerTransport({
                      target,
                      runId:
                        attachmentIdentity?.runId ??
                        input.execution.binding.runId,
                      localConnectUrl: "ws://127.0.0.1/unused",
                      runnerPublicUrl: input.runnerPublicUrl,
                      runnerCaBundlePath: input.runnerCaBundlePath,
                      runnerIngressAuthorized: true,
                    }),
                );
              }

              const selectedAtMs = Date.now();
              await input.trace?.record({
                name: "runner.transport.selected",
                parentName: "runner.transport.connect",
                startedAtMs: selectedAtMs,
                endedAtMs: selectedAtMs,
                attributes: {
                  mode: transport.mode,
                  connectionOwner:
                    transport.mode === "provider_ingress"
                      ? "paperclip"
                      : "runnerd",
                },
              });

              await input.onLog?.(
                "stderr",
                `[paperclip-runner] transport mode=${transport.mode} state=connecting\n`,
              );

              if (transport.mode === "direct_outbound") {
                const inbound = await measureNativeRunnerSpan(
                  input.trace,
                  "runner.prp.route.register",
                  () =>
                    registerRunnerPrpAuthority({
                      companyId: input.execution.binding.companyId,
                      issueId: input.execution.binding.issueId,
                      agentId: input.execution.binding.agentId,
                      runId:
                        attachmentIdentity?.runId ??
                        input.execution.binding.runId,
                      authority,
                    }),
                  { parentName: "runner.transport.connect" },
                );
                let caBundlePath = transport.caBundlePath;
                if (caBundlePath && remoteBinary) {
                  const remoteCaBundlePath = posix.join(
                    posix.dirname(remoteBinary),
                    "runner-ca-bundle.pem",
                  );
                  remoteCaBundleMapping = {
                    sourcePath: caBundlePath,
                    targetPath: remoteCaBundlePath,
                  };
                  caBundlePath = remoteCaBundlePath;
                }
                return {
                  connection: {
                    mode: "connect" as const,
                    connectUrl: transport.connectUrl,
                    ...(caBundlePath ? { caBundlePath } : {}),
                  },
                  startupFailureCode: "runner_direct_wss_failed" as const,
                  checkpoint: checkpointRemoteRunner,
                  release: () => inbound.release(),
                };
              }

              if (transport.mode !== "provider_ingress") {
                throw new Error("runner_transport_mode_changed_after_dispatch");
              }
              let outbound: ReturnType<typeof connectRunnerPrpIngress> | null =
                null;
              let activation: Promise<void> | null = null;
              return {
                connection: {
                  mode: "listen" as const,
                  listenAddress: transport.listenAddress,
                  listenPort: transport.listenPort,
                  listenPath: transport.listenPath,
                },
                activate: () => {
                  activation = measureNativeRunnerSpan(
                    input.trace,
                    "runner.transport.activation",
                    async () => {
                      await measureNativeRunnerSpan(
                        input.trace,
                        "runner.ingress.wait_for_process",
                        () => remoteRunnerProcessSpawned,
                      );
                      outbound = connectRunnerPrpIngress({
                        authority,
                        endpoint: transport.ingress,
                        onStateChange: (state, failureCode) => {
                          logRunnerDiagnostic(
                            `[paperclip-runner] transport mode=provider_ingress state=${state}${failureCode ? ` failure=${failureCode}` : ""}\n`,
                          );
                        },
                      });
                    },
                    { parentName: "runner.session.startup" },
                  );
                  // Cancellation can release the sandbox while activation is
                  // still waiting for the remote runner process. Attach a
                  // rejection observer immediately; `ready()` still awaits the
                  // original promise and reports the same startup failure, but
                  // an early teardown can no longer crash the controller with
                  // an unhandled plugin RPC rejection.
                  void activation.catch(() => undefined);
                },
                ready: async () => {
                  await measureNativeRunnerSpan(
                    input.trace,
                    "runner.transport.ready",
                    async () => {
                      await activation;
                      if (!outbound)
                        throw new Error("runner_ingress_unavailable");
                      await measureNativeRunnerSpan(
                        input.trace,
                        "runner.prp.authenticate",
                        () => outbound!.ready,
                      );
                    },
                    { parentName: "runner.session.startup" },
                  );
                },
                get failure() {
                  return outbound?.failure;
                },
                startupFailureCode: "runner_ingress_unavailable" as const,
                checkpoint: checkpointRemoteRunner,
                release: async () => {
                  if (outbound) await outbound.close();
                  else await transport.ingress.close();
                },
              };
            },
          );
        },
      }).transport,
  });
  const boundManagedSessions = new WeakSet<NativeSession>();
  const wrapManagedSession = (session: NativeSession): NativeSession => {
    if (!input.managedAiCredentialHome || input.execution.provider.kind !== "codex" || boundManagedSessions.has(session)) return session;
    boundManagedSessions.add(session);
    const remoteAuth = remoteRunnerFilesystemRoot ? posix.join(remoteRunnerFilesystemRoot, "codex-home", "auth.json") : null;
    const localAuth = join(root, "codex-home", "auth.json");
    return bindManagedNativeCredentialTurn(session, {
      copyBack: async () => {
        await copyBackCodexAuth({
          hostAuthPath: join(input.managedAiCredentialHome!, "auth.json"),
          readSandboxAuth: async () => {
            if (!remoteAuth || !remoteCommandRunner) return readFileSync(localAuth);
            const result = await remoteCommandRunner.execute({ command: "base64", args: [remoteAuth], bypassSession: true, timeoutMs: 10000 });
            if (result.exitCode !== 0 || result.timedOut) throw new Error("AI credential copy-back failed");
            return Buffer.from(result.stdout, "base64");
          },
          log: () => {},
        });
      },
      remove: async () => {
        rmSync(localAuth, { force: true });
        if (remoteAuth && remoteCommandRunner) await remoteCommandRunner.execute({ command: "rm", args: ["-f", "--", remoteAuth], bypassSession: true, timeoutMs: 10000 });
      },
    });
  };
  const priorAuthorityEpoch = sessionToolAuthorityEpochs.get(sessionScopeId);
  if (priorAuthorityEpoch && priorAuthorityEpoch !== authorityEpoch) {
    priorAuthorityEpoch.revoke();
  }
  sessionToolAuthorityEpochs.set(sessionScopeId, authorityEpoch);
  return {
    bindManagedSession: wrapManagedSession,
    descriptor: () => backend.descriptor(),
    openSession: async (sessionInput) => wrapManagedSession(await backend.openSession(sessionInput)),
    recoverSession: async (snapshot, options) => {
      const result = backend.recoverSession ? await backend.recoverSession(snapshot, options) : { recovered: false, reason: "driver does not support recovery" };
      return result.session ? { ...result, session: wrapManagedSession(result.session) } : result;
    },
    openReplacementSession: async (sessionInput) => {
      await measureNativeRunnerSpan(
        input.trace,
        "provider.session.archive_before_replacement",
        archiveContinuityState,
        { parentName: "native.session.execute" },
      );
      return wrapManagedSession(await backend.openSession(sessionInput));
    },
  } satisfies NativeSessionBackend & { bindManagedSession(session: NativeSession): NativeSession };
}
