# V10-169 current software gap audit — 2026-10-30

## Decision summary

This is a read-only source review against the original 169-row register and the binding V10 brief. The generated safe-change crosswalk is useful for navigation, but its status values are not acceptance evidence. I found four concrete software gaps that remain visible in current owners, plus one operating-knowledge inventory gap. These findings are separate from the active Native-9, resource-cleanup, §17 scanner, Project-finalization, Learning, and CI work the root agent already identified.

The strongest implementation candidates are: (1) company-scoped customer-success outcome/effort projection, (2) actual satisfaction/effort collection and reporting, (3) connector feed cursor/watermark and missed-event detection, and (4) a usable cross-source customer-problem classification rather than an `unknown`-only DTO. A required legacy Skill migration register and runtime-evaluation harness are also absent. External provider/runtime, operator, and Human qualification remain separate from these software gaps.

## Scope and evidence basis

I read the binding brief and the original recovery register directly: `doc/reference/blentera-v10/Blentera_Master_Build_Brief_V10_FINAL_v4.0_2026-10-18.md` and `doc/operations/aw-v10-evidence/recovery-2026-10-22/requirement-reconciliation.json`. The original register has 169 rows, was recorded 2026-10-22 and reviewed 2026-10-28, and labels itself a “source work catalogue and reconciliation index; not acceptance evidence.” Its reconciliation totals are 81 `partial_implementation_open`, 39 `no_scoped_evidence_located_open`, 22 `current_bounded_work_open`, 17 `historical_partial_evidence_open`, and 10 `implemented_unqualified_open`.

The current generated `v10-safe-change-graph.source.json` has 169 crosswalk rows, 123 marked `partial_implementation`, and has explicitly limited scope. I did not promote any status because a generated row or source path exists. I inspected the binding clauses in §§8, 23.5–23.6, 27.7 and the enumerated V10 work catalogue, then read the current typed owners listed below. I did not run tests or alter repository code.

For breadth, I also compared the 2026-10-29 current-r2 reconciliation candidate’s exact linked targets with the present worktree. Its prior snapshot identifies 1,669 references across all 169 rows: 1,654 file references, 11 directory references, one symbol reference, and three already-missing snapshot references. Of the file references, 57 files now differ from the candidate’s recorded hash, touching 81 requirement rows; the three missing references are the recorded 0502/0514 Drizzle snapshots for V10-158, V10-166 and V10-167. Those are pin drift and inventory facts, not proof of product gaps or a reason to restore generated snapshots. The candidate was based on `bc9ac00874634442e034f7fcff06a10919b21141`; current HEAD during this audit is `fcec9c5a5e2a7eb7a3cdfd50d54de96a49a8e1ff`, with a dirty worktree. Re-pin before using any old source receipt as current evidence.

## Prioritized software gaps

### P1 — V10-099: internal company/customer-success projection is not implemented

The brief’s §23.6 projection is company-specific and includes activation incomplete, first value not reached, critical connector broken, unresolved blocking support case, repeated recovery failure, aging critical Action needed, and managed runtime unhealthy. The current `server/src/routes/service-health.ts` exposes only `/api/service-status`; it has no company parameter or authorization and returns `managedServiceHealthFromEnvironment`. Its owner is explicitly a read-only managed-provider public Statuspage adapter (`server/src/services/experience/service-health.ts`); it returns global component/incidents and hard-codes `customerImpact: "unknown"`. It cannot answer the six tenant-specific signals in §23.6.

**Implement:** a restricted internal projection with per-signal source, freshness, missing/unavailable state, and company authorization; consume the existing activation, connector, support, recovery/Action-needed, and managed-runtime owners without combining them into a hidden quality score. Keep the public Statuspage endpoint separate.

**Separate qualification:** verify actual source coverage, privacy minimization, access policy, operator use, and production data freshness. Those do not substitute for the missing company-scoped projection software.

### P1 — V10-097 / §23.5: the measure pack documents missing data but does not measure satisfaction or effort

`packages/shared/src/customer-success-quality.ts` defines a measurement pack and explicitly says no new collection, survey, telemetry, or stored analytics dataset is enabled; `currentAvailability` says no structured satisfaction rating and no direct effort measure are recorded. The current `customer_feedback` schema stores category/body/goal/blocker/context and triage state, not a task-context satisfaction/effort observation (`packages/db/src/schema/customer_feedback.ts:17–39`). `support_cases` stores impact and case lifecycle, not a post-resolution rating or effort value (`packages/db/src/schema/support_cases.ts:9–32`). The pack itself calls feedback and resolution qualitative/process proxies and says neither establishes satisfaction or effort (`customer-success-quality.ts:76–118`).

The brief asks to monitor satisfaction using multiple proxies (§23.5) and §8 binds customer effort to required choices, corrections, backtracks, help dependency, and task success with context and denominator. A definitions-only pack cannot produce the values or response-coverage denominator.

**Implement:** a consented, task-bound satisfaction/effort response contract and storage/read path, with explicit population, denominator, missingness, withdrawal, retention, and source/version. Keep responses optional, separate satisfaction from task success and activation, and do not infer from silence, clicks, or support resolution.

**Separate qualification:** representative research, bilingual comprehension, sampling adequacy, customer acceptance, and privacy/operator approval remain Human/operator evidence.

### P1 — V10-069 / V10-072: connector delivery IDs are idempotent, but feed completeness is unobservable

Current lifecycle DTOs deliberately expose `cursor`, `watermark`, `gapDetection`, and `rateLimitState` only as `"not_reported"` (`packages/shared/src/types/tool-access.ts:246–262`; `server/src/services/tool-connection-lifecycle.ts:178–191`). The implemented reconciliation is GitHub repository-access full-snapshot state, whose timestamp is explicitly not a feed cursor or content-sync watermark. The GitHub event receipt table deduplicates provider delivery IDs and stores processed/failed attempts (`packages/db/src/schema/connection_event_deliveries.ts:11–38`); the consumer replays failed receipts idempotently (`server/src/services/github-connection-events.ts:339–369`). This handles known delivery retries but cannot detect a missing webhook or missed provider event between receipts.

**Implement:** a provider-capability contract for event cursor/watermark, expected freshness, gap detection, and a bounded delta/full-reconcile recovery path. Preserve `not_reported` when the provider cannot supply a signal; do not present receipt timestamps or opaque delivery IDs as completeness proof. Add fault cases for lost delivery, duplicate/reordered delivery, cursor expiry/reset, reconnect, and full-reconcile recovery.

**Separate qualification:** provider-specific cursor guarantees, retry behavior, and installed credential/webhook operation need current provider documentation and live/provider evidence. The generic framework and negative tests are software work.

### P2 — V10-094: the shared customer-problem taxonomy is present as a shell, but not as a usable classification contract

Current code has a source enum spanning feedback, support, incidents, studies, effort, activation, connection failure, procurement, churn, and outcomes (`packages/shared/src/customer-problem-evidence.ts:3–18`) and a `CUSTOMER_PROBLEM_AREAS` enum (`packages/shared/src/customer-success-quality.ts:8–20`). However, the base schema fixes `classification` to the single literal `"unknown"` (`customer-problem-evidence.ts:21–28`), and `CUSTOMER_PROBLEM_AREAS` has no consumer in the current tree. The actual discriminated projection only supports `product_feedback` and `support_case` (`customer-success-quality.ts:34–48`), and both projection functions always emit `classification: "unknown"` (`:50–73`). Incident, usability/accessibility study, customer effort, connection failure, procurement, churn, and business-outcome source values have no corresponding source-owner projection in this union.

**Implement:** an authorized classification record with the declared area/impact and provenance/version, plus source-owner projections for the sources actually enabled. Preserve native source category/lifecycle and company scoping; do not grant access to source rows through the evidence pointer. If Human classification is required, provide the canonical issue/decision artifact field and read path so the classification can be recorded and retrieved; the current contract only documents that intent.

**Separate qualification:** source-owner approvals and privacy/consent policy for each new evidence type remain required; unused source enum entries do not mean those data sources are available.

### P2 — V10-131 / V10-140 / V10-143: migration register and runtime conformance harness are missing

There is no current migration inventory that maps each legacy Paperclip Skill/AGENTS/Hermes instruction to its Blentera release version/digest, runtime destination, precedence, shadow-collision disposition, and sunset/rollback policy. Both the large legacy `skills/paperclip/SKILL.md` and the current `skills/blentera-platform/SKILL.md` remain. The V10-145 corpus tests Skill text through Promptfoo; that is not an adapter conformance driver. Current `runtimeProfiles` explicitly do not claim OpenClaw/Hermes/A2A-custom as GA.

I verified Hermes delivery code is present: its executor requires exactly one admitted `blentera-platform` entry, reads the release files, rejects a stale session profile hash, and prepares a dedicated isolated profile (`packages/adapters/hermes/src/server/execute.ts:372–379`; `governed-profile.ts`). I therefore do **not** classify Hermes Skill delivery implementation as absent. The gap is the required source-to-runtime migration/precedence register and a common executable conformance suite that sends the same positive, negative, stale-pin, collision, and recovery scenarios through each claimed runtime’s actual adapter dispatch.

**Implement:** the migration register and shared adapter conformance runner. Keep unqualified profiles unavailable until exact installed versions and results are recorded. The external installed-runtime/provider runs and Human platform-owner review remain separate qualification gates.

## Explicitly not counted as software gaps

- Hermes isolated-profile Skill delivery and collision guards have current implementation code; runtime/provider qualification is still open.
- The public managed Statuspage adapter is intentionally separate and working within its narrower global/public scope; it does not satisfy the internal tenant projection.
- Existing connector delivery receipts and GitHub repository-access full snapshots are useful bounded mechanisms; they do not prove event-feed completeness.
- The current shared measure pack correctly states its missing-data limits. The gap is actual measurement and projection software, not permission to infer quality from activity.
- External domain ownership, provider webhook guarantees, deployed runtime compatibility, live data coverage, representative research, bilingual/customer usability, and operator/Human sign-off are qualification tasks, not code closure.

## Source pins

Current HEAD: `fcec9c5a5e2a7eb7a3cdfd50d54de96a49a8e1ff` (dirty worktree). SHA-256 pins for the binding brief, original register, current generated graph, prior reconciliation candidate, and principal current owners:

| Path | SHA-256 |
|---|---|
| `doc/reference/blentera-v10/Blentera_Master_Build_Brief_V10_FINAL_v4.0_2026-10-18.md` | `7f4387338e6c9ce82359801a92c802c55b9af5c92cd65d1b6271f8ae68970c22` |
| `doc/operations/aw-v10-evidence/recovery-2026-10-22/requirement-reconciliation.json` | `63fc64316d59206557d94497f6efeb8c0c0f45123bd1513f7a9d2e53c30d84b3` |
| `doc/operations/v10-safe-change-graph.source.json` | `0bcd53b6098331f9545bb7d605be290d6f34de58870addbabed58709f377f919` |
| `/workspace/v10-preparation/v10-requirement-implementation-reconciliation-candidate-current-r2-20261029.json` | `7503087c46a0973f96243cadb92d1bd57e29c0ac0ff00121f6c16e9e0e086cb4` |
| `packages/shared/src/customer-problem-evidence.ts` | `6361a2a79c07e2c2040972b89f2774b8297d8032137a310eafcc7a403a5262e9` |
| `packages/shared/src/customer-success-quality.ts` | `21139743ecf50b437289bb6e3215611546b28d608e552022a742399810a7a6b1` |
| `packages/db/src/schema/customer_feedback.ts` | `006577679e0f3af548f9d75b51880e15cac67f49297f76ba336ca072ce474be8` |
| `packages/db/src/schema/support_cases.ts` | `69b01365fc5d46b668ee451f3be1384a544371a2976fb095affa54dec0166d36` |
| `server/src/routes/service-health.ts` | `bdf5a7eef496817669c1f21a67637636534d3eef548f44676a0f9c91b982cf82` |
| `server/src/services/experience/service-health.ts` | `a7bbe53bb978cb192b1b598bcc34f3afc314a08c26f7cc13438d6c34d4406972` |
| `packages/shared/src/types/tool-access.ts` | `40977a017dcf8e487ce4d8981dbee133b0015d5b36180ab6401b68c07a6b5e9f` |
| `server/src/services/tool-connection-lifecycle.ts` | `6eb1e16d6189cb2072ca9dcecf41476db6cc2df7dbfe83a612a5f9a1f2ecdf2a` |
| `packages/db/src/schema/connection_event_deliveries.ts` | `6e79eb2f98e9ca7b0836ebc594386e7f3d9d92ff52bd0752be8ffd292bad104c` |
| `server/src/services/github-connection-events.ts` | `db225b77599cc9bd84c3bd02d6038f4d10000bfecbca93bf964359da0f6175f8` |
| `packages/adapters/hermes/src/server/execute.ts` | `a67a8f544769d138b43c8e9df39901463a275cb3dd40f1edb3fa79a8d4d2589d` |
| `packages/adapters/hermes/src/server/governed-profile.ts` | `1b94bd13ac1a8e39e07b39951b95c3967c0779c44495027db6018770f203db7e` |
