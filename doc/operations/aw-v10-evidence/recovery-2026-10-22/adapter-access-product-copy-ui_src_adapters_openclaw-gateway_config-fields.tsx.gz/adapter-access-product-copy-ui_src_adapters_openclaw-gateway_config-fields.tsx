import { configFieldsForSection } from "../config-sections";
import { useEffect, useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import type { AdapterConfigFieldsProps } from "../types";
import {
  Field,
  DraftInput,
  help,
} from "../../components/agent-config-primitives";
import {
  PayloadTemplateJsonField,
  RuntimeServicesJsonField,
} from "../runtime-json-fields";
import { PRODUCT_IDENTITY } from "@paperclipai/shared/product-identity";

const inputClass =
  "w-full rounded-md border border-border px-2.5 py-1.5 bg-transparent outline-none text-sm font-mono placeholder:text-muted-foreground/40";

function HeadersJsonTextarea({
  isCreate,
  createDraft,
  onCreateDraftChange,
  editStringified,
  onEditCommit,
  inputClass,
}: {
  isCreate: boolean;
  createDraft: string;
  onCreateDraftChange: (next: string) => void;
  editStringified: string;
  onEditCommit: (next: string) => void;
  inputClass: string;
}) {
  const [editDraft, setEditDraft] = useState<string>(editStringified);
  const [lastSyncedFromConfig, setLastSyncedFromConfig] = useState<string>(editStringified);
  useEffect(() => {
    if (isCreate) return;
    if (editStringified !== lastSyncedFromConfig) {
      setEditDraft(editStringified);
      setLastSyncedFromConfig(editStringified);
    }
  }, [editStringified, isCreate, lastSyncedFromConfig]);
  const value = isCreate ? createDraft : editDraft;
  return (
    <textarea
      value={value}
      onChange={(e) => {
        const next = e.target.value;
        if (isCreate) {
          onCreateDraftChange(next);
        } else {
          setEditDraft(next);
          onEditCommit(next);
        }
      }}
      rows={3}
      className={inputClass}
      placeholder='{"x-custom-header": "value"}'
    />
  );
}

function SecretField({
  label,
  value,
  onCommit,
  placeholder,
}: {
  label: string;
  value: string;
  onCommit: (v: string) => void;
  placeholder?: string;
}) {
  const [visible, setVisible] = useState(false);
  return (
    <Field label={label}>
      <div className="relative">
        <button
          type="button"
          onClick={() => setVisible((v) => !v)}
          className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground/50 hover:text-muted-foreground transition-colors"
        >
          {visible ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5" />}
        </button>
        <DraftInput
          value={value}
          onCommit={onCommit}
          immediate
          type={visible ? "text" : "password"}
          className={inputClass + " pl-8"}
          placeholder={placeholder}
        />
      </div>
    </Field>
  );
}

function parseScopes(value: unknown): string {
  if (Array.isArray(value)) {
    return value.filter((entry): entry is string => typeof entry === "string").join(", ");
  }
  return typeof value === "string" ? value : "";
}

export function OpenClawGatewayConfigFields({
  section,
  isCreate,
  values,
  set,
  config,
  eff,
  mark,
}: AdapterConfigFieldsProps) {
  const configuredHeaders =
    config.headers && typeof config.headers === "object" && !Array.isArray(config.headers)
      ? (config.headers as Record<string, unknown>)
      : {};
  const effectiveHeaders =
    (eff("adapterConfig", "headers", configuredHeaders) as Record<string, unknown>) ?? {};

  const effectiveGatewayToken = typeof effectiveHeaders["x-openclaw-token"] === "string"
    ? String(effectiveHeaders["x-openclaw-token"])
    : typeof effectiveHeaders["x-openclaw-auth"] === "string"
      ? String(effectiveHeaders["x-openclaw-auth"])
      : "";

  const commitGatewayToken = (rawValue: string) => {
    const nextValue = rawValue.trim();
    const nextHeaders: Record<string, unknown> = { ...effectiveHeaders };
    if (nextValue) {
      nextHeaders["x-openclaw-token"] = nextValue;
      delete nextHeaders["x-openclaw-auth"];
    } else {
      delete nextHeaders["x-openclaw-token"];
      delete nextHeaders["x-openclaw-auth"];
    }
    mark("adapterConfig", "headers", Object.keys(nextHeaders).length > 0 ? nextHeaders : undefined);
  };

  const sessionStrategy = eff(
    "adapterConfig",
    "sessionKeyStrategy",
    String(config.sessionKeyStrategy ?? "fixed"),
  );

  return configFieldsForSection(section, (
    <>
      <Field label="Gateway URL" hint={help.webhookUrl}>
        <DraftInput
          value={
            isCreate
              ? values!.url
              : eff("adapterConfig", "url", String(config.url ?? ""))
          }
          onCommit={(v) =>
            isCreate
              ? set!({ url: v })
              : mark("adapterConfig", "url", v || undefined)
          }
          immediate
          className={inputClass}
          placeholder="ws://127.0.0.1:18789"
        />
      </Field>

      <PayloadTemplateJsonField
        isCreate={isCreate}
        values={values}
        set={set}
        config={config}
        mark={mark}
      />

      {/* Auth and Identity - available in both create and edit modes */}
      <SecretField
        label="Gateway auth token"
        value={
          isCreate
            ? values!.authToken ?? ""
            : effectiveGatewayToken
        }
        onCommit={(v) =>
          isCreate
            ? set!({ authToken: v })
            : commitGatewayToken(v)
        }
        placeholder="OpenClaw gateway token"
      />

      <Field label="Agent ID">
        <DraftInput
          value={
            isCreate
              ? values!.agentId ?? ""
              : eff("adapterConfig", "agentId", String(config.agentId ?? ""))
          }
          onCommit={(v) =>
            isCreate
              ? set!({ agentId: v })
              : mark("adapterConfig", "agentId", v || undefined)
          }
          immediate
          className={inputClass}
          placeholder="agent-123"
        />
      </Field>

      <Field label="Session strategy">
        <select
          value={
            isCreate
              ? values!.sessionKeyStrategy ?? "fixed"
              : sessionStrategy
          }
          onChange={(e) =>
            isCreate
              ? set!({ sessionKeyStrategy: e.target.value })
              : mark("adapterConfig", "sessionKeyStrategy", e.target.value)
          }
          className={inputClass}
        >
          <option value="fixed">Fixed</option>
          <option value="issue">Per issue</option>
          <option value="run">Per run</option>
        </select>
      </Field>

      {(isCreate ? values!.sessionKeyStrategy ?? "fixed" : sessionStrategy) === "fixed" && (
        <Field label="Session key">
          <DraftInput
            value={
              isCreate
                ? values!.sessionKey ?? ""
                : eff("adapterConfig", "sessionKey", String(config.sessionKey ?? "paperclip"))
            }
            onCommit={(v) =>
              isCreate
                ? set!({ sessionKey: v })
                : mark("adapterConfig", "sessionKey", v || undefined)
            }
            immediate
            className={inputClass}
            placeholder="paperclip"
          />
        </Field>
      )}

      <SecretField
        label="Password (alternative auth)"
        value={
          isCreate
            ? values!.password ?? ""
            : eff("adapterConfig", "password", String(config.password ?? ""))
        }
        onCommit={(v) =>
          isCreate
            ? set!({ password: v })
            : mark("adapterConfig", "password", v || undefined)
        }
        placeholder="Gateway shared password"
      />

      <Field label="Role">
        <DraftInput
          value={
            isCreate
              ? values!.role ?? ""
              : eff("adapterConfig", "role", String(config.role ?? "operator"))
          }
          onCommit={(v) =>
            isCreate
              ? set!({ role: v })
              : mark("adapterConfig", "role", v || undefined)
          }
          immediate
          className={inputClass}
          placeholder="operator"
        />
      </Field>

      <Field label="Scopes (comma-separated)">
        <DraftInput
          value={
            isCreate
              ? values!.scopes ?? ""
              : eff("adapterConfig", "scopes", parseScopes(config.scopes ?? ["operator.admin"]))
          }
          onCommit={(v) => {
            const parsed = v
              .split(",")
              .map((entry) => entry.trim())
              .filter(Boolean);
            if (isCreate) {
              set!({ scopes: v });
            } else {
              mark("adapterConfig", "scopes", parsed.length > 0 ? parsed : undefined);
            }
          }}
          immediate
          className={inputClass}
          placeholder="operator.admin"
        />
      </Field>

      <RuntimeServicesJsonField
        isCreate={isCreate}
        values={values}
        set={set}
        config={config}
        mark={mark}
      />

      <Field label={`${PRODUCT_IDENTITY.productName} API URL override`}>
        <DraftInput
          value={
            isCreate
              ? values!.paperclipApiUrl ?? ""
              : eff("adapterConfig", "paperclipApiUrl", String(config.paperclipApiUrl ?? ""))
          }
          onCommit={(v) =>
            isCreate
              ? set!({ paperclipApiUrl: v })
              : mark("adapterConfig", "paperclipApiUrl", v || undefined)
          }
          immediate
          className={inputClass}
          placeholder={PRODUCT_IDENTITY.appOrigin}
        />
      </Field>

      <Field configSection="runPolicy" label="Timeout (seconds)">
        <DraftInput
          value={
            isCreate
              ? values!.timeoutSec != null ? String(values!.timeoutSec) : ""
              : eff("adapterConfig", "timeoutSec", String(config.timeoutSec ?? ""))
          }
          onCommit={(v) => {
            const parsed = Number.parseInt(v.trim(), 10);
            const val = Number.isFinite(parsed) && parsed > 0 ? parsed : undefined;
            if (isCreate) {
              set!({ timeoutSec: val });
            } else {
              mark("adapterConfig", "timeoutSec", val);
            }
          }}
          immediate
          className={inputClass}
          placeholder="120"
        />
      </Field>

      <Field label="Headers JSON">
        <HeadersJsonTextarea
          isCreate={isCreate}
          createDraft={isCreate ? values!.headersJson ?? "" : ""}
          onCreateDraftChange={(next) => set!({ headersJson: next })}
          editStringified={JSON.stringify(eff("adapterConfig", "headers", config.headers ?? {}), null, 2)}
          onEditCommit={(next) => {
            const trimmed = next.trim();
            if (!trimmed) {
              mark("adapterConfig", "headers", undefined);
              return;
            }
            try {
              const parsed = JSON.parse(trimmed);
              if (typeof parsed === "object" && parsed !== null && !Array.isArray(parsed)) {
                mark("adapterConfig", "headers", parsed);
              }
            } catch {
              // Keep local draft until JSON is valid
            }
          }}
          inputClass={inputClass}
        />
      </Field>

      {!isCreate && (
        <Field label="Claimed API key path">
          <DraftInput
            value={eff("adapterConfig", "claimedApiKeyPath", String(config.claimedApiKeyPath ?? ""))}
            onCommit={(v) => mark("adapterConfig", "claimedApiKeyPath", v || undefined)}
            immediate
            className={inputClass}
            placeholder="~/.openclaw/workspace/paperclip-claimed-api-key.json"
          />
        </Field>
      )}

      <Field configSection="runPolicy" label="Wait timeout (ms)">
        <DraftInput
          value={
            isCreate
              ? values!.waitTimeoutMs != null
                ? String(values!.waitTimeoutMs)
                : ""
              : eff("adapterConfig", "waitTimeoutMs", String(config.waitTimeoutMs ?? "120000"))
          }
          onCommit={(v) => {
            const parsed = Number.parseInt(v.trim(), 10);
            const next = Number.isFinite(parsed) && parsed > 0 ? parsed : undefined;
            if (isCreate) {
              set!({ waitTimeoutMs: next });
            } else {
              mark("adapterConfig", "waitTimeoutMs", next);
            }
          }}
          immediate
          className={inputClass}
          placeholder="120000"
        />
      </Field>

      <Field label="Disable device auth">
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={
              isCreate
                ? values!.disableDeviceAuth ?? false
                : eff("adapterConfig", "disableDeviceAuth", Boolean(config.disableDeviceAuth ?? false))
            }
            onChange={(e) =>
              isCreate
                ? set!({ disableDeviceAuth: e.target.checked })
                : mark("adapterConfig", "disableDeviceAuth", e.target.checked || undefined)
            }
          />
          Skip device key authentication
        </label>
      </Field>

      <Field label="Auto-pair on first connect">
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={
              isCreate
                ? values!.autoPairOnFirstConnect ?? true
                : eff("adapterConfig", "autoPairOnFirstConnect", config.autoPairOnFirstConnect !== false)
            }
            onChange={(e) =>
              isCreate
                ? set!({ autoPairOnFirstConnect: e.target.checked })
                : mark("adapterConfig", "autoPairOnFirstConnect", e.target.checked)
            }
          />
          Automatically approve device pairing
        </label>
      </Field>

      <Field label="Device auth">
        <div className="text-xs text-muted-foreground leading-relaxed">
          When enabled, {PRODUCT_IDENTITY.productName} persists a device key during onboarding so pairing approvals
          remain stable across runs.
        </div>
      </Field>
    </>
  ));
}
