#!/usr/bin/env python3
"""Reporting mechanics only: tiny actual Vitest workspaces, no repository suites."""
from pathlib import Path
import argparse, fcntl, hashlib, json, os, shutil, signal, subprocess, time
MAIN=Path('/workspace/blentera-v10'); DEPS=Path('/workspace/v10-dep-qualification')
PACKET=Path('/workspace/v10-preparation/vitest-durable-module-reporting-20261102/r2')
HEAD='003404c031dad874db43aa1ad8c07e80568bdd17'
PINS='f6c88838fa0f35566d91b733b742d0aaa1a400fea23dfe894c9117a7c43ebf1e'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=argparse.ArgumentParser();a.add_argument('--output',type=Path,required=True);args=a.parse_args()
if not args.output.is_absolute() or not args.output.resolve().is_relative_to(Path('/workspace/v10-preparation/vitest-durable-module-reporting-20261102/r3')) or args.output.exists():raise SystemExit('unique absent R3 output required')
if sha(PACKET/'source-pins.json')!=PINS:raise SystemExit('frozen R2 pins changed')
rows=json.loads((PACKET/'source-pins.json').read_text())['files']; bypath={r['path']:r for r in rows}
HELPERS=['scripts/general-server-shard.mjs','scripts/test-line-shard.mjs','scripts/general-server-shard-durations.json','scripts/serialized-shard-durations.json']
REPORTER='scripts/vitest-module-results-reporter.mjs';RUNNER='scripts/run-vitest-stable.mjs'
RSS_LIMIT=768*1024

def ensure(value,message):
 if not value:raise RuntimeError(message)
def members(group):
 result=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   raw=(p/'stat').read_text();fields=raw[raw.rfind(') ')+2:].split()
   if int(fields[2])==group and int(fields[3])==group:
    result.append({'pid':int(p.name),'state':fields[0],'rssKiB':int((p/'statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')//1024})
  except (FileNotFoundError,ProcessLookupError):pass
 return result
def close_owned(p):
 for sig,seconds in [(signal.SIGTERM,2),(signal.SIGKILL,3)]:
  try:os.killpg(p.pid,sig)
  except ProcessLookupError:pass
  until=time.monotonic()+seconds
  while time.monotonic()<until:
   p.poll()
   if not members(p.pid):break
   time.sleep(.05)
  if not members(p.pid):break
 p.wait(timeout=3)
 return members(p.pid)
def clean():return all(subprocess.run(cmd,cwd=MAIN).returncode==0 for cmd in [['git','diff','--quiet'],['git','diff','--cached','--quiet']])
def events():return Path('/sys/fs/cgroup/memory.events').read_text()

with Path('/workspace/v10-preparation/v10-pg-tests.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 ensure(subprocess.check_output(['git','rev-parse','HEAD'],cwd=MAIN,text=True).strip()==HEAD and clean(),'actual clean Main003 required')
 ensure(shutil.disk_usage('/workspace').free>=120000*1024 and shutil.disk_usage('/tmp').free>=1048576*1024,'original resource floors not met')
 ensure(json.loads((DEPS/'node_modules/vitest/package.json').read_text())['version']=='4.1.11','existing installed Vitest4.1.11 required')
 for row in rows:ensure(sha(Path(row['candidateSource']))==row['candidateSha256'],'candidate changed')
 before={name:sha(MAIN/name) for name in HELPERS+[RUNNER,'.github/workflows/pr-trusted.yml']}
 args.output.mkdir(parents=True); report=args.output/'results';report.mkdir(); provenance=args.output/'runtime-provenance.jsonl'
 result={'status':'RUNNING','scope':'Synthetic reporting mechanics only; no DB/SDK/browser/compiler/build/paid calls or real suite qualification',
  'currentMain':HEAD,'candidateSourceParent':'c80b6f6f2fe4380fd4e1bcd7e6c6d336aebbcbd7','candidatePinsSha256':PINS,
  'workflowScope':'Old frozen c80 candidate hash only; NOT applied or qualified as current Main003 workflow; preserve current kernel9654 on future composition.',
  'rssLimitKiB':RSS_LIMIT,'heapMiB':512,'wallSeconds':60,'peakOwnedTotalRssKiB':0,'commands':[],'memoryEventsBefore':events(),'sourceCopies':[]}
 started=time.monotonic(); active=None
 def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
 def copy(src,dst):dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst);ensure(not dst.is_symlink() and sha(src)==sha(dst),'copy provenance');result['sourceCopies'].append({'path':str(dst),'sha256':sha(dst)})
 # The workflow is never executed or installed in any synthetic workspace.
 copy(Path(bypath['.github/workflows/pr-trusted.yml']['candidateSource']),args.output/'static-inputs/pr-trusted.yml')
 expected={}
 def workspace(name,projects):
  root=args.output/name;root.mkdir();(root/'server/src').mkdir(parents=True)
  write(root/'package.json',json.dumps({'name':'private-reporting-controls','private':True,'type':'module'}))
  modules=root/'node_modules';modules.mkdir()
  for dependency in (DEPS/'node_modules').iterdir():
   if dependency.name not in ['.vite','.vite-temp','.cache']: (modules/dependency.name).symlink_to(dependency,target_is_directory=dependency.is_dir())
  for rel in [RUNNER,REPORTER]:
   copy(Path(bypath[rel]['candidateSource']),root/rel);expected[str(root/rel)]=bypath[rel]['candidateSha256']
  copy(MAIN/RUNNER,root/'scripts/run-vitest-stable.original.mjs');expected[str(root/'scripts/run-vitest-stable.original.mjs')]=sha(MAIN/RUNNER)
  for rel in HELPERS:copy(MAIN/rel,root/rel)
  plugin='''{name:'exact-reporting-candidate',enforce:'pre',transform(code,id){const file=id.split('?')[0];if(!file.endsWith('/vitest-module-results-reporter.mjs'))return null;const actual=fs.realpathSync(file),expected=JSON.parse(fs.readFileSync(process.env.AW_REPORTING_EXPECTED,'utf8'));if(!expected[actual]||crypto.createHash('sha256').update(fs.readFileSync(actual)).digest('hex')!==expected[actual])throw Error('candidate reporter escaped');fs.appendFileSync(process.env.AW_REPORTING_PROVENANCE,JSON.stringify({role:'vite-load',path:actual,sha256:expected[actual]})+String.fromCharCode(10));return null;}}'''
  write(root/'vitest.config.mjs',"import {defineConfig} from 'vitest/config';import fs from 'node:fs';import crypto from 'node:crypto';\nexport default defineConfig({cacheDir:"+json.dumps(str(root/'.vite-cache'))+",plugins:["+plugin+"],test:{projects:"+json.dumps(list(projects))+",cache:false}});\n")
  for directory,name in projects.items():
   write(root/directory/'vitest.config.mjs',"import {defineConfig} from 'vitest/config';export default defineConfig({cacheDir:"+json.dumps(str(root/directory/'.vite-cache'))+",test:{name:"+json.dumps(name)+",include:['src/**/*.test.ts'],environment:'node',pool:'forks',maxWorkers:1,minWorkers:1,fileParallelism:false,cache:false,testTimeout:4000,hookTimeout:1000}});\n")
  return root
 normal=workspace('normal',{'server':'@paperclipai/server','ui':'@paperclipai/ui','cli':'paperclipai'})
 # Two real child invocations prove unique output and actual remaining budget.
 # Formatting/cap mechanics are checked separately with fixed pure data.
 for i in range(1):
  write(normal/f'ui/src/pass-{i:02}.test.ts',"import {it,expect} from 'vitest';import fs from 'node:fs';import path from 'node:path';it('normal UI reporting case',()=>{expect(true).toBe(true);fs.writeFileSync(path.join(process.env.PAPERCLIP_VITEST_INVOCATION_REPORT_DIR,'worker-budget.json'),JSON.stringify({budget:Number(process.env.PAPERCLIP_VITEST_NOTICE_BUDGET)}));});\n")
 for i in range(1):
  write(normal/f'cli/src/pass-{i:02}.test.ts',"import {it,expect} from 'vitest';import fs from 'node:fs';import path from 'node:path';it('normal CLI reporting case',()=>{expect(true).toBe(true);fs.writeFileSync(path.join(process.env.PAPERCLIP_VITEST_INVOCATION_REPORT_DIR,'worker-budget.json'),JSON.stringify({budget:Number(process.env.PAPERCLIP_VITEST_NOTICE_BUDGET)}));});\n")
 failed=workspace('after-all-failure',{'server':'@paperclipai/server'})
 write(failed/'server/src/after-all.test.ts',"import {it,expect,afterAll} from 'vitest';it('body passes',()=>expect(true).toBe(true));afterAll(()=>{throw new Error('REPORTING_AFTER_ALL_SENTINEL');});\n")
 crashed=workspace('owned-worker-exit',{'server':'@paperclipai/server'})
 write(crashed/'server/src/worker-exit.test.ts',"import {it,expect} from 'vitest';it('earlier body returns',()=>expect(true).toBe(true));it('owned worker exits',()=>{process.kill(process.pid,'SIGKILL');});\n")
 unset=workspace('reporting-unset',{'server':'@paperclipai/server'})
 write(unset/'server/src/pass.test.ts',"import {it,expect} from 'vitest';it('default remains ordinary',()=>{expect(process.env.PAPERCLIP_VITEST_REPORT_DIR).toBeUndefined();expect(true).toBe(true);});\n")
 expected_file=args.output/'expected.json';write(expected_file,json.dumps(expected))
 preload=args.output/'provenance-preload.mjs'
 write(preload,"""import fs from 'node:fs';import crypto from 'node:crypto';import {registerHooks} from 'node:module';import {fileURLToPath} from 'node:url';
const expected=JSON.parse(fs.readFileSync(process.env.AW_REPORTING_EXPECTED,'utf8'));
function observe(file,role){const actual=fs.realpathSync(file);if(!expected[actual])return;if(crypto.createHash('sha256').update(fs.readFileSync(actual)).digest('hex')!==expected[actual])throw Error('candidate SHA changed');fs.appendFileSync(process.env.AW_REPORTING_PROVENANCE,JSON.stringify({role,path:actual,sha256:expected[actual]})+String.fromCharCode(10));}
if(process.argv[1]&&Object.hasOwn(expected,process.argv[1]))observe(process.argv[1],'node-entry');
registerHooks({load(url,context,next){if(url.startsWith('file:')){const file=fileURLToPath(url);if(file.endsWith('/vitest-module-results-reporter.mjs'))observe(file,'node-load');}return next(url,context);}});
""")
 write(args.output/'formatter.mjs',"""import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';import ModuleResultsReporter,{moduleObservation,moduleNotice} from '"""+(normal/REPORTER).as_uri()+"""';
const fake={moduleId:'/controlled/../outside.test.ts',state:()=> 'failed',children:{*allTests(){for(let i=0;i<7;i++)yield{result:()=>({state:'failed'}),fullName:'::error%0A\\r\\n'+('x'.repeat(300))};}}};
const observation=moduleObservation(fake,'/controlled');assert.equal(observation.file,'external-module');assert.equal(observation.state,'failed');assert.equal(observation.counts.failed,7);assert.equal(observation.failedCaseNames.length,5);assert(observation.failedCaseNamesTruncated);assert(observation.failedCaseNames.every(name=>name.length<=160));const line=moduleNotice(observation,'a'.repeat(64)+'.json');assert(!line.includes('\\n')&&!line.includes('\\r'));assert(line.includes('%250A'));assert(line.includes('processExit=pending'));assert(line.includes('module=failed'));assert(line.length<=13000);
// Fixed public task/module data exercises only notice/cap machinery. These
// fabricated records are outside actual result dirs and are NOT test passes.
const root=new URL('./formatter-unit/',import.meta.url).pathname;fs.mkdirSync(root,{recursive:true});
process.env.PAPERCLIP_VITEST_INVOCATION_REPORT_DIR=root;process.env.PAPERCLIP_VITEST_REPORT_REPO_ROOT=root;process.env.PAPERCLIP_VITEST_NOTICE_BUDGET='3';
const reporter=new ModuleResultsReporter();reporter.onInit({snapshot:{summary:{}},config:{passWithNoTests:false,root},logger:{log(){}}});
const lines=[],originalLog=console.log;console.log=(value)=>lines.push(String(value));
try{for(let i=0;i<5;i++){
 const file={type:'suite',name:'unit-'+i,filepath:path.join(root,'unit-'+i+'.test.ts'),projectName:'unit',mode:'run',result:{state:'pass'},tasks:[]};
 const task={type:'test',name:'fixed unit datum',mode:'run',result:{state:'pass',startTime:1,duration:1},suite:file,file,meta:{},tags:[]};file.tasks.push(task);
 await reporter.onTestModuleEnd({task:file,moduleId:file.filepath,project:{name:'unit'},state:()=> 'passed',children:{*allTests(){yield{result:()=>({state:'passed'}),fullName:'fixed unit datum'};}}});
}}finally{console.log=originalLog;}
assert.equal(lines.length,3);assert.equal(lines.filter(value=>value.includes('notices truncated')).length,1);assert.equal(reporter.notices,3);assert.equal(JSON.parse(fs.readFileSync(path.join(root,'notice-count.json'),'utf8')).count,3);assert.equal(fs.readdirSync(root).filter(name=>name.endsWith('.lifecycle.json')).length,5);process.env.PAPERCLIP_VITEST_NOTICE_BUDGET='21';assert.throws(()=>new ModuleResultsReporter().onInit({}),/Invalid optional/);console.log('FORMATTER_AND_CAP_CONTROLS_PASSED');
""")
 ensure(shutil.disk_usage('/workspace').free>=120000*1024 and shutil.disk_usage('/tmp').free>=1048576*1024,'post preparation original floors not met')
 env=dict(os.environ)
 for key in ['PAPERCLIP_VITEST_REPORT_DIR','PAPERCLIP_VITEST_INVOCATION_REPORT_DIR','PAPERCLIP_VITEST_REPORT_REPO_ROOT','PAPERCLIP_VITEST_NOTICE_BUDGET']:env.pop(key,None)
 env.update({'CI':'1','COREPACK_ENABLE_NETWORK':'0','NODE_DISABLE_COMPILE_CACHE':'1','XDG_CACHE_HOME':str(args.output/'cache'),'npm_config_cache':str(args.output/'npm-cache'),'npm_config_update_notifier':'false','NODE_OPTIONS':'--max-old-space-size=512 --import='+preload.as_uri(),'AW_REPORTING_EXPECTED':str(expected_file),'AW_REPORTING_PROVENANCE':str(provenance),'PAPERCLIP_TEST_TMPDIR':str(args.output/'tmp')})
 (args.output/'tmp').mkdir()
 def run(name,command,cwd,reporting=False):
  global active
  e=dict(env)
  if reporting:e['PAPERCLIP_VITEST_REPORT_DIR']=str(report)
  record={'name':name,'command':command,'cwd':str(cwd)};result['commands'].append(record)
  with (args.output/(name+'.log')).open('w') as log:
   active=subprocess.Popen(command,cwd=cwd,env=e,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   record['ownedGroup']=active.pid
   while True:
    group=members(active.pid); own=int(Path('/proc/self/statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')//1024
    total=sum(m['rssKiB'] for m in group)+own;result['peakOwnedTotalRssKiB']=max(result['peakOwnedTotalRssKiB'],total)
    if total>RSS_LIMIT or time.monotonic()-started>60:
     record['guard']='RSS' if total>RSS_LIMIT else 'TIME';record['remaining']=close_owned(active);raise RuntimeError('owned resource guard')
    rc=active.poll()
    if rc is not None:
     record['exitCode']=rc
     if members(active.pid):record['remaining']=close_owned(active)
     ensure(not members(active.pid),'owned process group not closed');active=None;return rc
    time.sleep(.1)
 def invoke(root):return ['node',str(root/RUNNER),'--mode','general','--group','general-server']
 def inventory():return sorted(p for p in report.iterdir() if p.is_dir())
 def lifecycle(directory):return [json.loads(p.read_text()) for p in directory.glob('*.lifecycle.json')]
 try:
  ensure(run('formatter',['node',str(args.output/'formatter.mjs')],normal)==0,'formatter controls')
  ensure(run('normal-two-invocations',['node',str(normal/RUNNER),'--mode','general','--group','general-workspaces-a'],normal,True)==0,'normal run')
  inv=inventory();ensure(len(inv)==2,'two unique invocation directories');normal_dirs=inv[:]
  budgets=sorted(json.loads((p/'worker-budget.json').read_text())['budget'] for p in inv);ensure(budgets==[19,20],'actual shared notice budget propagation')
  ensure(sorted(len(lifecycle(p)) for p in inv)==[1,1],'both real normal modules recorded')
  for p in inv:
   ensure(json.loads((p/'exit.json').read_text())['status']==0,'normal actual parent exit');end=json.loads((p/'run-end.json').read_text());ensure(end['reason']=='passed' and end['unhandledErrorCount']==0,'normal final run')
   for native in p.glob('*.json'):
    if len(native.stem)==64:
     data=json.loads(native.read_text());ensure(data['testResults'][0]['status']=='passed' and len(data['testResults'][0]['assertionResults'])==1 and data['testResults'][0]['assertionResults'][0]['status']=='passed','native normal cases intact')
   for item in lifecycle(p):ensure(item['state']=='passed' and item['counts']['passed']==1 and item['processExit']=='pending','module not final process')
  normal_text=(args.output/'normal-two-invocations.log').read_text();notice_lines=[line for line in normal_text.splitlines() if line.startswith('::notice')]
  ensure(len(notice_lines)==2 and not any('notices truncated' in line for line in notice_lines),'normal notices preserve shared allowance')
  saved={str(p):sha(p) for d in normal_dirs for p in d.glob('*.json')}
  ensure(run('after-all',invoke(failed),failed,True)!=0,'afterAll must fail parent')
  new=[p for p in inventory() if p not in inv];ensure(len(new)==1,'one failed invocation');d=new[0];inv+=new
  ensure(json.loads((d/'exit.json').read_text())['status']!=0,'failed actual exit recorded')
  failed_end=json.loads((d/'run-end.json').read_text());ensure(failed_end['reason']=='failed','afterAll final run fails')
  life=lifecycle(d);ensure(len(life)==1 and life[0]['state']=='failed' and life[0]['counts']['passed']==1,'body pass cannot hide afterAll failure')
  native=[p for p in d.glob('*.json') if len(p.stem)==64][0];native_data=json.loads(native.read_text());ensure(native_data['testResults'][0]['assertionResults'][0]['status']=='passed' and native_data['testResults'][0]['status']=='failed' and 'REPORTING_AFTER_ALL_SENTINEL' in native_data['testResults'][0]['message'],'native afterAll module error retained')
  ensure(run('owned-worker-exit',invoke(crashed),crashed,True)!=0,'worker exit cannot pass')
  new=[p for p in inventory() if p not in inv];ensure(len(new)==1,'one crash invocation');d=new[0]
  ensure(json.loads((d/'exit.json').read_text())['status']!=0,'worker actual exit record')
  ensure(all(item['state']!='passed' for item in lifecycle(d)),'worker exit module not passed')
  end=json.loads((d/'run-end.json').read_text());ensure(end['reason']!='passed' or end['unhandledErrorCount']>0,'worker final unknown/failed')
  original=['node',str(unset/'scripts/run-vitest-stable.original.mjs'),'--mode','general','--group','general-server','--dry-run'];candidate=invoke(unset)+['--dry-run']
  ensure(run('dry-original',original,unset)==0 and run('dry-candidate',candidate,unset)==0,'dry parity commands')
  ensure((args.output/'dry-original.log').read_text()==(args.output/'dry-candidate.log').read_text(),'unset selection parity')
  ensure(not any('reporting-unset' in str(p) for p in inventory()),'unset dry run does not activate reporting')
  prior_count=len(inventory());ensure(run('unset-default',invoke(unset),unset)==0 and len(inventory())==prior_count,'actual unset run leaves reporting disabled')
  ensure(all(sha(Path(p))==digest for p,digest in saved.items()),'no result overwrite')
  provenance_bytes=provenance.read_bytes();ensure(provenance_bytes.endswith(b'\n') and b'\n' in provenance_bytes,'actual JSONL newline framing')
  observed=[json.loads(line) for line in provenance_bytes.decode().splitlines()]
  for root in [normal,failed,crashed]:
   ensure(any(x['path']==str(root/RUNNER) and x['sha256']==bypath[RUNNER]['candidateSha256'] and x['role']=='node-entry' for x in observed),'actual candidate runner provenance')
   ensure(any(x['path']==str(root/REPORTER) and x['sha256']==bypath[REPORTER]['candidateSha256'] for x in observed),'actual candidate reporter provenance')
  ensure(any(x['path']==str(unset/RUNNER) and x['role']=='node-entry' for x in observed) and not any(x['path']==str(unset/REPORTER) for x in observed),'actual unset candidate runs without reporter load')
  result['runtimeProvenance']=observed;result['normalModules']=2;result['normalCases']=2;result['noticeCount']=2;result['afterAllFailurePreserved']=True;result['workerExitNotCompletePass']=True;result['unsetParity']=True;result['multipleInvocationNoOverwrite']=True;result['status']='REPORTING_MECHANICS_PASS_PENDING_REVIEW';rc=0
 except BaseException as error:
  result['status']='CONTROL_FAILED_NO_RETRY';result['errorType']=type(error).__name__;result['errorMessage']=str(error);rc=1
 finally:
  if active is not None and (active.poll() is None or members(active.pid)):result['remainingOwned']=close_owned(active)
  result['mainHeadUnchanged']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=MAIN,text=True).strip()==HEAD
  result['mainTrackedClean']=clean();result['mainNamedInputsUnchanged']=all(sha(MAIN/p)==v for p,v in before.items())
  result['frozenR2Unchanged']=all(sha(Path(r['candidateSource']))==r['candidateSha256'] for r in rows)
  result['copiedInputsUnchanged']=all(sha(Path(r['path']))==r['sha256'] for r in result['sourceCopies'])
  result['memoryEventsAfter']=events();result['memoryEventsUnchanged']=result['memoryEventsBefore']==result['memoryEventsAfter'];result['elapsedSeconds']=time.monotonic()-started
  if not all(result[k] for k in ['mainHeadUnchanged','mainTrackedClean','mainNamedInputsUnchanged','frozenR2Unchanged','copiedInputsUnchanged','memoryEventsUnchanged']):rc=99;result['status']='SOURCE_OR_MEMORY_GUARD_FAILED'
  result['exitCode']=rc;(args.output/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');(args.output/'exit').write_text(str(rc)+'\n')
 raise SystemExit(rc)
