ALTER TABLE "heartbeat_runs" ADD COLUMN "native_process_cleanup_pending" boolean;--> statement-breakpoint
CREATE INDEX "environment_leases_resource_cleanup_idx" ON "environment_leases" USING btree ("company_id","heartbeat_run_id","id") WHERE not coalesce((("environment_leases"."status" in ('released','expired','failed') and "environment_leases"."released_at" is not null and
        ("environment_leases"."cleanup_status"='success' or ("environment_leases"."cleanup_status" is null and
          (("environment_leases"."provider"='local' and "environment_leases"."provider_lease_id" is null) or
           ("environment_leases"."provider"='ssh' and "environment_leases"."metadata"->>'driver'='ssh' and "environment_leases"."provider_lease_id" like 'ssh://%')))))
        or ("environment_leases"."status"='retained' and "environment_leases"."lease_policy"='reuse_by_environment' and "environment_leases"."cleanup_status"='success')),false)
        or coalesce("environment_leases"."metadata"->>'pendingCleanupInFlight','false')<>'false';--> statement-breakpoint
CREATE INDEX "heartbeat_runs_resource_local_cleanup_idx" ON "heartbeat_runs" USING btree ("company_id","id") WHERE "heartbeat_runs"."native_process_cleanup_pending" is true or ("heartbeat_runs"."native_process_cleanup_pending" is null and "heartbeat_runs"."runtime_mode"='native'
        and ("heartbeat_runs"."status"<>'queued' or "heartbeat_runs"."started_at" is not null or "heartbeat_runs"."process_started_at" is not null
          or "heartbeat_runs"."process_pid" is not null or "heartbeat_runs"."process_group_id" is not null or "heartbeat_runs"."native_phase" is not null
          or "heartbeat_runs"."session_id_after" is not null));--> statement-breakpoint
CREATE INDEX "heartbeat_runs_resource_workspace_cleanup_idx" ON "heartbeat_runs" USING btree ("company_id","id") WHERE "heartbeat_runs"."runner_profile_json"->>'nativeWorkspaceFinalizationOwner' is not null;--> statement-breakpoint
CREATE INDEX "memory_jobs_resource_active_idx" ON "memory_jobs" USING btree ("company_id","id") WHERE "memory_jobs"."status"='running';--> statement-breakpoint
CREATE INDEX "memory_jobs_resource_queued_idx" ON "memory_jobs" USING btree ("company_id","submitted_at","created_at","id") WHERE "memory_jobs"."status"='queued';--> statement-breakpoint
CREATE INDEX "memory_jobs_resource_progress_idx" ON "memory_jobs" USING btree ("company_id","updated_at" DESC NULLS LAST,"id" DESC NULLS LAST) WHERE "memory_jobs"."started_at" is not null;--> statement-breakpoint
CREATE INDEX "native_run_finalizations_resource_cleanup_idx" ON "native_run_finalizations" USING btree ("company_id","run_id") WHERE "native_run_finalizations"."lease_owner" is not null or "native_run_finalizations"."phase" not in ('committed','applied','terminal_failure');--> statement-breakpoint
CREATE INDEX "workflow_runs_resource_active_idx" ON "workflow_runs" USING btree ("company_id","id") WHERE "workflow_runs"."status" in ('running','recovering','cancelling');--> statement-breakpoint
CREATE INDEX "workflow_runs_resource_queued_idx" ON "workflow_runs" USING btree ("company_id","updated_at","id") WHERE "workflow_runs"."status"='queued';--> statement-breakpoint
CREATE INDEX "workflow_runs_resource_progress_idx" ON "workflow_runs" USING btree ("company_id","updated_at" DESC NULLS LAST,"id" DESC NULLS LAST) WHERE "workflow_runs"."started_at" is not null;