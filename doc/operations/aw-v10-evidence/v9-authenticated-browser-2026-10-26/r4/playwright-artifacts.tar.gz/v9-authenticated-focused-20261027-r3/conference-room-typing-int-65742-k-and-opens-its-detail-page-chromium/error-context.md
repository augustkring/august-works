# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: conference-room-typing-intro.spec.ts >> First-task launch after onboarding wizard >> creates the first task and opens its detail page
- Location: tests/e2e/conference-room-typing-intro.spec.ts:142:3

# Error details

```
TimeoutError: locator.waitFor: Timeout 20000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: /Get started/ }) to be visible

```

# Page snapshot

```yaml
- generic [ref=e5]:
  - generic [ref=e6]:
    - button "Name your organization" [ref=e7] [cursor=pointer]
    - button "Create your first agent" [ref=e8] [cursor=pointer]
    - button "Connect a model" [disabled] [ref=e9]
    - button "Review" [disabled] [ref=e10]
    - generic [ref=e11]: Step 3 of 4
  - generic [ref=e12]:
    - generic [ref=e13]: Ada
    - heading "Connect a model" [level=1] [ref=e25]
    - paragraph [ref=e28]:
      - generic [ref=e29]: Paperclip works with your subscription or API keys.
  - generic [ref=e31]:
    - radiogroup "Model source" [ref=e32]:
      - radio "Claude Subscription" [checked] [ref=e34] [cursor=pointer]:
        - generic [ref=e36]: Claude
        - generic [ref=e37]: Subscription
    - button "Use API key instead" [ref=e40] [cursor=pointer]
  - paragraph [ref=e43]: Board mutation requires trusted browser origin
  - generic [ref=e44]:
    - button "Back" [ref=e45]
    - button "Connect" [ref=e47]
```

# Test source

```ts
  14  |  * Completing the onboarding wizard now creates the first assigned task and
  15  |  * drops the user straight onto that task's detail page (not the dashboard),
  16  |  * so they land in the conversation the agent will start in. The chat intro
  17  |  * still has unit coverage in BoardChat tests.
  18  |  *
  19  |  * PAP-404: onboarding used to intermittently bounce to the company dashboard.
  20  |  * The bounce only reproduces when the instance already has ≥1 company (the
  21  |  * board's test ports), so the second test seeds a company first to exercise
  22  |  * exactly that failing condition.
  23  |  */
  24  | 
  25  | const FIRST_TASK_TITLE = "Paperclip onboarding";
  26  | 
  27  | /**
  28  |  * Intercept authentication, environment checks, and hiring so no real CLI check
  29  |  * runs and no real agent process spawns (the hire still happens server-side
  30  |  * with an inert http adapter).
  31  |  */
  32  | async function installLaunchIntercepts(page: Page, baseURL?: string) {
  33  |   await mockOnboardingLocalAiConnection(page);
  34  |   await page.route("**/test-environment", (route) =>
  35  |     route.fulfill({
  36  |       contentType: "application/json",
  37  |       body: JSON.stringify({ status: "pass", checks: [] }),
  38  |     }),
  39  |   );
  40  | 
  41  |   await page.route("**/agent-hires", async (route) => {
  42  |     const req = route.request();
  43  |     const body = JSON.parse(req.postData() || "{}");
  44  |     const headers = req.headers();
  45  |     const real = await fetch(new URL(req.url(), baseURL).toString(), {
  46  |       method: "POST",
  47  |       headers: {
  48  |         "Content-Type": "application/json",
  49  |         ...(headers.authorization ? { Authorization: headers.authorization } : {}),
  50  |         ...(headers.cookie ? { Cookie: headers.cookie } : {}),
  51  |       },
  52  |       body: JSON.stringify({
  53  |         name: body.name,
  54  |         role: body.role,
  55  |         adapterType: "http",
  56  |         adapterConfig: { url: "http://127.0.0.1:1/dead" },
  57  |         runtimeConfig: { heartbeat: { enabled: false } },
  58  |       }),
  59  |     });
  60  |     await route.fulfill({
  61  |       status: real.status,
  62  |       contentType: "application/json",
  63  |       body: await real.text(),
  64  |     });
  65  |   });
  66  | }
  67  | 
  68  | /** Drive the wizard from the /onboarding route through to "Get started". */
  69  | async function runOnboardingWizard(page: Page, companyName: string) {
  70  |   await page.goto("/onboarding");
  71  | 
  72  |   // Launcher card path (existing companies) — enter the wizard if the
  73  |   // route shows a launcher instead of opening the wizard directly.
  74  |   const startBtn = page.getByRole("button", { name: /Start Onboarding/i });
  75  |   if (await startBtn.count()) await startBtn.first().click();
  76  | 
  77  |   // Step 0: front door (skipped when the wizard opens on the create path).
  78  |   const frontDoor = page.getByText("Build a new organization");
  79  |   if (await frontDoor.count()) await frontDoor.first().click();
  80  | 
  81  |   // Step 1: company name.
  82  |   await page.getByPlaceholder("e.g. Northwind Labs").fill(companyName);
  83  |   await page.getByRole("button", { name: /^Continue/ }).click();
  84  | 
  85  |   // Step 1's "Next" creates the company; the mission step no longer runs.
  86  | 
  87  |   // Step 3: name the agent. The role picker is gone — the arc asks for a
  88  |   // name and hires under the neutral `general` role.
  89  |   await page.waitForSelector("#onboarding-agent-name", { timeout: 30_000 });
  90  |   await page.locator("#onboarding-agent-name").fill("Ada");
  91  |   await page.getByRole("button", { name: /^Next$/ }).click();
  92  | 
  93  |   // Step 4: pick a model source, then advance. Nothing is selected on arrival
  94  |   // — the row is a question, not a confirmation — so the CTA is disabled until
  95  |   // a tile is pressed. By role rather than by label: which adapters the tiles
  96  |   // offer depends on the registry this environment reports.
  97  |   const source = page.getByRole("radio").first();
  98  |   await source.waitFor({ timeout: 30_000 });
  99  |   await source.click();
  100 | 
  101 |   // "Connect", not "Next": this step's button starts the sign-in where there
  102 |   // is one to start, so it is named for what it does. This test simulates
  103 |   // successful local account connection before the environment check and hire.
  104 |   //
  105 |   // Waited on for enabled rather than for visible: it is already on screen,
  106 |   // disabled, and clicking a disabled button raises nothing and does nothing.
  107 |   const connectNext = page.getByRole("button", { name: /^Connect$/ });
  108 |   await expect(connectNext).toBeEnabled({ timeout: 30_000 });
  109 |   await connectNext.click();
  110 | 
  111 |   // Step 5: review → Get started creates the first task and opens its
  112 |   // detail page.
  113 |   const getStarted = page.getByRole("button", { name: /Get started/ });
> 114 |   await getStarted.waitFor({ timeout: 20_000 });
      |                    ^ TimeoutError: locator.waitFor: Timeout 20000ms exceeded.
  115 |   await getStarted.click();
  116 | }
  117 | 
  118 | async function assertFirstTaskExists(page: Page, companyName: string) {
  119 |   const companiesRes = await page.request.get("/api/companies");
  120 |   expect(companiesRes.ok()).toBe(true);
  121 |   const companies = await companiesRes.json();
  122 |   const company = companies.find(
  123 |     (candidate: { name: string }) => candidate.name === companyName,
  124 |   );
  125 |   expect(company).toBeTruthy();
  126 | 
  127 |   const issuesRes = await page.request.get(`/api/companies/${company.id}/issues`);
  128 |   expect(issuesRes.ok()).toBe(true);
  129 |   const issues = await issuesRes.json();
  130 |   const firstTask = issues.find(
  131 |     (candidate: { title: string }) => candidate.title === FIRST_TASK_TITLE,
  132 |   );
  133 |   expect(firstTask).toBeTruthy();
  134 |   // The progressive sidebar can retain a hidden task label. Assert the actual
  135 |   // task detail heading instead of whichever text node appears first.
  136 |   await expect(page.getByRole("main").getByRole("heading", { name: FIRST_TASK_TITLE, exact: true })).toBeVisible({
  137 |     timeout: 15_000,
  138 |   });
  139 | }
  140 | 
  141 | test.describe("First-task launch after onboarding wizard", () => {
  142 |   test("creates the first task and opens its detail page", async ({ page, baseURL }) => {
  143 |     await instrumentNavLog(page);
  144 |     await installLaunchIntercepts(page, baseURL);
  145 | 
  146 |     const companyName = `E2E-TypingIntro-${Date.now()}`;
  147 |     await runOnboardingWizard(page, companyName);
  148 | 
  149 |     await expectLandsOnFirstTaskWithoutDashboardBounce(page);
  150 |     await assertFirstTaskExists(page, companyName);
  151 |   });
  152 | 
  153 |   // PAP-404 regression: the dashboard bounce only fires when the instance
  154 |   // already has a company for the route-sync effect to reset selection to.
  155 |   // Seed one first, then onboard a brand-new company and assert we still land
  156 |   // on the first task without a dashboard bounce.
  157 |   test("lands on the first task even when a company already exists", async ({
  158 |     page,
  159 |     baseURL,
  160 |   }) => {
  161 |     await instrumentNavLog(page);
  162 |     await installLaunchIntercepts(page, baseURL);
  163 | 
  164 |     // Seed a pre-existing company so the companies list is non-empty when the
  165 |     // wizard launches — the exact condition that reproduced the bounce.
  166 |     const seedRes = await page.request.post("/api/companies", {
  167 |       data: { name: `E2E-Seed-${Date.now()}` },
  168 |     });
  169 |     expect(seedRes.ok()).toBe(true);
  170 | 
  171 |     const companyName = `E2E-TypingIntro-Existing-${Date.now()}`;
  172 |     await runOnboardingWizard(page, companyName);
  173 | 
  174 |     await expectLandsOnFirstTaskWithoutDashboardBounce(page);
  175 |     await assertFirstTaskExists(page, companyName);
  176 |   });
  177 | });
  178 | 
```