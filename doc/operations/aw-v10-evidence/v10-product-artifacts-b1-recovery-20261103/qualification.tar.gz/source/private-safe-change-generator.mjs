import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { buildGraph } from "file:///workspace/blentera-v10/scripts/generate-v10-safe-change-graph.mjs";
const source = "/tmp/v10-product-artifacts-b1-recovery-20261103/v10-safe-change-graph.source.json";
const destination = "/tmp/v10-product-artifacts-b1-recovery-20261103/v10-safe-change-graph.json";
const rendered = JSON.stringify(buildGraph(JSON.parse(readFileSync(source, 'utf8')), path => readFileSync(path === 'doc/operations/v10-capability-projection.json' ? "/tmp/v10-product-artifacts-b1-recovery-20261103/v10-capability-projection.json" : resolve("/workspace/blentera-v10", path))), null, 2) + '\n';
if(process.argv.includes('--check')) {
  if(readFileSync(destination,'utf8')!==rendered) throw new Error('Private Safe Change graph is stale against actual original generator');
} else writeFileSync(destination, rendered);
