# Final source freeze and metadata successor sequence

Preparation only. Main/Mirror were not restored, staged, committed or generated; no tests were run. Five dirty metadata files were copied byte-for-byte and mode-for-mode to `preserved/`, with the exact HEAD-based binary patch and index observations in `preservation-receipt.json`. Current Main bytes/modes were rechecked after copying. Any later source/metadata drift requires a new preservation receipt rather than reusing these pins.

## Exact preserved metadata

Captured HEAD: `05b25e2cff6ce20c9877aea5e5f079835facf411`. No metadata path was staged at capture.

| Path | Working SHA256 | Mode |
| --- | --- | --- |
| doc/operations/aw-v10-evidence/v10-169-migration-phases-current-2026-10-30/README.md | 32e91d963d28221916c09b4f2f5140cd98ff964885fb46cf2682faa64edd38df | 0o600 |
| doc/operations/aw-v10-evidence/v10-169-migration-phases-current-2026-10-30/SHA256SUMS | 1f879c30a83f8e19a7bd02fa4143de9b078a7a6af0a07b265b440c3720f8b7b4 | 0o600 |
| doc/operations/aw-v10-evidence/v10-169-migration-phases-current-2026-10-30/phase-matrix.json | e6beb820c72c1deb3680889fd608bc1198f1e514caaaf081dbe4c7818d821ccb | 0o600 |
| doc/operations/aw-v10-evidence/v10-169-migration-phases-current-2026-10-30/stage-list.txt | 81a3189ae34a45c5d364d9cc45fec1bb2266ea3d77ecbf2efe9f99c7835be885 | 0o600 |
| doc/operations/v10-safe-change-graph.source.json | 0bcd53b6098331f9545bb7d605be290d6f34de58870addbabed58709f377f919 | 0o600 |

Patch SHA256: `95227354952be6d93677cb3379b64956fd62dca10ea53e39d181b2ee0a51f626` (`preserved-five-metadata.patch`). The private current schema2 manifest to supply to the inventory helper is `preserved/doc/operations/v10-safe-change-graph.source.json`; do not substitute the temporarily restored older HEAD manifest. The four migration metadata files are preservation inputs to a final refresh, not automatically final pins.

## Correct Help scope

The workflow Help manifest `/workspace/v10-preparation/runtime-unavailable-workflow-help-nov01/manifest.json` has two bilingual Help articles plus `docs/api/workflows.md`, an API **documentation** contract, not executable source. API-doc parent SHA256 `598da0a38f2d0b066f82ca0d94267658bb8afd80828f874deee3c37458d31809`; candidate `5bf51120db05bbcd8a20992a71664d593c2e98e96af0b538cf9804dab7f5519b` was independently matched to the private file.

Root confirmed all six article/guide files plus this API document stay in the metadata/docs phase after code freeze. The other four files are the paired managing-agents guides and apps-and-connections Help pair from `/workspace/v10-preparation/runtime-unavailable-help-nov01/manifest.json`. The executable workflow HTTP availability-copy source `server/src/services/workflows/workflow-http-request.ts` and its tests already belong to final55 (aa285 lineage), so they must be in the qualified source commit.

## Shortest safe sequence: source commit, then metadata commit

Execute only after core green and exact owner freeze, under the parent's existing snapshot/lock/publication discipline. No broad stash, reset, stage, delete or cleanup is needed.

1. Verify the five current SHA/modes and captured-parent/index assumptions against this preservation receipt. If they drifted, capture a fresh exact five-file private bundle/patch first. If those unrefreshed files prevent the required tracked-clean source checkpoint, temporarily restore ONLY these five working-tree paths to the then-verified HEAD; never restore another path, never touch unrelated untracked evidence, and never discard a staged metadata version. No restore is authorized by this document without the exact verified backup. Do not apply the saved patch after the source commit blindly; use the saved private schema2 manifest and migration67 candidate as final-refresh inputs.
2. Compose/stage ONLY the explicit qualified source manifest paths, including current qualified dirty source, final55, Host final, server capability7+constructor2, Native final/SDK and executable workflow availability source. Preserve Project changes. Commit the source checkpoint and record `SOURCE_HEAD`. Its tracked index/worktree must be clean; only unrelated untracked `doc/operations/aw-v10-evidence/` artifacts are allowed by the helper. Do not stage the deferred five metadata files or Help delta into that source checkpoint.
3. Invoke `final-metadata-inventory-audit-nov01/edit-frozen-source-inventory.py` with the clean frozen root/`SOURCE_HEAD`, the preserved private schema2 manifest and its exact receipt hash, and the frozen updated-owner-plan pin. Output to a NEW private filename. This computes source membership/base pins/counts without applying files or source-after hash generation. Do this before making metadata/docs changes in the tracked worktree.
4. In the metadata phase, apply the reviewed six Help articles/guides + API doc, refresh reviewed Help pairs, generate Help search, and prepare the operation-coverage, alias, migration67-row, R4/current evidence and append-only amendment metadata against exact final source receipts. Preserve historical statuses/50 groups. The Help search projection is executable generated data, but it already belongs to `SCR-V10-PRODUCT-IDENTITY-HELP-LANGUAGE` and is already changed at base→SOURCE_HEAD, so refreshing its contents introduces no new membership/count delta. If another generated source-classified path becomes newly changed, stop and obtain an explicit owner/update the clean freeze rather than silently omitting it.
5. Apply the private repaired source manifest; generate the Safe Change graph LAST, after every file it hashes (including generated Help search, operational contract JSON and sourceInputs) has its final metadata-phase bytes. Run generation `--check`/graph checker and all applicable metadata checks. The Help change-review checker needs a committed head: stage ONLY the explicit reviewed metadata/docs/generated projection files, commit a metadata successor `METADATA_HEAD`, then run `check-help-change-review.mjs --base <reviewed full base> --head METADATA_HEAD --evidence-out <private path>` plus final graph/register freshness checks. The successor is not final/qualified until these checks pass. If a correction is required, amend/recommit only the explicit metadata cohort and repeat affected checks; never alter historical statuses or unrelated work to satisfy a check.

This is two commits in the no-correction case. A separate Help-only commit is unnecessary: its required committed comparison can run against the final metadata successor after all hashes are generated. Keep the actual full SHAs in external receipts; do not insert the final commit's own SHA into its contents.

## Existing source/head semantics: no recursive HEAD pin

* `scripts/generate-v10-safe-change-graph.mjs:195–199` deliberately emits `sourceIdentity.commitSha:null`, `identityKind:sha256_of_each_listed_current_source_and_input_file`, and the immutable base commit. It reads current listed bytes and does not run `git rev-parse HEAD`. The checker validates the exact regenerated graph, base pins, source hashes and unique changed/deleted counts; it does not require current HEAD to equal SOURCE_HEAD.
* Consequently, a metadata-only successor commit does not invalidate graph identity merely by changing HEAD. If that commit changes a listed source/input byte, regenerate graph after those bytes settle. No graph self-hash/current-HEAD field is needed; the manifest and graph are excluded from the existing source-classification boundary.
* `scripts/check-v10-169-migration-phase-register.mjs` discovers migrations from the immutable source base and current journal and validates file hashes. Its shared validator has no current-HEAD equality requirement. A successor with identical migration/owner bytes is valid; actual changed pinned bytes require normal pin refresh.
* `scripts/check-help-change-review.mjs` reads article/source blobs at explicit committed base/head while reading the review map from the current worktree. This is why its final comparison follows the metadata commit. It does not require embedding METADATA_HEAD in the committed map, so there is no hash cycle.
* fullDiffPathCount records the frozen source-checkpoint diff used by the helper. The graph checker enforces actual source/deleted membership counts, not current Git HEAD or a recursive final metadata commit count. Metadata commits are separate evidence successors, not a source or acceptance upgrade.
