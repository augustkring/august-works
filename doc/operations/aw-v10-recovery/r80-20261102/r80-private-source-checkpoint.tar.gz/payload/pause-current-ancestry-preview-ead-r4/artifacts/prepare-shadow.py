from pathlib import Path
import hashlib,json,shutil,subprocess,sys
base=Path(__file__).parent; main=Path('/workspace/blentera-v10');work=Path(sys.argv[1]);out=Path(sys.argv[2]);assert not work.exists()
pins=json.loads((base/'source-pins.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=main,text=True).strip()==pins['parentCommit']
for row in pins['sourceFiles']:
 assert sha(main/row['path'])==row['parentSha256'],row['path']
 assert sha(base/'files'/row['path'])==row['candidateSha256'],row['path']
ignored={'node_modules','dist','dist-runtime','ui-dist','dist-preview','storybook-static','.vite','.vite-cache','.git','.cache','test-results','playwright-report'}
work.mkdir()
for package in ['server','ui']:
 shutil.copytree(main/package,work/package,ignore=shutil.ignore_patterns(*ignored,'*.tsbuildinfo'))
 modules = work/package/'node_modules'; modules.mkdir()
 for entry in (Path('/workspace/v10-dep-qualification')/package/'node_modules').iterdir():
  target = main/package/'node_modules'/entry.name if entry.name == '@paperclipai' else entry
  assert target.exists(),str(target)
  (modules/entry.name).symlink_to(target.resolve(),target_is_directory=target.is_dir())
 config=work/package/'vitest.config.ts';s=config.read_text().replace('export default defineConfig({','export default defineConfig({\n  cacheDir: '+json.dumps(str(work/package/'.vite-cache'))+',')
 config.write_text(s)
for child in main.iterdir():
 if child.name in {'server','ui','scripts','.git','node_modules'}:continue
 (work/child.name).symlink_to(child,target_is_directory=child.is_dir())
(work/'node_modules').symlink_to(main/'node_modules',target_is_directory=True)
(work/'scripts').mkdir()
for name in ['check-forbidden-tokens.mjs','check-token-gates.mjs','sync-agent-palette-tokens.mjs','sync-cliplab-character.mjs']:
 shutil.copy2(main/'scripts'/name,work/'scripts'/name)
for row in pins['sourceFiles']:
 dst=work/row['path'];assert dst.parent.resolve().is_relative_to(work.resolve());dst.unlink();shutil.copy2(base/'files'/row['path'],dst)
rows=[]
for package in ['server','ui']:
 for p in sorted((main/package).rglob('*')):
  rel=p.relative_to(main)
  if not p.is_file() or any(x in ignored for x in rel.parts) or p.name.endswith('.tsbuildinfo'):continue
  rows.append({'path':str(rel),'sha256':sha(p)})
(out/'main-source-before.json').write_text(json.dumps({'head':pins['parentCommit'],'files':rows},indent=2)+'\n')
print(json.dumps({'shadow':str(work),'mainSourceInputs':len(rows),'copiedRoots':['server','ui'],'MainMirrorWrites':False}))

# Record only public dependency identity/realpath, never environment or credentials.
resolved=work/'ui/node_modules/better-auth'
(out/'dependency-identity.json').write_text(json.dumps({'name':'better-auth','version':json.loads((resolved/'package.json').read_text())['version'],'realpath':str(resolved.resolve())},indent=2)+'\n')
assert json.loads((resolved/'package.json').read_text())['version']=='1.7.7'
