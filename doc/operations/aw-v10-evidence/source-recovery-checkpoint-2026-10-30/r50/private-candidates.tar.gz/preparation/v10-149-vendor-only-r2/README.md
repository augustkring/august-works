# OpenShell vendor-only R2 private candidate

This patch is based on the exact private R5 CLI files and RT01 R11 Docker driver files pinned in `source-pins.json`. It fixes per-sandbox PID-limit wire handling by accepting only a canonical decimal string in protobuf `Struct` driver config, retaining integer conversion only after strict parsing. The test constructs a real `DriverSandboxTemplate` with protobuf `Struct` data, parses it through `DockerSandboxDriverConfig::from_template`, and rejects a numeric Struct value to avoid relying on serde integer coercion from protobuf's f64 representation.

The `base/` and `candidate/` trees are retained as reproducible source evidence. `vendor-provision.patch` applies to all four exact parents and reconstructs the candidate bytes. This is source-level patch qualification only. Cargo compile/tests, host integration, publication, and physical qualification have not been run.
