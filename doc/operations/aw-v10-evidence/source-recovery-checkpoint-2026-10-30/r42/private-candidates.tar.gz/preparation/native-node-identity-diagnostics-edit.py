from pathlib import Path
p=Path('/workspace/blentera-v10/server/src/services/native-direct-input.ts');s=p.read_text()
s=s.replace('interface NativeSourceReadAncestry { work: number;', '''interface NativeGraphProofDiagnostic { calls: number; eligible: number; candidates: number; depthBlocked: number;
  ancestryBlocked: number; mapCount: number; maps: WeakSet<object>; keys: Set<string>; partitions: Set<string> }
interface NativeSourceReadAncestry { proofDiagnostics?: Map<string, NativeGraphProofDiagnostic>; work: number;''',1)
a=s.index('async function withNativeSourceGraphProof(')
helper='''function recordNativeGraphProofDiagnostic(scope: NativeSourceReadScope, kind: string, key: string,
  ledger: NativeSiblingToolSourceProofs, eligible: boolean, candidate: boolean, depthBlocked: boolean, ancestryBlocked: boolean) {
  if (!nativeSourceMemoDiagnosticsEnabled()) return;
  const kinds = scope.context.ancestry.proofDiagnostics ??= new Map();
  if (!kinds.has(kind) && kinds.size >= 8) return;
  let stats = kinds.get(kind);
  if (!stats) { stats = { calls: 0, eligible: 0, candidates: 0, depthBlocked: 0, ancestryBlocked: 0,
    mapCount: 0, maps: new WeakSet(), keys: new Set(), partitions: new Set() }; kinds.set(kind, stats); }
  stats.calls += 1; stats.eligible += Number(eligible); stats.candidates += Number(candidate);
  stats.depthBlocked += Number(depthBlocked); stats.ancestryBlocked += Number(ancestryBlocked);
  if (!stats.maps.has(ledger)) { stats.maps.add(ledger); stats.mapCount += 1; }
  if (stats.keys.size < 512) stats.keys.add(key);
  if (stats.partitions.size < 128) stats.partitions.add(`${scope.actorKey}:${scope.context.memoryTemporalIdentity}`);
}
function nativeGraphProofDiagnosticSummary(scope: NativeSourceReadScope) {
  return Object.fromEntries([...(scope.context.ancestry.proofDiagnostics ?? [])].map(([kind, stats]) => [kind, {
    calls: stats.calls, eligible: stats.eligible, candidates: stats.candidates, depthBlocked: stats.depthBlocked,
    ancestryBlocked: stats.ancestryBlocked, maps: stats.mapCount, uniqueKeys: stats.keys.size, partitions: stats.partitions.size,
  }]));
}
'''
s=s[:a]+helper+s[a:]
needle='  if (nativeSourceMemoDiagnosticsEnabled()) {\n    const kind = key.split(';assert s.count(needle)==1
s=s.replace(needle,'''  recordNativeGraphProofDiagnostic(scope, key.split(":", 1)[0]!, key, proofs, eligible, !!candidate,
    !!candidate && !proof, !!proof && nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, proof.descendants));
'''+needle)
s=s.replace('lastWorkOverflow: null as { work: number; counts: Record<string, number> } | null,','lastWorkOverflow: null as { work: number; counts: Record<string, number>; proofs: ReturnType<typeof nativeGraphProofDiagnosticSummary> } | null,')
s=s.replace('work: scope.context.ancestry.work, counts: { ...scope.context.ancestry.workByCaller } };','work: scope.context.ancestry.work, counts: { ...scope.context.ancestry.workByCaller }, proofs: nativeGraphProofDiagnosticSummary(scope) };')
needle='''      const siblingProof = siblingProofKey ? siblingToolSourceProofs?.get(siblingProofKey) : undefined;''';assert s.count(needle)==1
s=s.replace(needle,needle+'''
      recordNativeGraphProofDiagnostic(scope, "tool-node", toolSourceVisitKey, siblingToolSourceProofs, !!siblingProofKey,
        !!siblingProof, false, !!siblingProof && nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, siblingProof.descendants));''')
needle='''  const documentProof = documentProofEligible ? siblingToolSourceProofs.get(documentProofKey) : undefined;''';assert s.count(needle)==1
s=s.replace(needle,needle+'''
  recordNativeGraphProofDiagnostic(scope, "document-node", documentProofKey, siblingToolSourceProofs, documentProofEligible,
    !!documentProof, !!documentProof && depth > (documentProof.validatedDepth ?? -1),
    !!documentProof && nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, documentProof.descendants));''')
Path('/workspace/v10-preparation/native-node-identity-diagnostics-candidate.ts').write_text(s)
