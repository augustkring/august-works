#!/usr/bin/env bash
# Prepared canonical full-check runner. Intentionally not executed before the
# source freeze and disk preflight. Usage after freeze:
#   V10_SOURCE_FREEZE=1 run-final-workspace-aggregate-20261030.sh <expected-main-head>
set -Eeuo pipefail

LOCK=/workspace/v10-preparation/v10-pg-tests.lock
if [[ ${1:-} != --locked ]]; then
  exec flock -x "$LOCK" "$0" --locked "$@"
fi
shift

EXPECTED_HEAD=${1:-}
if [[ ${V10_SOURCE_FREEZE:-} != 1 || ! "$EXPECTED_HEAD" =~ ^[0-9a-f]{40}$ ]]; then
  echo 'Refusing aggregate checks: set V10_SOURCE_FREEZE=1 and pass the frozen 40-character MAIN HEAD.' >&2
  exit 64
fi

source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH

MAIN=/workspace/blentera-v10
MIRROR=/workspace/v10-dep-qualification
RUST_CACHE=/tmp/blentera-preserved-current-rust-target
EXPECTED_RUNNERD_SHA256=31964806291c8eac3cad8b18bc26c1d3377191fb46f1f1e65aee2595a5697604
OUT=/workspace/v10-preparation/final-workspace-aggregate-20261030-$(date -u +%H%M%S)
mkdir "$OUT"

exec 9>"$OUT/runner.lock"
flock -n 9 || { echo "Evidence directory already active: $OUT" >&2; exit 73; }

TEST_TMP=/tmp/v10-final-workspace-test-tmp-$(date -u +%Y%m%dT%H%M%SZ)-$$
test_tmp_cleaned=0
finish() {
  rc=$?
  printf '%s\n' "$rc" > "$OUT/exit"
  if [[ $test_tmp_cleaned == 1 && -d "$TEST_TMP" && "$TEST_TMP" == /tmp/v10-final-workspace-test-tmp-* ]]; then
    rm -rf -- "$TEST_TMP"
    printf '%s\n' 'removed exact runner-owned PAPERCLIP_TEST_TMPDIR after passing full test:run' > "$OUT/temp-cleanup.txt"
  elif [[ -d "$TEST_TMP" ]]; then
    printf '%s\n' "preserved test temp for diagnosis: $TEST_TMP" > "$OUT/temp-cleanup.txt"
  fi
  if [[ -f "$OUT/source-pins.json" ]]; then
    (cd "$OUT" && find . -type f ! -name artifact-sha256sums.txt ! -name runner.lock -print0 | sort -z | xargs -0 -r sha256sum > artifact-sha256sums.txt) || true
  fi
  exit "$rc"
}
trap finish EXIT

cd "$MAIN"
ACTUAL_HEAD=$(git rev-parse HEAD)
[[ "$ACTUAL_HEAD" == "$EXPECTED_HEAD" ]] || { echo "MAIN HEAD changed after freeze: expected=$EXPECTED_HEAD actual=$ACTUAL_HEAD" >&2; exit 65; }
printf '%s\n' "$ACTUAL_HEAD" > "$OUT/main-head.txt"
git status --porcelain=v1 > "$OUT/main-status-before.txt"

# Default free-space floors reflect the incremental outputs, not the occupied
# workspace: package dist directories already exist; the major absent output
# is server/dist, which vendors the existing 58 MiB runner dist plus compiled
# server/assets. Vitest roots are isolated below TEST_TMP and removed on test
# success. Floors are configurable for this host after checking available disk.
available_kib() { df -Pk "$1" | awk 'NR==2 {print $4}'; }
ROOT_FREE_KIB=$(available_kib /workspace)
TMP_FREE_KIB=$(available_kib /tmp)
MIN_WORKSPACE_KIB=${V10_AGGREGATE_MIN_WORKSPACE_KIB:-131072}
MIN_TMP_KIB=${V10_AGGREGATE_MIN_TMP_KIB:-262144}
[[ "$MIN_WORKSPACE_KIB" =~ ^[0-9]+$ && "$MIN_TMP_KIB" =~ ^[0-9]+$ ]] || { echo 'Disk floors must be non-negative integer KiB values' >&2; exit 64; }
printf 'workspace_free_kib=%s\ntmp_free_kib=%s\nminimum_workspace_free_kib=%s\nminimum_tmp_free_kib=%s\n' \
  "$ROOT_FREE_KIB" "$TMP_FREE_KIB" "$MIN_WORKSPACE_KIB" "$MIN_TMP_KIB" > "$OUT/disk-before.txt"
if (( ROOT_FREE_KIB < MIN_WORKSPACE_KIB || TMP_FREE_KIB < MIN_TMP_KIB )); then
  echo "Insufficient measured headroom for configured floors; workspace=${ROOT_FREE_KIB}/${MIN_WORKSPACE_KIB} KiB, tmp=${TMP_FREE_KIB}/${MIN_TMP_KIB} KiB. Override V10_AGGREGATE_MIN_WORKSPACE_KIB or V10_AGGREGATE_MIN_TMP_KIB if a lower floor is justified." >&2
  exit 69
fi

[[ -d "$MIRROR" && -f "$MIRROR/pnpm-lock.yaml" && -d "$MIRROR/node_modules" ]] || { echo 'Qualified mirror/dependencies missing' >&2; exit 66; }
cmp -s "$MAIN/pnpm-lock.yaml" "$MIRROR/pnpm-lock.yaml" || { echo 'MAIN/mirror frozen lock differs' >&2; exit 66; }
[[ -d "$RUST_CACHE/debug/deps" && -d "$RUST_CACHE/release/deps" && -x "$RUST_CACHE/release/paperclip-runnerd" ]] || { echo 'Pinned warm Rust cache incomplete; refusing any cold build' >&2; exit 67; }
RUNNERD_SHA=$(sha256sum "$RUST_CACHE/release/paperclip-runnerd" | awk '{print $1}')
[[ "$RUNNERD_SHA" == "$EXPECTED_RUNNERD_SHA256" ]] || { echo "Rust runner binary pin mismatch: $RUNNERD_SHA" >&2; exit 67; }
printf '%s  %s\n' "$RUNNERD_SHA" "$RUST_CACHE/release/paperclip-runnerd" > "$OUT/rust-runnerd.sha256"

export CARGO_TARGET_DIR="$RUST_CACHE"
export PAPERCLIP_TEST_TMPDIR="$TEST_TMP"
mkdir -p "$PAPERCLIP_TEST_TMPDIR"

# Keep the standard full test suite offline from provider credentials. Record
# only names, never values, of the credentials removed from this process.
stripped=()
while IFS= read -r name; do
  if [[ "$name" =~ (API_KEY|API_TOKEN|ACCESS_KEY_ID|SECRET_ACCESS_KEY|SESSION_TOKEN|CLIENT_SECRET)$ ]]; then
    stripped+=("$name"); unset "$name"
  fi
done < <(compgen -e)
for name in ANTHROPIC_AUTH_TOKEN; do
  if [[ -v $name ]]; then stripped+=("$name"); unset "$name"; fi
done
printf '%s\n' "${stripped[@]}" > "$OUT/provider-credential-vars-stripped.txt"

python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$OUT/source-pins.json" > "$OUT/snapshot.log" 2>&1
node /workspace/v10-preparation/check-snapshot-syntax.cjs "$OUT/source-pins.json" > "$OUT/oxc.log" 2>&1
sha256sum /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py \
  /workspace/v10-preparation/check-snapshot-syntax.cjs \
  /workspace/v10-preparation/record-static-ui-build-inputs.py > "$OUT/helper-sha256sums.txt"

# Check the lock-protected mirror is the exact source image captured above.
python3 - "$MAIN" "$MIRROR" "$OUT/source-pins.json" "$EXPECTED_HEAD" <<'PY'
import hashlib,json,pathlib,sys
main,mirror,pins_path=map(pathlib.Path,sys.argv[1:4]); expected_head=sys.argv[4]
pins=json.loads(pins_path.read_text())
assert pins['sourceHead']==expected_head, ('source HEAD changed before snapshot',pins['sourceHead'],expected_head)
for row in pins['copiedFiles']:
    rel=row['path']; src=main/rel; dst=mirror/rel
    if row.get('deleted'):
        assert not dst.exists(), ('deleted source still exists in mirror',rel)
        continue
    assert src.is_file() and dst.is_file(), ('source missing after snapshot',rel)
    want=hashlib.sha256(src.read_bytes()).hexdigest()
    assert want==row['sha256']==hashlib.sha256(dst.read_bytes()).hexdigest(), ('source pin mismatch',rel)
print(json.dumps({'sourceHead':pins['sourceHead'],'copiedFiles':len(pins['copiedFiles']),'status':'passed'}))
PY

run_step() {
  local label=$1; shift
  printf '%q ' "$@" > "$OUT/$label.command"
  printf '\n' >> "$OUT/$label.command"
  set +e
  (cd "$MIRROR" && "$@") > "$OUT/$label.log" 2>&1
  local rc=$?
  set -e
  printf '%s\n' "$rc" > "$OUT/$label.exit"
  if (( rc != 0 )); then
    tail -80 "$OUT/$label.log" >&2 || true
    return "$rc"
  fi
}

run_step typecheck pnpm -r typecheck
run_step test-run pnpm test:run
test_tmp_cleaned=1
if [[ "$TEST_TMP" == /tmp/v10-final-workspace-test-tmp-* && -d "$TEST_TMP" && ! -L "$TEST_TMP" ]]; then
  rm -rf -- "$TEST_TMP"
fi
printf '%s\n' 'removed only the runner-created PAPERCLIP_TEST_TMPDIR after passing full test:run' > "$OUT/temp-cleanup.txt"

python3 /workspace/v10-preparation/record-static-ui-build-inputs.py record "$MIRROR" "$OUT/ui-build-inputs.json"
python3 - "$OUT/ui-build-inputs.json" <<'PY'
import json,pathlib,sys
count=len(json.loads(pathlib.Path(sys.argv[1]).read_text())['buildInputs'])
assert count>=5999,('static UI/package input guard did not cover the qualified minimum',count)
print(json.dumps({'recordedBuildInputs':count,'minimum':5999,'status':'passed'}))
PY
run_step build pnpm build
python3 /workspace/v10-preparation/record-static-ui-build-inputs.py verify "$MIRROR" "$OUT/ui-build-inputs.json" > "$OUT/ui-build-inputs-verify.json"

# Detect MAIN edits made during the run and pin final mirror contents for every
# copied source path. Generated dist outputs are intentionally outside cleanup.
python3 - "$MAIN" "$MIRROR" "$OUT/source-pins.json" "$OUT" <<'PY'
import hashlib,json,pathlib,sys
main,mirror,pins_path,out=map(pathlib.Path,sys.argv[1:])
pins=json.loads(pins_path.read_text()); rows=[]
for item in pins['copiedFiles']:
    rel=item['path']; p=mirror/rel
    if item.get('deleted'):
        assert not p.exists(),('unexpected deleted path reappeared',rel)
        rows.append({'path':rel,'deleted':True}); continue
    assert p.is_file(),('qualified source missing',rel)
    expected=hashlib.sha256((main/rel).read_bytes()).hexdigest()
    actual=hashlib.sha256(p.read_bytes()).hexdigest()
    assert expected==item['sha256']==actual,('source changed during aggregate',rel)
    rows.append({'path':rel,'sha256':actual})
(out/'qualified-tree-source-pins.json').write_text(json.dumps({'sourceHead':pins['sourceHead'],'sourcePinsSha256':hashlib.sha256(pins_path.read_bytes()).hexdigest(),'files':rows},indent=2)+'\n')
print(json.dumps({'verifiedFiles':len(rows),'status':'passed'}))
PY
git status --porcelain=v1 > "$OUT/main-status-after.txt"
[[ $(git rev-parse HEAD) == "$EXPECTED_HEAD" ]] || { echo 'MAIN HEAD changed during aggregate; reject this run' >&2; exit 68; }
cmp -s "$OUT/main-status-before.txt" "$OUT/main-status-after.txt" || { echo 'MAIN working tree changed during aggregate; reject this run' >&2; exit 68; }
df -h /workspace /tmp > "$OUT/disk-after.txt"
printf '%s\n' 'typecheck, test:run, build, source pin, and static UI input guard passed' > "$OUT/summary.txt"
