from pathlib import Path
import difflib,hashlib,json
r=Path('/workspace/blentera-v10');rel='server/src/services/native-direct-input.ts';a=(r/rel).read_text();s=a
old='''    repeatedAbsentOrigins: Record<string, number>; emitted: boolean }; activeByActor: Map<string, Set<string>>;'''
new='''    repeatedAbsentOrigins: Record<string, number>; emitted: boolean;
    nodeWork: Map<string, { index: number; kind: string; runOwner: number; memoryOwner: number; shape: number;
      hint: number; hints: Record<string, number>; calls: number; cold: number; hits: number; inputs: number; policyRefs: number;
      inputKinds: Record<string, number>; ownerKinds: Record<string, number>;
      workByFamily: Record<string, number>; components?: { count: number; incidences: number; union: number; kinds: Record<string, number> } }>;
    runOwners: Map<string, number>; memoryOwners: Map<string | null, number>; shapes: Map<string, number> };
  activeByActor: Map<string, Set<string>>;'''
assert old in s;s=s.replace(old,new,1)
old='''          firstLedgerByNode: new Map(), seenHintsByNode: new Map(), repeatedAbsentOrigins: {}, emitted: false } } : {}),'''
new='''          firstLedgerByNode: new Map(), seenHintsByNode: new Map(), repeatedAbsentOrigins: {}, emitted: false,
          nodeWork: new Map(), runOwners: new Map(), memoryOwners: new Map(), shapes: new Map() } } : {}),'''
assert old in s;s=s.replace(old,new,1)
old='''    diagnostic.graph.set(kind, counts);
  }
  let stack'''
new='''    diagnostic.graph.set(kind, counts);
    let node = diagnostic.nodeWork.get(key);
    if (!node && diagnostic.nodeWork.size < 512) {
      if (!diagnostic.runOwners.has(input.runId)) diagnostic.runOwners.set(input.runId, diagnostic.runOwners.size + 1);
      if (!diagnostic.memoryOwners.has(scope.context.memoryTemporalIdentity))
        diagnostic.memoryOwners.set(scope.context.memoryTemporalIdentity, diagnostic.memoryOwners.size + 1);
      const shapeKey = nativeSha256({ policy: input.policy, inputs: input.inputs });
      if (!diagnostic.shapes.has(shapeKey)) diagnostic.shapes.set(shapeKey, diagnostic.shapes.size + 1);
      const inputKinds: Record<string, number> = {};
      const owners = new Map<string, Set<string>>();
      for (const source of input.inputs) {
        inputKinds[source.kind] = (inputKinds[source.kind] ?? 0) + 1;
        const kindOwners = owners.get(source.kind) ?? new Set<string>();
        // Diagnostic row identity only; these values are never emitted or used
        // by proof eligibility, source validation, or reader decisions.
        kindOwners.add(nativeSha256(Object.fromEntries(Object.entries(source).filter(([field]) =>
          field === "kind" || field.endsWith("Id") || field === "origin" || field === "key"))));
        owners.set(source.kind, kindOwners);
      }
      node = { index: diagnostic.nodeWork.size + 1, kind,
        runOwner: diagnostic.runOwners.get(input.runId)!, memoryOwner: diagnostic.memoryOwners.get(scope.context.memoryTemporalIdentity)!,
        shape: diagnostic.shapes.get(shapeKey)!, hint: historicalDocumentDepthHint, hints: {},
        calls: 0, cold: 0, hits: 0, inputs: input.inputs.length,
        policyRefs: Object.values(input.policy).reduce((n, values) => n + values.length, 0), inputKinds,
        ownerKinds: Object.fromEntries([...owners].map(([name, values]) => [name, values.size])), workByFamily: {} };
      diagnostic.nodeWork.set(key, node);
    }
    if (node) { node.calls += 1; node[hit ? "hits" : "cold"] += 1;
      node.hints[historicalDocumentDepthHint] = (node.hints[historicalDocumentDepthHint] ?? 0) + 1; }
  }
  let stack'''
assert old in s;s=s.replace(old,new,1)
old='''  if (diagnostic) diagnostic.workByFamily[family] = (diagnostic.workByFamily[family] ?? 0) + 1;
  if (++scope.context.ancestry.work > 512)'''
new='''  if (diagnostic) {
    diagnostic.workByFamily[family] = (diagnostic.workByFamily[family] ?? 0) + 1;
    const frames = scope.context.ancestry.frozenTaskProofStacks.get(scope.actorKey) ?? [];
    for (let index = frames.length - 1; index >= 0; index--) {
      const node = diagnostic.nodeWork.get(frames[index]!.visitKey);
      if (node) { node.workByFamily[family] = (node.workByFamily[family] ?? 0) + 1; break; }
    }
  }
  if (++scope.context.ancestry.work > 512)'''
assert old in s;s=s.replace(old,new,1)
old='''        repeatedAbsentOrigins: diagnostic.repeatedAbsentOrigins,
        actorScopes:'''
new='''        repeatedAbsentOrigins: diagnostic.repeatedAbsentOrigins,
        nodeWork: [...diagnostic.nodeWork.values()],
        actorScopes:'''
assert old in s;s=s.replace(old,new,1)
old='''  // This local memo is scoped to this read-only component traversal only. It'''
new='''  const componentDiagnostic = scope.context.ancestry.diagnostics;
  if (componentDiagnostic) {
    const frames = scope.context.ancestry.frozenTaskProofStacks.get(scope.actorKey) ?? [];
    for (let index = frames.length - 1; index >= 0; index--) {
      const node = componentDiagnostic.nodeWork.get(frames[index]!.visitKey);
      if (node?.kind === "managed_consumed") {
        const kinds: Record<string, number> = {};
        for (const component of input.components) kinds[component.kind] = (kinds[component.kind] ?? 0) + 1;
        node.components = { count: input.components.length,
          incidences: componentSets.reduce((n, set) => n + set.inputs.length, 0), union: combinedInputs.length, kinds };
        break;
      }
    }
  }
  // This local memo is scoped to this read-only component traversal only. It'''
assert old in s;s=s.replace(old,new,1)
o=Path('/workspace/v10-preparation/native-node-work-r60-candidate');p=o/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
(o/'candidate.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
(o/'manifest.json').write_text(json.dumps({rel:{'priorSha256':hashlib.sha256(a.encode()).hexdigest(),'candidateSha256':hashlib.sha256(s.encode()).hexdigest()}},indent=2))
