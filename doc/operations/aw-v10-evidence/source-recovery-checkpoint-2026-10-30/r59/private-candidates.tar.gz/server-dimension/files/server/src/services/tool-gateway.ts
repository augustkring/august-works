import { readSandboxBrokerAuthorityEnforcement } from "./runtime/control.js";
import { ToolModelEffectAdmissionError } from "./native-runtime/paid-transport-admission.js";
import { currentResourcePolicy } from "./resource-governance.js";
import { assertPackageExecution } from "./agent-packages/execution-gate.js";
import { assertExecutionGovernance } from "./ai-governance/execution-gate.js";
import { agentRunWritesRevoked } from "../agent-run-cancellation.js";
import { assertManagedRuntimeCommercialAuthority } from "./billing/managed-runtime-admission.js";
import { signalRunningProcess } from "@paperclipai/adapter-utils/server-utils";
import { resolveWorkflowConnectorSession, type WorkflowGatewayContext } from "./workflows/workflow-connector-authority.js";
import { validateWorkflowOutput, WorkflowOutputSchemaError } from "./workflows/workflow-output-schema.js";
import { COGNEE_STDIO_TEMPLATE, cogneeCloudUrl, callCogneeCloud } from "./cognee-connection.js";
import { HttpError } from "../errors.js";
import {
  authorizationService,
  canActorReadProjectPrivacy,
  issueReadSqlCondition,
  projectReadSqlCondition,
  type AuthorizationActor,
} from "./authorization.js";
import { projectService } from "./projects.js";
import { agentService } from "./agents.js";
import { withCurrentTaskSourceRead } from "./task-source-read-scope.js";
import { decisionSearchService } from "./decisions.js";
import { processFindingService } from "./process-findings.js";
import { withNativeAnalyticalReader } from "./analytical-reader.js";
import { managedServiceHealthFromEnvironment } from "./experience/service-health.js";
import type { NativeModelOutputCapture } from "./native-runtime/native-execution-input.js";
import { nativeSha256 } from "./native-runtime/canonical.js";
import {
  AGENT_NATIVE_OPERATION_MANIFEST,
  agentNativeOperationForLegacyToolName,
  agentNativeOperationForToolName,
  agentNativeOperationManifestHash,
  blenteraToolCatalogContractHash,
} from "./agent-native-operation-manifest.js";
import { CAPABILITY_SEMANTIC_TOOL_CATALOG, paperclipSemanticAction } from "../vendor/paperclip-runner/index.js";
import { PaperclipRunnerToolAuthority } from "./native-runtime/paperclip-runner-tool-authority.js";
import { claimSlackRateLimitRetry } from "./connectors/slack-retry.js";
import { assertPlatformSkillAdmission } from "./platform-skill-admission.js";
import { resolveSlackTaskAuthority } from "./connectors/slack-authority.js";
import { SLACK_TOOLS, SANDBOX_HOST_COMMAND } from "@paperclipai/shared";
import { slackToolsForSession } from "./connectors/slack-catalog.js";
import { executeSlackTool } from "./connectors/slack.js";
import { githubGuestBotConnectionForSession, githubBotToolsForSession } from "./chat-github-tools.js";
import { githubChatReviewService } from "./chat-github-reviews.js";
import { runIdentityContexts } from "@paperclipai/db";
import { captureRunIdentity } from "./run-identity.js";
import { emitConnectionInvoked } from "./connector-telemetry.js";
import { resolveManagedGitHubIdentitySelection } from "./git-credentials.js";
import { extractRemoteMcpPending } from "./remote-mcp-pending.js";
import { logger } from "../middleware/logger.js";
import { createSandboxQualificationCredentialJwt, verifySandboxBrokerJwt, verifySandboxQualificationCredentialJwt, type SandboxBrokerCapabilityClaim, type SandboxQualificationCredentialClaim } from "../agent-auth-jwt.js";
import { spawn } from "node:child_process";
import { createHash, randomBytes, randomUUID, timingSafeEqual } from "node:crypto";
import {
  and,
  asc,
  desc,
  eq,
  gt,
  inArray,
  isNull,
  lte,
  ne,
  or,
  sql,
} from "drizzle-orm";
import type { Db } from "@paperclipai/db";
import {
  agents,
  agentPresenceRuntimeBindings,
  agentExecutionManifests,
  approvals,
  companies,
  companyMemberships,
  companySecrets,
  connectionGrantMembers,
  connectionGrantDelegations,
  connectionGrants,
  documents,
  heartbeatRuns,
  issueApprovals,
  issueDocuments,
  issueThreadInteractions,
  issues,
  memoryRecords,
  projects,
  toolActionRequests,
  toolActionDeliveries,
  toolAccessAuditEvents,
  toolApplications,
  toolCallEvents,
  toolCatalogEntries,
  toolConnections,
  toolGatewayRateLimitCounters,
  toolGatewaySessions,
  toolInvocations,
  toolMcpGateways,
  toolMcpGatewayTokens,
  toolPolicies,
  toolProfileBindings,
  toolProfileEntries,
  toolProfiles,
  toolStdioCommandTemplates,
  runtimeHostCommands,
  runtimePolicySnapshots,
} from "@paperclipai/db";
import { authSessions, runtimeCells, runtimeHosts, runtimeSandboxBindings } from "@paperclipai/db";
import { assertConfiguredOperatorAuthentication } from "../auth/authenticator-assurance.js";
import { assertV7Authorization } from "./v7-authorization.js";

let nativeRememberFailureDiagnostics = 0;
import type { ToolRunContext } from "@paperclipai/plugin-sdk";
import type {
  CreateToolMcpGateway,
  CreateToolMcpGatewayToken,
  DeploymentExposure,
  DeploymentMode,
  McpConnectionCredentialRef,
  SecretVersionSelector,
  ToolAccessDecision,
  ToolAccessDecisionInput,
  ToolConnectionTestCallStatus,
  ToolUpstreamPending,
  ToolConnectionTestCallStatusPhase,
  ToolCredentialSecretRef,
  ToolMcpGateway,
  ToolMcpGatewayClientSnippet,
  ToolMcpGatewayToken,
  ToolMcpGatewayTokenAction,
  ToolMcpGatewayTokenCreated,
  ToolMcpGatewayWithTokens,
  UpdateToolMcpGateway,
  SandboxPolicy,
  SandboxCapabilitySnapshot,
} from "@paperclipai/shared";
import {
  memoryAgentRememberInputSchema,
  memoryAgentCorrectInputJsonSchema,
  memoryAgentRecallInputJsonSchema,
  memoryAgentRememberInputJsonSchema,
  memoryAgentShareInputJsonSchema,
  workflowAuthoringAddStepInputJsonSchema,
  workflowAuthoringAddTriggerInputJsonSchema,
  workflowAuthoringConnectStepsInputJsonSchema,
  workflowAuthoringCreateInputJsonSchema,
  workflowAuthoringPublishInputJsonSchema,
  workflowAuthoringRemoveStepInputJsonSchema,
  workflowAuthoringTestStepInputJsonSchema,
  workflowAuthoringUpdateStepInputJsonSchema,
} from "@paperclipai/shared";
import {
  isGitHubConnectorProfileId,
  isGoogleWorkspaceConnectorProfileId,
  type GitHubConnectorProfileId,
  type GoogleWorkspaceConnectorProfileId,
} from "@paperclipai/shared";
import type {
  AgentToolDescriptor,
  PluginToolDispatcher,
} from "./plugin-tool-dispatcher.js";
import { logActivity, type LogActivityInput } from "./activity-log.js";
import { secretService } from "./secrets.js";
import { railwayCommandBudgetMs, createRailwayClient, isRailwayConnection, isRailwayEndpoint, isRailwayToolBlocked, normalizeRailwayToolName, RAILWAY_TOOLS, RAILWAY_API_URL, RAILWAY_TOOL_PREFIX, RailwayError } from "./railway.js";
import { RAILWAY_SSH_SECRET_PATH, runRailwaySshCommand } from "./railway-ssh.js";
import {
  MCP_PROTOCOL_VERSION,
  SUPPORTED_MCP_PROTOCOL_VERSIONS,
  initializeMcpHttpSession,
  getMcpHttpSession,
  forgetMcpHttpSessions,
  readMcpHttpResponse,
  McpHttpResponseError,
  mcpHttpRequestHeaders,
  parseMcpHttpResponseBody,
} from "./mcp-http.js";
import {
  projectedConnectionHeaders,
  projectedConnectionToolArguments,
  projectedConnectionToolInputSchema,
  toolAccessService,
} from "./tool-access.js";
import { assertGoogleChatToolArgumentsSupported, googleChatToolDescription } from "./google-chat-tool-policy.js";
import { parseRemoteHttpEndpoint } from "./remote-http-endpoint-guard.js";
import {
  guardedRemoteHttpFetch,
  type GuardedRemoteHttpFetchOptions,
} from "./remote-http-fetch.js";
import {
  REMOTE_URL_SECRET_CONFIG_PATH,
  remoteUrlCredentialMatchesPublicUrl,
} from "./remote-url-credentials.js";
import { toolAccessPolicyService } from "./tool-access-policy.js";
import { commitToolActionReview } from "./tool-action-review.js";
import { issueThreadInteractionService } from "./issue-thread-interactions.js";
import {
  createToolRuntimeSupervisor,
  ToolRuntimeSupervisorError,
  type ToolRuntimeSupervisorOptions,
  type ToolRuntimeSlotView,
} from "./tool-runtime-supervisor.js";
import { recordToolRuntimeAuditWriteFailure } from "./tool-runtime-metrics.js";
import { isRetiredComposioConnection, RETIRED_COMPOSIO_MESSAGE } from "@paperclipai/shared";
import {
  createPaperclipCloudConnector,
  isPaperclipCloudConnectorStrategy,
  paperclipCloudConnectorConfigFromEnv,
  PaperclipCloudConnectorError,
  type PaperclipCloudConnector,
} from "./paperclip-cloud-connector.js";
import {
  createVercelConnectClient,
  vercelGrantReference,
  vercelTokenRequest,
  VercelConnectClientError,
  type VercelConnectClient,
} from "./vercel-connect.js";
import {
  canonicalToolArguments,
  readSignedToolArgumentsPayload,
  signToolArguments,
  summarizeToolValue,
  TOOL_ACTION_REQUEST_SIGNING_GRACE_MS,
  ToolActionSigningSecretMissingError,
  ToolContentValidationError,
  validateToolContent,
  verifyToolArgumentsSignature,
} from "./tool-content-guards.js";
import { extendApprovedExecutionWaitDeadline } from "./approved-execution-wait.js";
import { instanceSettingsService } from "./instance-settings.js";
import { memoryAgentToolsService } from "./memory/memory-agent-tools.js";
import { sealNativeMemoryToolResultSnapshot, type MemoryMutationActor } from "./memory/memory-service.js";
import { workflowAuthoringToolsService } from "./workflows/workflow-authoring-tools.js";
import { foundationAuthoringToolsService } from "./foundation-authoring-tools.js";
import { foundationAuthoringProposeInputJsonSchema } from "@paperclipai/shared";
import { notificationPreferenceProposalService } from "./notification-preference-proposals.js";
import { notificationPreferenceProposalInputJsonSchema } from "@paperclipai/shared";
import { routineAuthoringToolsService } from "./routine-authoring-tools.js";
import { agentSetupAuthoringToolsService } from "./agent-setup-authoring-tools.js";
import { customerSupportCaseService } from "./experience/support-cases.js";
import { readSupportCaseDataPolicy } from "./experience/support-case-configuration.js";
import { agentSetupAuthoringInputJsonSchema, agentSetupCatalogInputJsonSchema } from "@paperclipai/shared";
import { routineAuthoringCreateInputJsonSchema, v9FeatureEnabled } from "@paperclipai/shared";

const DEFAULT_SESSION_TTL_MS = 15 * 60 * 1000;
const MAX_SESSION_TTL_MS = 60 * 60 * 1000;
const DEFAULT_TOOL_TIMEOUT_MS = 10_000;

export function resolveCredentialGrantKind(
  policy: "shared" | "per_user" | "per_user_with_fallback" | "per_agent",
  actingUserId: string | null,
  hasUserGrant: boolean,
): "organization" | "user" | "user_authorization_required" {
  if (policy === "per_agent") return "user_authorization_required";
  if (policy === "shared") return "organization";
  if (actingUserId && hasUserGrant) return "user";
  return policy === "per_user" ? "user_authorization_required" : "organization";
}

export function isConnectionGrantAudienceAllowed(
  memberUserIds: string[],
  actingUserId: string | null,
  actingUserIsActiveMember: boolean,
): boolean {
  if (actingUserId !== null && !actingUserIsActiveMember) return false;
  return (
    memberUserIds.length === 0 ||
    (actingUserId !== null && memberUserIds.includes(actingUserId))
  );
}
// When a human approves a parked write, the server carries it out on their
// behalf with no interactive caller left to raise `timeoutMs`. Remote write
// providers (e.g. Zapier Google Sheets `add_row`) routinely take longer than
// the 10s interactive default, so an approved action would otherwise abort with
// `tool_timeout` even though the approval succeeded. Give approved executions
// the full permitted headroom instead.
const APPROVED_EXECUTION_TIMEOUT_MS = 60_000;
const ACTION_REQUEST_EXECUTION_POLL_MS = 25;
// Approval execution performs live target, signature, managed-argument, and
// issue-state checks before provider dispatch. Give that preparation a
// separate bounded window so it cannot consume the provider's execution
// budget for concurrent consumers.
const ACTION_REQUEST_PREPARATION_WAIT_MS = 2 * 60 * 1000;
// Concurrent consumers must wait at least as long as the provider execution
// they are joining. The extra grace lets the owner persist the terminal request
// state after the provider timeout/result settles.
const ACTION_REQUEST_EXECUTION_WAIT_MS = APPROVED_EXECUTION_TIMEOUT_MS + 5_000;
// The gateway creates an ask-first request in two steps: it inserts the row
// with a null signature, then it signs the row and sets the expiry. A concurrent
// matching call can observe the row in this window. A null signature alone does
// not prove the create stopped; the create can still run in another request. Only
// treat an unsigned row as abandoned after this grace time from createdAt. This
// grace must exceed the normal sign path (approval-snapshot fetch + interaction
// create) so a live create keeps its own row.
const MAX_REMOTE_MCP_RESPONSE_BYTES = 1_000_000;
const ACTIVE_GATEWAY_RUN_STATUSES = new Set(["running"]);
const uuidPattern =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

type McpGatewayProtocolMethod =
  | "initialize"
  | "tools/list"
  | "tools/call"
  | "resources/list"
  | "resources/read"
  | "prompts/list"
  | "prompts/get";
type McpGatewayRateLimitConfig = { windowMs: number; max: number };
type McpGatewayRateLimitState = {
  limited: boolean;
  count: number;
  retryAfterMs: number;
};
type McpGatewayProtocolLimitOptions = {
  authFailures: McpGatewayRateLimitConfig;
  gatewayRequests: McpGatewayRateLimitConfig;
  tokenRequests: McpGatewayRateLimitConfig;
  sessionSetup: McpGatewayRateLimitConfig;
};

const DEFAULT_MCP_GATEWAY_PROTOCOL_LIMITS: McpGatewayProtocolLimitOptions = {
  authFailures: { windowMs: 5 * 60 * 1000, max: 20 },
  gatewayRequests: { windowMs: 60 * 1000, max: 300 },
  tokenRequests: { windowMs: 60 * 1000, max: 120 },
  sessionSetup: { windowMs: 60 * 1000, max: 30 },
};
const TOOL_APPROVAL_DESCRIPTION_SUFFIX =
  "Requires human approval: calling it posts an approval card on your task and you will be woken with the result once decided.";

function runnerSemanticToolSchema(operationId: string): Record<string, unknown> {
  const tool = CAPABILITY_SEMANTIC_TOOL_CATALOG.find((candidate) => candidate.operationId === operationId);
  const action = paperclipSemanticAction(operationId);
  const schema = tool?.inputSchema ?? action?.inputSchema;
  if (!schema) throw new Error("agent_native_runner_tool_binding_missing");
  return schema as Record<string, unknown>;
}
const RUNNER_TASK_OPERATION_BY_SELF_TOOL: Readonly<Record<string, string>> = Object.freeze({
  "paperclip-self:create_task": "create_task",
  "paperclip-self:update_task": "update_task",
  "paperclip-self:propose_completion": "propose_completion",
  "paperclip-self:report_progress": "report_progress",
  "paperclip-self:reassign_task": "reassign_task",
  "paperclip-self:set_dependencies": "set_dependencies",
  "paperclip-self:create_project": "create_project",
  "paperclip-self:write_document": "write_document",
  "paperclip-self:request_human_input": "request_human_input",
});

export type ToolGatewayProviderType =
  | "mcp_http_fixture"
  | "mcp_stdio_fixture"
  | "mcp_remote_http"
  | "mcp_local_stdio"
  | "paperclip_self"
  | "paperclip_plugin"
  | "paperclip_virtual"
  | "paperclip_github_chat"
  | "paperclip_slack_chat";

export interface ConnectedMcpGatewayMetadata {
  applicationId: string;
  applicationKey: string | null;
  applicationDisplayName: string;
  connectionId: string;
  catalogEntryId: string;
  transport: "mcp_remote" | "local_stdio";
  gatewayToolName: string;
  upstreamToolName: string;
  catalogName: string;
  inputSchema: Record<string, unknown>;
  outputSchema: Record<string, unknown> | null;
  annotations: Record<string, unknown>;
  risk: {
    level: string;
    isReadOnly: boolean;
    isWrite: boolean;
    isDestructive: boolean;
  };
  onDemandTools?: boolean;
}

export interface ToolGatewayDescriptor extends AgentToolDescriptor {
  providerType: ToolGatewayProviderType;
  risk: "read" | "write" | "destructive";
  applicationId?: string | null;
  applicationKey?: string | null;
  applicationDisplayName?: string | null;
  connectionId?: string | null;
  catalogEntryId?: string | null;
  upstreamToolName?: string | null;
  providerMetadata?: ConnectedMcpGatewayMetadata | Record<string, unknown>;
}

export interface BlenteraPlatformContractHashes {
  operationManifestHash: string;
  toolCatalogContractHash: string;
}

export interface ToolGatewaySession {
  id: string;
  token: string;
  companyId: string;
  agentId: string | null;
  runId: string | null;
  issueId: string | null;
  projectId: string | null;
  gatewayId?: string | null;
  gatewayPublicId?: string | null;
  gatewayName?: string | null;
  gatewayProfileId?: string | null;
  gatewayTokenId?: string | null;
  gatewayTokenAllowedActions?: ToolMcpGatewayTokenAction[];
  actorType?: "agent" | "user" | "system" | "plugin";
  actorId?: string | null;
  /** Human whose personal connection grant applies to this execution. */
  responsibleUserId?: string | null;
  /** Captured by the controller for this request, never accepted from tool arguments. */
  identityContextId?: string | null;
  /** Set only after verifying the signed approved action. */
  approvedSlackInvocationId?: string;
  createdAt: Date;
  expiresAt: Date;
  workflowRunId?: string;
  workflowNodeId?: string;
  sandboxBrokerCapability?: SandboxBrokerCapabilityClaim;
}

export interface BlenteraGovernedRunBindingAttestation {
  protocolVersion: 1;
  companyId: string;
  agentId: string;
  paperclipRunId: string;
  responsibleUserId: string;
  runtimeAdapter: string;
  runtimeCapabilitySnapshotHash: string | null;
  platformSkill: { key: string; version: string; digest: string; sourceSha: string };
  operationManifestHash: string;
  toolCatalogContractHash: string;
  gatewayId: string;
  gatewayPublicId: string;
  gatewayProfileId: string | null;
  assignmentDigest: string | null;
  tokenExpiresAt: string;
}

export type SandboxBrokerAuthority = (input: {
  capabilityToken: string;
  gatewayPublicId: string;
}) => Promise<SandboxBrokerCapabilityClaim>;

export interface SandboxCredentialBrokerBinding {
  connectionId: string;
  grantVersionHash: string;
  gatewayPublicId: string;
  endpointPath: string;
  allowedTools: string[];
  binary: string | null;
  destination: { hostname: string; port: number; method: "POST"; path: string };
}

export type ToolGatewayRuntimeSlot = ToolRuntimeSlotView;

/** Server-owned delegation; never read from request bodies or gateway tokens. */
export interface ScopedToolGatewayContext {
  session: ToolGatewaySession;
  /** Current-run disclosure aperture for tool.list; it never authorizes invocation. */
  discoveryCatalogEntryIds?: readonly string[];
  assertCurrent: (tool?: ToolGatewayDescriptor) => Promise<void>;
  /** Verify a selected catalog pin after current policy has been evaluated. */
  assertManifestCurrent?: (tool: ToolGatewayDescriptor) => Promise<void>;
}

// The output witness is process-local capability state, never a field on an
// HTTP request or serializable scoped context.
const nativeMemoryOutputCaptures = new WeakMap<ScopedToolGatewayContext, NativeModelOutputCapture>();
export function bindManagedNativeMemoryOutputCapture(context: ScopedToolGatewayContext, capture: NativeModelOutputCapture) {
  nativeMemoryOutputCaptures.set(context, capture);
  return context;
}
function nativeMemoryOutputCapture(context: ScopedToolGatewayContext | undefined) {
  return context ? nativeMemoryOutputCaptures.get(context) : undefined;
}

/** Revalidate the canonical result and its Native Memory owner before a scoped idempotent replay. */
export async function assertScopedNativeMemoryReplayReceiptCurrent(db: Db, input: {
  companyId: string; runId: string; agentId: string; issueId: string; callId: string;
  invocationId: string; argumentsHash: string; result: unknown;
}): Promise<{ recordId: string; snapshotDigest: string }> {
  if (input.result === null || input.result === undefined) throw new ToolGatewayHttpError(403,
    "Managed Memory replay receipt is unavailable", "native_memory_capture_invalid");
  const resultRecord = asRecord(input.result);
  const resultData = asRecord(resultRecord?.data);
  const resultMemory = asRecord(resultData?.record);
  const recordId = typeof resultMemory?.id === "string" ? resultMemory.id : null;
  const resultSummary = validateToolContent({ value: input.result, direction: "result",
    sensitiveMode: "redact", promptInjectionMode: "block" }).summary;
  if (!recordId || !resultSummary.sha256) throw new ToolGatewayHttpError(403,
    "Managed Memory replay receipt is unavailable", "native_memory_capture_invalid");
  const [transactionStart] = await db.execute<{ transactionId: string }>(sql`select txid_current()::text as "transactionId"`);
  if (!transactionStart?.transactionId) throw new ToolGatewayHttpError(403,
    "Managed Memory replay transaction is unavailable", "native_memory_capture_invalid");
  const [invocation] = await db.select({ status: toolInvocations.status, argumentsHash: toolInvocations.argumentsHash,
    resultHash: toolInvocations.resultHash, workflowResultJson: toolInvocations.workflowResultJson })
    .from(toolInvocations).where(and(eq(toolInvocations.id, input.invocationId),
      eq(toolInvocations.companyId, input.companyId), eq(toolInvocations.runId, input.runId),
      eq(toolInvocations.agentId, input.agentId), eq(toolInvocations.issueId, input.issueId),
      eq(toolInvocations.idempotencyKey, `aw-native-tool:${input.runId}:${input.callId}`),
      eq(toolInvocations.toolName, "paperclip-self:remember"))).for("share");
  if (!invocation || invocation.status !== "succeeded" || invocation.argumentsHash !== input.argumentsHash ||
    invocation.resultHash !== resultSummary.sha256 || invocation.workflowResultJson === null ||
    nativeSha256(invocation.workflowResultJson) !== nativeSha256(input.result))
    throw new ToolGatewayHttpError(403, "Managed Memory replay receipt is no longer current",
      "native_memory_capture_invalid");
  const { memoryPayloadVisible } = await import("./memory/memory-privacy.js");
  const [output] = await db.select({ deletedAt: memoryRecords.deletedAt, revokedAt: memoryRecords.revokedAt,
    expiresAt: memoryRecords.expiresAt,
    retentionState: memoryRecords.retentionState, reviewState: memoryRecords.reviewState,
    createdByActorType: memoryRecords.createdByActorType, createdByActorId: memoryRecords.createdByActorId,
    sourceRunIds: memoryRecords.sourceRunIds,
    sourceProvenanceQualified: memoryRecords.sourceProvenanceQualified,
    payloadSourceProtocolVersion: memoryRecords.payloadSourceProtocolVersion,
    payloadSourceSnapshot: memoryRecords.payloadSourceSnapshot,
    payloadSourceSnapshotInvalidated: memoryRecords.payloadSourceSnapshotInvalidated,
    metadata: memoryRecords.metadata }).from(memoryRecords).where(and(
      eq(memoryRecords.companyId, input.companyId), eq(memoryRecords.id, recordId), memoryPayloadVisible(),
      isNull(memoryRecords.revokedAt), or(isNull(memoryRecords.expiresAt), gt(memoryRecords.expiresAt, sql`clock_timestamp()`)),
      eq(memoryRecords.retentionState, "active"), inArray(memoryRecords.reviewState, ["pending", "accepted"]),
      eq(memoryRecords.payloadSourceSnapshotInvalidated, false), eq(memoryRecords.payloadSourceProtocolVersion, 1))).for("share");
  const metadata = output?.metadata && typeof output.metadata === "object" && !Array.isArray(output.metadata)
    ? output.metadata as Record<string, unknown> : null;
  const { nativePayloadSourceSnapshotSchema } = await import("@paperclipai/shared");
  const snapshot = nativePayloadSourceSnapshotSchema.safeParse(output?.payloadSourceSnapshot);
  if (!output || output.deletedAt || output.revokedAt || output.expiresAt && output.expiresAt.getTime() <= Date.now() ||
    output.retentionState !== "active" ||
    !["pending", "accepted"].includes(output.reviewState) || output.createdByActorType !== "agent" ||
    output.createdByActorId !== input.agentId || !output.sourceProvenanceQualified ||
    output.payloadSourceProtocolVersion !== 1 || output.payloadSourceSnapshotInvalidated ||
    metadata?.nativeManagedMemoryInvocationId !== input.invocationId ||
    metadata.nativeManagedMemoryCallId !== input.callId || metadata.nativeManagedMemoryArgumentsHash !== input.argumentsHash ||
    !output.sourceRunIds.includes(input.runId) ||
    !snapshot.success || !snapshot.data.inputs.some(source => source.kind === "task" && source.issueId === input.issueId) ||
    snapshot.data.owner.kind !== "memory_record" ||
    snapshot.data.owner.companyId !== input.companyId || snapshot.data.owner.id !== recordId)
    throw new ToolGatewayHttpError(403, "Managed Memory output is no longer current", "native_memory_capture_invalid");
  const [owner] = await db.execute<{ valid: boolean }>(sql`select
    public.aw_native_payload_body_hash('memory_record',to_jsonb(m))=${snapshot.data.owner.contentHash}
      and encode(sha256(convert_to((m.payload_source_snapshot-'digest')::text,'UTF8')),'hex')=${snapshot.data.digest} as valid
    from ${memoryRecords} m where m.company_id=${input.companyId}::uuid and m.id=${recordId}::uuid`);
  const [transactionEnd] = await db.execute<{ transactionId: string }>(sql`select txid_current()::text as "transactionId"`);
  if (!owner?.valid || transactionEnd?.transactionId !== transactionStart.transactionId)
    throw new ToolGatewayHttpError(403, "Managed Memory output changed during replay validation",
      "native_memory_capture_invalid");
  return { recordId, snapshotDigest: snapshot.data.digest };
}

export class ToolGatewayHttpError extends Error {
  constructor(
    public readonly status: number,
    message: string,
    public readonly reasonCode: string,
    public readonly details: Record<string, unknown> = {},
  ) {
    super(message);
  }
}

interface ExecuteGatewayToolInput {
  sessionToken: string;
  gatewayId?: string | null;
  gatewayPublicId?: string | null;
  tool: string;
  parameters?: unknown;
  timeoutMs?: number;
  signal?: AbortSignal;
  approvedActionRequestId?: string | null;
  idempotencyKey?: string | null;
  callerHeaders?: Record<string, string | string[] | undefined>;
}


interface ExecuteTestCallInput {
  companyId: string;
  connectionId: string;
  agentId: string;
  userId: string;
  toolName: string;
  parameters?: unknown;
  timeoutMs?: number;
}

interface ExecutePluginToolInput {
  actor: {
    type: "agent" | "board";
    agentId?: string | null;
    companyId?: string | null;
    userId?: string | null;
    runId?: string | null;
  };
  tool: string;
  parameters: unknown;
  runContext: ToolRunContext;
}

type HeaderPolicyConfig = {
  staticHeaders: Array<{ name: string; value: string }>;
  passthroughAllowlist: string[];
  metadataHeaders: Array<
    | "company_id"
    | "agent_id"
    | "issue_id"
    | "project_id"
    | "run_id"
    | "gateway_session_id"
    | "correlation_id"
  >;
};

type HeaderPolicySummary = {
  staticHeaderNames: string[];
  credentialHeaderNames: string[];
  passthroughHeaderNames: string[];
  droppedPassthroughHeaderNames: string[];
  metadataHeaderNames: string[];
  collisionRules: Array<{ header: string; source: string; action: string }>;
};

type RemoteHttpExecutionResult = {
  result: unknown;
  headerSummary?: HeaderPolicySummary;
  execution?: RemoteHttpExecutionAudit;
};

type RemoteHttpExecutionAudit = {
  transport: "mcp_remote";
  request: {
    protocol: "MCP JSON-RPC 2.0" | "Railway GraphQL" | "Railway GraphQL + SSH";
    httpMethod: "POST";
    endpoint: string;
    mcpMethod: "tools/call";
    requestId: string;
    upstreamToolName: string;
    dispatched: boolean;
  };
  response?: {
    httpStatus: number;
    contentType: string | null;
    bodySizeBytes: number;
    upstreamRequestId: string | null;
  };
};

type LocalStdioRuntimeTemplate = {
  templateId: string;
  command: string | null;
  args: string[];
  envKeys: string[];
};

const BUILTIN_LOCAL_STDIO_RUNTIME_TEMPLATES: Record<
  string,
  Omit<LocalStdioRuntimeTemplate, "templateId">
> = {
  "paperclip.cognee-cloud": COGNEE_STDIO_TEMPLATE,
  "paperclip.google-sheets": {
    command: "paperclip-google-sheets-mcp-server",
    args: [],
    envKeys: [
      "GOOGLE_SHEETS_SERVICE_ACCOUNT_JSON",
      "GOOGLE_SHEETS_SERVICE_ACCOUNT_JSON_PATH",
      "GOOGLE_SHEETS_ALLOWED_SPREADSHEET_IDS",
    ],
  },
  "paperclip.echo-calculator-time": {
    command: null,
    args: [],
    envKeys: [],
  },
  "paperclip.synthetic-todo-kv": {
    command: null,
    args: [],
    envKeys: [],
  },
};

function asRecord(value: unknown): Record<string, unknown> | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  return value as Record<string, unknown>;
}

const sensitivePassthroughHeaderPattern =
  /(^|[-_])(auth|authorization|cookie|secret|session|token)([-_]|$)|(^|[-_])api[-_]?key([-_]|$)/i;
const sensitivePassthroughHeaderNames = new Set([
  "authorization",
  "proxy-authorization",
  "cookie",
  "set-cookie",
  "x-paperclip-tool-gateway-token",
]);

function isSensitivePassthroughHeader(name: string) {
  return (
    name.startsWith("x-paperclip-") ||
    sensitivePassthroughHeaderNames.has(name) ||
    sensitivePassthroughHeaderPattern.test(name)
  );
}

function stringValue(value: unknown): string | null {
  return typeof value === "string" && value.trim().length > 0 ? value : null;
}

function auditSafeEndpoint(endpoint: string): string {
  try {
    const url = new URL(endpoint);
    return `${url.origin}${url.pathname}`;
  } catch {
    return "configured remote MCP endpoint";
  }
}

function executionAuditFromError(
  error: unknown,
): RemoteHttpExecutionAudit | undefined {
  if (!(error instanceof ToolGatewayHttpError)) return undefined;
  const execution = error.details.execution;
  if (!execution || typeof execution !== "object" || Array.isArray(execution))
    return undefined;
  return execution as RemoteHttpExecutionAudit;
}

function generateGatewayToken(sessionId: string) {
  return `pcgt_${sessionId}.${randomBytes(32).toString("base64url")}`;
}

function generateNamedGatewayToken(tokenId: string) {
  return `pcgw_${tokenId}.${randomBytes(32).toString("base64url")}`;
}

function hashGatewayToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

function sessionIdFromGatewayToken(token: string) {
  const match = token.match(/^pcgt_([0-9a-fA-F-]{36})\.[A-Za-z0-9_-]+$/);
  return match?.[1] ?? null;
}

function namedGatewayTokenId(token: string) {
  const match = token.match(/^pcgw_([0-9a-fA-F-]{36})\.[A-Za-z0-9_-]+$/);
  return match?.[1] ?? null;
}

function positiveInt(value: string | undefined, fallback: number) {
  const parsed = Number.parseInt(value ?? "", 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

function mergeLimitConfig(
  defaults: McpGatewayRateLimitConfig,
  overrides: Partial<McpGatewayRateLimitConfig> | undefined,
): McpGatewayRateLimitConfig {
  return {
    windowMs:
      overrides?.windowMs && overrides.windowMs > 0
        ? overrides.windowMs
        : defaults.windowMs,
    max: overrides?.max && overrides.max > 0 ? overrides.max : defaults.max,
  };
}

function mcpGatewayProtocolLimits(
  overrides:
    | Partial<{
        authFailures: Partial<McpGatewayRateLimitConfig>;
        gatewayRequests: Partial<McpGatewayRateLimitConfig>;
        tokenRequests: Partial<McpGatewayRateLimitConfig>;
        sessionSetup: Partial<McpGatewayRateLimitConfig>;
      }>
    | undefined,
): McpGatewayProtocolLimitOptions {
  const envDefaults: McpGatewayProtocolLimitOptions = {
    authFailures: {
      windowMs: positiveInt(
        process.env.PAPERCLIP_MCP_GATEWAY_AUTH_FAILURE_WINDOW_MS,
        DEFAULT_MCP_GATEWAY_PROTOCOL_LIMITS.authFailures.windowMs,
      ),
      max: positiveInt(
        process.env.PAPERCLIP_MCP_GATEWAY_AUTH_FAILURE_LIMIT,
        DEFAULT_MCP_GATEWAY_PROTOCOL_LIMITS.authFailures.max,
      ),
    },
    gatewayRequests: {
      windowMs: positiveInt(
        process.env.PAPERCLIP_MCP_GATEWAY_REQUEST_WINDOW_MS,
        DEFAULT_MCP_GATEWAY_PROTOCOL_LIMITS.gatewayRequests.windowMs,
      ),
      max: positiveInt(
        process.env.PAPERCLIP_MCP_GATEWAY_REQUEST_LIMIT,
        DEFAULT_MCP_GATEWAY_PROTOCOL_LIMITS.gatewayRequests.max,
      ),
    },
    tokenRequests: {
      windowMs: positiveInt(
        process.env.PAPERCLIP_MCP_GATEWAY_TOKEN_REQUEST_WINDOW_MS,
        DEFAULT_MCP_GATEWAY_PROTOCOL_LIMITS.tokenRequests.windowMs,
      ),
      max: positiveInt(
        process.env.PAPERCLIP_MCP_GATEWAY_TOKEN_REQUEST_LIMIT,
        DEFAULT_MCP_GATEWAY_PROTOCOL_LIMITS.tokenRequests.max,
      ),
    },
    sessionSetup: {
      windowMs: positiveInt(
        process.env.PAPERCLIP_MCP_GATEWAY_SESSION_SETUP_WINDOW_MS,
        DEFAULT_MCP_GATEWAY_PROTOCOL_LIMITS.sessionSetup.windowMs,
      ),
      max: positiveInt(
        process.env.PAPERCLIP_MCP_GATEWAY_SESSION_SETUP_LIMIT,
        DEFAULT_MCP_GATEWAY_PROTOCOL_LIMITS.sessionSetup.max,
      ),
    },
  };
  return {
    authFailures: mergeLimitConfig(
      envDefaults.authFailures,
      overrides?.authFailures,
    ),
    gatewayRequests: mergeLimitConfig(
      envDefaults.gatewayRequests,
      overrides?.gatewayRequests,
    ),
    tokenRequests: mergeLimitConfig(
      envDefaults.tokenRequests,
      overrides?.tokenRequests,
    ),
    sessionSetup: mergeLimitConfig(
      envDefaults.sessionSetup,
      overrides?.sessionSetup,
    ),
  };
}

function tokenPrefixFromNamedBearer(token: string) {
  const tokenId = namedGatewayTokenId(token);
  if (tokenId) return `pcgw_${tokenId.slice(0, 8)}`;
  return token.startsWith("pcgw_") ? "pcgw_malformed" : "unknown";
}

function safeHeaderValue(
  headers: Record<string, string | string[] | undefined> | undefined,
  name: string,
  maxLength = 160,
) {
  const value = headers?.[name] ?? headers?.[name.toLowerCase()];
  const raw = Array.isArray(value) ? value[0] : value;
  if (!raw) return null;
  const sanitized = raw.replace(/[\r\n\t]/g, " ").trim();
  return sanitized ? sanitized.slice(0, maxLength) : null;
}

function safeClientMetadata(
  headers: Record<string, string | string[] | undefined> | undefined,
) {
  const clientName =
    safeHeaderValue(headers, "x-paperclip-client-name", 120) ??
    safeHeaderValue(headers, "mcp-client-name", 120) ??
    null;
  const correlationId =
    safeHeaderValue(headers, "x-request-id", 120) ??
    safeHeaderValue(headers, "x-correlation-id", 120) ??
    null;
  return {
    clientName,
    correlationId,
    userAgent: safeHeaderValue(headers, "user-agent", 200),
  };
}

function rateLimitWindowStart(current: number, windowMs: number) {
  return new Date(Math.floor(current / windowMs) * windowMs);
}

function gatewaySessionFromRow(
  row: typeof toolGatewaySessions.$inferSelect,
): ToolGatewaySession {
  return {
    id: row.id,
    token: "",
    companyId: row.companyId,
    agentId: row.agentId,
    runId: row.runId,
    issueId: row.issueId,
    projectId: row.projectId,
    createdAt: row.createdAt,
    expiresAt: row.expiresAt,
  };
}

function timeoutMs(value: number | undefined) {
  if (!Number.isFinite(value)) return DEFAULT_TOOL_TIMEOUT_MS;
  return Math.max(
    1,
    Math.min(60_000, Math.floor(value ?? DEFAULT_TOOL_TIMEOUT_MS)),
  );
}

function sessionTtlMs(value: number | undefined) {
  if (!Number.isFinite(value)) return DEFAULT_SESSION_TTL_MS;
  return Math.max(
    1_000,
    Math.min(MAX_SESSION_TTL_MS, Math.floor(value ?? DEFAULT_SESSION_TTL_MS)),
  );
}

function summarizeResult(result: unknown): Record<string, unknown> {
  const record = asRecord(result);
  if (!record) return { type: typeof result };
  const content = typeof record.content === "string" ? record.content : null;
  return {
    hasContent: content !== null,
    contentLength: content?.length ?? 0,
    hasData: record.data !== undefined,
    hasError: Boolean(record.error),
  };
}

function inferToolRisk(toolName: string): ToolGatewayDescriptor["risk"] {
  const lower = toolName.toLowerCase();
  if (
    /\b(delete|destroy|remove|drop|truncate|wipe|purge)\b|(^|[:._-])(delete|destroy|remove|drop|truncate|wipe|purge)([:._-]|$)/.test(
      lower,
    )
  ) {
    return "destructive";
  }
  if (
    /\b(create|update|write|edit|patch|post|send|publish|merge|commit|apply)\b|(^|[:._-])(create|update|write|edit|patch|post|send|publish|merge|commit|apply)([:._-]|$)/.test(
      lower,
    )
  ) {
    return "write";
  }
  return "read";
}

function riskFromCatalogEntry(
  entry: Pick<
    typeof toolCatalogEntries.$inferSelect,
    "riskLevel" | "isReadOnly" | "isWrite" | "isDestructive"
  >,
): ToolGatewayDescriptor["risk"] {
  if (
    entry.riskLevel === "destructive" ||
    entry.isDestructive ||
    entry.riskLevel === "critical" ||
    entry.riskLevel === "high"
  ) {
    return "destructive";
  }
  if (
    entry.riskLevel === "write" ||
    entry.isWrite ||
    entry.riskLevel === "medium"
  ) {
    return "write";
  }
  return "read";
}

function slugSegment(
  value: string | null | undefined,
  fallback: string,
): string {
  const slug = String(value ?? "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 64);
  return slug || fallback;
}

function shortStableId(id: string): string {
  return id.replace(/-/g, "").slice(0, 8);
}

function toolRequiresFormalApproval(tool: ToolGatewayDescriptor): boolean {
  return tool.risk === "destructive";
}

function toolAuditMetadata(
  tool: ToolGatewayDescriptor,
): Record<string, unknown> {
  return {
    applicationId: tool.applicationId ?? null,
    applicationKey: tool.applicationKey ?? null,
    connectionId: tool.connectionId ?? null,
    catalogEntryId: tool.catalogEntryId ?? null,
    upstreamToolName: tool.upstreamToolName ?? tool.name,
    providerType: tool.providerType,
    risk: tool.risk,
    riskLevel: tool.risk,
  };
}

function stableSerialize(value: unknown): string {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableSerialize).join(",")}]`;
  return `{${Object.keys(value as Record<string, unknown>)
    .sort()
    .map(
      (key) =>
        `${JSON.stringify(key)}:${stableSerialize((value as Record<string, unknown>)[key])}`,
    )
    .join(",")}}`;
}

function stableHash(value: unknown): string {
  return createHash("sha256").update(stableSerialize(value)).digest("hex");
}

function normalizeSignedApprovalSnapshot(
  value: unknown,
): Record<string, unknown> | null {
  return asRecord(value);
}

function approvalSnapshotsMatch(
  reviewed: unknown,
  live: Record<string, unknown> | null,
): boolean {
  const reviewedRecord = normalizeSignedApprovalSnapshot(reviewed);
  if (!reviewedRecord && !live) return true;
  if (!reviewedRecord || !live) return false;
  return stableSerialize(reviewedRecord) === stableSerialize(live);
}

type ConnectedCredentialVersionSnapshot = {
  refHash: string;
  versionSelector: string;
  resolvedVersion: number;
};

const REDACTED_ARGUMENT_SENTINEL = "***REDACTED***";

/** Turn a machine field key (`note_body`, `noteBody`, `note-body`) into a Title-Cased label. */
function humanizeArgumentKey(key: string): string {
  const words = key
    .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
    .replace(/[_-]+/g, " ")
    .trim()
    .split(/\s+/)
    .filter(Boolean);
  if (words.length === 0) return key;
  return words
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

/** Identifier-ish fields leak raw IDs into the prosumer card; the vocab gate forbids them. */
function isIdentifierArgumentKey(key: string): boolean {
  return /(^|[_-])(id|ids|uuid|guid|key|token|hash|sha\d*)$/i.test(key);
}

/** Render a single argument value as short, plain text — or null if it shouldn't be shown. */
function humanizeArgumentValue(value: unknown): string | null {
  if (typeof value === "string") {
    const trimmed = value.trim();
    if (!trimmed) return null;
    if (trimmed === REDACTED_ARGUMENT_SENTINEL) return "hidden for privacy";
    return trimmed.length > 140 ? `${trimmed.slice(0, 137)}…` : trimmed;
  }
  if (typeof value === "number" || typeof value === "boolean")
    return String(value);
  return null;
}

/**
 * Build the prosumer-facing "Ask first" preview (M5/M7/M9). Deliberately free of the
 * words tool/risk/transport/arguments and of raw JSON — those only belong on the
 * Advanced surfaces (M8a/M8b) and the board-only formal-approval interaction.
 */
function buildHumanizedActionPreview(input: {
  tool: ToolGatewayDescriptor;
  argumentsSummary: ReturnType<typeof summarizeToolValue>;
}): string {
  const actionName = input.tool.displayName?.trim() || input.tool.name;
  const trustLine =
    input.tool.risk === "destructive"
      ? `${actionName}. This can permanently change or remove data.`
      : actionName;

  let parsed: unknown;
  try {
    parsed = JSON.parse(input.argumentsSummary.summary);
  } catch {
    return trustLine;
  }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed))
    return trustLine;

  const fieldLines: string[] = [];
  for (const [key, value] of Object.entries(
    parsed as Record<string, unknown>,
  )) {
    if (fieldLines.length >= 6) break;
    if (isIdentifierArgumentKey(key)) continue;
    const rendered = humanizeArgumentValue(value);
    if (rendered === null) continue;
    fieldLines.push(`**${humanizeArgumentKey(key)}:** ${rendered}`);
  }

  if (fieldLines.length === 0) return trustLine;
  return [trustLine, ...fieldLines].join(" · ");
}

const BUILTIN_TOOLS: ToolGatewayDescriptor[] = [
  {
    name: "mcp-remote-fixture:echo",
    displayName: "Remote fixture echo",
    description:
      "Remote HTTP MCP fixture that echoes a message without spawning a local process.",
    parametersSchema: {
      type: "object",
      properties: { message: { type: "string" } },
      required: ["message"],
      additionalProperties: false,
    },
    pluginId: "mcp-remote-fixture",
    providerType: "mcp_http_fixture",
    risk: "read",
  },
  {
    name: "mcp-remote-fixture:add",
    displayName: "Remote fixture add",
    description:
      "Remote HTTP MCP fixture that adds two numbers without spawning a local process.",
    parametersSchema: {
      type: "object",
      properties: { a: { type: "number" }, b: { type: "number" } },
      required: ["a", "b"],
      additionalProperties: false,
    },
    pluginId: "mcp-remote-fixture",
    providerType: "mcp_http_fixture",
    risk: "read",
  },
  {
    name: "mcp-remote-fixture:update_note",
    displayName: "Remote fixture update note",
    description:
      "Remote HTTP MCP fixture that simulates a side-effecting write.",
    parametersSchema: {
      type: "object",
      properties: { noteId: { type: "string" }, body: { type: "string" } },
      required: ["noteId", "body"],
      additionalProperties: false,
    },
    pluginId: "mcp-remote-fixture",
    providerType: "mcp_http_fixture",
    risk: "write",
  },
  {
    name: "paperclip-self:list_my_issues",
    displayName: "List my Paperclip issues",
    description:
      "Paperclip self-MCP read fixture that lists the authenticated agent's current issues.",
    parametersSchema: {
      type: "object",
      properties: { limit: { type: "number" } },
      additionalProperties: false,
    },
    pluginId: "paperclip-self",
    providerType: "paperclip_self",
    risk: "read",
  },
  {
    name: "paperclip-self:create_task",
    displayName: "Create Task",
    description: "Create governed follow-up work using the current Task owner and current run authority.",
    parametersSchema: runnerSemanticToolSchema("create_task"),
    pluginId: "paperclip-self", providerType: "paperclip_self", risk: "write",
  },
  {
    name: "paperclip-self:update_task",
    displayName: "Update Task fields",
    description: "Update title, description, or priority on the Task attached to the current run using its exact current revision.",
    parametersSchema: runnerSemanticToolSchema("update_task"),
    pluginId: "paperclip-self", providerType: "paperclip_self", risk: "write",
  },
  {
    name: "paperclip-self:propose_completion",
    displayName: "Request completion review",
    description: "Ask the accountable Human to review Task completion readiness; Task status remains under the Native finalizer and evidence policy.",
    parametersSchema: runnerSemanticToolSchema("propose_completion"),
    pluginId: "paperclip-self", providerType: "paperclip_self", risk: "write",
  },
  {
    name: "paperclip-self:report_progress",
    displayName: "Add internal Task comment",
    description: "Add an internal progress comment to the Task attached to the current run.",
    parametersSchema: runnerSemanticToolSchema("report_progress"),
    pluginId: "paperclip-self", providerType: "paperclip_self", risk: "write",
  },
  {
    name: "paperclip-self:reassign_task",
    displayName: "Reassign Task",
    description: "Reassign an eligible Task after the current owner and version checks.",
    parametersSchema: runnerSemanticToolSchema("reassign_task"),
    pluginId: "paperclip-self", providerType: "paperclip_self", risk: "write",
  },
  {
    name: "paperclip-self:set_dependencies",
    displayName: "Set Task blockers",
    description: "Replace the blocker set for the Task attached to the current run.",
    parametersSchema: runnerSemanticToolSchema("set_dependencies"),
    pluginId: "paperclip-self", providerType: "paperclip_self", risk: "write",
  },
  {
    name: "paperclip-self:create_project",
    displayName: "Create Project",
    description: "Create a governed Project using the current Native Project owner.",
    parametersSchema: runnerSemanticToolSchema("create_project"),
    pluginId: "paperclip-self", providerType: "paperclip_self", risk: "write",
  },
  {
    name: "paperclip-self:write_document",
    displayName: "Write Task document",
    description: "Create or update a revisioned document on the Task attached to the current run.",
    parametersSchema: runnerSemanticToolSchema("write_document"),
    pluginId: "paperclip-self", providerType: "paperclip_self", risk: "write",
  },
  {
    name: "paperclip-self:request_human_input",
    displayName: "Request Task input",
    description: "Create a structured question or decision interaction on the Task attached to the current run.",
    parametersSchema: runnerSemanticToolSchema("request_human_input"),
    pluginId: "paperclip-self", providerType: "paperclip_self", risk: "write",
  },
  {
    name: "paperclip-self:recall",
    displayName: "Recall Memory",
    description:
      "Recall only accepted, active Memory authorized for this agent, the current project, company scope, and explicitly named subjects.",
    parametersSchema: memoryAgentRecallInputJsonSchema,
    pluginId: "paperclip-self",
    providerType: "paperclip_self",
    risk: "read",
  },
  {
    name: "paperclip-self:remember",
    displayName: "Remember",
    description:
      "Create governed Memory from the current task. Private Memory stays owner-bound; shared Memory enters review and is not automatically accepted.",
    parametersSchema: memoryAgentRememberInputJsonSchema,
    pluginId: "paperclip-self",
    providerType: "paperclip_self",
    risk: "write",
  },
  {
    name: "paperclip-self:correct_memory",
    displayName: "Correct Memory",
    description:
      "Correct an accessible Memory record with task-backed evidence. Shared corrections enter review; owner-private corrections remain private.",
    parametersSchema: memoryAgentCorrectInputJsonSchema,
    pluginId: "paperclip-self",
    providerType: "paperclip_self",
    risk: "write",
  },
  {
    name: "paperclip-self:share_memory",
    displayName: "Share Memory",
    description:
      "Promote owner-private Memory into shared review without mutating the private source record.",
    parametersSchema: memoryAgentShareInputJsonSchema,
    pluginId: "paperclip-self",
    providerType: "paperclip_self",
    risk: "write",
  },
  {
    name: "paperclip-self:create_workflow",
    displayName: "Create workflow draft",
    description:
      "Create an idempotent draft workflow through the governed Workflow service. This never publishes the workflow.",
    parametersSchema: workflowAuthoringCreateInputJsonSchema,
    pluginId: "paperclip-self",
    providerType: "paperclip_self",
    risk: "write",
  },
  {
    name: "paperclip-self:propose_foundation_change",
    displayName: "Propose a Foundation change",
    description: "Save a proposed change against the exact approved Foundation revision for Human review. This cannot accept or approve the change or alter canonical Foundation content.",
    parametersSchema: foundationAuthoringProposeInputJsonSchema,
    pluginId: "paperclip-self", providerType: "paperclip_self", risk: "write",
  },
  {
    name: "paperclip-self:propose_notification_preferences",
    displayName: "Propose notification preferences",
    description: "Save a notification preference proposal for the current conversation user. The user must review and explicitly apply it. This cannot change another account, disable security delivery, or send notifications.",
    parametersSchema: notificationPreferenceProposalInputJsonSchema,
    pluginId: "paperclip-self", providerType: "paperclip_self", risk: "write",
  },
  {
    name: "paperclip-self:list_agent_setup_capabilities",
    displayName: "Find qualified Agent capabilities",
    description: "Read the current bounded customer catalog for this admitted conversation. Use its exact version IDs when proposing a package setup. Missing matches are not proof that the full catalog is empty. Catalog declarations are not effective permissions or installed access. No model call or installation occurs.",
    parametersSchema: agentSetupCatalogInputJsonSchema,
    pluginId: "paperclip-self", providerType: "paperclip_self", risk: "read",
  },
  {
    name: "paperclip-self:create_agent_setup_draft",
    displayName: "Propose Agent setup",
    description: "Save an unpublished Custom Agent setup or an exact customer catalog package setup for the current conversation user. Custom fields remain empty; package fields come only from the approved catalog version. The Human must configure and review it. This creates no Agent, installation, runtime, permission or execution, and accepts no copied conversation instructions.",
    parametersSchema: agentSetupAuthoringInputJsonSchema,
    pluginId: "paperclip-self", providerType: "paperclip_self", risk: "write",
  },
  {
    name: "paperclip-self:create_routine_draft",
    displayName: "Create routine draft",
    description: "Save a typed routine intent for human review in the current conversation. The draft is inactive and has no execution target or schedule. Open its Original editor to configure and enable it.",
    parametersSchema: routineAuthoringCreateInputJsonSchema,
    pluginId: "paperclip-self",
    providerType: "paperclip_self",
    risk: "write",
  },
  {
    name: "paperclip-self:add_trigger",
    displayName: "Add workflow trigger",
    description:
      "Add one typed trigger node to the current workflow draft using optimistic revision control.",
    parametersSchema: workflowAuthoringAddTriggerInputJsonSchema,
    pluginId: "paperclip-self",
    providerType: "paperclip_self",
    risk: "write",
  },
  {
    name: "paperclip-self:add_step",
    displayName: "Add workflow step",
    description:
      "Add one registered non-trigger node to a workflow draft using optimistic revision control.",
    parametersSchema: workflowAuthoringAddStepInputJsonSchema,
    pluginId: "paperclip-self",
    providerType: "paperclip_self",
    risk: "write",
  },
  {
    name: "paperclip-self:update_step",
    displayName: "Update workflow step",
    description:
      "Update one existing draft step through typed fields and the registered node validator.",
    parametersSchema: workflowAuthoringUpdateStepInputJsonSchema,
    pluginId: "paperclip-self",
    providerType: "paperclip_self",
    risk: "write",
  },
  {
    name: "paperclip-self:connect_steps",
    displayName: "Connect workflow steps",
    description:
      "Add one typed edge between existing draft nodes. Invalid graph references are rejected.",
    parametersSchema: workflowAuthoringConnectStepsInputJsonSchema,
    pluginId: "paperclip-self",
    providerType: "paperclip_self",
    risk: "write",
  },
  {
    name: "paperclip-self:remove_step",
    displayName: "Remove workflow step",
    description:
      "Remove one draft node and its incident edges through the governed Workflow service.",
    parametersSchema: workflowAuthoringRemoveStepInputJsonSchema,
    pluginId: "paperclip-self",
    providerType: "paperclip_self",
    risk: "write",
  },
  {
    name: "paperclip-self:test_step",
    displayName: "Validate workflow step",
    description:
      "Validate a draft step against its registered node contract and report its supported test mode. This does not execute side effects.",
    parametersSchema: workflowAuthoringTestStepInputJsonSchema,
    pluginId: "paperclip-self",
    providerType: "paperclip_self",
    risk: "read",
  },
  {
    name: "paperclip-self:publish_workflow",
    displayName: "Prepare workflow publish",
    description:
      "Validate the exact draft for publication and return the human publish request. The agent cannot publish or bypass approval through this tool.",
    parametersSchema: workflowAuthoringPublishInputJsonSchema,
    pluginId: "paperclip-self",
    providerType: "paperclip_self",
    risk: "read",
  },
  {
    name: "paperclip-self:get_issue_context",
    displayName: "Get issue context",
    description:
      "Paperclip self-MCP read fixture that returns scoped issue context and plan document metadata.",
    parametersSchema: {
      type: "object",
      properties: { issueId: { type: "string" } },
      additionalProperties: false,
    },
    pluginId: "paperclip-self",
    providerType: "paperclip_self",
    risk: "read",
  },
  {
    name: "paperclip-self:list_projects",
    displayName: "List readable Projects",
    description: "List current non-archived Projects readable by this Co-worker and its represented Human.",
    parametersSchema: {
      type: "object",
      properties: { limit: { type: "integer", minimum: 1, maximum: 50 } },
      additionalProperties: false,
    },
    pluginId: "paperclip-self",
    providerType: "paperclip_self",
    risk: "read",
  },
  {
    name: "paperclip-self:get_project_context",
    displayName: "Read a Project summary",
    description: "Read one current Project summary after current Project and retained Task-source access checks.",
    parametersSchema: {
      type: "object",
      properties: { projectId: { type: "string", format: "uuid" } },
      required: ["projectId"],
      additionalProperties: false,
    },
    pluginId: "paperclip-self",
    providerType: "paperclip_self",
    risk: "read",
  },
  {
    name: "paperclip-self:get_my_agent_context",
    displayName: "Read my Co-worker status",
    description: "Read a bounded identity and operating-status summary for the current verified Co-worker. No credentials, configuration, permissions, or other Co-workers are returned.",
    parametersSchema: { type: "object", properties: {}, additionalProperties: false },
    pluginId: "paperclip-self", providerType: "paperclip_self", risk: "read",
  },
  {
    name: "paperclip-self:get_my_current_work",
    displayName: "Read my current Task",
    description: "Read the Task bound to this current run after current Task and source authorization checks.",
    parametersSchema: { type: "object", properties: {}, additionalProperties: false },
    pluginId: "paperclip-self", providerType: "paperclip_self", risk: "read",
  },
  {
    name: "paperclip-self:search_decisions",
    displayName: "Search readable Decisions",
    description: "Search Decisions only when the current Co-worker and represented Human can read the origin and every referenced Task. Search does not decide or execute a Decision.",
    parametersSchema: {
      type: "object", properties: { query: { type: "string", minLength: 1, maxLength: 500 }, limit: { type: "integer", minimum: 1, maximum: 20 } },
      required: ["query"], additionalProperties: false,
    },
    pluginId: "paperclip-self", providerType: "paperclip_self", risk: "read",
  },
  {
    name: "paperclip-self:search_process_findings",
    displayName: "Search authorized Insights",
    description: "Search current process findings only through the retained native analytical reader boundary. Findings are evidence for Human interpretation, not calibrated probability or an operational decision.",
    parametersSchema: {
      type: "object", properties: { query: { type: "string", maxLength: 500 }, limit: { type: "integer", minimum: 1, maximum: 20 } },
      additionalProperties: false,
    },
    pluginId: "paperclip-self", providerType: "paperclip_self", risk: "read",
  },
  {
    name: "paperclip-self:create_support_request",
    displayName: "Create a Support request",
    description: "Create a local Support case for the current represented Human using a bounded description and optional schema-whitelisted safe context. External delivery is separate and is not implied.",
    parametersSchema: {
      type: "object",
      properties: {
        idempotencyKey: { type: "string", format: "uuid" },
        expectedPolicyRevision: { type: "string", pattern: "^[a-f0-9]{64}$" },
        description: { type: "string", minLength: 1, maxLength: 10000 },
        category: { type: "string", enum: ["not_working", "access", "apps_connections", "account_billing", "using_blentera", "other"] },
        subject: { type: "string", minLength: 1, maxLength: 200 },
        impact: { type: ["string", "null"], enum: ["blocked", "limited", "question", null] },
        safeContext: { type: "object", properties: {
          surface: { type: "string", enum: ["home", "needs_you", "work", "agents", "apps", "company", "account", "onboarding", "workflow", "support", "other"] },
          operationId: { type: "string", format: "uuid" }, occurredAt: { type: "string", format: "date-time" },
          errorCode: { type: "string", enum: ["NETWORK_UNAVAILABLE", "REQUEST_TIMEOUT", "ACCESS_CHANGED", "DEPENDENCY_UNAVAILABLE"] },
        }, additionalProperties: false },
      }, required: ["idempotencyKey", "expectedPolicyRevision", "description"], additionalProperties: false,
    },
    pluginId: "paperclip-self", providerType: "paperclip_self", risk: "write",
  },
  {
    name: "paperclip-self:get_support_intake_status",
    displayName: "Check Support intake",
    description: "Check whether configured Support case intake is currently available and read its approved disclosure terms. This does not report external service incidents.",
    parametersSchema: { type: "object", properties: {}, additionalProperties: false },
    pluginId: "paperclip-self", providerType: "paperclip_self", risk: "read",
  },
  {
    name: "paperclip-self:get_service_status",
    displayName: "Read current service status",
    description: "Read the bounded public Blentera Statuspage projection. This is separate from Support case intake availability and returns no customer case or credentials.",
    parametersSchema: { type: "object", properties: {}, additionalProperties: false },
    pluginId: "paperclip-self", providerType: "paperclip_self", risk: "read",
  },
  {
    name: "paperclip-self:list_authorized_apps",
    displayName: "Check authorized Apps",
    description: "List only active Apps and connections whose tools are currently discoverable under this session's profile and policy. Reports bounded health state, never credentials or connection configuration.",
    parametersSchema: { type: "object", properties: {}, additionalProperties: false },
    pluginId: "paperclip-self", providerType: "paperclip_self", risk: "read",
  },
  {
    name: "mcp-stdio-fixture:increment_counter",
    displayName: "Stdio runtime counter",
    description:
      "Local stdio MCP fixture that lazy-starts a supervised runtime slot and increments slot-local state.",
    parametersSchema: {
      type: "object",
      properties: {},
      additionalProperties: false,
    },
    pluginId: "mcp-stdio-fixture",
    providerType: "mcp_stdio_fixture",
    risk: "read",
  },
  {
    name: "mcp-stdio-fixture:runtime_status",
    displayName: "Stdio runtime status",
    description:
      "Local stdio MCP fixture that reports the reused runtime slot state.",
    parametersSchema: {
      type: "object",
      properties: {},
      additionalProperties: false,
    },
    pluginId: "mcp-stdio-fixture",
    providerType: "mcp_stdio_fixture",
    risk: "read",
  },
];

/** Canonical first-party Memory tool descriptor for managed Native catalogs. */
export function managedNativeRememberToolDescriptor(): ToolGatewayDescriptor {
  const tool = BUILTIN_TOOLS.find(candidate => candidate.name === "paperclip-self:remember");
  if (!tool) throw new Error("managed_native_memory_tool_unavailable");
  return { ...tool, parametersSchema: structuredClone(tool.parametersSchema) };
}

const VIRTUAL_SEARCH_TOOLS: ToolGatewayDescriptor = {
  name: "search_tools",
  displayName: "Search available tools",
  description:
    "Search the tools available through this Paperclip gateway without loading every target tool into the tool list.",
  parametersSchema: {
    type: "object",
    properties: {
      query: { type: "string" },
      limit: { type: "number" },
    },
    additionalProperties: false,
  },
  pluginId: "paperclip-gateway",
  providerType: "paperclip_virtual",
  risk: "read",
};

const VIRTUAL_RUN_TOOL: ToolGatewayDescriptor = {
  name: "run_tool",
  displayName: "Run a selected tool",
  description:
    "Run a target tool by name after Paperclip applies the target tool's profile, policy, approval, and rate-limit checks.",
  parametersSchema: {
    type: "object",
    properties: {
      tool: { type: "string" },
      arguments: { type: "object" },
    },
    required: ["tool"],
    additionalProperties: false,
  },
  pluginId: "paperclip-gateway",
  providerType: "paperclip_virtual",
  risk: "write",
};

const VIRTUAL_TOOLS = [VIRTUAL_SEARCH_TOOLS, VIRTUAL_RUN_TOOL];

function blenteraSelfToolContractCatalog() {
  const catalog = AGENT_NATIVE_OPERATION_MANIFEST.filter((operation) => operation.toolId !== null && operation.legacyAliases.length > 0).map((operation) => {
    const legacyName = operation.legacyAliases[0];
    const tool = BUILTIN_TOOLS.find((candidate) => candidate.name === legacyName && candidate.providerType === "paperclip_self");
    if (!tool) throw new Error("agent_native_operation_tool_binding_missing");
    return {
      toolId: operation.toolId,
      operationId: operation.operationId,
      legacyAliases: operation.legacyAliases,
      displayName: operation.customerJob.replace(/\.$/, ""),
      description: operation.customerJob,
      inputSchema: tool.parametersSchema,
      risk: tool.risk,
    };
  });
  const manifestAliases = catalog.flatMap((operation) => operation.legacyAliases).sort();
  const builtinSelfNames = BUILTIN_TOOLS
    .filter((tool) => tool.providerType === "paperclip_self")
    .map((tool) => tool.name)
    .sort();
  if (JSON.stringify(manifestAliases) !== JSON.stringify(builtinSelfNames)) {
    throw new Error("agent_native_operation_catalog_incomplete");
  }
  return catalog;
}

function assertBlenteraSelfToolCatalogComplete(): void {
  // A first-party tool added to Tool Gateway must acquire canonical coverage
  // metadata before it can be discovered or executed through the model path.
  blenteraSelfToolContractCatalog();
}

/** Stable contracts used by the reserved Blentera Platform Skill release. */
export function blenteraPlatformContractHashes(): BlenteraPlatformContractHashes {
  return {
    operationManifestHash: agentNativeOperationManifestHash(),
    toolCatalogContractHash: blenteraToolCatalogContractHash(blenteraSelfToolContractCatalog()),
  };
}

function blenteraFirstPartyToolForDiscovery(tool: ToolGatewayDescriptor): ToolGatewayDescriptor {
  const operation = agentNativeOperationForLegacyToolName(tool.name);
  if (!operation?.toolId) return tool;
  return {
    ...tool,
    name: operation.toolId,
    displayName: operation.customerJob.replace(/\.$/, ""),
    description: operation.customerJob,
  };
}

const MEMORY_SELF_TOOL_NAMES = new Set([
  "paperclip-self:recall",
  "paperclip-self:remember",
  "paperclip-self:correct_memory",
  "paperclip-self:share_memory",
]);

function isMemorySelfToolName(name: string): boolean {
  return MEMORY_SELF_TOOL_NAMES.has(name);
}

const WORKFLOW_AUTHORING_SELF_TOOL_NAMES = new Set([
  "paperclip-self:create_workflow",
  "paperclip-self:add_trigger",
  "paperclip-self:add_step",
  "paperclip-self:update_step",
  "paperclip-self:connect_steps",
  "paperclip-self:remove_step",
  "paperclip-self:test_step",
  "paperclip-self:publish_workflow",
]);

function isWorkflowAuthoringSelfToolName(name: string): boolean {
  return WORKFLOW_AUTHORING_SELF_TOOL_NAMES.has(name);
}

export function createToolGatewayService(
  db: Db,
  options: {
    operatorUserIds?: readonly string[];
    /** Server-owned application origin for the fixed inert qualification endpoint. */
    qualificationBrokerOrigin?: string;
    supportCaseDataPolicy?: ReturnType<typeof readSupportCaseDataPolicy>;
    serviceHealthReader?: ReturnType<typeof managedServiceHealthFromEnvironment>;
    pluginToolDispatcher?: PluginToolDispatcher;
    deploymentMode?: DeploymentMode;
    deploymentExposure?: DeploymentExposure;
    trustedLocalStdioRuntimeHost?: string | null;
    runtimeSupervisor?: ToolRuntimeSupervisorOptions;
    toolActionSigningSecret?: string;
    onToolActionSettled?: (actionRequestId: string) => Promise<unknown>;
    /** Test seam for deterministic remote MCP protocol fixtures. */
    remoteHttpRequest?: (url: string, init: RequestInit) => Promise<Response>;
    /** Test seam for refreshing personal Gmail grants. */
    paperclipCloudConnector?: PaperclipCloudConnector | null;
    /** @deprecated Use paperclipCloudConnector. */
    paperclipIdGmailConnector?: PaperclipCloudConnector | null;
    /** Refreshes customer-owned/DCR OAuth grants before remote MCP execution. */
    oauthGrantRefresher?: (input: {
      companyId: string;
      connectionId: string;
      grantId: string;
      forceRefresh?: boolean;
      actor?: {
        actorType?: "agent" | "user" | "system" | "plugin";
        actorId?: string | null;
      };
      issueId?: string | null;
      heartbeatRunId?: string | null;
    }) => Promise<typeof connectionGrants.$inferSelect>;
    /** Test seam for resolving Vercel Connect credentials. */
    vercelConnectClient?: VercelConnectClient | null;
    /** Test seam for reproducing the managed-argument drift expiry race. */
    beforeManagedArgumentDriftExpiry?: () => Promise<void>;
    /** Test seam for pausing a legacy approved request before its execution claim. */
    beforeLegacyApprovedActionClaim?: () => Promise<void>;
    mcpGatewayProtocolLimits?: Partial<{
      authFailures: Partial<McpGatewayRateLimitConfig>;
      gatewayRequests: Partial<McpGatewayRateLimitConfig>;
      tokenRequests: Partial<McpGatewayRateLimitConfig>;
      sessionSetup: Partial<McpGatewayRateLimitConfig>;
    }>;
    now?: () => number;
  } = {},
) {
  const supportCaseDataPolicy = options.supportCaseDataPolicy ?? readSupportCaseDataPolicy(process.env);
  const serviceHealthReader = options.serviceHealthReader ?? managedServiceHealthFromEnvironment(process.env);
  // Tool Gateway sessions persist only their token hash and execution IDs.
  // Retain the original verified Agent actor in process memory so Memory
  // writers can recheck its current credential, key revocation, run, and
  // responsible-user authority. A process restart intentionally loses this
  // carrier and makes Memory tools unavailable for those sessions.
  const memorySessionActors = new Map<string, { actor: AuthorizationActor; sessionExpiresAt: number }>();
  function rememberSessionActor(session: ToolGatewaySession, actor: AuthorizationActor | undefined) {
    const now = Date.now();
    for (const [id, value] of memorySessionActors) {
      if (value.sessionExpiresAt <= now) memorySessionActors.delete(id);
    }
    while (memorySessionActors.size >= 10_000) {
      const oldest = memorySessionActors.keys().next().value;
      if (!oldest) break;
      memorySessionActors.delete(oldest);
    }
    if (
      actor?.type !== "agent" || (actor.source !== "agent_jwt" && actor.source !== "agent_key") ||
      actor.companyId !== session.companyId || actor.agentId !== session.agentId ||
      (actor.runId ?? null) !== (session.runId ?? null) ||
      (actor.onBehalfOfUserId ?? null) !== (session.responsibleUserId ?? null) ||
      (actor.authenticatedCredentialExpiresAt != null &&
        (!Number.isFinite(actor.authenticatedCredentialExpiresAt) || actor.authenticatedCredentialExpiresAt <= now))
    ) return;
    const detached: AuthorizationActor = {
      ...actor,
      companyIds: actor.companyIds ? [...actor.companyIds] : undefined,
      memberships: actor.memberships?.map((membership) => ({ ...membership })),
      onBehalfOfMemberships: actor.onBehalfOfMemberships?.map((membership) => ({ ...membership })),
      keyScope: actor.keyScope ? structuredClone(actor.keyScope) : actor.keyScope,
      // One-request native effect proofs are consumed by middleware and must
      // never become reusable session authority.
      nativeToolEffect: undefined,
    };
    memorySessionActors.set(session.id, { actor: detached, sessionExpiresAt: session.expiresAt.getTime() });
  }
  function currentSessionMemoryActor(session: ToolGatewaySession): AuthorizationActor | undefined {
    const value = memorySessionActors.get(session.id);
    if (!value || value.sessionExpiresAt <= Date.now()) {
      memorySessionActors.delete(session.id);
      return undefined;
    }
    const actor = value.actor;
    if (actor.companyId !== session.companyId || actor.agentId !== session.agentId ||
      (actor.runId ?? null) !== (session.runId ?? null) ||
      (actor.onBehalfOfUserId ?? null) !== (session.responsibleUserId ?? null) ||
      (actor.authenticatedCredentialExpiresAt != null && actor.authenticatedCredentialExpiresAt <= Date.now())) {
      memorySessionActors.delete(session.id);
      return undefined;
    }
    return actor;
  }
  // Authorization links can contain one-time codes. Keep them briefly in memory;
  // persist only the redacted request and execution identifiers for recovery.
  const upstreamHandoffs = new Map<string, { pending: ToolUpstreamPending; expires: number }>();
  async function retainUpstreamHandoff(invocationId: string, pending: ToolUpstreamPending) {
    for (const [id, value] of upstreamHandoffs) if (value.expires <= Date.now()) upstreamHandoffs.delete(id);
    while (upstreamHandoffs.size >= 256) upstreamHandoffs.delete(upstreamHandoffs.keys().next().value!);
    upstreamHandoffs.set(invocationId, { pending, expires: Date.now() + 15 * 60_000 });
    const summary = validateToolContent({
      value: { upstreamPending: { ...pending, links: [] } }, direction: "result", sensitiveMode: "redact", promptInjectionMode: "ignore",
    }).summary;
    await db.update(toolInvocations).set({ resultSummary: summary }).where(eq(toolInvocations.id, invocationId));
  }
  function recoverUpstreamHandoff(invocation: typeof toolInvocations.$inferSelect): ToolUpstreamPending | undefined {
    if (invocation.errorCode !== "provider_interaction_required") return undefined;
    const cached = upstreamHandoffs.get(invocation.id);
    if (cached && cached.expires > Date.now()) return cached.pending;
    upstreamHandoffs.delete(invocation.id);
    const stored = asRecord(storedInvocationResult(invocation));
    const pending = asRecord(stored?.upstreamPending);
    if (!pending || !["approval", "authorization"].includes(String(pending.kind))) return undefined;
    return { ...pending, links: [] } as unknown as ToolUpstreamPending;
  }
  const runtimeSupervisor = createToolRuntimeSupervisor(db, {
    deploymentMode: options.deploymentMode,
    deploymentExposure: options.deploymentExposure,
    trustedLocalStdioRuntimeHost: options.trustedLocalStdioRuntimeHost,
    ...options.runtimeSupervisor,
  });
  const pluginToolDispatcher = options.pluginToolDispatcher;
  const interactions = issueThreadInteractionService(db);
  const policyService = toolAccessPolicyService(db);
  const secrets = secretService(db);
  // Authentication produces a new session object for every operation. Keep
  // credential acquisition scoped to that object and out of persisted inputs.
  const githubOperationCredentials = new WeakMap<
    ToolGatewaySession,
    {
      grant: typeof connectionGrants.$inferSelect;
      headers: Record<string, string>;
    }
  >();
  const configuredCloudConnector =
    options.paperclipCloudConnector ?? options.paperclipIdGmailConnector;
  const connectorWasProvided =
    options.paperclipCloudConnector !== undefined ||
    options.paperclipIdGmailConnector !== undefined;
  let cachedCloudConnector = configuredCloudConnector ?? null;
  const currentCloudConnector = (): PaperclipCloudConnector | null => {
    if (cachedCloudConnector || connectorWasProvided)
      return cachedCloudConnector;
    const config = paperclipCloudConnectorConfigFromEnv();
    cachedCloudConnector = config
      ? createPaperclipCloudConnector({ config, now: options.now })
      : null;
    return cachedCloudConnector;
  };
  const gmailRefreshFlights = new Map<
    string,
    Promise<typeof connectionGrants.$inferSelect>
  >();
  let sandboxBrokerAuthority: SandboxBrokerAuthority | null = null;
  let sandboxBrokerAuthorityOrigin: string | null = null;
  const vercelConnect =
    options.vercelConnectClient === undefined
      ? createVercelConnectClient()
      : options.vercelConnectClient;
  const protocolLimits = mcpGatewayProtocolLimits(
    options.mcpGatewayProtocolLimits,
  );
  let nextProtocolRateLimitPruneAt = 0;

  async function pruneExpiredProtocolRateLimitCounters(current: number) {
    if (current < nextProtocolRateLimitPruneAt) return;
    nextProtocolRateLimitPruneAt = current + 60_000;
    await db
      .delete(toolGatewayRateLimitCounters)
      .where(lte(toolGatewayRateLimitCounters.resetAt, new Date(current)));
  }

  async function consumeProtocolRateLimit(input: {
    companyId: string;
    counterKey: string;
    config: McpGatewayRateLimitConfig;
  }): Promise<McpGatewayRateLimitState> {
    const current = options.now?.() ?? Date.now();
    const windowStartAt = rateLimitWindowStart(current, input.config.windowMs);
    const resetAt = new Date(windowStartAt.getTime() + input.config.windowMs);
    const nowDate = new Date(current);
    const windowStartIso = windowStartAt.toISOString();
    const resetIso = resetAt.toISOString();
    const nowIso = nowDate.toISOString();
    await pruneExpiredProtocolRateLimitCounters(current);
    const rows = Array.from(
      await db.execute(sql<{ count: number | string }>`
      INSERT INTO "tool_gateway_rate_limit_counters" (
        "company_id",
        "counter_key",
        "window_start_at",
        "window_ms",
        "limit",
        "count",
        "reset_at",
        "created_at",
        "updated_at"
      )
      VALUES (
        ${input.companyId},
        ${input.counterKey},
        ${windowStartIso}::timestamptz,
        ${input.config.windowMs},
        ${input.config.max},
        1,
        ${resetIso}::timestamptz,
        ${nowIso}::timestamptz,
        ${nowIso}::timestamptz
      )
      ON CONFLICT ("company_id", "counter_key", "window_start_at")
      DO UPDATE SET
        "count" = "tool_gateway_rate_limit_counters"."count" + 1,
        "window_ms" = ${input.config.windowMs},
        "limit" = ${input.config.max},
        "reset_at" = ${resetIso}::timestamptz,
        "updated_at" = ${nowIso}::timestamptz
      RETURNING "count"
    `),
    );
    const count = Number(rows[0]?.count ?? 1);
    return {
      limited: count > input.config.max,
      count,
      retryAfterMs: Math.max(0, resetAt.getTime() - current),
    };
  }

  function pluginTools(): ToolGatewayDescriptor[] {
    return (pluginToolDispatcher?.listToolsForAgent() ?? [])
      // First-party operation IDs and their historical selectors are reserved.
      // A plugin with the same name must not create an ambiguous catalog entry
      // or shadow the operation's policy selector.
      .filter((tool) => !agentNativeOperationForToolName(tool.name))
      .map((tool) => ({
      ...tool,
      providerType: "paperclip_plugin" as const,
      risk: inferToolRisk(tool.name),
      }));
  }

  function allTools(): ToolGatewayDescriptor[] {
    return [...BUILTIN_TOOLS, ...pluginTools()];
  }

  async function selfToolFeatureFlags() {
    const experimental = await instanceSettingsService(db).getExperimental();
    return {
      sharedMemory: experimental.enableCollectiveMemoryV1 === true,
      privateMemory: experimental.enablePrivateAgentMemoryV1 === true,
      notificationAuthoring: v9FeatureEnabled(experimental,"ambient_commands_v9") && v9FeatureEnabled(experimental,"notification_policy_v9"),
      routineAuthoring: v9FeatureEnabled(experimental, "ambient_commands_v9"),
      agentSetupAuthoring: v9FeatureEnabled(experimental, "ambient_commands_v9") && v9FeatureEnabled(experimental, "hire_agent_v9"),
      supportRequests: supportCaseDataPolicy !== null,
      foundationAuthoring: experimental.enableFoundationV1 === true && v9FeatureEnabled(experimental, "ambient_commands_v9"),
      workflowAuthoring:
        experimental.enableWorkflowsV1 === true &&
        experimental.enableWorkflowBuilderV1 === true &&
        experimental.enableAiWorkflowAuthoring === true,
    };
  }

  async function assertExternalMcpModelEffects(session: ToolGatewaySession): Promise<void> {
    // A company-purpose/manual call is still a platform-initiated invocation.
    await assertToolInternalInferenceAdmitted(session);
  }

  function serverOwnedNonModelRemoteTool(connection: typeof toolConnections.$inferSelect, toolName: string): boolean {
    // This exact branch executes our strict schemas/fixed GraphQL documents at
    // RAILWAY_API_URL, not arbitrary MCP implementation or caller URL/body.
    return isRailwayConnection(connection) && connection.config.railwayApiStatus === "available" &&
      RAILWAY_TOOLS.some(tool => tool.name === toolName) &&
      toolName !== `${RAILWAY_TOOL_PREFIX}run-command` && !isRailwayToolBlocked(toolName);
  }

  async function assertConnectedToolModelEffects(session: ToolGatewaySession, tool: ToolGatewayDescriptor): Promise<void> {
    if (tool.providerType === "mcp_remote_http") {
      const { entry, connection } = await resolveConnectedRemoteTool(session, tool);
      if (!serverOwnedNonModelRemoteTool(connection, entry.toolName)) await assertExternalMcpModelEffects(session);
    } else if (tool.providerType === "mcp_local_stdio") {
      const { entry, connection } = await resolveConnectedLocalStdioTool(session, tool);
      const template = await resolveLocalStdioRuntimeTemplate(connection);
      if (!(template.templateId === "paperclip.cognee-cloud" && entry.toolName === "forget"))
        await assertExternalMcpModelEffects(session);
    }
  }

  async function assertToolInternalInferenceAdmitted(session: ToolGatewaySession): Promise<void> {
    // Opaque plugin workers and model-backed memory operations have no forced
    // nested reservation/whole-invocation liability contract in this profile.
    const error = new ToolModelEffectAdmissionError("tool_internal_inference", {
      companyId: session.companyId, agentId: session.agentId,
    });
    throw new ToolGatewayHttpError(409, error.message, "tool_model_effect_unqualified", {
      code: "configuration_incomplete", ...error.resultJson,
    });
  }

  async function eligibleStaticToolsForSession(
    session: ToolGatewaySession,
  ): Promise<ToolGatewayDescriptor[]> {
    assertBlenteraSelfToolCatalogComplete();
    const tools = allTools().filter(tool => tool.providerType !== "paperclip_plugin");
    if (!session.agentId) {
      return tools.filter((tool) => tool.providerType !== "paperclip_self");
    }
    const flags = await selfToolFeatureFlags();
    return tools.filter((tool) => {
      if (tool.name === "paperclip-self:propose_notification_preferences") return flags.notificationAuthoring;
      if (tool.name === "paperclip-self:create_routine_draft") return flags.routineAuthoring;
      if (tool.name === "paperclip-self:create_agent_setup_draft") return flags.agentSetupAuthoring;
      if (tool.name === "paperclip-self:list_agent_setup_capabilities") return flags.agentSetupAuthoring;
      if (tool.name === "paperclip-self:create_support_request") return flags.supportRequests;
      if (tool.name === "paperclip-self:propose_foundation_change") return flags.foundationAuthoring;
      if (isMemorySelfToolName(tool.name)) {
        if (tool.name === "paperclip-self:share_memory") {
          return flags.sharedMemory && flags.privateMemory;
        }
        return flags.sharedMemory || flags.privateMemory;
      }
      if (isWorkflowAuthoringSelfToolName(tool.name)) {
        return flags.workflowAuthoring;
      }
      return true;
    });
  }

  async function staticToolsForSession(
    session: ToolGatewaySession,
  ): Promise<ToolGatewayDescriptor[]> {
    return (await eligibleStaticToolsForSession(session)).map(blenteraFirstPartyToolForDiscovery);
  }

  async function connectedMcpToolsForCompany(
    companyId: string,
  ): Promise<ToolGatewayDescriptor[]> {
    const rows = await db
      .select({
        catalogEntry: toolCatalogEntries,
        connection: toolConnections,
        application: toolApplications,
      })
      .from(toolCatalogEntries)
      .innerJoin(
        toolConnections,
        eq(toolCatalogEntries.connectionId, toolConnections.id),
      )
      .innerJoin(
        toolApplications,
        eq(toolConnections.applicationId, toolApplications.id),
      )
      .where(
        and(
          eq(toolCatalogEntries.companyId, companyId),
          eq(toolCatalogEntries.entryKind, "tool"),
          eq(toolCatalogEntries.status, "active"),
          isNull(toolCatalogEntries.quarantinedAt),
          eq(toolConnections.companyId, companyId),
          inArray(toolConnections.transport, ["mcp_remote", "local_stdio"]),
          eq(toolConnections.status, "active"),
          eq(toolConnections.enabled, true),
          // A personal connection has no company-level credential to probe. A
          // credential-less health sweep can therefore mark it as errored even
          // while the responsible user's grant is valid. Keep its cached active
          // catalog discoverable; execution resolves and validates that user's
          // grant, and a successful call restores the shared health indicator.
          or(
            inArray(toolConnections.healthStatus, ["ok", "healthy"]),
            eq(toolConnections.credentialPolicy, "per_user"),
          ),
          eq(toolApplications.companyId, companyId),
          inArray(toolApplications.type, ["mcp_http", "mcp_stdio"]),
          eq(toolApplications.status, "active"),
        ),
      )
      .orderBy(toolConnections.name, toolCatalogEntries.name);

    const eligibleRows = rows.filter(
      ({ catalogEntry, connection, application }) =>
        !isRetiredComposioConnection(connection) &&
        !(isRailwayEndpoint(connection.config.url) && (isRailwayToolBlocked(catalogEntry.toolName) || (normalizeRailwayToolName(catalogEntry.toolName).startsWith(RAILWAY_TOOL_PREFIX) && connection.config.railwayApiStatus !== "available"))) &&
        ((connection.transport === "mcp_remote" &&
          application.type === "mcp_http") ||
        (connection.transport === "local_stdio" &&
          application.type === "mcp_stdio")),
    );
    const baseNames = eligibleRows.map(
      ({ catalogEntry, connection, application }) => {
        const applicationKey = application.applicationKey ?? null;
        const connectionNamespace = `${slugSegment(applicationKey ?? connection.name ?? application.name, "mcp")}-${shortStableId(connection.id)}`;
        const toolSlug = slugSegment(catalogEntry.toolName, "tool");
        return `mcp.${connectionNamespace}:${toolSlug}`;
      },
    );
    const baseNameCounts = baseNames.reduce<Map<string, number>>(
      (counts, name) => {
        counts.set(name, (counts.get(name) ?? 0) + 1);
        return counts;
      },
      new Map(),
    );

    return eligibleRows.map(
      ({ catalogEntry, connection, application }, index) => {
        if (
          connection.transport !== "mcp_remote" &&
          connection.transport !== "local_stdio"
        ) {
          throw new Error(
            `Non-MCP connection ${connection.id} cannot be exposed through the MCP gateway`,
          );
        }
        const baseName = baseNames[index]!;
        const gatewayToolName =
          baseNameCounts.get(baseName)! > 1
            ? `${baseName}-${shortStableId(catalogEntry.id)}`
            : baseName;
        const applicationKey = application.applicationKey ?? null;
        const inputSchema = projectedConnectionToolInputSchema(
          connection,
          catalogEntry.inputSchema ?? {},
          catalogEntry.toolName,
        );
        const outputSchema = catalogEntry.outputSchema ?? null;
        const annotations = catalogEntry.annotations ?? {};
        const risk = riskFromCatalogEntry(catalogEntry);
        const onDemandTools = readOnDemandToolsEnabled(connection);
        const providerMetadata: ConnectedMcpGatewayMetadata = {
          applicationId: application.id,
          applicationKey,
          applicationDisplayName: application.name,
          connectionId: connection.id,
          catalogEntryId: catalogEntry.id,
          transport: connection.transport,
          gatewayToolName,
          upstreamToolName: catalogEntry.toolName,
          catalogName: catalogEntry.name,
          inputSchema,
          outputSchema,
          annotations,
          risk: {
            level: catalogEntry.riskLevel,
            isReadOnly: catalogEntry.isReadOnly,
            isWrite: catalogEntry.isWrite,
            isDestructive: catalogEntry.isDestructive,
          },
          onDemandTools,
        };
        return {
          name: gatewayToolName,
          displayName: catalogEntry.title ?? catalogEntry.toolName,
          description:
            googleChatToolDescription(connection, catalogEntry.toolName, catalogEntry.description) ??
            `Connected MCP tool ${catalogEntry.toolName} from ${connection.name}.`,
          parametersSchema: inputSchema,
          pluginId: `mcp:${applicationKey ?? application.id}`,
          providerType:
            connection.transport === "local_stdio"
              ? "mcp_local_stdio"
              : "mcp_remote_http",
          risk,
          applicationId: application.id,
          applicationKey,
          applicationDisplayName: application.name,
          connectionId: connection.id,
          catalogEntryId: catalogEntry.id,
          upstreamToolName: catalogEntry.toolName,
          providerMetadata,
        };
      },
    );
  }

  async function connectedMcpToolsForConnection(
    companyId: string,
    connectionId: string,
  ): Promise<ToolGatewayDescriptor[]> {
    return (await connectedMcpToolsForCompany(companyId)).filter(
      (tool) => tool.connectionId === connectionId,
    );
  }

  async function assertAgentInCompany(
    companyId: string,
    agentId: string,
  ): Promise<void> {
    const [agent] = await db
      .select({
        companyId: agents.companyId,
      })
      .from(agents)
      .where(eq(agents.id, agentId))
      .limit(1);

    if (!agent || agent.companyId !== companyId) {
      throw new ToolGatewayHttpError(
        404,
        "Agent not found for company",
        "agent_not_found",
      );
    }
  }

  /**
   * "Last changed by {Actor} · {relativeTime}" audit hint for the Test tab Off
   * side panel. Looks across the configuration that governs this agent's access
   * to the connection — the policies that matched, the profiles in effect, the
   * entries that scope them to this connection, and the bindings that assigned
   * those profiles to the agent — and reports the most recent edit. Only
   * policies and bindings carry an actor, so the attributed agent name is best
   * effort: when the latest edit was a profile/entry toggle (no actor column),
   * the timestamp is still returned but the actor is null.
   */
  async function summarizeAccessLastChange(input: {
    companyId: string;
    connectionId: string;
    agentId: string;
    policyIds: string[];
    profileIds: string[];
  }): Promise<{
    lastChangedAt: string | null;
    lastChangedByAgentId: string | null;
    lastChangedByName: string | null;
  }> {
    const empty = {
      lastChangedAt: null,
      lastChangedByAgentId: null,
      lastChangedByName: null,
    };
    const candidates: Array<{ updatedAt: Date; agentId: string | null }> = [];

    if (input.policyIds.length > 0) {
      const policies = await db
        .select({
          updatedAt: toolPolicies.updatedAt,
          agentId: toolPolicies.createdByAgentId,
        })
        .from(toolPolicies)
        .where(
          and(
            eq(toolPolicies.companyId, input.companyId),
            inArray(toolPolicies.id, input.policyIds),
          ),
        );
      candidates.push(
        ...policies.map((row) => ({
          updatedAt: row.updatedAt,
          agentId: row.agentId,
        })),
      );
    }

    if (input.profileIds.length > 0) {
      const [profiles, entries, bindings] = await Promise.all([
        db
          .select({ updatedAt: toolProfiles.updatedAt })
          .from(toolProfiles)
          .where(
            and(
              eq(toolProfiles.companyId, input.companyId),
              inArray(toolProfiles.id, input.profileIds),
            ),
          ),
        db
          .select({ updatedAt: toolProfileEntries.updatedAt })
          .from(toolProfileEntries)
          .where(
            and(
              eq(toolProfileEntries.companyId, input.companyId),
              inArray(toolProfileEntries.profileId, input.profileIds),
              eq(toolProfileEntries.connectionId, input.connectionId),
            ),
          ),
        db
          .select({
            updatedAt: toolProfileBindings.updatedAt,
            agentId: toolProfileBindings.createdByAgentId,
          })
          .from(toolProfileBindings)
          .where(
            and(
              eq(toolProfileBindings.companyId, input.companyId),
              inArray(toolProfileBindings.profileId, input.profileIds),
              eq(toolProfileBindings.targetType, "agent"),
              eq(toolProfileBindings.targetId, input.agentId),
            ),
          ),
      ]);
      candidates.push(
        ...profiles.map((row) => ({ updatedAt: row.updatedAt, agentId: null })),
      );
      candidates.push(
        ...entries.map((row) => ({ updatedAt: row.updatedAt, agentId: null })),
      );
      candidates.push(
        ...bindings.map((row) => ({
          updatedAt: row.updatedAt,
          agentId: row.agentId,
        })),
      );
    }

    if (candidates.length === 0) return empty;
    const latest = candidates.reduce((a, b) =>
      b.updatedAt.getTime() > a.updatedAt.getTime() ? b : a,
    );

    let lastChangedByName: string | null = null;
    if (latest.agentId) {
      const [actor] = await db
        .select({ name: agents.name })
        .from(agents)
        .where(eq(agents.id, latest.agentId))
        .limit(1);
      lastChangedByName = actor?.name ?? null;
    }
    return {
      lastChangedAt: latest.updatedAt.toISOString(),
      lastChangedByAgentId: latest.agentId,
      lastChangedByName,
    };
  }

  async function resolveRunContext(input: {
    companyId: string;
    agentId: string;
    runId: string;
    issueId?: string | null;
    projectId?: string | null;
  }): Promise<{ issueId: string | null; projectId: string | null }> {
    const [run] = await db
      .select({
        companyId: heartbeatRuns.companyId,
        agentId: heartbeatRuns.agentId,
        status: heartbeatRuns.status,
        resultJson: heartbeatRuns.resultJson,
        contextSnapshot: heartbeatRuns.contextSnapshot,
      })
      .from(heartbeatRuns)
      .where(eq(heartbeatRuns.id, input.runId))
      .limit(1);

    if (!run || run.companyId !== input.companyId) {
      throw new ToolGatewayHttpError(
        403,
        "Run does not belong to company",
        "run_company_mismatch",
      );
    }
    if (run.agentId !== input.agentId) {
      throw new ToolGatewayHttpError(
        403,
        "Run does not belong to agent",
        "run_agent_mismatch",
      );
    }
    if (!ACTIVE_GATEWAY_RUN_STATUSES.has(run.status) || agentRunWritesRevoked(run)) {
      throw new ToolGatewayHttpError(403, "Run is not active", "run_inactive");
    }
    await assertPackageExecution(db, input.companyId, input.agentId, input.runId);
    await assertExecutionGovernance(db, input.companyId, input.agentId, input.runId);
    await assertManagedRuntimeCommercialAuthority(db, input.companyId, input.agentId);

    const snapshot = asRecord(run.contextSnapshot);
    const snapshotIssueId = stringValue(snapshot?.issueId);
    const snapshotProjectId = stringValue(snapshot?.projectId);
    if (
      (input.issueId && snapshotIssueId && input.issueId !== snapshotIssueId) ||
      (input.projectId &&
        snapshotProjectId &&
        input.projectId !== snapshotProjectId)
    ) {
      throw new ToolGatewayHttpError(
        403,
        "Supplied run context does not match stored heartbeat context",
        "run_context_mismatch",
      );
    }
    const issueId = snapshotIssueId ?? input.issueId ?? null;
    let projectId = snapshotProjectId ?? input.projectId ?? null;
    if (issueId) {
      const [issue] = await db
        .select({ companyId: issues.companyId, projectId: issues.projectId })
        .from(issues)
        .where(eq(issues.id, issueId))
        .limit(1);
      if (!issue || issue.companyId !== input.companyId) {
        throw new ToolGatewayHttpError(
          403,
          "Issue context is outside the run company",
          "run_context_mismatch",
        );
      }
      if (projectId && issue.projectId && projectId !== issue.projectId) {
        throw new ToolGatewayHttpError(
          403,
          "Project context does not match issue context",
          "run_context_mismatch",
        );
      }
      projectId = projectId ?? issue.projectId;
    }
    if (projectId) {
      const [project] = await db
        .select({ companyId: projects.companyId })
        .from(projects)
        .where(eq(projects.id, projectId))
        .limit(1);
      if (!project || project.companyId !== input.companyId) {
        throw new ToolGatewayHttpError(
          403,
          "Project context is outside the run company",
          "run_context_mismatch",
        );
      }
    }
    return {
      issueId,
      projectId,
    };
  }

  async function writeAudit(input: {
    session?: ToolGatewaySession | null;
    companyId: string;
    agentId: string | null;
    runId: string | null;
    issueId: string | null;
    actorType?: LogActivityInput["actorType"];
    actorId?: string;
    action: string;
    details: Record<string, unknown>;
  }) {
    const dedicatedAuditAction =
      input.action === "tool_gateway.discovery"
        ? "discovery"
        : input.action === "tool_gateway.session_revoked"
          ? "session_revoked"
          : input.action === "tool_gateway.call_allowed" ||
              input.action === "tool_gateway.session_created"
            ? "policy_decision"
            : input.action === "tool_gateway.call_completed"
              ? "call_completed"
              : input.action === "tool_gateway.call_denied" ||
                  input.action === "tool_gateway.session_rejected"
                ? "call_denied"
                : input.action === "tool_gateway.call_deferred"
                  ? "call_failed"
                  : "call_failed";
    const dedicatedOutcome =
      input.action === "tool_gateway.session_revoked"
        ? "success"
        : input.action === "tool_gateway.call_denied" ||
            input.action === "tool_gateway.session_rejected"
          ? "denied"
          : input.action === "tool_gateway.call_deferred"
            ? "timeout"
            : input.action === "tool_gateway.call_failed"
              ? "failure"
              : "success";
    try {
      await db.insert(toolAccessAuditEvents).values({
        companyId: input.companyId,
        gatewayId:
          input.session?.gatewayId ??
          (typeof input.details.gatewayId === "string" &&
          uuidPattern.test(input.details.gatewayId)
            ? input.details.gatewayId
            : null),
        gatewayTokenId:
          input.session?.gatewayTokenId &&
          uuidPattern.test(input.session.gatewayTokenId)
            ? input.session.gatewayTokenId
            : typeof input.details.gatewayTokenId === "string" &&
                uuidPattern.test(input.details.gatewayTokenId)
              ? input.details.gatewayTokenId
              : null,
        gatewayPublicId:
          typeof input.details.gatewayPublicId === "string"
            ? input.details.gatewayPublicId
            : null,
        clientName:
          typeof input.details.clientName === "string"
            ? input.details.clientName
            : null,
        correlationId:
          typeof input.details.correlationId === "string"
            ? input.details.correlationId
            : null,
        connectionId:
          typeof input.details.connectionId === "string"
            ? input.details.connectionId
            : null,
        catalogEntryId:
          typeof input.details.catalogEntryId === "string"
            ? input.details.catalogEntryId
            : null,
        actorType:
          input.actorType ??
          input.session?.actorType ??
          (input.agentId ? "agent" : "system"),
        actorId:
          input.actorId ??
          input.session?.actorId ??
          input.agentId ??
          input.session?.gatewayTokenId ??
          input.companyId,
        action: dedicatedAuditAction,
        outcome: dedicatedOutcome,
        reasonCode:
          typeof input.details.reasonCode === "string"
            ? input.details.reasonCode
            : null,
        details: {
          source: input.action,
          agentId: input.agentId,
          issueId: input.issueId,
          projectId: input.session?.projectId ?? null,
          runId: input.runId,
          workflowRunId: input.session?.workflowRunId ?? null,
          gatewaySessionId: input.session?.id ?? null,
          identityContextId: input.session?.identityContextId ?? null,
          gatewayId: input.session?.gatewayId ?? null,
          gatewayPublicId: input.session?.gatewayPublicId ?? null,
          gatewayName: input.session?.gatewayName ?? null,
          gatewayTokenId: input.session?.gatewayTokenId ?? null,
          ...input.details,
        },
      });
    } catch (error) {
      await recordToolRuntimeAuditWriteFailure(db, input.companyId);
      throw error;
    }

    const entityType = input.issueId
      ? "issue"
      : input.session?.gatewayId
        ? "tool_mcp_gateway"
        : "agent";
    const entityId =
      input.issueId ??
      input.session?.gatewayId ??
      input.agentId ??
      input.companyId;
    await logActivity(db, {
      companyId: input.companyId,
      actorType:
        input.actorType ??
        input.session?.actorType ??
        (input.agentId ? "agent" : "system"),
      actorId:
        input.actorId ??
        input.session?.actorId ??
        input.agentId ??
        input.session?.gatewayTokenId ??
        input.companyId,
      action: input.action,
      entityType,
      entityId,
      agentId: input.agentId,
      runId: input.runId,
      issueId: input.issueId,
      details: {
        gatewaySessionId: input.session?.id ?? null,
        gatewayId: input.session?.gatewayId ?? null,
        gatewayPublicId: input.session?.gatewayPublicId ?? null,
        issueId: input.issueId,
        projectId: input.session?.projectId ?? null,
        runId: input.runId,
        ...input.details,
      },
    });
  }

  async function writeSessionAuthFailure(
    row: typeof toolGatewaySessions.$inferSelect,
    reasonCode: string,
    details: Record<string, unknown> = {},
  ) {
    const session = gatewaySessionFromRow(row);
    await writeAudit({
      session,
      companyId: session.companyId,
      agentId: session.agentId,
      runId: session.runId,
      issueId: session.issueId,
      action: "tool_gateway.session_rejected",
      details: {
        decision: "deny",
        reasonCode,
        expiresAt: session.expiresAt.toISOString(),
        revokedAt: row.revokedAt?.toISOString() ?? null,
        ...details,
      },
    });
  }

  async function assertSessionRunIsActive(
    row: typeof toolGatewaySessions.$inferSelect,
  ) {
    const [run] = await db
      .select({
        companyId: heartbeatRuns.companyId,
        agentId: heartbeatRuns.agentId,
        status: heartbeatRuns.status,
        resultJson: heartbeatRuns.resultJson,
      })
      .from(heartbeatRuns)
      .where(eq(heartbeatRuns.id, row.runId))
      .limit(1);

    if (
      !run ||
      run.companyId !== row.companyId ||
      run.agentId !== row.agentId ||
      !ACTIVE_GATEWAY_RUN_STATUSES.has(run.status)
      || agentRunWritesRevoked(run)
    ) {
      await writeSessionAuthFailure(row, "session_run_inactive", {
        runStatus: run?.status ?? null,
      });
      throw new ToolGatewayHttpError(
        401,
        "Tool gateway session is expired or invalid",
        "session_run_inactive",
      );
    }
    await assertPackageExecution(db, row.companyId, row.agentId, row.runId);
    await assertExecutionGovernance(db, row.companyId, row.agentId, row.runId);
    await assertManagedRuntimeCommercialAuthority(db, row.companyId, row.agentId);
  }

  async function getActiveSession(
    sessionToken: string,
    namedGatewayProtocol?: {
      gatewayId?: string | null;
      gatewayPublicId?: string | null;
      protocolMethod: McpGatewayProtocolMethod;
      callerHeaders?: Record<string, string | string[] | undefined>;
    },
  ): Promise<ToolGatewaySession> {
    const token = sessionToken.trim();
    if (!token) {
      throw new ToolGatewayHttpError(
        401,
        "Tool gateway session is expired or invalid",
        "session_invalid",
      );
    }
    if (namedGatewayTokenId(token)) {
      return namedGatewaySessionFromBearer({
        gatewayId: namedGatewayProtocol?.gatewayId ?? null,
        gatewayPublicId: namedGatewayProtocol?.gatewayPublicId ?? null,
        bearerToken: token,
        protocolMethod: namedGatewayProtocol?.protocolMethod ?? "tools/call",
        callerHeaders: namedGatewayProtocol?.callerHeaders,
      });
    }

    const tokenHash = hashGatewayToken(token);
    const [row] = await db
      .select()
      .from(toolGatewaySessions)
      .where(eq(toolGatewaySessions.tokenHash, tokenHash))
      .limit(1);

    if (!row) {
      const sessionId = sessionIdFromGatewayToken(token);
      if (sessionId) {
        const [candidate] = await db
          .select()
          .from(toolGatewaySessions)
          .where(eq(toolGatewaySessions.id, sessionId))
          .limit(1);
        if (candidate) {
          await writeSessionAuthFailure(candidate, "session_invalid");
        }
      }
      throw new ToolGatewayHttpError(
        401,
        "Tool gateway session is expired or invalid",
        "session_invalid",
      );
    }

    if (row.revokedAt) {
      await writeSessionAuthFailure(row, "session_revoked");
      throw new ToolGatewayHttpError(
        401,
        "Tool gateway session is expired or invalid",
        "session_revoked",
      );
    }

    if (row.expiresAt.getTime() <= Date.now()) {
      await writeSessionAuthFailure(row, "session_expired");
      throw new ToolGatewayHttpError(
        401,
        "Tool gateway session is expired or invalid",
        "session_expired",
      );
    }

    await assertSessionRunIsActive(row);

    const now = new Date();
    await db
      .update(toolGatewaySessions)
      .set({ lastUsedAt: now, updatedAt: now })
      .where(eq(toolGatewaySessions.id, row.id));

    const session = gatewaySessionFromRow({
      ...row,
      lastUsedAt: now,
      updatedAt: now,
    });
    const memoryActor = memorySessionActors.get(session.id)?.actor;
    return captureSessionIdentity(memoryActor?.type === "agent"
      ? { ...session, responsibleUserId: memoryActor.onBehalfOfUserId ?? null }
      : session);
  }

  async function captureSessionIdentity(
    session: ToolGatewaySession,
  ): Promise<ToolGatewaySession> {
    // Authentication creates a fresh operation snapshot on every invocation.
    // Never trust a previously attached context on a reusable transport session.
    // Approved operations restore their signed origin after authentication.
    if (!session.runId || !session.agentId) return session;
    const [run] = await db
      .select({
        activeIdentityContextId: heartbeatRuns.activeIdentityContextId,
      })
      .from(heartbeatRuns)
      .where(
        and(
          eq(heartbeatRuns.id, session.runId),
          eq(heartbeatRuns.companyId, session.companyId),
        ),
      );
    if (!run?.activeIdentityContextId) return session;
    const captured = await captureRunIdentity(db, {
      companyId: session.companyId,
      agentId: session.agentId,
      runId: session.runId,
    });
    return {
      ...session,
      identityContextId: captured.context?.id,
      responsibleUserId:
        captured.context?.cause === "company_default"
          ? null
          : captured.context?.responsibleUserId,
    };
  }

  function normalizeGatewayTokenActions(
    value: unknown,
  ): ToolMcpGatewayTokenAction[] {
    const known = new Set<ToolMcpGatewayTokenAction>([
      "tools/list",
      "tools/call",
      "resources/list",
      "resources/read",
      "prompts/list",
      "prompts/get",
    ]);
    const actions = Array.isArray(value)
      ? value.filter((action): action is ToolMcpGatewayTokenAction =>
          known.has(action as ToolMcpGatewayTokenAction),
        )
      : [];
    return actions.length > 0 ? actions : [...known];
  }

  async function assertGatewayTokenAction(
    session: ToolGatewaySession,
    action: ToolMcpGatewayTokenAction,
  ) {
    const allowedActions = session.gatewayTokenAllowedActions;
    if (!allowedActions || allowedActions.includes(action)) return;
    await writeAudit({
      session,
      companyId: session.companyId,
      agentId: session.agentId,
      runId: session.runId,
      issueId: session.issueId,
      action: action.endsWith("/list")
        ? "tool_gateway.discovery"
        : "tool_gateway.call_denied",
      details: {
        decision: "deny",
        reasonCode: "gateway_token_action_denied",
        requestedAction: action,
        allowedActions,
      },
    });
    throw new ToolGatewayHttpError(
      403,
      "Gateway bearer token is not allowed to perform this MCP action",
      "gateway_token_action_denied",
      {
        requestedAction: action,
      },
    );
  }

  async function writeToolCallEvent(input: {
    invocationId?: string | null;
    actionRequestId?: string | null;
    session: ToolGatewaySession;
    eventType:
      | "policy_decision"
      | "invocation_created"
      | "approval_requested"
      | "approval_resolved"
      | "call_started"
      | "call_completed"
      | "call_failed"
      | "call_denied";
    outcome:
      "pending" | "success" | "failure" | "denied" | "timeout" | "cancelled";
    toolName: string;
    policyDecision?:
      "allow" | "deny" | "require_approval" | "defer_runtime" | null;
    reasonCode?: string | null;
    argumentsSummary?: ReturnType<typeof summarizeToolValue> | null;
    resultSummary?: ReturnType<typeof summarizeToolValue> | null;
    metadata?: Record<string, unknown> | null;
    tool?: ToolGatewayDescriptor | null;
  }) {
    const metadata = input.tool ? toolAuditMetadata(input.tool) : {};
    await db.insert(toolCallEvents).values({
      companyId: input.session.companyId,
      invocationId: input.invocationId ?? null,
      actionRequestId: input.actionRequestId ?? null,
      eventType: input.eventType,
      outcome: input.outcome,
      actorType:
        input.session.actorType ?? (input.session.agentId ? "agent" : "system"),
      actorId:
        input.session.actorId ??
        input.session.agentId ??
        input.session.gatewayTokenId ??
        input.session.companyId,
      agentId: input.session.agentId,
      issueId: input.session.issueId,
      runId: input.session.runId,
      applicationId: input.tool?.applicationId ?? null,
      connectionId: input.tool?.connectionId ?? null,
      catalogEntryId: input.tool?.catalogEntryId ?? null,
      toolName: input.toolName,
      decision: input.policyDecision ?? null,
      reasonCode: input.reasonCode ?? null,
      matchedPolicyIds: [],
      requestHash: input.argumentsSummary?.sha256 ?? null,
      requestSummary: input.argumentsSummary ?? null,
      resultHash: input.resultSummary?.sha256 ?? null,
      resultSummary: input.resultSummary ?? null,
      resultSizeBytes: input.resultSummary?.sizeBytes ?? null,
      metadata:
        Object.keys(metadata).length > 0 ||
        input.metadata ||
        input.session.projectId ||
        input.session.identityContextId
          ? {
              ...metadata,
              identityContextId: input.session.identityContextId ?? null,
              gatewayId: input.session.gatewayId ?? null,
              gatewayName: input.session.gatewayName ?? null,
              projectId: input.session.projectId ?? null,
              ...(input.metadata ?? {}),
            }
          : null,
    });
  }

  async function reflectToolActionInteractionLifecycle(input: {
    actionRequestId: string;
    status:
      | "approved"
      | "executing"
      | "executed"
      | "failed"
      | "expired"
      | "cancelled";
    errorCode?: string | null;
    errorMessage?: string | null;
    resultSummary?: string | null;
  }): Promise<void> {
    const [linked] = await db
      .select({
        companyId: toolActionRequests.companyId,
        interactionId: toolActionRequests.interactionId,
        issueId: toolActionRequests.issueId,
      })
      .from(toolActionRequests)
      .where(eq(toolActionRequests.id, input.actionRequestId))
      .limit(1);
    if (!linked?.interactionId) return;

    const interactionId = linked.interactionId;
    const changed = await db.transaction(async (tx) => {
      const [interaction] = await tx
        .select({
          status: issueThreadInteractions.status,
          result: issueThreadInteractions.result,
        })
        .from(issueThreadInteractions)
        .where(
          and(
            eq(issueThreadInteractions.id, interactionId),
            eq(issueThreadInteractions.companyId, linked.companyId),
          ),
        )
        .for("update")
        .limit(1);
      const [currentRequest] = await tx
        .select({ status: toolActionRequests.status })
        .from(toolActionRequests)
        .where(eq(toolActionRequests.id, input.actionRequestId))
        .for("update");
      if (currentRequest?.status !== input.status) return false;
      if (!interaction) return;

      const currentResult =
        interaction.result && typeof interaction.result === "object"
          ? (interaction.result as unknown as Record<string, unknown>)
          : null;
      const outcome =
        typeof currentResult?.outcome === "string"
          ? currentResult.outcome
          : interaction.status === "accepted"
            ? "accepted"
            : interaction.status === "rejected"
              ? "rejected"
              : interaction.status === "expired" ||
                  input.status === "expired" ||
                  input.status === "cancelled"
                ? "stale_target"
                : null;
      if (!outcome) return;

      const now = new Date();
      await tx
        .update(issueThreadInteractions)
        .set({
          ...(["expired", "cancelled"].includes(input.status) &&
          interaction.status === "pending"
            ? { status: input.status, resolvedAt: now }
            : {}),
          result: {
            ...(currentResult ?? { version: 1, outcome }),
            toolAction: {
              ...asRecord(currentResult?.toolAction),
              version: 1,
              status: input.status === "cancelled" ? "expired" : input.status,
              errorCode: input.errorCode ?? null,
              errorMessage: input.errorMessage ?? null,
              resultSummary: input.resultSummary ?? null,
              updatedAt: now.toISOString(),
            },
          } as unknown as NonNullable<
            typeof issueThreadInteractions.$inferInsert.result
          >,
          updatedAt: now,
        })
        .where(eq(issueThreadInteractions.id, interactionId));
      return true;
    });
    if (!changed) return;
    await logActivity(db, {
      companyId: linked.companyId,
      actorType: "system",
      actorId: "tool-gateway",
      action: "issue.thread_interaction_updated",
      entityType: "issue",
      entityId: linked.issueId!,
      details: {
        interactionId: linked.interactionId,
        actionRequestId: input.actionRequestId,
        executionStatus: input.status,
      },
    });
    if (["executed", "failed", "expired", "cancelled"].includes(input.status))
      await options
        .onToolActionSettled?.(input.actionRequestId)
        .catch((error) =>
          logger.warn(
            { err: error, actionRequestId: input.actionRequestId },
            "Tool review continuation will be retried",
          ),
        );
  }

  async function approvalRequiredInstructions(
    issueId: string,
  ): Promise<string> {
    const [issue] = await db
      .select({ identifier: issues.identifier })
      .from(issues)
      .where(eq(issues.id, issueId))
      .limit(1);
    const task = issue?.identifier ?? issueId;
    return `A human approval card was posted on task ${task}. Do not retry this call now. Wrap up other work and end your run noting you are waiting on tool approval (status in_review). You will be woken when it is decided; if approved, the action runs automatically and your wake includes the result.`;
  }

  async function throwApprovalRequired(input: {
    invocationId: string;
    actionRequestId: string;
    interactionId?: string | null;
    issueId: string | null;
    toolName: string;
    argumentsHash: string;
  }): Promise<never> {
    throw new ToolGatewayHttpError(
      409,
      "Tool action requires approval",
      "approval_required",
      {
        invocationId: input.invocationId,
        actionRequestId: input.actionRequestId,
        interactionId: input.interactionId ?? null,
        issueId: input.issueId,
        tool: input.toolName,
        argumentsHash: input.argumentsHash,
        instructions: input.issueId ? await approvalRequiredInstructions(input.issueId)
          : "Review the action on the workflow run. Recovery will continue from its durable receipt after approval.",
      },
    );
  }

  async function requestApprovalForRecordedToolCall(input: {
    invocation: typeof toolInvocations.$inferSelect;
    actionRequest: typeof toolActionRequests.$inferSelect | null;
    session: ToolGatewaySession;
    tool: ToolGatewayDescriptor;
    parameters: unknown;
    argumentsSummary: ReturnType<typeof summarizeToolValue>;
    policyDecision: ToolAccessDecision;
  }): Promise<never> {
    const canonicalArguments = canonicalToolArguments(input.parameters);
    const canonicalArgumentsHash = input.argumentsSummary.sha256 ?? "";
    const approvalSnapshot = await connectedRemoteApprovalSnapshot(
      input.session,
      input.tool,
      {
        requireResolvedCredentials: true,
      },
    );

    if (!input.session.issueId && !input.session.workflowRunId) {
      await db
        .update(toolInvocations)
        .set({
          status: "denied",
          approvalState: "required",
          errorCode: "approval_path_missing",
          errorMessage:
            "Approval-required tool calls need an issue-scoped gateway session",
          completedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(toolInvocations.id, input.invocation.id));
      void emitConnectionInvoked(db, input.invocation.id);
      await writeToolCallEvent({
        invocationId: input.invocation.id,
        actionRequestId: input.actionRequest?.id ?? null,
        session: input.session,
        eventType: "call_denied",
        outcome: "denied",
        toolName: input.tool.name,
        policyDecision: "deny",
        reasonCode: "approval_path_missing",
        argumentsSummary: input.argumentsSummary,
        tool: input.tool,
      });
      throw new ToolGatewayHttpError(
        409,
        "Tool action requires approval, but this gateway session is not attached to an issue",
        "approval_path_missing",
        {
          invocationId: input.invocation.id,
          tool: input.tool.name,
          instructions:
            "This session is not attached to a task, so an approval card cannot be posted. Re-run this action from a run that has the task checked out.",
        },
      );
    }

    if (!input.actionRequest) {
      await db
        .update(toolInvocations)
        .set({
          status: "denied",
          errorCode: "approval_request_missing",
          errorMessage:
            "Approval-required policy decision did not create an action request",
          completedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(toolInvocations.id, input.invocation.id));
      void emitConnectionInvoked(db, input.invocation.id);
      throw new ToolGatewayHttpError(
        500,
        "Approval request was not created",
        "approval_request_missing",
        {
          invocationId: input.invocation.id,
          tool: input.tool.name,
        },
      );
    }
    const actionRequest = input.actionRequest;
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000);

    let signedArguments: ReturnType<typeof signToolArguments>;
    try {
      signedArguments = signToolArguments({
        invocationId: input.invocation.id,
        toolName: input.tool.name,
        canonicalArguments,
        approvalSnapshot: approvalSnapshot ?? undefined,
        executionOnApprove: true,
        identityContextId: input.session.identityContextId ?? undefined,
        signingSecret: options.toolActionSigningSecret,
      });
    } catch (error) {
      await db
        .update(toolActionRequests)
        .set({
          status: "cancelled",
          resolvedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(
          and(
            eq(toolActionRequests.id, actionRequest.id),
            eq(toolActionRequests.status, "pending"),
          ),
        );
      if (error instanceof ToolActionSigningSecretMissingError) {
        await db
          .update(toolInvocations)
          .set({
            status: "failed",
            errorCode: "signing_secret_unconfigured",
            errorMessage: error.message,
            completedAt: new Date(),
            updatedAt: new Date(),
          })
          .where(eq(toolInvocations.id, input.invocation.id));
        void emitConnectionInvoked(db, input.invocation.id);
        throw new ToolGatewayHttpError(
          500,
          error.message,
          "signing_secret_unconfigured",
          {
            invocationId: input.invocation.id,
            tool: input.tool.name,
          },
        );
      }
      throw error;
    }
    // Board-only technical detail for the formal-approval interaction (target=custom).
    const detailsMarkdown = [
      `Tool: \`${input.tool.name}\``,
      `Risk: \`${input.tool.risk}\``,
      "",
      "Arguments reviewed for execution:",
      "",
      "```json",
      input.argumentsSummary.summary,
      "```",
    ].join("\n");

    // Prosumer-facing card preview (M5/M7/M9). Respect an already-set custom preview
    // (e.g. OpenClaw-supplied), otherwise emit plain language with no technical vocab.
    const previewMarkdown =
      actionRequest.previewMarkdown?.trim() ||
      buildHumanizedActionPreview({
        tool: input.tool,
        argumentsSummary: input.argumentsSummary,
      });

    let formalApprovalId: string | null = null;
    if (toolRequiresFormalApproval(input.tool)) {
      const [approval] = await db
        .insert(approvals)
        .values({
          companyId: input.session.companyId,
          type: "request_board_approval",
          requestedByAgentId: input.session.agentId,
          requestedByUserId: input.session.actorType === "user" ? input.session.actorId : null,
          payload: {
            title: `Approve high-risk tool action: ${input.tool.name}`,
            summary: `${input.tool.name} is classified as ${input.tool.risk} and requires formal board approval before execution.`,
            recommendedAction:
              "Approve only if the reviewed arguments match the intended operation.",
            risks: [
              "The tool may perform irreversible or externally visible side effects.",
              "Execution will use the stored reviewed arguments exactly once.",
            ],
            source: "tool_gateway",
            invocationId: input.invocation.id,
            actionRequestId: actionRequest.id,
            tool: input.tool.name,
            risk: input.tool.risk,
            argumentsHash: canonicalArgumentsHash,
          },
        })
        .returning();
      formalApprovalId = approval.id;
      if (input.session.issueId) await db
        .insert(issueApprovals)
        .values({
          companyId: input.session.companyId,
          issueId: input.session.issueId,
          approvalId: approval.id,
          linkedByAgentId: input.session.agentId,
        })
        .onConflictDoNothing();
    }

    const interaction = input.session.issueId ? await interactions.create(
      { id: input.session.issueId, companyId: input.session.companyId },
      {
        kind: "request_confirmation",
        idempotencyKey: `tool-action:${actionRequest.id}`,
        title: "Approve tool action",
        resolverPolicy: "human_only",
        sourceRunId: input.session.runId ?? undefined,
        summary: "This action needs your approval before it runs.",
        continuationPolicy: "wake_assignee",
        payload: {
          version: 1,
          prompt: `Approve ${input.tool.displayName?.trim() || input.tool.name}?`,
          acceptLabel: "Approve action",
          rejectLabel: "Reject action",
          rejectRequiresReason: false,
          allowDeclineReason: true,
          supersedeOnUserComment: false,
          detailsMarkdown,
          target: {
            type: "custom",
            key: `tool-action:${actionRequest.id}`,
            revisionId: canonicalArgumentsHash,
            label: input.tool.name,
          },
          toolAction: {
            version: 1,
            actionRequestId: actionRequest.id,
            invocationId: input.invocation.id,
            toolName: input.tool.name,
            toolDisplayName: input.tool.displayName?.trim() || input.tool.name,
            connectionId: input.tool.connectionId ?? null,
            applicationId: input.tool.applicationId ?? null,
            appDisplayName: input.tool.applicationDisplayName?.trim() || null,
            risk:
              input.tool.risk === "read"
                ? "read"
                : input.tool.risk === "destructive"
                  ? "destructive"
                  : "write",
            ...(!formalApprovalId &&
            input.session.agentId &&
            input.tool.connectionId
              ? {
                  rememberActionScope: `This agent may use this action with different arguments on this connection${input.session.projectId ? " within this project" : ""}.`,
                }
              : {}),
            previewMarkdown,
            argumentsSummaryJson: input.argumentsSummary.summary,
            argumentsHash: canonicalArgumentsHash,
            expiresAt: expiresAt.toISOString(),
          },
        },
      },
      { agentId: input.session.agentId },
    ) : null;

    // Sign the row only while it is still pending. A concurrent matching call can
    // expire this row when the create runs longer than the abandon grace time.
    // Guard the update with the pending status so the sign step never resurrects
    // an expired row. When the guard matches no row, the row is already resolved.
    // Do not emit an approval card for a dead row; throw a retriable conflict so
    // the retry finds the live request or creates a fresh, signable one.
    const signedRows = await db
      .update(toolActionRequests)
      .set({
        interactionId: interaction?.id ?? null,
        canonicalArgumentsHash,
        canonicalArgumentsSummary: input.argumentsSummary,
        signedArguments,
        previewMarkdown,
        approvalId: formalApprovalId,
        expiresAt,
        updatedAt: new Date(),
      })
      .where(
        and(
          eq(toolActionRequests.id, actionRequest.id),
          eq(toolActionRequests.status, "pending"),
        ),
      )
      .returning({ id: toolActionRequests.id });
    if (signedRows.length === 0) {
      await db
        .update(toolInvocations)
        .set({
          status: "failed",
          approvalState: "expired",
          errorCode: "approval_request_superseded",
          errorMessage:
            "The approval request was resolved before it could be signed",
          completedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(toolInvocations.id, input.invocation.id));
      void emitConnectionInvoked(db, input.invocation.id);
      throw new ToolGatewayHttpError(
        409,
        "The approval request was resolved before it could be signed",
        "approval_request_superseded",
        {
          invocationId: input.invocation.id,
          actionRequestId: actionRequest.id,
          tool: input.tool.name,
          instructions:
            "A parallel call already handled this approval. Retry the same call now to reach the live approval request.",
        },
      );
    }

    if (input.session.issueId && interaction) await db
      .insert(toolActionDeliveries)
      .values({
        companyId: input.session.companyId,
        actionRequestId: actionRequest.id,
        issueId: input.session.issueId,
        interactionId: interaction?.id ?? null,
      })
      .onConflictDoNothing();

    await writeToolCallEvent({
      invocationId: input.invocation.id,
      actionRequestId: actionRequest.id,
      session: input.session,
      eventType: "approval_requested",
      outcome: "pending",
      toolName: input.tool.name,
      policyDecision: "require_approval",
      reasonCode: "requires_approval_policy",
      argumentsSummary: input.argumentsSummary,
      metadata: {
        actionRequestId: actionRequest.id,
        interactionId: interaction?.id ?? null,
        approvalId: formalApprovalId,
      },
      tool: input.tool,
    });

    await writeAudit({
      session: input.session,
      companyId: input.session.companyId,
      agentId: input.session.agentId,
      runId: input.session.runId,
      issueId: input.session.issueId,
      action: "tool_gateway.approval_requested",
      details: {
        invocationId: input.invocation.id,
        actionRequestId: actionRequest.id,
        interactionId: interaction?.id ?? null,
        approvalId: formalApprovalId,
        decision: "require_approval",
        reasonCode: "requires_approval_policy",
        matchedPolicyIds: input.policyDecision.matchedPolicyIds,
        tool: input.tool.name,
        ...toolAuditMetadata(input.tool),
        argumentsSummary: input.argumentsSummary,
      },
    });

    return throwApprovalRequired({
      invocationId: input.invocation.id,
      actionRequestId: actionRequest.id,
      interactionId: interaction?.id ?? null,
      issueId: input.session.issueId,
      toolName: input.tool.name,
      argumentsHash: canonicalArgumentsHash,
    });
  }

  function typedWorkflowToolResult(tool: ToolGatewayDescriptor, value: unknown) {
    const schema = asRecord(asRecord(tool.providerMetadata)?.outputSchema);
    if (!schema) return value;
    const data = asRecord(value)?.structuredContent ?? value;
    try { validateWorkflowOutput(schema, data); }
    catch (error) {
      if (!(error instanceof WorkflowOutputSchemaError)) throw error;
      throw new ToolGatewayHttpError(502, "Connected action output did not match its published schema",
        error.code === "workflow_output_schema_invalid" ? "tool_output_schema_invalid" : "tool_output_schema_mismatch");
    }
    return data;
  }

  function policyInputForTool(input: {
    session: ToolGatewaySession;
    tool: ToolGatewayDescriptor;
    parameters?: unknown;
    idempotencyKey?: string | null;
    consumeRateLimit?: boolean;
  }): ToolAccessDecisionInput {
    const operation = agentNativeOperationForToolName(input.tool.name);
    const policyTool = operation
      ? { ...input.tool, name: operation.legacyAliases[0] }
      : input.tool;
    return policyInputForAgentTool({
      companyId: input.session.companyId,
      agentId: input.session.agentId,
      actorType: input.session.actorType,
      actorId: input.session.actorId ?? input.session.gatewayTokenId ?? null,
      tool: policyTool,
      parameters: input.parameters,
      idempotencyKey: input.idempotencyKey,
      consumeRateLimit: input.consumeRateLimit,
      heartbeatRunId: input.session.runId,
      workflowRunId: input.session.workflowRunId,
      workflowNodeId: input.session.workflowNodeId,
      issueId: input.session.issueId,
      projectId: input.session.projectId,
      gatewayId: input.session.gatewayId ?? null,
    });
  }

  function policyInputForAgentTool(input: {
    companyId: string;
    agentId: string | null;
    actorType?: "agent" | "user" | "system" | "plugin";
    actorId?: string | null;
    tool: ToolGatewayDescriptor;
    parameters?: unknown;
    idempotencyKey?: string | null;
    consumeRateLimit?: boolean;
    heartbeatRunId?: string | null;
    workflowRunId?: string | null;
    workflowNodeId?: string | null;
    issueId?: string | null;
    projectId?: string | null;
    gatewayId?: string | null;
  }): ToolAccessDecisionInput {
    const actorType = input.actorType ?? (input.agentId ? "agent" : "system");
    const actorId =
      input.actorId ?? input.agentId ?? input.gatewayId ?? input.companyId;
    return {
      companyId: input.companyId,
      actor: {
        actorType,
        actorId,
        agentId: input.agentId,
      },
      runContext: {
        heartbeatRunId: input.heartbeatRunId ?? null,
        workflowRunId: input.workflowRunId ?? null,
        workflowNodeId: input.workflowNodeId ?? null,
        issueId: input.issueId ?? null,
        projectId: input.projectId ?? null,
        gatewayId: input.gatewayId ?? null,
      },
      request: {
        toolName: input.tool.name,
        applicationId: input.tool.applicationId ?? null,
        applicationKey: input.tool.applicationKey ?? null,
        connectionId: input.tool.connectionId ?? null,
        catalogEntryId: input.tool.catalogEntryId ?? null,
        providerType: input.tool.providerType,
        upstreamToolName: input.tool.upstreamToolName ?? input.tool.name,
        riskLevel: input.tool.risk,
        arguments: input.parameters ?? {},
        idempotencyKey: input.idempotencyKey ?? null,
        sideEffecting: input.tool.risk !== "read",
      },
      consumeRateLimit: input.consumeRateLimit === true,
    };
  }

  function policyErrorStatus(decision: ToolAccessDecision) {
    if (decision.decision === "rate_limited") return 429;
    return 403;
  }

  function findStaticTool(toolName: string): ToolGatewayDescriptor {
    const operation = agentNativeOperationForToolName(toolName);
    const tool = (operation ? BUILTIN_TOOLS.find((candidate) =>
      candidate.providerType === "paperclip_self" && operation.legacyAliases.includes(candidate.name)) : undefined) ??
      allTools().find((candidate) => candidate.name === toolName);
    if (!tool) {
      throw new ToolGatewayHttpError(
        404,
        `Tool "${toolName}" not found`,
        "tool_not_found",
        { tool: toolName },
      );
    }
    return tool;
  }

  async function findToolForSession(
    session: ToolGatewaySession,
    toolName: string,
  ): Promise<ToolGatewayDescriptor> {
    const connectedTools = await connectedMcpToolsForCompany(session.companyId);
    // Classify the stored requested descriptor before identity selection can
    // refresh OAuth or open a vault credential. This catalogue projection is
    // secret-free, shared by direct, approved and virtual invocation entries.
    const requestedConnected = agentNativeOperationForToolName(toolName) ? null
      : connectedTools.find(candidate => candidate.name === toolName);
    if (requestedConnected) await assertConnectedToolModelEffects(session, requestedConnected);
    const hasOnDemandTargets = connectedTools.some(isOnDemandRemoteTool);
    const virtualTools = hasOnDemandTargets ? VIRTUAL_TOOLS : [];
    const githubBotTools = await githubBotToolsForSession(db, session);
    const candidates = [...await eligibleStaticToolsForSession(session), ...connectedTools, ...virtualTools, ...githubBotTools, ...await slackToolsForSession(db, session)]
      .filter(
        (candidate) =>
          session.agentId ||
          (candidate.providerType !== "paperclip_self" &&
            candidate.providerType !== "paperclip_plugin"),
      );
    const operation = agentNativeOperationForToolName(toolName);
    const operationTool = operation ? candidates.find((candidate) =>
      candidate.providerType === "paperclip_self" && operation.legacyAliases.includes(candidate.name)) : undefined;
    // Canonical operation IDs and historical aliases are reserved names. A
    // disabled first-party tool must stay unavailable instead of falling
    // through to a same-named plugin/connector candidate.
    const tool = operation ? operationTool : candidates.find((candidate) => candidate.name === toolName);
    if (!tool) {
      throw new ToolGatewayHttpError(
        404,
        `Tool "${toolName}" not found`,
        "tool_not_found",
        { tool: toolName },
      );
    }
    if (tool.providerType === "paperclip_self" && !agentNativeOperationForLegacyToolName(tool.name)) {
      throw new ToolGatewayHttpError(503, "First-party operation metadata is unavailable", "operation_manifest_incomplete");
    }
    const guestBotConnection = await githubGuestBotConnectionForSession(db, session);
    if (guestBotConnection && tool.connectionId && (tool.connectionId !== guestBotConnection || tool.providerType !== "paperclip_github_chat"))
      throw new ToolGatewayHttpError(403, "Sponsored GitHub runs can only use their bot's governed connection; sponsorship does not grant personal credentials", "guest_connection_denied");
    if (session.identityContextId && session.agentId && tool.connectionId) {
      const [connection] = await db
        .select()
        .from(toolConnections)
        .where(
          and(
            eq(toolConnections.id, tool.connectionId),
            eq(toolConnections.companyId, session.companyId),
          ),
        );
      if (
        connection?.config.sourceTemplateKey === "github" ||
        connection?.transportConfig?.sourceTemplateKey === "github"
      ) {
        let selected = await resolveManagedGitHubIdentitySelection(
          db,
          session.companyId,
          {
            agentId: session.agentId,
            responsibleUserId: session.responsibleUserId,
            allowStandingDelegation: false,
          },
        );
        if (!selected.grant)
          throw new ToolGatewayHttpError(
            409,
            selected.error ?? "No GitHub identity connected",
            "github_identity_unavailable",
          );
        const original = selected.grant;
        // Acquire before policy evaluation or dispatch. An alternate connection
        // gets its own catalog descriptor and policy checks; never replay a call.
        for (let attempt = 0; attempt < 2; attempt += 1) {
          const grant = selected.grant!;
          const target = connectedTools.find(
            (candidate) =>
              candidate.connectionId === grant.connectionId &&
              candidate.upstreamToolName === tool.upstreamToolName &&
              candidate.providerType === tool.providerType,
          );
          if (!target)
            throw new ToolGatewayHttpError(
              404,
              "This GitHub tool is unavailable for the responsible person",
              "github_tool_unavailable",
            );
          const [selectedConnection] = await db
            .select()
            .from(toolConnections)
            .where(
              and(
                eq(toolConnections.id, grant.connectionId),
                eq(toolConnections.companyId, session.companyId),
              ),
            );
          if (!selectedConnection)
            throw new ToolGatewayHttpError(
              409,
              "GitHub connection is unavailable",
              "github_identity_unavailable",
            );
          if (attempt === 0)
            await resolveConnectionGrant(session, selectedConnection);
          try {
            const headers = await resolveCredentialHeaders(
              session,
              selectedConnection,
              grant,
            );
            githubOperationCredentials.set(session, { grant, headers });
            return target;
          } catch (error) {
            if (attempt !== 0) throw error;
            const alternate = await resolveManagedGitHubIdentitySelection(
              db,
              session.companyId,
              {
                agentId: session.agentId,
                responsibleUserId: session.responsibleUserId,
                allowStandingDelegation: false,
                excludeGrantId: original.id,
              },
            );
            const accountId = original.providerTenant?.github?.userId;
            if (
              !accountId ||
              !alternate.grant ||
              alternate.grant.providerTenant?.github?.userId !== accountId ||
              alternate.grant.subjectUserId !== original.subjectUserId ||
              alternate.grant.subjectAgentId !== original.subjectAgentId
            )
              throw error;
            selected = alternate;
          }
        }
        throw new ToolGatewayHttpError(
          409,
          "GitHub credentials are unavailable",
          "github_identity_unavailable",
        );
      }
    }
    return tool;
  }

  function virtualRunToolInput(parameters: unknown): {
    targetToolName: string;
    targetParameters: unknown;
  } {
    const params = asRecord(parameters) ?? {};
    const targetToolName =
      typeof params.tool === "string" ? params.tool.trim() : "";
    if (!targetToolName) {
      throw new ToolGatewayHttpError(
        400,
        "run_tool requires a target tool name",
        "invalid_parameters",
      );
    }
    return {
      targetToolName,
      targetParameters: params.arguments ?? {},
    };
  }

  async function searchableOnDemandTools(
    session: ToolGatewaySession,
  ): Promise<ToolGatewayDescriptor[]> {
    const tools = (await connectedMcpToolsForCompany(session.companyId)).filter(
      isOnDemandRemoteTool,
    );
    const decisions = await Promise.all(
      tools.map(async (tool) => ({
        tool,
        decision: await policyService.decide(
          policyInputForTool({ session, tool }),
        ),
      })),
    );
    return decisions
      .filter(
        ({ decision }) =>
          decision.allowed || decision.decision === "require_approval",
      )
      .map(({ tool }) => tool);
  }

  async function executeVirtualSearchTools(
    session: ToolGatewaySession,
    parameters: unknown,
  ) {
    const params = asRecord(parameters) ?? {};
    const query =
      typeof params.query === "string" ? params.query.trim().toLowerCase() : "";
    const limit = Math.max(1, Math.min(50, Number(params.limit ?? 10) || 10));
    const tools = (await searchableOnDemandTools(session))
      .filter((tool) => {
        if (!query) return true;
        return [
          tool.name,
          tool.displayName,
          tool.description,
          tool.applicationKey,
          tool.upstreamToolName,
        ]
          .filter((value): value is string => typeof value === "string")
          .some((value) => value.toLowerCase().includes(query));
      })
      .slice(0, limit)
      .map((tool) => ({
        name: tool.name,
        displayName: tool.displayName ?? tool.name,
        description: tool.description ?? null,
        parametersSchema: tool.parametersSchema,
        applicationId: tool.applicationId ?? null,
        connectionId: tool.connectionId ?? null,
        catalogEntryId: tool.catalogEntryId ?? null,
        upstreamToolName: tool.upstreamToolName ?? tool.name,
        risk: tool.risk,
      }));

    return {
      content: JSON.stringify({ tools }),
      data: { tools },
    };
  }

  async function listToolsForContext(
    session: ToolGatewaySession,
  ): Promise<ToolGatewayDescriptor[]> {
    if (session.agentId) {
      await assertAgentInCompany(session.companyId, session.agentId);
    }
    const guestBotConnection = await githubGuestBotConnectionForSession(db, session);
    const allConnectedTools = (await connectedMcpToolsForCompany(
      session.companyId,
    )).filter(tool => !guestBotConnection || !tool.connectionId || (tool.connectionId === guestBotConnection && tool.providerType === "paperclip_github_chat"));
    const onDemandTargets = allConnectedTools.filter(isOnDemandRemoteTool);
    const tools = [
      ...await staticToolsForSession(session),
      ...await githubBotToolsForSession(db, session),
      ...await slackToolsForSession(db, session),
      ...allConnectedTools.filter((tool) => !isOnDemandRemoteTool(tool)),
    ].filter(
      (tool) =>
        session.agentId ||
        (tool.providerType !== "paperclip_self" &&
          tool.providerType !== "paperclip_plugin"),
    );
    const decisions = await Promise.all(
      tools.map(async (tool) => {
        const decision = await policyService.decide(
          policyInputForTool({ session, tool }),
        );
        return { tool, decision };
      }),
    );
    const visibleTools = decisions
      .filter(
        ({ decision }) =>
          decision.allowed || decision.decision === "require_approval",
      )
      .map(({ tool, decision }) =>
        decision.decision === "require_approval"
          ? {
              ...tool,
              description: [
                tool.description?.trim(),
                TOOL_APPROVAL_DESCRIPTION_SUFFIX,
              ]
                .filter(Boolean)
                .join(" "),
            }
          : tool,
      );
    if (onDemandTargets.length > 0) {
      const targetDecisions = await Promise.all(
        onDemandTargets.map(async (tool) => {
          const decision = await policyService.decide(
            policyInputForTool({ session, tool }),
          );
          return { tool, decision };
        }),
      );
      if (
        targetDecisions.some(
          ({ decision }) =>
            decision.allowed || decision.decision === "require_approval",
        )
      ) {
        visibleTools.push(...VIRTUAL_TOOLS);
      }
    }
    return visibleTools;
  }

  async function executeBuiltinTool(
    session: ToolGatewaySession,
    tool: ToolGatewayDescriptor,
    parameters: unknown,
    invocationId?: string,
    scopedContext?: ScopedToolGatewayContext,
  ) {
    const params = asRecord(parameters) ?? {};

    const runnerTaskOperation = RUNNER_TASK_OPERATION_BY_SELF_TOOL[tool.name];
    if (runnerTaskOperation) {
      if (!session.agentId || !session.runId || !session.issueId || !invocationId) {
        throw new ToolGatewayHttpError(403,
          "Task mutations require a current Native Agent run and durable Tool Gateway call identity",
          "native_task_run_required");
      }
      const actor = currentSessionMemoryActor(session);
      if (!actor || actor.type !== "agent" || !actor.onBehalfOfUserId) {
        throw new ToolGatewayHttpError(403,
          "Task mutations require the original verified Agent credential and current represented Human",
          "native_task_authority_unavailable");
      }
      const result = await new PaperclipRunnerToolAuthority(db, {
        companyId: session.companyId,
        agentId: session.agentId,
        issueId: session.issueId,
        runId: session.runId,
        sourceChannel: "tool_gateway_mcp",
        transportCallId: invocationId,
        requireCurrentResponsibleUser: true,
      }).execute({ tool: runnerTaskOperation, callId: invocationId, arguments: params });
      return { content: JSON.stringify(result), data: result };
    }

    if (tool.providerType === "paperclip_slack_chat") {
      if (!session.agentId || !session.runId || !session.issueId) throw new ToolGatewayHttpError(403, "Slack task binding required", "slack_task_required");
      try {
      const data = await executeSlackTool(db, { companyId: session.companyId, agentId: session.agentId, runId: session.runId, issueId: session.issueId, endpointId: String(asRecord(tool.providerMetadata)?.endpointId ?? ""), identityContextId: session.identityContextId, approvedInvocationId: session.approvedSlackInvocationId }, tool.upstreamToolName ?? "", parameters, fetch, invocationId);
      return { content: JSON.stringify(data), data };
      } catch (error) {
        if (error instanceof HttpError) {
          const details = asRecord(error.details) ?? {};
          throw new ToolGatewayHttpError(error.status, error.message, typeof details.code === "string" ? details.code : "slack_operation_rejected", details);
        }
        throw error;
      }
    }
    if (tool.providerType === "paperclip_github_chat") {
      const data = await githubChatReviewService(db).execute(session, tool.upstreamToolName ?? "", parameters, invocationId);
      return { content: JSON.stringify(data), data };
    }
    if (tool.name === "mcp-remote-fixture:echo") {
      return {
        content: String(params.message ?? ""),
        data: {
          transport: "mcp_http",
          spawnedLocalProcess: false,
        },
      };
    }

    if (tool.name === "mcp-remote-fixture:add") {
      const a = Number(params.a);
      const b = Number(params.b);
      if (!Number.isFinite(a) || !Number.isFinite(b)) {
        throw new ToolGatewayHttpError(
          400,
          "Parameters a and b must be finite numbers",
          "invalid_parameters",
        );
      }
      return {
        content: String(a + b),
        data: {
          result: a + b,
          transport: "mcp_http",
          spawnedLocalProcess: false,
        },
      };
    }

    if (tool.name === "mcp-remote-fixture:update_note") {
      const noteId =
        typeof params.noteId === "string" ? params.noteId.trim() : "";
      const body = typeof params.body === "string" ? params.body : "";
      if (!noteId || !body) {
        throw new ToolGatewayHttpError(
          400,
          "Parameters noteId and body are required",
          "invalid_parameters",
        );
      }
      return {
        content: JSON.stringify({ noteId, updated: true }),
        data: {
          noteId,
          bodyLength: body.length,
          transport: "mcp_http",
          spawnedLocalProcess: false,
        },
      };
    }

    if (tool.name === "paperclip-self:list_my_issues") {
      if (!session.agentId) {
        throw new ToolGatewayHttpError(
          403,
          "Paperclip self tools require an agent-scoped gateway session",
          "agent_context_required",
        );
      }
      const actor = currentSessionMemoryActor(session);
      if (!actor) throw new ToolGatewayHttpError(403,
        "Task discovery requires the original verified Agent credential and represented Human", "task_reader_authority_unavailable");
      const limit = Math.max(1, Math.min(50, Number(params.limit ?? 10) || 10));
      const rows = await withCurrentTaskSourceRead(db, session.companyId, actor, async (queryDb) => {
        const readCondition = await issueReadSqlCondition(queryDb, actor);
        return queryDb
          .select({
            id: issues.id,
            identifier: issues.identifier,
            title: issues.title,
            status: issues.status,
            priority: issues.priority,
          })
          .from(issues)
          .where(and(
            eq(issues.companyId, session.companyId),
            eq(issues.assigneeAgentId, session.agentId!),
            readCondition,
          ))
          .orderBy(desc(issues.updatedAt))
          .limit(limit);
      }, true, true);

      return {
        content: JSON.stringify(rows),
        data: { issues: rows },
      };
    }

    if (tool.name === "paperclip-self:get_issue_context") {
      if (!session.agentId) {
        throw new ToolGatewayHttpError(
          403,
          "Paperclip self tools require an agent-scoped gateway session",
          "agent_context_required",
        );
      }
      const actor = currentSessionMemoryActor(session);
      if (!actor) throw new ToolGatewayHttpError(403,
        "Task context requires the original verified Agent credential and represented Human", "task_reader_authority_unavailable");
      const issueId =
        typeof params.issueId === "string" ? params.issueId : session.issueId;
      if (!issueId) {
        throw new ToolGatewayHttpError(
          400,
          "issueId is required when the session is not issue-scoped",
          "missing_issue_id",
        );
      }
      const result = await withCurrentTaskSourceRead(db, session.companyId, actor, async (queryDb) => {
        const readCondition = await issueReadSqlCondition(queryDb, actor);
        const [issue] = await queryDb
          .select({
            id: issues.id,
            identifier: issues.identifier,
            title: issues.title,
            description: issues.description,
            status: issues.status,
            priority: issues.priority,
          })
          .from(issues)
          .where(and(eq(issues.companyId, session.companyId), eq(issues.id, issueId), readCondition))
          .limit(1)
          .for("share");
        if (!issue) return null;

        const [planDocument] = await queryDb
          .select({
            documentId: documents.id,
            title: documents.title,
            latestRevisionId: documents.latestRevisionId,
            latestRevisionNumber: documents.latestRevisionNumber,
          })
          .from(issueDocuments)
          .innerJoin(documents, eq(issueDocuments.documentId, documents.id))
          .where(and(eq(issueDocuments.issueId, issue.id), eq(issueDocuments.key, "plan")))
          .limit(1);
        return { issue, planDocument: planDocument ?? null };
      }, true, true);
      if (!result) {
        throw new ToolGatewayHttpError(
          404,
          "Issue not found",
          "issue_not_found",
        );
      }

      return {
        content: JSON.stringify(result),
        data: result,
      };
    }

    if (tool.name === "paperclip-self:get_my_agent_context") {
      if (!session.agentId || !session.runId) throw new ToolGatewayHttpError(403,
        "Co-worker status requires an Agent-scoped current run", "agent_context_required");
      const actor = currentSessionMemoryActor(session);
      if (!actor) throw new ToolGatewayHttpError(403,
        "Co-worker status requires the original verified Agent credential and represented Human", "agent_reader_authority_unavailable");
      const data = await withCurrentTaskSourceRead(db, session.companyId, actor, async (queryDb) => {
        const currentAgent = await agentService(queryDb).getById(session.agentId!);
        const agent = currentAgent?.companyId === session.companyId ? {
          id: currentAgent.id, name: currentAgent.name, title: currentAgent.title, role: currentAgent.role,
          status: currentAgent.status, reportsTo: currentAgent.reportsTo,
          lastHeartbeatAt: currentAgent.lastHeartbeatAt, updatedAt: currentAgent.updatedAt,
        } : null;
        const [run] = await queryDb.select({ id: heartbeatRuns.id, status: heartbeatRuns.status,
          startedAt: heartbeatRuns.startedAt, finishedAt: heartbeatRuns.finishedAt }).from(heartbeatRuns).where(and(
          eq(heartbeatRuns.companyId, session.companyId), eq(heartbeatRuns.id, session.runId!),
          eq(heartbeatRuns.agentId, session.agentId!), eq(heartbeatRuns.responsibleUserId, actor.onBehalfOfUserId!),
          eq(heartbeatRuns.status, "running"),
        )).limit(1).for("share");
        return agent && run ? { agent, run } : null;
      }, true, true);
      if (!data) throw new ToolGatewayHttpError(404, "Current Co-worker run not found", "agent_run_not_found");
      return { content: JSON.stringify(data), data };
    }

    if (tool.name === "paperclip-self:get_my_current_work") {
      if (!session.agentId || !session.runId || !session.issueId) throw new ToolGatewayHttpError(403,
        "Current work requires an issue-scoped Agent run", "agent_context_required");
      const actor = currentSessionMemoryActor(session);
      if (!actor) throw new ToolGatewayHttpError(403,
        "Current work requires the original verified Agent credential and represented Human", "task_reader_authority_unavailable");
      const data = await withCurrentTaskSourceRead(db, session.companyId, actor, async (queryDb) => {
        const readCondition = await issueReadSqlCondition(queryDb, actor);
        const [issue] = await queryDb.select({ id: issues.id, identifier: issues.identifier, title: issues.title,
          status: issues.status, priority: issues.priority, updatedAt: issues.updatedAt })
          .from(issues).where(and(eq(issues.companyId, session.companyId), eq(issues.id, session.issueId!), readCondition))
          .limit(1).for("share");
        const [run] = await queryDb.select({ id: heartbeatRuns.id, status: heartbeatRuns.status,
          startedAt: heartbeatRuns.startedAt }).from(heartbeatRuns).where(and(
          eq(heartbeatRuns.companyId, session.companyId), eq(heartbeatRuns.id, session.runId!),
          eq(heartbeatRuns.agentId, session.agentId!), or(
            eq(heartbeatRuns.issueId, session.issueId!), eq(heartbeatRuns.nativeIssueId, session.issueId!),
            sql`${heartbeatRuns.contextSnapshot}->>'issueId'=${session.issueId}`,
          ),
          eq(heartbeatRuns.responsibleUserId, actor.onBehalfOfUserId!), eq(heartbeatRuns.status, "running"),
        )).limit(1).for("share");
        return issue && run ? { issue, run } : null;
      }, true, true);
      if (!data) throw new ToolGatewayHttpError(404, "Current Task not found", "issue_not_found");
      return { content: JSON.stringify(data), data };
    }

    if (tool.name === "paperclip-self:search_decisions") {
      if (!session.agentId || !session.runId) throw new ToolGatewayHttpError(403,
        "Decision search requires an Agent-scoped current run", "agent_context_required");
      const actor = currentSessionMemoryActor(session);
      if (!actor) throw new ToolGatewayHttpError(403,
        "Decision search requires the original verified Agent credential and represented Human", "decision_reader_authority_unavailable");
      const query = typeof params.query === "string" ? params.query.trim() : "";
      if (!query || query.length > 500) throw new ToolGatewayHttpError(400, "A search query of 1 to 500 characters is required", "invalid_parameters");
      const limit = typeof params.limit === "number" ? Math.max(1, Math.min(20, Math.floor(params.limit))) : 20;
      const result = await decisionSearchService(db).search(session.companyId, actor, query, limit);
      const data = { items: result.items, limitReached: result.items.length >= limit };
      return { content: JSON.stringify(data), data };
    }

    if (tool.name === "paperclip-self:search_process_findings") {
      if (!session.agentId || !session.runId) throw new ToolGatewayHttpError(403,
        "Insight search requires an Agent-scoped current run", "agent_context_required");
      const actor = currentSessionMemoryActor(session);
      if (!actor) throw new ToolGatewayHttpError(403,
        "Insight search requires the original verified Agent credential and represented Human", "insight_reader_authority_unavailable");
      const query = typeof params.query === "string" ? params.query.trim() : "";
      if (query.length > 500) throw new ToolGatewayHttpError(400, "Search query is too long", "invalid_parameters");
      const limit = typeof params.limit === "number" ? Math.max(1, Math.min(20, Math.floor(params.limit))) : 20;
      const result = await withNativeAnalyticalReader(db, session.companyId, actor,
        () => processFindingService(db).search(session.companyId, actor, query, limit), "task");
      const data = { items: result.items, limitReached: result.items.length >= limit };
      return { content: JSON.stringify(data), data };
    }

    if (tool.name === "paperclip-self:create_support_request") {
      if (!session.agentId || !session.runId || !supportCaseDataPolicy) throw new ToolGatewayHttpError(403,
        "Support requests require a configured intake policy and an Agent-scoped run", "support_request_unavailable");
      const actor = currentSessionMemoryActor(session);
      if (!actor) throw new ToolGatewayHttpError(403,
        "Support requests require the original verified Agent credential and represented Human", "support_request_authority_unavailable");
      const data = await customerSupportCaseService(db, { dataPolicy: supportCaseDataPolicy })
        .createFromNative(actor, session.companyId, params);
      return { content: JSON.stringify(data), data };
    }

    if (tool.name === "paperclip-self:get_support_intake_status") {
      if (!session.agentId || !session.runId) throw new ToolGatewayHttpError(403,
        "Support intake status requires an Agent-scoped run", "agent_context_required");
      const actor = currentSessionMemoryActor(session);
      if (!actor) throw new ToolGatewayHttpError(403,
        "Support intake status requires the original verified Agent credential and represented Human", "support_reader_authority_unavailable");
      const data = await customerSupportCaseService(db, { dataPolicy: supportCaseDataPolicy })
        .intakePolicyFromNative(actor, session.companyId);
      return { content: JSON.stringify(data), data };
    }

    if (tool.name === "paperclip-self:get_service_status") {
      if (!session.agentId || !session.runId) throw new ToolGatewayHttpError(403,
        "Service status requires an Agent-scoped run", "agent_context_required");
      const actor = currentSessionMemoryActor(session);
      if (!actor) throw new ToolGatewayHttpError(403,
        "Service status requires the original verified Agent credential and represented Human", "service_status_authority_unavailable");
      await assertPlatformSkillAdmission(db, actor, blenteraPlatformContractHashes());
      const data = await serviceHealthReader.read();
      return { content: JSON.stringify(data), data };
    }

    if (tool.name === "paperclip-self:list_authorized_apps") {
      if (!session.agentId) throw new ToolGatewayHttpError(403, "App discovery requires an Agent-scoped gateway session", "agent_context_required");
      const actor = currentSessionMemoryActor(session);
      if (!actor) throw new ToolGatewayHttpError(403,
        "App discovery requires the original verified Agent credential and represented Human", "app_reader_authority_unavailable");
      const connectionTools = (await listToolsForContext(session)).filter((candidate) =>
        candidate.providerType !== "paperclip_self" && typeof candidate.connectionId === "string" &&
        typeof candidate.applicationId === "string");
      const connectionIds = [...new Set(connectionTools.map(candidate => candidate.connectionId!))];
      const apps = await withCurrentTaskSourceRead(db, session.companyId, actor, async (queryDb) => {
        if (connectionIds.length === 0) return [];
        const decisions = await Promise.all(connectionTools.map(async candidate => ({ candidate,
          decision: await toolAccessPolicyService(queryDb).decide(policyInputForTool({ session, tool: candidate })) })));
        const allowedNames = new Map<string, Set<string>>();
        for (const { candidate, decision } of decisions) {
          if (!decision.allowed && decision.decision !== "require_approval") continue;
          const names = allowedNames.get(candidate.connectionId!) ?? new Set<string>();
          names.add(candidate.name);
          allowedNames.set(candidate.connectionId!, names);
        }
        const rows = await queryDb.select({ connectionId: toolConnections.id, connectionName: toolConnections.name,
          applicationName: toolApplications.name, applicationType: toolApplications.type,
          status: toolConnections.status, enabled: toolConnections.enabled, credentialPolicy: toolConnections.credentialPolicy,
          healthStatus: toolConnections.healthStatus, lastHealthAt: toolConnections.lastHealthAt,
        }).from(toolConnections).innerJoin(toolApplications, eq(toolApplications.id, toolConnections.applicationId)).where(and(
          eq(toolConnections.companyId, session.companyId), inArray(toolConnections.id, connectionIds),
          eq(toolApplications.companyId, session.companyId), eq(toolApplications.status, "active"),
          eq(toolConnections.status, "active"), eq(toolConnections.enabled, true),
        )).orderBy(asc(toolApplications.name), asc(toolConnections.name)).for("share");
        return rows.flatMap(row => {
          const toolNames = [...(allowedNames.get(row.connectionId) ?? [])].sort();
          if (toolNames.length === 0) return [];
          return [{ application: row.applicationName, type: row.applicationType,
            connection: row.connectionName, status: row.status, enabled: row.enabled,
            health: row.credentialPolicy === "per_user" ? "unknown" : row.healthStatus,
            lastHealthAt: row.credentialPolicy === "per_user" ? null : row.lastHealthAt?.toISOString() ?? null,
            availableOperations: toolNames }];
        });
      }, true, true);
      const data = { applications: apps };
      return { content: JSON.stringify(data), data };
    }

    if (tool.name === "paperclip-self:list_projects" || tool.name === "paperclip-self:get_project_context") {
      if (!session.agentId) throw new ToolGatewayHttpError(403,
        "Project tools require an agent-scoped gateway session", "agent_context_required");
      const actor = currentSessionMemoryActor(session);
      if (!actor) throw new ToolGatewayHttpError(403,
        "Project reads require the original verified Agent credential and represented Human", "project_reader_authority_unavailable");
      const requestedProjectId = tool.name === "paperclip-self:get_project_context"
        ? typeof params.projectId === "string" && /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(params.projectId) ? params.projectId.toLowerCase() : null
        : null;
      if (tool.name === "paperclip-self:get_project_context" && !requestedProjectId) {
        throw new ToolGatewayHttpError(400, "projectId must be a UUID", "invalid_parameters");
      }
      const limit = Math.max(1, Math.min(50, Number(params.limit ?? 20) || 20));
      const summaries = await withCurrentTaskSourceRead(db, session.companyId, actor, async (queryDb) => {
        const projectCondition = await projectReadSqlCondition(queryDb, actor);
        const candidateQuery = queryDb.select({ id: projects.id }).from(projects).where(and(
          eq(projects.companyId, session.companyId),
          ...(requestedProjectId ? [] : [isNull(projects.archivedAt)]),
          projectCondition,
          ...(requestedProjectId ? [eq(projects.id, requestedProjectId)] : []),
        )).orderBy(desc(projects.updatedAt), asc(projects.name)).limit(requestedProjectId ? 1 : limit).for("share");
        const ids = await candidateQuery;
        if (ids.length === 0) return [];
        const hydrated = await projectService(queryDb).listByIds(session.companyId, ids.map(row => row.id));
        const visible: Array<Pick<(typeof hydrated)[number],
          "id" | "name" | "description" | "status" | "visibility" | "targetDate" | "leadAgentId" | "archivedAt" | "updatedAt">> = [];
        for (const project of hydrated) {
          if (!(await canActorReadProjectPrivacy(queryDb, actor, project))) continue;
          const decision = await authorizationService(queryDb).decide({ actor, action: "project:read",
            resource: { type: "project", companyId: session.companyId, projectId: project.id } });
          if (!decision.allowed) continue;
          visible.push({
            id: project.id,
            name: project.name,
            description: project.description,
            status: project.status,
            visibility: project.visibility,
            targetDate: project.targetDate,
            leadAgentId: project.leadAgentId,
            archivedAt: project.archivedAt,
            updatedAt: project.updatedAt,
          });
        }
        return visible;
      }, true, true);
      if (requestedProjectId && summaries.length === 0) throw new ToolGatewayHttpError(404,
        "Project not found", "project_not_found");
      const data = tool.name === "paperclip-self:get_project_context" ? summaries[0] : { projects: summaries };
      return { content: JSON.stringify(data), data };
    }

    if (tool.name === "paperclip-self:propose_foundation_change") {
      if (!session.agentId || !session.runId) throw new ToolGatewayHttpError(403,"Foundation authoring requires a current Agent run","foundation_authoring_run_required");
      try {
        const data=await foundationAuthoringToolsService(db).propose({companyId:session.companyId,agentId:session.agentId,runId:session.runId},parameters);
        return {content:JSON.stringify(data),data};
      } catch(error) {
        if(error instanceof HttpError)throw new ToolGatewayHttpError(error.status,error.message,"foundation_authoring_rejected");
        throw error;
      }
    }

    if (tool.name === "paperclip-self:propose_notification_preferences") {
      if(!session.agentId||!session.runId)throw new ToolGatewayHttpError(403,"Notification proposals require a current Agent run","notification_proposal_run_required");
      try {
        const data=await notificationPreferenceProposalService(db).propose({companyId:session.companyId,agentId:session.agentId,runId:session.runId},parameters);
        return {content:JSON.stringify(data),data};
      }catch(error){
        if(error instanceof HttpError)throw new ToolGatewayHttpError(error.status,error.message,"notification_proposal_rejected");
        throw error;
      }
    }

    if (tool.name === "paperclip-self:list_agent_setup_capabilities") {
      if (!session.agentId || !session.runId) throw new ToolGatewayHttpError(403, "Capability discovery requires a current Agent conversation", "agent_setup_run_required");
      try {
        const data = await agentSetupAuthoringToolsService(db).catalog({ companyId: session.companyId,
          agentId: session.agentId, runId: session.runId }, parameters);
        return { content: JSON.stringify(data), data };
      } catch (error) {
        if (error instanceof HttpError) throw new ToolGatewayHttpError(error.status, error.message, "agent_setup_rejected");
        throw error;
      }
    }

    if (tool.name === "paperclip-self:create_agent_setup_draft") {
      if (!session.agentId || !session.runId) throw new ToolGatewayHttpError(403, "Agent setup proposals require a current Agent run", "agent_setup_run_required");
      try {
        const data = await agentSetupAuthoringToolsService(db).create({ companyId: session.companyId,
          agentId: session.agentId, runId: session.runId }, parameters);
        return { content: JSON.stringify(data), data };
      } catch (error) {
        if (error instanceof HttpError) throw new ToolGatewayHttpError(error.status, error.message, "agent_setup_rejected");
        throw error;
      }
    }

    if (tool.name === "paperclip-self:create_routine_draft") {
      if (!session.agentId || !session.runId) throw new ToolGatewayHttpError(403, "Routine authoring requires a current Agent run", "routine_authoring_run_required");
      try {
        const data = await routineAuthoringToolsService(db).create({ companyId: session.companyId, agentId: session.agentId, runId: session.runId }, parameters);
        return { content: JSON.stringify(data), data };
      } catch (error) {
        if (error instanceof HttpError) throw new ToolGatewayHttpError(error.status, error.message, "routine_authoring_rejected");
        throw error;
      }
    }

    if (isWorkflowAuthoringSelfToolName(tool.name)) {
      if (!session.agentId || !session.runId) {
        throw new ToolGatewayHttpError(
          403,
          "Workflow authoring tools require an active agent run",
          "workflow_authoring_run_required",
        );
      }
      const flags = await selfToolFeatureFlags();
      if (!flags.workflowAuthoring) {
        throw new ToolGatewayHttpError(
          404,
          "AI workflow authoring is not enabled",
          "workflow_authoring_disabled",
        );
      }

      const authoring = workflowAuthoringToolsService(db);
      const context = {
        companyId: session.companyId,
        agentId: session.agentId,
        runId: session.runId,
        projectId: session.projectId,
      };
      try {
        const data =
          tool.name === "paperclip-self:create_workflow"
            ? await authoring.create(context, parameters)
            : tool.name === "paperclip-self:add_trigger"
              ? await authoring.addTrigger(context, parameters)
              : tool.name === "paperclip-self:add_step"
                ? await authoring.addStep(context, parameters)
                : tool.name === "paperclip-self:update_step"
                  ? await authoring.updateStep(context, parameters)
                  : tool.name === "paperclip-self:connect_steps"
                    ? await authoring.connectSteps(context, parameters)
                    : tool.name === "paperclip-self:remove_step"
                      ? await authoring.removeStep(context, parameters)
                      : tool.name === "paperclip-self:test_step"
                        ? await authoring.testStep(context, parameters)
                        : await authoring.preparePublish(context, parameters);
        return { content: JSON.stringify(data), data };
      } catch (error) {
        if (error instanceof HttpError) {
          const details =
            error.details && typeof error.details === "object"
              ? (error.details as Record<string, unknown>)
              : {};
          throw new ToolGatewayHttpError(
            error.status,
            error.message,
            typeof details.code === "string"
              ? details.code
              : "workflow_authoring_rejected",
            details,
          );
        }
        throw error;
      }
    }

    if (isMemorySelfToolName(tool.name)) {
      if (!session.agentId) {
        throw new ToolGatewayHttpError(
          403,
          "Memory tools require an agent-scoped gateway session",
          "agent_context_required",
        );
      }
      const flags = await selfToolFeatureFlags();
      const enabled =
        tool.name === "paperclip-self:share_memory"
          ? flags.sharedMemory && flags.privateMemory
          : flags.sharedMemory || flags.privateMemory;
      if (!enabled) {
        throw new ToolGatewayHttpError(
          404,
          "Memory tool is not enabled",
          "memory_tool_disabled",
        );
      }

      const authorizationActor = currentSessionMemoryActor(session);
      if (!authorizationActor) {
        throw new ToolGatewayHttpError(
          403,
          "Memory tools require the original verified Agent credential",
          "memory_agent_authority_unavailable",
        );
      }

      const memory = memoryAgentToolsService(db);
      const context = {
        companyId: session.companyId,
        agentId: session.agentId,
        runId: session.runId,
        issueId: session.issueId,
        projectId: session.projectId,
        responsibleUserId: session.responsibleUserId ?? null,
        authorizationActor,
        ...(nativeMemoryOutputCapture(scopedContext) ? {
          nativeModelOutputCapture: nativeMemoryOutputCapture(scopedContext)!,
          nativeToolInvocationId: invocationId,
        } : {}),
        allowShared: flags.sharedMemory,
        allowPrivate: flags.privateMemory,
      };

      try {
        const data =
          tool.name === "paperclip-self:recall"
            ? await memory.recall(context, parameters)
            : tool.name === "paperclip-self:remember"
              ? await memory.remember(context, parameters)
              : tool.name === "paperclip-self:correct_memory"
                ? await memory.correct(context, parameters)
                : await memory.share(context, parameters);
        return { content: JSON.stringify(data), data };
      } catch (error) {
        if (tool.name === "paperclip-self:remember" &&
            process.env.PAPERCLIP_NATIVE_SOURCE_MEMO_DIAGNOSTICS === "1" &&
            nativeRememberFailureDiagnostics < 8) {
          nativeRememberFailureDiagnostics += 1;
          const candidate = error && typeof error === "object" ? error as Record<string, unknown> : {};
          const details = candidate.details && typeof candidate.details === "object"
            ? candidate.details as Record<string, unknown> : {};
          const code = details.code ?? candidate.code;
          const frames = (typeof candidate.stack === "string" ? candidate.stack : "").split("\n").flatMap((line) => {
            const match = /server\/src\/services\/([A-Za-z0-9_./-]+\.ts):(\d+):\d+/.exec(line);
            return match ? [`${match[1]}:${match[2]}`] : [];
          }).slice(0, 5);
          const errorName = typeof candidate.name === "string" ? candidate.name : "Error";
          const safeCode = typeof code === "string" && /^(?:[a-z][a-z0-9_]{0,63}|[A-Z0-9_]{1,32})$/.test(code)
            ? code : null;
          console.error("native_managed_remember_failure", JSON.stringify({
            name: ["Error", "HttpError", "TypeError", "RangeError", "ConflictError"].includes(errorName) ? errorName : "other",
            status: typeof candidate.status === "number" ? candidate.status : null,
            code: safeCode,
            frames,
          }));
        }
        if (error instanceof HttpError) {
          const details =
            error.details && typeof error.details === "object"
              ? (error.details as Record<string, unknown>)
              : {};
          throw new ToolGatewayHttpError(
            error.status,
            error.message,
            typeof details.code === "string"
              ? details.code
              : "memory_operation_rejected",
            details,
          );
        }
        throw error;
      }
    }

    if (tool.providerType === "mcp_stdio_fixture") {
      return runtimeSupervisor.useFixtureSlot(
        {
          companyId: session.companyId,
          connectionKey: `${session.companyId}:mcp-stdio-fixture:default`,
          runId: session.runId,
          issueId: session.issueId,
          agentId: session.agentId,
        },
        async (handle) => {
          const priorUseCount = Number(handle.metadata.useCount ?? 0) || 0;
          let counter = Number(handle.metadata.counter ?? 0) || 0;
          if (tool.name === "mcp-stdio-fixture:increment_counter") {
            counter += 1;
            handle.metadata.counter = counter;
            handle.appendLog("stdout", `increment_counter counter=${counter}`);
          } else {
            handle.appendLog("stdout", `runtime_status counter=${counter}`);
          }
          const nextUseCount = priorUseCount + 1;
          return {
            content: JSON.stringify({
              slotId: handle.slot.id,
              status: handle.slot.status,
              counter,
              useCount: nextUseCount,
            }),
            data: {
              slotId: handle.slot.id,
              status: handle.slot.status,
              counter,
              useCount: nextUseCount,
              lazyStarted: priorUseCount === 0,
              reusedRuntimeSlot: priorUseCount > 0,
            },
          };
        },
      );
    }

    throw new ToolGatewayHttpError(
      404,
      `Tool "${tool.name}" not found`,
      "tool_not_found",
    );
  }

  async function revalidateFirstPartyBuiltinReplay(
    session: ToolGatewaySession,
    tool: ToolGatewayDescriptor,
    parameters: unknown,
    invocationId: string,
  ): Promise<unknown> {
    if (tool.providerType !== "paperclip_self") return undefined;
    const operation = agentNativeOperationForLegacyToolName(tool.name);
    if (!operation || !operation.mcpExposed) {
      throw new ToolGatewayHttpError(409,
        "This first-party operation is not classified for replay; refresh through its canonical workflow",
        "first_party_replay_revalidation_unavailable", { tool: tool.name });
    }
    const replayOwnerKind = RUNNER_TASK_OPERATION_BY_SELF_TOOL[tool.name]
      ? "semantic_receipt"
      : tool.risk === "read"
        ? "read_projection"
        : tool.name === "paperclip-self:create_workflow" &&
            operation.operationId === "blentera.workflow.draft.create" &&
            operation.canonicalService === "workflowAuthoringToolsService.create"
          ? "idempotent_owner"
        : operation.operationId === "blentera.support.case.request" &&
            operation.canonicalService === "customerSupportCaseService.createFromNative"
          ? "idempotent_owner"
          : null;
    if (!replayOwnerKind) {
      throw new ToolGatewayHttpError(409,
        "This first-party operation has no qualified replay owner; refresh through its canonical workflow",
        "first_party_replay_revalidation_unavailable", { operationId: operation.operationId });
    }
    const actor = currentSessionMemoryActor(session);
    if (!actor || actor.type !== "agent" || !actor.runId || !actor.onBehalfOfUserId) {
      throw new ToolGatewayHttpError(403, "Current Agent and represented Human authority is unavailable", "native_task_authority_unavailable");
    }
    await assertPlatformSkillAdmission(db, actor, blenteraPlatformContractHashes());
    const refreshed = await executeBuiltinTool(session, tool, parameters, invocationId);
    return validateToolContent({ value: refreshed, direction: "result", sensitiveMode: "redact",
      promptInjectionMode: "block" }).value;
  }

  function remoteEndpoint(config: Record<string, unknown>): string {
    const value = config.url ?? config.endpoint ?? config.remoteUrl;
    const parsed = parseRemoteHttpEndpoint(
      value,
      (message, code) => new ToolGatewayHttpError(422, message, code),
    );
    return parsed.toString();
  }

  async function resolvedRemoteEndpoint(
    session: ToolGatewaySession,
    connection: typeof toolConnections.$inferSelect,
    grant: typeof connectionGrants.$inferSelect,
  ): Promise<string> {
    const publicEndpoint = remoteEndpoint(connection.config ?? {});
    const ref = (connection.credentialRefs ?? []).find(
      (candidate) => candidate.placement === "url",
    );
    if (!ref) return publicEndpoint;
    const grantRef = grantRefForCredential(grant, ref);
    if (!grantRef) {
      throw new ToolGatewayHttpError(
        422,
        "A configured credential secret could not be resolved.",
        "mcp_remote_missing_secret",
        {
          connectionId: connection.id,
          credential: REMOTE_URL_SECRET_CONFIG_PATH,
        },
      );
    }
    const value = await resolveGrantSecretValue(
      session,
      connection,
      grant,
      grantRef,
      REMOTE_URL_SECRET_CONFIG_PATH,
    );
    if (!remoteUrlCredentialMatchesPublicUrl(publicEndpoint, value)) {
      throw new ToolGatewayHttpError(
        422,
        "The stored MCP URL credential no longer matches this connection.",
        "mcp_remote_url_credential_mismatch",
        { connectionId: connection.id },
      );
    }
    return parseRemoteHttpEndpoint(
      value,
      (message, code) => new ToolGatewayHttpError(422, message, code),
    ).toString();
  }

  function allowPrivateRemoteEndpoints() {
    return (
      options.deploymentMode !== "authenticated" ||
      options.deploymentExposure !== "public"
    );
  }

  /**
   * Guard options for every outbound call to an operator-supplied MCP endpoint.
   *
   * The private-network check no longer runs as a standalone pre-flight: it is
   * part of `guardedRemoteHttpFetch`, which keeps the approved address and dials
   * it directly. Splitting validation from dispatch is what created the
   * DNS-rebinding TOCTOU in PAP-17098.
   */
  function remoteHttpFetchOptions(): GuardedRemoteHttpFetchOptions {
    return {
      allowPrivateNetwork: allowPrivateRemoteEndpoints(),
      error: (message, code) => new ToolGatewayHttpError(422, message, code),
    };
  }

  function headerName(value: unknown): string | null {
    if (typeof value !== "string") return null;
    const trimmed = value.trim();
    if (!/^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/.test(trimmed)) return null;
    return trimmed.toLowerCase();
  }

  function headerValue(value: unknown): string | null {
    if (typeof value !== "string") return null;
    if (/[\r\n]/.test(value)) return null;
    return value;
  }

  function stringArray(value: unknown): string[] {
    if (!Array.isArray(value)) return [];
    return value.filter((entry): entry is string => typeof entry === "string");
  }

  function readHeaderPolicy(
    connection: typeof toolConnections.$inferSelect,
  ): HeaderPolicyConfig {
    const config = asRecord(connection.config) ?? {};
    const transportConfig = asRecord(connection.transportConfig) ?? {};
    const rawPolicy =
      asRecord(config.headerPolicy) ??
      asRecord(transportConfig.headerPolicy) ??
      {};
    const passthrough = asRecord(rawPolicy.passthrough) ?? {};
    const staticHeaders = rawPolicy.staticHeaders;
    const parsedStaticHeaders: Array<{ name: string; value: string }> = [];

    if (Array.isArray(staticHeaders)) {
      for (const entry of staticHeaders) {
        const record = asRecord(entry);
        const name = headerName(record?.name);
        const value = headerValue(record?.value);
        if (name && value !== null) parsedStaticHeaders.push({ name, value });
      }
    } else {
      const record = asRecord(staticHeaders);
      if (record) {
        for (const [rawName, rawValue] of Object.entries(record)) {
          const name = headerName(rawName);
          const value = headerValue(rawValue);
          if (name && value !== null) parsedStaticHeaders.push({ name, value });
        }
      }
    }

    const passthroughAllowlist = [
      ...stringArray(passthrough.allow),
      ...stringArray(passthrough.allowedHeaders),
      ...stringArray(rawPolicy.allowedPassthroughHeaders),
    ]
      .map(headerName)
      .filter((name): name is string => Boolean(name))
      .filter((name) => !isSensitivePassthroughHeader(name));

    const metadata = asRecord(rawPolicy.metadata) ?? {};
    const metadataHeaders = [
      ...stringArray(metadata.forward),
      ...stringArray(metadata.headers),
      ...stringArray(rawPolicy.forwardContextHeaders),
    ].filter(
      (value): value is HeaderPolicyConfig["metadataHeaders"][number] =>
        value === "company_id" ||
        value === "agent_id" ||
        value === "issue_id" ||
        value === "project_id" ||
        value === "run_id" ||
        value === "gateway_session_id" ||
        value === "correlation_id",
    );

    return {
      staticHeaders: parsedStaticHeaders,
      passthroughAllowlist: [...new Set(passthroughAllowlist)],
      metadataHeaders: [...new Set(metadataHeaders)],
    };
  }

  function readOnDemandToolsEnabled(
    connectionOrConfig:
      typeof toolConnections.$inferSelect | Record<string, unknown>,
  ): boolean {
    const config =
      "config" in connectionOrConfig
        ? (asRecord(connectionOrConfig.config) ?? {})
        : connectionOrConfig;
    const raw =
      asRecord(config.onDemandTools) ?? asRecord(config.loadToolsOnDemand);
    return (
      config.onDemandTools === true ||
      config.loadToolsOnDemand === true ||
      raw?.enabled === true
    );
  }

  function isOnDemandRemoteTool(tool: ToolGatewayDescriptor): boolean {
    const metadata = asRecord(tool.providerMetadata);
    return (
      tool.providerType === "mcp_remote_http" &&
      metadata?.onDemandTools === true
    );
  }

  function normalizeCallerHeaders(
    input: ExecuteGatewayToolInput["callerHeaders"],
  ): Record<string, string> {
    const headers: Record<string, string> = {};
    for (const [rawName, rawValue] of Object.entries(input ?? {})) {
      const name = headerName(rawName);
      if (!name) continue;
      const value = Array.isArray(rawValue) ? rawValue.join(", ") : rawValue;
      const normalizedValue = headerValue(value);
      if (normalizedValue !== null) headers[name] = normalizedValue;
    }
    return headers;
  }

  function metadataHeadersForSession(
    session: ToolGatewaySession,
    policy: HeaderPolicyConfig,
  ): Record<string, string> {
    const headers: Record<string, string> = {};
    const values: Record<
      HeaderPolicyConfig["metadataHeaders"][number],
      string | null
    > = {
      company_id: session.companyId,
      agent_id: session.agentId,
      issue_id: session.issueId,
      project_id: session.projectId,
      run_id: session.runId,
      gateway_session_id: session.id,
      correlation_id: randomUUID(),
    };
    for (const key of policy.metadataHeaders) {
      const value = values[key];
      if (value) headers[`x-paperclip-${key.replace(/_/g, "-")}`] = value;
    }
    return headers;
  }

  function buildRemoteHeaders(input: {
    session: ToolGatewaySession;
    connection: typeof toolConnections.$inferSelect;
    credentialHeaders: Record<string, string>;
    callerHeaders?: ExecuteGatewayToolInput["callerHeaders"];
  }): { headers: Record<string, string>; summary: HeaderPolicySummary } {
    const policy = readHeaderPolicy(input.connection);
    const caller = normalizeCallerHeaders(input.callerHeaders);
    const credentialHeaders: Record<string, string> = {};
    for (const [name, value] of Object.entries(input.credentialHeaders)) {
      const normalized = headerName(name);
      if (normalized) credentialHeaders[normalized] = value;
    }
    const reservedHeaders = new Set([
      "accept",
      "content-type",
      "content-length",
      "host",
      "connection",
    ]);
    const managedCredentialHeaders = new Set(Object.keys(credentialHeaders));
    const headers: Record<string, string> = {};
    const summary: HeaderPolicySummary = {
      staticHeaderNames: [],
      credentialHeaderNames: Object.keys(credentialHeaders).sort(),
      passthroughHeaderNames: [],
      droppedPassthroughHeaderNames: [],
      metadataHeaderNames: [],
      collisionRules: [],
    };

    for (const [name, value] of Object.entries(caller)) {
      if (reservedHeaders.has(name)) {
        summary.droppedPassthroughHeaderNames.push(name);
        summary.collisionRules.push({
          header: name,
          source: "caller",
          action: "dropped_reserved_header",
        });
        continue;
      }
      if (managedCredentialHeaders.has(name)) {
        summary.droppedPassthroughHeaderNames.push(name);
        summary.collisionRules.push({
          header: name,
          source: "caller",
          action: "kept_managed_credential",
        });
        continue;
      }
      if (isSensitivePassthroughHeader(name)) {
        summary.droppedPassthroughHeaderNames.push(name);
        summary.collisionRules.push({
          header: name,
          source: "caller",
          action: "dropped_sensitive_header",
        });
        continue;
      }
      if (!policy.passthroughAllowlist.includes(name)) {
        summary.droppedPassthroughHeaderNames.push(name);
        continue;
      }
      headers[name] = value;
      summary.passthroughHeaderNames.push(name);
    }

    for (const { name, value } of policy.staticHeaders) {
      if (reservedHeaders.has(name)) {
        summary.collisionRules.push({
          header: name,
          source: "static",
          action: "dropped_reserved_header",
        });
        continue;
      }
      if (managedCredentialHeaders.has(name)) {
        summary.collisionRules.push({
          header: name,
          source: "static",
          action: "kept_managed_credential",
        });
        continue;
      }
      if (headers[name] !== undefined) {
        summary.collisionRules.push({
          header: name,
          source: "static",
          action: "overrode_passthrough",
        });
      }
      headers[name] = value;
      summary.staticHeaderNames.push(name);
    }

    const metadataHeaders = metadataHeadersForSession(input.session, policy);
    for (const [name, value] of Object.entries(metadataHeaders)) {
      if (reservedHeaders.has(name)) continue;
      if (managedCredentialHeaders.has(name)) {
        summary.collisionRules.push({
          header: name,
          source: "metadata",
          action: "kept_managed_credential",
        });
        continue;
      }
      if (headers[name] !== undefined) {
        summary.collisionRules.push({
          header: name,
          source: "metadata",
          action: "overrode_previous_header",
        });
      }
      headers[name] = value;
      summary.metadataHeaderNames.push(name);
    }

    for (const [name, value] of Object.entries(credentialHeaders)) {
      if (headers[name] !== undefined) {
        summary.collisionRules.push({
          header: name,
          source: "credential",
          action: "overrode_previous_header",
        });
      }
      headers[name] = value;
    }

    summary.staticHeaderNames.sort();
    summary.passthroughHeaderNames.sort();
    summary.droppedPassthroughHeaderNames = [
      ...new Set(summary.droppedPassthroughHeaderNames),
    ].sort();
    summary.metadataHeaderNames.sort();
    return { headers, summary };
  }

  async function markRemoteConnectionHealth(
    connection: typeof toolConnections.$inferSelect,
    status: "ok" | "error" | "missing_secret" | "degraded",
    message: string | null,
  ) {
    const now = new Date();
    await db
      .update(toolConnections)
      .set({
        healthStatus: status,
        healthMessage: message,
        healthCheckedAt: now,
        lastHealthAt: now,
        lastError: status === "ok" ? null : message,
        updatedAt: now,
      })
      .where(eq(toolConnections.id, connection.id));
  }

  function grantRefForCredential(
    grant: typeof connectionGrants.$inferSelect,
    ref: McpConnectionCredentialRef,
  ): ToolCredentialSecretRef | undefined {
    return grant.credentialSecretRefs.find(
      (candidate) =>
        candidate.configPath === ref.name ||
        candidate.configPath === `credentials.${ref.name}`,
    );
  }

  async function resolveGrantSecretValue(
    session: ToolGatewaySession,
    connection: typeof toolConnections.$inferSelect,
    grant: typeof connectionGrants.$inferSelect,
    ref: ToolCredentialSecretRef,
    configPath = ref.configPath,
  ): Promise<string> {
    const accessContext = {
      consumerType: "tool_connection" as const,
      consumerId: connection.id,
      configPath,
      actorType: "system" as const,
      actorId: session.agentId,
      responsibleUserId: grant.subjectUserId,
      issueId: session.issueId,
      heartbeatRunId: session.runId,
    };
    if (grant.kind !== "user") {
      return secrets.resolveSecretValue(
        connection.companyId,
        ref.secretId,
        ref.versionSelector ?? "latest",
        { accessContext },
      );
    }
    if (!grant.subjectUserId) {
      throw new ToolGatewayHttpError(
        422,
        "Personal authorization has no owner",
        "grant_owner_missing",
        {
          connectionId: connection.id,
          grantId: grant.id,
        },
      );
    }
    const [secret] = await db
      .select({
        scope: companySecrets.scope,
        ownerUserId: companySecrets.ownerUserId,
        userSecretDefinitionId: companySecrets.userSecretDefinitionId,
      })
      .from(companySecrets)
      .where(
        and(
          eq(companySecrets.id, ref.secretId),
          eq(companySecrets.companyId, connection.companyId),
        ),
      )
      .limit(1);
    if (
      !secret ||
      secret.scope !== "user" ||
      secret.ownerUserId !== grant.subjectUserId ||
      !secret.userSecretDefinitionId
    ) {
      throw new ToolGatewayHttpError(
        422,
        "Personal authorization has an invalid credential",
        "grant_credential_invalid",
        {
          connectionId: connection.id,
          grantId: grant.id,
          credential: configPath,
        },
      );
    }
    const resolved = await secrets.resolveUserSecretValue(
      connection.companyId,
      {
        definitionId: secret.userSecretDefinitionId,
        responsibleUserId: grant.subjectUserId,
        version: ref.versionSelector ?? "latest",
        required: ref.required ?? true,
      },
      accessContext,
    );
    if (!resolved) {
      throw new ToolGatewayHttpError(
        422,
        "Personal credential is not configured",
        "user_secret_missing",
        {
          connectionId: connection.id,
          grantId: grant.id,
          credential: configPath,
        },
      );
    }
    return resolved.value;
  }

  async function maybeRefreshPaperclipCloudGrant(
    session: ToolGatewaySession,
    connection: typeof toolConnections.$inferSelect,
    grant: typeof connectionGrants.$inferSelect,
    forceRefresh = false,
  ): Promise<typeof connectionGrants.$inferSelect> {
    const oauth = asRecord(asRecord(connection.config)?.oauth);
    if (!oauth || !isPaperclipCloudConnectorStrategy(oauth.strategy))
      return grant;
    const configuredProfile = oauth.connectorProfile;
    const connectorProfile:
      GoogleWorkspaceConnectorProfileId | GitHubConnectorProfileId =
      configuredProfile === undefined
        ? "gmail.draft"
        : typeof configuredProfile === "string" &&
            (isGoogleWorkspaceConnectorProfileId(configuredProfile) ||
              isGitHubConnectorProfileId(configuredProfile))
          ? configuredProfile
          : (() => {
              throw new ToolGatewayHttpError(
                422,
                "Managed authorization has an invalid connector profile",
                "connector_profile_invalid",
                {
                  connectionId: connection.id,
                  grantId: grant.id,
                },
              );
            })();
    const connectorSubject =
      typeof oauth.connectorSubjectAgentId === "string"
        ? `agent:${oauth.connectorSubjectAgentId}`
        : typeof oauth.connectorSubjectUserId === "string"
          ? oauth.connectorSubjectUserId
          : grant.kind === "agent" && grant.subjectAgentId
            ? `agent:${grant.subjectAgentId}`
            : grant.subjectUserId;
    const grantOauth = asRecord(asRecord(grant.providerTenant)?.oauth);
    const expiresAt =
      typeof grantOauth?.accessTokenExpiresAt === "string"
        ? Date.parse(grantOauth.accessTokenExpiresAt)
        : Number.NaN;
    const currentTime = options.now?.() ?? Date.now();
    // The preferred GitHub App policy yields a non-expiring ghu_ token and no
    // refresh token. Absence of an expiry is deliberate, not an invitation to
    // enter the rotation path.
    if (
      grantOauth?.accessTokenExpiresAt === null ||
      grantOauth?.accessTokenExpiresAt === undefined
    )
      return grant;
    const refreshedAt =
      typeof grantOauth.refreshedAt === "string"
        ? Date.parse(grantOauth.refreshedAt)
        : Number.NaN;
    const rotationDue =
      !Number.isFinite(refreshedAt) ||
      refreshedAt <= currentTime - 30 * 24 * 60 * 60_000;
    if (
      !forceRefresh &&
      Number.isFinite(expiresAt) &&
      expiresAt > currentTime + 60 * 60_000 &&
      !rotationDue
    )
      return grant;
    if (oauth.strategy === "paperclip_id_connector") {
      // Paperclip ID used different endpoints, signing metadata, envelope
      // purposes, and a different Google client. Its refresh token cannot be
      // exchanged through Paperclip Cloud. Let an unexpired access token finish
      // its useful life, then require an explicit managed-connector enrollment
      // and provider reconnect instead of sending it to the wrong client.
      await db
        .update(connectionGrants)
        .set({
          status: "needs_reauthorization",
          updatedAt: new Date(currentTime),
        })
        .where(eq(connectionGrants.id, grant.id));
      throw new ToolGatewayHttpError(
        409,
        "Legacy authorization must be reconnected through Paperclip Cloud",
        "connector_reauthorization_required",
        {
          connectionId: connection.id,
          grantId: grant.id,
        },
      );
    }
    const existingFlight = gmailRefreshFlights.get(grant.id);
    if (existingFlight) return existingFlight;
    const refresh = (async () => {
      const cloudConnector = currentCloudConnector();
      if (!cloudConnector || !connectorSubject) {
        await db
          .update(connectionGrants)
          .set({
            status: "needs_reauthorization",
            updatedAt: new Date(currentTime),
          })
          .where(eq(connectionGrants.id, grant.id));
        throw new ToolGatewayHttpError(
          409,
          "Managed authorization must be reconnected",
          "connector_reauthorization_required",
          {
            connectionId: connection.id,
            grantId: grant.id,
          },
        );
      }
      const accessRef = grant.credentialSecretRefs.find(
        (ref) => ref.configPath === "oauth.access_token",
      );
      const refreshRef = grant.credentialSecretRefs.find(
        (ref) => ref.configPath === "oauth.refresh_token",
      );
      if (!accessRef || !refreshRef) {
        await db
          .update(connectionGrants)
          .set({
            status: "needs_reauthorization",
            updatedAt: new Date(currentTime),
          })
          .where(eq(connectionGrants.id, grant.id));
        throw new ToolGatewayHttpError(
          409,
          "Managed authorization must be reconnected",
          "connector_reauthorization_required",
          {
            connectionId: connection.id,
            grantId: grant.id,
          },
        );
      }
      const refreshToken = await resolveGrantSecretValue(
        session,
        connection,
        grant,
        refreshRef,
      );
      try {
        const credentials = await cloudConnector.refresh({
          subject: connectorSubject,
          companyId: connection.companyId,
          profile: connectorProfile,
          refreshToken,
        });
        await secrets.rotate(accessRef.secretId, {
          value: credentials.accessToken,
        });
        if (credentials.refreshToken) {
          await secrets.rotate(refreshRef.secretId, {
            value: credentials.refreshToken,
          });
        }
        const providerTenant = {
          ...(grant.providerTenant ?? {}),
          oauth: {
            ...(grant.providerTenant?.oauth ?? {}),
            strategy: "paperclip_cloud_connector",
            accessTokenExpiresAt: credentials.accessTokenExpiresAt,
            scopes: credentials.scopes,
            tokenType: credentials.tokenType,
            refreshedAt: new Date(options.now?.() ?? Date.now()).toISOString(),
            ...(credentials.refreshTokenExpiresAt
              ? { refreshTokenExpiresAt: credentials.refreshTokenExpiresAt }
              : {}),
          },
        };
        const [updated] = await db
          .update(connectionGrants)
          .set({
            providerTenant,
            updatedAt: new Date(options.now?.() ?? Date.now()),
          })
          .where(
            and(
              eq(connectionGrants.id, grant.id),
              eq(connectionGrants.status, "active"),
            ),
          )
          .returning();
        if (!updated) {
          throw new ToolGatewayHttpError(
            409,
            "Managed authorization is no longer active",
            "connector_reauthorization_required",
            {
              connectionId: connection.id,
              grantId: grant.id,
            },
          );
        }
        return updated;
      } catch (error) {
        if (error instanceof ToolGatewayHttpError) throw error;
        if (
          error instanceof PaperclipCloudConnectorError &&
          error.code === "REAUTHORIZATION_REQUIRED"
        ) {
          await db
            .update(connectionGrants)
            .set({
              status: "needs_reauthorization",
              updatedAt: new Date(options.now?.() ?? Date.now()),
            })
            .where(eq(connectionGrants.id, grant.id));
          throw new ToolGatewayHttpError(
            409,
            "Managed authorization must be reconnected",
            "connector_reauthorization_required",
            {
              connectionId: connection.id,
              grantId: grant.id,
            },
          );
        }
        throw new ToolGatewayHttpError(
          502,
          "Managed authorization could not be refreshed",
          "connector_refresh_failed",
          {
            connectionId: connection.id,
            grantId: grant.id,
          },
        );
      }
    })();
    gmailRefreshFlights.set(grant.id, refresh);
    try {
      return await refresh;
    } finally {
      if (gmailRefreshFlights.get(grant.id) === refresh)
        gmailRefreshFlights.delete(grant.id);
    }
  }

  async function resolveCredentialHeaders(
    session: ToolGatewaySession,
    connection: typeof toolConnections.$inferSelect,
    grant: typeof connectionGrants.$inferSelect,
    resolveOptions: { forceRefresh?: boolean } = {},
  ): Promise<Record<string, string>> {
    const tracked =
      session.identityContextId &&
      (connection.config.sourceTemplateKey === "github" ||
        connection.transportConfig?.sourceTemplateKey === "github");
    try {
      const captured = githubOperationCredentials.get(session);
      const headers =
        !resolveOptions.forceRefresh && captured?.grant.id === grant.id
          ? captured.headers
          : await resolveCredentialHeadersUnrecorded(
              session,
              connection,
              grant,
              resolveOptions,
            );
      if (tracked)
        await db
          .update(runIdentityContexts)
          .set({
            github: {
              status: "available",
              login: grant.providerTenant?.github?.login,
              source: grant.kind === "agent" ? "dedicated" : "personal",
              connectionId: connection.id,
              grantId: grant.id,
              authenticationMode: "managed",
            },
          })
          .where(
            and(
              eq(runIdentityContexts.id, session.identityContextId!),
              eq(runIdentityContexts.companyId, session.companyId),
            ),
          );
      return headers;
    } catch (error) {
      if (tracked)
        await db
          .update(runIdentityContexts)
          .set({
            github: {
              status: "unavailable",
              reason: "GitHub authorization is unavailable",
              source: grant.kind === "agent" ? "dedicated" : "personal",
            },
          })
          .where(
            and(
              eq(runIdentityContexts.id, session.identityContextId!),
              eq(runIdentityContexts.companyId, session.companyId),
            ),
          );
      throw error;
    }
  }

  async function resolveCredentialHeadersUnrecorded(
    session: ToolGatewaySession,
    connection: typeof toolConnections.$inferSelect,
    grant: typeof connectionGrants.$inferSelect,
    resolveOptions: { forceRefresh?: boolean } = {},
  ): Promise<Record<string, string>> {
    if (connection.credentialSource === "vercel_connect") {
      if (!connection.externalCredential || !vercelConnect) {
        throw new ToolGatewayHttpError(
          503,
          "Vercel Connect is not configured",
          "vercel_connect_unavailable",
          {
            connectionId: connection.id,
            grantId: grant.id,
          },
        );
      }
      const request = vercelTokenRequest({
        credential: connection.externalCredential,
        grant,
        connectionId: connection.id,
        companyId: connection.companyId,
      });
      try {
        const token = await vercelConnect.getToken(request, resolveOptions);
        if (
          token.connector.id !== connection.externalCredential.connectorId &&
          token.connector.uid !== connection.externalCredential.connectorUid
        ) {
          throw new VercelConnectClientError(
            "vercel_connect_request_failed",
            502,
          );
        }
        const [updatedGrant] = await db
          .update(connectionGrants)
          .set({
            externalCredential: vercelGrantReference({
              credential: connection.externalCredential,
              token,
              subjectId: grant.externalCredential?.subjectId,
              verifiedAt: new Date(options.now?.() ?? Date.now()),
            }),
            updatedAt: new Date(options.now?.() ?? Date.now()),
          })
          .where(
            and(
              eq(connectionGrants.id, grant.id),
              eq(connectionGrants.companyId, connection.companyId),
              eq(connectionGrants.connectionId, connection.id),
              eq(connectionGrants.status, "active"),
              isNull(connectionGrants.revokedAt),
            ),
          ).returning({ id: connectionGrants.id });
        if (!updatedGrant) throw new ToolGatewayHttpError(403,
          "Connection authorization changed during token resolution", "credential_grant_changed");
        return {
          [connection.externalCredential.headerName]:
            `${connection.externalCredential.headerPrefix ?? ""}${token.token}`,
        };
      } catch (error) {
        if (error instanceof ToolGatewayHttpError) throw error;
        if (
          error instanceof VercelConnectClientError &&
          error.code === "vercel_connect_authorization_required"
        ) {
          await db
            .update(connectionGrants)
            .set({
              status: "needs_reauthorization",
              updatedAt: new Date(options.now?.() ?? Date.now()),
            })
            .where(
              and(
                eq(connectionGrants.id, grant.id),
                eq(connectionGrants.companyId, connection.companyId),
                eq(connectionGrants.status, "active"),
                isNull(connectionGrants.revokedAt),
              ),
            );
          const responsibleUserId =
            grant.kind === "user"
              ? grant.subjectUserId
              : session.responsibleUserId;
          if (responsibleUserId) {
            await createUserAuthorizationInteraction(
              session,
              connection,
              responsibleUserId,
              grant.kind === "user" ? "user" : "organization",
            );
          }
        }
        const code =
          error instanceof VercelConnectClientError
            ? error.code
            : "vercel_connect_request_failed";
        const status =
          error instanceof VercelConnectClientError ? error.status : 502;
        const message =
          error instanceof VercelConnectClientError
            ? error.message
            : "Vercel Connect could not resolve this credential.";
        await markRemoteConnectionHealth(
          connection,
          code === "vercel_connect_unavailable" ||
            code === "vercel_connect_auth_failed" ||
            code === "vercel_connect_installation_required"
            ? "degraded"
            : "error",
          message,
        );
        throw new ToolGatewayHttpError(status, message, code, {
          connectionId: connection.id,
          grantId: grant.id,
        });
      }
    }
    const oauth = asRecord(asRecord(connection.config)?.oauth);
    if (
      isPaperclipCloudConnectorStrategy(oauth?.strategy) &&
      !options.oauthGrantRefresher
    ) {
      // Compatibility fallback for isolated service consumers. The production
      // app supplies tool-access's lease/CAS refresher below.
      grant = await maybeRefreshPaperclipCloudGrant(
        session,
        connection,
        grant,
        resolveOptions.forceRefresh === true,
      );
    }
    if (
      connection.authKind === "oauth" &&
      connection.credentialSource === "paperclip_vault" &&
      options.oauthGrantRefresher
    ) {
      try {
        grant = await options.oauthGrantRefresher({
          companyId: connection.companyId,
          connectionId: connection.id,
          grantId: grant.id,
          forceRefresh: resolveOptions.forceRefresh,
          actor: {
            actorType:
              session.actorType ?? (session.agentId ? "agent" : "system"),
            actorId: session.actorId ?? session.agentId,
          },
          issueId: session.issueId,
          heartbeatRunId: session.runId,
        });
      } catch (error) {
        if (error instanceof ToolGatewayHttpError) throw error;
        const record = asRecord(error);
        const details = asRecord(record?.details) ?? {};
        const status = typeof record?.status === "number" ? record.status : 502;
        const reasonCode =
          typeof details.code === "string"
            ? details.code
            : "oauth_refresh_failed";
        const message =
          error instanceof Error
            ? error.message
            : "OAuth authorization could not be refreshed";
        throw new ToolGatewayHttpError(status, message, reasonCode, {
          ...details,
          connectionId: connection.id,
          grantId: grant.id,
        });
      }
    }
    const headers: Record<string, string> = {};
    for (const ref of connection.credentialRefs ?? []) {
      if (ref.placement !== "header") continue;
      const grantRef = grantRefForCredential(grant, ref);
      if (!grantRef) continue;
      try {
        const value = await resolveGrantSecretValue(
          session,
          connection,
          grant,
          grantRef,
          // Personal grants resolve against their declared vault path. API-key
          // paths already include credentials.* or headers.*; prepending again
          // breaks the declaration just as it does for OAuth token paths.
          grant.kind === "user" || grantRef.configPath.startsWith("oauth.")
            ? grantRef.configPath
            : `credentials.${ref.name}`,
        );
        headers[ref.key] = `${ref.prefix ?? ""}${value}`;
      } catch {
        await markRemoteConnectionHealth(
          connection,
          "missing_secret",
          "A configured credential secret could not be resolved.",
        );
        throw new ToolGatewayHttpError(
          422,
          "A configured credential secret could not be resolved.",
          "mcp_remote_missing_secret",
          { connectionId: connection.id, credential: ref.name },
        );
      }
    }
    const oauthAccessRef = grant.credentialSecretRefs.find(
      (ref) => ref.configPath === "oauth.access_token",
    );
    if (oauthAccessRef && headers.Authorization === undefined) {
      try {
        const value = await resolveGrantSecretValue(
          session,
          connection,
          grant,
          oauthAccessRef,
        );
        headers.Authorization = `Bearer ${value}`;
      } catch {
        await markRemoteConnectionHealth(
          connection,
          "missing_secret",
          "A configured credential secret could not be resolved.",
        );
        throw new ToolGatewayHttpError(
          422,
          "A configured credential secret could not be resolved.",
          "mcp_remote_missing_secret",
          {
            connectionId: connection.id,
            credential: oauthAccessRef.configPath,
          },
        );
      }
    }
    return headers;
  }

  function credentialVersionRefHash(value: Record<string, unknown>): string {
    return stableHash(value);
  }

  async function resolveConnectedCredentialVersion(
    connection: typeof toolConnections.$inferSelect,
    input: {
      secretId: string;
      versionSelector: SecretVersionSelector | undefined;
      configPath: string;
      refHash: string;
      requireResolved: boolean;
    },
  ): Promise<ConnectedCredentialVersionSnapshot> {
    const versionSelector = input.versionSelector ?? "latest";
    try {
      const resolvedVersion = await secrets.resolveSecretVersion(
        connection.companyId,
        input.secretId,
        versionSelector,
      );
      return {
        refHash: input.refHash,
        versionSelector: String(versionSelector),
        resolvedVersion,
      };
    } catch {
      await markRemoteConnectionHealth(
        connection,
        "missing_secret",
        "A configured credential secret could not be resolved.",
      );
      if (input.requireResolved) {
        throw new ToolGatewayHttpError(
          422,
          "A configured credential secret could not be resolved.",
          "mcp_remote_missing_secret",
          { connectionId: connection.id, credential: input.configPath },
        );
      }
      return {
        refHash: input.refHash,
        versionSelector: String(versionSelector),
        resolvedVersion: -1,
      };
    }
  }

  async function connectedCredentialVersionSnapshots(
    connection: typeof toolConnections.$inferSelect,
    grant: typeof connectionGrants.$inferSelect,
    options: { requireResolved: boolean },
  ): Promise<{
    headerCredentialVersions: ConnectedCredentialVersionSnapshot[];
    credentialSecretVersions: ConnectedCredentialVersionSnapshot[];
  }> {
    const headerCredentialVersions: ConnectedCredentialVersionSnapshot[] = [];
    const credentialSecretVersions: ConnectedCredentialVersionSnapshot[] = [];

    for (const ref of connection.credentialRefs ?? []) {
      if (ref.placement !== "header" && ref.placement !== "url") continue;
      const typedRef = ref as McpConnectionCredentialRef;
      const grantRef = grantRefForCredential(grant, typedRef);
      if (!grantRef) continue;
      const configPath =
        typedRef.placement === "url"
          ? REMOTE_URL_SECRET_CONFIG_PATH
          : `credentials.${typedRef.name}`;
      headerCredentialVersions.push(
        await resolveConnectedCredentialVersion(connection, {
          secretId: grantRef.secretId,
          versionSelector: grantRef.versionSelector,
          configPath,
          refHash: credentialVersionRefHash({
            kind: typedRef.placement === "url" ? "url" : "header",
            name: typedRef.name,
            secretId: grantRef.secretId,
            placement: typedRef.placement,
            key: typedRef.key,
            prefix: typedRef.prefix ?? null,
            configPath,
          }),
          requireResolved: options.requireResolved,
        }),
      );
    }

    for (const ref of grant.credentialSecretRefs ?? []) {
      const typedRef = ref as ToolCredentialSecretRef;
      credentialSecretVersions.push(
        await resolveConnectedCredentialVersion(connection, {
          secretId: typedRef.secretId,
          versionSelector: typedRef.versionSelector,
          configPath: typedRef.configPath,
          refHash: credentialVersionRefHash({
            kind: "secret_ref",
            secretId: typedRef.secretId,
            configPath: typedRef.configPath,
            required: typedRef.required ?? true,
            label: typedRef.label ?? null,
          }),
          requireResolved: options.requireResolved,
        }),
      );
    }

    return { headerCredentialVersions, credentialSecretVersions };
  }

  async function createUserAuthorizationInteraction(
    session: ToolGatewaySession,
    connection: typeof toolConnections.$inferSelect,
    userId: string,
    grantKind: "organization" | "user" = "user",
  ) {
    if (!session.issueId || !session.agentId || !session.runId) return;
    const [company] = await db
      .select({ issuePrefix: companies.issuePrefix })
      .from(companies)
      .where(eq(companies.id, session.companyId))
      .limit(1);
    const href = `/${company?.issuePrefix ?? ""}/apps/${connection.id}/permissions`;
    const idempotencyKey = `connection-authorization:${connection.id}:${userId}`;
    const payload = {
      version: 1 as const,
      prompt:
        grantKind === "organization"
          ? `Reconnect the ${connection.name} organization identity to continue`
          : `Connect your ${connection.name} account to continue`,
      acceptLabel:
        grantKind === "organization"
          ? "Reconnect organization"
          : "Connect account",
      rejectLabel: "Not now",
      detailsMarkdown:
        grantKind === "organization"
          ? "Vercel Connect reports that the shared organization identity needs authorization."
          : "This run needs your personal authorization. Paperclip will not use another user's identity.",
      target: {
        type: "custom" as const,
        key: `connection:${connection.uid}:user:${userId}`,
        revisionId: connection.updatedAt.toISOString(),
        label: `Connect ${connection.name}`,
        href,
      },
    };
    const [existing] = await db
      .select({ id: issueThreadInteractions.id })
      .from(issueThreadInteractions)
      .where(
        and(
          eq(issueThreadInteractions.companyId, session.companyId),
          eq(issueThreadInteractions.issueId, session.issueId),
          eq(issueThreadInteractions.idempotencyKey, idempotencyKey),
        ),
      )
      .limit(1);
    if (existing) {
      await db
        .update(issueThreadInteractions)
        .set({
          status: "pending",
          continuationPolicy: "wake_assignee",
          requestedResolverPolicy: "human_only",
          effectiveResolverPolicy: "human_only",
          resolverPolicyProvenance: "explicit",
          effectiveResolverPolicySource: "requested",
          addresseeUserId: userId,
          payload,
          result: null,
          resolvedAt: null,
          updatedAt: new Date(),
        })
        .where(eq(issueThreadInteractions.id, existing.id));
      return;
    }
    await db.insert(issueThreadInteractions).values({
      companyId: session.companyId,
      issueId: session.issueId,
      kind: "request_confirmation",
      status: "pending",
      continuationPolicy: "wake_assignee",
      requestedResolverPolicy: "human_only",
      effectiveResolverPolicy: "human_only",
      resolverPolicyProvenance: "explicit",
      effectiveResolverPolicySource: "requested",
      idempotencyKey,
      sourceRunId: session.runId,
      title:
        grantKind === "organization"
          ? `Reconnect ${connection.name}`
          : `Connect your ${connection.name}`,
      summary:
        grantKind === "organization"
          ? "Organization authorization is required before this run can continue."
          : "Personal authorization is required before this run can continue.",
      createdByAgentId: session.agentId,
      addresseeUserId: userId,
      payload,
    });
  }

  async function resolveConnectionGrant(
    session: ToolGatewaySession,
    connection: typeof toolConnections.$inferSelect,
  ): Promise<typeof connectionGrants.$inferSelect> {
    const [run] =
      session.runId && !session.identityContextId
        ? await db
            .select({
              responsibleUserId: heartbeatRuns.responsibleUserId,
              invocationSource: heartbeatRuns.invocationSource,
            })
            .from(heartbeatRuns)
            .where(
              and(
                eq(heartbeatRuns.id, session.runId),
                eq(heartbeatRuns.companyId, session.companyId),
              ),
            )
            .limit(1)
        : [];
    const actingUserId = session.identityContextId
      ? (session.responsibleUserId ?? null)
      : (run?.responsibleUserId ?? session.responsibleUserId ?? null);
    if (
      session.identityContextId &&
      session.agentId &&
      (connection.config.sourceTemplateKey === "github" ||
        connection.transportConfig?.sourceTemplateKey === "github")
    ) {
      const captured = githubOperationCredentials.get(session);
      const selected = captured
        ? { grant: captured.grant, error: undefined }
        : await resolveManagedGitHubIdentitySelection(db, session.companyId, {
            agentId: session.agentId,
            responsibleUserId: session.responsibleUserId,
            allowStandingDelegation: false,
          });
      if (!selected.grant || selected.grant.connectionId !== connection.id) {
        throw new ToolGatewayHttpError(
          409,
          selected.error ??
            "GitHub identity changed; retry through the managed tool",
          "github_identity_unavailable",
        );
      }
      if (selected.grant.kind === "user") {
        const [member] = await db
          .select({ role: companyMemberships.membershipRole })
          .from(companyMemberships)
          .where(
            and(
              eq(companyMemberships.companyId, session.companyId),
              eq(companyMemberships.principalType, "user"),
              eq(companyMemberships.principalId, selected.grant.subjectUserId!),
              eq(companyMemberships.status, "active"),
            ),
          )
          .limit(1);
        if (!member || member.role === "viewer") {
          throw new ToolGatewayHttpError(
            403,
            "The personal grant owner is not an authorized company member",
            "grant_owner_membership_inactive",
          );
        }
      }
      // Managed GitHub selection is final: a legacy shared policy cannot replace
      // the captured person's grant with an organization or teammate's account.
      return selected.grant;
    }
    const autonomous =
      !session.identityContextId &&
      (run?.invocationSource === "automation" ||
        run?.invocationSource === "timer");
    const findUserGrant = async () => {
      if (!actingUserId) return undefined;
      const [membership] = await db
        .select({ id: companyMemberships.id })
        .from(companyMemberships)
        .where(
          and(
            eq(companyMemberships.companyId, connection.companyId),
            eq(companyMemberships.principalType, "user"),
            eq(companyMemberships.principalId, actingUserId),
            eq(companyMemberships.status, "active"),
          ),
        )
        .limit(1);
      if (!membership) {
        throw new ToolGatewayHttpError(
          403,
          "The personal grant owner is not an active company member",
          "grant_owner_membership_inactive",
          {
            connectionId: connection.id,
            actingUserId,
            remediation: { action: "restore_membership_or_reconnect" },
          },
        );
      }
      const [grant] = await db
        .select()
        .from(connectionGrants)
        .where(
          and(
            eq(connectionGrants.companyId, connection.companyId),
            eq(connectionGrants.connectionId, connection.id),
            eq(connectionGrants.kind, "user"),
            eq(connectionGrants.subjectUserId, actingUserId),
            eq(connectionGrants.status, "active"),
          ),
        )
        .limit(1);
      return grant;
    };
    const findOrganizationGrant = async () => {
      const [grant] = await db
        .select()
        .from(connectionGrants)
        .where(
          and(
            eq(connectionGrants.companyId, connection.companyId),
            eq(connectionGrants.connectionId, connection.id),
            eq(connectionGrants.kind, "organization"),
            eq(connectionGrants.isDefault, true),
            eq(connectionGrants.status, "active"),
          ),
        )
        .limit(1);
      if (!grant) {
        throw new ToolGatewayHttpError(
          409,
          "Organization authorization is required",
          "organization_authorization_required",
          {
            connectionId: connection.id,
          },
        );
      }
      const members = await db
        .select({ subjectId: connectionGrantMembers.subjectId })
        .from(connectionGrantMembers)
        .where(
          and(
            eq(connectionGrantMembers.companyId, connection.companyId),
            eq(connectionGrantMembers.grantId, grant.id),
            eq(connectionGrantMembers.subjectType, "user"),
          ),
        );
      const activeAudienceMember = actingUserId
        ? await db
            .select({ id: companyMemberships.id })
            .from(companyMemberships)
            .where(
              and(
                eq(companyMemberships.companyId, connection.companyId),
                eq(companyMemberships.principalType, "user"),
                eq(companyMemberships.principalId, actingUserId),
                eq(companyMemberships.status, "active"),
              ),
            )
            .limit(1)
            .then((rows) => rows[0] ?? null)
        : null;
      if (
        !isConnectionGrantAudienceAllowed(
          members.map((member) => member.subjectId),
          actingUserId,
          Boolean(activeAudienceMember),
        )
      ) {
        throw new ToolGatewayHttpError(
          403,
          "The acting user is not in this grant's audience",
          "grant_audience_denied",
          {
            connectionId: connection.id,
            grantId: grant.id,
            actingUserId,
          },
        );
      }
      return grant;
    };

    if (connection.credentialPolicy === "per_agent") {
      if (!session.agentId) {
        throw new ToolGatewayHttpError(
          409,
          "A dedicated agent authorization is required",
          "agent_authorization_required",
          {
            connectionId: connection.id,
          },
        );
      }
      const [agentGrant] = await db
        .select()
        .from(connectionGrants)
        .where(
          and(
            eq(connectionGrants.companyId, connection.companyId),
            eq(connectionGrants.connectionId, connection.id),
            eq(connectionGrants.kind, "agent"),
            eq(connectionGrants.subjectAgentId, session.agentId),
            eq(connectionGrants.status, "active"),
          ),
        )
        .limit(1);
      if (!agentGrant) {
        throw new ToolGatewayHttpError(
          409,
          "This agent's dedicated authorization is not connected",
          "agent_authorization_required",
          {
            connectionId: connection.id,
            agentId: session.agentId,
          },
        );
      }
      return agentGrant;
    }

    // The owner-selected connection install is the consent boundary for agent use.
    // `responsibleUserId` is resolved and persisted by the control plane, never
    // accepted from agent input, so a run carrying it uses that owner's grant
    // directly. Delegation is reserved for genuinely ownerless unattended runs.
    let userGrant =
      connection.credentialPolicy === "shared"
        ? undefined
        : await findUserGrant();
    if (
      !userGrant &&
      !actingUserId &&
      autonomous &&
      session.agentId &&
      connection.credentialPolicy !== "shared"
    ) {
      const delegated = await db
        .select({ grant: connectionGrants })
        .from(connectionGrantDelegations)
        .innerJoin(
          connectionGrants,
          and(
            eq(connectionGrants.id, connectionGrantDelegations.grantId),
            eq(
              connectionGrants.companyId,
              connectionGrantDelegations.companyId,
            ),
          ),
        )
        .where(
          and(
            eq(connectionGrantDelegations.companyId, connection.companyId),
            eq(connectionGrantDelegations.agentId, session.agentId),
            eq(connectionGrants.connectionId, connection.id),
            eq(connectionGrants.kind, "user"),
            eq(connectionGrants.status, "active"),
          ),
        );
      if (delegated.length > 1) {
        throw new ToolGatewayHttpError(
          409,
          "More than one delegated personal authorization matches this autonomous run",
          "ambiguous_personal_grant",
          {
            connectionId: connection.id,
            agentId: session.agentId,
          },
        );
      }
      userGrant = delegated[0]?.grant;
      if (userGrant?.subjectUserId) {
        const [membership] = await db
          .select({ id: companyMemberships.id })
          .from(companyMemberships)
          .where(
            and(
              eq(companyMemberships.companyId, connection.companyId),
              eq(companyMemberships.principalType, "user"),
              eq(companyMemberships.principalId, userGrant.subjectUserId),
              eq(companyMemberships.status, "active"),
            ),
          )
          .limit(1);
        if (!membership) {
          throw new ToolGatewayHttpError(
            403,
            "The delegated personal grant owner is not an active company member",
            "grant_owner_membership_inactive",
            {
              connectionId: connection.id,
              grantId: userGrant.id,
            },
          );
        }
      }
    }
    const resolution = userGrant
      ? "user"
      : resolveCredentialGrantKind(
          connection.credentialPolicy,
          actingUserId,
          false,
        );
    if (resolution === "user" && userGrant) return userGrant;
    if (resolution === "user_authorization_required") {
      if (actingUserId)
        await createUserAuthorizationInteraction(
          session,
          connection,
          actingUserId,
        );
      throw new ToolGatewayHttpError(
        409,
        "User authorization is required",
        "user_authorization_required",
        {
          connectionId: connection.id,
          actingUserId,
        },
      );
    }
    return findOrganizationGrant();
  }

  async function qualificationCanarySourceBindingHash(input: {
    session: ToolGatewaySession;
    connection: typeof toolConnections.$inferSelect;
    grant: typeof connectionGrants.$inferSelect;
    gateway: typeof toolMcpGateways.$inferSelect;
    tool: ToolGatewayDescriptor;
    fixtureConfig: Record<string, unknown>;
  }) {
    const endpoint = new URL(await resolvedRemoteEndpoint(input.session, input.connection, input.grant));
    const profileEntries = await db.select().from(toolProfileEntries).where(and(
      eq(toolProfileEntries.companyId, input.gateway.companyId), eq(toolProfileEntries.profileId, input.gateway.profileId),
    ));
    return nativeSha256({
      connection: {
        id: input.connection.id, applicationId: input.connection.applicationId, transport: input.connection.transport,
        status: input.connection.status, enabled: input.connection.enabled, authKind: input.connection.authKind,
        credentialSource: input.connection.credentialSource, credentialPolicy: input.connection.credentialPolicy,
        credentialRefs: input.connection.credentialRefs, credentialSecretRefs: input.connection.credentialSecretRefs,
        config: input.connection.config, transportConfig: input.connection.transportConfig,
      },
      grant: {
        id: input.grant.id, kind: input.grant.kind, subjectUserId: input.grant.subjectUserId,
        status: input.grant.status, revokedAt: input.grant.revokedAt,
        credentialSecretRefs: input.grant.credentialSecretRefs, externalCredential: input.grant.externalCredential,
      },
      endpoint: { protocol: endpoint.protocol, hostname: endpoint.hostname, port: endpoint.port, pathname: endpoint.pathname },
      gateway: { id: input.gateway.id, publicId: input.gateway.gatewayPublicId, status: input.gateway.status,
        profileId: input.gateway.profileId, profileEntries: profileEntries.map(entry => ({
          selectorType: entry.selectorType, effect: entry.effect, connectionId: entry.connectionId,
          applicationId: entry.applicationId, catalogEntryId: entry.catalogEntryId, toolName: entry.toolName,
          riskLevel: entry.riskLevel, conditions: entry.conditions,
        })).sort((a, b) => stableHash(a).localeCompare(stableHash(b))) },
      tool: { name: input.tool.name, upstreamToolName: input.tool.upstreamToolName,
        catalogEntryId: input.tool.catalogEntryId, parametersSchema: input.tool.parametersSchema,
        description: input.tool.description, risk: input.tool.risk },
      fixtureConfig: input.fixtureConfig,
    });
  }

  async function resolveConnectedRemoteTool(
    session: ToolGatewaySession,
    tool: ToolGatewayDescriptor,
  ) {
    if (
      tool.providerType !== "mcp_remote_http" ||
      !tool.connectionId ||
      !tool.catalogEntryId
    ) {
      throw new ToolGatewayHttpError(
        404,
        `Tool "${tool.name}" not found`,
        "tool_not_found",
      );
    }
    const [entry] = await db
      .select()
      .from(toolCatalogEntries)
      .where(
        and(
          eq(toolCatalogEntries.id, tool.catalogEntryId),
          eq(toolCatalogEntries.companyId, session.companyId),
        ),
      )
      .limit(1);
    if (!entry || entry.status !== "active" || entry.entryKind !== "tool") {
      throw new ToolGatewayHttpError(
        404,
        `Tool "${tool.name}" not found`,
        "tool_not_found",
      );
    }
    const [connection] = await db
      .select()
      .from(toolConnections)
      .where(
        and(
          eq(toolConnections.id, entry.connectionId),
          eq(toolConnections.companyId, session.companyId),
        ),
      )
      .limit(1);
    if (!connection || connection.transport !== "mcp_remote") {
      throw new ToolGatewayHttpError(
        404,
        `Tool "${tool.name}" not found`,
        "tool_not_found",
      );
    }
    if (isRetiredComposioConnection(connection)) {
      throw new ToolGatewayHttpError(422, RETIRED_COMPOSIO_MESSAGE, "composio_broker_retired");
    }
    if (!connection.enabled || connection.status !== "active") {
      throw new ToolGatewayHttpError(
        403,
        "Connection is disabled.",
        "mcp_remote_connection_disabled",
        {
          connectionId: connection.id,
        },
      );
    }
    if (isRailwayEndpoint(connection.config.url) && isRailwayToolBlocked(entry.toolName)) {
      throw new ToolGatewayHttpError(403, "This Railway action cannot bind its effects to an approved target. Use redeploy, restart, or rollback for an existing deployment.", "railway_action_blocked");
    }
    return { entry, connection };
  }

  async function governedToolArguments(
    session: ToolGatewaySession,
    tool: ToolGatewayDescriptor,
    parameters: unknown,
  ): Promise<unknown> {
    if (tool.providerType !== "mcp_remote_http") return parameters;
    const { connection, entry } = await resolveConnectedRemoteTool(session, tool);
    return projectedConnectionToolArguments(connection, parameters, entry.toolName);
  }

  async function approvedManagedArgumentsRemainCurrent(
    session: ToolGatewaySession,
    tool: ToolGatewayDescriptor,
    reviewedParameters: unknown,
  ): Promise<boolean> {
    const currentParameters = await governedToolArguments(
      session,
      tool,
      reviewedParameters,
    );
    return (
      stableSerialize(currentParameters) === stableSerialize(reviewedParameters)
    );
  }

  async function resolveConnectedLocalStdioTool(
    session: ToolGatewaySession,
    tool: ToolGatewayDescriptor,
  ) {
    if (
      tool.providerType !== "mcp_local_stdio" ||
      !tool.connectionId ||
      !tool.catalogEntryId
    ) {
      throw new ToolGatewayHttpError(
        404,
        `Tool "${tool.name}" not found`,
        "tool_not_found",
      );
    }
    const [entry] = await db
      .select()
      .from(toolCatalogEntries)
      .where(
        and(
          eq(toolCatalogEntries.id, tool.catalogEntryId),
          eq(toolCatalogEntries.companyId, session.companyId),
        ),
      )
      .limit(1);
    if (!entry || entry.status !== "active" || entry.entryKind !== "tool") {
      throw new ToolGatewayHttpError(
        404,
        `Tool "${tool.name}" not found`,
        "tool_not_found",
      );
    }
    const [connection] = await db
      .select()
      .from(toolConnections)
      .where(
        and(
          eq(toolConnections.id, entry.connectionId),
          eq(toolConnections.companyId, session.companyId),
        ),
      )
      .limit(1);
    if (!connection || connection.transport !== "local_stdio") {
      throw new ToolGatewayHttpError(
        404,
        `Tool "${tool.name}" not found`,
        "tool_not_found",
      );
    }
    if (isRetiredComposioConnection(connection)) {
      throw new ToolGatewayHttpError(422, RETIRED_COMPOSIO_MESSAGE, "composio_broker_retired");
    }
    if (!connection.enabled || connection.status !== "active") {
      throw new ToolGatewayHttpError(
        403,
        "Connection is disabled.",
        "local_stdio_connection_disabled",
        {
          connectionId: connection.id,
        },
      );
    }
    return { entry, connection };
  }

  function localStdioTemplateId(
    connection: typeof toolConnections.$inferSelect,
  ): string {
    const config = asRecord(connection.config) ?? {};
    const templateId = config.templateId;
    if (typeof templateId !== "string" || templateId.trim().length === 0) {
      throw new ToolGatewayHttpError(
        422,
        "Local stdio MCP connection requires an approved templateId",
        "local_stdio_template_missing",
        {
          connectionId: connection.id,
        },
      );
    }
    return templateId.trim();
  }

  async function resolveLocalStdioRuntimeTemplate(
    connection: typeof toolConnections.$inferSelect,
  ): Promise<LocalStdioRuntimeTemplate> {
    const templateId = localStdioTemplateId(connection);
    const builtIn = BUILTIN_LOCAL_STDIO_RUNTIME_TEMPLATES[templateId];
    if (builtIn) return { templateId, ...builtIn };
    const [template] = await db
      .select()
      .from(toolStdioCommandTemplates)
      .where(
        and(
          eq(toolStdioCommandTemplates.companyId, connection.companyId),
          eq(toolStdioCommandTemplates.templateKey, templateId),
        ),
      )
      .limit(1);
    if (!template || template.status !== "active") {
      throw new ToolGatewayHttpError(
        422,
        "Local stdio MCP connection requires an active approved template",
        "local_stdio_template_invalid",
        {
          connectionId: connection.id,
          templateId,
        },
      );
    }
    return {
      templateId,
      command: template.command,
      args: template.args ?? [],
      envKeys: template.envKeys ?? [],
    };
  }

  async function localStdioEnvironment(
    session: ToolGatewaySession,
    connection: typeof toolConnections.$inferSelect,
    template: LocalStdioRuntimeTemplate,
    grant: typeof connectionGrants.$inferSelect,
  ): Promise<NodeJS.ProcessEnv> {
    const env: NodeJS.ProcessEnv = {};
    for (const key of [
      "PATH",
      "Path",
      "SystemRoot",
      "WINDIR",
      "COMSPEC",
      "PATHEXT",
    ]) {
      const value = process.env[key];
      if (typeof value === "string" && value.length > 0) {
        env[key] = value;
      }
    }
    for (const key of template.envKeys) {
      const grantRef = grant.credentialSecretRefs.find(
        (ref) => ref.configPath === `env.${key}`,
      );
      if (!grantRef) continue;
      try {
        env[key] = await resolveGrantSecretValue(
          session,
          connection,
          grant,
          grantRef,
        );
      } catch {
        await markRemoteConnectionHealth(
          connection,
          "missing_secret",
          "A configured local stdio credential could not be resolved.",
        );
        throw new ToolGatewayHttpError(
          422,
          "A configured local stdio credential could not be resolved.",
          "local_stdio_missing_secret",
          { connectionId: connection.id, credential: grantRef.configPath },
        );
      }
    }
    if (template.templateId === "paperclip.cognee-cloud") {
      try { cogneeCloudUrl(env.COGNEE_BASE_URL ?? ""); }
      catch {
        throw new ToolGatewayHttpError(422, "Reconnect Cognee with the tenant API Base URL from its API Keys page.", "cognee_cloud_url_invalid");
      }
    }
    return env;
  }

  function stdioProtocolError(
    message: string,
    details: Record<string, unknown> = {},
  ) {
    return new ToolGatewayHttpError(
      502,
      message,
      "local_stdio_protocol_error",
      details,
    );
  }

  async function callLocalStdioMcp(input: {
    connection: typeof toolConnections.$inferSelect;
    entry?: typeof toolCatalogEntries.$inferSelect;
    template: LocalStdioRuntimeTemplate;
    env: NodeJS.ProcessEnv;
    parameters?: unknown;
    protocolMethod?: string;
    protocolParams?: Record<string, unknown>;
    timeoutMs: number;
    signal?: AbortSignal;
  }): Promise<unknown> {
    if (input.template.templateId === "paperclip.cognee-cloud") {
      if (input.protocolMethod === "resources/list") return { resources: [] };
      if (input.protocolMethod === "prompts/list") return { prompts: [] };
      if (input.protocolMethod && input.protocolMethod !== "tools/call") {
        throw stdioProtocolError("Cognee does not expose this context operation");
      }
      return callCogneeCloud({
        baseUrl: input.env.COGNEE_BASE_URL ?? "", apiKey: input.env.COGNEE_API_KEY ?? "",
        tool: input.entry?.toolName ?? "", parameters: asRecord(input.parameters) ?? {},
        signal: input.signal ? AbortSignal.any([input.signal, AbortSignal.timeout(input.timeoutMs)]) : AbortSignal.timeout(input.timeoutMs),
        request: async (url, init) => {
          const response = await guardedRemoteHttpFetch(url, init, remoteHttpFetchOptions());
          const body = await readBoundedRemoteResponse(response);
          if (!response.ok) throw new ToolGatewayHttpError(502,
            `Cognee Cloud request failed (HTTP ${response.status}).`, "cognee_api_error");
          if (!body) return { status: "success" };
          try { return JSON.parse(body); }
          catch { throw new ToolGatewayHttpError(502, "Cognee Cloud returned invalid JSON.", "cognee_api_error"); }
        },
      });
    }
    if (!input.template.command) {
      throw new ToolGatewayHttpError(
        501,
        "Local stdio template does not define an executable command",
        "local_stdio_command_unavailable",
        {
          connectionId: input.connection.id,
          templateId: input.template.templateId,
        },
      );
    }
    const child = spawn(input.template.command, input.template.args, {
      env: input.env,
      stdio: ["pipe", "pipe", "pipe"],
      detached: process.platform !== "win32",
    });
    let stdout = "";
    let stderr = "";
    let nextId = 1;
    const pending = new Map<
      number,
      {
        resolve: (value: unknown) => void;
        reject: (error: Error) => void;
      }
    >();
    const ownedProcess = { child, processGroupId: process.platform !== "win32" ? child.pid ?? null : null };
    let terminalError: Error | null = null;
    const stop = (error: Error) => {
      terminalError ??= error;
      signalRunningProcess(ownedProcess, "SIGTERM");
      for (const { reject } of pending.values()) reject(terminalError);
      pending.clear();
    };
    const abort = () => stop(new ToolGatewayHttpError(409, "Local stdio invocation cancelled", "tool_cancelled"));
    child.stdin.on("error", () => stop(stdioProtocolError("Local stdio request stream closed")));
    input.signal?.addEventListener("abort", abort, { once: true });
    if (input.signal?.aborted) abort();
    const timer = setTimeout(() => {
      stop(new ToolGatewayHttpError(504, "Local stdio MCP tool call timed out", "tool_timeout",
        { connectionId: input.connection.id, catalogEntryId: input.entry?.id ?? null }));
    }, input.timeoutMs);
    timer.unref?.();
    child.stdout.setEncoding("utf8");
    child.stderr.setEncoding("utf8");
    child.stdout.on("data", (chunk: string) => {
      if (terminalError) return;
      stdout += chunk;
      if (Buffer.byteLength(stdout, "utf8") > MAX_REMOTE_MCP_RESPONSE_BYTES) {
        stop(stdioProtocolError("Local stdio MCP response exceeds the size limit"));
        stdout = "";
        return;
      }
      let newline = stdout.indexOf("\n");
      while (newline >= 0) {
        const line = stdout.slice(0, newline).trim();
        stdout = stdout.slice(newline + 1);
        if (line) {
          try {
            const message = JSON.parse(line) as Record<string, unknown>;
            const id = typeof message.id === "number" ? message.id : null;
            if (id !== null && pending.has(id)) {
              const waiter = pending.get(id)!;
              pending.delete(id);
              if (message.error !== undefined) {
                waiter.reject(
                  stdioProtocolError(
                    "Local stdio MCP server returned a JSON-RPC error",
                    {
                      connectionId: input.connection.id,
                      catalogEntryId: input.entry?.id ?? null,
                      error: message.error,
                    },
                  ),
                );
              } else {
                waiter.resolve(message.result);
              }
            }
          } catch {
            for (const { reject } of pending.values()) {
              reject(
                stdioProtocolError(
                  "Local stdio MCP server returned invalid JSON",
                  {
                    connectionId: input.connection.id,
                    catalogEntryId: input.entry?.id ?? null,
                  },
                ),
              );
            }
            pending.clear();
          }
        }
        newline = stdout.indexOf("\n");
      }
    });
    child.stderr.on("data", (chunk: string) => {
      stderr = `${stderr}${chunk}`.slice(-4_000);
    });
    const exitPromise = new Promise<void>((resolve, reject) => {
      child.on("error", (error) => {
        const gatewayError = new ToolGatewayHttpError(
          502,
          "Local stdio MCP command failed to start",
          "local_stdio_spawn_failed",
          {
            connectionId: input.connection.id,
            templateId: input.template.templateId,
            message: error.message,
          },
        );
        for (const { reject: rejectPending } of pending.values()) {
          rejectPending(gatewayError);
        }
        pending.clear();
        terminalError ??= gatewayError;
        resolve();
      });
      child.on("exit", (code, signal) => {
        terminalError ??= stdioProtocolError("Local stdio process has exited", { code, signal });
        if (pending.size === 0) {
          resolve();
          return;
        }
        for (const { reject: rejectPending } of pending.values()) {
          rejectPending(
            new ToolGatewayHttpError(
              502,
              "Local stdio MCP command exited before responding",
              "local_stdio_process_exited",
              {
                connectionId: input.connection.id,
                catalogEntryId: input.entry?.id ?? null,
                code,
                signal,
                stderr,
              },
            ),
          );
        }
        pending.clear();
        resolve();
      });
    });
    const request = (method: string, params: Record<string, unknown>) => {
      if (terminalError) return Promise.reject(terminalError);
      const id = nextId;
      nextId += 1;
      const promise = new Promise<unknown>((resolve, reject) => {
        pending.set(id, { resolve, reject });
      });
      child.stdin.write(
        `${JSON.stringify({ jsonrpc: "2.0", id, method, params })}\n`,
        (error) => { if (error) stop(stdioProtocolError("Local stdio request could not be written")); },
      );
      return promise;
    };
    try {
      const initialized = await request("initialize", {
        protocolVersion: MCP_PROTOCOL_VERSION,
        capabilities: {},
        clientInfo: { name: "blentera-tool-gateway", version: "0.3.1" },
      });
      const negotiatedProtocol = asRecord(initialized)?.protocolVersion;
      if (typeof negotiatedProtocol !== "string" || !SUPPORTED_MCP_PROTOCOL_VERSIONS.has(negotiatedProtocol)) {
        throw stdioProtocolError("Local stdio MCP selected an unsupported protocol version", {
          connectionId: input.connection.id,
          catalogEntryId: input.entry?.id ?? null,
        });
      }
      child.stdin.write(
        `${JSON.stringify({ jsonrpc: "2.0", method: "notifications/initialized", params: {} })}\n`,
      );
      return await request(
        input.protocolMethod ?? "tools/call",
        input.protocolParams ?? {
          name: input.entry?.toolName,
          arguments: input.parameters ?? {},
        },
      );
    } finally {
      clearTimeout(timer);
      input.signal?.removeEventListener("abort", abort);
      child.stdin.end();
      signalRunningProcess(ownedProcess, "SIGTERM");
      // Bound cleanup even when the provider or a descendant ignores SIGTERM.
      await new Promise<void>((resolve) => setTimeout(resolve, 250));
      signalRunningProcess(ownedProcess, "SIGKILL");
      await Promise.race([exitPromise, new Promise<void>((resolve) => setTimeout(resolve, 250))]);
    }
  }

  async function fullyAssignedMcpConnections(session: ToolGatewaySession) {
    if (!session.gatewayProfileId) return [];
    return db
      .select({ connection: toolConnections })
      .from(toolProfileEntries)
      .innerJoin(
        toolConnections,
        eq(toolProfileEntries.connectionId, toolConnections.id),
      )
      .where(
        and(
          eq(toolProfileEntries.companyId, session.companyId),
          eq(toolProfileEntries.profileId, session.gatewayProfileId),
          eq(toolProfileEntries.selectorType, "connection"),
          eq(toolProfileEntries.effect, "include"),
          eq(toolConnections.companyId, session.companyId),
          eq(toolConnections.enabled, true),
          eq(toolConnections.status, "active"),
          inArray(toolConnections.transport, ["mcp_remote", "local_stdio"]),
        ),
      )
      .then((rows) => rows.map((row) => row.connection));
  }

  async function callRemoteConnectionProtocol(input: {
    session: ToolGatewaySession;
    connection: typeof toolConnections.$inferSelect;
    method: string;
    params: Record<string, unknown>;
    callerHeaders?: Record<string, string | string[] | undefined>;
  }): Promise<unknown> {
    if (!["tools/list", "resources/list", "prompts/list"].includes(input.method)) {
      await assertExternalMcpModelEffects(input.session);
    }
    const grant = await resolveConnectionGrant(input.session, input.connection);
    const endpoint = await resolvedRemoteEndpoint(
      input.session,
      input.connection,
      grant,
    );
    const credentialHeaders = {
      ...projectedConnectionHeaders(input.connection),
      ...(await resolveCredentialHeaders(
        input.session,
        input.connection,
        grant,
      )),
    };
    const { headers } = buildRemoteHeaders({
      session: input.session,
      connection: input.connection,
      credentialHeaders,
      callerHeaders: input.callerHeaders,
    });
    const response = await guardedRemoteHttpFetch(
      endpoint,
      {
        method: "POST",
        redirect: "manual",
        headers: mcpHttpRequestHeaders(headers),
        body: JSON.stringify({
          jsonrpc: "2.0",
          id: `paperclip-context-${randomUUID()}`,
          method: input.method,
          params: input.params,
        }),
      },
      remoteHttpFetchOptions(),
    );
    const body = await readBoundedRemoteResponse(response);
    if (!response.ok) {
      await markRemoteConnectionHealth(
        input.connection,
        "error",
        `Remote MCP server failed ${input.method}.`,
      );
      throw new ToolGatewayHttpError(
        502,
        "Remote MCP context request failed",
        "mcp_remote_status",
        {
          status: response.status,
          connectionId: input.connection.id,
          method: input.method,
        },
      );
    }
    let payload: unknown;
    try {
      payload = parseMcpHttpResponseBody(
        body,
        response.headers.get("content-type"),
      );
    } catch {
      throw new ToolGatewayHttpError(
        502,
        "Remote MCP context response was invalid",
        "mcp_remote_invalid_json",
        {
          connectionId: input.connection.id,
          method: input.method,
        },
      );
    }
    const record = asRecord(payload);
    if (
      !record ||
      record.error !== undefined ||
      !Object.prototype.hasOwnProperty.call(record, "result")
    ) {
      throw new ToolGatewayHttpError(
        502,
        "Remote MCP context request returned an error",
        "remote_mcp_error",
        {
          connectionId: input.connection.id,
          method: input.method,
        },
      );
    }
    await markRemoteConnectionHealth(
      input.connection,
      "ok",
      `Remote MCP server responded to ${input.method}.`,
    );
    return record.result;
  }

  async function callAssignedConnectionProtocol(input: {
    session: ToolGatewaySession;
    connection: typeof toolConnections.$inferSelect;
    method: string;
    params?: Record<string, unknown>;
    callerHeaders?: Record<string, string | string[] | undefined>;
  }): Promise<unknown> {
    if (input.connection.transport === "mcp_remote") {
      return callRemoteConnectionProtocol({
        ...input,
        params: input.params ?? {},
      });
    }
    if (input.connection.transport !== "local_stdio") {
      throw new ToolGatewayHttpError(
        501,
        "Assigned MCP connection transport is unsupported",
        "mcp_transport_unsupported",
      );
    }
    if (!["tools/list", "resources/list", "prompts/list"].includes(input.method)) {
      await assertExternalMcpModelEffects(input.session);
    }
    const template = await resolveLocalStdioRuntimeTemplate(input.connection);
    const grant = await resolveConnectionGrant(input.session, input.connection);
    const env = await localStdioEnvironment(
      input.session,
      input.connection,
      template,
      grant,
    );
    if (template.templateId === "paperclip.cognee-cloud") {
      return callLocalStdioMcp({ connection: input.connection, template, env,
        protocolMethod: input.method, protocolParams: input.params ?? {}, timeoutMs: DEFAULT_TOOL_TIMEOUT_MS });
    }
    return runtimeSupervisor.useConnectionSlot(
      {
        companyId: input.session.companyId,
        applicationId: input.connection.applicationId,
        connectionId: input.connection.id,
        // Each gateway session is run-bound. Keep local stdio slot state
        // isolated by that session instead of reusing a company connection slot.
        connectionKey: `mcp:${input.session.companyId}:${input.connection.id}:${input.session.id}`,
        runId: input.session.runId,
        issueId: input.session.issueId,
        agentId: input.session.agentId,
        commandTemplateKey: template.templateId,
        metadata: {
          source: "native-runtime-context",
          protocolMethod: input.method,
        },
      },
      async () =>
        callLocalStdioMcp({
          connection: input.connection,
          template,
          env,
          protocolMethod: input.method,
          protocolParams: input.params ?? {},
          timeoutMs: DEFAULT_TOOL_TIMEOUT_MS,
        }),
    );
  }

  function contextHandle(
    kind: "resource" | "prompt",
    connectionId: string,
    value: string,
  ) {
    return `paperclip-${kind}://${connectionId}/${Buffer.from(value, "utf8").toString("base64url")}`;
  }

  function parseContextHandle(kind: "resource" | "prompt", value: unknown) {
    if (typeof value !== "string") return null;
    const match = value.match(
      new RegExp(`^paperclip-${kind}://([0-9a-f-]{36})/([A-Za-z0-9_-]+)$`, "i"),
    );
    if (!match) return null;
    try {
      return {
        connectionId: match[1]!,
        value: Buffer.from(match[2]!, "base64url").toString("utf8"),
      };
    } catch {
      return null;
    }
  }

  async function namedGatewayContextProtocol(input: {
    gatewayId?: string | null;
    gatewayPublicId?: string | null;
    bearerToken: string;
    method:
      "resources/list" | "resources/read" | "prompts/list" | "prompts/get";
    params?: Record<string, unknown>;
    callerHeaders?: Record<string, string | string[] | undefined>;
  }) {
    const session = await namedGatewaySessionFromBearer({
      gatewayId: input.gatewayId ?? null,
      gatewayPublicId: input.gatewayPublicId ?? null,
      bearerToken: input.bearerToken,
      protocolMethod: input.method,
      callerHeaders: input.callerHeaders,
    });
    await assertGatewayTokenAction(session, input.method);
    const connections = await fullyAssignedMcpConnections(session);
    if (input.method === "resources/list") {
      const resources = [] as Array<Record<string, unknown>>;
      for (const connection of connections) {
        const result = asRecord(
          await callAssignedConnectionProtocol({
            ...input,
            session,
            connection,
            method: input.method,
          }),
        );
        for (const resource of Array.isArray(result?.resources)
          ? result.resources
          : []) {
          const record = asRecord(resource);
          if (!record || typeof record.uri !== "string") continue;
          resources.push({
            ...record,
            uri: contextHandle("resource", connection.id, record.uri),
            name: `${connection.name}: ${typeof record.name === "string" ? record.name : record.uri}`,
          });
        }
      }
      return { resources };
    }
    if (input.method === "prompts/list") {
      const prompts = [] as Array<Record<string, unknown>>;
      for (const connection of connections) {
        const result = asRecord(
          await callAssignedConnectionProtocol({
            ...input,
            session,
            connection,
            method: input.method,
          }),
        );
        for (const prompt of Array.isArray(result?.prompts)
          ? result.prompts
          : []) {
          const record = asRecord(prompt);
          if (!record || typeof record.name !== "string") continue;
          prompts.push({
            ...record,
            name: contextHandle("prompt", connection.id, record.name),
            title: `${connection.name}: ${typeof record.title === "string" ? record.title : record.name}`,
          });
        }
      }
      return { prompts };
    }
    const kind = input.method === "resources/read" ? "resource" : "prompt";
    const handle = parseContextHandle(
      kind,
      input.params?.[kind === "resource" ? "uri" : "name"],
    );
    const connection = handle
      ? connections.find((candidate) => candidate.id === handle.connectionId)
      : null;
    if (!handle || !connection) {
      throw new ToolGatewayHttpError(
        404,
        `Assigned MCP ${kind} was not found`,
        `mcp_${kind}_not_found`,
      );
    }
    const params =
      kind === "resource"
        ? { uri: handle.value }
        : { name: handle.value, arguments: input.params?.arguments ?? {} };
    const result = asRecord(
      await callAssignedConnectionProtocol({
        ...input,
        session,
        connection,
        method: input.method,
        params,
      }),
    );
    if (kind === "resource" && Array.isArray(result?.contents)) {
      return {
        ...result,
        contents: result.contents.map((content) => {
          const record = asRecord(content);
          return record && typeof record.uri === "string"
            ? {
                ...record,
                uri: contextHandle("resource", connection.id, record.uri),
              }
            : content;
        }),
      };
    }
    return result ?? {};
  }

  async function connectedRemoteApprovalSnapshot(
    session: ToolGatewaySession,
    tool: ToolGatewayDescriptor,
    options: { requireResolvedCredentials?: boolean } = {},
  ): Promise<Record<string, unknown> | null> {
    await assertConnectedToolModelEffects(session, tool);
    if (tool.providerType === "paperclip_slack_chat") {
      if (!session.agentId || !session.runId || !session.issueId) throw new ToolGatewayHttpError(403, "Slack task binding required", "slack_task_required");
      const authority = await resolveSlackTaskAuthority(db, { companyId: session.companyId, agentId: session.agentId, runId: session.runId, issueId: session.issueId, endpointId: String(asRecord(tool.providerMetadata)?.endpointId ?? ""), identityContextId: session.identityContextId, approvedInvocationId: session.approvedSlackInvocationId });
      return { endpointId: authority.endpoint.id, userId: authority.userId, revision: authority.revision, identityContextId: authority.identityContextId };
    }
    if (
      tool.providerType !== "mcp_remote_http" ||
      !tool.connectionId ||
      !tool.catalogEntryId
    ) {
      return null;
    }
    const [row] = await db
      .select({
        entry: toolCatalogEntries,
        connection: toolConnections,
        application: toolApplications,
      })
      .from(toolCatalogEntries)
      .innerJoin(
        toolConnections,
        eq(toolCatalogEntries.connectionId, toolConnections.id),
      )
      .innerJoin(
        toolApplications,
        eq(toolConnections.applicationId, toolApplications.id),
      )
      .where(
        and(
          eq(toolCatalogEntries.id, tool.catalogEntryId),
          eq(toolCatalogEntries.companyId, session.companyId),
          eq(toolConnections.id, tool.connectionId),
          eq(toolConnections.companyId, session.companyId),
          eq(toolApplications.companyId, session.companyId),
        ),
      )
      .limit(1);
    if (!row) return null;
    const grant = await resolveConnectionGrant(session, row.connection);
    const credentialVersions = await connectedCredentialVersionSnapshots(
      row.connection,
      grant,
      {
        requireResolved: options.requireResolvedCredentials === true,
      },
    );
    return {
      applicationId: row.application.id,
      applicationKey: row.application.applicationKey ?? null,
      applicationStatus: row.application.status,
      applicationType: row.application.type,
      connectionId: row.connection.id,
      connectionStatus: row.connection.status,
      connectionEnabled: row.connection.enabled,
      connectionTransport: row.connection.transport,
      connectionConfigHash: stableHash(row.connection.config ?? {}),
      connectionTransportConfigHash: stableHash(
        row.connection.transportConfig ?? {},
      ),
      credentialRefsHash: stableHash(row.connection.credentialRefs ?? []),
      credentialSecretRefsHash: stableHash(
        row.connection.credentialSecretRefs ?? [],
      ),
      credentialGrantId: grant.id,
      credentialGrantRefsHash: stableHash(grant.credentialSecretRefs ?? []),
      headerCredentialVersions: credentialVersions.headerCredentialVersions,
      credentialSecretVersions: credentialVersions.credentialSecretVersions,
      catalogEntryId: row.entry.id,
      catalogStatus: row.entry.status,
      catalogEntryKind: row.entry.entryKind,
      catalogVersionHash: row.entry.versionHash,
      catalogSchemaHash: row.entry.schemaHash ?? null,
      upstreamToolName: row.entry.toolName,
      providerType: tool.providerType,
      gatewayToolName: tool.name,
      riskLevel: tool.risk,
    };
  }

  function responseTooLargeError() {
    return new ToolGatewayHttpError(
      502,
      "Remote MCP response exceeded the gateway size limit",
      "mcp_remote_response_too_large",
      { maxBytes: MAX_REMOTE_MCP_RESPONSE_BYTES },
    );
  }

  async function readBoundedRemoteResponse(
    response: Response,
  ): Promise<string> {
    const contentLength = response.headers.get("content-length");
    if (
      contentLength &&
      Number(contentLength) > MAX_REMOTE_MCP_RESPONSE_BYTES
    ) {
      throw responseTooLargeError();
    }
    const body = await response.text();
    if (Buffer.byteLength(body, "utf8") > MAX_REMOTE_MCP_RESPONSE_BYTES) {
      throw responseTooLargeError();
    }
    return body;
  }

  function malformedRemoteMcpResponse(): ToolGatewayHttpError {
    return new ToolGatewayHttpError(
      502,
      "Remote MCP server returned a malformed tools/call response",
      "remote_mcp_malformed_response",
    );
  }

  type McpElicitationRequest = {
    message: string;
    requestedSchema: Record<string, unknown> | null;
    raw: Record<string, unknown>;
  };

  function extractMcpElicitationRequest(
    value: unknown,
  ): McpElicitationRequest | null {
    const record = asRecord(value);
    if (!record) return null;
    const meta = asRecord(record._meta);
    const candidate =
      (record.method === "elicitation/create"
        ? asRecord(record.params)
        : null) ??
      asRecord(record.elicitation) ??
      asRecord(record.elicitationRequest) ??
      asRecord(meta?.elicitation) ??
      asRecord(meta?.elicitationRequest);
    if (!candidate) return null;
    const message =
      stringValue(candidate.message) ??
      stringValue(candidate.prompt) ??
      stringValue(candidate.title) ??
      "The MCP tool needs more information before it can continue.";
    const requestedSchema = asRecord(
      candidate.requestedSchema ?? candidate.schema ?? candidate.inputSchema,
    );
    return { message, requestedSchema, raw: candidate };
  }

  function enumOptions(
    values: unknown[],
  ): Array<{ id: string; label: string }> {
    return values.slice(0, 10).map((value, index) => {
      const label =
        typeof value === "string" ||
        typeof value === "number" ||
        typeof value === "boolean"
          ? String(value)
          : `Option ${index + 1}`;
      return {
        id: slugSegment(label, `option-${index + 1}`).slice(0, 120),
        label: label.slice(0, 120),
      };
    });
  }

  function elicitationQuestions(request: McpElicitationRequest) {
    const schema = request.requestedSchema;
    const properties = asRecord(schema?.properties);
    const required = Array.isArray(schema?.required)
      ? new Set(
          schema.required.filter(
            (item): item is string => typeof item === "string",
          ),
        )
      : new Set<string>();
    const questions: Array<{
      id: string;
      prompt: string;
      helpText?: string | null;
      selectionMode: "single" | "multi";
      required?: boolean;
      options: Array<{
        id: string;
        label: string;
        description?: string | null;
      }>;
    }> = [];
    if (properties) {
      for (const [key, rawProperty] of Object.entries(properties)) {
        if (questions.length >= 10) break;
        const property = asRecord(rawProperty) ?? {};
        const enumValues = Array.isArray(property.enum) ? property.enum : [];
        const options =
          enumValues.length > 0
            ? enumOptions(enumValues)
            : [{ id: "answer", label: "Provide answer" }];
        questions.push({
          id: key.slice(0, 120),
          prompt: (
            stringValue(property.title) ??
            stringValue(property.description) ??
            key
          ).slice(0, 500),
          helpText:
            enumValues.length > 0
              ? null
              : "Use Other to enter the requested value.",
          selectionMode: "single",
          required: required.has(key),
          options,
        });
      }
    }
    if (questions.length > 0) return questions;
    return [
      {
        id: "response",
        prompt: request.message.slice(0, 500),
        helpText: "Use Other to enter the requested response.",
        selectionMode: "single" as const,
        required: true,
        options: [{ id: "answer", label: "Provide response" }],
      },
    ];
  }

  async function requestElicitationForRecordedToolCall(input: {
    session: ToolGatewaySession;
    tool: ToolGatewayDescriptor;
    invocationId: string;
    request: McpElicitationRequest;
  }): Promise<never> {
    if (!input.session.issueId) {
      throw new ToolGatewayHttpError(
        409,
        "MCP elicitation is not supported for non-interactive gateway clients",
        "elicitation_not_supported",
        { invocationId: input.invocationId, tool: input.tool.name },
      );
    }
    const interaction = await interactions.create(
      { id: input.session.issueId, companyId: input.session.companyId },
      {
        kind: "ask_user_questions",
        idempotencyKey: `mcp-elicitation:${input.invocationId}`,
        title: "Tool needs input",
        summary: `${input.tool.name} asked for more information before it can continue.`,
        continuationPolicy: "wake_assignee",
        payload: {
          version: 1,
          title: input.request.message.slice(0, 240),
          submitLabel: "Send response",
          questions: elicitationQuestions(input.request),
        },
      },
      { agentId: input.session.agentId },
    );
    const now = new Date();
    await db
      .update(toolInvocations)
      .set({
        status: "awaiting_approval",
        errorCode: "elicitation_required",
        errorMessage:
          "Remote MCP tool requested elicitation; Paperclip created an issue interaction for the response.",
        updatedAt: now,
      })
      .where(eq(toolInvocations.id, input.invocationId));
    await writeToolCallEvent({
      invocationId: input.invocationId,
      session: input.session,
      eventType: "call_failed",
      outcome: "pending",
      toolName: input.tool.name,
      policyDecision: "defer_runtime",
      reasonCode: "elicitation_required",
      metadata: {
        interactionId: interaction.id,
        elicitation: {
          message: input.request.message,
          requestedSchema: input.request.requestedSchema,
        },
      },
      tool: input.tool,
    });
    await writeAudit({
      session: input.session,
      companyId: input.session.companyId,
      agentId: input.session.agentId,
      runId: input.session.runId,
      issueId: input.session.issueId,
      action: "tool_gateway.elicitation_requested",
      details: {
        invocationId: input.invocationId,
        interactionId: interaction.id,
        decision: "defer_runtime",
        reasonCode: "elicitation_required",
        tool: input.tool.name,
        ...toolAuditMetadata(input.tool),
      },
    });
    throw new ToolGatewayHttpError(
      409,
      "MCP tool requested additional input",
      "elicitation_required",
      {
        invocationId: input.invocationId,
        interactionId: interaction.id,
        tool: input.tool.name,
      },
    );
  }

  function normalizeMcpContent(content: unknown): string {
    if (!Array.isArray(content)) throw malformedRemoteMcpResponse();
    return content
      .map((item) => {
        const record = asRecord(item);
        if (!record || typeof record.type !== "string")
          throw malformedRemoteMcpResponse();
        if (record.type === "text") {
          if (typeof record.text !== "string")
            throw malformedRemoteMcpResponse();
          return record.text;
        }
        return JSON.stringify(record);
      })
      .join("\n");
  }

  function normalizeMcpToolResult(
    result: unknown,
    transport: "mcp_http" | "local_stdio" | "cognee_cloud" = "mcp_http",
    spawnedLocalProcess = false,
    sourceTemplateKey?: string | null,
  ) {
    const record = asRecord(result);
    if (!record) throw malformedRemoteMcpResponse();
    const providerContent = normalizeMcpContent(record.content);
    const googleWorkspacePermissionDenied =
      record.isError === true &&
      (sourceTemplateKey === "gmail" ||
        sourceTemplateKey?.startsWith("google-") === true) &&
      /caller does not have permission/i.test(providerContent);
    const content = googleWorkspacePermissionDenied
      ? "Google rejected this call. Google Workspace MCP is a Developer Preview: enroll the signed-in Workspace account and this OAuth client's Google Cloud project in Google's Developer Preview Program, wait for Google's registration confirmation, then reconnect and try again."
      : providerContent;
    return {
      content,
      data: {
        content: record.content,
        structuredContent: record.structuredContent ?? null,
        isError: record.isError === true,
        transport,
        spawnedLocalProcess,
      },
      ...(record.isError === true
        ? { error: "MCP tool returned an error result" }
        : {}),
    };
  }

  async function executeRemoteHttpTool(
    session: ToolGatewaySession,
    tool: ToolGatewayDescriptor,
    parameters: unknown,
    ms: number,
    invocationId: string,
    callerHeaders?: ExecuteGatewayToolInput["callerHeaders"],
    useDefaultTimeout = false,
    signal?: AbortSignal,
    scopedContext?: ScopedToolGatewayContext,
  ): Promise<RemoteHttpExecutionResult> {
    const { entry, connection } = await resolveConnectedRemoteTool(
      session,
      tool,
    );
    if (!serverOwnedNonModelRemoteTool(connection, entry.toolName)) await assertExternalMcpModelEffects(session);
    // Recheck immediately before dispatch, including previously approved calls
    // and connections whose stored grant/catalog predates scope reduction.
    assertGoogleChatToolArgumentsSupported(connection, entry.toolName, parameters);
    if (useDefaultTimeout && isRailwayConnection(connection) && entry.toolName === `${RAILWAY_TOOL_PREFIX}run-command`) {
      ms = railwayCommandBudgetMs(parameters);
    }
    const grant = await resolveConnectionGrant(session, connection);
    // Scoped authority belongs to the original native execution. Credential
    // resolution, initialization and refresh can all await external work; an
    // earlier check cannot authorize the request that follows those awaits.
    const connectionPin = (row: typeof toolConnections.$inferSelect) => stableHash({
      id: row.id, applicationId: row.applicationId, authKind: row.authKind,
      credentialSource: row.credentialSource, credentialPolicy: row.credentialPolicy,
      config: row.config, transportConfig: row.transportConfig,
      credentialRefs: row.credentialRefs, credentialSecretRefs: row.credentialSecretRefs,
      externalCredential: row.externalCredential,
    });
    const pinnedConnection = scopedContext ? connectionPin(connection) : null;
    const assertScopedTransportCurrent = async () => {
      if (!scopedContext) return;
      try {
        await scopedContext.assertCurrent(tool);
        await scopedContext.assertManifestCurrent?.(tool);
      } catch (error) {
        if (error instanceof ToolGatewayHttpError) throw error;
        if (error instanceof HttpError) {
          const details = error.details && typeof error.details === "object" ? error.details as Record<string, unknown> : {};
          throw new ToolGatewayHttpError(error.status, error.message,
            typeof details.code === "string" ? details.code : "scoped_tool_authority_changed", details);
        }
        throw new ToolGatewayHttpError(403, "Scoped execution authority changed", "scoped_tool_authority_changed");
      }
      const live = await resolveConnectedRemoteTool(session, tool);
      const [application] = await db.select({ status: toolApplications.status })
        .from(toolApplications).where(and(eq(toolApplications.id, live.connection.applicationId),
          eq(toolApplications.companyId, session.companyId)));
      const [liveGrant] = await db.select().from(connectionGrants).where(and(
        eq(connectionGrants.companyId, session.companyId),
        eq(connectionGrants.connectionId, connection.id),
        eq(connectionGrants.id, grant.id),
      ));
      if (!application || application.status !== "active" || connectionPin(live.connection) !== pinnedConnection ||
          live.entry.versionHash !== entry.versionHash ||
          live.entry.schemaHash !== entry.schemaHash ||
          live.entry.toolName !== entry.toolName ||
          live.entry.riskLevel !== entry.riskLevel ||
          !liveGrant || liveGrant.status !== "active" || liveGrant.revokedAt ||
          liveGrant.kind !== grant.kind || liveGrant.subjectUserId !== grant.subjectUserId ||
          liveGrant.subjectAgentId !== grant.subjectAgentId ||
          stableHash(liveGrant.credentialSecretRefs) !== stableHash(grant.credentialSecretRefs)) {
        throw new ToolGatewayHttpError(403, "Scoped connection authority changed", "scoped_tool_connection_changed");
      }
      // Reuse the native audience/membership/delegation resolver, then refuse
      // fallback to another person's or organization's grant within this call.
      const selectedGrant = await resolveConnectionGrant(session, live.connection);
      if (selectedGrant.id !== grant.id) {
        throw new ToolGatewayHttpError(403, "Scoped credential selection changed", "scoped_tool_grant_changed");
      }
    };
    await assertScopedTransportCurrent();
    const endpoint = await resolvedRemoteEndpoint(session, connection, grant);
    // Method-defined headers are trusted catalog configuration. Treat them as
    // managed headers so callers cannot override the scope that was reviewed
    // during tools/list. Credentials remain authoritative on collisions.
    let credentialHeaders = {
      ...projectedConnectionHeaders(connection),
      ...(await resolveCredentialHeaders(session, connection, grant)),
    };
    let builtHeaders = buildRemoteHeaders({
      session,
      connection,
      credentialHeaders,
      callerHeaders,
    });
    let headers = builtHeaders.headers;
    let headerSummary = builtHeaders.summary;
    const requestId = `paperclip-tool-${randomUUID()}`;
    const execution: RemoteHttpExecutionAudit = {
      transport: "mcp_remote",
      request: {
        protocol: "MCP JSON-RPC 2.0",
        httpMethod: "POST",
        endpoint: auditSafeEndpoint(endpoint),
        mcpMethod: "tools/call",
        requestId,
        upstreamToolName: entry.toolName,
        dispatched: false,
      },
    };
    const controller = new AbortController();
    const abort = () => controller.abort(signal?.reason);
    signal?.addEventListener("abort", abort, { once: true });
    if (signal?.aborted) abort();
    const timer = setTimeout(() => controller.abort(), ms);
    timer.unref?.();
    try {
      const dispatchRemote = async (target: string, init: RequestInit) => {
        await assertScopedTransportCurrent();
        controller.signal.throwIfAborted();
        execution.request.dispatched = true;
        return options.remoteHttpRequest
          ? options.remoteHttpRequest(target, init)
          : guardedRemoteHttpFetch(target, init, {
              ...remoteHttpFetchOptions(),
              // This call site owns a caller-set budget that can exceed the
              // transport's default response deadline, so hand it down rather than
              // letting the tighter default cut a legitimately slow tool short.
              responseTimeoutMs: ms,
            });
      };
      if (isRailwayEndpoint(connection.config.url) && normalizeRailwayToolName(entry.toolName).startsWith(RAILWAY_TOOL_PREFIX)) {
        if (!isRailwayConnection(connection) || connection.config.railwayApiStatus !== "available") {
          throw new ToolGatewayHttpError(422, "Railway API access is not verified. Refresh actions or reconnect this Railway connection.", "railway_api_not_verified");
        }
        const ssh = asRecord(connection.config.railwaySsh);
        const sshRef = grant.credentialSecretRefs.find((ref) => ref.configPath === RAILWAY_SSH_SECRET_PATH);
        execution.request.endpoint = RAILWAY_API_URL;
        execution.request.protocol = entry.toolName === `${RAILWAY_TOOL_PREFIX}run-command` ? "Railway GraphQL + SSH" : "Railway GraphQL";
        const client = createRailwayClient({
          authorization: credentialHeaders.Authorization ?? "",
          signal: controller.signal,
          request: dispatchRemote,
          runCommand: ssh?.grantId === grant.id && ssh?.enabled === true && sshRef
            ? async (input) => {
                const privateKey = await resolveGrantSecretValue(session, connection, grant, sshRef);
                await assertScopedTransportCurrent();
                controller.signal.throwIfAborted();
                return runRailwaySshCommand({
                  ...input, privateKey,
                  knownHosts: typeof ssh.knownHosts === "string" ? ssh.knownHosts : "",
                });
              }
            : undefined,
        });
        const data = await client.call(entry.toolName, parameters);
        await assertScopedTransportCurrent();
        const record = asRecord(data);
        const failedCommand = entry.toolName === `${RAILWAY_TOOL_PREFIX}run-command` && (record?.exitCode !== 0 || record?.timedOut === true || record?.truncated === true);
        return {
          result: normalizeMcpToolResult({ content: [{ type: "text", text: JSON.stringify(data) }], structuredContent: data, isError: failedCommand }, "mcp_http", entry.toolName === `${RAILWAY_TOOL_PREFIX}run-command`, "railway"),
          headerSummary,
          execution,
        };
      }
      let requestHeaders = headers;
      if (connection.config.mcpSessionRequired === true) {
        requestHeaders = await getMcpHttpSession({
          scope: `${connection.id}:grant:${grant.id}:actor:${session.agentId}:${endpoint}`,
          send: (init) =>
            dispatchRemote(endpoint, {
              ...init,
              redirect: "manual",
              signal: controller.signal,
            }),
          headers,
          requestId,
        });
      }
      // The guard runs inside this call and the connection is pinned to the
      // address it approved, so an operator-supplied hostname cannot be rebound
      // onto a loopback or metadata address between validation and dispatch
      // (PAP-17098).
      const requestInit: RequestInit = {
        method: "POST",
        redirect: "manual",
        // MCP Streamable HTTP requires the Accept header advertising both a JSON
        // body and an SSE stream; spec-compliant servers 406 without it.
        headers: mcpHttpRequestHeaders(requestHeaders),
        signal: controller.signal,
        body: JSON.stringify({
          jsonrpc: "2.0",
          id: requestId,
          method: "tools/call",
          params: {
            name: entry.toolName,
            arguments: parameters,
          },
        }),
      };
      let response = await dispatchRemote(endpoint, requestInit);
      const oauth = asRecord(asRecord(connection.config)?.oauth);
      if (
        response.status === 401 &&
        connection.authKind === "oauth" &&
        connection.credentialSource === "paperclip_vault" &&
        isPaperclipCloudConnectorStrategy(oauth?.strategy)
      ) {
        await assertScopedTransportCurrent();
        credentialHeaders = {
          ...projectedConnectionHeaders(connection),
          ...(await resolveCredentialHeaders(session, connection, grant, {
            forceRefresh: true,
          })),
        };
        builtHeaders = buildRemoteHeaders({
          session,
          connection,
          credentialHeaders,
          callerHeaders,
        });
        headers = builtHeaders.headers;
        headerSummary = builtHeaders.summary;
        response = await dispatchRemote(endpoint, {
          ...requestInit,
          headers: mcpHttpRequestHeaders(headers),
        });
        if (response.status === 401) {
          await db
            .update(connectionGrants)
            .set({
              status: "needs_reauthorization",
              updatedAt: new Date(options.now?.() ?? Date.now()),
            })
            .where(
              and(
                eq(connectionGrants.id, grant.id),
                eq(connectionGrants.companyId, connection.companyId),
              ),
            );
        }
      }
      if (
        response.status === 401 &&
        connection.authKind === "oauth" &&
        connection.credentialSource === "paperclip_vault" &&
        !isPaperclipCloudConnectorStrategy(oauth?.strategy) &&
        options.oauthGrantRefresher
      ) {
        await assertScopedTransportCurrent();
        credentialHeaders = {
          ...projectedConnectionHeaders(connection),
          ...(await resolveCredentialHeaders(session, connection, grant, {
            forceRefresh: true,
          })),
        };
        builtHeaders = buildRemoteHeaders({
          session,
          connection,
          credentialHeaders,
          callerHeaders,
        });
        headers = builtHeaders.headers;
        headerSummary = builtHeaders.summary;
        response = await dispatchRemote(endpoint, {
          ...requestInit,
          headers: mcpHttpRequestHeaders(headers),
        });
      }
      if (
        response.status === 401 &&
        connection.credentialSource === "vercel_connect"
      ) {
        await assertScopedTransportCurrent();
        if (!connection.externalCredential || !vercelConnect) {
          throw new ToolGatewayHttpError(
            503,
            "Vercel Connect is not configured",
            "vercel_connect_unavailable",
            {
              connectionId: connection.id,
            },
          );
        }
        const tokenRequest = vercelTokenRequest({
          credential: connection.externalCredential,
          grant,
          connectionId: connection.id,
          companyId: connection.companyId,
        });
        vercelConnect.evict(tokenRequest);
        credentialHeaders = {
          ...projectedConnectionHeaders(connection),
          ...(await resolveCredentialHeaders(session, connection, grant, {
            forceRefresh: true,
          })),
        };
        builtHeaders = buildRemoteHeaders({
          session,
          connection,
          credentialHeaders,
          callerHeaders,
        });
        headers = builtHeaders.headers;
        headerSummary = builtHeaders.summary;
        response = await dispatchRemote(endpoint, {
          ...requestInit,
          headers: mcpHttpRequestHeaders(headers),
        });
      }
      const sessionExpired = response.status === 404 && new Headers(requestHeaders).has("mcp-session-id");
      if (sessionExpired) {
        // The next explicit call initializes again. Never replay a tools/call
        // automatically: the failed call may have changed app data.
        forgetMcpHttpSessions(connection.id);
      }
      const body = response.ok
        ? JSON.stringify(await readMcpHttpResponse(response, requestId, {
            maxBytes: MAX_REMOTE_MCP_RESPONSE_BYTES,
            onRequest: async (message) => {
              const pending = extractRemoteMcpPending(message);
              if (pending) {
                await retainUpstreamHandoff(invocationId, pending);
                // Defer this interaction to the user. Do not claim that consent
                // was granted or repeat a potentially state-changing tool call.
                await dispatchRemote(endpoint, {
                  method: "POST", headers: mcpHttpRequestHeaders(requestHeaders),
                  body: JSON.stringify({ jsonrpc: "2.0", id: message.id, result: { action: "cancel" } }),
                });
                throw new ToolGatewayHttpError(409, "This tool needs authorization in the provider.", "provider_interaction_required", { upstreamPending: pending, invocationId });
              }
              const request = extractMcpElicitationRequest(message);
              if (request) await requestElicitationForRecordedToolCall({ session, tool, invocationId, request });
            },
          }))
        : await readBoundedRemoteResponse(response);
      execution.response = {
        httpStatus: response.status,
        contentType: response.headers.get("content-type"),
        bodySizeBytes: Buffer.byteLength(body, "utf8"),
        upstreamRequestId:
          response.headers.get("x-request-id") ??
          response.headers.get("x-zapier-request-id") ??
          response.headers.get("traceparent"),
      };
      if (!response.ok) {
        // Session expiration is recoverable on an explicit retry. Marking the
        // connection unhealthy here would hide every tool and prevent it.
        if (!sessionExpired) {
          await markRemoteConnectionHealth(connection, "error", "Remote MCP server returned an HTTP error.");
        }
        throw new ToolGatewayHttpError(
          502,
          sessionExpired ? "Remote MCP session expired. Retry the action explicitly to start a new session." : "Remote MCP server returned an HTTP error",
          "mcp_remote_status",
          {
            status: response.status,
            ...(sessionExpired ? { sessionExpired: true } : {}),
            connectionId: connection.id,
            catalogEntryId: entry.id,
            execution,
          },
        );
      }
      let payload: unknown;
      try {
        payload = JSON.parse(body);
      } catch {
        await markRemoteConnectionHealth(
          connection,
          "error",
          "Remote MCP server returned invalid JSON.",
        );
        throw new ToolGatewayHttpError(
          502,
          "Remote MCP server returned invalid JSON",
          "mcp_remote_invalid_json",
          {
            connectionId: connection.id,
            catalogEntryId: entry.id,
            execution,
          },
        );
      }
      const payloadRecord = asRecord(payload);
      if (!payloadRecord) throw malformedRemoteMcpResponse();
      const upstreamPending = extractRemoteMcpPending(payloadRecord, String(connection.config.sourceTemplateKey ?? ""), entry.toolName);
      if (upstreamPending) {
        await retainUpstreamHandoff(invocationId, upstreamPending);
        throw new ToolGatewayHttpError(409, "Complete the provider's authorization or approval before continuing. The original call has not been replayed.", "provider_interaction_required", { upstreamPending, invocationId });
      }
      const topLevelElicitation = extractMcpElicitationRequest(payloadRecord);
      if (topLevelElicitation) {
        await requestElicitationForRecordedToolCall({
          session,
          tool,
          invocationId,
          request: topLevelElicitation,
        });
      }
      if (payloadRecord.error !== undefined) {
        const errorRecord = asRecord(payloadRecord.error);
        await markRemoteConnectionHealth(
          connection,
          "error",
          "Remote MCP server returned a JSON-RPC error.",
        );
        throw new ToolGatewayHttpError(
          502,
          "Remote MCP server returned an error",
          "remote_mcp_error",
          {
            code:
              typeof errorRecord?.code === "number" ? errorRecord.code : null,
            connectionId: connection.id,
            catalogEntryId: entry.id,
            execution,
          },
        );
      }
      if (!Object.prototype.hasOwnProperty.call(payloadRecord, "result")) {
        throw malformedRemoteMcpResponse();
      }
      const resultElicitation = extractMcpElicitationRequest(
        payloadRecord.result,
      );
      if (resultElicitation) {
        await requestElicitationForRecordedToolCall({
          session,
          tool,
          invocationId,
          request: resultElicitation,
        });
      }
      const sourceTemplateKey =
        typeof connection.config.sourceTemplateKey === "string"
          ? connection.config.sourceTemplateKey
          : null;
      const result = normalizeMcpToolResult(
        payloadRecord.result,
        "mcp_http",
        false,
        sourceTemplateKey,
      );
      await assertScopedTransportCurrent();
      await markRemoteConnectionHealth(
        connection,
        "ok",
        "Remote MCP server responded to tools/call.",
      );
      return { result, headerSummary, execution };
    } catch (error) {
      if (error instanceof McpHttpResponseError) {
        const failure = error.reason === "too_large" ? responseTooLargeError()
          : error.reason === "malformed_response" ? malformedRemoteMcpResponse()
          : new ToolGatewayHttpError(502, "Remote MCP server returned invalid JSON", "mcp_remote_invalid_json");
        await markRemoteConnectionHealth(connection, "error", failure.message);
        throw new ToolGatewayHttpError(failure.status, failure.message, failure.reasonCode, {
          connectionId: connection.id, catalogEntryId: entry.id, execution,
        });
      }
      if (error instanceof RailwayError) {
        throw new ToolGatewayHttpError(error.status, error.message, error.code, { connectionId: connection.id, catalogEntryId: entry.id, execution });
      }
      if (error instanceof ToolGatewayHttpError) {
        throw new ToolGatewayHttpError(
          error.status,
          error.message,
          error.reasonCode,
          {
            ...error.details,
            execution: error.details.execution ?? execution,
          },
        );
      }
      if (error instanceof Error && error.name === "AbortError") {
        await markRemoteConnectionHealth(
          connection,
          "error",
          "Remote MCP tool call timed out.",
        );
        throw new ToolGatewayHttpError(
          504,
          "Remote MCP tool call timed out",
          "tool_timeout",
          {
            connectionId: connection.id,
            catalogEntryId: entry.id,
            execution,
          },
        );
      }
      await markRemoteConnectionHealth(
        connection,
        "error",
        "Remote MCP tool call failed.",
      );
      throw new ToolGatewayHttpError(
        502,
        "Remote MCP tool call failed",
        "mcp_remote_fetch_failed",
        {
          connectionId: connection.id,
          catalogEntryId: entry.id,
          execution,
        },
      );
    } finally {
      clearTimeout(timer);
      signal?.removeEventListener("abort", abort);
    }
  }

  async function executeLocalStdioTool(
    session: ToolGatewaySession,
    tool: ToolGatewayDescriptor,
    parameters: unknown,
    ms: number,
    useProviderDefaultTimeout = false,
    signal?: AbortSignal,
  ): Promise<RemoteHttpExecutionResult> {
    const { entry, connection } = await resolveConnectedLocalStdioTool(
      session,
      tool,
    );
    const template = await resolveLocalStdioRuntimeTemplate(connection);
    if (!(template.templateId === "paperclip.cognee-cloud" && entry.toolName === "forget")) {
      await assertExternalMcpModelEffects(session);
    }
    if (template.templateId === "paperclip.cognee-cloud" && ["remember", "recall"].includes(entry.toolName)) {
      await assertToolInternalInferenceAdmitted(session);
    }
    const grant = await resolveConnectionGrant(session, connection);
    const env = await localStdioEnvironment(
      session,
      connection,
      template,
      grant,
    );
    const invoke = () => callLocalStdioMcp({ connection, entry, template, env, parameters, signal,
      timeoutMs: useProviderDefaultTimeout && template.templateId === "paperclip.cognee-cloud" ? 60_000 : ms });
    // Cognee is a bundled HTTP client. Provider failures are tool failures, not
    // crashed local processes, and must never consume slots or restart budgets.
    const result = template.templateId === "paperclip.cognee-cloud"
      ? await invoke()
      : await runtimeSupervisor.useConnectionSlot(
      {
        companyId: session.companyId,
        applicationId: tool.applicationId ?? null,
        connectionId: connection.id,
          connectionKey: `mcp:${session.companyId}:${connection.id}:${session.id}`,
        runId: session.runId,
        issueId: session.issueId,
        agentId: session.agentId,
        commandTemplateKey: template.templateId,
        metadata: {
          fixture: "connected-local-stdio",
          applicationId: tool.applicationId ?? null,
          connectionId: connection.id,
          catalogEntryId: entry.id,
        },
      },
      async (handle) => {
        handle.appendLog("stdout", `calling ${entry.toolName}`);
        return invoke();
      },
    );
    return {
      result: normalizeMcpToolResult(result, template.templateId === "paperclip.cognee-cloud" ? "cognee_cloud" : "local_stdio", template.templateId !== "paperclip.cognee-cloud"),
    };
  }

  async function runWithTimeout<T>(
    promise: Promise<T>,
    ms: number,
  ): Promise<T> {
    let timer: ReturnType<typeof setTimeout> | null = null;
    try {
      return await Promise.race([
        promise,
        new Promise<T>((_resolve, reject) => {
          timer = setTimeout(() => {
            reject(
              new ToolGatewayHttpError(
                504,
                "Tool execution timed out",
                "tool_timeout",
              ),
            );
          }, ms);
          timer.unref?.();
        }),
      ]);
    } finally {
      if (timer) clearTimeout(timer);
    }
  }

  function gatewayEndpointPath(gatewayPublicId: string) {
    return `/mcp/gateways/${gatewayPublicId}`;
  }

  function gatewayClientSnippets(
    gateway: Pick<
      typeof toolMcpGateways.$inferSelect,
      "gatewayPublicId" | "name"
    >,
  ): ToolMcpGatewayClientSnippet[] {
    const endpoint = gatewayEndpointPath(gateway.gatewayPublicId);
    const bearerPlaceholder = "pcgw_...";
    return [
      {
        client: "cursor",
        label: "Cursor",
        config: {
          mcpServers: {
            [gateway.name]: {
              url: endpoint,
              headers: { Authorization: `Bearer ${bearerPlaceholder}` },
            },
          },
        },
        notes: ["Use the full Paperclip origin before the endpoint path."],
      },
      {
        client: "claude_desktop",
        label: "Claude Desktop",
        config: {
          mcpServers: {
            [gateway.name]: {
              url: endpoint,
              headers: { Authorization: `Bearer ${bearerPlaceholder}` },
            },
          },
        },
        notes: [
          "Recent Claude Desktop builds support remote HTTP MCP servers.",
        ],
      },
      {
        client: "vscode",
        label: "VS Code",
        config: {
          servers: {
            [gateway.name]: {
              type: "http",
              url: endpoint,
              headers: { Authorization: `Bearer ${bearerPlaceholder}` },
            },
          },
        },
        notes: ["Place this under your MCP extension or editor MCP settings."],
      },
      {
        client: "claude_code",
        label: "Claude Code",
        config: {
          command: "claude",
          args: [
            "mcp",
            "add",
            gateway.name,
            endpoint,
            "--header",
            `Authorization: Bearer ${bearerPlaceholder}`,
          ],
        },
        notes: [
          "Use the equivalent remote HTTP MCP add command for your installed version.",
        ],
      },
      {
        client: "opencode",
        label: "OpenCode",
        config: {
          mcp: {
            [gateway.name]: {
              url: endpoint,
              headers: { Authorization: `Bearer ${bearerPlaceholder}` },
            },
          },
        },
        notes: ["Use the full Paperclip origin before the endpoint path."],
      },
    ];
  }

  function toGateway(row: typeof toolMcpGateways.$inferSelect): ToolMcpGateway {
    return {
      id: row.id,
      companyId: row.companyId,
      gatewayPublicId: row.gatewayPublicId,
      name: row.name,
      displaySlug: row.displaySlug || row.slug,
      slug: row.slug,
      description: row.description,
      status: row.status,
      profileId: row.profileId,
      defaultProfileMode: row.defaultProfileMode,
      contextScopeType: row.contextScopeType,
      contextScopeId: row.contextScopeId,
      agentId: row.agentId,
      projectId: row.projectId,
      issueId: row.issueId,
      approvalIssueId: row.approvalIssueId,
      endpointPath: gatewayEndpointPath(row.gatewayPublicId),
      authConfig: row.authConfig,
      headerPolicy: row.headerPolicy,
      metadataPolicy: row.metadataPolicy,
      onDemandToolsConfig: row.onDemandToolsConfig,
      metadata: row.metadata ?? {},
      createdByAgentId: row.createdByAgentId,
      createdByUserId: row.createdByUserId,
      archivedAt: row.archivedAt,
      createdAt: row.createdAt,
      updatedAt: row.updatedAt,
    };
  }

  function toGatewayToken(
    row: typeof toolMcpGatewayTokens.$inferSelect,
  ): ToolMcpGatewayToken {
    return {
      id: row.id,
      companyId: row.companyId,
      gatewayId: row.gatewayId,
      name: row.name,
      tokenPrefix: row.tokenPrefix,
      subjectType: row.subjectType,
      subjectId: row.subjectId,
      clientLabel: row.clientLabel,
      ownerNote: row.ownerNote,
      allowedActions: row.allowedActions,
      expiresAt: row.expiresAt,
      expiryOverrideReason: row.expiryOverrideReason,
      expiryOverrideByUserId: row.expiryOverrideByUserId,
      expiryOverrideByAgentId: row.expiryOverrideByAgentId,
      expiryOverrideAt: row.expiryOverrideAt,
      lastUsedAt: row.lastUsedAt,
      revokedAt: row.revokedAt,
      createdByAgentId: row.createdByAgentId,
      createdByUserId: row.createdByUserId,
      createdAt: row.createdAt,
      updatedAt: row.updatedAt,
    };
  }

  async function getGatewayWithTokens(
    companyId: string,
    gatewayId: string,
  ): Promise<ToolMcpGatewayWithTokens> {
    const [gateway] = await db
      .select()
      .from(toolMcpGateways)
      .where(
        and(
          eq(toolMcpGateways.companyId, companyId),
          eq(toolMcpGateways.id, gatewayId),
        ),
      )
      .limit(1);
    if (!gateway) {
      throw new ToolGatewayHttpError(
        404,
        "MCP gateway not found",
        "gateway_not_found",
      );
    }
    const tokens = await db
      .select()
      .from(toolMcpGatewayTokens)
      .where(
        and(
          eq(toolMcpGatewayTokens.companyId, companyId),
          eq(toolMcpGatewayTokens.gatewayId, gatewayId),
        ),
      )
      .orderBy(desc(toolMcpGatewayTokens.createdAt));
    return {
      ...toGateway(gateway),
      tokens: tokens.map(toGatewayToken),
      clientSnippets: gatewayClientSnippets(gateway),
    };
  }

  async function assertGatewayContext(input: {
    companyId: string;
    profileId?: string | null;
    agentId?: string | null;
    projectId?: string | null;
    issueId?: string | null;
  }) {
    if (input.profileId) {
      const [profile] = await db
        .select({ id: toolProfiles.id })
        .from(toolProfiles)
        .where(
          and(
            eq(toolProfiles.companyId, input.companyId),
            eq(toolProfiles.id, input.profileId),
          ),
        )
        .limit(1);
      if (!profile)
        throw new ToolGatewayHttpError(
          422,
          "Gateway profile must belong to the company",
          "gateway_profile_invalid",
        );
    }
    if (input.agentId)
      await assertAgentInCompany(input.companyId, input.agentId);
    if (input.projectId) {
      const [project] = await db
        .select({ id: projects.id })
        .from(projects)
        .where(
          and(
            eq(projects.companyId, input.companyId),
            eq(projects.id, input.projectId),
          ),
        )
        .limit(1);
      if (!project)
        throw new ToolGatewayHttpError(
          422,
          "Gateway project must belong to the company",
          "gateway_project_invalid",
        );
    }
    if (input.issueId) {
      const [issue] = await db
        .select({ id: issues.id, projectId: issues.projectId })
        .from(issues)
        .where(
          and(
            eq(issues.companyId, input.companyId),
            eq(issues.id, input.issueId),
          ),
        )
        .limit(1);
      if (!issue)
        throw new ToolGatewayHttpError(
          422,
          "Gateway issue must belong to the company",
          "gateway_issue_invalid",
        );
      if (
        input.projectId &&
        issue.projectId &&
        issue.projectId !== input.projectId
      ) {
        throw new ToolGatewayHttpError(
          422,
          "Gateway issue must belong to the selected project",
          "gateway_issue_project_mismatch",
        );
      }
    }
  }

  async function findGatewayForProtocolLocator(input: {
    gatewayId?: string | null;
    gatewayPublicId?: string | null;
  }) {
    if (input.gatewayId) {
      const [gateway] = await db
        .select()
        .from(toolMcpGateways)
        .where(eq(toolMcpGateways.id, input.gatewayId))
        .limit(1);
      return gateway ?? null;
    }
    if (input.gatewayPublicId) {
      const [gateway] = await db
        .select()
        .from(toolMcpGateways)
        .where(eq(toolMcpGateways.gatewayPublicId, input.gatewayPublicId))
        .limit(1);
      return gateway ?? null;
    }
    return null;
  }

  function protocolLimiterKeyClass(method: McpGatewayProtocolMethod) {
    return method === "initialize" ? "session_setup" : method;
  }

  async function writeProtocolRateLimitAudit(input: {
    session: ToolGatewaySession;
    method: McpGatewayProtocolMethod;
    limiterKeyClass: "token" | "gateway";
    count: number;
    limit: McpGatewayRateLimitConfig;
    retryAfterMs: number;
    clientMetadata: ReturnType<typeof safeClientMetadata>;
  }) {
    await writeAudit({
      session: input.session,
      companyId: input.session.companyId,
      agentId: input.session.agentId,
      runId: input.session.runId,
      issueId: input.session.issueId,
      action: "tool_gateway.call_denied",
      details: {
        decision: "rate_limited",
        reasonCode: "gateway_rate_limited",
        reasonText:
          "The MCP gateway request was rate limited before the protocol action ran.",
        limiterKeyClass: input.limiterKeyClass,
        protocolMethod: input.method,
        protocolAction: protocolLimiterKeyClass(input.method),
        requestCount: input.count,
        limit: input.limit.max,
        windowMs: input.limit.windowMs,
        retryAfterMs: input.retryAfterMs,
        gatewayId: input.session.gatewayId ?? null,
        gatewayPublicId: input.session.gatewayPublicId ?? null,
        gatewayTokenId: input.session.gatewayTokenId ?? null,
        tokenPrefix:
          typeof input.session.gatewayTokenId === "string"
            ? `pcgw_${input.session.gatewayTokenId.slice(0, 8)}`
            : null,
        ...input.clientMetadata,
      },
    });
  }

  async function assertNamedGatewayProtocolLimit(
    session: ToolGatewaySession,
    method: McpGatewayProtocolMethod,
    clientMetadata: ReturnType<typeof safeClientMetadata>,
  ) {
    // The original authenticated gateway request owns the existing durable
    // counter. A configured company policy is additional to token/gateway
    // limits; entitlement or a paid tier never bypasses either gate.
    const resourceRate = (await currentResourcePolicy(db))?.rates.find(rule => rule.companyId === session.companyId);
    if (resourceRate) {
      const config = { max: resourceRate.hardLimit + resourceRate.burst, windowMs: resourceRate.windowMs };
      const state = await consumeProtocolRateLimit({ companyId: session.companyId,
        counterKey: "resource:gateway_request:company:v1", config });
      if (state.limited) {
        await writeProtocolRateLimitAudit({ session, method, limiterKeyClass: "gateway", count: state.count,
          limit: config, retryAfterMs: state.retryAfterMs, clientMetadata });
        throw new ToolGatewayHttpError(429, "Configured gateway request budget is occupied", "resource_gateway_request_limited",
          { resource: "gateway_request", retryAfterMs: state.retryAfterMs });
      }
    }
    const action = protocolLimiterKeyClass(method);
    const tokenLimit =
      method === "initialize"
        ? protocolLimits.sessionSetup
        : protocolLimits.tokenRequests;
    const tokenKey = `mcp_gateway_protocol:token:${session.gatewayTokenId ?? session.actorId ?? "unknown"}:${action}`;
    const tokenState = await consumeProtocolRateLimit({
      companyId: session.companyId,
      counterKey: tokenKey,
      config: tokenLimit,
    });
    if (tokenState.limited) {
      await writeProtocolRateLimitAudit({
        session,
        method,
        limiterKeyClass: "token",
        count: tokenState.count,
        limit: tokenLimit,
        retryAfterMs: tokenState.retryAfterMs,
        clientMetadata,
      });
      throw new ToolGatewayHttpError(
        429,
        "MCP gateway request was rate limited",
        "gateway_rate_limited",
        {
          reasonText:
            "The MCP gateway request was rate limited before the protocol action ran.",
          limiterKeyClass: "token",
          protocolMethod: method,
          retryAfterMs: tokenState.retryAfterMs,
        },
      );
    }

    const gatewayLimit =
      method === "initialize"
        ? protocolLimits.sessionSetup
        : protocolLimits.gatewayRequests;
    const gatewayKey = `mcp_gateway_protocol:gateway:${session.gatewayId ?? session.gatewayPublicId ?? "unknown"}:${action}`;
    const gatewayState = await consumeProtocolRateLimit({
      companyId: session.companyId,
      counterKey: gatewayKey,
      config: gatewayLimit,
    });
    if (gatewayState.limited) {
      await writeProtocolRateLimitAudit({
        session,
        method,
        limiterKeyClass: "gateway",
        count: gatewayState.count,
        limit: gatewayLimit,
        retryAfterMs: gatewayState.retryAfterMs,
        clientMetadata,
      });
      throw new ToolGatewayHttpError(
        429,
        "MCP gateway request was rate limited",
        "gateway_rate_limited",
        {
          reasonText:
            "The MCP gateway request was rate limited before the protocol action ran.",
          limiterKeyClass: "gateway",
          protocolMethod: method,
          retryAfterMs: gatewayState.retryAfterMs,
        },
      );
    }
  }

  async function recordNamedGatewayAuthFailure(input: {
    gatewayId?: string | null;
    gatewayPublicId?: string | null;
    bearerToken: string;
    reasonCode: string;
    clientMetadata: ReturnType<typeof safeClientMetadata>;
  }): Promise<never> {
    const token = input.bearerToken.trim();
    const tokenId = namedGatewayTokenId(token);
    const gatewayKey = input.gatewayId
      ? `id:${input.gatewayId}`
      : `public:${input.gatewayPublicId ?? "unknown"}`;
    const tokenKey = tokenId
      ? `id:${tokenId}`
      : `hash:${hashGatewayToken(token).slice(0, 24)}`;
    const gateway = await findGatewayForProtocolLocator(input);
    if (!gateway) {
      throw new ToolGatewayHttpError(
        401,
        "Gateway bearer token is expired or invalid",
        input.reasonCode,
      );
    }
    const gatewayState = await consumeProtocolRateLimit({
      companyId: gateway.companyId,
      counterKey: `mcp_gateway_auth_failure:gateway:${gatewayKey}`,
      config: protocolLimits.authFailures,
    });
    const tokenState = await consumeProtocolRateLimit({
      companyId: gateway.companyId,
      counterKey: `mcp_gateway_auth_failure:token:${gatewayKey}:${tokenKey}`,
      config: protocolLimits.authFailures,
    });
    const limited = gatewayState.limited || tokenState.limited;
    if (limited) {
      const limiterKeyClass = gatewayState.limited
        ? "gateway_auth"
        : "token_auth";
      const count = gatewayState.limited
        ? gatewayState.count
        : tokenState.count;
      const retryAfterMs = gatewayState.limited
        ? gatewayState.retryAfterMs
        : tokenState.retryAfterMs;
      await writeAudit({
        session: {
          id: `gateway:${gateway.id}`,
          token: "",
          companyId: gateway.companyId,
          agentId: gateway.agentId,
          runId: null,
          issueId: gateway.issueId,
          projectId: gateway.projectId,
          gatewayId: gateway.id,
          gatewayPublicId: gateway.gatewayPublicId,
          gatewayName: gateway.name,
          gatewayTokenId: null,
          actorType: "system",
          actorId: gateway.id,
          createdAt: new Date(),
          expiresAt: new Date(),
        },
        companyId: gateway.companyId,
        agentId: gateway.agentId,
        runId: null,
        issueId: gateway.issueId,
        action: "tool_gateway.session_rejected",
        details: {
          decision: "deny",
          reasonCode: "gateway_auth_throttled",
          reasonText:
            "The MCP gateway authentication attempt was throttled after repeated failures.",
          limiterKeyClass,
          failedReasonCode: input.reasonCode,
          requestCount: count,
          limit: protocolLimits.authFailures.max,
          windowMs: protocolLimits.authFailures.windowMs,
          retryAfterMs,
          gatewayId: gateway.id,
          gatewayPublicId: gateway.gatewayPublicId,
          tokenPrefix: tokenPrefixFromNamedBearer(token),
          ...input.clientMetadata,
        },
      });
    }
    if (limited) {
      throw new ToolGatewayHttpError(
        429,
        "MCP gateway authentication was throttled",
        "gateway_auth_throttled",
        {
          reasonText:
            "The MCP gateway authentication attempt was throttled after repeated failures.",
          retryAfterMs: Math.max(
            gatewayState.retryAfterMs,
            tokenState.retryAfterMs,
          ),
        },
      );
    }
    throw new ToolGatewayHttpError(
      401,
      "Gateway bearer token is expired or invalid",
      input.reasonCode,
    );
  }

  async function sandboxBrokerSessionFromBearer(input: {
    gatewayId?: string | null;
    gatewayPublicId?: string | null;
    bearerToken: string;
    protocolMethod: McpGatewayProtocolMethod;
    callerHeaders?: Record<string, string | string[] | undefined>;
  }): Promise<ToolGatewaySession | null> {
    const claims = verifySandboxBrokerJwt(input.bearerToken);
    if (!claims) return null;
    if (!sandboxBrokerAuthority || !input.gatewayPublicId) {
      throw new ToolGatewayHttpError(503, "Managed credential broker is unavailable", "sandbox_broker_unavailable");
    }
    const capability = await sandboxBrokerAuthority({ capabilityToken: input.bearerToken, gatewayPublicId: input.gatewayPublicId });
    if (stableHash(capability) !== stableHash(claims.sandbox_broker)) {
      throw new ToolGatewayHttpError(401, "Sandbox broker capability changed", "sandbox_broker_capability_invalid");
    }
    const selected = capability.bindings.find(binding => binding.gatewayPublicId === input.gatewayPublicId);
    if (!selected || selected.endpointPath !== `/mcp/gateways/${input.gatewayPublicId}` ||
      (input.gatewayId && !/^[0-9a-f-]{36}$/i.test(input.gatewayId))) {
      throw new ToolGatewayHttpError(403, "Sandbox broker capability does not include this Gateway", "sandbox_broker_gateway_denied");
    }
    const now = new Date();
    const [parent] = await db.select().from(runtimeHostCommands).where(and(
      eq(runtimeHostCommands.idempotencyKey, capability.parentRequestId),
      eq(runtimeHostCommands.companyId, claims.company_id),
      eq(runtimeHostCommands.runtimeCellId, capability.cellId),
      eq(runtimeHostCommands.cellGeneration, BigInt(capability.generation)),
      eq(runtimeHostCommands.commandType, "sandbox_exec"), eq(runtimeHostCommands.status, "CLAIMED"),
      gt(runtimeHostCommands.deadlineAt, now),
    )).limit(1);
    const parentPayload = parent?.payload as Record<string, unknown> | undefined;
    if (!parent || parentPayload?.bindingId !== capability.bindingId || parentPayload.hostId !== capability.hostId ||
      parentPayload.hostEpoch !== capability.hostEpoch || parentPayload.runId !== capability.runId ||
      parentPayload.attemptId !== capability.attemptId || parentPayload.attempt !== capability.attempt ||
      parentPayload.manifestId !== capability.manifestId || parentPayload.manifestHash !== capability.manifestHash ||
      parentPayload.policySnapshotId !== capability.policySnapshotId || parentPayload.policyHash !== capability.policyHash) {
      throw new ToolGatewayHttpError(403, "Parent sandbox execution is no longer current", "sandbox_broker_parent_fenced");
    }
    const [run] = await db.select({ agentId: heartbeatRuns.agentId, responsibleUserId: heartbeatRuns.responsibleUserId,
      issueId: heartbeatRuns.nativeIssueId, status: heartbeatRuns.status }).from(heartbeatRuns).where(and(
      eq(heartbeatRuns.companyId, claims.company_id), eq(heartbeatRuns.id, capability.runId),
    )).limit(1);
    if (!run || run.status !== "running" || run.agentId !== claims.sub ||
      !claims.responsible_user_id || run.responsibleUserId !== claims.responsible_user_id || !run.issueId) {
      throw new ToolGatewayHttpError(403, "Current responsible run is unavailable", "sandbox_broker_run_changed");
    }
    const [policy] = await db.select().from(runtimePolicySnapshots).where(and(
      eq(runtimePolicySnapshots.companyId, claims.company_id), eq(runtimePolicySnapshots.id, capability.policySnapshotId),
      eq(runtimePolicySnapshots.bindingId, capability.bindingId), eq(runtimePolicySnapshots.runtimeCellId, capability.cellId),
      eq(runtimePolicySnapshots.agentId, claims.sub), eq(runtimePolicySnapshots.executionManifestId, capability.manifestId),
      eq(runtimePolicySnapshots.policyHash, capability.policyHash), eq(runtimePolicySnapshots.status, "qualified"),
      gt(runtimePolicySnapshots.expiresAt, now),
    )).limit(1);
    const compiledPolicy = policy?.compilation.compiledPolicy;
    if (!policy || !compiledPolicy || compiledPolicy.credentials.mode !== "brokered") {
      throw new ToolGatewayHttpError(403, "Compiled credential broker policy is no longer current", "sandbox_broker_policy_changed");
    }
    const [presence] = await db.select().from(agentPresenceRuntimeBindings).where(and(
      eq(agentPresenceRuntimeBindings.companyId, claims.company_id), eq(agentPresenceRuntimeBindings.agentId, claims.sub),
      eq(agentPresenceRuntimeBindings.status, "active"),
    )).limit(1);
    if (!presence) throw new ToolGatewayHttpError(403, "Current local presence is unavailable", "sandbox_broker_presence_changed");
    const resolved = await createToolGatewayService(db).resolveSandboxCredentialBrokerBindings({
      companyId: claims.company_id, agentId: claims.sub, runId: capability.runId,
      responsibleUserId: claims.responsible_user_id, presenceId: presence.id,
      bindings: compiledPolicy.credentials.bindings,
    });
    if (resolved.bindings.length !== capability.bindings.length ||
      stableHash(resolved.bindings) !== stableHash(capability.bindings) ||
      compiledPolicy.credentials.bindings.some(binding => resolved.authorizedConnectionGrantHashes[binding.connectionId] !== binding.grantVersionHash)) {
      throw new ToolGatewayHttpError(403, "Current connector grant or secret revision changed", "sandbox_broker_grant_changed");
    }
    const [gateway] = await db.select().from(toolMcpGateways).where(and(
      eq(toolMcpGateways.companyId, claims.company_id), eq(toolMcpGateways.gatewayPublicId, input.gatewayPublicId),
      eq(toolMcpGateways.status, "active"), isNull(toolMcpGateways.archivedAt),
      ...(input.gatewayId ? [eq(toolMcpGateways.id, input.gatewayId)] : []),
    )).limit(1);
    if (!gateway) throw new ToolGatewayHttpError(404, "MCP gateway not found", "gateway_not_found");
    const [issue] = await db.select({ projectId: issues.projectId }).from(issues).where(and(
      eq(issues.companyId, claims.company_id), eq(issues.id, run.issueId), eq(issues.assigneeAgentId, claims.sub),
    )).limit(1);
    if (!issue) throw new ToolGatewayHttpError(403, "Current Task owner is unavailable", "sandbox_broker_task_changed");
    const session = await captureSessionIdentity({
      id: `sandbox-broker:${capability.brokerSessionId}`, token: "", companyId: claims.company_id,
      agentId: claims.sub, runId: capability.runId, issueId: run.issueId, projectId: issue.projectId,
      gatewayId: gateway.id, gatewayPublicId: gateway.gatewayPublicId, gatewayName: gateway.name,
      gatewayProfileId: gateway.profileId, gatewayTokenAllowedActions: ["tools/list", "tools/call"],
      actorType: "agent", actorId: claims.sub, responsibleUserId: claims.responsible_user_id,
      sandboxBrokerCapability: capability, createdAt: now, expiresAt: new Date(capability.expiresAt),
    });
    if (session.responsibleUserId !== claims.responsible_user_id) {
      throw new ToolGatewayHttpError(403, "Current execution identity changed", "sandbox_broker_identity_changed");
    }
    return session;
  }

  async function namedGatewaySessionFromBearer(input: {
    gatewayId?: string | null;
    gatewayPublicId?: string | null;
    bearerToken: string;
    protocolMethod: McpGatewayProtocolMethod;
    callerHeaders?: Record<string, string | string[] | undefined>;
  }): Promise<ToolGatewaySession> {
    const clientMetadata = safeClientMetadata(input.callerHeaders);
    const bearerToken = input.bearerToken.trim();
    const sandboxBroker = await sandboxBrokerSessionFromBearer({ ...input, bearerToken });
    if (sandboxBroker) return sandboxBroker;
    const tokenId = namedGatewayTokenId(bearerToken.trim());
    const tokenHash = hashGatewayToken(bearerToken.trim());
    const conditions = [eq(toolMcpGatewayTokens.tokenHash, tokenHash)];
    if (input.gatewayId)
      conditions.push(eq(toolMcpGatewayTokens.gatewayId, input.gatewayId));
    if (input.gatewayPublicId)
      conditions.push(
        eq(toolMcpGateways.gatewayPublicId, input.gatewayPublicId),
      );
    const [row] = await db
      .select({ gateway: toolMcpGateways, token: toolMcpGatewayTokens })
      .from(toolMcpGatewayTokens)
      .innerJoin(
        toolMcpGateways,
        eq(toolMcpGatewayTokens.gatewayId, toolMcpGateways.id),
      )
      .where(and(...conditions))
      .limit(1);
    if (!row) {
      await recordNamedGatewayAuthFailure({
        gatewayId: input.gatewayId,
        gatewayPublicId: input.gatewayPublicId,
        bearerToken,
        reasonCode: "gateway_token_invalid",
        clientMetadata,
      });
    }
    if (row.gateway.status !== "active") {
      await recordNamedGatewayAuthFailure({
        gatewayId: input.gatewayId,
        gatewayPublicId: input.gatewayPublicId,
        bearerToken,
        reasonCode: "gateway_disabled",
        clientMetadata,
      });
    }
    if (row.token.revokedAt) {
      await recordNamedGatewayAuthFailure({
        gatewayId: input.gatewayId,
        gatewayPublicId: input.gatewayPublicId,
        bearerToken,
        reasonCode: "gateway_token_revoked",
        clientMetadata,
      });
    }
    if (row.token.expiresAt && row.token.expiresAt.getTime() <= Date.now()) {
      await recordNamedGatewayAuthFailure({
        gatewayId: input.gatewayId,
        gatewayPublicId: input.gatewayPublicId,
        bearerToken,
        reasonCode: "gateway_token_expired",
        clientMetadata,
      });
    }
    let agentId = row.gateway.agentId;
    let runId: string | null = null;
    let responsibleUserId: string | null = null;
    let issueId = row.gateway.issueId;
    let projectId = row.gateway.projectId;
    if (row.token.subjectType === "heartbeat_run") {
      const tokenRunId = row.token.subjectId;
      if (!tokenRunId || !uuidPattern.test(tokenRunId)) {
        return recordNamedGatewayAuthFailure({
          gatewayId: input.gatewayId,
          gatewayPublicId: input.gatewayPublicId,
          bearerToken,
          reasonCode: "gateway_token_run_invalid",
          clientMetadata,
        });
      }
      const [run] = await db
        .select({
          companyId: heartbeatRuns.companyId,
          agentId: heartbeatRuns.agentId,
          status: heartbeatRuns.status,
          responsibleUserId: heartbeatRuns.responsibleUserId,
        })
        .from(heartbeatRuns)
        .where(eq(heartbeatRuns.id, tokenRunId))
        .limit(1);
      if (!run || run.companyId !== row.gateway.companyId) {
        return recordNamedGatewayAuthFailure({
          gatewayId: input.gatewayId,
          gatewayPublicId: input.gatewayPublicId,
          bearerToken,
          reasonCode: "gateway_token_run_invalid",
          clientMetadata,
        });
      }
      if (!ACTIVE_GATEWAY_RUN_STATUSES.has(run.status)) {
        return recordNamedGatewayAuthFailure({
          gatewayId: input.gatewayId,
          gatewayPublicId: input.gatewayPublicId,
          bearerToken,
          reasonCode: "gateway_token_run_inactive",
          clientMetadata,
        });
      }
      if (row.gateway.agentId && row.gateway.agentId !== run.agentId) {
        return recordNamedGatewayAuthFailure({
          gatewayId: input.gatewayId,
          gatewayPublicId: input.gatewayPublicId,
          bearerToken,
          reasonCode: "gateway_token_run_context_invalid",
          clientMetadata,
        });
      }
      try {
        const runContext = await resolveRunContext({
          companyId: row.gateway.companyId,
          agentId: run.agentId,
          runId: tokenRunId,
          issueId: row.gateway.issueId,
          projectId: row.gateway.projectId,
        });
        agentId = run.agentId;
        runId = tokenRunId;
        responsibleUserId = run.responsibleUserId;
        issueId = runContext.issueId;
        projectId = runContext.projectId;
      } catch {
        return recordNamedGatewayAuthFailure({
          gatewayId: input.gatewayId,
          gatewayPublicId: input.gatewayPublicId,
          bearerToken,
          reasonCode: "gateway_token_run_context_invalid",
          clientMetadata,
        });
      }
    }
    const now = new Date();
    await db
      .update(toolMcpGatewayTokens)
      .set({ lastUsedAt: now, updatedAt: now })
      .where(eq(toolMcpGatewayTokens.id, row.token.id));
    const session: ToolGatewaySession = {
      id: `gateway:${row.gateway.id}`,
      token: "",
      companyId: row.gateway.companyId,
      agentId,
      runId,
      issueId,
      projectId,
      gatewayId: row.gateway.id,
      gatewayPublicId: row.gateway.gatewayPublicId,
      gatewayName: row.gateway.name,
      gatewayProfileId: row.gateway.profileId,
      gatewayTokenId: row.token.id || tokenId,
      gatewayTokenAllowedActions: normalizeGatewayTokenActions(
        row.token.allowedActions,
      ),
      actorType: runId ? "agent" : "system",
      actorId: runId ? agentId : row.token.id,
      responsibleUserId,
      createdAt: row.token.createdAt,
      expiresAt:
        row.token.expiresAt ??
        new Date(Date.now() + 3650 * 24 * 60 * 60 * 1000),
    };
    await assertNamedGatewayProtocolLimit(
      session,
      input.protocolMethod,
      clientMetadata,
    );
    return captureSessionIdentity(session);
  }

  /**
   * A "test-origin" invocation is one created by the Apps → Test tab's
   * impersonated test call: an out-of-band `actorType: "user"` invocation with
   * no heartbeat run, issue, or gateway behind it. We key off the durable
   * invocation columns rather than audit metadata so the signal survives a
   * reload — and so the live test panel can drive an approved test call to
   * completion without a real agent run re-invoking it.
   */
  function isTestOriginInvocation(
    invocation: typeof toolInvocations.$inferSelect,
  ): boolean {
    return (
      invocation.actorType === "user" &&
      invocation.workflowRunId === null && invocation.workflowNodeId === null &&
      invocation.runId === null &&
      invocation.issueId === null &&
      invocation.gatewayId === null &&
      invocation.connectionId !== null
    );
  }

  /**
   * Execute an already-authorized test-tab tool call against the connected MCP
   * server and record the result/error onto the invocation. Shared by
   * {@link executeTestCall} (the allow path) and the approval-driven execution
   * of a parked ask-first request, so both produce identical persistence,
   * events, and audit entries.
   */
  async function runTestToolInvocation(args: {
    session: ToolGatewaySession;
    tool: ToolGatewayDescriptor;
    parameters: unknown;
    invocationId: string;
    companyId: string;
    agentId: string;
    userId: string;
    argumentsSummary: ReturnType<typeof summarizeToolValue>;
    reasonCode: string;
    matchedPolicyIds: string[];
    timeoutMs?: number;
  }): Promise<
    | { decision: "allowed"; invocationId: string; result: unknown }
    | {
        decision: "allowed";
        invocationId: string;
        error: { message: string; reasonCode: string };
      }
  > {
    await db
      .update(toolInvocations)
      .set({
        status: "executing",
        startedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(toolInvocations.id, args.invocationId));
    await writeAudit({
      session: args.session,
      companyId: args.companyId,
      agentId: args.agentId,
      runId: null,
      issueId: null,
      actorType: "user",
      actorId: args.userId,
      action: "tool_gateway.call_allowed",
      details: {
        source: "test",
        invocationId: args.invocationId,
        decision: "allow",
        reasonCode: args.reasonCode,
        matchedPolicyIds: args.matchedPolicyIds,
        tool: args.tool.name,
        ...toolAuditMetadata(args.tool),
        argumentsSummary: args.argumentsSummary,
      },
    });

    const startedAt = Date.now();
    try {
      const executionTimeoutMs = timeoutMs(args.timeoutMs);
      const connectedMcpExecution =
        args.tool.providerType === "mcp_remote_http"
          ? await executeRemoteHttpTool(
              args.session,
              args.tool,
              args.parameters,
              executionTimeoutMs,
              args.invocationId,
              undefined,
              args.timeoutMs === undefined,
            )
          : args.tool.providerType === "mcp_local_stdio"
            ? await executeLocalStdioTool(
                args.session,
                args.tool,
                args.parameters,
                executionTimeoutMs,
                args.timeoutMs === undefined,
              )
            : null;
      if (!connectedMcpExecution) {
        throw new ToolGatewayHttpError(
          404,
          `Tool "${args.tool.name}" not found`,
          "tool_not_found",
          {
            tool: args.tool.name,
          },
        );
      }
      const result = connectedMcpExecution.result;
      const resultValidation = validateToolContent({
        value: result,
        direction: "result",
        sensitiveMode: "redact",
        promptInjectionMode: "block",
      });
      const providerResult = asRecord(resultValidation.value);
      if (providerResult?.error) {
        throw new ToolGatewayHttpError(502, String(providerResult.content || providerResult.error),
          "tool_error", { execution: connectedMcpExecution.execution });
      }
      await db
        .update(toolInvocations)
        .set({
          status: "succeeded",
          resultHash: resultValidation.summary.sha256 ?? null,
          resultSummary: resultValidation.summary,
          resultSizeBytes: resultValidation.summary.sizeBytes ?? null,
          completedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(toolInvocations.id, args.invocationId));
      await writeToolCallEvent({
        invocationId: args.invocationId,
        session: args.session,
        eventType: "call_completed",
        outcome: "success",
        toolName: args.tool.name,
        policyDecision: "allow",
        reasonCode: "tool_completed",
        argumentsSummary: args.argumentsSummary,
        resultSummary: resultValidation.summary,
        metadata: {
          source: "test",
          headerSummary: connectedMcpExecution.headerSummary ?? undefined,
          execution: connectedMcpExecution.execution,
        },
        tool: args.tool,
      });
      await writeAudit({
        session: args.session,
        companyId: args.companyId,
        agentId: args.agentId,
        runId: null,
        issueId: null,
        actorType: "user",
        actorId: args.userId,
        action: "tool_gateway.call_completed",
        details: {
          source: "test",
          invocationId: args.invocationId,
          decision: "allow",
          reasonCode: "tool_completed",
          tool: args.tool.name,
          ...toolAuditMetadata(args.tool),
          durationMs: Date.now() - startedAt,
          argumentsSummary: args.argumentsSummary,
          result: summarizeResult(resultValidation.value),
          resultSummary: resultValidation.summary,
          headerSummary: connectedMcpExecution.headerSummary ?? undefined,
          execution: connectedMcpExecution.execution,
        },
      });
      // After the bookkeeping above: a throw there is caught below, overwrites
      // the row to failed, and emits — an earlier success emit would make one
      // execution report both outcomes.
      void emitConnectionInvoked(db, args.invocationId);
      return {
        decision: "allowed" as const,
        invocationId: args.invocationId,
        result: resultValidation.value,
      };
    } catch (err) {
      const status = err instanceof ToolGatewayHttpError ? err.status : 502;
      const reasonCode =
        err instanceof ToolContentValidationError
          ? err.reasonCode
          : err instanceof ToolGatewayHttpError
            ? err.reasonCode
            : "tool_execution_failed";
      const message = err instanceof Error ? err.message : String(err);
      await db
        .update(toolInvocations)
        .set({
          status:
            status === 504
              ? "timed_out"
              : status === 429
                ? "rate_limited"
                : "failed",
          errorCode: reasonCode,
          errorMessage: message,
          completedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(toolInvocations.id, args.invocationId));
      void emitConnectionInvoked(db, args.invocationId);
      await writeToolCallEvent({
        invocationId: args.invocationId,
        session: args.session,
        eventType: "call_failed",
        outcome: status === 504 ? "timeout" : "failure",
        toolName: args.tool.name,
        policyDecision: status === 504 ? "defer_runtime" : "deny",
        reasonCode,
        argumentsSummary: args.argumentsSummary,
        metadata: {
          source: "test",
          ...(err instanceof ToolContentValidationError
            ? { findings: err.findings }
            : {}),
          ...(executionAuditFromError(err)
            ? { execution: executionAuditFromError(err) }
            : {}),
        },
        tool: args.tool,
      });
      await writeAudit({
        session: args.session,
        companyId: args.companyId,
        agentId: args.agentId,
        runId: null,
        issueId: null,
        actorType: "user",
        actorId: args.userId,
        action:
          status === 504
            ? "tool_gateway.call_deferred"
            : "tool_gateway.call_failed",
        details: {
          source: "test",
          invocationId: args.invocationId,
          decision: status === 504 ? "defer_runtime" : "deny",
          reasonCode,
          tool: args.tool.name,
          ...toolAuditMetadata(args.tool),
          argumentsSummary: args.argumentsSummary,
          durationMs: Date.now() - startedAt,
          error: message,
          ...(executionAuditFromError(err)
            ? { execution: executionAuditFromError(err) }
            : {}),
        },
      });
      return {
        decision: "allowed" as const,
        invocationId: args.invocationId,
        error: { message, reasonCode },
        ...(err instanceof ToolGatewayHttpError && err.reasonCode === "provider_interaction_required"
          ? { upstreamPending: err.details.upstreamPending as ToolUpstreamPending }
          : {}),
      };
    }
  }

  /**
   * Drive a freshly-approved test-origin ask-first request to completion. The
   * Test tab has no agent run to re-invoke the parked call, so approving it in
   * the Review tab is what executes it — the live status panel then surfaces the
   * real result. Reconstructs the impersonated test session and the signed
   * arguments, and never throws: any failure is recorded on the invocation so it
   * shows up as an error in the panel rather than rolling back the approval.
   */
  async function runApprovedTestInvocation(
    invocation: typeof toolInvocations.$inferSelect,
    parameters: unknown,
    actionRequestId: string,
  ): Promise<void> {
    const agentId = invocation.agentId;
    if (!invocation.connectionId || !agentId) return;
    const userId = invocation.actorId ?? "board";
    const session: ToolGatewaySession = {
      id: "test-call",
      token: "test-call",
      companyId: invocation.companyId,
      agentId,
      runId: null,
      issueId: null,
      projectId: null,
      actorType: "user",
      actorId: userId,
      responsibleUserId: userId,
      createdAt: new Date(),
      expiresAt: new Date(Date.now() + DEFAULT_SESSION_TTL_MS),
    };
    let tool: ToolGatewayDescriptor | undefined;
    try {
      tool = (
        await connectedMcpToolsForConnection(
          invocation.companyId,
          invocation.connectionId,
        )
      ).find(
        (candidate) =>
          candidate.name === invocation.toolName ||
          candidate.upstreamToolName === invocation.toolName,
      );
    } catch {
      tool = undefined;
    }
    if (!tool) {
      await db
        .update(toolInvocations)
        .set({
          status: "failed",
          errorCode: "tool_not_found",
          errorMessage: `Tool "${invocation.toolName}" is no longer connected`,
          completedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(toolInvocations.id, invocation.id));
      void emitConnectionInvoked(db, invocation.id);
      await reflectToolActionInteractionLifecycle({
        actionRequestId,
        status: "failed",
        errorCode: "tool_not_found",
        errorMessage: `Tool "${invocation.toolName}" is no longer connected`,
      });
      return;
    }
    const argumentsSummary = validateToolContent({
      value: parameters,
      direction: "arguments",
      sensitiveMode: "redact",
      promptInjectionMode: "ignore",
    }).summary;
    try {
      await runTestToolInvocation({
        session,
        tool,
        parameters,
        invocationId: invocation.id,
        companyId: invocation.companyId,
        agentId,
        userId,
        argumentsSummary,
        reasonCode: "approval_granted",
        matchedPolicyIds: invocation.matchedPolicyIds ?? [],
      });
      await reflectToolActionInteractionLifecycle({
        actionRequestId,
        status: "executed",
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      await db
        .update(toolInvocations)
        .set({
          status: "failed",
          errorCode: "tool_execution_failed",
          errorMessage: message,
          completedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(toolInvocations.id, invocation.id));
      void emitConnectionInvoked(db, invocation.id);
      await reflectToolActionInteractionLifecycle({
        actionRequestId,
        status: "failed",
        errorCode: "tool_execution_failed",
        errorMessage: message,
      });
    }
  }

  async function waitForActionRequestExecution(actionRequestId: string) {
    let deadline = Date.now() + ACTION_REQUEST_EXECUTION_WAIT_MS;
    while (true) {
      const [match] = await db
        .select({
          actionRequest: toolActionRequests,
          invocationStatus: toolInvocations.status,
          invocationStartedAt: toolInvocations.startedAt,
        })
        .from(toolActionRequests)
        .innerJoin(
          toolInvocations,
          eq(toolInvocations.id, toolActionRequests.invocationId),
        )
        .where(eq(toolActionRequests.id, actionRequestId))
        .limit(1);
      const row = match?.actionRequest;
      if (!row || row.status !== "executing") return row ?? null;
      deadline = extendApprovedExecutionWaitDeadline({
        currentDeadlineMs: deadline,
        invocationStatus: match.invocationStatus,
        invocationStartedAt: match.invocationStartedAt,
        preparationStartedAt: row.updatedAt,
        preparationWaitMs: ACTION_REQUEST_PREPARATION_WAIT_MS,
        executionWaitMs: ACTION_REQUEST_EXECUTION_WAIT_MS,
      });
      const remainingMs = deadline - Date.now();
      if (remainingMs <= 0) break;
      await new Promise((resolve) =>
        setTimeout(
          resolve,
          Math.min(ACTION_REQUEST_EXECUTION_POLL_MS, remainingMs),
        ),
      );
    }
    throw new ToolGatewayHttpError(
      409,
      "Approved tool action is still executing",
      "action_execution_in_progress",
      {
        actionRequestId,
        preparationWaitMs: ACTION_REQUEST_PREPARATION_WAIT_MS,
        executionWaitMs: ACTION_REQUEST_EXECUTION_WAIT_MS,
      },
    );
  }

  function storedInvocationResult(
    invocation: typeof toolInvocations.$inferSelect,
  ): unknown {
    const summary = invocation.resultSummary?.summary;
    if (typeof summary !== "string") return null;
    try {
      return JSON.parse(summary);
    } catch {
      return summary;
    }
  }

  async function actionRequestResolution(
    actionRequest: typeof toolActionRequests.$inferSelect,
  ) {
    if (
      actionRequest.status !== "executed" &&
      actionRequest.status !== "failed"
    )
      return actionRequest;
    const [invocation] = await db
      .select()
      .from(toolInvocations)
      .where(eq(toolInvocations.id, actionRequest.invocationId))
      .limit(1);
    return {
      ...actionRequest,
      resultSummary: invocation?.resultSummary?.summary ?? null,
      error: invocation?.errorMessage ?? null,
    };
  }

  async function markApprovedActionFailed(input: {
    actionRequestId: string;
    invocationId: string;
    claimUpdatedAt: Date;
    expectedInvocationStatus: "awaiting_approval" | "executing";
    error: unknown;
  }) {
    const reasonCode =
      input.error instanceof ToolGatewayHttpError
        ? input.error.reasonCode
        : "tool_execution_failed";
    const message =
      input.error instanceof Error ? input.error.message : String(input.error);
    const now = new Date();
    const settled = await db.transaction(async (tx) => {
      // Lock in the same invocation -> request order used by the normal
      // execution settlement path. The claim timestamp is the ownership token:
      // a consumer that merely read an approved row cannot settle another
      // consumer's claim, and a pre-dispatch failure cannot overwrite a call
      // that has already entered provider execution or completed successfully.
      const [invocation] = await tx
        .select({ status: toolInvocations.status })
        .from(toolInvocations)
        .where(eq(toolInvocations.id, input.invocationId))
        .for("update")
        .limit(1);
      if (invocation?.status !== input.expectedInvocationStatus) return false;

      const [actionRequest] = await tx
        .select({
          status: toolActionRequests.status,
          updatedAt: toolActionRequests.updatedAt,
        })
        .from(toolActionRequests)
        .where(eq(toolActionRequests.id, input.actionRequestId))
        .for("update")
        .limit(1);
      if (
        actionRequest?.status !== "executing" ||
        actionRequest.updatedAt.getTime() !== input.claimUpdatedAt.getTime()
      ) {
        return false;
      }

      await tx
        .update(toolInvocations)
        .set({
          status: "failed",
          idempotencyKey: null,
          errorCode: reasonCode,
          errorMessage: message,
          completedAt: now,
          updatedAt: now,
        })
        .where(
          and(
            eq(toolInvocations.id, input.invocationId),
            eq(toolInvocations.status, input.expectedInvocationStatus),
          ),
        );
      await tx
        .update(toolActionRequests)
        .set({
          status: "failed",
          resolvedAt: now,
          updatedAt: now,
        })
        .where(
          and(
            eq(toolActionRequests.id, input.actionRequestId),
            eq(toolActionRequests.status, "executing"),
            eq(toolActionRequests.updatedAt, input.claimUpdatedAt),
          ),
        );
      return true;
    });
    if (!settled) return { reasonCode, message, settled: false };
    void emitConnectionInvoked(db, input.invocationId);
    await reflectToolActionInteractionLifecycle({
      actionRequestId: input.actionRequestId,
      status: "failed",
      errorCode: reasonCode,
      errorMessage: message,
    });
    return { reasonCode, message, settled: true };
  }

  async function expireApprovedActionForManagedArgumentDrift(input: {
    actionRequestId: string;
    invocationId: string;
    toolName: string;
    ownsExecutingClaim?: boolean;
  }) {
    const error = new ToolGatewayHttpError(
      409,
      "Approved tool action managed arguments changed after review; request a new approval",
      "approved_tool_managed_arguments_changed",
      {
        actionRequestId: input.actionRequestId,
        invocationId: input.invocationId,
        tool: input.toolName,
      },
    );
    const now = new Date();
    await options.beforeManagedArgumentDriftExpiry?.();
    const [expired] = await db
      .update(toolActionRequests)
      .set({ status: "expired", resolvedAt: now, updatedAt: now })
      .where(
        and(
          eq(toolActionRequests.id, input.actionRequestId),
          input.ownsExecutingClaim
            ? inArray(toolActionRequests.status, ["approved", "executing"])
            : eq(toolActionRequests.status, "approved"),
        ),
      )
      .returning({ id: toolActionRequests.id });
    if (!expired) return error;
    await db
      .update(toolInvocations)
      .set({
        status: "failed",
        approvalState: "expired",
        idempotencyKey: null,
        errorCode: error.reasonCode,
        errorMessage: error.message,
        completedAt: now,
        updatedAt: now,
      })
      .where(eq(toolInvocations.id, input.invocationId));
    void emitConnectionInvoked(db, input.invocationId);
    await reflectToolActionInteractionLifecycle({
      actionRequestId: expired.id,
      status: "expired",
      errorCode: error.reasonCode,
      errorMessage: error.message,
    });
    return error;
  }

  // Guard for approved-action execution: the issue must still be open. Expires
  // the claimed request and reflects the interaction lifecycle when it is not.
  // Called twice — after winning the executing claim, and again immediately
  // before provider dispatch, because tool/snapshot resolution between the two
  // involves network calls and leaves a seconds-wide window for the issue to
  // close.
  async function workflowApprovedActionSession(invocation: typeof toolInvocations.$inferSelect) {
    if (!invocation.workflowRunId || !invocation.workflowNodeId) {
      throw new ToolGatewayHttpError(409, "Workflow action binding is unavailable", "workflow_connector_binding_invalid");
    }
    const { session } = await resolveWorkflowConnectorSession(db, {
      companyId: invocation.companyId, workflowRunId: invocation.workflowRunId,
      nodeId: invocation.workflowNodeId, approvalInvocationId: invocation.id,
    }, invocation.idempotencyKey, options.deploymentMode);
    if (session.actorType !== invocation.actorType || session.actorId !== invocation.actorId) {
      throw new ToolGatewayHttpError(409, "Workflow action authority changed", "workflow_connector_binding_invalid");
    }
    return session;
  }

  async function assertIssueOpenForApprovedAction(input: {
    claimed: typeof toolActionRequests.$inferSelect;
    invocation: typeof toolInvocations.$inferSelect;
  }): Promise<{ projectId: string | null }> {
    const { claimed, invocation } = input;
    if (invocation.workflowRunId) {
      try {
        const session = await workflowApprovedActionSession(invocation);
        if (!invocation.issueId) return { projectId: session.projectId };
      } catch (error) {
        await markApprovedActionFailed({ actionRequestId: claimed.id, invocationId: invocation.id,
          claimUpdatedAt: claimed.updatedAt, expectedInvocationStatus: "awaiting_approval",
          error: error instanceof Error ? error : new Error("Workflow review is no longer active") });
        throw error;
      }
    }
    const [issue] = await db
      .select({ status: issues.status, projectId: issues.projectId })
      .from(issues)
      .where(
        and(
          eq(issues.id, invocation.issueId!),
          eq(issues.companyId, invocation.companyId),
        ),
      )
      .limit(1);
    if (issue && issue.status !== "done" && issue.status !== "cancelled") {
      return { projectId: issue.projectId };
    }
    const expiredAt = new Date();
    await db
      .update(toolActionRequests)
      .set({ status: "expired", resolvedAt: expiredAt, updatedAt: expiredAt })
      .where(eq(toolActionRequests.id, claimed.id));
    await reflectToolActionInteractionLifecycle({
      actionRequestId: claimed.id,
      status: "expired",
    });
    throw new ToolGatewayHttpError(
      409,
      "The issue for this tool action is closed; the approval has expired",
      "action_issue_closed",
      { actionRequestId: claimed.id, invocationId: invocation.id },
    );
  }

  async function restoreApprovedActionIdentity(
    session: ToolGatewaySession,
    identityContextId: string | undefined,
  ) {
    if (!identityContextId) return;
    const [origin] = await db
      .select()
      .from(runIdentityContexts)
      .where(
        and(
          eq(runIdentityContexts.id, identityContextId),
          eq(runIdentityContexts.companyId, session.companyId),
          eq(runIdentityContexts.runId, session.runId!),
          eq(runIdentityContexts.status, "accepted"),
        ),
      );
    if (!origin)
      throw new ToolGatewayHttpError(
        409,
        "Approved action identity is unavailable",
        "identity_context_unavailable",
      );
    session.identityContextId = origin.id;
    session.responsibleUserId =
      origin.cause === "company_default" ? null : origin.responsibleUserId;
  }

  async function executeApprovedAgentInvocation(input: {
    actionRequest: typeof toolActionRequests.$inferSelect;
    invocation: typeof toolInvocations.$inferSelect;
  }) {
    const { actionRequest, invocation } = input;
    if (
      (!invocation.workflowRunId && (!invocation.agentId || !invocation.issueId)) ||
      (invocation.workflowNodeId !== null && invocation.workflowRunId === null) ||
      isTestOriginInvocation(invocation)
    ) {
      throw new ToolGatewayHttpError(
        409,
        "Tool action request is not an agent-origin action",
        "action_origin_invalid",
      );
    }

    const [claimed] = await db
      .update(toolActionRequests)
      .set({ status: "executing", updatedAt: new Date() })
      .where(
        and(
          eq(toolActionRequests.id, actionRequest.id),
          eq(toolActionRequests.status, "approved"),
        ),
      )
      .returning();
    if (!claimed) {
      const settled = await waitForActionRequestExecution(actionRequest.id);
      const [settledInvocation] = await db
        .select()
        .from(toolInvocations)
        .where(eq(toolInvocations.id, invocation.id))
        .limit(1);
      if (settled?.status === "executed" && settledInvocation) {
        return storedInvocationResult(settledInvocation);
      }
      if (settled?.status === "failed") {
        throw new ToolGatewayHttpError(
          502,
          settledInvocation?.errorMessage ?? "Approved tool action failed",
          settledInvocation?.errorCode ?? "tool_execution_failed",
          { actionRequestId: actionRequest.id, invocationId: invocation.id },
        );
      }
      throw new ToolGatewayHttpError(
        409,
        "Tool action request was already consumed",
        "action_already_consumed",
      );
    }

    // Terminal-issue expiry revokes pending/approved requests, but a claim that
    // committed just before the issue closed slips past that revocation. Recheck
    // the issue after winning the claim so a governed action never runs external
    // side effects for an issue that is already done or cancelled.
    const issue = await assertIssueOpenForApprovedAction({
      claimed,
      invocation,
    });

    const signedPayload = readSignedToolArgumentsPayload({
      signedArguments: claimed.signedArguments,
      invocationId: invocation.id,
      toolName: invocation.toolName,
      signingSecret: options.toolActionSigningSecret,
    });
    if (!signedPayload) {
      const error = new ToolGatewayHttpError(
        409,
        "Approved tool action arguments signature is invalid",
        "signed_arguments_invalid",
      );
      await markApprovedActionFailed({
        actionRequestId: claimed.id,
        invocationId: invocation.id,
        claimUpdatedAt: claimed.updatedAt,
        expectedInvocationStatus: "awaiting_approval",
        error,
      });
      throw error;
    }
    if (signedPayload.executionOnApprove !== true) {
      const error = new ToolGatewayHttpError(
        409,
        "This approval predates execute-on-approve and must remain inert",
        "legacy_approved_action_inert",
      );
      await markApprovedActionFailed({
        actionRequestId: claimed.id,
        invocationId: invocation.id,
        claimUpdatedAt: claimed.updatedAt,
        expectedInvocationStatus: "awaiting_approval",
        error,
      });
      throw error;
    }

    const session: ToolGatewaySession = invocation.workflowRunId
      ? await workflowApprovedActionSession(invocation)
      : {
      id: `approved-action:${claimed.id}`,
      token: "",
      companyId: invocation.companyId,
      agentId: invocation.agentId,
      runId: invocation.runId,
      issueId: invocation.issueId,
      projectId: issue?.projectId ?? null,
      gatewayId: invocation.gatewayId,
      gatewayPublicId: invocation.gatewayPublicId,
      gatewayTokenId: invocation.gatewayTokenId,
      actorType: "agent",
      actorId: invocation.agentId,
      createdAt: new Date(),
      expiresAt: new Date(Date.now() + DEFAULT_SESSION_TTL_MS),
    };
    let tool: ToolGatewayDescriptor;
    let liveApprovalSnapshot: Awaited<
      ReturnType<typeof connectedRemoteApprovalSnapshot>
    >;
    try {
      await restoreApprovedActionIdentity(
        session,
        signedPayload.identityContextId,
      );
      session.approvedSlackInvocationId = invocation.id;
      tool = await findToolForSession(session, invocation.toolName);
      liveApprovalSnapshot = await connectedRemoteApprovalSnapshot(
        session,
        tool,
      );
      const currentAccess = await policyService.decide(
        policyInputForTool({
          session,
          tool,
          parameters: signedPayload.arguments,
        }),
      );
      if (
        !currentAccess.allowed &&
        currentAccess.decision !== "require_approval"
      )
        throw new ToolGatewayHttpError(
          403,
          currentAccess.explanation,
          currentAccess.reasonCode,
        );
    } catch (error) {
      await markApprovedActionFailed({
        actionRequestId: claimed.id,
        invocationId: invocation.id,
        claimUpdatedAt: claimed.updatedAt,
        expectedInvocationStatus: "awaiting_approval",
        error,
      });
      throw error;
    }
    if (
      !approvalSnapshotsMatch(
        signedPayload.approvalSnapshot,
        liveApprovalSnapshot,
      )
    ) {
      const error = new ToolGatewayHttpError(
        409,
        "Approved tool action target changed after review",
        "approved_tool_target_changed",
      );
      await markApprovedActionFailed({
        actionRequestId: claimed.id,
        invocationId: invocation.id,
        claimUpdatedAt: claimed.updatedAt,
        expectedInvocationStatus: "awaiting_approval",
        error,
      });
      throw error;
    }
    const parameters = signedPayload.arguments;
    const canonicalArguments = canonicalToolArguments(parameters);
    if (
      claimed.canonicalArgumentsHash !==
        summarizeToolValue(parameters).sha256 ||
      !verifyToolArgumentsSignature({
        signedArguments: claimed.signedArguments,
        invocationId: invocation.id,
        toolName: invocation.toolName,
        canonicalArguments,
        approvalSnapshot: signedPayload.approvalSnapshot,
        executionOnApprove: true,
        identityContextId: signedPayload.identityContextId,
        signingSecret: options.toolActionSigningSecret,
      })
    ) {
      const error = new ToolGatewayHttpError(
        409,
        "Approved tool action arguments do not match reviewed hash",
        "signed_arguments_mismatch",
      );
      await markApprovedActionFailed({
        actionRequestId: claimed.id,
        invocationId: invocation.id,
        claimUpdatedAt: claimed.updatedAt,
        expectedInvocationStatus: "awaiting_approval",
        error,
      });
      throw error;
    }
    let managedArgumentsRemainCurrent: boolean;
    try {
      managedArgumentsRemainCurrent =
        await approvedManagedArgumentsRemainCurrent(session, tool, parameters);
    } catch (error) {
      await markApprovedActionFailed({
        actionRequestId: claimed.id,
        invocationId: invocation.id,
        claimUpdatedAt: claimed.updatedAt,
        expectedInvocationStatus: "awaiting_approval",
        error,
      });
      throw error;
    }
    if (!managedArgumentsRemainCurrent) {
      throw await expireApprovedActionForManagedArgumentDrift({
        actionRequestId: claimed.id,
        invocationId: invocation.id,
        toolName: invocation.toolName,
        ownsExecutingClaim: true,
      });
    }

    const argumentsSummary = validateToolContent({
      value: parameters,
      direction: "arguments",
      sensitiveMode: "redact",
      promptInjectionMode: "ignore",
    }).summary;
    // Final recheck at the last DB write before dispatch: tool and snapshot
    // resolution above involve network calls, so re-verify the issue is still
    // open now that only the provider call remains. A close that commits after
    // this read has raced an execution that was approved, claimed, and verified
    // while the issue was open; that instant is irreducible for an external
    // side effect gated by DB state (holding a DB lock across a remote provider
    // call is not an option), and the accepted linearization is that the
    // execution wins — its result still lands on the expired card via
    // reflectToolActionInteractionLifecycle.
    await assertIssueOpenForApprovedAction({ claimed, invocation });

    const startedAt = Date.now();
    await db
      .update(toolInvocations)
      .set({
        status: "executing",
        approvalState: "approved",
        startedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(toolInvocations.id, invocation.id));
    await reflectToolActionInteractionLifecycle({
      actionRequestId: claimed.id,
      status: "executing",
    });

    try {
      const executionTimeoutMs = timeoutMs(APPROVED_EXECUTION_TIMEOUT_MS);
      const result =
        tool.providerType === "mcp_remote_http"
          ? (
              await executeRemoteHttpTool(
                session,
                tool,
                parameters,
                executionTimeoutMs,
                invocation.id,
              )
            ).result
          : tool.providerType === "mcp_local_stdio"
            ? (
                await executeLocalStdioTool(
                  session,
                  tool,
                  parameters,
                  executionTimeoutMs,
                )
              ).result
            : tool.providerType !== "paperclip_plugin"
              ? await runWithTimeout(
                  executeBuiltinTool(session, tool, parameters, invocation.id),
                  executionTimeoutMs,
                )
              : (() => {
                  throw new ToolGatewayHttpError(
                    409,
                    "Plugin actions cannot execute outside their originating run",
                    "approved_execution_unsupported",
                  );
                })();
      const resultRecord = asRecord(result);
      if (resultRecord?.error)
        throw new ToolGatewayHttpError(
          502,
          String(resultRecord.content || resultRecord.error),
          "tool_execution_failed",
        );
      const resultValidation = validateToolContent({
        value: result,
        direction: "result",
        sensitiveMode: "redact",
        promptInjectionMode: "block",
      });
      const now = new Date();
      await db
        .update(toolInvocations)
        .set({
          status: "succeeded",
          resultHash: resultValidation.summary.sha256 ?? null,
          resultSummary: resultValidation.summary,
          resultSizeBytes: resultValidation.summary.sizeBytes ?? null,
          workflowResultJson: session.workflowRunId ? typedWorkflowToolResult(tool, resultValidation.value) : null,
          completedAt: now,
          updatedAt: now,
        })
        .where(eq(toolInvocations.id, invocation.id));
      void emitConnectionInvoked(db, invocation.id);
      await db
        .update(toolActionRequests)
        .set({ status: "executed", resolvedAt: now, updatedAt: now })
        .where(eq(toolActionRequests.id, claimed.id));
      await reflectToolActionInteractionLifecycle({
        actionRequestId: claimed.id,
        status: "executed",
        resultSummary: resultValidation.summary.summary,
      });
      await writeToolCallEvent({
        invocationId: invocation.id,
        actionRequestId: claimed.id,
        session,
        eventType: "call_completed",
        outcome: "success",
        toolName: tool.name,
        policyDecision: "allow",
        reasonCode: "approved_action_executed",
        argumentsSummary,
        resultSummary: resultValidation.summary,
        metadata: {
          durationMs: Date.now() - startedAt,
          timeoutMs: executionTimeoutMs,
        },
        tool,
      });
      return resultValidation.value;
    } catch (error) {
      const { reasonCode } = await markApprovedActionFailed({
        actionRequestId: claimed.id,
        invocationId: invocation.id,
        claimUpdatedAt: claimed.updatedAt,
        expectedInvocationStatus: "executing",
        error,
      });
      await writeToolCallEvent({
        invocationId: invocation.id,
        actionRequestId: claimed.id,
        session,
        eventType: "call_failed",
        outcome: "failure",
        toolName: tool.name,
        policyDecision: "deny",
        reasonCode,
        argumentsSummary,
        metadata: { durationMs: Date.now() - startedAt },
        tool,
      });
      throw error;
    }
  }

  async function matchingAgentActionRequest(input: {
    session: ToolGatewaySession;
    toolName: string;
    argumentsHash: string;
  }) {
    if (!input.session.issueId || !input.session.agentId) return null;
    const [match] = await db
      .select({
        actionRequest: toolActionRequests,
        invocation: toolInvocations,
      })
      .from(toolActionRequests)
      .innerJoin(
        toolInvocations,
        eq(toolInvocations.id, toolActionRequests.invocationId),
      )
      .where(
        and(
          eq(toolActionRequests.companyId, input.session.companyId),
          eq(toolActionRequests.issueId, input.session.issueId),
          eq(toolActionRequests.canonicalArgumentsHash, input.argumentsHash),
          eq(toolInvocations.agentId, input.session.agentId),
          eq(toolInvocations.toolName, input.toolName),
          inArray(toolActionRequests.status, [
            "pending",
            "approved",
            "executing",
            "rejected",
            "executed",
            "failed",
          ]),
        ),
      )
      .orderBy(desc(toolActionRequests.createdAt))
      .limit(1);
    if (!match) return null;
    if (match.actionRequest.status === "failed" && match.invocation.errorCode !== "provider_interaction_required") return null;
    // The gateway builds an ask-first request in two steps inside one call: it
    // inserts the row with a null signature and a null expiry, then signs the
    // row and sets the expiry. A concurrent matching call can observe the row in
    // this window. A null signature does not prove the create stopped, because a
    // parallel create can still be signing the same row right now. Only treat an
    // unsigned row as abandoned after the grace time from createdAt has passed;
    // before that, return the match so the retry replays approval_required and
    // does not create a duplicate request or expire a live row. After the grace
    // time an unsigned row stays pending forever and the review queue hides it,
    // so it can never be approved. Do not replay it as a live approval. Expire
    // the row and let the retry create a fresh, signable request. A null expiry
    // alone (without this guard) also makes the getTime() check below unsafe.
    const pendingRequest = match.actionRequest;
    const pendingUnsigned =
      pendingRequest.status === "pending" &&
      pendingRequest.signedArguments === null &&
      Date.now() - pendingRequest.createdAt.getTime() >=
        TOOL_ACTION_REQUEST_SIGNING_GRACE_MS;
    const pendingExpired =
      pendingRequest.status === "pending" &&
      pendingRequest.expiresAt !== null &&
      pendingRequest.expiresAt.getTime() <= Date.now();
    if (pendingUnsigned || pendingExpired) {
      const now = new Date();
      await db
        .update(toolActionRequests)
        .set({ status: "expired", resolvedAt: now, updatedAt: now })
        .where(
          and(
            eq(toolActionRequests.id, match.actionRequest.id),
            eq(toolActionRequests.status, "pending"),
          ),
        );
      await db
        .update(toolInvocations)
        .set({
          approvalState: "expired",
          idempotencyKey: null,
          updatedAt: now,
        })
        .where(eq(toolInvocations.id, match.invocation.id));
      await reflectToolActionInteractionLifecycle({
        actionRequestId: match.actionRequest.id,
        status: "expired",
      });
      return null;
    }
    return match;
  }

  async function replayMatchingAgentAction(input: {
    session: ToolGatewaySession;
    toolName: string;
    argumentsHash: string;
  }) {
    const match = await matchingAgentActionRequest(input);
    if (!match) return null;
    const { actionRequest, invocation } = match;
    if (actionRequest.status === "failed") {
      throw new ToolGatewayHttpError(409,
        "The provider is waiting for authorization or approval. Continue the existing execution; do not repeat the original call.",
        "provider_interaction_required", {
          invocationId: invocation.id, actionRequestId: actionRequest.id,
          upstreamPending: recoverUpstreamHandoff(invocation),
        });
    }
    if (actionRequest.status === "pending") {
      await throwApprovalRequired({
        invocationId: invocation.id,
        actionRequestId: actionRequest.id,
        interactionId: actionRequest.interactionId,
        issueId: input.session.issueId!,
        toolName: input.toolName,
        argumentsHash: input.argumentsHash,
      });
    }
    if (actionRequest.status === "rejected") {
      throw new ToolGatewayHttpError(
        409,
        "This tool action was declined; do not retry the same call",
        "action_declined",
        {
          invocationId: invocation.id,
          actionRequestId: actionRequest.id,
          instructions:
            "The action was declined. Do not retry the same call; adjust your approach or report the decline on the task.",
        },
      );
    }
    if (actionRequest.status === "executed") {
      return {
        matched: true as const,
        result: storedInvocationResult(invocation),
        invocationId: invocation.id,
      };
    }
    if (actionRequest.status === "executing") {
      const settled = await waitForActionRequestExecution(actionRequest.id);
      const [settledInvocation] = await db
        .select()
        .from(toolInvocations)
        .where(eq(toolInvocations.id, invocation.id))
        .limit(1);
      if (settled?.status === "executed" && settledInvocation) {
        return {
          matched: true as const,
          result: storedInvocationResult(settledInvocation),
          invocationId: invocation.id,
        };
      }
      throw new ToolGatewayHttpError(
        502,
        settledInvocation?.errorMessage ?? "Approved tool action failed",
        settledInvocation?.errorCode ?? "tool_execution_failed",
      );
    }
    if (actionRequest.status === "approved" && actionRequest.decidedAt) {
      const result = await executeApprovedAgentInvocation({
        actionRequest,
        invocation,
      });
      return { matched: true as const, result, invocationId: invocation.id };
    }
    return null;
  }

  /**
   * Project an ask-first test request + its invocation onto the lifecycle the
   * Test tab panel renders. Recovers the redacted parameter snapshot (the
   * "Where" row) and, once the call has run, the structured result or error.
   */
  function buildTestCallStatus(
    actionRequest: typeof toolActionRequests.$inferSelect,
    invocation: typeof toolInvocations.$inferSelect,
  ): ToolConnectionTestCallStatus {
    const invocationDone =
      invocation.status === "succeeded" ||
      invocation.status === "failed" ||
      invocation.status === "timed_out" ||
      invocation.status === "rate_limited" ||
      invocation.status === "denied";

    let phase: ToolConnectionTestCallStatusPhase;
    if (actionRequest.status === "rejected") {
      phase = "denied";
    } else if (actionRequest.status === "cancelled") {
      phase = "cancelled";
    } else if (actionRequest.status === "expired") {
      phase = "expired";
    } else if (
      actionRequest.status === "approved" ||
      actionRequest.status === "executed" || actionRequest.status === "failed"
    ) {
      phase = invocationDone ? "done" : "running";
    } else {
      phase = "waiting";
    }

    // Recover a redacted, structured snapshot of the parameters for the
    // "Where" row — the test-call response never echoes them back.
    let parameters: Record<string, unknown> | null = null;
    const signed = readSignedToolArgumentsPayload({
      signedArguments: actionRequest.signedArguments,
      invocationId: invocation.id,
      toolName: invocation.toolName,
      signingSecret: options.toolActionSigningSecret,
    });
    if (
      signed &&
      signed.arguments &&
      typeof signed.arguments === "object" &&
      !Array.isArray(signed.arguments)
    ) {
      const redacted = validateToolContent({
        value: signed.arguments,
        direction: "arguments",
        sensitiveMode: "redact",
        promptInjectionMode: "ignore",
      }).value;
      if (
        redacted &&
        typeof redacted === "object" &&
        !Array.isArray(redacted)
      ) {
        parameters = redacted as Record<string, unknown>;
      }
    }

    let result: unknown;
    let error: ToolConnectionTestCallStatus["error"];
    if (phase === "done") {
      if (invocation.status === "succeeded") {
        const summary = invocation.resultSummary?.summary;
        if (typeof summary === "string") {
          try {
            result = JSON.parse(summary);
          } catch {
            result = summary;
          }
        } else {
          result = null;
        }
      } else {
        error = {
          message: invocation.errorMessage ?? "The call didn't complete.",
          reasonCode: invocation.errorCode ?? null,
        };
      }
    }

    const durationMs =
      invocation.startedAt && invocation.completedAt
        ? Math.max(
            0,
            invocation.completedAt.getTime() - invocation.startedAt.getTime(),
          )
        : null;

    return {
      actionRequestId: actionRequest.id,
      invocationId: invocation.id,
      phase,
      parameters,
      ...(result !== undefined ? { result } : {}),
      ...(error ? { error } : {}),
      ...(recoverUpstreamHandoff(invocation) ? { upstreamPending: recoverUpstreamHandoff(invocation) } : {}),
      durationMs,
      requestedAt: actionRequest.createdAt.toISOString(),
      resolvedAt: actionRequest.resolvedAt
        ? actionRequest.resolvedAt.toISOString()
        : null,
    };
  }

  async function resolveSandboxCredentialBrokerBindingsWithDecision(
    input: {
      companyId: string;
      agentId: string;
      runId: string;
      responsibleUserId: string;
      presenceId: string;
      bindings: SandboxPolicy["credentials"]["bindings"];
    },
    decideForTool: (input: ToolAccessDecisionInput) => Promise<ToolAccessDecision>,
  ): Promise<{ authorizedConnectionGrantHashes: Record<string, string>; bindings: SandboxCredentialBrokerBinding[] }> {
    const authorizedConnectionGrantHashes: Record<string, string> = {};
    const resolved: SandboxCredentialBrokerBinding[] = [];
    const [run] = await db.select({
      companyId: heartbeatRuns.companyId, agentId: heartbeatRuns.agentId,
      responsibleUserId: heartbeatRuns.responsibleUserId, status: heartbeatRuns.status,
      issueId: heartbeatRuns.nativeIssueId,
    }).from(heartbeatRuns).where(and(eq(heartbeatRuns.companyId, input.companyId), eq(heartbeatRuns.id, input.runId))).limit(1);
    if (!run || run.status !== "running" || run.agentId !== input.agentId || run.responsibleUserId !== input.responsibleUserId || !run.issueId) {
      throw new ToolGatewayHttpError(409, "Current responsible run is required for credential brokering", "sandbox_broker_run_changed");
    }
    const [issue] = await db.select({ projectId: issues.projectId }).from(issues).where(and(
      eq(issues.companyId, input.companyId), eq(issues.id, run.issueId), eq(issues.assigneeAgentId, input.agentId),
    )).limit(1);
    if (!issue) throw new ToolGatewayHttpError(409, "Current Task owner is required for credential brokering", "sandbox_broker_task_changed");
    const sessionBase: ToolGatewaySession = {
      id: `sandbox-broker:${input.runId}`, token: "", companyId: input.companyId,
      agentId: input.agentId, runId: input.runId, issueId: run.issueId, projectId: issue.projectId,
      actorType: "agent", actorId: input.agentId, responsibleUserId: input.responsibleUserId,
      createdAt: new Date(), expiresAt: new Date(Date.now() + 60_000),
    };
    const currentSession = await captureSessionIdentity(sessionBase);
    if (currentSession.responsibleUserId !== input.responsibleUserId) {
      throw new ToolGatewayHttpError(403, "The current execution identity does not match the responsible Human", "sandbox_broker_identity_changed");
    }
    for (const binding of input.bindings) {
      const [connection] = await db.select().from(toolConnections).where(and(
        eq(toolConnections.companyId, input.companyId), eq(toolConnections.id, binding.connectionId),
        eq(toolConnections.enabled, true), eq(toolConnections.status, "active"), eq(toolConnections.transport, "mcp_remote"),
      )).limit(1);
      if (!connection) throw new ToolGatewayHttpError(409, "Credential broker connection is unavailable", "sandbox_broker_connection_unavailable");
      const grant = await resolveConnectionGrant(currentSession, connection);
      const endpoint = new URL(await resolvedRemoteEndpoint(currentSession, connection, grant));
      const port = endpoint.port ? Number(endpoint.port) : endpoint.protocol === "https:" ? 443 : 80;
      const path = endpoint.pathname || "/";
      if (endpoint.protocol !== "https:" || endpoint.username || endpoint.password || endpoint.search || endpoint.hash ||
        endpoint.hostname !== binding.hostname || port !== binding.port || !binding.methods.includes("POST") ||
        !binding.pathPrefixes.some(prefix => prefix === "/" || path === prefix || path.startsWith(`${prefix.replace(/\/$/, "")}/`))) {
        throw new ToolGatewayHttpError(409, "Credential broker destination does not match the compiled connection endpoint", "sandbox_broker_destination_changed");
      }
      const secretVersions = await connectedCredentialVersionSnapshots(connection, grant, { requireResolved: true });
      const gateways = await db.select().from(toolMcpGateways).where(and(
        eq(toolMcpGateways.companyId, input.companyId), eq(toolMcpGateways.status, "active"), isNull(toolMcpGateways.archivedAt),
      ));
      const eligible: Array<{
        gateway: typeof toolMcpGateways.$inferSelect;
        profile: typeof toolProfiles.$inferSelect;
        profileEntries: Array<typeof toolProfileEntries.$inferSelect>;
        tools: ToolGatewayDescriptor[];
      }> = [];
      for (const gateway of gateways) {
        if ((gateway.agentId && gateway.agentId !== input.agentId) || (gateway.projectId && gateway.projectId !== issue.projectId) ||
          (gateway.issueId && gateway.issueId !== run.issueId) ||
          (gateway.contextScopeType === "agent" && gateway.contextScopeId && gateway.contextScopeId !== input.agentId) ||
          (gateway.contextScopeType === "project" && gateway.contextScopeId && gateway.contextScopeId !== issue.projectId) ||
          (gateway.contextScopeType === "issue" && gateway.contextScopeId && gateway.contextScopeId !== run.issueId)) continue;
        const [profile] = await db.select().from(toolProfiles).where(and(
          eq(toolProfiles.companyId, input.companyId), eq(toolProfiles.id, gateway.profileId), eq(toolProfiles.status, "active"),
        )).limit(1);
        if (!profile) continue;
        const profileEntries = await db.select().from(toolProfileEntries).where(and(
          eq(toolProfileEntries.companyId, input.companyId), eq(toolProfileEntries.profileId, gateway.profileId),
        ));
        if (profileEntries.some(entry => entry.conditions && Object.keys(entry.conditions).length > 0)) continue;
        const matches = (entry: typeof toolProfileEntries.$inferSelect, tool: ToolGatewayDescriptor) => {
          if (entry.selectorType === "connection") return entry.connectionId === connection.id;
          if (entry.selectorType === "application") return entry.applicationId === connection.applicationId;
          if (entry.selectorType === "catalog_entry") return entry.catalogEntryId === tool.catalogEntryId;
          if (entry.selectorType === "tool_name") return entry.toolName === tool.name || entry.toolName === tool.upstreamToolName;
          return entry.riskLevel === tool.risk;
        };
        const gatewaySession: ToolGatewaySession = {
          ...currentSession, id: `sandbox-broker:${input.runId}:${gateway.id}`,
          gatewayId: gateway.id, gatewayPublicId: gateway.gatewayPublicId,
          gatewayName: gateway.name, gatewayProfileId: gateway.profileId,
        };
        // Compile-time route provenance does not confer dispatch authority. Use
        // the server-owned catalog and Gateway profile directly, then apply
        // policy checks through the caller-selected server-only decision path.
        const guestBotConnection = await githubGuestBotConnectionForSession(db, gatewaySession);
        const visibleTools = (await connectedMcpToolsForCompany(input.companyId)).filter(tool => {
          if (guestBotConnection && (tool.connectionId !== guestBotConnection || tool.providerType !== "paperclip_github_chat")) return false;
          if (tool.connectionId !== connection.id || tool.providerType !== "mcp_remote_http") return false;
          if (profile.defaultAction === "allow") return !profileEntries.some(entry => entry.effect === "exclude" && matches(entry, tool));
          return profileEntries.some(entry => entry.effect === "include" && matches(entry, tool)) &&
            !profileEntries.some(entry => entry.effect === "exclude" && matches(entry, tool));
        });
        const permittedTools: ToolGatewayDescriptor[] = [];
        for (const tool of visibleTools) {
          const decision = await decideForTool(policyInputForTool({ session: gatewaySession, tool }));
          if (decision.allowed) permittedTools.push(tool);
        }
        if (permittedTools.length) eligible.push({ gateway, profile, profileEntries, tools: permittedTools });
      }
      eligible.sort((a, b) => a.gateway.gatewayPublicId.localeCompare(b.gateway.gatewayPublicId));
      const selected = eligible[0];
      if (!selected) throw new ToolGatewayHttpError(409, "No current assigned gateway tools match the credential binding", "sandbox_broker_tools_unavailable");
      const allowedTools = selected.tools.map(tool => tool.name).sort();
      const fingerprint = {
        source: {
          companyId: input.companyId, agentId: input.agentId, runId: input.runId,
          issueId: run.issueId, projectId: issue.projectId, responsibleUserId: input.responsibleUserId,
          presenceId: input.presenceId,
        },
        connection: {
          id: connection.id, applicationId: connection.applicationId, transport: connection.transport,
          enabled: connection.enabled, status: connection.status, authKind: connection.authKind,
          credentialSource: connection.credentialSource, credentialPolicy: connection.credentialPolicy,
          credentialRefs: connection.credentialRefs, credentialSecretRefs: connection.credentialSecretRefs,
          externalCredential: connection.externalCredential,
        },
        grant: {
          id: grant.id, kind: grant.kind, subjectUserId: grant.subjectUserId,
          subjectAgentId: grant.subjectAgentId, status: grant.status, revokedAt: grant.revokedAt,
          credentialSecretRefs: grant.credentialSecretRefs, externalCredential: grant.externalCredential,
          providerTenant: grant.providerTenant,
        },
        endpoint: { protocol: endpoint.protocol, hostname: endpoint.hostname, port, path },
        secretVersions,
        gateway: {
          id: selected.gateway.id, publicId: selected.gateway.gatewayPublicId,
          agentId: selected.gateway.agentId, projectId: selected.gateway.projectId,
          issueId: selected.gateway.issueId, contextScopeType: selected.gateway.contextScopeType,
          contextScopeId: selected.gateway.contextScopeId,
          profile: { id: selected.profile.id, status: selected.profile.status, defaultAction: selected.profile.defaultAction },
          entries: selected.profileEntries.map(entry => ({
            selectorType: entry.selectorType, effect: entry.effect, connectionId: entry.connectionId,
            applicationId: entry.applicationId, catalogEntryId: entry.catalogEntryId,
            toolName: entry.toolName, riskLevel: entry.riskLevel,
          })),
          tools: selected.tools.map(tool => ({
            name: tool.name, upstreamToolName: tool.upstreamToolName,
            catalogEntryId: tool.catalogEntryId, schemaHash: stableHash(tool.parametersSchema),
            descriptionHash: stableHash(tool.description), risk: tool.risk,
          })),
        },
      };
      const grantVersionHash = stableHash(fingerprint);
      authorizedConnectionGrantHashes[binding.connectionId] = grantVersionHash;
      resolved.push({
        connectionId: binding.connectionId, grantVersionHash,
        gatewayPublicId: selected.gateway.gatewayPublicId,
        endpointPath: `/mcp/gateways/${selected.gateway.gatewayPublicId}`,
        allowedTools,
        binary: binding.binary,
        destination: { hostname: endpoint.hostname, port, method: "POST", path },
      });
    }
    return { authorizedConnectionGrantHashes, bindings: resolved };
  }

  const qualificationEchoPath = "/mcp/qualification/credential-echo";
  const qualificationEchoMarker = "paperclip-qualification-credential-ok-v1";
  const qualificationEchoEndpoint = (() => {
    try {
      const origin = new URL(options.qualificationBrokerOrigin ?? "");
      if (origin.protocol !== "https:" || origin.username || origin.password || origin.search || origin.hash || origin.pathname !== "/") return null;
      return `${origin.origin}${qualificationEchoPath}`;
    } catch { return null; }
  })();

  const service = {
    setSandboxBrokerAuthority(authority: SandboxBrokerAuthority, endpointOrigin?: string) {
      sandboxBrokerAuthority = authority;
      sandboxBrokerAuthorityOrigin = null;
      const owned=readSandboxBrokerAuthorityEnforcement(authority);
      if(owned) try {
        const url=new URL(endpointOrigin ?? owned.origin);
        if(url.protocol === "https:" && !url.username && !url.password && !url.search && !url.hash && url.pathname === "/" && url.origin === owned.origin)
          sandboxBrokerAuthorityOrigin=owned.origin;
      } catch { /* Unknown/mismatched origin earns no capability claim. */ }
    },
    describeSandboxBrokerEnforcement(endpointOrigin: string) {
      if(!sandboxBrokerAuthority || sandboxBrokerAuthorityOrigin !== endpointOrigin ||
          service.resolveSandboxCredentialBrokerPolicyBindings !== canonicalSandboxBrokerResolver) return null;
      return { protocol: "sandbox_exec_v1" as const, origin:sandboxBrokerAuthorityOrigin,
        dimensions: ["company","presence","expiry","revocation"] as const };
    },
    isSandboxBrokerToken(token: string) {
      return verifySandboxBrokerJwt(token) !== null;
    },
    isSandboxQualificationCredentialToken(token: string) {
      return verifySandboxQualificationCredentialJwt(token) !== null;
    },
    async isSandboxQualificationCanaryCall(input: { gatewayPublicId: string; tool: string }) {
      const [gateway] = await db.select({ id: toolMcpGateways.id }).from(toolMcpGateways).where(and(
        eq(toolMcpGateways.gatewayPublicId, input.gatewayPublicId), eq(toolMcpGateways.status, "active"),
        isNull(toolMcpGateways.archivedAt),
      )).limit(1);
      if (!gateway) return false;
      const connections = await db.select({ config: toolConnections.config }).from(toolMcpGateways)
        .innerJoin(toolProfileEntries, and(eq(toolProfileEntries.companyId, toolMcpGateways.companyId), eq(toolProfileEntries.profileId, toolMcpGateways.profileId)))
        .innerJoin(toolConnections, eq(toolConnections.id, toolProfileEntries.connectionId))
        .where(and(eq(toolMcpGateways.id, gateway.id), eq(toolConnections.status, "active"), eq(toolConnections.enabled, true)));
      return connections.some(row => {
        const fixture = row.config?.sandboxQualificationCanary as Record<string, unknown> | undefined;
        return fixture?.kind === "platform_owned_qualification_echo" &&
          fixture.purpose === "sandbox_qualification" && fixture.setupOnly === true &&
          (fixture.toolName === input.tool || fixture.wrongToolName === input.tool);
      });
    },
    async issueSandboxQualificationCredentialProbe(input: {
      actor: AuthorizationActor;
      scope: { companyId: string; bindingId: string; cellId: string; cellGeneration: string; sandboxRef: string };
      bindingVersion: number;
      operationKey: string;
      target: NonNullable<SandboxCapabilitySnapshot["qualificationTarget"]>;
      caseId: SandboxQualificationCredentialClaim["caseId"];
      commandId: string;
    }): Promise<{ commandId: string; capabilityToken: string; nonce: string } | null> {
      const fixture = input.target.qualificationCredentialFixture;
      if (!qualificationEchoEndpoint || fixture?.profileId !== "paperclip-qualification" ||
          fixture.origin !== new URL(qualificationEchoEndpoint).origin) return null;
      const caseIds = new Set<SandboxQualificationCredentialClaim["caseId"]>([
        "credential_allow", "credential_raw_read_deny", "credential_wrong_destination_deny",
        "credential_wrong_binary_deny", "credential_revoke_deny",
      ]);
      if (!fixture || !caseIds.has(input.caseId) || fixture.argumentTemplateHash !== nativeSha256({
        caseId: "<caseId>", fixtureId: "<fixtureId>", nonce: "<nonce>",
      })) return null;
      const operatorId = input.actor.type === "board" && input.actor.source === "session" ? input.actor.userId : null;
      const sessionId = input.actor.type === "board" && input.actor.source === "session" ? input.actor.sessionId : null;
      if (!operatorId || !sessionId || !options.operatorUserIds?.includes(operatorId)) return null;
      await assertConfiguredOperatorAuthentication(db, input.actor, options.operatorUserIds ?? []);
      await assertV7Authorization(db, input.actor, input.scope.companyId, "runtime:manage");
      const [binding] = await db.select().from(runtimeSandboxBindings).where(and(
        eq(runtimeSandboxBindings.companyId, input.scope.companyId), eq(runtimeSandboxBindings.id, input.scope.bindingId),
        eq(runtimeSandboxBindings.runtimeCellId, input.scope.cellId), eq(runtimeSandboxBindings.cellGeneration, input.scope.cellGeneration),
      )).limit(1);
      const [cell] = await db.select().from(runtimeCells).where(and(
        eq(runtimeCells.companyId, input.scope.companyId), eq(runtimeCells.id, input.scope.cellId),
        eq(runtimeCells.generation, BigInt(input.scope.cellGeneration)), eq(runtimeCells.status, "STOPPED"), isNull(runtimeCells.deletedAt),
      )).limit(1);
      const [host] = cell?.runtimeHostId ? await db.select().from(runtimeHosts).where(and(
        eq(runtimeHosts.id, cell.runtimeHostId), eq(runtimeHosts.credentialVersion, input.target.hostEpoch),
        eq(runtimeHosts.status, "READY"), isNull(runtimeHosts.credentialRevokedAt), isNull(runtimeHosts.fencedAt), isNull(runtimeHosts.retiredAt),
      )).limit(1) : [];
      if (!binding || !cell || !host || binding.version !== input.bindingVersion ||
        !["requested", "ready", "failed"].includes(binding.status) || binding.backend !== "openshell" ||
        (binding.sandboxRef ?? `aw-v7-${binding.id}`) !== input.scope.sandboxRef ||
        input.target.companyId !== input.scope.companyId || input.target.bindingId !== input.scope.bindingId ||
        input.target.cellId !== input.scope.cellId || input.target.cellGeneration !== input.scope.cellGeneration ||
        input.target.sandboxRef !== input.scope.sandboxRef || input.target.bindingVersion !== input.bindingVersion ||
        input.target.phase !== "Ready" || input.target.hostEpoch !== host.credentialVersion ||
        !binding.boundaryPolicy.credentials || binding.boundaryPolicy.credentials.mode !== "brokered")
        return null;
      const [operatorSession] = await db.select().from(authSessions).where(and(
        eq(authSessions.id, sessionId), eq(authSessions.userId, operatorId), gt(authSessions.expiresAt, new Date()),
      )).limit(1);
      if (!operatorSession) return null;
      const [gateway] = await db.select().from(toolMcpGateways).where(and(
        eq(toolMcpGateways.companyId, input.scope.companyId), eq(toolMcpGateways.gatewayPublicId, fixture.gatewayPublicId),
        eq(toolMcpGateways.status, "active"), isNull(toolMcpGateways.archivedAt),
      )).limit(1);
      const companyConnections = await db.select().from(toolConnections).where(and(
        eq(toolConnections.companyId, input.scope.companyId), eq(toolConnections.status, "active"),
        eq(toolConnections.enabled, true), eq(toolConnections.transport, "mcp_remote"),
      ));
      const fixtureConnections = companyConnections.filter(row => {
        const candidate = row.config?.sandboxQualificationCanary as Record<string, unknown> | undefined;
        return row.createdByUserId === operatorId && candidate?.kind === "platform_owned_qualification_echo" && candidate.purpose === "sandbox_qualification" &&
          candidate.setupOnly === true && candidate.fixtureId === fixture.fixtureId;
      });
      const connection = fixtureConnections.length === 1 ? fixtureConnections[0] : undefined;
      if (!gateway || !connection || binding.boundaryPolicy.credentials.bindings.some(candidate => candidate.connectionId === connection.id)) return null;
      const canary = connection.config?.sandboxQualificationCanary;
      if (!canary || typeof canary !== "object" || Array.isArray(canary)) return null;
      const canaryConfig = canary as Record<string, unknown>;
      const canaryKeys = ["argumentTemplateHash", "endpointOrigin", "endpointPath", "fixtureHash", "fixtureId", "gatewayPublicId", "grantId", "kind", "marker", "noSideEffects", "purpose", "readOnly", "setupOnly", "toolName", "version", "wrongToolName"].sort();
      if (Object.keys(canaryConfig).sort().join(",") !== canaryKeys.join(",") ||
        canaryConfig.kind !== "platform_owned_qualification_echo" || canaryConfig.version !== 1 ||
        canaryConfig.purpose !== "sandbox_qualification" || canaryConfig.setupOnly !== true ||
        canaryConfig.fixtureId !== fixture.fixtureId || canaryConfig.fixtureHash !== fixture.fixtureHash ||
        canaryConfig.gatewayPublicId !== fixture.gatewayPublicId || canaryConfig.toolName !== fixture.toolName ||
        canaryConfig.wrongToolName !== fixture.wrongToolName || canaryConfig.argumentTemplateHash !== fixture.argumentTemplateHash ||
        canaryConfig.marker !== fixture.marker || canaryConfig.readOnly !== true || canaryConfig.noSideEffects !== true ||
        typeof canaryConfig.endpointOrigin !== "string" || canaryConfig.marker !== qualificationEchoMarker) return null;
      const session: ToolGatewaySession = {
        id: `qualification:${input.commandId}`, token: "qualification-host-probe", companyId: input.scope.companyId,
        agentId: null, runId: null, issueId: null, projectId: null, gatewayId: gateway.id,
        gatewayPublicId: gateway.gatewayPublicId, gatewayName: gateway.name, gatewayProfileId: gateway.profileId,
        gatewayTokenAllowedActions: ["tools/call"], actorType: "user", actorId: operatorId, responsibleUserId: operatorId,
        createdAt: operatorSession.createdAt, expiresAt: operatorSession.expiresAt,
      };
      let grant: typeof connectionGrants.$inferSelect;
      try { grant = await resolveConnectionGrant(session, connection); } catch { return null; }
      if (grant.id !== canaryConfig.grantId || grant.status !== "active") return null;
      const endpoint = new URL(await resolvedRemoteEndpoint(session, connection, grant));
      if (endpoint.href !== qualificationEchoEndpoint || endpoint.protocol !== "https:" || endpoint.origin !== canaryConfig.endpointOrigin || endpoint.pathname !== canaryConfig.endpointPath ||
        endpoint.username || endpoint.password || endpoint.search || endpoint.hash) return null;
      const snapshots = await connectedCredentialVersionSnapshots(connection, grant, { requireResolved: true });
      const secretVersionHash = nativeSha256(snapshots);
      const tool = (await connectedMcpToolsForConnection(session.companyId, connection.id)).find(candidate => candidate.name === fixture.toolName) ?? null;
      if (!tool || tool.connectionId !== connection.id || tool.providerType !== "mcp_remote_http" || tool.risk !== "read") return null;
      const sourceBindingHash = await qualificationCanarySourceBindingHash({ session, connection, grant, gateway, tool, fixtureConfig: canaryConfig });
      const nonce = randomBytes(16).toString("hex"), expiresAt = new Date(Date.now() + 20_000).toISOString();
      const argumentsValue = { fixtureId: fixture.fixtureId, caseId: input.caseId, nonce };
      const positiveBody = { jsonrpc: "2.0", id: input.commandId, method: "tools/call", params: { name: fixture.toolName, arguments: argumentsValue } };
      const claim: SandboxQualificationCredentialClaim = {
        version: 1, purpose: "qualification_credential_probe", aud: "paperclip-sandbox-qualification",
        jti: randomUUID(), commandId: input.commandId, caseId: input.caseId, fixtureId: fixture.fixtureId,
        fixtureHash: fixture.fixtureHash, hostEpoch: input.target.hostEpoch, scope: {
          companyId: input.scope.companyId, bindingId: input.scope.bindingId, cellId: input.scope.cellId,
          generation: input.scope.cellGeneration, sandboxRef: input.scope.sandboxRef,
        }, bindingVersion: input.bindingVersion, sandboxId: input.target.sandboxId, containerId: input.target.containerId,
        provisioningHash: input.target.provisioningHash, targetQualificationHash: input.target.targetHash,
        connectionId: connection.id, grantId: grant.id,
        secretVersionHash, sourceBindingHash, operatorUserId: operatorId, operatorSessionId: sessionId, profileId: fixture.profileId,
        profileHash: fixture.profileHash, binaries: [...fixture.binaries], gatewayPublicId: fixture.gatewayPublicId,
        toolName: fixture.toolName, argumentTemplateHash: fixture.argumentTemplateHash, argumentsHash: nativeSha256(argumentsValue),
        requestBodyHash: nativeSha256(positiveBody), nonce, origin: fixture.origin, method: "POST",
        path: `/mcp/gateways/${fixture.gatewayPublicId}`, expiresAt, maxUses: 1,
      };
      const capabilityToken = createSandboxQualificationCredentialJwt({ companyId: input.scope.companyId,
        bindingId: input.scope.bindingId, operatorUserId: operatorId, claim });
      if (!capabilityToken) return null;
      if (input.caseId === "credential_revoke_deny") {
        await toolAccessService(db).revokeConnectionGrant(connection.id, grant.id, { actorType: "user", actorId: operatorId });
      }
      return { commandId: input.commandId, capabilityToken, nonce };
    },
    async executeSandboxQualificationCredentialTool(input: {
      capabilityToken: string; gatewayPublicId: string; commandId: string; tool: string; parameters: unknown;
    }, observedAuthorization?: string): Promise<{ invocationId: string; result: { content: string; structuredContent: { marker: string } } }> {
      const verified = verifySandboxQualificationCredentialJwt(input.capabilityToken);
      const claim = verified?.qualification_credential;
      if (!claim) throw new ToolGatewayHttpError(401, "Qualification credential capability is required", "sandbox_qualification_credential_required");
      if (!qualificationEchoEndpoint || claim.profileId !== "paperclip-qualification" || claim.origin !== new URL(qualificationEchoEndpoint).origin)
        throw new ToolGatewayHttpError(409, "Platform qualification endpoint is unavailable", "sandbox_qualification_fixture_changed");
      if (input.commandId !== claim.commandId || (observedAuthorization === undefined ? input.gatewayPublicId !== claim.gatewayPublicId : input.gatewayPublicId !== "") ||
        !input.parameters || typeof input.parameters !== "object" || Array.isArray(input.parameters))
        throw new ToolGatewayHttpError(403, "Qualification request scope changed", "sandbox_qualification_tool_mismatch");
      const args = input.parameters as Record<string, unknown>;
      const expectedArgs = { fixtureId: claim.fixtureId, caseId: claim.caseId, nonce: claim.nonce };
      const body = { jsonrpc: "2.0", id: claim.commandId, method: "tools/call", params: { name: claim.toolName, arguments: expectedArgs } };
      if (Object.keys(args).length !== 3 || args.fixtureId !== claim.fixtureId || args.caseId !== claim.caseId || args.nonce !== claim.nonce ||
        nativeSha256(args) !== claim.argumentsHash || nativeSha256({ caseId: "<caseId>", fixtureId: "<fixtureId>", nonce: "<nonce>" }) !== claim.argumentTemplateHash)
        throw new ToolGatewayHttpError(403, "Qualification request body changed", "sandbox_qualification_tool_mismatch");
      const actor: AuthorizationActor = { type: "board", source: "session", userId: claim.operatorUserId, sessionId: claim.operatorSessionId };
      const now = new Date();
      const [cell] = await db.select().from(runtimeCells).where(and(
        eq(runtimeCells.companyId, claim.scope.companyId), eq(runtimeCells.id, claim.scope.cellId),
        eq(runtimeCells.generation, BigInt(claim.scope.generation)), eq(runtimeCells.status, "STOPPED"), isNull(runtimeCells.deletedAt),
      )).limit(1);
      const [binding] = await db.select().from(runtimeSandboxBindings).where(and(
        eq(runtimeSandboxBindings.companyId, claim.scope.companyId), eq(runtimeSandboxBindings.id, claim.scope.bindingId),
        eq(runtimeSandboxBindings.runtimeCellId, claim.scope.cellId), eq(runtimeSandboxBindings.cellGeneration, claim.scope.generation),
        eq(runtimeSandboxBindings.version, claim.bindingVersion),
      )).limit(1);
      const [host] = cell?.runtimeHostId ? await db.select().from(runtimeHosts).where(and(
        eq(runtimeHosts.id, cell.runtimeHostId), eq(runtimeHosts.credentialVersion, claim.hostEpoch), eq(runtimeHosts.status, "READY"),
        isNull(runtimeHosts.credentialRevokedAt), isNull(runtimeHosts.fencedAt), isNull(runtimeHosts.retiredAt),
      )).limit(1) : [];
      const [gateway] = await db.select().from(toolMcpGateways).where(and(
        eq(toolMcpGateways.companyId, claim.scope.companyId), eq(toolMcpGateways.gatewayPublicId, claim.gatewayPublicId),
        eq(toolMcpGateways.status, "active"), isNull(toolMcpGateways.archivedAt),
      )).limit(1);
      const [hostCommand] = await db.select().from(runtimeHostCommands).where(and(
        eq(runtimeHostCommands.id, claim.commandId), eq(runtimeHostCommands.runtimeHostId, host?.id ?? "00000000-0000-4000-8000-000000000000"),
        eq(runtimeHostCommands.companyId, claim.scope.companyId), eq(runtimeHostCommands.runtimeCellId, claim.scope.cellId),
        eq(runtimeHostCommands.cellGeneration, BigInt(claim.scope.generation)), eq(runtimeHostCommands.commandType, SANDBOX_HOST_COMMAND),
        eq(runtimeHostCommands.status, "CLAIMED"), gt(runtimeHostCommands.deadlineAt, now),
      )).limit(1);
      if (!cell || !binding || !host || !gateway || !hostCommand || !["requested", "ready", "failed"].includes(binding.status) ||
        (binding.sandboxRef ?? `aw-v7-${binding.id}`) !== claim.scope.sandboxRef || Date.parse(claim.expiresAt) <= now.getTime())
        throw new ToolGatewayHttpError(409, "Qualification target is no longer current", "sandbox_qualification_target_changed");
      await assertConfiguredOperatorAuthentication(db, actor, options.operatorUserIds ?? []);
      await assertV7Authorization(db, actor, claim.scope.companyId, "runtime:manage");
      const [hostUse] = await db.transaction(async tx => {
        if (observedAuthorization !== undefined) {
          const [existing] = await tx.select().from(runtimeHostCommands).where(and(
            eq(runtimeHostCommands.runtimeHostId, host.id), eq(runtimeHostCommands.companyId, claim.scope.companyId),
            eq(runtimeHostCommands.runtimeCellId, claim.scope.cellId), eq(runtimeHostCommands.cellGeneration, BigInt(claim.scope.generation)),
            eq(runtimeHostCommands.commandType, "sandbox_qualification_credential_probe"),
            eq(runtimeHostCommands.idempotencyKey, `sandbox-qualification-credential:${claim.jti}`),
            eq(runtimeHostCommands.status, "CLAIMED"), gt(runtimeHostCommands.deadlineAt, now),
          )).limit(1);
          if (!existing || existing.payload.operationBodyHash !== claim.requestBodyHash || existing.safeResult !== null)
            throw new ToolGatewayHttpError(409, "Qualification observation is not current", "sandbox_qualification_capability_replayed");
          return [existing];
        }
        await assertConfiguredOperatorAuthentication(tx as unknown as Db, actor, options.operatorUserIds ?? []);
        const [inserted] = await tx.insert(runtimeHostCommands).values({
          runtimeHostId: host.id, companyId: claim.scope.companyId, runtimeCellId: claim.scope.cellId,
          cellGeneration: BigInt(claim.scope.generation), commandType: "sandbox_qualification_credential_probe",
          idempotencyKey: `sandbox-qualification-credential:${claim.jti}`,
          payload: { jtiHash: nativeSha256(claim.jti), commandId: claim.commandId, caseId: claim.caseId,
            gatewayPublicId: claim.gatewayPublicId, connectionId: claim.connectionId, operationBodyHash: claim.requestBodyHash },
          status: "CLAIMED", attempt: 1, deadlineAt: new Date(Math.min(Date.parse(claim.expiresAt), hostCommand.deadlineAt.getTime())),
        }).onConflictDoNothing().returning();
        if (!inserted) throw new ToolGatewayHttpError(409, "Qualification capability was already consumed", "sandbox_qualification_capability_replayed");
        return [inserted];
      });
      const session: ToolGatewaySession = {
        id: `qualification:${claim.jti}`, token: input.capabilityToken, companyId: claim.scope.companyId,
        agentId: null, runId: null, issueId: null, projectId: gateway.projectId ?? null, gatewayId: gateway.id,
        gatewayPublicId: claim.gatewayPublicId, gatewayName: gateway.name, gatewayProfileId: gateway.profileId,
        gatewayTokenAllowedActions: ["tools/call"], actorType: "user", actorId: claim.operatorUserId,
        responsibleUserId: claim.operatorUserId, createdAt: now, expiresAt: new Date(Date.parse(claim.expiresAt)),
      };
      const assertCurrent = async (tool?: ToolGatewayDescriptor) => {
        await assertConfiguredOperatorAuthentication(db, actor, options.operatorUserIds ?? []);
        await assertV7Authorization(db, actor, claim.scope.companyId, "runtime:manage");
        const [currentBinding] = await db.select().from(runtimeSandboxBindings).where(and(
          eq(runtimeSandboxBindings.companyId, claim.scope.companyId), eq(runtimeSandboxBindings.id, claim.scope.bindingId),
          eq(runtimeSandboxBindings.version, claim.bindingVersion), eq(runtimeSandboxBindings.status, binding.status),
        )).limit(1);
        const [currentCell] = await db.select({ status: runtimeCells.status }).from(runtimeCells).where(and(
          eq(runtimeCells.companyId, claim.scope.companyId), eq(runtimeCells.id, claim.scope.cellId),
          eq(runtimeCells.generation, BigInt(claim.scope.generation)), eq(runtimeCells.status, "STOPPED"), isNull(runtimeCells.deletedAt),
        )).limit(1);
        const [currentHost] = await db.select({ credentialVersion: runtimeHosts.credentialVersion }).from(runtimeHosts).where(and(
          eq(runtimeHosts.id, host.id), eq(runtimeHosts.credentialVersion, claim.hostEpoch), eq(runtimeHosts.status, "READY"),
          isNull(runtimeHosts.credentialRevokedAt), isNull(runtimeHosts.fencedAt), isNull(runtimeHosts.retiredAt),
        )).limit(1);
        const [currentChallenge] = await db.select({ id: runtimeHostCommands.id }).from(runtimeHostCommands).where(and(
          eq(runtimeHostCommands.id, claim.commandId), eq(runtimeHostCommands.runtimeHostId, host.id),
          eq(runtimeHostCommands.companyId, claim.scope.companyId), eq(runtimeHostCommands.runtimeCellId, claim.scope.cellId),
          eq(runtimeHostCommands.cellGeneration, BigInt(claim.scope.generation)),
          eq(runtimeHostCommands.commandType, SANDBOX_HOST_COMMAND), eq(runtimeHostCommands.status, "CLAIMED"),
          gt(runtimeHostCommands.deadlineAt, new Date()),
        )).limit(1);
        if (!currentBinding || !currentCell || !currentHost || !currentChallenge || Date.parse(claim.expiresAt) <= Date.now())
          throw new ToolGatewayHttpError(409, "Qualification target changed during probe", "sandbox_qualification_target_changed");
        const [currentConnection] = await db.select().from(toolConnections).where(and(
          eq(toolConnections.companyId, claim.scope.companyId), eq(toolConnections.id, claim.connectionId),
          eq(toolConnections.status, "active"), eq(toolConnections.enabled, true),
        )).limit(1);
        const activeFixtureConnections = await db.select({ id: toolConnections.id, config: toolConnections.config, createdByUserId: toolConnections.createdByUserId }).from(toolConnections).where(and(
          eq(toolConnections.companyId, claim.scope.companyId), eq(toolConnections.status, "active"),
          eq(toolConnections.enabled, true), eq(toolConnections.transport, "mcp_remote"),
        ));
        const sameFixture = activeFixtureConnections.filter(row => {
          const candidate = row.config?.sandboxQualificationCanary as Record<string, unknown> | undefined;
          return row.createdByUserId === claim.operatorUserId && candidate?.kind === "platform_owned_qualification_echo" && candidate.purpose === "sandbox_qualification" &&
            candidate.setupOnly === true && candidate.fixtureId === claim.fixtureId;
        });
        const [currentGateway] = await db.select().from(toolMcpGateways).where(and(
          eq(toolMcpGateways.companyId, claim.scope.companyId), eq(toolMcpGateways.gatewayPublicId, claim.gatewayPublicId),
          eq(toolMcpGateways.status, "active"), isNull(toolMcpGateways.archivedAt),
        )).limit(1);
        if (!currentConnection || currentConnection.createdByUserId !== claim.operatorUserId || !currentGateway)
          throw new ToolGatewayHttpError(409, "Qualification gateway grant was revoked", "sandbox_qualification_grant_revoked");
        if (sameFixture.length !== 1 || sameFixture[0]?.id !== claim.connectionId)
          throw new ToolGatewayHttpError(409, "Qualification fixture identity changed", "sandbox_qualification_fixture_changed");
        const canaryConfig = currentConnection.config?.sandboxQualificationCanary as Record<string, unknown> | undefined;
        if (!canaryConfig || canaryConfig.kind !== "platform_owned_qualification_echo" || canaryConfig.purpose !== "sandbox_qualification" ||
          canaryConfig.setupOnly !== true || canaryConfig.fixtureId !== claim.fixtureId ||
          canaryConfig.fixtureHash !== claim.fixtureHash || canaryConfig.toolName !== claim.toolName || canaryConfig.gatewayPublicId !== claim.gatewayPublicId ||
          canaryConfig.marker !== qualificationEchoMarker)
          throw new ToolGatewayHttpError(409, "Qualification canary fixture changed", "sandbox_qualification_fixture_changed");
        if (currentBinding.boundaryPolicy.credentials.bindings.some(candidate => candidate.connectionId === claim.connectionId))
          throw new ToolGatewayHttpError(409, "Qualification fixture grant cannot overlap runtime credentials", "sandbox_qualification_fixture_changed");
        const currentGrant = await resolveConnectionGrant(session, currentConnection).catch(() => null);
        if (!currentGrant || currentGrant.id !== claim.grantId || currentGrant.status !== "active")
          throw new ToolGatewayHttpError(403, "Qualification credential grant was revoked", "sandbox_qualification_grant_revoked");
        if (currentGateway.id !== session.gatewayId || currentGateway.profileId !== session.gatewayProfileId || currentGrant.id !== canaryConfig.grantId)
          throw new ToolGatewayHttpError(409, "Qualification gateway authority changed", "sandbox_qualification_fixture_changed");
        const endpoint = new URL(await resolvedRemoteEndpoint(session, currentConnection, currentGrant));
        if (endpoint.href !== qualificationEchoEndpoint || endpoint.protocol !== "https:" || endpoint.origin !== canaryConfig.endpointOrigin || endpoint.pathname !== canaryConfig.endpointPath ||
          endpoint.username || endpoint.password || endpoint.search || endpoint.hash)
          throw new ToolGatewayHttpError(409, "Qualification canary destination changed", "sandbox_qualification_fixture_changed");
        const versions = await connectedCredentialVersionSnapshots(currentConnection, currentGrant, { requireResolved: true }).catch(() => null);
        if (!versions || nativeSha256(versions) !== claim.secretVersionHash)
          throw new ToolGatewayHttpError(409, "Qualification credential version changed", "sandbox_qualification_grant_revoked");
        const currentTool = (await connectedMcpToolsForConnection(session.companyId, currentConnection.id)).find(candidate => candidate.name === claim.toolName) ?? null;
        if (!currentTool || currentTool.connectionId !== claim.connectionId || currentTool.providerType !== "mcp_remote_http" || currentTool.risk !== "read" ||
          await qualificationCanarySourceBindingHash({ session, connection: currentConnection, grant: currentGrant,
            gateway: currentGateway, tool: currentTool, fixtureConfig: canaryConfig }) !== claim.sourceBindingHash)
          throw new ToolGatewayHttpError(409, "Qualification canary source binding changed", "sandbox_qualification_fixture_changed");
        if (tool && (tool.name !== claim.toolName || tool.connectionId !== claim.connectionId || tool.providerType !== "mcp_remote_http" || tool.risk !== "read"))
          throw new ToolGatewayHttpError(403, "Qualification tool is outside the one-use fixture", "sandbox_qualification_tool_mismatch");
        return canaryConfig.marker;
      };
      try {
        if (input.tool !== claim.toolName) throw new ToolGatewayHttpError(403, "Qualification tool is outside the one-use fixture", "sandbox_qualification_tool_mismatch");
        if (nativeSha256(body) !== claim.requestBodyHash) throw new ToolGatewayHttpError(403, "Qualification request body changed", "sandbox_qualification_tool_mismatch");
        await assertCurrent();
        if (!qualificationEchoEndpoint) throw new ToolGatewayHttpError(409, "Platform qualification endpoint is unavailable", "sandbox_qualification_fixture_changed");
        const [connection] = await db.select().from(toolConnections).where(and(
          eq(toolConnections.id, claim.connectionId), eq(toolConnections.companyId, claim.scope.companyId),
        )).limit(1);
        if (!connection) throw new ToolGatewayHttpError(409, "Qualification connection changed", "sandbox_qualification_grant_revoked");
        const grant = await resolveConnectionGrant(session, connection);
        const headers = await resolveCredentialHeaders(session, connection, grant);
        await assertCurrent(); // credential refresh is asynchronous and cannot extend authority
        const authorization = headers.Authorization ?? headers.authorization;
        if (Object.keys(headers).length !== 1 || typeof authorization !== "string" || !authorization.startsWith("Bearer "))
          throw new ToolGatewayHttpError(409, "Qualification requires its dedicated bearer credential", "sandbox_qualification_fixture_changed");
        const observation = { version: 1, commandId: claim.commandId, requestBodyHash: claim.requestBodyHash,
          sourceBindingHash: claim.sourceBindingHash, secretVersionHash: claim.secretVersionHash, marker: qualificationEchoMarker };
        const safeResult = { invocationId: hostUse.id, result: { content: qualificationEchoMarker, structuredContent: { marker: qualificationEchoMarker } } };
        if (observedAuthorization !== undefined) {
          const observed = Buffer.from(observedAuthorization), expected = Buffer.from(authorization);
          if (observed.length !== expected.length || !timingSafeEqual(observed, expected))
            throw new ToolGatewayHttpError(403, "Qualification credential was not observed", "sandbox_qualification_credential_required");
          await assertCurrent();
          const [recorded] = await db.update(runtimeHostCommands).set({ safeResult: observation }).where(and(
            eq(runtimeHostCommands.id, hostUse.id), eq(runtimeHostCommands.status, "CLAIMED"),
            isNull(runtimeHostCommands.safeResult), gt(runtimeHostCommands.deadlineAt, new Date()),
          )).returning({ id: runtimeHostCommands.id });
          if (!recorded) throw new ToolGatewayHttpError(409, "Qualification capability was already observed", "sandbox_qualification_capability_replayed");
          return safeResult;
        }
        const init: RequestInit = { method: "POST", redirect: "manual", signal: AbortSignal.timeout(10_000),
          headers: { "content-type": "application/json", Authorization: authorization,
            "x-paperclip-qualification-capability": input.capabilityToken }, body: JSON.stringify(body) };
        await assertCurrent();
        const response = options.remoteHttpRequest ? await options.remoteHttpRequest(qualificationEchoEndpoint, init)
          : await guardedRemoteHttpFetch(qualificationEchoEndpoint, init, { ...remoteHttpFetchOptions(), responseTimeoutMs: 10_000 });
        await assertCurrent();
        if (!response.ok || response.redirected)
          throw new ToolGatewayHttpError(502, "Qualification echo did not succeed", "sandbox_qualification_probe_failed");
        const echoed = asRecord(await response.json());
        await assertCurrent();
        if (nativeSha256(echoed) !== nativeSha256(safeResult))
          throw new ToolGatewayHttpError(502, "Qualification echo result changed", "sandbox_qualification_result_invalid");
        const [completed] = await db.update(runtimeHostCommands).set({ status: "SUCCEEDED", completedAt: new Date(),
          safeResult: { ...observation, invocationId: hostUse.id, resultHash: nativeSha256(safeResult.result) },
        }).where(and(eq(runtimeHostCommands.id, hostUse.id), eq(runtimeHostCommands.status, "CLAIMED"),
          eq(runtimeHostCommands.safeResult, observation), gt(runtimeHostCommands.deadlineAt, new Date()),
        )).returning({ id: runtimeHostCommands.id });
        if (!completed) throw new ToolGatewayHttpError(409, "Qualification observation changed", "sandbox_qualification_capability_replayed");
        return safeResult;
      } catch (error) {
        const code = error instanceof ToolGatewayHttpError ? error.reasonCode : "sandbox_qualification_probe_failed";
        if (observedAuthorization === undefined) await db.update(runtimeHostCommands).set({ status: "FAILED", completedAt: new Date(), errorCode: code })
          .where(and(eq(runtimeHostCommands.id, hostUse.id), eq(runtimeHostCommands.status, "CLAIMED")));
        throw error;
      }
    },
    async executeSandboxBrokerTool(input: {
      capabilityToken: string;
      gatewayPublicId: string;
      operationId: string;
      tool: string;
      parameters?: unknown;
      timeoutMs?: number;
      signal?: AbortSignal;
    }) {
      if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(input.operationId)) {
        throw new ToolGatewayHttpError(400, "Broker operation id must be a UUID", "sandbox_broker_operation_id_invalid");
      }
      const session = await sandboxBrokerSessionFromBearer({
        gatewayPublicId: input.gatewayPublicId, bearerToken: input.capabilityToken, protocolMethod: "tools/call",
      });
      if (!session?.sandboxBrokerCapability) throw new ToolGatewayHttpError(401, "Sandbox broker capability is required", "sandbox_broker_capability_invalid");
      const capability = session.sandboxBrokerCapability;
      const binding = capability.bindings.find(candidate => candidate.gatewayPublicId === input.gatewayPublicId);
      if (!binding || !binding.allowedTools.includes(input.tool)) {
        throw new ToolGatewayHttpError(403, "Operation is outside the current broker capability", "sandbox_broker_operation_denied");
      }
      const [parent] = await db.select().from(runtimeHostCommands).where(and(
        eq(runtimeHostCommands.idempotencyKey, capability.parentRequestId),
        eq(runtimeHostCommands.companyId, session.companyId),
        eq(runtimeHostCommands.runtimeCellId, capability.cellId),
        eq(runtimeHostCommands.cellGeneration, BigInt(capability.generation)),
        eq(runtimeHostCommands.commandType, "sandbox_exec"), eq(runtimeHostCommands.status, "CLAIMED"),
      )).limit(1);
      if (!parent) throw new ToolGatewayHttpError(403, "Parent sandbox execution is fenced", "sandbox_broker_parent_fenced");
      const parameterValue = input.parameters ?? {};
      const operationHash = stableHash({ tool: input.tool, parameters: parameterValue });
      const operationKey = `sandbox-broker:${capability.brokerSessionId}:${input.operationId}`;
      const claimState = await db.transaction(async tx => {
        const [liveParent] = await tx.select({ id: runtimeHostCommands.id }).from(runtimeHostCommands).where(and(
          eq(runtimeHostCommands.idempotencyKey, capability.parentRequestId),
          eq(runtimeHostCommands.companyId, session.companyId),
          eq(runtimeHostCommands.runtimeCellId, capability.cellId),
          eq(runtimeHostCommands.cellGeneration, BigInt(capability.generation)),
          eq(runtimeHostCommands.commandType, "sandbox_exec"), eq(runtimeHostCommands.status, "CLAIMED"),
          gt(runtimeHostCommands.deadlineAt, new Date()),
        )).for("update").limit(1);
        if (!liveParent) throw new ToolGatewayHttpError(403, "Parent sandbox execution is fenced", "sandbox_broker_parent_fenced");
        const [prior] = await tx.select().from(runtimeHostCommands).where(eq(runtimeHostCommands.idempotencyKey, operationKey)).for("update").limit(1);
        if (prior) {
          const payload = prior.payload as Record<string, unknown>;
          if (payload.operationHash !== operationHash || payload.parentRequestId !== capability.parentRequestId || payload.connectionId !== binding.connectionId || payload.tool !== input.tool) {
            throw new ToolGatewayHttpError(409, "Broker operation id was reused for different arguments", "sandbox_broker_operation_conflict");
          }
          if (prior.status !== "SUCCEEDED") throw new ToolGatewayHttpError(409, "Original broker operation has an unknown or incomplete outcome", "sandbox_broker_operation_unsettled");
          return { replay: prior };
        }
        const now = new Date();
        const [created] = await tx.insert(runtimeHostCommands).values({
          runtimeHostId: capability.hostId, companyId: session.companyId, runtimeCellId: capability.cellId,
          cellGeneration: BigInt(capability.generation), commandType: "sandbox_broker", idempotencyKey: operationKey,
          payload: {
            parentRequestId: capability.parentRequestId, brokerSessionId: capability.brokerSessionId,
            bindingId: capability.bindingId, runId: capability.runId, attemptId: capability.attemptId, attempt: capability.attempt,
            manifestId: capability.manifestId, manifestHash: capability.manifestHash,
            policySnapshotId: capability.policySnapshotId, policyHash: capability.policyHash,
            connectionId: binding.connectionId, gatewayPublicId: input.gatewayPublicId,
            tool: input.tool, operationId: input.operationId, operationHash,
          },
          status: "PENDING", attempt: 0, deadlineAt: new Date(Math.min(parent.deadlineAt.getTime(), Date.parse(capability.expiresAt))),
        }).onConflictDoNothing().returning();
        if (!created) {
          const [raced] = await tx.select().from(runtimeHostCommands).where(eq(runtimeHostCommands.idempotencyKey, operationKey)).for("update").limit(1);
          if (!raced) throw new ToolGatewayHttpError(409, "Broker operation claim could not be persisted", "sandbox_broker_claim_unavailable");
          const payload = raced.payload as Record<string, unknown>;
          if (payload.operationHash !== operationHash || raced.status !== "SUCCEEDED") throw new ToolGatewayHttpError(409, "Original broker operation has an unknown or conflicting outcome", "sandbox_broker_operation_unsettled");
          return { replay: raced };
        }
        const [claimed] = await tx.update(runtimeHostCommands).set({ status: "CLAIMED", attempt: 1 }).where(and(
          eq(runtimeHostCommands.id, created.id), eq(runtimeHostCommands.status, "PENDING"), eq(runtimeHostCommands.attempt, 0),
        )).returning();
        if (!claimed) throw new ToolGatewayHttpError(409, "Broker operation claim was already consumed", "sandbox_broker_claim_unavailable");
        return { replay: null, claim: claimed };
      });
      if (claimState.replay) {
        const safe = claimState.replay.safeResult as Record<string, unknown> | null;
        const invocationId = typeof safe?.invocationId === "string" ? safe.invocationId : null;
        const [invocation] = invocationId ? await db.select().from(toolInvocations).where(and(
          eq(toolInvocations.companyId, session.companyId), eq(toolInvocations.id, invocationId),
          eq(toolInvocations.idempotencyKey, operationKey), eq(toolInvocations.status, "succeeded"),
        )).limit(1) : [];
        if (!invocation) throw new ToolGatewayHttpError(409, "Completed broker result is unavailable; external outcome cannot be repeated", "sandbox_broker_result_unavailable");
        return { invocationId, status: "replayed" as const, tool: input.tool, result: invocation.workflowResultJson };
      }
      const claim = "claim" in claimState ? claimState.claim : null;
      if (!claim) throw new ToolGatewayHttpError(409, "Broker operation claim is unavailable", "sandbox_broker_claim_unavailable");
      const assertCurrent = async (tool?: ToolGatewayDescriptor) => {
        const current = await sandboxBrokerSessionFromBearer({
          gatewayPublicId: input.gatewayPublicId, bearerToken: input.capabilityToken, protocolMethod: "tools/call",
        });
        if (!current?.sandboxBrokerCapability || stableHash(current.sandboxBrokerCapability) !== stableHash(capability) ||
          current.gatewayId !== session.gatewayId || current.runId !== session.runId || current.responsibleUserId !== session.responsibleUserId ||
          (tool && (tool.connectionId !== binding.connectionId || tool.name !== input.tool || !binding.allowedTools.includes(tool.name)))) {
          throw new ToolGatewayHttpError(403, "Broker execution authority changed", "sandbox_broker_authority_changed");
        }
      };
      try {
        await assertCurrent();
        const result = await service.executeTool({
          sessionToken: input.capabilityToken, tool: input.tool, parameters: parameterValue,
          idempotencyKey: operationKey, timeoutMs: input.timeoutMs, signal: input.signal,
        }, undefined, { session, assertCurrent });
        await assertCurrent();
        const [completed] = await db.update(runtimeHostCommands).set({
          status: "SUCCEEDED", completedAt: new Date(),
          safeResult: { invocationId: result.invocationId, resultHash: stableHash(result.result ?? null) },
        }).where(and(eq(runtimeHostCommands.id, claim.id), eq(runtimeHostCommands.status, "CLAIMED"))).returning({ id: runtimeHostCommands.id });
        if (!completed) throw new ToolGatewayHttpError(409, "Broker result was fenced before delivery", "sandbox_broker_result_fenced");
        return result;
      } catch (error) {
        const reasonCode = error instanceof ToolGatewayHttpError ? error.reasonCode : "sandbox_broker_outcome_unknown";
        await db.update(runtimeHostCommands).set({ status: "FAILED", completedAt: new Date(), errorCode: reasonCode })
          .where(and(eq(runtimeHostCommands.id, claim.id), eq(runtimeHostCommands.status, "CLAIMED")));
        throw error;
      }
    },
    /** Resolve current, server-owned credential and gateway metadata for sandbox
     * policy compilation. Secret values are never returned; only the selected
     * grant revision and resolved secret version numbers enter the digest. */
    async resolveSandboxCredentialBrokerBindings(input: {
      companyId: string;
      agentId: string;
      runId: string;
      responsibleUserId: string;
      presenceId: string;
      bindings: SandboxPolicy["credentials"]["bindings"];
    }): Promise<{ authorizedConnectionGrantHashes: Record<string, string>; bindings: SandboxCredentialBrokerBinding[] }> {
      return resolveSandboxCredentialBrokerBindingsWithDecision(input, policyService.decide);
    },
    /** Current grant/secret and assigned Gateway metadata for server-side
     * sandbox policy compilation. This route projection is not a dispatch
     * authorization; `resolveSandboxCredentialBrokerBindings` remains the
     * full current-operation check used when minting or consuming capability. */
    async resolveSandboxCredentialBrokerPolicyBindings(input: {
      companyId: string;
      agentId: string;
      runId: string;
      responsibleUserId: string;
      presenceId: string;
      bindings: SandboxPolicy["credentials"]["bindings"];
    }): Promise<{ authorizedConnectionGrantHashes: Record<string, string>; bindings: SandboxCredentialBrokerBinding[] }> {
      return resolveSandboxCredentialBrokerBindingsWithDecision(input, policyService.decideForPolicyCompilation);
    },
    async recordRuntimeMcpDeliveryDiagnostic(input: {
      companyId: string;
      agentId: string;
      runId: string;
      permittedNotInstalledConnections: Array<{ id: string; name: string }>;
      firstPartyToolsDelivered?: boolean;
    }) {
      if (input.permittedNotInstalledConnections.length === 0) return;
      const [run] = await db
        .select({
          issueId: sql<
            string | null
          >`${heartbeatRuns.contextSnapshot} ->> 'issueId'`,
        })
        .from(heartbeatRuns)
        .where(
          and(
            eq(heartbeatRuns.id, input.runId),
            eq(heartbeatRuns.companyId, input.companyId),
            eq(heartbeatRuns.agentId, input.agentId),
          ),
        )
        .limit(1);
      await writeAudit({
        companyId: input.companyId,
        agentId: input.agentId,
        runId: input.runId,
        issueId: run?.issueId ?? null,
        action: "tool_gateway.runtime_mcp_delivery",
        details: {
          decision: "diagnostic",
          reasonCode: "permitted_connections_not_installed",
          deliveredServerCount: input.firstPartyToolsDelivered === false ? 0 : 1,
          deliveredAssignmentCount: 0,
          deliveredFirstPartyTools: input.firstPartyToolsDelivered !== false,
          permittedNotInstalledCount:
            input.permittedNotInstalledConnections.length,
          permittedNotInstalledConnections:
            input.permittedNotInstalledConnections,
        },
      });
    },

    async listNamedGateways(
      companyId: string,
    ): Promise<ToolMcpGatewayWithTokens[]> {
      // Archived gateways are retired — they must not appear in the list UI.
      const gateways = await db
        .select()
        .from(toolMcpGateways)
        .where(
          and(
            eq(toolMcpGateways.companyId, companyId),
            ne(toolMcpGateways.status, "archived"),
          ),
        )
        .orderBy(desc(toolMcpGateways.createdAt));
      const rows = await Promise.all(
        gateways.map((gateway) => getGatewayWithTokens(companyId, gateway.id)),
      );
      return rows;
    },

    async createNamedGateway(input: {
      companyId: string;
      body: CreateToolMcpGateway;
      actor?: { agentId?: string | null; userId?: string | null };
    }): Promise<ToolMcpGatewayWithTokens> {
      await assertGatewayContext({
        companyId: input.companyId,
        profileId: input.body.profileId,
        agentId: input.body.agentId ?? null,
        projectId: input.body.projectId ?? null,
        issueId: input.body.issueId ?? null,
      });
      const now = new Date();
      const slug =
        input.body.displaySlug ??
        input.body.slug ??
        slugSegment(input.body.name, "gateway");
      const [gateway] = await db
        .insert(toolMcpGateways)
        .values({
          companyId: input.companyId,
          name: input.body.name,
          slug,
          displaySlug: slug,
          description: input.body.description ?? null,
          defaultProfileMode: input.body.defaultProfileMode ?? "gateway_only",
          contextScopeType: input.body.contextScopeType ?? "none",
          contextScopeId: input.body.contextScopeId ?? null,
          profileId: input.body.profileId,
          agentId: input.body.agentId ?? null,
          projectId: input.body.projectId ?? null,
          issueId: input.body.issueId ?? null,
          approvalIssueId: input.body.approvalIssueId ?? null,
          ...(input.body.authConfig !== undefined
            ? { authConfig: input.body.authConfig }
            : {}),
          ...(input.body.headerPolicy !== undefined
            ? { headerPolicy: input.body.headerPolicy }
            : {}),
          ...(input.body.metadataPolicy !== undefined
            ? { metadataPolicy: input.body.metadataPolicy }
            : {}),
          ...(input.body.onDemandToolsConfig !== undefined
            ? { onDemandToolsConfig: input.body.onDemandToolsConfig }
            : {}),
          metadata: input.body.metadata ?? {},
          createdByAgentId: input.actor?.agentId ?? null,
          createdByUserId: input.actor?.userId ?? null,
          createdAt: now,
          updatedAt: now,
        })
        .returning();
      await db
        .insert(toolProfileBindings)
        .values({
          companyId: input.companyId,
          profileId: input.body.profileId,
          targetType: "gateway",
          targetId: gateway.id,
          priority: 10,
          metadata: { source: "named_mcp_gateway" },
          createdByAgentId: input.actor?.agentId ?? null,
          createdByUserId: input.actor?.userId ?? null,
        })
        .onConflictDoNothing();
      await writeAudit({
        session: {
          id: `gateway:${gateway.id}`,
          token: "",
          companyId: gateway.companyId,
          agentId: gateway.agentId,
          runId: null,
          issueId: gateway.issueId,
          projectId: gateway.projectId,
          gatewayId: gateway.id,
          gatewayName: gateway.name,
          actorType: input.actor?.agentId
            ? "agent"
            : input.actor?.userId
              ? "user"
              : "system",
          actorId: input.actor?.agentId ?? input.actor?.userId ?? gateway.id,
          createdAt: now,
          expiresAt: now,
        },
        companyId: input.companyId,
        agentId: input.actor?.agentId ?? gateway.agentId,
        runId: null,
        issueId: gateway.issueId,
        actorType: input.actor?.agentId
          ? "agent"
          : input.actor?.userId
            ? "user"
            : "system",
        actorId: input.actor?.agentId ?? input.actor?.userId ?? gateway.id,
        action: "tool_gateway.session_created",
        details: {
          decision: "allow",
          reasonCode: "named_gateway_created",
          gatewayId: gateway.id,
          gatewayName: gateway.name,
          profileId: gateway.profileId,
        },
      });
      return getGatewayWithTokens(input.companyId, gateway.id);
    },

    async updateNamedGateway(input: {
      companyId: string;
      gatewayId: string;
      body: UpdateToolMcpGateway;
    }): Promise<ToolMcpGatewayWithTokens> {
      const [existing] = await db
        .select()
        .from(toolMcpGateways)
        .where(
          and(
            eq(toolMcpGateways.companyId, input.companyId),
            eq(toolMcpGateways.id, input.gatewayId),
          ),
        )
        .limit(1);
      if (!existing)
        throw new ToolGatewayHttpError(
          404,
          "MCP gateway not found",
          "gateway_not_found",
        );
      await assertGatewayContext({
        companyId: input.companyId,
        profileId: input.body.profileId ?? existing.profileId,
        agentId:
          input.body.agentId === undefined
            ? existing.agentId
            : input.body.agentId,
        projectId:
          input.body.projectId === undefined
            ? existing.projectId
            : input.body.projectId,
        issueId:
          input.body.issueId === undefined
            ? existing.issueId
            : input.body.issueId,
      });
      const [updated] = await db
        .update(toolMcpGateways)
        .set({
          ...(input.body.name !== undefined ? { name: input.body.name } : {}),
          ...(input.body.slug !== undefined ||
          input.body.displaySlug !== undefined
            ? { slug: input.body.displaySlug ?? input.body.slug }
            : {}),
          ...(input.body.slug !== undefined ||
          input.body.displaySlug !== undefined
            ? { displaySlug: input.body.displaySlug ?? input.body.slug }
            : {}),
          ...(input.body.description !== undefined
            ? { description: input.body.description ?? null }
            : {}),
          ...(input.body.status !== undefined
            ? { status: input.body.status }
            : {}),
          ...(input.body.profileId !== undefined
            ? { profileId: input.body.profileId }
            : {}),
          ...(input.body.defaultProfileMode !== undefined
            ? { defaultProfileMode: input.body.defaultProfileMode }
            : {}),
          ...(input.body.contextScopeType !== undefined
            ? { contextScopeType: input.body.contextScopeType }
            : {}),
          ...(input.body.contextScopeId !== undefined
            ? { contextScopeId: input.body.contextScopeId ?? null }
            : {}),
          ...(input.body.agentId !== undefined
            ? { agentId: input.body.agentId ?? null }
            : {}),
          ...(input.body.projectId !== undefined
            ? { projectId: input.body.projectId ?? null }
            : {}),
          ...(input.body.issueId !== undefined
            ? { issueId: input.body.issueId ?? null }
            : {}),
          ...(input.body.approvalIssueId !== undefined
            ? { approvalIssueId: input.body.approvalIssueId ?? null }
            : {}),
          ...(input.body.authConfig !== undefined
            ? { authConfig: input.body.authConfig }
            : {}),
          ...(input.body.headerPolicy !== undefined
            ? { headerPolicy: input.body.headerPolicy }
            : {}),
          ...(input.body.metadataPolicy !== undefined
            ? { metadataPolicy: input.body.metadataPolicy }
            : {}),
          ...(input.body.onDemandToolsConfig !== undefined
            ? { onDemandToolsConfig: input.body.onDemandToolsConfig }
            : {}),
          ...(input.body.metadata !== undefined
            ? { metadata: input.body.metadata ?? {} }
            : {}),
          updatedAt: new Date(),
        })
        .where(
          and(
            eq(toolMcpGateways.companyId, input.companyId),
            eq(toolMcpGateways.id, input.gatewayId),
          ),
        )
        .returning();
      if (input.body.profileId && input.body.profileId !== existing.profileId) {
        await db
          .insert(toolProfileBindings)
          .values({
            companyId: input.companyId,
            profileId: input.body.profileId,
            targetType: "gateway",
            targetId: input.gatewayId,
            priority: 10,
            metadata: { source: "named_mcp_gateway" },
          })
          .onConflictDoNothing();
      }
      return getGatewayWithTokens(input.companyId, updated.id);
    },

    async createNamedGatewayToken(input: {
      companyId: string;
      gatewayId: string;
      body: CreateToolMcpGatewayToken;
      actor?: { agentId?: string | null; userId?: string | null };
    }): Promise<ToolMcpGatewayTokenCreated> {
      const [gateway] = await db
        .select()
        .from(toolMcpGateways)
        .where(
          and(
            eq(toolMcpGateways.companyId, input.companyId),
            eq(toolMcpGateways.id, input.gatewayId),
          ),
        )
        .limit(1);
      if (!gateway)
        throw new ToolGatewayHttpError(
          404,
          "MCP gateway not found",
          "gateway_not_found",
        );
      const tokenId = randomUUID();
      const token = generateNamedGatewayToken(tokenId);
      const tokenPrefix = `pcgw_${tokenId.slice(0, 8)}`;
      const now = new Date();
      const [row] = await db
        .insert(toolMcpGatewayTokens)
        .values({
          id: tokenId,
          companyId: input.companyId,
          gatewayId: input.gatewayId,
          name: input.body.name,
          tokenHash: hashGatewayToken(token),
          tokenPrefix,
          subjectType: input.body.subjectType ?? "gateway_client",
          subjectId: input.body.subjectId ?? null,
          clientLabel: input.body.clientLabel,
          ownerNote: input.body.ownerNote,
          allowedActions: input.body.allowedActions ?? [
            "tools/list",
            "tools/call",
            "resources/list",
            "resources/read",
            "prompts/list",
            "prompts/get",
          ],
          expiresAt: input.body.expiresAt ?? null,
          expiryOverrideReason: input.body.expiryOverrideReason ?? null,
          expiryOverrideByAgentId:
            input.actor?.agentId && input.body.expiryOverrideReason
              ? input.actor.agentId
              : null,
          expiryOverrideByUserId:
            input.actor?.userId && input.body.expiryOverrideReason
              ? input.actor.userId
              : null,
          expiryOverrideAt: input.body.expiryOverrideReason ? now : null,
          createdByAgentId: input.actor?.agentId ?? null,
          createdByUserId: input.actor?.userId ?? null,
          createdAt: now,
          updatedAt: now,
        })
        .returning();
      return { ...toGatewayToken(row), token };
    },

    async revokeNamedGatewayToken(input: {
      companyId: string;
      tokenId: string;
      revokedAt?: Date;
    }): Promise<ToolMcpGatewayToken> {
      const now = input.revokedAt ?? new Date();
      const [row] = await db
        .update(toolMcpGatewayTokens)
        .set({ revokedAt: now, updatedAt: now })
        .where(
          and(
            eq(toolMcpGatewayTokens.companyId, input.companyId),
            eq(toolMcpGatewayTokens.id, input.tokenId),
          ),
        )
        .returning();
      if (!row)
        throw new ToolGatewayHttpError(
          404,
          "MCP gateway token not found",
          "gateway_token_not_found",
        );
      return toGatewayToken(row);
    },

    async initializeNamedGatewayProtocol(input: {
      gatewayId?: string | null;
      gatewayPublicId?: string | null;
      bearerToken: string;
      callerHeaders?: Record<string, string | string[] | undefined>;
    }): Promise<ToolGatewaySession> {
      return namedGatewaySessionFromBearer({
        gatewayId: input.gatewayId ?? null,
        gatewayPublicId: input.gatewayPublicId ?? null,
        bearerToken: input.bearerToken,
        protocolMethod: "initialize",
        callerHeaders: input.callerHeaders,
      });
    },

    /**
     * Authenticated metadata for the repository-owned OpenClaw bridge plugin.
     * The claims are reconstructed from the bearer token and the existing
     * server-owned Run admission; caller-supplied identities are never used.
     */
    async describeNamedGatewayRunBinding(input: {
      gatewayId?: string | null;
      gatewayPublicId?: string | null;
      bearerToken: string;
      callerHeaders?: Record<string, string | string[] | undefined>;
    }): Promise<BlenteraGovernedRunBindingAttestation | null> {
      const session = await namedGatewaySessionFromBearer({
        gatewayId: input.gatewayId ?? null,
        gatewayPublicId: input.gatewayPublicId ?? null,
        bearerToken: input.bearerToken,
        protocolMethod: "initialize",
        callerHeaders: input.callerHeaders,
      });
      if (!session.runId || !session.agentId || !session.responsibleUserId || !session.gatewayId || !session.gatewayPublicId) {
        return null;
      }
      const contracts = blenteraPlatformContractHashes();
      const actor: AuthorizationActor = {
        type: "agent",
        source: "none",
        companyId: session.companyId,
        agentId: session.agentId,
        runId: session.runId,
        onBehalfOfUserId: session.responsibleUserId,
      };
      await assertPlatformSkillAdmission(db, actor, contracts);
      const [run] = await db.select({
        runnerProfileJson: heartbeatRuns.runnerProfileJson,
        runtimeAdapter: agents.adapterType,
      }).from(heartbeatRuns).innerJoin(agents, and(
        eq(agents.id, heartbeatRuns.agentId),
        eq(agents.companyId, heartbeatRuns.companyId),
      )).where(and(
        eq(heartbeatRuns.companyId, session.companyId),
        eq(heartbeatRuns.id, session.runId),
        eq(heartbeatRuns.agentId, session.agentId),
        eq(heartbeatRuns.status, "running"),
      )).limit(1);
      const [gateway] = await db.select({ metadata: toolMcpGateways.metadata })
        .from(toolMcpGateways)
        .where(and(
          eq(toolMcpGateways.companyId, session.companyId),
          eq(toolMcpGateways.id, session.gatewayId),
          eq(toolMcpGateways.status, "active"),
        )).limit(1);
      const [manifestRow] = await db.select({ manifest: agentExecutionManifests.manifest })
        .from(agentExecutionManifests)
        .where(and(
          eq(agentExecutionManifests.companyId, session.companyId),
          eq(agentExecutionManifests.agentId, session.agentId),
          eq(agentExecutionManifests.runId, session.runId),
        )).limit(1);
      const runnerProfile = asRecord(run?.runnerProfileJson);
      const admission = asRecord(runnerProfile?.platformSkillAdmission);
      const skill = asRecord(admission?.platformSkill);
      const manifest = asRecord(manifestRow?.manifest);
      const nativeContract = asRecord(manifest?.agentNativeContract);
      const primaryProvider = Array.isArray(manifest?.providers)
        ? asRecord(manifest.providers[0])
        : null;
      const metadata = asRecord(gateway?.metadata);
      const assignmentDigest = metadata?.nativeRuntimeAssignmentDigest;
      if (!run || typeof run.runtimeAdapter !== "string" || !admission || !skill || typeof skill.key !== "string" ||
          typeof skill.version !== "string" || typeof skill.digest !== "string" ||
          typeof skill.sourceSha !== "string" ||
          !nativeContract ||
          admission.operationManifestHash !== contracts.operationManifestHash ||
          admission.toolCatalogContractHash !== contracts.toolCatalogContractHash ||
          admission.runtimeAdapter !== run.runtimeAdapter ||
          typeof assignmentDigest !== "string" || !/^[a-f0-9]{64}$/.test(assignmentDigest)) {
        throw new ToolGatewayHttpError(409, "The current operating procedure admission is unavailable", "platform_skill_readmission_required");
      }
      if (manifestRow && (!nativeContract || nativeContract.operationManifestHash !== contracts.operationManifestHash ||
          nativeContract.toolCatalogContractHash !== contracts.toolCatalogContractHash ||
          nativeContract.protocolProfile !== "2026-07-28" || nativeContract.runtimeAdapter !== run.runtimeAdapter ||
          typeof nativeContract.runtimeCapabilitySnapshotHash !== "string" ||
          nativeContract.runtimeCapabilitySnapshotHash !== primaryProvider?.snapshotHash)) {
        throw new ToolGatewayHttpError(409, "The current provider capability snapshot is unavailable", "provider_capability_revalidation_required");
      }
      return {
        protocolVersion: 1,
        companyId: session.companyId,
        agentId: session.agentId,
        paperclipRunId: session.runId,
        responsibleUserId: session.responsibleUserId,
        runtimeAdapter: run.runtimeAdapter,
        runtimeCapabilitySnapshotHash: typeof nativeContract?.runtimeCapabilitySnapshotHash === "string"
          ? nativeContract.runtimeCapabilitySnapshotHash : null,
        platformSkill: {
          key: skill.key,
          version: skill.version,
          digest: skill.digest,
          sourceSha: skill.sourceSha,
        },
        operationManifestHash: contracts.operationManifestHash,
        toolCatalogContractHash: contracts.toolCatalogContractHash,
        gatewayId: session.gatewayId,
        gatewayPublicId: session.gatewayPublicId,
        gatewayProfileId: session.gatewayProfileId ?? null,
        assignmentDigest: typeof assignmentDigest === "string" ? assignmentDigest : null,
        tokenExpiresAt: session.expiresAt.toISOString(),
      };
    },

    async listToolsForNamedGateway(input: {
      gatewayId?: string | null;
      gatewayPublicId?: string | null;
      bearerToken: string;
      callerHeaders?: Record<string, string | string[] | undefined>;
    }): Promise<ToolGatewayDescriptor[]> {
      const session = await namedGatewaySessionFromBearer({
        gatewayId: input.gatewayId ?? null,
        gatewayPublicId: input.gatewayPublicId ?? null,
        bearerToken: input.bearerToken,
        protocolMethod: "tools/list",
        callerHeaders: input.callerHeaders,
      });
      await assertGatewayTokenAction(session, "tools/list");
      const tools = (await listToolsForContext(session)).filter(tool => {
        if (!session.sandboxBrokerCapability) return true;
        const binding = session.sandboxBrokerCapability.bindings.find(candidate => candidate.gatewayPublicId === session.gatewayPublicId);
        return !!binding && tool.connectionId === binding.connectionId && binding.allowedTools.includes(tool.name);
      });
      await writeAudit({
        session,
        companyId: session.companyId,
        agentId: session.agentId,
        runId: session.runId,
        issueId: session.issueId,
        action: "tool_gateway.discovery",
        details: {
          decision: "allow",
          reasonCode: "named_gateway_discovery_filtered",
          visibleToolCount: tools.length,
          visibleTools: tools.map((tool) => tool.name),
        },
      });
      return tools;
    },

    async executeContextForNamedGateway(input: {
      gatewayId?: string | null;
      gatewayPublicId?: string | null;
      bearerToken: string;
      method:
        "resources/list" | "resources/read" | "prompts/list" | "prompts/get";
      params?: Record<string, unknown>;
      callerHeaders?: Record<string, string | string[] | undefined>;
    }): Promise<Record<string, unknown>> {
      return namedGatewayContextProtocol(input);
    },

    async createSession(input: {
      companyId: string;
      agentId: string;
      runId: string;
      issueId?: string | null;
      projectId?: string | null;
      ttlMs?: number;
      actorType?: LogActivityInput["actorType"];
      actorId?: string;
      /** Original middleware-verified actor; never populated from request JSON. */
      authorizationActor?: AuthorizationActor;
    }): Promise<ToolGatewaySession> {
      await assertAgentInCompany(input.companyId, input.agentId);
      const { issueId, projectId } = await resolveRunContext(input);
      const now = new Date();
      const sessionId = randomUUID();
      const token = generateGatewayToken(sessionId);
      const session: ToolGatewaySession = {
        id: sessionId,
        token,
        companyId: input.companyId,
        agentId: input.agentId,
        runId: input.runId,
        issueId,
        projectId,
        createdAt: now,
        expiresAt: new Date(now.getTime() + sessionTtlMs(input.ttlMs)),
        responsibleUserId: input.authorizationActor?.type === "agent"
          ? input.authorizationActor.onBehalfOfUserId ?? null
          : null,
      };

      await db.insert(toolGatewaySessions).values({
        id: session.id,
        companyId: session.companyId,
        agentId: input.agentId,
        runId: input.runId,
        issueId: session.issueId,
        projectId: session.projectId,
        tokenHash: hashGatewayToken(token),
        expiresAt: session.expiresAt,
        createdAt: session.createdAt,
        updatedAt: session.createdAt,
      } as any);

      await writeAudit({
        session,
        companyId: session.companyId,
        agentId: session.agentId,
        runId: session.runId,
        issueId: session.issueId,
        actorType: input.actorType,
        actorId: input.actorId,
        action: "tool_gateway.session_created",
        details: {
          decision: "allow",
          reasonCode: "session_created",
          expiresAt: session.expiresAt.toISOString(),
        },
      });
      rememberSessionActor(session, input.authorizationActor);

      return session;
    },

    async listToolsForSession(
      sessionToken: string,
    ): Promise<ToolGatewayDescriptor[]> {
      const session = await getActiveSession(sessionToken);
      const tools = await listToolsForContext(session);
      await writeAudit({
        session,
        companyId: session.companyId,
        agentId: session.agentId,
        runId: session.runId,
        issueId: session.issueId,
        action: "tool_gateway.discovery",
        details: {
          decision: "allow",
          reasonCode: "discovery_filtered",
          visibleToolCount: tools.length,
          visibleTools: tools.map((tool) => tool.name),
        },
      });
      return tools;
    },

    async listPluginToolsForAgent(input: {
      companyId: string;
      agentId: string;
    }): Promise<AgentToolDescriptor[]> {
      await assertAgentInCompany(input.companyId, input.agentId);
      const decisions = await Promise.all(
        pluginTools().map(async (tool) => {
          const decision = await policyService.decide(
            policyInputForAgentTool({
              companyId: input.companyId,
              agentId: input.agentId,
              tool,
            }),
          );
          return { tool, decision };
        }),
      );
      return decisions
        .filter(
          ({ decision }) =>
            decision.allowed || decision.decision === "require_approval",
        )
        .map(({ tool }) => {
          const {
            providerType: _providerType,
            risk: _risk,
            ...descriptor
          } = tool;
          return descriptor;
        });
    },

    async summarizeConnectionAccessForAgent(input: {
      companyId: string;
      connectionId: string;
      agentId: string;
    }) {
      await assertAgentInCompany(input.companyId, input.agentId);
      const tools = await connectedMcpToolsForConnection(
        input.companyId,
        input.connectionId,
      );
      const decisions = await Promise.all(
        tools.map(async (tool) => {
          const decision = await policyService.decide(
            policyInputForAgentTool({
              companyId: input.companyId,
              agentId: input.agentId,
              tool,
            }),
          );
          const testDecision =
            decision.decision === "require_approval"
              ? "ask_first"
              : decision.allowed
                ? "allowed"
                : "off";
          return {
            toolName: tool.upstreamToolName ?? tool.name,
            gatewayToolName: tool.name,
            displayName: tool.displayName,
            risk: tool.risk,
            decision: testDecision,
            reasonCode: decision.reasonCode,
            matchedPolicyIds: decision.matchedPolicyIds,
            effectiveProfileIds: decision.effectiveProfileIds,
          };
        }),
      );
      const lastChange = await summarizeAccessLastChange({
        companyId: input.companyId,
        connectionId: input.connectionId,
        agentId: input.agentId,
        policyIds: [
          ...new Set(
            decisions.flatMap((decision) => decision.matchedPolicyIds),
          ),
        ],
        profileIds: [
          ...new Set(
            decisions.flatMap((decision) => decision.effectiveProfileIds),
          ),
        ],
      });
      return {
        connectionId: input.connectionId,
        toolCount: decisions.length,
        allowedCount: decisions.filter(
          (decision) => decision.decision === "allowed",
        ).length,
        askFirstCount: decisions.filter(
          (decision) => decision.decision === "ask_first",
        ).length,
        offCount: decisions.filter((decision) => decision.decision === "off")
          .length,
        lastChangedAt: lastChange.lastChangedAt,
        lastChangedByAgentId: lastChange.lastChangedByAgentId,
        lastChangedByName: lastChange.lastChangedByName,
        tools: decisions.map(
          ({ effectiveProfileIds: _effectiveProfileIds, ...tool }) => tool,
        ),
      };
    },

    async executeTestCall(input: ExecuteTestCallInput) {
      await assertAgentInCompany(input.companyId, input.agentId);
      const session: ToolGatewaySession = {
        id: "test-call",
        token: "test-call",
        companyId: input.companyId,
        agentId: input.agentId,
        runId: null,
        issueId: null,
        projectId: null,
        actorType: "user",
        actorId: input.userId,
        responsibleUserId: input.userId,
        createdAt: new Date(),
        expiresAt: new Date(Date.now() + DEFAULT_SESSION_TTL_MS),
      };
      const tool = (
        await connectedMcpToolsForConnection(
          input.companyId,
          input.connectionId,
        )
      ).find(
        (candidate) =>
          candidate.name === input.toolName ||
          candidate.upstreamToolName === input.toolName,
      );
      if (!tool) {
        throw new ToolGatewayHttpError(
          404,
          `Tool "${input.toolName}" not found`,
          "tool_not_found",
          {
            connectionId: input.connectionId,
            tool: input.toolName,
          },
        );
      }

      await assertConnectedToolModelEffects(session, tool);
      const requestedParameters = await governedToolArguments(
        session,
        tool,
        input.parameters ?? {},
      );
      const argumentValidation = validateToolContent({
        value: requestedParameters,
        direction: "arguments",
        sensitiveMode: "redact",
        promptInjectionMode: "ignore",
      });
      const decisionInput = policyInputForAgentTool({
        companyId: input.companyId,
        agentId: input.agentId,
        actorType: "user",
        actorId: input.userId,
        tool,
        parameters: requestedParameters,
        idempotencyKey: `test-call:${randomUUID()}`,
        consumeRateLimit: true,
      });
      const accessDecision = await policyService.decide(decisionInput);
      const recorded = await policyService.recordInvocation(
        decisionInput,
        accessDecision,
      );
      await policyService.writeAudit(decisionInput, accessDecision);
      const invocationId = recorded.invocation.id;

      if (accessDecision.decision === "require_approval") {
        if (!recorded.actionRequest) {
          throw new ToolGatewayHttpError(
            500,
            "Approval request was not created",
            "approval_request_missing",
            {
              invocationId,
              tool: tool.name,
            },
          );
        }
        const canonicalArguments = canonicalToolArguments(requestedParameters);
        const canonicalArgumentsHash = argumentValidation.summary.sha256 ?? "";
        const approvalSnapshot = await connectedRemoteApprovalSnapshot(
          session,
          tool,
          {
            requireResolvedCredentials: true,
          },
        );
        let signedArguments: ReturnType<typeof signToolArguments>;
        try {
          signedArguments = signToolArguments({
            invocationId,
            toolName: tool.name,
            canonicalArguments,
            approvalSnapshot: approvalSnapshot ?? undefined,
            executionOnApprove: true,
            signingSecret: options.toolActionSigningSecret,
          });
        } catch (error) {
          await db
            .update(toolActionRequests)
            .set({
              status: "cancelled",
              resolvedAt: new Date(),
              updatedAt: new Date(),
            })
            .where(
              and(
                eq(toolActionRequests.id, recorded.actionRequest.id),
                eq(toolActionRequests.status, "pending"),
              ),
            );
          if (error instanceof ToolActionSigningSecretMissingError) {
            await db
              .update(toolInvocations)
              .set({
                status: "failed",
                errorCode: "signing_secret_unconfigured",
                errorMessage: error.message,
                completedAt: new Date(),
                updatedAt: new Date(),
              })
              .where(eq(toolInvocations.id, invocationId));
            void emitConnectionInvoked(db, invocationId);
            throw new ToolGatewayHttpError(
              500,
              error.message,
              "signing_secret_unconfigured",
              {
                invocationId,
                tool: tool.name,
              },
            );
          }
          throw error;
        }
        const previewMarkdown = buildHumanizedActionPreview({
          tool,
          argumentsSummary: argumentValidation.summary,
        });
        await db
          .update(toolActionRequests)
          .set({
            canonicalArgumentsHash,
            canonicalArgumentsSummary: argumentValidation.summary,
            signedArguments,
            previewMarkdown,
            expiresAt: new Date(Date.now() + 60 * 60 * 1000),
            updatedAt: new Date(),
          })
          .where(eq(toolActionRequests.id, recorded.actionRequest.id));
        await writeToolCallEvent({
          invocationId,
          actionRequestId: recorded.actionRequest.id,
          session,
          eventType: "approval_requested",
          outcome: "pending",
          toolName: tool.name,
          policyDecision: "require_approval",
          reasonCode: accessDecision.reasonCode,
          argumentsSummary: argumentValidation.summary,
          metadata: {
            source: "test",
            actionRequestId: recorded.actionRequest.id,
          },
          tool,
        });
        await writeAudit({
          session,
          companyId: input.companyId,
          agentId: input.agentId,
          runId: null,
          issueId: null,
          actorType: "user",
          actorId: input.userId,
          action: "tool_gateway.approval_requested",
          details: {
            source: "test",
            invocationId,
            actionRequestId: recorded.actionRequest.id,
            decision: "require_approval",
            reasonCode: accessDecision.reasonCode,
            matchedPolicyIds: accessDecision.matchedPolicyIds,
            tool: tool.name,
            ...toolAuditMetadata(tool),
            argumentsSummary: argumentValidation.summary,
          },
        });
        return {
          decision: "ask_first" as const,
          invocationId,
          actionRequestId: recorded.actionRequest.id,
        };
      }

      if (!accessDecision.allowed) {
        // recordInvocation inserted this row already terminal (denied or
        // rate_limited), so this is its only completion boundary.
        void emitConnectionInvoked(db, invocationId);
        await writeAudit({
          session,
          companyId: input.companyId,
          agentId: input.agentId,
          runId: null,
          issueId: null,
          actorType: "user",
          actorId: input.userId,
          action: "tool_gateway.call_denied",
          details: {
            source: "test",
            invocationId,
            decision: accessDecision.decision,
            reasonCode: accessDecision.reasonCode,
            matchedPolicyIds: accessDecision.matchedPolicyIds,
            tool: tool.name,
            ...toolAuditMetadata(tool),
            argumentsSummary: argumentValidation.summary,
            rateLimitState: accessDecision.rateLimitState ?? null,
          },
        });
        return {
          decision: "off" as const,
          invocationId,
          error: {
            message: accessDecision.explanation,
            reasonCode: accessDecision.reasonCode,
          },
        };
      }

      return runTestToolInvocation({
        session,
        tool,
        parameters: requestedParameters,
        invocationId,
        companyId: input.companyId,
        agentId: input.agentId,
        userId: input.userId,
        argumentsSummary: argumentValidation.summary,
        reasonCode: accessDecision.reasonCode,
        matchedPolicyIds: accessDecision.matchedPolicyIds,
        timeoutMs: input.timeoutMs,
      });
    },

    /**
     * Live status of an ask-first test call, polled by the Test tab panel.
     * Scoped to the connection the panel is bound to and to test-origin
     * requests only, so it can't be used to read arbitrary action requests.
     */
    async getTestCallStatus(input: {
      companyId: string;
      connectionId: string;
      actionRequestId: string;
    }): Promise<ToolConnectionTestCallStatus> {
      const [actionRequest] = await db
        .select()
        .from(toolActionRequests)
        .where(eq(toolActionRequests.id, input.actionRequestId))
        .limit(1);
      if (!actionRequest || actionRequest.companyId !== input.companyId) {
        throw new ToolGatewayHttpError(
          404,
          "Tool action request not found",
          "action_request_not_found",
        );
      }
      const [invocation] = await db
        .select()
        .from(toolInvocations)
        .where(eq(toolInvocations.id, actionRequest.invocationId))
        .limit(1);
      if (!invocation || invocation.companyId !== input.companyId) {
        throw new ToolGatewayHttpError(
          404,
          "Tool invocation not found",
          "invocation_not_found",
        );
      }
      if (
        invocation.connectionId !== input.connectionId ||
        !isTestOriginInvocation(invocation)
      ) {
        throw new ToolGatewayHttpError(
          404,
          "Tool action request not found",
          "action_request_not_found",
        );
      }
      return buildTestCallStatus(actionRequest, invocation);
    },

    async sweepActionReviews() {
      // A process may stop between persisting a provider outcome and updating the
      // feed projection. Reconcile from authoritative rows before delivering it.
      const unreflected = await db
        .select({ request: toolActionRequests, invocation: toolInvocations })
        .from(toolActionRequests)
        .innerJoin(
          issueThreadInteractions,
          eq(issueThreadInteractions.id, toolActionRequests.interactionId),
        )
        .innerJoin(
          toolInvocations,
          eq(toolInvocations.id, toolActionRequests.invocationId),
        )
        .where(
          and(
            inArray(toolActionRequests.status, [
              "executed",
              "failed",
              "expired",
              "cancelled",
            ]),
            sql`coalesce(${issueThreadInteractions.result}->'toolAction'->>'status', '') <> case when ${toolActionRequests.status} = 'cancelled' then 'expired' else ${toolActionRequests.status} end`,
          ),
        )
        .limit(100);
      for (const { request, invocation } of unreflected)
        await reflectToolActionInteractionLifecycle({
          actionRequestId: request.id,
          status: request.status as
            "executed" | "failed" | "expired" | "cancelled",
          errorCode: invocation.errorCode,
          errorMessage: invocation.errorMessage,
          resultSummary: invocation.resultSummary?.summary,
        });
      const now = new Date();
      const staleAt = new Date(now.getTime() - 10 * 60_000);
      let cursor: string | undefined;
      let scanned = 0;
      for (;;) {
        const rows = await db
          .select()
          .from(toolActionRequests)
          .where(
            and(
              or(
                and(
                  eq(toolActionRequests.status, "pending"),
                  lte(toolActionRequests.expiresAt, now),
                ),
                eq(toolActionRequests.status, "approved"),
                and(
                  eq(toolActionRequests.status, "executing"),
                  lte(toolActionRequests.updatedAt, staleAt),
                ),
              ),
              cursor ? gt(toolActionRequests.id, cursor) : undefined,
            ),
          )
          .orderBy(asc(toolActionRequests.id))
          .limit(100);
        for (const row of rows) {
          if (row.status === "approved") {
            await this.approveActionRequest({
              companyId: row.companyId,
              actionRequestId: row.id,
              actor: { userId: row.decidedByUserId ?? row.resolvedByUserId },
            }).catch((error) =>
              logger.warn(
                { err: error, actionRequestId: row.id },
                "Could not recover approved tool action",
              ),
            );
            continue;
          }
          const status = row.status === "pending" ? "expired" : "failed";
          const errorCode =
            status === "failed"
              ? "tool_execution_outcome_unknown"
              : "action_expired";
          const errorMessage =
            status === "failed"
              ? "Execution was interrupted; the external outcome is unknown. Inspect the provider before retrying."
              : "The approval request expired before a decision.";
          const [changed] = await db
            .update(toolActionRequests)
            .set({ status, resolvedAt: now, updatedAt: now })
            .where(
              and(
                eq(toolActionRequests.id, row.id),
                eq(toolActionRequests.status, row.status),
                eq(toolActionRequests.updatedAt, row.updatedAt),
              ),
            )
            .returning();
          if (!changed) continue;
          await db
            .update(toolInvocations)
            .set({
              status: "failed",
              errorCode,
              errorMessage,
              completedAt: now,
              updatedAt: now,
            })
            .where(eq(toolInvocations.id, row.invocationId));
          void emitConnectionInvoked(db, row.invocationId);
          await reflectToolActionInteractionLifecycle({
            actionRequestId: row.id,
            status,
            errorCode,
            errorMessage,
          });
        }
        scanned += rows.length;
        if (rows.length < 100) break;
        cursor = rows[rows.length - 1].id;
      }
      return { scanned };
    },

    async approveActionRequest(input: {
      companyId: string;
      rememberAction?: boolean;
      issueId?: string;
      interactionId?: string;
      actionRequestId: string;
      actor: { agentId?: string | null; userId?: string | null };
    }) {
      if (input.actor.agentId)
        throw new ToolGatewayHttpError(
          403,
          "Only a human can resolve a tool review",
          "human_review_required",
        );
      const [actionRequest] = await db
        .select()
        .from(toolActionRequests)
        .where(eq(toolActionRequests.id, input.actionRequestId))
        .limit(1);
      if (!actionRequest || actionRequest.companyId !== input.companyId) {
        throw new ToolGatewayHttpError(
          404,
          "Tool action request not found",
          "action_request_not_found",
        );
      }
      const [invocation] = await db
        .select()
        .from(toolInvocations)
        .where(eq(toolInvocations.id, actionRequest.invocationId))
        .limit(1);
      if (!invocation || invocation.companyId !== input.companyId) {
        throw new ToolGatewayHttpError(
          404,
          "Tool invocation not found",
          "invocation_not_found",
        );
      }
      if (input.issueId !== undefined || input.interactionId !== undefined) {
        if (
          !input.issueId ||
          !input.interactionId ||
          actionRequest.issueId !== input.issueId ||
          actionRequest.interactionId !== input.interactionId ||
          invocation.issueId !== input.issueId
        ) {
          throw new ToolGatewayHttpError(
            409,
            "Tool action request does not belong to this interaction",
            "action_context_mismatch",
          );
        }
        const [originatingInteraction] = await db
          .select({ id: issueThreadInteractions.id })
          .from(issueThreadInteractions)
          .where(
            and(
              eq(issueThreadInteractions.id, input.interactionId),
              eq(issueThreadInteractions.companyId, input.companyId),
              eq(issueThreadInteractions.issueId, input.issueId),
            ),
          )
          .limit(1);
        if (!originatingInteraction) {
          throw new ToolGatewayHttpError(
            409,
            "Tool action request does not belong to this interaction",
            "action_context_mismatch",
          );
        }
      }
      if (
        ["executing", "executed", "failed"].includes(actionRequest.status) &&
        actionRequest.decidedAt
      ) {
        await options.onToolActionSettled?.(actionRequest.id);
        return actionRequestResolution(actionRequest);
      }
      if (
        actionRequest.status !== "pending" &&
        actionRequest.status !== "approved"
      ) {
        throw new ToolGatewayHttpError(
          409,
          "Tool action request is no longer pending",
          "action_not_pending",
        );
      }
      let signedPayload: ReturnType<typeof readSignedToolArgumentsPayload> =
        null;
      try {
        signedPayload = readSignedToolArgumentsPayload({
          signedArguments: actionRequest.signedArguments,
          invocationId: invocation.id,
          toolName: invocation.toolName,
          signingSecret: options.toolActionSigningSecret,
        });
      } catch {
        signedPayload = null;
      }
      if (!signedPayload) {
        if (actionRequest.status === "pending") {
          await db
            .update(toolActionRequests)
            .set({
              status: "cancelled",
              resolvedAt: new Date(),
              updatedAt: new Date(),
            })
            .where(
              and(
                eq(toolActionRequests.id, actionRequest.id),
                eq(toolActionRequests.status, "pending"),
              ),
            );
        }
        await reflectToolActionInteractionLifecycle({
          actionRequestId: actionRequest.id,
          status: "cancelled",
        });
        throw new ToolGatewayHttpError(
          409,
          "Tool action request is no longer approvable; refresh the review queue",
          "action_request_invalidated",
        );
      }
      if (actionRequest.approvalId) {
        const [formalApproval] = await db
          .select({ status: approvals.status })
          .from(approvals)
          .where(
            and(
              eq(approvals.id, actionRequest.approvalId),
              eq(approvals.companyId, input.companyId),
            ),
          )
          .limit(1);
        if (!formalApproval || formalApproval.status !== "approved") {
          throw new ToolGatewayHttpError(
            409,
            "Tool action request requires formal board approval before execution",
            "formal_approval_required",
            { approvalId: actionRequest.approvalId },
          );
        }
      }
      if (actionRequest.status === "approved") {
        await reflectToolActionInteractionLifecycle({
          actionRequestId: actionRequest.id,
          status: "approved",
        });
        if (
          !isTestOriginInvocation(invocation) &&
          signedPayload.executionOnApprove === true
        ) {
          try {
            await executeApprovedAgentInvocation({ actionRequest, invocation });
          } catch {
            // The execution outcome is persisted on the invocation/request and
            // reflected onto the accepted interaction for the continuation wake.
          }
          const [settled] = await db
            .select()
            .from(toolActionRequests)
            .where(eq(toolActionRequests.id, actionRequest.id))
            .limit(1);
          return actionRequestResolution(settled ?? actionRequest);
        }
        return actionRequest;
      }
      if (actionRequest.expiresAt && actionRequest.expiresAt <= new Date())
        throw new ToolGatewayHttpError(
          409,
          "Tool review has expired",
          "action_expired",
        );
      if (
        !isTestOriginInvocation(invocation) &&
        signedPayload.executionOnApprove === true
      ) {
        const [issue] = invocation.issueId ? await db
          .select()
          .from(issues)
          .where(
            and(
              eq(issues.id, invocation.issueId!),
              eq(issues.companyId, input.companyId),
            ),
          )
          .limit(1) : [];
        if (!invocation.workflowRunId && (!issue || issue.status === "done" || issue.status === "cancelled"))
          throw new ToolGatewayHttpError(
            409,
            "Task is closed",
            "action_task_closed",
          );
        const session: ToolGatewaySession = invocation.workflowRunId
          ? await workflowApprovedActionSession(invocation)
          : {
          id: `review:${actionRequest.id}`,
          token: "",
          companyId: input.companyId,
          agentId: invocation.agentId,
          runId: invocation.runId,
          issueId: issue!.id,
          projectId: issue!.projectId,
          createdAt: new Date(),
          expiresAt: new Date(Date.now() + DEFAULT_SESSION_TTL_MS),
        };
        await restoreApprovedActionIdentity(
          session,
          signedPayload.identityContextId,
        );
        session.approvedSlackInvocationId = invocation.id;
        const tool = await findToolForSession(session, invocation.toolName);
        if (
          !approvalSnapshotsMatch(
            signedPayload.approvalSnapshot,
            await connectedRemoteApprovalSnapshot(session, tool),
          )
        )
          throw new ToolGatewayHttpError(
            409,
            "Tool definition or connection changed; request a new review",
            "approved_tool_target_changed",
          );
        const access = await policyService.decide(
          policyInputForTool({
            session,
            tool,
            parameters: signedPayload.arguments,
          }),
        );
        if (!access.allowed && access.decision !== "require_approval")
          throw new ToolGatewayHttpError(
            403,
            access.explanation,
            access.reasonCode,
          );
      }
      const updated = await commitToolActionReview(db, {
        ...input,
        decision: "approved",
      });
      await reflectToolActionInteractionLifecycle({
        actionRequestId: updated.id,
        status: "approved",
      });
      // A test-tab ask-first request has no agent run to carry out the parked
      // call, so approving it is what runs it. Execute against the signed
      // arguments and record the result on the invocation for the live panel.
      if (isTestOriginInvocation(invocation)) {
        await runApprovedTestInvocation(
          { ...invocation, approvalState: "approved" },
          signedPayload.arguments,
          updated.id,
        );
      } else if (signedPayload.executionOnApprove === true) {
        try {
          await executeApprovedAgentInvocation({
            actionRequest: updated,
            invocation,
          });
        } catch {
          // Persisted failure is the approval result; accepting the card itself
          // remains successful and the agent wake receives the failure context.
        }
      }
      const [settled] = await db
        .select()
        .from(toolActionRequests)
        .where(eq(toolActionRequests.id, updated.id))
        .limit(1);
      return actionRequestResolution(settled ?? updated);
    },

    async declineActionRequest(input: {
      companyId: string;
      issueId?: string;
      interactionId?: string;
      actionRequestId: string;
      reason?: string;
      actor: { agentId?: string | null; userId?: string | null };
    }) {
      const updated = await commitToolActionReview(db, {
        ...input,
        decision: "rejected",
      });
      await options
        .onToolActionSettled?.(updated.id)
        .catch((error) =>
          logger.warn(
            { err: error, actionRequestId: updated.id },
            "Tool review continuation will be retried",
          ),
        );
      return updated;
    },

    async listScopedTools(context: ScopedToolGatewayContext) {
      await context.assertCurrent();
      const discoveryCatalogEntryIds = context.discoveryCatalogEntryIds ? new Set(context.discoveryCatalogEntryIds) : null;
      const tools = (await listToolsForContext(context.session)).filter(tool =>
        tool.connectionId && ["mcp_remote_http", "mcp_local_stdio"].includes(tool.providerType) &&
        (!discoveryCatalogEntryIds || typeof tool.catalogEntryId === "string" && discoveryCatalogEntryIds.has(tool.catalogEntryId)));
      const visible: ToolGatewayDescriptor[] = [];
      // ponytail: bound per-tool authority checks to 100; paginate larger inventories.
      for (const tool of tools.slice(0, 100)) {
        try { await context.assertCurrent(tool); await context.assertManifestCurrent?.(tool); visible.push(tool); }
        catch (error) {
          if (!(error instanceof Error && "status" in error && error.status === 403)) throw error;
        }
      }
      await context.assertCurrent();
      return visible;
    },

    async executeTool(input: ExecuteGatewayToolInput, workflowContext?: WorkflowGatewayContext, scopedContext?: ScopedToolGatewayContext) {
      if (scopedContext) {
        if (workflowContext || input.approvedActionRequestId || input.callerHeaders || input.gatewayId || input.gatewayPublicId) {
          throw new ToolGatewayHttpError(403, "Scoped tools cannot inherit another execution or approval", "scoped_tool_context_invalid");
        }
        await scopedContext.assertCurrent();
      }
      const workflowBinding = workflowContext ? await resolveWorkflowConnectorSession(db, workflowContext,
        input.idempotencyKey, options.deploymentMode) : null;
      const session = scopedContext?.session ?? workflowBinding?.session ?? await getActiveSession(input.sessionToken, {
        gatewayId: input.gatewayId ?? null,
        gatewayPublicId: input.gatewayPublicId ?? null,
        protocolMethod: "tools/call",
        callerHeaders: input.callerHeaders,
      });
      await assertGatewayTokenAction(session, "tools/call");
      if (allTools().some(tool => tool.name === input.tool && tool.providerType === "paperclip_plugin")) {
        await assertToolInternalInferenceAdmitted(session);
      }
      let invocationId = String(randomUUID());
      const startedAt = Date.now();

      // A retry carries the signed originating operation, even if steering has
      // since accepted instructions from someone else in this same run.
      if (input.approvedActionRequestId) {
        const [request] = await db
          .select()
          .from(toolActionRequests)
          .where(
            and(
              eq(toolActionRequests.id, input.approvedActionRequestId),
              eq(toolActionRequests.companyId, session.companyId),
            ),
          );
        const [invocation] = request
          ? await db
              .select()
              .from(toolInvocations)
              .where(
                and(
                  eq(toolInvocations.id, request.invocationId),
                  eq(toolInvocations.companyId, session.companyId),
                  eq(toolInvocations.runId, session.runId!),
                  eq(toolInvocations.agentId, session.agentId!),
                ),
              )
          : [];
        const payload =
          request && invocation
            ? readSignedToolArgumentsPayload({
                signedArguments: request.signedArguments,
                invocationId: invocation.id,
                toolName: invocation.toolName,
                signingSecret: options.toolActionSigningSecret,
              })
            : null;
        if (payload?.identityContextId) {
          const [origin] = await db
            .select()
            .from(runIdentityContexts)
            .where(
              and(
                eq(runIdentityContexts.id, payload.identityContextId),
                eq(runIdentityContexts.companyId, session.companyId),
                eq(runIdentityContexts.runId, session.runId!),
                eq(runIdentityContexts.status, "accepted"),
              ),
            );
          if (!origin)
            throw new ToolGatewayHttpError(
              409,
              "Approved action identity is unavailable",
              "identity_context_unavailable",
            );
          session.identityContextId = origin.id;
          session.responsibleUserId =
            origin.cause === "company_default"
              ? null
              : origin.responsibleUserId;
        }
      }
      if (workflowBinding) {
        const tools = [
          ...await connectedMcpToolsForCompany(session.companyId),
          ...await staticToolsForSession(session),
          ...await githubBotToolsForSession(db, session),
          ...await slackToolsForSession(db, session),
        ];
        const bound = tools.find((candidate) => candidate.catalogEntryId === workflowBinding.entry.id &&
          candidate.connectionId === workflowBinding.entry.connectionId);
        if (!bound) throw new ToolGatewayHttpError(404, "Published connector is unavailable", "workflow_connector_unavailable");
        input = { ...input, tool: bound.name };
      }
      let tool = await findToolForSession(session, input.tool);
      await assertConnectedToolModelEffects(session, tool);
      const scopedMemoryCapture = nativeMemoryOutputCapture(scopedContext);
      if (scopedMemoryCapture) {
        const capture = scopedMemoryCapture;
        const use = capture.managedOpenCodeToolUse;
        if (tool.name !== "paperclip-self:remember" || tool.providerType !== "paperclip_self" ||
          tool.pluginId !== "paperclip-self" || !use || use.toolName !== tool.name ||
          capture.runId !== session.runId || capture.dispatch.runId !== session.runId ||
          !session.agentId || !session.issueId ||
          !capture.sourceSet.inputs.some(source => source.kind === "task" && source.issueId === session.issueId) ||
          use.argumentsHash !== nativeSha256(input.parameters ?? {})) {
          throw new ToolGatewayHttpError(403, "Native Memory output capture does not match this scoped call", "native_memory_capture_invalid");
        }
        const [capturedRun] = await db.select({ agentId: heartbeatRuns.agentId, issueId: heartbeatRuns.nativeIssueId,
          responsibleUserId: heartbeatRuns.responsibleUserId }).from(heartbeatRuns).where(and(
          eq(heartbeatRuns.companyId, session.companyId), eq(heartbeatRuns.id, capture.runId),
        ));
        if (!capturedRun || capturedRun.agentId !== session.agentId || capturedRun.issueId !== session.issueId ||
          capturedRun.responsibleUserId !== (session.responsibleUserId ?? null))
          throw new ToolGatewayHttpError(403, "Native Memory output session binding changed", "native_memory_capture_invalid");
        // The canonical Native Memory write transaction revalidates this exact
        // capture after reading the persisted detail and before commit; sealing
        // repeats the complete check once the Gateway invocation succeeds.
        input = { ...input, idempotencyKey: `aw-native-tool:${capture.runId}:${use.callId}` };
      }
      const revalidateScopedMemoryReplay = async (replay: { invocationId: string; argumentsHash: string; result: unknown }) => {
        if (!scopedMemoryCapture) return;
        const replayIssueId = session.issueId;
        const replayAgentId = session.agentId;
        const replayRunId = session.runId;
        if (!replayIssueId) throw new ToolGatewayHttpError(403,
          "Managed Memory replay has no current Task binding", "native_memory_capture_invalid");
        if (!replay.argumentsHash || !replayAgentId || !replayRunId) throw new ToolGatewayHttpError(403,
          "Managed Memory replay receipt is unavailable", "native_memory_capture_invalid");
        const { assertNativeModelOutputCaptureCurrent } = await import("./native-direct-input.js");
        const { lockAnalyticalCompany } = await import("./analytical-privacy.js");
        const { lockMemoryPrivacy } = await import("./memory/memory-privacy.js");
        await db.transaction(async rawTx => {
          const tx = rawTx as unknown as Db;
          await lockAnalyticalCompany(tx, session.companyId);
          await lockMemoryPrivacy(tx, session.companyId);
          const outputReceipt = await assertScopedNativeMemoryReplayReceiptCurrent(tx, { companyId: session.companyId,
            runId: replayRunId, agentId: replayAgentId, issueId: replayIssueId,
            callId: scopedMemoryCapture.managedOpenCodeToolUse!.callId,
            invocationId: replay.invocationId, argumentsHash: replay.argumentsHash,
            result: replay.result });
          // Recheck consumed inputs after output receipt reads, then apply the output's current reader policy.
          await assertNativeModelOutputCaptureCurrent(tx, session.companyId, replayIssueId, scopedMemoryCapture,
            "paperclip-self:remember");
          const { canActorReadMemorySources, memoryPayloadVisible } = await import("./memory/memory-privacy.js");
          const currentReader = currentSessionMemoryActor(session);
          if (!currentReader || !await canActorReadMemorySources(tx, session.companyId, currentReader, outputReceipt.recordId))
            throw new ToolGatewayHttpError(403, "Managed Memory output destination is no longer readable",
              "native_memory_capture_invalid");
          const [stillCurrent] = await tx.select({ payloadSourceSnapshot: memoryRecords.payloadSourceSnapshot })
            .from(memoryRecords).where(and(eq(memoryRecords.companyId, session.companyId),
              eq(memoryRecords.id, outputReceipt.recordId), memoryPayloadVisible(), isNull(memoryRecords.revokedAt),
              or(isNull(memoryRecords.expiresAt), gt(memoryRecords.expiresAt, sql`clock_timestamp()`)),
              eq(memoryRecords.retentionState, "active"), inArray(memoryRecords.reviewState, ["pending", "accepted"]),
              eq(memoryRecords.payloadSourceSnapshotInvalidated, false), eq(memoryRecords.payloadSourceProtocolVersion, 1)))
            .for("share");
          const { nativePayloadSourceSnapshotSchema } = await import("@paperclipai/shared");
          const finalSnapshot = nativePayloadSourceSnapshotSchema.safeParse(stillCurrent?.payloadSourceSnapshot);
          if (!finalSnapshot.success || finalSnapshot.data.digest !== outputReceipt.snapshotDigest)
            throw new ToolGatewayHttpError(403, "Managed Memory output changed during replay validation",
              "native_memory_capture_invalid");
        });
      };
      if (scopedContext && tool.name === "paperclip-self:remember" && !scopedMemoryCapture) {
        throw new ToolGatewayHttpError(403, "Managed Native Memory writes require a current provider tool-use capture", "native_memory_capture_required");
      }
      if (scopedContext && tool.providerType === "paperclip_virtual" && tool.name !== "run_tool") {
        throw new ToolGatewayHttpError(403, "Scoped runs discover connected tools through tool.list", "scoped_tool_not_connected");
      }
      if (workflowBinding && (tool.catalogEntryId !== workflowBinding.entry.id || tool.connectionId !== workflowBinding.entry.connectionId)) {
        throw new ToolGatewayHttpError(403, "Connector does not match its published binding", "workflow_connector_binding_invalid");
      }
      if (tool.providerType === "paperclip_slack_chat") {
        const definition = SLACK_TOOLS.find(t => t.name === tool.upstreamToolName);
        const args = definition?.schema.parse(input.parameters ?? {}) as Record<string, unknown> | undefined;
        if (!args) throw new ToolGatewayHttpError(403, "Unknown Slack operation", "slack_task_required");
        if (typeof args.idempotencyKey === "string") {
          const key = `slack:${tool.connectionId}:${session.issueId}:${session.responsibleUserId}:${args.idempotencyKey}`;
          const [prior] = await db.select().from(toolInvocations).where(and(eq(toolInvocations.companyId, session.companyId), eq(toolInvocations.idempotencyKey, key)));
          const currentHash = validateToolContent({ value: args, direction: "arguments", sensitiveMode: "redact", promptInjectionMode: "ignore" }).summary.sha256;
          if (prior && (prior.toolName !== tool.name || prior.argumentsHash !== currentHash)) throw new ToolGatewayHttpError(409, "Idempotency key belongs to a different Slack operation", "slack_idempotency_conflict");
          input = { ...input, idempotencyKey: key };
        }
      }
      let virtualToolName: string | null = null;
      let requestedParameters: unknown = input.parameters ?? {};

      if (
        tool.name === "search_tools" &&
        tool.providerType === "paperclip_virtual"
      ) {
        const argumentValidation = validateToolContent({
          value: requestedParameters,
          direction: "arguments",
          sensitiveMode: "redact",
          promptInjectionMode: "ignore",
        });
        const result = await executeVirtualSearchTools(
          session,
          requestedParameters,
        );
        const resultValidation = validateToolContent({
          value: result,
          direction: "result",
          sensitiveMode: "redact",
          promptInjectionMode: "block",
        });
        const [invocation] = await db
          .insert(toolInvocations)
          .values({
            companyId: session.companyId,
            actorType:
              session.actorType ?? (session.agentId ? "agent" : "system"),
            actorId:
              session.actorId ??
              session.agentId ??
              session.gatewayTokenId ??
              session.companyId,
            agentId: session.agentId,
            issueId: session.issueId,
            runId: session.runId,
            providerType: "paperclip_virtual",
            upstreamToolName: "search_tools",
            riskLevel: "read",
            toolName: "search_tools",
            argumentsHash: argumentValidation.summary.sha256 ?? null,
            argumentsSummary: argumentValidation.summary,
            policyDecision: "allow",
            matchedPolicyIds: [],
            approvalState: "not_required",
            status: "succeeded",
            resultHash: resultValidation.summary.sha256 ?? null,
            resultSummary: resultValidation.summary,
            workflowResultJson: session.workflowRunId ? typedWorkflowToolResult(tool, resultValidation.value) : null,
            resultSizeBytes: resultValidation.summary.sizeBytes ?? null,
            startedAt: new Date(),
            completedAt: new Date(),
          })
          .returning();
        await writeToolCallEvent({
          invocationId: invocation.id,
          session,
          eventType: "call_completed",
          outcome: "success",
          toolName: "search_tools",
          policyDecision: "allow",
          reasonCode: "virtual_tool_completed",
          argumentsSummary: argumentValidation.summary,
          resultSummary: resultValidation.summary,
          metadata: { virtualToolName: "search_tools" },
          tool,
        });
        await writeAudit({
          session,
          companyId: session.companyId,
          agentId: session.agentId,
          runId: session.runId,
          issueId: session.issueId,
          action: "tool_gateway.call_completed",
          details: {
            invocationId: invocation.id,
            decision: "allow",
            reasonCode: "virtual_tool_completed",
            tool: "search_tools",
            virtualToolName: "search_tools",
            durationMs: Date.now() - startedAt,
            argumentsSummary: argumentValidation.summary,
            result: summarizeResult(resultValidation.value),
            resultSummary: resultValidation.summary,
          },
        });
        return {
          invocationId: invocation.id,
          status: "completed" as const,
          tool: "search_tools",
          result: session.workflowRunId ? typedWorkflowToolResult(tool, resultValidation.value) : resultValidation.value,
        };
      }

      if (
        tool.name === "run_tool" &&
        tool.providerType === "paperclip_virtual"
      ) {
        const { targetToolName, targetParameters } =
          virtualRunToolInput(requestedParameters);
        const targetTool = await findToolForSession(session, targetToolName);
        if (!isOnDemandRemoteTool(targetTool)) {
          throw new ToolGatewayHttpError(
            404,
            `Tool "${targetToolName}" not found`,
            "tool_not_found",
            { tool: targetToolName },
          );
        }
        virtualToolName = "run_tool";
        tool = targetTool;
        requestedParameters = targetParameters;
      }

      if (scopedContext) {
        const nativeMemoryCall = Boolean(scopedMemoryCapture && tool.name === "paperclip-self:remember" &&
          tool.providerType === "paperclip_self");
        if (!nativeMemoryCall && (!tool.connectionId || !["mcp_remote_http", "mcp_local_stdio"].includes(tool.providerType))) {
          throw new ToolGatewayHttpError(403, "Scoped calls require a local connected tool", "scoped_tool_not_connected");
        }
        await scopedContext.assertCurrent(tool);
      }

      // Managed provider arguments are part of the governed call, not a
      // transport decoration. Project them before hashing, policy evaluation,
      // approval signing, previews, and audit summaries. Approved retries
      // re-project only for a compatibility comparison and dispatch the
      // already-reviewed signed payload unchanged.
      if (!input.approvedActionRequestId) {
        requestedParameters = await governedToolArguments(
          session,
          tool,
          requestedParameters,
        );
      }

      const argumentValidation = validateToolContent({
        value: requestedParameters,
        direction: "arguments",
        sensitiveMode: "redact",
        promptInjectionMode: "ignore",
      });
      let effectiveParameters: unknown = requestedParameters;
      let effectiveArgumentsSummary = argumentValidation.summary;

      if (!input.approvedActionRequestId) {
        const replay = await replayMatchingAgentAction({
          session,
          toolName: tool.name,
          argumentsHash: argumentValidation.summary.sha256 ?? "",
        });
        if (replay?.matched) {
          if (tool.providerType === "paperclip_self") {
            // Preserve the original Gateway invocation and its receipt, but
            // re-enter the original semantic owner before returning any
            // first-party replay. The manifest classifies its effect and the
            // matching builtin remains its original executable owner. The
            // owner rechecks current source, Human, ACL, and Skill authority;
            // current Tool Gateway policy is also required. An operation
            // without a known safe owner class fails closed instead of using
            // the generic cached result.
            const currentPolicy = await policyService.decide(policyInputForTool({
              session,
              tool,
              parameters: requestedParameters,
              consumeRateLimit: true,
            }));
            if (!currentPolicy.allowed) {
              throw new ToolGatewayHttpError(403, "Current Tool Gateway policy no longer permits this operation", "tool_policy_denied");
            }
            const refreshed = await revalidateFirstPartyBuiltinReplay(session, tool, requestedParameters, replay.invocationId);
            return {
              invocationId: replay.invocationId,
              status: "replayed" as const,
              tool: virtualToolName ?? tool.name,
              targetTool: virtualToolName ? tool.name : undefined,
              result: refreshed,
            };
          }
          await revalidateScopedMemoryReplay({ invocationId: replay.invocationId,
            argumentsHash: argumentValidation.summary.sha256 ?? "", result: replay.result });
          return {
            invocationId: replay.invocationId,
            status: "replayed" as const,
            tool: virtualToolName ?? tool.name,
            targetTool: virtualToolName ? tool.name : undefined,
            result: replay.result,
          };
        }
      }

      if (input.approvedActionRequestId) {
        let [actionRequest] = await db
          .select()
          .from(toolActionRequests)
          .where(eq(toolActionRequests.id, input.approvedActionRequestId))
          .limit(1);
        if (!actionRequest || actionRequest.companyId !== session.companyId) {
          throw new ToolGatewayHttpError(
            404,
            "Tool action request not found",
            "action_request_not_found",
          );
        }
        const [storedInvocation] = await db
          .select()
          .from(toolInvocations)
          .where(eq(toolInvocations.id, actionRequest.invocationId))
          .limit(1);
        if (
          !storedInvocation ||
          storedInvocation.companyId !== session.companyId
        ) {
          throw new ToolGatewayHttpError(
            404,
            "Tool invocation not found",
            "invocation_not_found",
          );
        }
        if (
          actionRequest.issueId !== session.issueId ||
          storedInvocation.issueId !== session.issueId ||
          storedInvocation.agentId !== session.agentId ||
          storedInvocation.runId !== session.runId ||
          actionRequest.requestedByAgentId !== session.agentId
        ) {
          throw new ToolGatewayHttpError(
            403,
            "Approved action request is not scoped to this gateway session",
            "action_scope_mismatch",
          );
        }
        if (!actionRequest.issueId || !actionRequest.interactionId) {
          throw new ToolGatewayHttpError(
            403,
            "Approved action request is missing issue scope",
            "action_scope_mismatch",
          );
        }
        const actionIssueId: string = actionRequest.issueId;
        const [linkedInteraction] = await db
          .select({
            id: issueThreadInteractions.id,
            issueId: issueThreadInteractions.issueId,
            companyId: issueThreadInteractions.companyId,
          })
          .from(issueThreadInteractions)
          .where(
            and(
              eq(issueThreadInteractions.id, actionRequest.interactionId),
              eq(issueThreadInteractions.companyId, session.companyId),
              eq(issueThreadInteractions.issueId, actionIssueId),
            ),
          )
          .limit(1);
        if (!linkedInteraction) {
          throw new ToolGatewayHttpError(
            403,
            "Approved action request is not linked to its originating interaction",
            "action_scope_mismatch",
          );
        }
        if (storedInvocation.toolName !== tool.name) {
          throw new ToolGatewayHttpError(
            409,
            "Approved action request is for a different tool",
            "action_tool_mismatch",
          );
        }
        if (
          actionRequest.expiresAt &&
          actionRequest.expiresAt.getTime() <= Date.now()
        ) {
          const expiredAt = new Date();
          const [expired] = await db
            .update(toolActionRequests)
            .set({
              status: "expired",
              resolvedAt: expiredAt,
              updatedAt: expiredAt,
            })
            .where(
              and(
                eq(toolActionRequests.id, actionRequest.id),
                inArray(toolActionRequests.status, ["pending", "approved"]),
              ),
            )
            .returning({ id: toolActionRequests.id });
          if (expired) {
            await reflectToolActionInteractionLifecycle({
              actionRequestId: expired.id,
              status: "expired",
            });
          }
          throw new ToolGatewayHttpError(
            409,
            "Tool action request approval has expired",
            "action_expired",
          );
        }
        if (actionRequest.status === "pending" && actionRequest.interactionId) {
          const [interaction] = await db
            .select({
              status: issueThreadInteractions.status,
              kind: issueThreadInteractions.kind,
              resolvedByAgentId: issueThreadInteractions.resolvedByAgentId,
              resolvedByUserId: issueThreadInteractions.resolvedByUserId,
              resolvedAt: issueThreadInteractions.resolvedAt,
            })
            .from(issueThreadInteractions)
            .where(
              and(
                eq(issueThreadInteractions.id, actionRequest.interactionId),
                eq(issueThreadInteractions.companyId, session.companyId),
                eq(issueThreadInteractions.issueId, actionIssueId),
              ),
            )
            .limit(1);
          if (
            interaction?.kind === "request_confirmation" &&
            interaction.status === "accepted"
          ) {
            const [approved] = await db
              .update(toolActionRequests)
              .set({
                status: "approved",
                resolvedByAgentId: interaction.resolvedByAgentId ?? null,
                resolvedByUserId: interaction.resolvedByUserId ?? null,
                decidedByAgentId: interaction.resolvedByAgentId ?? null,
                decidedByUserId: interaction.resolvedByUserId ?? null,
                decidedAt: interaction.resolvedAt ?? new Date(),
                resolvedAt: interaction.resolvedAt ?? new Date(),
                updatedAt: new Date(),
              })
              .where(
                and(
                  eq(toolActionRequests.id, actionRequest.id),
                  eq(toolActionRequests.status, "pending"),
                ),
              )
              .returning();
            if (!approved) {
              throw new ToolGatewayHttpError(
                409,
                "Tool action request has already been resolved",
                "action_already_resolved",
              );
            }
            actionRequest = approved;
            await reflectToolActionInteractionLifecycle({
              actionRequestId: approved.id,
              status: "approved",
            });
            await writeToolCallEvent({
              invocationId: storedInvocation.id,
              actionRequestId: actionRequest.id,
              session,
              eventType: "approval_resolved",
              outcome: "success",
              toolName: tool.name,
              policyDecision: "require_approval",
              reasonCode: "interaction_accepted",
              metadata: {
                actionRequestId: actionRequest.id,
                interactionId: actionRequest.interactionId,
              },
              tool,
            });
          }
        }
        if (actionRequest.status !== "approved") {
          throw new ToolGatewayHttpError(
            409,
            "Tool action request is not approved or was already consumed",
            "action_not_approved",
          );
        }
        if (actionRequest.approvalId) {
          const [formalApproval] = await db
            .select({ status: approvals.status })
            .from(approvals)
            .where(
              and(
                eq(approvals.id, actionRequest.approvalId),
                eq(approvals.companyId, session.companyId),
              ),
            )
            .limit(1);
          if (!formalApproval || formalApproval.status !== "approved") {
            throw new ToolGatewayHttpError(
              409,
              "Tool action request requires formal board approval before execution",
              "formal_approval_required",
              { approvalId: actionRequest.approvalId },
            );
          }
        }
        const signedPayload = readSignedToolArgumentsPayload({
          signedArguments: actionRequest.signedArguments,
          invocationId: storedInvocation.id,
          toolName: storedInvocation.toolName,
          signingSecret: options.toolActionSigningSecret,
        });
        if (!signedPayload) {
          throw new ToolGatewayHttpError(
            409,
            "Approved tool action arguments signature is invalid",
            "signed_arguments_invalid",
          );
        }
        if (signedPayload.executionOnApprove !== true) {
          const error = new ToolGatewayHttpError(
            409,
            "This approval predates execute-on-approve and must remain inert",
            "legacy_approved_action_inert",
          );
          await options.beforeLegacyApprovedActionClaim?.();
          const claimedAt = new Date();
          const [claimed] = await db
            .update(toolActionRequests)
            .set({
              status: "executing",
              resolvedByAgentId: session.agentId,
              updatedAt: claimedAt,
            })
            .where(
              and(
                eq(toolActionRequests.id, actionRequest.id),
                eq(toolActionRequests.status, "approved"),
              ),
            )
            .returning();
          if (!claimed) {
            throw new ToolGatewayHttpError(
              409,
              "Tool action request was already consumed",
              "action_already_consumed",
            );
          }
          await reflectToolActionInteractionLifecycle({
            actionRequestId: claimed.id,
            status: "executing",
          });
          await markApprovedActionFailed({
            actionRequestId: claimed.id,
            invocationId: storedInvocation.id,
            claimUpdatedAt: claimed.updatedAt,
            expectedInvocationStatus: "awaiting_approval",
            error,
          });
          throw error;
        }
        const liveApprovalSnapshot = await connectedRemoteApprovalSnapshot(
          session,
          tool,
        );
        if (
          !approvalSnapshotsMatch(
            signedPayload.approvalSnapshot,
            liveApprovalSnapshot,
          )
        ) {
          throw new ToolGatewayHttpError(
            409,
            "Approved tool action target changed after review",
            "approved_tool_target_changed",
            {
              invocationId: storedInvocation.id,
              actionRequestId: actionRequest.id,
              tool: tool.name,
            },
          );
        }
        const storedParameters = signedPayload.arguments;
        const storedArgumentValidation = validateToolContent({
          value: storedParameters,
          direction: "arguments",
          sensitiveMode: "redact",
          promptInjectionMode: "ignore",
        });
        const storedCanonical = canonicalToolArguments(storedParameters);
        if (
          actionRequest.canonicalArgumentsHash !==
            summarizeToolValue(storedParameters).sha256 ||
          !verifyToolArgumentsSignature({
            signedArguments: actionRequest.signedArguments,
            invocationId: storedInvocation.id,
            toolName: storedInvocation.toolName,
            canonicalArguments: storedCanonical,
            approvalSnapshot: signedPayload.approvalSnapshot,
            executionOnApprove: signedPayload.executionOnApprove,
            identityContextId: signedPayload.identityContextId,
            signingSecret: options.toolActionSigningSecret,
          })
        ) {
          throw new ToolGatewayHttpError(
            409,
            "Approved tool action arguments do not match reviewed hash",
            "signed_arguments_mismatch",
          );
        }
        if (
          !(await approvedManagedArgumentsRemainCurrent(
            session,
            tool,
            storedParameters,
          ))
        ) {
          throw await expireApprovedActionForManagedArgumentDrift({
            actionRequestId: actionRequest.id,
            invocationId: storedInvocation.id,
            toolName: storedInvocation.toolName,
          });
        }
        const claimedAt = new Date();
        const [claimed] = await db
          .update(toolActionRequests)
          .set({
            status: "executing",
            resolvedByAgentId: session.agentId,
            updatedAt: claimedAt,
          })
          .where(
            and(
              eq(toolActionRequests.id, actionRequest.id),
              eq(toolActionRequests.status, "approved"),
            ),
          )
          .returning();
        if (!claimed) {
          throw new ToolGatewayHttpError(
            409,
            "Tool action request was already consumed",
            "action_already_consumed",
          );
        }
        await reflectToolActionInteractionLifecycle({
          actionRequestId: claimed.id,
          status: "executing",
        });
        invocationId = storedInvocation.id as typeof invocationId;
        effectiveParameters = storedParameters;
        effectiveArgumentsSummary = storedArgumentValidation.summary;
        await db
          .update(toolInvocations)
          .set({
            status: "executing",
            approvalState: "approved",
            startedAt: new Date(),
            updatedAt: new Date(),
          })
          .where(eq(toolInvocations.id, invocationId));
      } else {
        const decisionInput = policyInputForTool({
          session,
          tool,
          parameters: effectiveParameters,
          idempotencyKey: input.idempotencyKey,
          consumeRateLimit: true,
        });
        let accessDecision = await policyService.decide(decisionInput);
        if (accessDecision.allowed && tool.providerType === "paperclip_slack_chat" && SLACK_TOOLS.some(t => t.name === tool.upstreamToolName && t.risk === "approval")) {
          accessDecision = { ...accessDecision, allowed: false, decision: "require_approval", reasonCode: "requires_approval_policy", explanation: "Slack destructive actions, channel creation and invitations require approval." };
        }
        if (scopedContext && (accessDecision.allowed || accessDecision.decision === "require_approval"))
          await scopedContext.assertManifestCurrent?.(tool);
        const rememberDraft = scopedMemoryCapture && tool.name === "paperclip-self:remember"
          ? memoryAgentRememberInputSchema.safeParse(effectiveParameters).success : false;
        const recorded = await policyService.recordInvocation(decisionInput, accessDecision,
          rememberDraft ? { nativeMemoryDraft: true } : undefined);
        await policyService.writeAudit(decisionInput, accessDecision);
        invocationId = recorded.invocation.id;
        const retryingSlackRateLimit = recorded.replayed && accessDecision.allowed && tool.providerType === "paperclip_slack_chat" && session.agentId && session.runId && session.issueId
          ? await claimSlackRateLimitRetry(db, { companyId: session.companyId, agentId: session.agentId, runId: session.runId, issueId: session.issueId, endpointId: String(asRecord(tool.providerMetadata)?.endpointId ?? ""), identityContextId: session.identityContextId }, invocationId)
          : false;
        if (recorded.replayed && !retryingSlackRateLimit) {
          const reviewedReceipt = recorded.invocation.status === "succeeded" && recorded.invocation.approvalState === "approved";
          if (!accessDecision.allowed && !(accessDecision.decision === "require_approval" && reviewedReceipt)) {
            if (session.workflowRunId && accessDecision.decision === "require_approval" && recorded.invocation.status === "awaiting_approval") {
              const [review] = await db.select().from(toolActionRequests).where(and(
                eq(toolActionRequests.companyId, session.companyId), eq(toolActionRequests.invocationId, invocationId),
                eq(toolActionRequests.status, "pending")));
              if (review?.signedArguments) return throwApprovalRequired({ invocationId, actionRequestId: review.id,
                interactionId: review.interactionId, issueId: session.issueId, toolName: tool.name,
                argumentsHash: review.canonicalArgumentsHash });
            }
            throw new ToolGatewayHttpError(policyErrorStatus(accessDecision),
            accessDecision.explanation, accessDecision.reasonCode, { invocationId });
          }
          if ((session.workflowRunId || scopedContext) && recorded.invocation.status !== "succeeded") throw new ToolGatewayHttpError(409,
            "The original tool operation is pending or failed; its effects cannot be repeated",
            "tool_idempotency_unsettled", { invocationId, status: recorded.invocation.status });
          const replayResult = tool.providerType === "paperclip_self"
            ? await revalidateFirstPartyBuiltinReplay(session, tool, effectiveParameters, invocationId)
            : session.workflowRunId || scopedContext
              ? recorded.invocation.workflowResultJson : storedInvocationResult(recorded.invocation);
          await writeAudit({
            session,
            companyId: session.companyId,
            agentId: session.agentId,
            runId: session.runId,
            issueId: session.issueId,
            action: "tool_gateway.call_completed",
            details: {
              invocationId,
              decision: "allow",
              reasonCode: "idempotent_replay",
              tool: tool.name,
              ...toolAuditMetadata(tool),
              replayed: true,
            },
          });
          if (tool.providerType !== "paperclip_self") await revalidateScopedMemoryReplay({ invocationId,
            argumentsHash: argumentValidation.summary.sha256 ?? "", result: replayResult });
          return {
            invocationId,
            status: "replayed" as const,
            tool: tool.name,
            result: replayResult,
          };
        }
        if (accessDecision.decision === "require_approval") {
          await requestApprovalForRecordedToolCall({
            invocation: recorded.invocation,
            actionRequest: recorded.actionRequest,
            session,
            tool,
            parameters: effectiveParameters,
            argumentsSummary: argumentValidation.summary,
            policyDecision: accessDecision,
          });
        }
        if (!accessDecision.allowed) {
          // recordInvocation inserted this row already terminal (denied or
          // rate_limited), so this is its only completion boundary.
          void emitConnectionInvoked(db, invocationId);
          await writeAudit({
            session,
            companyId: session.companyId,
            agentId: session.agentId,
            runId: session.runId,
            issueId: session.issueId,
            action: "tool_gateway.call_denied",
            details: {
              invocationId,
              decision: accessDecision.decision,
              reasonCode: accessDecision.reasonCode,
              matchedPolicyIds: accessDecision.matchedPolicyIds,
              tool: tool.name,
              virtualToolName,
              targetToolName: virtualToolName ? tool.name : undefined,
              ...toolAuditMetadata(tool),
              argumentsSummary: effectiveArgumentsSummary,
              rateLimitState: accessDecision.rateLimitState ?? null,
            },
          });
          throw new ToolGatewayHttpError(
            policyErrorStatus(accessDecision),
            accessDecision.explanation,
            accessDecision.reasonCode,
            {
              invocationId,
              tool: tool.name,
              decision: accessDecision.decision,
              matchedPolicyIds: accessDecision.matchedPolicyIds,
              rateLimitState: accessDecision.rateLimitState ?? null,
            },
          );
        }
        await db
          .update(toolInvocations)
          .set({
            status: "executing",
            startedAt: new Date(),
            updatedAt: new Date(),
          })
          .where(eq(toolInvocations.id, invocationId));
      }

      await writeAudit({
        session,
        companyId: session.companyId,
        agentId: session.agentId,
        runId: session.runId,
        issueId: session.issueId,
        action: "tool_gateway.call_allowed",
        details: {
          invocationId,
          decision: input.approvedActionRequestId ? "approved" : "allow",
          reasonCode: input.approvedActionRequestId
            ? "approved_action_request"
            : "profile_allows_tool",
          tool: tool.name,
          virtualToolName,
          targetToolName: virtualToolName ? tool.name : undefined,
          ...toolAuditMetadata(tool),
          argumentsSummary: effectiveArgumentsSummary,
        },
      });

      try {
        const executionTimeoutMs = timeoutMs(input.timeoutMs);
        input.signal?.throwIfAborted();
        await scopedContext?.assertCurrent(tool);
        if (
          tool.providerType === "paperclip_plugin" &&
          (!session.agentId || !session.runId)
        ) {
          throw new ToolGatewayHttpError(
            403,
            "Plugin tools require an agent run context",
            "agent_context_required",
          );
        }
        if (tool.providerType === "paperclip_plugin") await assertToolInternalInferenceAdmitted(session);
        const connectedMcpExecution =
          tool.providerType === "mcp_remote_http"
            ? await executeRemoteHttpTool(
                session,
                tool,
                effectiveParameters,
                executionTimeoutMs,
                invocationId,
                input.callerHeaders,
                input.timeoutMs === undefined,
                input.signal,
                scopedContext,
              )
            : tool.providerType === "mcp_local_stdio"
              ? await executeLocalStdioTool(
                  session,
                  tool,
                  effectiveParameters,
                  executionTimeoutMs,
                  input.timeoutMs === undefined,
                  input.signal,
                )
              : null;
        const result = connectedMcpExecution
          ? connectedMcpExecution.result
          : tool.providerType === "paperclip_plugin"
            ? await runWithTimeout(
                pluginToolDispatcher!.executeTool(
                  tool.name,
                  effectiveParameters,
                  {
                    agentId: session.agentId!,
                    runId: session.runId!,
                    companyId: session.companyId,
                    projectId: session.projectId ?? "",
                  },
                ),
                executionTimeoutMs,
              )
            : await runWithTimeout(
                executeBuiltinTool(session, tool, effectiveParameters, invocationId, scopedContext),
                executionTimeoutMs,
              );

        const resultValidation = validateToolContent({
          value: result,
          direction: "result",
          sensitiveMode: "redact",
          promptInjectionMode: "block",
        });
        await scopedContext?.assertCurrent(tool);
        const completedAt = new Date();
        const validatedMcpResult = connectedMcpExecution
          ? asRecord(resultValidation.value)
          : null;
        if (validatedMcpResult?.error) {
          throw new ToolGatewayHttpError(
            502,
            String(validatedMcpResult.content || validatedMcpResult.error),
            "tool_error",
            { execution: connectedMcpExecution?.execution },
          );
        }
        await db
          .update(toolInvocations)
          .set({
            status: "succeeded",
            resultHash: resultValidation.summary.sha256 ?? null,
            resultSummary: resultValidation.summary,
            // Retain the validated scoped reply for exact, at-most-once replay.
            workflowResultJson: scopedContext ? resultValidation.value : session.workflowRunId ? typedWorkflowToolResult(tool, resultValidation.value) : null,
            resultSizeBytes: resultValidation.summary.sizeBytes ?? null,
            completedAt,
            updatedAt: completedAt,
          })
          .where(eq(toolInvocations.id, invocationId));
        const nativeMemoryCapture = nativeMemoryOutputCapture(scopedContext);
        if (tool.name === "paperclip-self:remember" && nativeMemoryCapture) {
          const resultRecord = asRecord(resultValidation.value);
          const data = asRecord(resultRecord?.data);
          const memory = asRecord(data?.record);
          if ((data?.status === "accepted" || data?.status === "pending") && typeof memory?.id === "string" &&
            resultValidation.summary.sha256) {
            const authorizationActor = currentSessionMemoryActor(session);
            if (!authorizationActor) throw new ToolGatewayHttpError(403,
              "Memory output lost its verified Agent session", "memory_agent_authority_unavailable");
            const actor: MemoryMutationActor = {
              principal: { type: "agent", agentId: session.agentId!, responsibleUserId: session.responsibleUserId ?? null },
              runId: session.runId, authorizationActor,
              nativeModelOutputCapture: nativeMemoryCapture, nativeToolInvocationId: invocationId,
            };
            await sealNativeMemoryToolResultSnapshot(db, { companyId: session.companyId,
              recordId: memory.id, actor, resultHash: resultValidation.summary.sha256 });
          }
        }
        if (input.approvedActionRequestId) {
          const [executedRequest] = await db
            .update(toolActionRequests)
            .set({
              status: "executed",
              resolvedAt: completedAt,
              updatedAt: completedAt,
            })
            .where(
              and(
                eq(toolActionRequests.id, input.approvedActionRequestId),
                eq(toolActionRequests.status, "executing"),
              ),
            )
            .returning({ id: toolActionRequests.id });
          if (executedRequest) {
            await reflectToolActionInteractionLifecycle({
              actionRequestId: executedRequest.id,
              status: "executed",
            });
          }
        }
        await writeToolCallEvent({
          invocationId,
          actionRequestId: input.approvedActionRequestId ?? null,
          session,
          eventType: "call_completed",
          outcome: "success",
          toolName: tool.name,
          policyDecision: input.approvedActionRequestId ? "allow" : "allow",
          reasonCode: "tool_completed",
          argumentsSummary: effectiveArgumentsSummary,
          resultSummary: resultValidation.summary,
          metadata: {
            ...(virtualToolName
              ? { virtualToolName, targetToolName: tool.name }
              : {}),
            ...(connectedMcpExecution?.headerSummary
              ? { headerSummary: connectedMcpExecution.headerSummary }
              : {}),
            ...(connectedMcpExecution
              ? { execution: connectedMcpExecution.execution }
              : {}),
          },
          tool,
        });

        await writeAudit({
          session,
          companyId: session.companyId,
          agentId: session.agentId,
          runId: session.runId,
          issueId: session.issueId,
          action: "tool_gateway.call_completed",
          details: {
            invocationId,
            decision: "allow",
            reasonCode: "tool_completed",
            tool: tool.name,
            virtualToolName,
            targetToolName: virtualToolName ? tool.name : undefined,
            ...toolAuditMetadata(tool),
            durationMs: Date.now() - startedAt,
            argumentsSummary: effectiveArgumentsSummary,
            result: summarizeResult(resultValidation.value),
            resultSummary: resultValidation.summary,
            headerSummary: connectedMcpExecution?.headerSummary ?? undefined,
            execution: connectedMcpExecution?.execution ?? undefined,
          },
        });
        // After the bookkeeping above: a throw there is caught below, overwrites
        // the row to failed, and emits — an earlier success emit would make one
        // execution report both outcomes.
        void emitConnectionInvoked(db, invocationId);
        return {
          invocationId,
          status: "completed" as const,
          tool: virtualToolName ?? tool.name,
          targetTool: virtualToolName ? tool.name : undefined,
          result: session.workflowRunId ? typedWorkflowToolResult(tool, resultValidation.value) : resultValidation.value,
        };
      } catch (err) {
        const normalizedError =
          err instanceof ToolRuntimeSupervisorError
            ? new ToolGatewayHttpError(
                err.status,
                err.message,
                err.reasonCode,
                err.details,
              )
            : err;
        const status =
          normalizedError instanceof ToolGatewayHttpError
            ? normalizedError.status
            : 502;
        const reasonCode =
          normalizedError instanceof ToolContentValidationError
            ? normalizedError.reasonCode
            : normalizedError instanceof ToolGatewayHttpError
              ? normalizedError.reasonCode
              : "tool_execution_failed";
        const isRuntimeDeferred =
          status === 429 &&
          (reasonCode === "runtime_capacity_unavailable" ||
            reasonCode === "runtime_restart_backoff" ||
            reasonCode === "runtime_restart_suppressed");
        const isDeferred = status === 504 || isRuntimeDeferred;
        const message =
          normalizedError instanceof Error
            ? normalizedError.message
            : String(normalizedError);
        if (reasonCode === "elicitation_required") {
          throw normalizedError;
        }
        const completedAt = new Date();
        await db
          .update(toolInvocations)
          .set({
            status:
              status === 504
                ? "timed_out"
                : status === 429
                  ? "rate_limited"
                  : "failed",
            errorCode: reasonCode,
            errorMessage: message,
            completedAt,
            updatedAt: completedAt,
          })
          .where(eq(toolInvocations.id, invocationId));
        void emitConnectionInvoked(db, invocationId);
        if (input.approvedActionRequestId) {
          const [failedRequest] = await db
            .update(toolActionRequests)
            .set({
              status: "failed",
              resolvedAt: completedAt,
              updatedAt: completedAt,
            })
            .where(
              and(
                eq(toolActionRequests.id, input.approvedActionRequestId),
                eq(toolActionRequests.status, "executing"),
              ),
            )
            .returning({ id: toolActionRequests.id });
          if (failedRequest) {
            await reflectToolActionInteractionLifecycle({
              actionRequestId: failedRequest.id,
              status: "failed",
              errorCode: reasonCode,
              errorMessage: message,
            });
          }
        }
        await writeToolCallEvent({
          invocationId,
          actionRequestId: input.approvedActionRequestId ?? null,
          session,
          eventType: status === 504 ? "call_failed" : "call_failed",
          outcome: status === 504 ? "timeout" : "failure",
          toolName: tool.name,
          policyDecision: isDeferred ? "defer_runtime" : "deny",
          reasonCode,
          argumentsSummary: effectiveArgumentsSummary,
          metadata: {
            ...(virtualToolName
              ? { virtualToolName, targetToolName: tool.name }
              : {}),
            ...(normalizedError instanceof ToolContentValidationError
              ? { findings: normalizedError.findings }
              : {}),
            ...(executionAuditFromError(normalizedError)
              ? { execution: executionAuditFromError(normalizedError) }
              : {}),
          },
          tool,
        });
        await writeAudit({
          session,
          companyId: session.companyId,
          agentId: session.agentId,
          runId: session.runId,
          issueId: session.issueId,
          action: isDeferred
            ? "tool_gateway.call_deferred"
            : "tool_gateway.call_failed",
          details: {
            invocationId,
            decision: isDeferred ? "defer_runtime" : "deny",
            reasonCode,
            tool: tool.name,
            virtualToolName,
            targetToolName: virtualToolName ? tool.name : undefined,
            ...toolAuditMetadata(tool),
            argumentsSummary: effectiveArgumentsSummary,
            durationMs: Date.now() - startedAt,
            error: message,
            ...(executionAuditFromError(normalizedError)
              ? { execution: executionAuditFromError(normalizedError) }
              : {}),
          },
        });
        if (normalizedError instanceof ToolContentValidationError) {
          throw new ToolGatewayHttpError(422, message, reasonCode, {
            findings: normalizedError.findings,
          });
        }
        throw normalizedError;
      }
    },

    async executePluginTool(input: ExecutePluginToolInput) {
      if (!pluginToolDispatcher) {
        throw new ToolGatewayHttpError(
          501,
          "Plugin tool dispatch is not enabled",
          "plugin_tools_disabled",
        );
      }
      if (input.actor.type === "agent") {
        if (input.actor.companyId !== input.runContext.companyId) {
          throw new ToolGatewayHttpError(
            403,
            "Agent key cannot access another company",
            "actor_company_mismatch",
          );
        }
        if (input.actor.agentId !== input.runContext.agentId) {
          throw new ToolGatewayHttpError(
            403,
            "Agent cannot execute tools as another agent",
            "actor_agent_mismatch",
          );
        }
        if (input.actor.runId && input.actor.runId !== input.runContext.runId) {
          throw new ToolGatewayHttpError(
            403,
            "Agent cannot execute tools for another run",
            "actor_run_mismatch",
          );
        }
      }

      const context = await resolveRunContext({
        companyId: input.runContext.companyId,
        agentId: input.runContext.agentId,
        runId: input.runContext.runId,
        projectId: input.runContext.projectId,
      });
      let invocationId = String(randomUUID());
      const sessionLike: ToolGatewaySession = {
        id: "plugin-route",
        token: "plugin-route",
        companyId: input.runContext.companyId,
        agentId: input.runContext.agentId,
        runId: input.runContext.runId,
        issueId: context.issueId,
        projectId: input.runContext.projectId ?? context.projectId,
        createdAt: new Date(),
        expiresAt: new Date(Date.now() + DEFAULT_SESSION_TTL_MS),
      };

      const tool = findStaticTool(input.tool);
      if (tool.providerType === "paperclip_plugin") await assertToolInternalInferenceAdmitted(sessionLike);

      if (tool.providerType !== "paperclip_plugin") {
        throw new ToolGatewayHttpError(
          404,
          `Tool "${input.tool}" is not a plugin tool`,
          "tool_not_found",
        );
      }

      const requestedParameters = input.parameters ?? {};
      const argumentValidation = validateToolContent({
        value: requestedParameters,
        direction: "arguments",
        sensitiveMode: "redact",
        promptInjectionMode: "ignore",
      });

      const decisionInput = policyInputForTool({
        session: sessionLike,
        tool,
        parameters: requestedParameters,
        consumeRateLimit: true,
      });
      const accessDecision = await policyService.decide(decisionInput);
      const recorded = await policyService.recordInvocation(
        decisionInput,
        accessDecision,
      );
      await policyService.writeAudit(decisionInput, accessDecision);
      invocationId = recorded.invocation.id;

      if (recorded.replayed) {
        return recorded.invocation.resultSummary;
      }

      if (accessDecision.decision === "require_approval") {
        await requestApprovalForRecordedToolCall({
          invocation: recorded.invocation,
          actionRequest: recorded.actionRequest,
          session: sessionLike,
          tool,
          parameters: requestedParameters,
          argumentsSummary: argumentValidation.summary,
          policyDecision: accessDecision,
        });
      }

      if (!accessDecision.allowed) {
        // recordInvocation inserted this row already terminal (denied or
        // rate_limited), so this is its only completion boundary.
        void emitConnectionInvoked(db, invocationId);
        await writeAudit({
          session: sessionLike,
          companyId: input.runContext.companyId,
          agentId: input.runContext.agentId,
          runId: input.runContext.runId,
          issueId: context.issueId,
          action: "tool_gateway.call_denied",
          details: {
            invocationId,
            decision: accessDecision.decision,
            reasonCode: accessDecision.reasonCode,
            matchedPolicyIds: accessDecision.matchedPolicyIds,
            tool: input.tool,
            ...toolAuditMetadata(tool),
            argumentsSummary: argumentValidation.summary,
            rateLimitState: accessDecision.rateLimitState ?? null,
          },
        });
        throw new ToolGatewayHttpError(
          policyErrorStatus(accessDecision),
          accessDecision.explanation,
          accessDecision.reasonCode,
          {
            invocationId,
            tool: input.tool,
            decision: accessDecision.decision,
            matchedPolicyIds: accessDecision.matchedPolicyIds,
            rateLimitState: accessDecision.rateLimitState ?? null,
          },
        );
      }

      await db
        .update(toolInvocations)
        .set({
          status: "executing",
          startedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(toolInvocations.id, invocationId));

      await writeAudit({
        session: sessionLike,
        companyId: input.runContext.companyId,
        agentId: input.runContext.agentId,
        runId: input.runContext.runId,
        issueId: context.issueId,
        action: "tool_gateway.call_allowed",
        details: {
          invocationId,
          decision: "allow",
          reasonCode: "profile_allows_tool",
          tool: input.tool,
          ...toolAuditMetadata(tool),
          argumentsSummary: argumentValidation.summary,
        },
      });

      const startedAt = Date.now();
      try {
        const result = await pluginToolDispatcher.executeTool(
          input.tool,
          requestedParameters,
          input.runContext,
        );
        const resultValidation = validateToolContent({
          value: result,
          direction: "result",
          sensitiveMode: "redact",
          promptInjectionMode: "block",
        });
        await db
          .update(toolInvocations)
          .set({
            status: "succeeded",
            resultHash: resultValidation.summary.sha256 ?? null,
            resultSummary: resultValidation.summary,
            resultSizeBytes: resultValidation.summary.sizeBytes ?? null,
            completedAt: new Date(),
            updatedAt: new Date(),
          })
          .where(eq(toolInvocations.id, invocationId));
        await writeToolCallEvent({
          invocationId,
          session: sessionLike,
          eventType: "call_completed",
          outcome: "success",
          toolName: tool.name,
          policyDecision: "allow",
          reasonCode: "tool_completed",
          argumentsSummary: argumentValidation.summary,
          resultSummary: resultValidation.summary,
          tool,
        });
        await writeAudit({
          session: sessionLike,
          companyId: input.runContext.companyId,
          agentId: input.runContext.agentId,
          runId: input.runContext.runId,
          issueId: context.issueId,
          action: "tool_gateway.call_completed",
          details: {
            invocationId,
            decision: "allow",
            reasonCode: "tool_completed",
            tool: input.tool,
            ...toolAuditMetadata(tool),
            durationMs: Date.now() - startedAt,
            result: summarizeResult(
              (resultValidation.value as typeof result).result,
            ),
            resultSummary: resultValidation.summary,
          },
        });
        // After the bookkeeping above: a throw there is caught below, overwrites
        // the row to failed, and emits — an earlier success emit would make one
        // execution report both outcomes.
        void emitConnectionInvoked(db, invocationId);
        return resultValidation.value as typeof result;
      } catch (err) {
        const status = err instanceof ToolGatewayHttpError ? err.status : 502;
        const reasonCode =
          err instanceof ToolContentValidationError
            ? err.reasonCode
            : err instanceof ToolGatewayHttpError
              ? err.reasonCode
              : "tool_execution_failed";
        const message = err instanceof Error ? err.message : String(err);
        await db
          .update(toolInvocations)
          .set({
            status: status === 504 ? "timed_out" : "failed",
            errorCode: reasonCode,
            errorMessage: message,
            completedAt: new Date(),
            updatedAt: new Date(),
          })
          .where(eq(toolInvocations.id, invocationId));
        void emitConnectionInvoked(db, invocationId);
        await writeToolCallEvent({
          invocationId,
          session: sessionLike,
          eventType: "call_failed",
          outcome: status === 504 ? "timeout" : "failure",
          toolName: tool.name,
          policyDecision: status === 504 ? "defer_runtime" : "deny",
          reasonCode,
          argumentsSummary: argumentValidation.summary,
          metadata:
            err instanceof ToolContentValidationError
              ? { findings: err.findings }
              : null,
          tool,
        });
        await writeAudit({
          session: sessionLike,
          companyId: input.runContext.companyId,
          agentId: input.runContext.agentId,
          runId: input.runContext.runId,
          issueId: context.issueId,
          action: "tool_gateway.call_failed",
          details: {
            invocationId,
            decision: "deny",
            reasonCode,
            tool: input.tool,
            ...toolAuditMetadata(tool),
            argumentsSummary: argumentValidation.summary,
            durationMs: Date.now() - startedAt,
            error: message,
          },
        });
        if (err instanceof ToolContentValidationError) {
          throw new ToolGatewayHttpError(422, message, reasonCode, {
            findings: err.findings,
          });
        }
        throw err;
      }
    },

    async revokeSession(input: {
      companyId: string;
      sessionId: string;
      revokedAt?: Date;
      actor?: {
        actorType?: LogActivityInput["actorType"];
        actorId?: string;
        agentId?: string | null;
        runId?: string | null;
      };
      agentScope?: { agentId: string; runId?: string | null } | null;
    }) {
      const now = input.revokedAt ?? new Date();
      const [existing] = await db
        .select()
        .from(toolGatewaySessions)
        .where(
          and(
            eq(toolGatewaySessions.companyId, input.companyId),
            eq(toolGatewaySessions.id, input.sessionId),
          ),
        )
        .limit(1);
      if (!existing) {
        throw new ToolGatewayHttpError(
          404,
          "Tool gateway session not found",
          "session_not_found",
        );
      }
      if (input.agentScope) {
        const runMatches = input.agentScope.runId
          ? existing.runId === input.agentScope.runId
          : true;
        if (existing.agentId !== input.agentScope.agentId || !runMatches) {
          throw new ToolGatewayHttpError(
            403,
            "Tool gateway session is outside the authenticated agent scope",
            "session_scope_mismatch",
          );
        }
      }
      const [session] = await db
        .update(toolGatewaySessions)
        .set({ revokedAt: now, updatedAt: now })
        .where(
          and(
            eq(toolGatewaySessions.companyId, input.companyId),
            eq(toolGatewaySessions.id, input.sessionId),
          ),
        )
        .returning();
      memorySessionActors.delete(input.sessionId);
      const sessionView = gatewaySessionFromRow(session!);
      await writeAudit({
        session: sessionView,
        companyId: sessionView.companyId,
        agentId: sessionView.agentId,
        runId: sessionView.runId,
        issueId: sessionView.issueId,
        actorType: input.actor?.actorType,
        actorId: input.actor?.actorId,
        action: "tool_gateway.session_revoked",
        details: {
          decision: "revoke",
          reasonCode: "session_revoked",
          revokedAt: now.toISOString(),
          previousRevokedAt: existing.revokedAt?.toISOString() ?? null,
        },
      });
      return { ...sessionView, revokedAt: session!.revokedAt ?? now };
    },

    async cleanupExpiredSessions(input: { now?: Date } = {}) {
      const now = input.now ?? new Date();
      const rows = await db
        .delete(toolGatewaySessions)
        .where(lte(toolGatewaySessions.expiresAt, now))
        .returning({ id: toolGatewaySessions.id });
      for (const row of rows) memorySessionActors.delete(row.id);
      return { deletedCount: rows.length };
    },

    async listRuntimeSlots(companyId?: string) {
      return runtimeSupervisor.listSlots(companyId);
    },

    async stopRuntimeSlot(input: {
      companyId: string;
      slotId: string;
      actor?: { agentId?: string | null; runId?: string | null };
    }) {
      try {
        return await runtimeSupervisor.stopSlot({
          companyId: input.companyId,
          slotId: input.slotId,
          agentId: input.actor?.agentId ?? null,
          runId: input.actor?.runId ?? null,
        });
      } catch (err) {
        if (err instanceof ToolRuntimeSupervisorError) {
          throw new ToolGatewayHttpError(
            err.status,
            err.message,
            err.reasonCode,
            err.details,
          );
        }
        throw err;
      }
    },

    async restartRuntimeSlot(input: {
      companyId: string;
      slotId: string;
      actor?: { agentId?: string | null; runId?: string | null };
    }) {
      try {
        return await runtimeSupervisor.restartSlot({
          companyId: input.companyId,
          slotId: input.slotId,
          agentId: input.actor?.agentId ?? null,
          runId: input.actor?.runId ?? null,
        });
      } catch (err) {
        if (err instanceof ToolRuntimeSupervisorError) {
          throw new ToolGatewayHttpError(
            err.status,
            err.message,
            err.reasonCode,
            err.details,
          );
        }
        throw err;
      }
    },
  };
  const canonicalSandboxBrokerResolver=service.resolveSandboxCredentialBrokerPolicyBindings;
  return service;
}

export type ToolGatewayService = ReturnType<typeof createToolGatewayService>;
