import { describe, expect, it } from "vitest";
import { sandboxPolicySchema, SANDBOX_CONTROLS, type SandboxCapabilitySnapshot, type SandboxPolicy } from "@paperclipai/shared";
import { compileSandboxPolicy } from "../services/execution-sandbox/policy-compiler.js";
import { projectOpenShellPolicy } from "../services/execution-sandbox/openshell-policy.js";
import { runSandboxQualification } from "../services/execution-sandbox/qualification.js";
import { existingCellContainerBackend } from "../services/execution-sandbox/compatibility-backend.js";
import type { ExecutionSandboxBackend } from "../services/execution-sandbox/backend.js";
const now = new Date("2026-10-05T12:00:00Z"), image = "fixture.invalid/sandbox@sha256:" + "a".repeat(64);
import { policyFixture } from "./helpers/sandbox-fixture.js";
const caps = (): SandboxCapabilitySnapshot => ({ ...Object.fromEntries(SANDBOX_CONTROLS.map(control => [control, true])), backend: "openshell", backendVersion: "fixture", hostKernelVersion: "fixture", sandboxImageDigest: image, filesystemEnforcementMode: "hard_requirement", staticPolicyRequiresRecreate: true, dynamicNetworkPolicy: true, policyProverBoundaryCheck: true, policyProverCoverage: [...SANDBOX_CONTROLS], credentialBindingDimensions: ["company", "presence", "host", "port", "method", "path", "binary", "expiry", "revocation"], credentialBrokerProviderProfile: { id: "paperclip-broker", hash: "d".repeat(64) }, testedAt: now.toISOString(), expiresAt: "2026-10-06T12:00:00Z", qualificationHash: "a".repeat(64), evidenceKind: "local_fixture" } as SandboxCapabilitySnapshot);
const compile = (candidate = policyFixture(), capabilities: SandboxCapabilitySnapshot | null = caps(), boundary = policyFixture(), grants = {}) => compileSandboxPolicy({ candidate, capabilities, boundary, authorizedConnectionGrantHashes: grants, sourcePolicyRefs: ["fixture-only"], now });
describe("V7 policy subset proofs, distinct from physical boundary qualification", () => {
  it("proves a narrower policy and pins deterministic content", () => { const p = policyFixture(); p.filesystem.readPaths = ["/work/input"]; p.resources.wallClockSeconds = 60; const first = compile(p); expect(first.proverResult).toBe("pass"); expect(compile(p)).toEqual(first); expect(first.candidatePolicyHash).not.toBe(first.boundaryPolicyHash); });
  it.each([
    ["filesystem sibling", (p: SandboxPolicy) => { p.filesystem.readPaths = ["/worker"]; }, "filesystem_read_expansion"],
    ["removed deny", (p: SandboxPolicy) => { p.filesystem.deniedPaths = []; }, "filesystem_deny_removed"],
    ["binary substitution", (p: SandboxPolicy) => { p.process.allowedBinaries = ["/usr/bin/node/evil"]; }, "process_expansion"],
    ["hostname", (p: SandboxPolicy) => { p.network.destinations[0]!.hostname = "evil.example.com"; }, "network_expansion"],
    ["port", (p: SandboxPolicy) => { p.network.destinations[0]!.port = 80; }, "network_expansion"],
    ["method", (p: SandboxPolicy) => { p.network.destinations[0]!.methods = ["DELETE"]; }, "network_expansion"],
    ["path sibling", (p: SandboxPolicy) => { p.network.destinations[0]!.pathPrefixes = ["/v11"]; }, "network_expansion"],
    ["budget", (p: SandboxPolicy) => { p.resources.pidsLimit = 65; }, "resource_pidsLimit_expansion"],
    ["autonomy", (p: SandboxPolicy) => { p.broadAutonomy = true; }, "autonomy_expansion"],
    ["C4", (p: SandboxPolicy) => { p.riskClass = "C4"; }, "domain_overlay_not_qualified"],
  ] as const)("rejects %s expansion", (_name, mutate, reason) => { const p = policyFixture(); mutate(p); expect(compile(p).failedBoundaries).toContain(reason); });
  it.each(["/work/../secret", "/work//secret", "/work/", "/work/*"])("rejects noncanonical filesystem path %s", path => { const p = policyFixture(); p.filesystem.readPaths = [path]; expect(sandboxPolicySchema.safeParse(p).success).toBe(false); });
  it.each(["/v1/%2e%2e", "/v1?override=true", "/v1#fragment", "/v1/[a-z]", "/v1/[!a]", "/v1/[[]", "/v1/unclosed["])("rejects ambiguous destination path %s", path => { const p = policyFixture(); p.network.destinations[0]!.pathPrefixes = [path]; expect(sandboxPolicySchema.safeParse(p).success).toBe(false); });
  it.each(["/v1/[a-z]", "/v1/[!a]", "/v1/[[]"])("rejects OpenShell glob syntax in a credential destination %s", path => {
    const p = policyFixture();
    p.credentials = { mode: "brokered", bindings: [{ connectionId: "11111111-1111-4111-8111-111111111111", grantVersionHash: "b".repeat(64),
      hostname: "api.example.com", port: 443, methods: ["GET"], pathPrefixes: [path], binary: "/usr/bin/node", ttlSeconds: 30 }] };
    expect(sandboxPolicySchema.safeParse(p).success).toBe(false);
  });
  it("preserves literal filesystem bracket names and segment-boundary REST prefixes", () => {
    const p = policyFixture(); p.filesystem.readPaths = ["/work/data[1]"];
    expect(sandboxPolicySchema.safeParse(p).success).toBe(true);
    p.network.destinations[0]!.pathPrefixes = ["/v1/items"];
    expect(compile(p).proverResult).toBe("pass");
  });
  it("requires actual fresh capability evidence and hard filesystem enforcement", () => { expect(compile(undefined, null).proverResult).toBe("unsupported"); const c = caps(); c.expiresAt = now.toISOString(); expect(compile(undefined, c).unsupportedFeatures).toContain("capability_snapshot_stale"); c.expiresAt = "2026-10-06T12:00:00Z"; c.filesystemEnforcementMode = "best_effort"; expect(compile(undefined, c).unsupportedFeatures).toContain("filesystem_hard_enforcement_missing"); });
  it("does not promote local fixtures into managed assurance", () => { const p = policyFixture(); p.profile = "standard_managed"; expect(compile(p).unsupportedFeatures).toContain("production_boundary_evidence_missing"); });
  it("requires L7 enforcement even for DELETE-only destinations", () => { const p = policyFixture(); p.network.destinations[0]!.methods = ["DELETE"]; const c = caps(); c.networkLayer7Policy = false; expect(compile(p, c, p).unsupportedFeatures).toContain("networkLayer7Policy"); });
  it("requires current grants and supported credential dimensions", () => { const p = policyFixture(); p.credentials = { mode: "brokered", bindings: [{ connectionId: "11111111-1111-4111-8111-111111111111", grantVersionHash: "b".repeat(64), hostname: "api.example.com", port: 443, methods: ["GET"], pathPrefixes: ["/v1"], binary: "/usr/bin/node", ttlSeconds: 30 }] }; const c = caps(); c.credentialBindingDimensions = ["company", "presence"]; const result = compile(p, c, p); expect(result.failedBoundaries).toContain("credential_grant_not_current"); expect(result.unsupportedFeatures).toContain("credential_binary_binding_missing"); expect(result.unsupportedFeatures).toContain("credential_revocation_binding_missing"); });
  it("rejects broker mode without a current binding", () => { const p = policyFixture(); p.credentials = { mode: "brokered", bindings: [] }; expect(compile(p, caps(), p).failedBoundaries).toContain("credential_broker_binding_missing"); });
  it("binds each resolved broker grant to its exact executable and only accepts a single profile-wide executable", () => {
    const p = policyFixture(); p.network.destinations = [];
    p.filesystem.readPaths = ["/usr"];
    p.credentials = { mode: "brokered", bindings: [{ connectionId: "11111111-1111-4111-8111-111111111111", grantVersionHash: "b".repeat(64), hostname: "provider.example.com", port: 443, methods: ["POST"], pathPrefixes: ["/mcp"], binary: "/usr/bin/node", ttlSeconds: 30 }] };
    const resolved = [{ connectionId: p.credentials.bindings[0]!.connectionId, grantVersionHash: p.credentials.bindings[0]!.grantVersionHash, gatewayPublicId: "gateway_1", endpointPath: "/mcp/gateways/gateway_1", allowedTools: ["read_record"], binary: "/usr/bin/node", destination: { hostname: "provider.example.com", port: 443, method: "POST" as const, path: "/mcp" } }];
    const grants = { [p.credentials.bindings[0]!.connectionId]: p.credentials.bindings[0]!.grantVersionHash };
    const mismatch = compileSandboxPolicy({ boundary: p, candidate: p, capabilities: caps(), authorizedConnectionGrantHashes: grants, credentialBrokerOrigin: "https://paperclip.example.test/", credentialBrokerBindings: [{ ...resolved[0]!, binary: "/usr/bin/python" }], sourcePolicyRefs: [], now });
    expect(mismatch.failedBoundaries).toContain("credential_broker_binding_resolution_mismatch");
    expect(mismatch.failedBoundaries).toContain("credential_binary_grant_resolution_mismatch");
    const exact = compileSandboxPolicy({ boundary: p, candidate: p, capabilities: caps(), authorizedConnectionGrantHashes: grants, credentialBrokerOrigin: "https://paperclip.example.test/", credentialBrokerBindings: resolved, sourcePolicyRefs: [], now });
    expect(exact.proverResult).toBe("pass");
    const second = structuredClone(p.credentials.bindings[0]!); second.connectionId = "22222222-2222-4222-8222-222222222222"; second.binary = "/usr/bin/python";
    p.credentials.bindings.push(second);
    const mixed = compileSandboxPolicy({ boundary: p, candidate: p, capabilities: caps(), authorizedConnectionGrantHashes: grants, credentialBrokerOrigin: "https://paperclip.example.test/", credentialBrokerBindings: [resolved[0]!, { ...resolved[0]!, connectionId: second.connectionId, binary: second.binary }], sourcePolicyRefs: [], now });
    expect(mixed.unsupportedFeatures).toContain("credential_binary_profile_not_separable");
    const nullFirst = structuredClone(p);
    nullFirst.credentials.bindings[0]!.binary = null;
    const mixedNullFirst = compileSandboxPolicy({ boundary: nullFirst, candidate: nullFirst, capabilities: caps(), authorizedConnectionGrantHashes: grants,
      credentialBrokerOrigin: "https://paperclip.example.test/", credentialBrokerBindings: [{ ...resolved[0]!, binary: null }, { ...resolved[0]!, connectionId: second.connectionId, binary: second.binary }], sourcePolicyRefs: [], now });
    expect(mixedNullFirst.unsupportedFeatures).toContain("credential_binary_profile_not_separable");
    const writable = structuredClone(p); writable.credentials.bindings = [structuredClone(writable.credentials.bindings[0]!)];
    writable.filesystem.writePaths = ["/usr"];
    const writableBinary = compileSandboxPolicy({ boundary: writable, candidate: writable, capabilities: caps(), authorizedConnectionGrantHashes: grants,
      credentialBrokerOrigin: "https://paperclip.example.test/", credentialBrokerBindings: resolved, sourcePolicyRefs: [], now });
    expect(writableBinary.failedBoundaries).toContain("credential_binary_not_immutable");
  });
  it("adds only the configured Paperclip MCP route for brokered calls", () => {
    const p = policyFixture();
    p.network.destinations = [];
    p.credentials = { mode: "brokered", bindings: [{ connectionId: "11111111-1111-4111-8111-111111111111", grantVersionHash: "b".repeat(64), hostname: "provider.example.com", port: 443, methods: ["POST"], pathPrefixes: ["/mcp"], binary: null, ttlSeconds: 30 }] };
    const resolved = [{ connectionId: p.credentials.bindings[0]!.connectionId, grantVersionHash: p.credentials.bindings[0]!.grantVersionHash, gatewayPublicId: "gateway_1", endpointPath: "/mcp/gateways/gateway_1", allowedTools: ["read_record"], binary: null, destination: { hostname: "provider.example.com", port: 443, method: "POST" as const, path: "/mcp" } }];
    const result = compileSandboxPolicy({ boundary: p, candidate: p, capabilities: caps(), authorizedConnectionGrantHashes: { [p.credentials.bindings[0]!.connectionId]: p.credentials.bindings[0]!.grantVersionHash }, credentialBrokerOrigin: "https://paperclip.example.test/", credentialBrokerBindings: resolved, sourcePolicyRefs: ["fixture-only"], now });
    expect(result.proverResult).toBe("pass");
    expect(result.compiledPolicy.network.destinations).toEqual([{ hostname: "paperclip.example.test", port: 443, methods: ["POST"], pathPrefixes: ["/mcp/gateways/gateway_1"] }]);
    const projected = projectOpenShellPolicy(result.compiledPolicy);
    expect(projected.document.network_policies.aw_0?.endpoints[0]?.rules).toEqual([{ allow: { method: "POST", path: "/mcp/gateways/gateway_1" } }]);
    const wrongDestination = compileSandboxPolicy({ boundary: p, candidate: p, capabilities: caps(), authorizedConnectionGrantHashes: { [p.credentials.bindings[0]!.connectionId]: p.credentials.bindings[0]!.grantVersionHash }, credentialBrokerOrigin: "https://paperclip.example.test/", credentialBrokerBindings: [{ ...resolved[0]!, destination: { ...resolved[0]!.destination, hostname: "other-provider.example.test" } }], sourcePolicyRefs: ["fixture-only"], now });
    expect(wrongDestination.failedBoundaries).toContain("credential_broker_binding_resolution_mismatch");
  });
  it("adds the exact managed Messages route from its separate host profile without ToolGateway bindings", () => {
    const p = policyFixture();
    p.network.destinations = [];
    p.credentials = { mode: "none", bindings: [] };
    const capability = caps();
    capability.modelBrokerProviderProfile = { id: "paperclip-model-broker", hash: "e".repeat(64) };
    capability.evidenceKind = "protected_host_report";
    const result = compileSandboxPolicy({ boundary: p, candidate: p, capabilities: capability,
      authorizedConnectionGrantHashes: {}, credentialBrokerOrigin: "https://paperclip.example.test/",
      sourcePolicyRefs: ["fixture-only"], now });
    expect(result.proverResult).toBe("pass");
    expect(result.compiledPolicy.credentials.bindings).toEqual([]);
    expect(result.modelBrokerEndpoint).toEqual({ hostname: "paperclip.example.test", port: 443, path: "/runtime-tools/model/v1/messages" });
    expect(result.compiledPolicy.network.destinations).toEqual([{ hostname: "paperclip.example.test", port: 443,
      methods: ["POST"], pathPrefixes: ["/runtime-tools/model/v1/messages"] }]);
    const projection = projectOpenShellPolicy(result.compiledPolicy, result.modelBrokerEndpoint);
    expect(projection.document.network_policies.aw_0?.endpoints[0]?.rules).toEqual([
      { allow: { method: "POST", path: "/runtime-tools/model/v1/messages" } },
    ]);
    const predeclared = structuredClone(p);
    predeclared.network.destinations = [{ hostname: "paperclip.example.test", port: 443, methods: ["POST"], pathPrefixes: ["/runtime-tools/model/v1/messages"] }];
    expect(compileSandboxPolicy({ boundary: predeclared, candidate: predeclared, capabilities: capability, authorizedConnectionGrantHashes: {},
      credentialBrokerOrigin: "https://paperclip.example.test", sourcePolicyRefs: [], now }).modelBrokerEndpoint).toEqual(result.modelBrokerEndpoint);
    expect(compileSandboxPolicy({ boundary: p, candidate: p, capabilities: capability, authorizedConnectionGrantHashes: {},
      credentialBrokerOrigin: "http://paperclip.example.test", sourcePolicyRefs: [], now }).unsupportedFeatures).toContain("managed_model_broker_origin_unavailable");
    const broad = structuredClone(p);
    broad.network.destinations = [{ hostname: "paperclip.example.test", port: 443, methods: ["POST"], pathPrefixes: ["/"] }];
    expect(compileSandboxPolicy({ boundary: broad, candidate: broad, capabilities: capability, authorizedConnectionGrantHashes: {},
      credentialBrokerOrigin: "https://paperclip.example.test/", sourcePolicyRefs: [], now }).failedBoundaries).toContain("managed_model_broker_egress_broadened");
    const direct = structuredClone(p);
    direct.network.destinations = [{ hostname: "api.anthropic.com", port: 443, methods: ["POST"], pathPrefixes: ["/v1/messages"] }];
    expect(compileSandboxPolicy({ boundary: direct, candidate: direct, capabilities: capability, authorizedConnectionGrantHashes: {},
      credentialBrokerOrigin: "https://paperclip.example.test/", sourcePolicyRefs: [], now }).failedBoundaries).toContain("managed_model_provider_direct_egress");
  });
  it("blocks direct provider egress and broad predeclared broker origins", () => {
    const p = policyFixture();
    p.credentials = { mode: "brokered", bindings: [{ connectionId: "11111111-1111-4111-8111-111111111111", grantVersionHash: "b".repeat(64), hostname: "provider.example.com", port: 443, methods: ["POST"], pathPrefixes: ["/mcp"], binary: null, ttlSeconds: 30 }] };
    p.network.destinations = [{ hostname: "provider.example.com", port: 443, methods: ["POST"], pathPrefixes: ["/mcp"] }];
    const resolved = [{ connectionId: p.credentials.bindings[0]!.connectionId, grantVersionHash: p.credentials.bindings[0]!.grantVersionHash, gatewayPublicId: "gateway_1", endpointPath: "/mcp/gateways/gateway_1", allowedTools: ["read_record"], binary: null, destination: { hostname: "provider.example.com", port: 443, method: "POST" as const, path: "/mcp" } }];
    const grants = { [p.credentials.bindings[0]!.connectionId]: p.credentials.bindings[0]!.grantVersionHash };
    const direct = compileSandboxPolicy({ boundary: p, candidate: p, capabilities: caps(), authorizedConnectionGrantHashes: grants, credentialBrokerOrigin: "https://paperclip.example.test/", credentialBrokerBindings: resolved, sourcePolicyRefs: ["fixture-only"], now });
    expect(direct.failedBoundaries).toContain("credential_provider_direct_egress");
    p.network.destinations = [{ hostname: "paperclip.example.test", port: 443, methods: ["POST"], pathPrefixes: ["/"] }];
    const broad = compileSandboxPolicy({ boundary: p, candidate: p, capabilities: caps(), authorizedConnectionGrantHashes: grants, credentialBrokerOrigin: "https://paperclip.example.test/", credentialBrokerBindings: resolved, sourcePolicyRefs: ["fixture-only"], now });
    expect(broad.failedBoundaries).toContain("credential_broker_egress_broadened");
  });
  it("keeps broker compilation unsupported when the trusted Paperclip origin is absent", () => {
    const p = policyFixture(); p.network.destinations = [];
    p.credentials = { mode: "brokered", bindings: [{ connectionId: "11111111-1111-4111-8111-111111111111", grantVersionHash: "b".repeat(64), hostname: "provider.example.com", port: 443, methods: ["POST"], pathPrefixes: ["/mcp"], binary: null, ttlSeconds: 30 }] };
    const resolved = [{ connectionId: p.credentials.bindings[0]!.connectionId, grantVersionHash: p.credentials.bindings[0]!.grantVersionHash, gatewayPublicId: "gateway_1", endpointPath: "/mcp/gateways/gateway_1", allowedTools: ["read_record"], binary: null, destination: { hostname: "provider.example.com", port: 443, method: "POST" as const, path: "/mcp" } }];
    const result = compileSandboxPolicy({ boundary: p, candidate: p, capabilities: caps(), authorizedConnectionGrantHashes: { [p.credentials.bindings[0]!.connectionId]: p.credentials.bindings[0]!.grantVersionHash }, credentialBrokerBindings: resolved, sourcePolicyRefs: ["fixture-only"], now });
    expect(result.unsupportedFeatures).toContain("credential_broker_origin_unavailable");
  });
  it("refuses legacy fallback while retaining native Stop", async () => { let stops = 0; const b = existingCellContainerBackend({ inspect: async () => ({ generation: "1", imageDigest: image, state: "stopped", backendVersion: "6.0.0" }), stop: async () => ({ operationId: String(++stops) }), destroy: async () => ({ operationId: "delete" }) }); const identity = { companyId: "c", bindingId: "b", cellId: "cell", cellGeneration: "1", sandboxRef: "cell:1" }; const report = await runSandboxQualification(b, identity, now); expect(report.status).toBe("inconclusive"); expect(report.capabilities).toBeNull(); await expect(b.startWorkload({ ...identity, policy: compile(), expiresAt: now.toISOString(), idempotencyKey: "start" })).rejects.toMatchObject({ status: 403 }); expect(await b.stopWorkload({ ...identity, idempotencyKey: "stop" })).toEqual({ operationId: "1" }); await expect(b.prepareSandbox({ ...identity, cellGeneration: "2" })).rejects.toMatchObject({ status: 409 }); });
  it("does not qualify claimed passing probes without observations or matching contracts", async () => { const b = { backend: "openshell", evidenceKind: "local_fixture", capabilities: async () => null, probeBoundary: async () => ({ verdict: "pass", observationHash: "a".repeat(64), contractHash: "b".repeat(64) }) } as unknown as ExecutionSandboxBackend; const r = await runSandboxQualification(b, { companyId: "c", bindingId: "b", cellId: "cell", cellGeneration: "1", sandboxRef: "fixture" }, now); expect(r.status).toBe("inconclusive"); expect(r.results.every(test => test.verdict === "unsupported")).toBe(true); });
});
