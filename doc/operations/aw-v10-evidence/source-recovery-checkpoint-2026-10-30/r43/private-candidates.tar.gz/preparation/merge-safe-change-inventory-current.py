from pathlib import Path
import json,hashlib,subprocess,copy
root=Path('/workspace/blentera-v10');prep=Path('/workspace/v10-preparation')
old=json.load(open(root/'doc/operations/v10-safe-change-graph.source.json'));draft=json.load(open(prep/'v10-safe-change-source-inventory-draft-current.json'))
base=old['sourceBase']['commitSha'];by={r['changeId']:r for r in draft['changes']};before_cache={}
def before(p):
 if p not in before_cache:
  q=subprocess.run(['git','show',base+':'+p],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
  before_cache[p]={'path':p,'baseCommitSha':base,'status':'present_at_base' if q.returncode==0 else 'absent_at_base','sha256':hashlib.sha256(q.stdout).hexdigest() if q.returncode==0 else None}
 return before_cache[p]
actual=set(subprocess.check_output(['git','diff','--name-only',base],cwd=root,text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines())
out=copy.deepcopy(old);retired=set();preserved=0
for r in out['changes']:
 d=by.pop(r['changeId']);paths=set(r['sourcePaths'])|set(r.get('deletedSourcePaths',[]))|set(d['sourcePaths'])|set(d.get('deletedSourcePaths',[]))
 absent={p for p in paths if not (root/p).is_file() and before(p)['status']=='absent_at_base'};retired|=absent;paths-=absent
 r['sourcePaths']=sorted(p for p in paths if (root/p).is_file());r['deletedSourcePaths']=sorted(paths-set(r['sourcePaths']));r['changedSourcePaths']=sorted(paths&actual);r['sourceBeforePins']=[before(p) for p in sorted(paths)]
 for k in ['dependencyPaths','characterizationTests']:
  r[k]=sorted((set(r.get(k,[]))|set(d.get(k,[])))-absent)
 r['requirements']=sorted(set(r.get('requirements',[]))|set(d['requirements']))
 if 'hotspotSourcePin' in d:r['hotspotSourcePin']=d['hotspotSourcePin']
 if absent:r['retiredBranchSourcePaths']=[{'path':p,'disposition':'Intermediate branch metadata retired by later append-only migration generation; absent at pinned master base and current source. Historical Git blobs and qualification receipts retain original bytes; not a base deletion or current dependency.'} for p in sorted(absent)]
 for k in set(old['changes'][out['changes'].index(r)])-{'sourcePaths','deletedSourcePaths','changedSourcePaths','sourceBeforePins','dependencyPaths','characterizationTests','requirements','hotspotSourcePin'}:
  assert r[k]==old['changes'][out['changes'].index(r)][k],k
 preserved+=1
assert not by,by.keys()
# Retired paths may also occur solely in another record's dependency/test list.
for r in out['changes']:
 for k in ['dependencyPaths','characterizationTests']:r[k]=[p for p in r.get(k,[]) if p not in retired]
# Retain each row's existing assessment; update only exact source linkage fields.
dcross={r['workId']:r for r in draft['requirementsCrosswalk']}
for row in out['requirementsCrosswalk']:
 d=dcross[row['workId']]
 row['changedReferencedPaths']=sorted(set(d['changedReferencedPaths'])-retired)
 row['safeChangeIds']=sorted(set(row['safeChangeIds'])|set(d['safeChangeIds']))
 row['sourceDeltaStatus']=d['sourceDeltaStatus']
changed={p for r in out['changes'] for p in r['changedSourcePaths']};deleted={p for r in out['changes'] for p in r['deletedSourcePaths']}
out['sourceInventoryBoundary']={**draft['sourceInventoryBoundary'],'sourceDeltaPathCount':len(changed),'deletedSourcePathCount':len(deleted)}
out['sourceInventoryBoundary']['note']+=' Source includes Rust/TOML/Python, root build/configuration, dependency patches, runtime Skill/release/evaluation assets and UI assets. Previously reviewed owner/recovery/rollback/approval metadata and explicit dependencies are preserved. Intermediate branch-only migration snapshots absent at both base and current source are recorded as retired, never base deletions.'
out['sourceAfterGeneration']='pending_final_candidate_freeze; current source ownership inventory is not final behavioral qualification'
path=prep/'v10-safe-change-source-inventory-merged-current.json';path.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'output':str(path),'groupsWithPreservedMetadata':preserved,'changed':len(changed),'deleted':len(deleted),'retired':sorted(retired),'modelDependencies':len(next(r for r in out['changes'] if r['changeId']=='SCR-V10-MODEL-PROVIDER-AND-MIGRATION-MONITOR')['dependencyPaths'])},indent=2))
