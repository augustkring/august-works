#!/usr/bin/env bash
set -euo pipefail
REPO=/workspace/blentera-v10
PREP=/workspace/v10-preparation/native-paid-admission-guard-nov01
LOCK=/workspace/v10-preparation/v10-pg-tests.lock
EXPECTED_HEAD=254e5c998c9f41725708a2c8c404078397a3fcac
CONNECT_LINK="$REPO/server/node_modules/@vercel/connect"
CONNECT_TARGET=/workspace/.cloud-setup/lockfile/node_modules/.pnpm/@vercel+connect@0.6.1_@chat-adapter+slack@4.39.0_patch_hash=226jj24akljccsfbw7bcxujz4u_zod@4._jrz3mecw2ouunkeec7koa7tmoi/node_modules/@vercel/connect
OPENCODE=/workspace/.cloud-setup/lockfile/node_modules/.pnpm/opencode-linux-x64@1.18.32/node_modules/opencode-linux-x64/bin/opencode
RUN_DIR="$PREP/test-sandbox-positive-$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$RUN_DIR/restore"
exec 9>"$LOCK"
flock -x 9
actual_head="$(git -C "$REPO" rev-parse HEAD)"
if [[ "$actual_head" != "$EXPECTED_HEAD" ]]; then echo "HEAD changed: $actual_head" >&2; exit 70; fi
old_connect_target="$(readlink "$CONNECT_LINK")"
files=(
  server/src/services/heartbeat.ts
  server/src/services/native-runtime/native-session-executor.ts
  server/src/services/native-runtime/native-session-executor.test.ts
  server/src/services/native-runtime/paid-transport-admission.ts
  server/src/services/native-runtime/paid-transport-admission.test.ts
  server/src/services/native-runtime/native-session-executor-admission.test.ts
)
: > "$RUN_DIR/restore-manifest.txt"
for rel in "${files[@]}"; do
  src="$REPO/$rel"
  if [[ -e "$src" ]]; then mkdir -p "$RUN_DIR/restore/$(dirname "$rel")"; cp -p "$src" "$RUN_DIR/restore/$rel"; printf 'present %s %s\n' "$(sha256sum "$src" | awk '{print $1}')" "$rel" >> "$RUN_DIR/restore-manifest.txt"
  else printf 'absent - %s\n' "$rel" >> "$RUN_DIR/restore-manifest.txt"; fi
done
restore() {
  local code=$?
  trap - EXIT
  for rel in "${files[@]}"; do
    if [[ -e "$RUN_DIR/restore/$rel" ]]; then cp -p "$RUN_DIR/restore/$rel" "$REPO/$rel"; else rm -f "$REPO/$rel"; fi
  done
  rm -f "$REPO/server/src/services/native-runtime/native-session-executor.ts.orig"
  rm -f "$CONNECT_LINK"; ln -s "$old_connect_target" "$CONNECT_LINK"
  local bad=0
  while read -r state digest rel; do
    if [[ "$state" == present ]]; then actual="$(sha256sum "$REPO/$rel" | awk '{print $1}')"; [[ "$actual" == "$digest" ]] || { echo "restore mismatch: $rel" >&2; bad=1; }
    elif [[ -e "$REPO/$rel" ]]; then echo "restore expected absent: $rel" >&2; bad=1; fi
  done < "$RUN_DIR/restore-manifest.txt"
  [[ "$(readlink "$CONNECT_LINK")" == "$old_connect_target" ]] || bad=1
  if (( bad )); then code=71; fi
  printf '%s\n' "$code" > "$RUN_DIR/exit"
  exit "$code"
}
trap restore EXIT
sha256sum "$PREP/native-paid-admission-guard.patch" > "$RUN_DIR/patch.sha256"
ln -sfn "$CONNECT_TARGET" "$CONNECT_LINK"
cd "$REPO"
patch --dry-run -p1 < "$PREP/native-paid-admission-guard.patch" > "$RUN_DIR/patch-dry-run.log"
patch -p1 < "$PREP/native-paid-admission-guard.patch" > "$RUN_DIR/patch-apply.log"
cd "$REPO/server"
PAPERCLIP_QUALIFIED_OPENCODE_BINARY="$OPENCODE" timeout 300s ../node_modules/.bin/vitest run src/services/native-runtime/native-opencode-managed-conversation-frame.integration.test.ts -t "runs the route-created conversation through RuntimeControl" --reporter=verbose > "$RUN_DIR/vitest.log" 2>&1
cat "$RUN_DIR/vitest.log"
