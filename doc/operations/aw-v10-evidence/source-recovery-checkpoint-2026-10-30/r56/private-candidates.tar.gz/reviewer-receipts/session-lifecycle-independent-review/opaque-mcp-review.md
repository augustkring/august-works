# Opaque MCP company-purpose review

No concrete security bypass found in the frozen nine-file delta. Exact trusted HTTPS origin, current credential/source authority, one-use observation/completion CAS, secret-free fixed discovery and old-workflow execution fencing are present.

**P2 OM-01:** Existing `server/src/services/workflows/workflow-http-request.test.ts:14` and subsequent tests retain old successful-fetch/transport-error expectations. The new executor always rejects `configuration_incomplete`; update those existing tests alongside the new fence tests. Sent owner.

The echo test uses actual Express handlers through supertest with an injected transport, not production DNS/TLS or physical Host. It covers bearer observation, concurrent observers, replay, wrong marker and revocation. Physical Host/helper composition still needs owner validation.

Patch SHA: `0f3ac2f76b51551536b828e073fb8e7a41e31d32f1cba73df13a2fd0c8991b82`. No source edits, tests, network or DB changes.
