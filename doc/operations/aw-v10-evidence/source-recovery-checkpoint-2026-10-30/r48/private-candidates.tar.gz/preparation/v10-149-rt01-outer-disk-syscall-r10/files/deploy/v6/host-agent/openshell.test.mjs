import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm, mkdir, writeFile, chmod, readFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { createHash, randomUUID } from "node:crypto";
import { EventEmitter } from "node:events";
import { PassThrough, Readable } from "node:stream";
import { openShellHostEngine } from "./openshell.mjs";

const scope = {
  companyId: randomUUID(),
  bindingId: randomUUID(),
  cellId: randomUUID(),
  cellGeneration: "1",
};
scope.sandboxRef = `aw-v7-${scope.bindingId}`;
const input = (action) => ({
  version: 1,
  action,
  scope,
  hostEpoch: 1,
  requesterUserId: "fixture-owner",
  imageDigest: "fixture.invalid/image@sha256:" + "a".repeat(64),
});
const policyDocument = {
  version: 1,
  filesystem_policy: { include_workdir: false, read_only: ["/etc"], read_write: [] },
  landlock: { compatibility: "hard_requirement" },
  process: { run_as_user: "1000", run_as_group: "1000" },
  network_policies: {},
};
const policyHash = "b".repeat(64);
const resourceLimits = { cpuMillis: 1500, memoryBytes: 536870912, diskBytes: 1073741824, pidsLimit: 128 };
const hostAdmission = (idempotencyKey, document = policyDocument, credentialProviderProfile) => ({
  policyHash, expiresAt: new Date(Date.now() + 50000).toISOString(), idempotencyKey, document,
  resourceLimits, ...(credentialProviderProfile ? { credentialProviderProfile } : {}),
});
const deadline = () => new Date(Date.now() + 20000).toISOString();
async function fixture(work, hooks = {}) {
  const root = await mkdtemp(path.join(os.tmpdir(), "aw-v7-host-cli-"));
  try {
    const executable = path.join(root, "fixture-cli"),
      stateHome = path.join(root, "private-cli-state");
    await writeFile(executable, "fixture-only-cli", { mode: 0o700 });
    await mkdir(stateHome, { mode: 0o700 });
    const config = {
      executable,
      executableSha256: createHash("sha256")
        .update("fixture-only-cli")
        .digest("hex"),
      stateHome,
      gateway: "fixture-gateway",
      workspace: "fixture-company",
    };
    const calls = [];
    let sandboxId = randomUUID(),
      phase = hooks.phase ?? "Ready",
      wrongScope = false,
      resourceConfig = { NanoCpus: 0, Memory: 0, MemorySwap: 0, PidsLimit: 0,
        StorageOpt: { size: `${resourceLimits.diskBytes}B` },
        Tmpfs: { "/run/openshell-supervisor-ca/material": "rw,noexec,nosuid,nodev,size=1m,uid=1000,gid=1000,mode=0755" } },
      attached = [{ name: "fixture-provider" }],
      physical = hooks.physical ?? false,
      running = hooks.running ?? false,
      effectivePolicy = structuredClone(hooks.effectivePolicy ?? policyDocument),
      configRevision = 1,
      wrongContainerLabels = hooks.wrongContainerLabels ?? false,
      containerImageDigest = hooks.containerImageDigest ?? input("inspect").imageDigest;
    let containerId = "d".repeat(64);
    const originalContainerId = containerId,
      imageId = "sha256:" + "e".repeat(64);
    const requireExpectedSandboxId = command => {
      const index = command.indexOf("--expected-sandbox-id");
      if (index < 0 || command[index + 1] !== sandboxId)
        throw new Error("fixture-expected-sandbox-id-mismatch");
    };
    const run = async (file, args, options) => {
      calls.push({ args, options });
      await hooks.beforeCommand?.(file, args);
      assert.equal(options.env.HOME, stateHome);
      assert.equal(options.env.OPENSHELL_GATEWAY_INSECURE, undefined);
      assert.ok(options.timeout <= 18000);
      if (file === "docker") {
        assert.equal(options.env.PATH, process.env.PATH);
        assert.equal(options.env.DOCKER_HOST, "unix:///var/run/docker.sock");
        if (args[0] === "info") {
          if (args[2] === "{{.Driver}}") return { stdout: `${hooks.storageDriver ?? "overlay2"}\n` };
          if (args[2] === "{{json .DriverStatus}}")
            return { stdout: JSON.stringify(hooks.driverStatus ?? [["Backing Filesystem", "xfs"]]) };
          return { stdout: "openshell-docker-engine-1\n" };
        }
        if (args[0] === "ps") return { stdout: physical ? `${containerId}\n` : "" };
        if (args[0] === "inspect")
          return {
            stdout: JSON.stringify([
              {
                Id: containerId,
                Image: imageId,
                RepoDigests: [containerImageDigest],
                Config: {
                  Image: imageId,
                  WorkingDir: "/workspace/project",
                  Labels: {
                    "openshell.ai/managed-by": "openshell",
                    "openshell.ai/sandbox-id": sandboxId,
                    "openshell.ai/sandbox-name": scope.sandboxRef,
                    "openshell.ai/sandbox-namespace": "default",
                    "openshell.ai/sandbox-workspace": config.workspace,
                    "openshell.ai/workspace-root": "/workspace/project",
                    "openshell.ai/isolation-backend": "openshell-sandbox",
                    "openshell.ai/isolation-role": "sandbox",
                    "aw.company_id": wrongContainerLabels ? randomUUID() : scope.companyId,
                    "aw.binding_id": scope.bindingId,
                    "aw.cell_id": scope.cellId,
                    "aw.generation": "1",
                  },
                },
                HostConfig: { ...resourceConfig,
                  StorageOpt: hooks.storageOpt ?? resourceConfig.StorageOpt,
                  Tmpfs: hooks.tmpfs ?? resourceConfig.Tmpfs },
                Mounts: hooks.mounts ?? [
                  { Type: "volume", Name: `openshell-channel-${createHash("sha256").update(`default\0${sandboxId}`).digest("hex").slice(0, 32)}`,
                    Driver: "local", Destination: "/.openshell/channel", RW: true },
                  { Type: "tmpfs", Destination: "/run/openshell-supervisor-ca/material", Mode: "rw,noexec,nosuid,nodev,size=1m,uid=1000,gid=1000,mode=0755", RW: true },
                  ...(hooks.extraMounts ?? []),
                ],
                State: { Running: running },
              },
            ]),
          };
        if (args[0] === "update") {
          const updateTarget = args.at(-1);
          assert.equal(updateTarget, originalContainerId, "Docker resource updates must target the full pinned container ID");
          if (updateTarget !== containerId) throw new Error("fixture-container-replaced");
          const option = name => args[args.indexOf(name) + 1];
          resourceConfig = { ...resourceConfig, NanoCpus: Math.round(Number(option("--cpus")) * 1e9), Memory: Number(option("--memory")),
            MemorySwap: Number(option("--memory-swap")), PidsLimit: Number(option("--pids-limit")) };
          return { stdout: "fixture update" };
        }
        throw new Error("fixture-unexpected-docker-command");
      }
      assert.equal(options.env.PATH, "/usr/bin:/bin");
      const command = args.slice(4);
      if (command[0] === "profile" && command[1] === "describe")
        return { stdout: JSON.stringify(hooks.modelBrokerProfile ?? hooks.brokerProfile ?? {}) };
      if (command[0] === "provider" && command[1] === "create") {
        assert.ok(!args.some(value => String(value).includes(hooks.brokerToken ?? "__never__")));
        assert.equal(options.env.PAPERCLIP_SANDBOX_BROKER_TOKEN ?? options.env.PAPERCLIP_SANDBOX_MODEL_TOKEN, hooks.brokerToken, `provider env keys: ${Object.keys(options.env).join(",")}`);
        return { stdout: "provider created" };
      }
      if (command[0] === "provider" && command[1] === "update") return { stdout: "provider updated" };
      if (command[0] === "provider" && command[1] === "delete") return { stdout: "provider deleted" };
      if (command[0] === "sandbox" && command[1] === "provider" && command[2] === "attach") {
        requireExpectedSandboxId(command);
        attached.push({ name: command[4] });
        return { stdout: JSON.stringify({ provider: command[4] }) };
      }
      if (command[0] === "sandbox" && command[1] === "provider" && command[2] === "detach") {
        requireExpectedSandboxId(command);
        attached = attached.filter(value => value.name !== command[4]);
        return { stdout: "{}" };
      }
      if (command[0] === "--version") return { stdout: "openshell 0.1.2\n" };
      if (command[0] === "sandbox" && command[1] === "exec") {
        requireExpectedSandboxId(command);
        if (hooks.probeExitCode !== undefined && hooks.probeExitCode !== 0)
          throw Object.assign(new Error("fixture-sandbox-exec-failed"), { code: hooks.probeExitCode });
        return { stdout: hooks.probeStdout ?? "" };
      }
      if (command[0] === "sandbox" && command[1] === "get")
        return {
          stdout: JSON.stringify({
            id: sandboxId,
            name: scope.sandboxRef,
            workspace: config.workspace,
            phase,
            labels: {
              "aw.company_id": wrongScope ? randomUUID() : scope.companyId,
              "aw.binding_id": scope.bindingId,
              "aw.cell_id": scope.cellId,
              "aw.generation": "1",
            },
          }),
        };
      if (command[0] === "sandbox" && command[1] === "stop") {
        requireExpectedSandboxId(command);
        phase = "Stopped";
        running = false;
        return { stdout: "Stopped" };
      }
      if (command[0] === "sandbox" && command[1] === "start") {
        requireExpectedSandboxId(command);
        phase = "Ready";
        running = true;
        return { stdout: "Started" };
      }
      if (command[0] === "sandbox" && command[1] === "delete") {
        requireExpectedSandboxId(command);
        sandboxId = undefined;
        return { stdout: "Deleted" };
      }
      if (command[0] === "sandbox" && command[1] === "list")
        return { stdout: JSON.stringify({ sandboxes: [], next_page_token: "" }) };
      if (command[0] === "policy" && command[1] === "get")
        return {
          stdout: JSON.stringify({
            sandbox: scope.sandboxRef,
            status: "effective",
            version: 1,
            config_revision: configRevision,
            hash: createHash("sha256").update(JSON.stringify(effectivePolicy)).digest("hex"),
            policy: effectivePolicy,
          }),
        };
      if (command[0] === "policy" && command[1] === "set") {
        requireExpectedSandboxId(command);
        assert.equal(command[2], scope.sandboxRef);
        assert.equal(command[3], "--policy");
        assert.ok((await readFile(command[4], "utf8")).length > 0);
        effectivePolicy = JSON.parse(await readFile(command[4], "utf8"));
        return { stdout: "Policy updated" };
      }
      if (command[1] === "provider" && command[2] === "list")
        return {
          stdout: JSON.stringify({ providers: attached, next_page_token: "" }),
        };
      if (command[1] === "provider" && command[2] === "detach") {
        requireExpectedSandboxId(command);
        attached = [];
        return { stdout: "{}" };
      }
      throw new Error("fixture-unexpected-command");
    };
    const engine = openShellHostEngine({ config, epoch: 1, root, run, spawnProcess: hooks.spawnProcess });
    await engine.initialize();
    await work({
      engine,
      config,
      calls,
      root,
      run,
      replaceSandbox: () => { sandboxId = randomUUID(); },
      sandboxId: () => sandboxId,
      clearSandboxIdentity: () => { sandboxId = undefined; },
      enablePhysical: () => { physical = true; },
      setPhase: (value) => { phase = value; running = value === "Ready"; },
      setWrongContainerLabels: () => { wrongContainerLabels = true; },
      setContainerImageDigest: (value) => { containerImageDigest = value; },
      resourceConfig: () => ({ ...resourceConfig }),
      setResourceConfig: value => { resourceConfig = { ...value }; },
      replaceContainerBeforeUpdate: () => { containerId = "f".repeat(64); },
      changePolicyRevision: () => { configRevision += 1; },
      swapScope: () => {
        wrongScope = true;
      },
    });
  } finally {
    await rm(root, { recursive: true, force: true });
  }
}
function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === "object") return Object.fromEntries(Object.keys(value).sort().map(key => [key, canonical(value[key])]));
  return value;
}
function execRequest(deadlineAt = deadline(), stdinBase64 = "") {
  const argv = ["node", "-e", "process.stdout.write('fixture')"];
  const cwd = "/workspace", env = {};
  const commandDigest = createHash("sha256").update(JSON.stringify(canonical({
    argv, cwd, env,
    stdinHash: createHash("sha256").update(Buffer.from(stdinBase64, "base64")).digest("hex"),
    timeoutDeadline: deadlineAt,
    brokerCapabilityHash: null,
    brokerProviderProfile: null,
    modelBrokerCapabilityHash: null,
    modelBrokerProviderProfile: null,
  }))).digest("hex");
  return {
    requestId: randomUUID(), bindingId: scope.bindingId, hostEpoch: 1,
    runId: randomUUID(), attemptId: randomUUID(), attempt: 1,
    manifestId: randomUUID(), manifestHash: "c".repeat(64),
    policySnapshotId: randomUUID(), policyHash, commandDigest, deadlineAt,
    sandboxRef: scope.sandboxRef, imageDigest: input("inspect").imageDigest,
    argv, cwd, env, stdinBase64,
  };
}
const brokerProfile = {
  id: "paperclip-broker",
  credentials: [{ name: "broker_token", env_vars: ["PAPERCLIP_SANDBOX_BROKER_TOKEN"], required: true, auth_style: "bearer", header_name: "Authorization" }],
  endpoints: [{ host: "paperclip.example.test", port: 443, protocol: "rest", enforcement: "enforce", path: "", rules: [{ allow: { method: "POST", path: "/mcp/gateways/*" } }] }],
  binaries: [{ path: "/usr/bin/node" }],
};
const modelBrokerProfile = {
  id: "paperclip-model-broker",
  credentials: [{ name: "model_token", env_vars: ["PAPERCLIP_SANDBOX_MODEL_TOKEN"], required: true, auth_style: "bearer", header_name: "Authorization" }],
  endpoints: [{ host: "paperclip.example.test", port: 443, protocol: "rest", enforcement: "enforce", path: "", rules: [{ allow: { method: "POST", path: "/runtime-tools/model/v1/messages" } }] }],
  binaries: [{ path: "/usr/bin/node" }],
};
function brokerExecRequest() {
  const request = execRequest();
  const expiresAt = new Date(Math.min(Date.parse(request.deadlineAt), Date.now() + 30000)).toISOString();
  const claim = {
    parentRequestId: request.requestId,
    bindingId: request.bindingId,
    cellId: scope.cellId,
    generation: scope.cellGeneration,
    hostId: randomUUID(),
    hostEpoch: request.hostEpoch,
    runId: request.runId,
    attemptId: request.attemptId,
    attempt: request.attempt,
    manifestId: request.manifestId,
    manifestHash: request.manifestHash,
    policySnapshotId: request.policySnapshotId,
    policyHash: request.policyHash,
    brokerSessionId: request.requestId,
    endpointOrigin: "https://paperclip.example.test/",
    bindings: [{ binary: "/usr/bin/node" }],
    expiresAt,
  };
  const claims = {
    purpose: "sandbox_broker",
    aud: "paperclip-sandbox-broker",
    jti: request.requestId,
    company_id: scope.companyId,
    run_id: request.runId,
    exp: Math.floor(Date.parse(expiresAt) / 1000),
    sandbox_broker: claim,
  };
  const token = `fixture.${Buffer.from(JSON.stringify(claims)).toString("base64url")}.signature`;
  request.env.PAPERCLIP_SANDBOX_BROKER_ENDPOINT_ORIGIN = claim.endpointOrigin;
  request.env.PAPERCLIP_SANDBOX_BROKER_SESSION_ID = request.requestId;
  request.brokerCredential = { capabilityToken: token, profileId: brokerProfile.id,
    profileHash: createHash("sha256").update(JSON.stringify(canonical(brokerProfile))).digest("hex"), expiresAt };
  const argv = request.argv, cwd = request.cwd, env = request.env;
  request.commandDigest = createHash("sha256").update(JSON.stringify(canonical({ argv, cwd, env,
    stdinHash: createHash("sha256").update(Buffer.from(request.stdinBase64, "base64")).digest("hex"),
    timeoutDeadline: request.deadlineAt,
    brokerCapabilityHash: createHash("sha256").update(token).digest("hex"),
    brokerProviderProfile: { id: request.brokerCredential.profileId, hash: request.brokerCredential.profileHash },
    modelBrokerCapabilityHash: null,
    modelBrokerProviderProfile: null,
  }))).digest("hex");
  return { request, token };
}
function modelBrokerExecRequest() {
  const request = execRequest();
  const expiresAt = new Date(Math.min(Date.parse(request.deadlineAt), Date.now() + 30000)).toISOString();
  const claims = { scope: "worker_model", company_id: scope.companyId, run_id: request.runId, sub: randomUUID(),
    exp: Math.floor(Date.parse(expiresAt) / 1000) + 1, worker_model: { workerAttemptId: randomUUID(), executionManifestId: request.manifestId } };
  const token = `fixture.${Buffer.from(JSON.stringify(claims)).toString("base64url")}.signature`;
  request.env.PAPERCLIP_MANAGED_MODEL_BROKER_ORIGIN = "https://paperclip.example.test/";
  request.env.PAPERCLIP_MANAGED_MODEL_INPUT_TOKENS_UPPER_BOUND = "100000";
  request.env.PAPERCLIP_MANAGED_MODEL_MAX_OUTPUT_TOKENS = "1024";
  request.modelBrokerCredential = { capabilityToken: token, profileId: modelBrokerProfile.id,
    profileHash: createHash("sha256").update(JSON.stringify(canonical(modelBrokerProfile))).digest("hex"), expiresAt,
    inputTokensUpperBound: 100000, maxOutputTokens: 1024 };
  request.commandDigest = createHash("sha256").update(JSON.stringify(canonical({ argv: request.argv, cwd: request.cwd, env: request.env,
    stdinHash: createHash("sha256").update(Buffer.from(request.stdinBase64, "base64")).digest("hex"), timeoutDeadline: request.deadlineAt,
    brokerCapabilityHash: null, brokerProviderProfile: null,
    modelBrokerCapabilityHash: createHash("sha256").update(token).digest("hex"),
    modelBrokerProviderProfile: { id: request.modelBrokerCredential.profileId, hash: request.modelBrokerCredential.profileHash },
  }))).digest("hex");
  return { request, token };
}
test("CLI fixtures cannot earn complete physical capabilities or forced-stop probes", async () =>
  fixture(async ({ engine, calls }) => {
    assert.deepEqual(
      (await engine.execute(randomUUID(), input("capabilities"), deadline()))
        .reply,
      { action: "capabilities", capabilities: null },
    );
    const forcedStopProbe = await engine.execute(randomUUID(), {
      ...input("probe"),
      probe: {
        caseId: "force_stop",
        control: "forceStop",
        expected: "observe",
        contractHash: "a".repeat(64),
      },
    }, deadline());
    assert.deepEqual(forcedStopProbe.reply,
      { action: "probe", verdict: "unsupported", observationHash: null, contractHash: "a".repeat(64) },
      JSON.stringify({ errorCode: forcedStopProbe.errorCode, reply: forcedStopProbe.reply }));
    assert.ok(calls.length > 0);
    assert.ok(calls.every(({ args }) => !args.includes("start") && !args.includes("stop")));
    assert.ok(calls.every(({ args }) => !args.includes("exec")));
  }));
test("policy-bound process probe executes the pinned OpenShell command and hashes only its assertion", async () =>
  fixture(async ({ engine, calls, sandboxId }) => {
    const capabilityReply = await engine.execute(randomUUID(), input("capabilities"), deadline());
    const reply = await engine.execute(randomUUID(), {
      ...input("probe"),
      probe: { caseId: "process_nonprivileged", control: "processPrivilegePolicy", expected: "observe", contractHash: "c".repeat(64) },
    }, deadline());
    assert.equal(reply.reply.verdict, "pass");
    assert.match(reply.reply.observationHash, /^[a-f0-9]{64}$/);
    assert.equal(reply.reply.targetQualificationHash, capabilityReply.reply.capabilities.qualificationHash);
    const execCall = calls.find(({ args }) => args.includes("exec"));
    assert.ok(execCall);
    assert.ok(execCall.args.includes("--no-login-shell"));
    assert.equal(execCall.args[execCall.args.indexOf("--expected-sandbox-id") + 1], sandboxId());
    assert.ok(execCall.args.includes("--timeout"));
    assert.deepEqual(execCall.args.slice(-3), ["--", "/usr/bin/id", "-u"]);
    assert.equal(JSON.stringify(reply).includes("1000"), false);
  }, { physical: true, running: true, probeStdout: "1000\n" }));
test("a probe cannot attest a same-name replacement after observing the original sandbox UUID", async () => {
  let replaceDuringProbe = () => {};
  const hooks = {
    physical: true,
    running: true,
    probeStdout: "1000\n",
    beforeCommand(_file, args) {
      const command = args.slice(4);
      if (command[0] === "sandbox" && command[1] === "exec") replaceDuringProbe();
    },
  };
  await fixture(async ({ engine, calls, replaceSandbox, sandboxId }) => {
    replaceDuringProbe = replaceSandbox;
    const expectedId = sandboxId();
    const reply = await engine.execute(randomUUID(), {
      ...input("probe"),
      probe: { caseId: "process_nonprivileged", control: "processPrivilegePolicy", expected: "observe", contractHash: "d".repeat(64) },
    }, deadline());
    assert.equal(reply.reply.verdict, "unsupported");
    assert.equal(sandboxId() === expectedId, false);
    const execCall = calls.find(({ args }) => args.includes("exec"));
    assert.ok(execCall);
    assert.equal(execCall.args[execCall.args.indexOf("--expected-sandbox-id") + 1], expectedId);
  }, hooks);
});
test("syscall probe parses only the pinned runtime's built-in allow and deny report", async () => {
  const report = JSON.stringify({ version: 1, profile: "openshell-linux-built-in-seccomp-v1",
    getpid: "allowed", memfd_create: "denied", denied_errno: "EPERM" });
  const readOnlyRuntime = { ...policyDocument,
    filesystem_policy: { ...policyDocument.filesystem_policy, read_only: ["/.openshell/runtime"] } };
  await fixture(async ({ engine, calls, sandboxId }) => {
    for (const [caseId, expected] of [
      ["syscall_allow", "allow"],
      ["syscall_deny", "deny"],
    ]) {
      const reply = await engine.execute(randomUUID(), {
        ...input("probe"),
        probe: { caseId, control: "syscallPolicy", expected, contractHash: "e".repeat(64) },
      }, deadline());
      assert.equal(reply.reply.verdict, "pass");
      assert.match(reply.reply.observationHash, /^[a-f0-9]{64}$/);
      const execCall = calls.filter(({ args }) => args.includes("exec")).at(-1);
      assert.ok(execCall);
      assert.equal(execCall.args[execCall.args.indexOf("--expected-sandbox-id") + 1], sandboxId());
      assert.deepEqual(execCall.args.slice(-3), ["--", "/.openshell/runtime/openshell-sandbox", "runtime-seccomp-probe"]);
    }
  }, { physical: true, running: true, probeStdout: report, effectivePolicy: readOnlyRuntime });
  for (const probeStdout of ["not-json", JSON.stringify({ ...JSON.parse(report), denied_errno: "EACCES" })]) {
    await fixture(async ({ engine }) => {
      const reply = await engine.execute(randomUUID(), {
        ...input("probe"),
        probe: { caseId: "syscall_deny", control: "syscallPolicy", expected: "deny", contractHash: "f".repeat(64) },
      }, deadline());
      assert.equal(reply.reply.verdict, "fail");
    }, { physical: true, running: true, probeStdout, effectivePolicy: readOnlyRuntime });
  }
  await fixture(async ({ engine, calls }) => {
    const reply = await engine.execute(randomUUID(), {
      ...input("probe"),
      probe: { caseId: "syscall_allow", control: "syscallPolicy", expected: "allow", contractHash: "1".repeat(64) },
    }, deadline());
    assert.equal(reply.reply.verdict, "unsupported");
    assert.equal(calls.some(({ args }) => args.includes("exec")), false);
  }, { physical: true, running: true });
});
test("observed metadata cannot substitute for image or complete control enforcement", async () =>
  fixture(async ({ engine }) => {
    const receipt = await engine.execute(
      randomUUID(),
      input("inspect"),
      deadline(),
    );
    assert.deepEqual(receipt.reply, {
      action: "inspect",
      state: "unknown",
      policyHash: null,
      imageDigest: null,
      generation: "1",
      controlsHealthy: false,
    });
    const preparation = await engine.execute(
      randomUUID(),
      input("prepare"),
      deadline(),
    );
    assert.equal(preparation.success, false);
  }));
test("prepare returns only an observed exact stopped sandbox image and rejects drift", async () => {
  await fixture(async ({ engine, calls }) => {
    const receipt = await engine.execute(randomUUID(), input("prepare"), deadline());
    assert.equal(receipt.success, true);
    assert.deepEqual(receipt.reply, {
      action: "prepare",
      backendVersion: "0.1.2",
      imageDigest: input("prepare").imageDigest,
    });
    assert.ok(calls.some(call => call.args[0] === "info"));
    assert.ok(calls.some(call => call.args[0] === "ps"));
    assert.ok(calls.some(call => call.args[0] === "inspect"));
    assert.ok(calls.some(call => call.args[4] === "sandbox" && call.args[5] === "get"));
    assert.ok(!calls.some(call => call.args[4] === "sandbox" && ["create", "start", "stop"].includes(call.args[5])));
  }, { phase: "Stopped", physical: true });

  for (const hooks of [
    { phase: "Stopped", physical: true, containerImageDigest: "fixture.invalid/other@sha256:" + "c".repeat(64) },
    { phase: "Stopped", physical: true, wrongContainerLabels: true },
    { phase: "Ready", physical: true },
    { phase: "Stopped", physical: true, running: true },
  ]) {
    await fixture(async ({ engine }) => {
      const receipt = await engine.execute(randomUUID(), input("prepare"), deadline());
      assert.equal(receipt.success, false);
      assert.equal(receipt.reply, null);
    }, hooks);
  }
});

test("host rejects malformed cleanup attestations and never accepts them for execution actions", async () =>
  fixture(async ({ engine }) => {
    const cleanupAttestation = {
      version: 1, jobId: randomUUID(), jobKey: `runtime-asset-erasure:v1:${randomUUID()}`,
      attemptNumber: 1, executionOwnerId: "retention-worker", locatorDigest: "a".repeat(64),
      companyPurgeOperationId: null, startBindingDigest: "b".repeat(64),
    };
    const cleanupCapabilities = input("capabilities");
    delete cleanupCapabilities.requesterUserId;
    const cleanupStart = input("start");
    delete cleanupStart.requesterUserId;
    await assert.rejects(engine.execute(randomUUID(), {
      ...cleanupCapabilities,
      cleanupAttestation: { ...cleanupAttestation, unexpected: true },
    }, deadline()));
    await assert.rejects(engine.execute(randomUUID(), {
      ...cleanupStart, start: {
        policyHash, expiresAt: deadline(), idempotencyKey: randomUUID(),
      }, cleanupAttestation,
    }, deadline()));
    await assert.rejects(engine.execute(randomUUID(), {
      ...cleanupCapabilities,
      cleanupAttestation: { ...cleanupAttestation, locatorDigest: "bad" },
    }, deadline()));
    await assert.rejects(engine.execute(randomUUID(), {
      ...input("capabilities"), requesterUserId: "fixture-owner", cleanupAttestation,
    }, deadline()), /sandbox_scope_changed/);
  }));
test("Stop checks immutable scope, targets one sandbox and persists a restart receipt", async () =>
  fixture(async ({ engine, config, calls, root, run }) => {
    const id = randomUUID(),
      receipt = await engine.execute(id, input("stop"), deadline());
    assert.equal(receipt.reply.stopped, true);
    const count = calls.length,
      restarted = openShellHostEngine({ config, epoch: 1, root, run });
    await restarted.initialize();
    assert.deepEqual(
      await restarted.execute(id, input("stop"), deadline()),
      receipt,
    );
    assert.equal(calls.length, count);
    assert.ok(
      calls.every(
        ({ args }) =>
          !args.includes("--all") && !args.includes("--gateway-insecure"),
      ),
    );
    await assert.rejects(
      restarted.execute(
        id,
        { ...input("stop"), scope: { ...scope, cellGeneration: "2" } },
        deadline(),
      ),
      /sandbox_scope_changed/,
    );
  }));
test("foreign labels and host epochs cannot run Stop", async () =>
  fixture(async ({ engine, calls, swapScope }) => {
    swapScope();
    assert.equal(
      (await engine.execute(randomUUID(), input("stop"), deadline())).errorCode,
      "sandbox_scope_changed",
    );
    assert.ok(calls.every(({ args }) => !args.includes("stop")));
    await assert.rejects(
      engine.execute(
        randomUUID(),
        { ...input("stop"), hostEpoch: 2 },
        deadline(),
      ),
      /sandbox_scope_changed/,
    );
  }));
test("binary change and public CLI state close the command without leaking subprocess errors", async () =>
  fixture(async ({ engine, config }) => {
    await writeFile(config.executable, "changed");
    assert.equal(
      (await engine.execute(randomUUID(), input("stop"), deadline())).errorCode,
      "sandbox_host_unavailable",
    );
    await writeFile(config.executable, "fixture-only-cli");
    await chmod(config.stateHome, 0o755);
    assert.equal(
      (await engine.execute(randomUUID(), input("stop"), deadline())).errorCode,
      "sandbox_host_unavailable",
    );
  }));
test("provider revocation uses exact private names and unreachable fencing rechecks ownership", async () =>
  fixture(async ({ engine, calls, swapScope }) => {
    assert.equal(
      (
        await engine.execute(
          randomUUID(),
          input("revoke_providers"),
          deadline(),
        )
      ).reply.revoked,
      true,
    );
    assert.ok(
      calls.some(
        ({ args }) =>
          args.includes("detach") &&
          args.includes("fixture-provider") &&
          args.includes("--wait"),
      ),
    );
    swapScope();
    await assert.rejects(engine.fenceAll(), /sandbox_host_unavailable/);
  }));

test("reused names and identical labels cannot replace a pinned instance after restart", async () =>
  fixture(async ({ engine, config, root, run, calls, replaceSandbox }) => {
    assert.equal((await engine.execute(randomUUID(), input("inspect"), deadline())).success, true);
    const pinned = JSON.parse(await readFile(path.join(root, "openshell-journal.json"), "utf8"));
    assert.equal(pinned.version, 2);
    assert.ok(pinned.scopes[scope.bindingId].sandboxId);
    replaceSandbox();
    const restarted = openShellHostEngine({ config, epoch: 1, root, run });
    await restarted.initialize();
    for (const action of ["stop", "destroy", "revoke_providers"]) {
      assert.equal((await restarted.execute(randomUUID(), input(action), deadline())).errorCode,
        "sandbox_scope_changed");
    }
    await assert.rejects(restarted.fenceAll(), /sandbox_host_unavailable/);
    assert.ok(calls.every(({ args }) => !args.includes("stop") && !args.includes("delete") && !args.includes("detach")));
    assert.deepEqual(JSON.parse(await readFile(path.join(root, "openshell-journal.json"), "utf8")).scopes,
      pinned.scopes);
  }));
test("absent gateway identity cannot be learned from labels", async () =>
  fixture(async ({ engine, calls, clearSandboxIdentity }) => {
    clearSandboxIdentity();
    assert.equal((await engine.execute(randomUUID(), input("stop"), deadline())).errorCode,
      "sandbox_scope_changed");
    assert.ok(calls.every(({ args }) => !args.includes("stop")));
  }));
test("legacy unpinned observations stay fenced during journal migration", async () =>
  fixture(async ({ config, root, run, calls }) => {
    await writeFile(path.join(root, "openshell-journal.json"), JSON.stringify({
      version: 1, scopes: { [scope.bindingId]: scope }, commands: {},
    }));
    const restarted = openShellHostEngine({ config, epoch: 1, root, run });
    await restarted.initialize();
    assert.equal((await restarted.execute(randomUUID(), input("stop"), deadline())).errorCode,
      "sandbox_scope_changed");
    await assert.rejects(restarted.fenceAll(), /sandbox_host_unavailable/);
    assert.ok(calls.every(({ args }) => !args.includes("stop")));
  }));

test("apply and start use pinned OpenShell policy APIs plus exact Docker identity observations", async () =>
  fixture(async ({ engine, calls, enablePhysical, setPhase, sandboxId }) => {
    enablePhysical();
    setPhase("Stopped");
    const applied = await engine.execute(
      randomUUID(),
      { ...input("apply"), admission: hostAdmission("policy-test", policyDocument) },
      deadline(),
    );
    assert.equal(applied.reply.action, "apply");
    assert.equal(applied.reply.applied, true);
    assert.equal(applied.reply.policyHash, policyHash);
    assert.equal(applied.reply.requiresRecreate, false);
    assert.ok(calls.some(({ args }) => args.includes("policy") && args.includes("set")));
    const expectedSandboxId = sandboxId();
    const policySet = calls.find(({ args }) => args.slice(4).includes("set"));
    assert.equal(policySet.args[policySet.args.indexOf("--expected-sandbox-id") + 1], expectedSandboxId);
    const started = await engine.execute(
      randomUUID(),
      {
        ...input("start"),
        start: {
          policyHash,
          expiresAt: new Date(Date.now() + 50000).toISOString(),
          idempotencyKey: "native-start-1",
        },
      },
      deadline(),
    );
    assert.equal(started.reply.action, "start");
    assert.equal(started.reply.started, true);
    assert.equal(started.reply.containerId, "d".repeat(64));
    assert.equal(started.reply.imageDigest, input("inspect").imageDigest);
    assert.equal(started.reply.policyHash, policyHash);
    assert.ok(calls.some(({ args }) => args.includes("sandbox") && args.includes("start")));
    const startCall = calls.find(({ args }) => args.slice(4).includes("start"));
    assert.equal(startCall.args[startCall.args.indexOf("--expected-sandbox-id") + 1], expectedSandboxId);
  }));

test("expected sandbox IDs guard policy, start, stop, and delete CLI mutations", async () =>
  fixture(async ({ engine, calls, enablePhysical, setPhase, sandboxId }) => {
    enablePhysical();
    setPhase("Stopped");
    const applied = await engine.execute(randomUUID(), { ...input("apply"), admission: hostAdmission("expected-id-policy") }, deadline());
    assert.equal(applied.reply.applied, true);
    const expectedSandboxId = sandboxId();
    await engine.execute(randomUUID(), {
      ...input("start"),
      start: { policyHash, expiresAt: new Date(Date.now() + 50000).toISOString(), idempotencyKey: "expected-id-start" },
    }, deadline());
    await engine.execute(randomUUID(), input("stop"), deadline());
    const destroyed = await engine.execute(randomUUID(), input("destroy"), deadline());
    assert.equal(destroyed.reply.destroyed, true);
    for (const verb of ["set", "start", "stop", "delete"]) {
      const call = calls.find(({ args }) => args.slice(4).includes(verb) &&
        (verb === "set" ? args.slice(4, 6).join(" ") === "policy set" : args.slice(4, 6).join(" ") === `sandbox ${verb === "delete" ? "delete" : verb}`));
      assert.ok(call, `missing ${verb} call`);
      assert.equal(call.args[call.args.indexOf("--expected-sandbox-id") + 1], expectedSandboxId, `${verb} must use the observed UUID precondition`);
    }
  }));

test("a same-name sandbox replacement is rejected by the observed-ID start precondition", async () => {
  let replaceBeforeStart;
  await fixture(async ({ engine, calls, enablePhysical, setPhase, sandboxId, replaceSandbox }) => {
    enablePhysical();
    setPhase("Stopped");
    await engine.execute(randomUUID(), { ...input("apply"), admission: hostAdmission("expected-id-race") }, deadline());
    const observedSandboxId = sandboxId();
    replaceBeforeStart = replaceSandbox;
    const started = await engine.execute(randomUUID(), {
      ...input("start"),
      start: { policyHash, expiresAt: new Date(Date.now() + 50000).toISOString(), idempotencyKey: "expected-id-race-start" },
    }, deadline());
    assert.equal(started.success, false);
    assert.equal(started.errorCode, "sandbox_scope_changed");
    const startCall = calls.find(({ args }) => args.slice(4, 6).join(" ") === "sandbox start");
    assert.ok(startCall);
    assert.equal(startCall.args[startCall.args.indexOf("--expected-sandbox-id") + 1], observedSandboxId);
  }, { beforeCommand(_file, args) {
    if (args.slice(4, 6).join(" ") === "sandbox start" && replaceBeforeStart) {
      const replace = replaceBeforeStart; replaceBeforeStart = null; replace();
    }
  } });
});

test("resource limits flow through a typed admission and are applied and observed on the pinned Docker ID", async () =>
  fixture(async ({ engine, calls, enablePhysical, setPhase, resourceConfig, root }) => {
    enablePhysical();
    setPhase("Stopped");
    const result = await engine.execute(randomUUID(), { ...input("apply"), admission: hostAdmission("resource-bounds") }, deadline());
    assert.ok(result.reply, JSON.stringify(result));
    assert.equal(result.reply.action, "apply");
    assert.equal(result.reply.applied, true);
    assert.deepEqual(resourceConfig(), { NanoCpus: 1500000000, Memory: 536870912, MemorySwap: 536870912, PidsLimit: 128,
      StorageOpt: { size: "1073741824B" },
      Tmpfs: { "/run/openshell-supervisor-ca/material": "rw,noexec,nosuid,nodev,size=1m,uid=1000,gid=1000,mode=0755" } });
    const update = calls.find(call => call.args[0] === "update");
    assert.ok(update);
    assert.equal(update.args.at(-1), "d".repeat(64));
    const journal = JSON.parse(await readFile(path.join(root, "openshell-journal.json"), "utf8"));
    assert.deepEqual(journal.scopes[scope.bindingId].policy.resourceLimits, resourceLimits);
    assert.ok(calls.some(call => call.args[0] === "inspect" && call.args[1] === "d".repeat(64)));
  }));

test("requires the exact create-time disk quota and overlay2 XFS backend before policy application", async () => {
  await fixture(async ({ engine, calls, enablePhysical, setPhase }) => {
    enablePhysical();
    setPhase("Stopped");
    const result = await engine.execute(randomUUID(), {
      ...input("apply"), admission: hostAdmission("disk-quota-match"),
    }, deadline());
    assert.equal(result.reply.applied, true);
    assert.ok(calls.some(({ args }) => args[0] === "info" && args[2] === "{{.Driver}}"));
    assert.ok(calls.some(({ args }) => args[0] === "info" && args[2] === "{{json .DriverStatus}}"));
  });
  await fixture(async ({ engine, calls, enablePhysical, setPhase }) => {
    enablePhysical();
    setPhase("Stopped");
    const result = await engine.execute(randomUUID(), {
      ...input("apply"), admission: hostAdmission("disk-quota-mismatch"),
    }, deadline());
    assert.equal(result.reply.applied, false);
    assert.equal(result.reply.requiresRecreate, true);
    assert.equal(calls.some(({ args }) => args[0] === "update"), false);
  }, { storageOpt: { size: "2147483648B" } });
  await fixture(async ({ engine, enablePhysical, setPhase }) => {
    enablePhysical();
    setPhase("Stopped");
    const result = await engine.execute(randomUUID(), {
      ...input("apply"), admission: hostAdmission("disk-quota-unsupported-backend"),
    }, deadline());
    assert.equal(result.reply.applied, false);
    assert.equal(result.reply.requiresRecreate, true);
  }, { storageDriver: "btrfs" });
});

test("rejects writable mounts outside the size-limited rootfs and mounts that replace its workspace", async () => {
  for (const mount of [
    { Type: "volume", Name: "external", Driver: "local", Destination: "/data", RW: true },
    { Type: "volume", Name: "external", Driver: "local", Destination: "/workspace", RW: false },
  ]) {
    await fixture(async ({ engine, enablePhysical, setPhase }) => {
      enablePhysical();
      setPhase("Stopped");
      const result = await engine.execute(randomUUID(), {
        ...input("apply"), admission: hostAdmission("disk-mount-topology"),
      }, deadline());
      assert.equal(result.success, false);
      assert.equal(result.errorCode, "sandbox_operation_unsupported");
    }, { extraMounts: [mount] });
  }
});

test("resource HostConfig drift blocks restart before the name-scoped OpenShell start call", async () =>
  fixture(async ({ engine, calls, enablePhysical, setPhase, setResourceConfig }) => {
    enablePhysical();
    setPhase("Stopped");
    const applied = await engine.execute(randomUUID(), { ...input("apply"), admission: hostAdmission("resource-drift") }, deadline());
    assert.equal(applied.success, true);
    setResourceConfig({ NanoCpus: 250000000, Memory: 134217728, MemorySwap: 134217728, PidsLimit: 32 });
    calls.length = 0;
    const started = await engine.execute(randomUUID(), {
      ...input("start"),
      start: { policyHash, expiresAt: new Date(Date.now() + 50000).toISOString(), idempotencyKey: "resource-drift-start" },
    }, deadline());
    assert.equal(started.success, false);
    assert.equal(started.errorCode, "sandbox_operation_unsupported");
    assert.equal(calls.some(call => call.args.includes("sandbox") && call.args.includes("start")), false);
  }));

test("a same-name replacement between Docker observation and resource update never receives the update", async () => {
  let replaceContainer;
  await fixture(async ({ engine, calls, enablePhysical, setPhase, replaceContainerBeforeUpdate }) => {
    enablePhysical();
    setPhase("Stopped");
    replaceContainer = replaceContainerBeforeUpdate;
    const result = await engine.execute(randomUUID(), { ...input("apply"), admission: hostAdmission("resource-replacement") }, deadline());
    assert.notEqual(result.success, true);
    const update = calls.find(call => call.args[0] === "update");
    assert.ok(update);
    assert.equal(update.args.at(-1), "d".repeat(64));
    assert.notEqual(update.args.at(-1), "f".repeat(64));
  }, { beforeCommand(file, args) { if (file === "docker" && args[0] === "update") replaceContainer?.(); } });
});

test("a broker profile with the exact authorized binary survives profile inspection", async () =>
  fixture(async ({ engine, calls, enablePhysical, setPhase }) => {
    enablePhysical();
    setPhase("Stopped");
    const profileHash = createHash("sha256").update(JSON.stringify(canonical(brokerProfile))).digest("hex");
    const result = await engine.execute(randomUUID(), { ...input("apply"), admission: hostAdmission("exact-binary-profile", policyDocument,
      { id: brokerProfile.id, hash: profileHash, binaries: ["/usr/bin/node"] }) }, deadline());
    assert.equal(result.success, true, JSON.stringify({ errorCode: result.errorCode, calls: calls.map(call => call.args) }));
    assert.equal(result.reply.applied, true);
    assert.ok(calls.some(call => call.args.slice(4).join(" ").includes("profile describe paperclip-broker")));
  }, { brokerProfile }));

test("broker binary profile must exactly equal the authorized compiled executable set", async () =>
  fixture(async ({ engine, calls, enablePhysical, setPhase }) => {
    enablePhysical();
    setPhase("Stopped");
    const profileHash = createHash("sha256").update(JSON.stringify(canonical(brokerProfile))).digest("hex");
    const result = await engine.execute(randomUUID(), { ...input("apply"), admission: hostAdmission("wrong-binary-profile", policyDocument,
      { id: brokerProfile.id, hash: profileHash, binaries: ["/usr/bin/other"] }) }, deadline());
    assert.equal(result.success, false);
    assert.equal(result.errorCode, "sandbox_operation_unsupported");
    assert.equal(calls.some(call => call.args[0] === "update"), false);
  }, { brokerProfile }));

test("expired source policy deadlines fail before any host or CLI observation", async () =>
  fixture(async ({ engine, calls }) => {
    const expiredApply = await engine.execute(
      randomUUID(),
      { ...input("apply"), admission: { ...hostAdmission("expired-apply"), expiresAt: new Date(0).toISOString() } },
      deadline(),
    );
    assert.equal(expiredApply.errorCode, "sandbox_scope_changed");
    const startBeforeItsSourceDeadline = await engine.execute(
      randomUUID(),
      { ...input("start"), start: { policyHash, expiresAt: new Date(Date.now() + 1000).toISOString(), idempotencyKey: "late-start", } },
      deadline(),
    );
    assert.equal(startBeforeItsSourceDeadline.errorCode, "sandbox_scope_changed");
    assert.equal(calls.length, 0);
  }));

test("a persisted unknown command intent is never replayed after host restart", async () =>
  fixture(async ({ engine, calls, root }) => {
    await engine.execute(randomUUID(), input("inspect"), deadline());
    const commandId = randomUUID();
    const request = {
      ...input("apply"),
      admission: hostAdmission("unknown-after-restart"),
    };
    const journalPath = path.join(root, "openshell-journal.json");
    const journal = JSON.parse(await readFile(journalPath, "utf8"));
    journal.commands[commandId] = {
      requestHash: createHash("sha256").update(JSON.stringify(request)).digest("hex"),
      result: null,
    };
    await writeFile(journalPath, JSON.stringify(journal), { mode: 0o600 });
    await engine.initialize();
    calls.length = 0;
    const retry = await engine.execute(commandId, request, deadline());
    assert.equal(retry.errorCode, "sandbox_observation_unavailable");
    assert.equal(calls.length, 0);
  }));

test("static policy changes require sandbox recreation before any policy mutation", async () =>
  fixture(async ({ engine, calls, enablePhysical, setPhase }) => {
    enablePhysical();
    setPhase("Stopped");
    const candidate = structuredClone(policyDocument);
    candidate.process.run_as_user = "1001";
    const result = await engine.execute(
      randomUUID(),
      { ...input("apply"), admission: hostAdmission("static-change", candidate) },
      deadline(),
    );
    assert.equal(result.reply.applied, false);
    assert.equal(result.reply.requiresRecreate, true);
    assert.equal(calls.some(({ args }) => args.includes("policy") && args.includes("set")), false);
  }));

test("foreign Docker labels block policy mutation before any effect", async () =>
  fixture(async ({ engine, calls, enablePhysical, setPhase, setWrongContainerLabels }) => {
    enablePhysical();
    setPhase("Stopped");
    setWrongContainerLabels();
    const result = await engine.execute(
      randomUUID(),
      { ...input("apply"), admission: hostAdmission("foreign-label", policyDocument) },
      deadline(),
    );
    assert.equal(result.success, false);
    assert.equal(result.errorCode, "sandbox_scope_changed");
    assert.equal(calls.some(({ args }) => args.includes("policy") && args.includes("set")), false);
  }));

test("an image repository digest mismatch blocks policy mutation before any effect", async () =>
  fixture(async ({ engine, calls, enablePhysical, setPhase, setContainerImageDigest }) => {
    enablePhysical();
    setPhase("Stopped");
    setContainerImageDigest("fixture.invalid/other@sha256:" + "f".repeat(64));
    const result = await engine.execute(
      randomUUID(),
      { ...input("apply"), admission: hostAdmission("wrong-image", policyDocument) },
      deadline(),
    );
    assert.equal(result.success, false);
    assert.equal(result.errorCode, "sandbox_scope_changed");
    assert.equal(calls.some(({ args }) => args.includes("policy") && args.includes("set")), false);
  }));

test("a changed OpenShell policy revision blocks workload start", async () =>
  fixture(async ({ engine, calls, enablePhysical, setPhase, changePolicyRevision }) => {
    enablePhysical();
    setPhase("Stopped");
    const applied = await engine.execute(
      randomUUID(),
      { ...input("apply"), admission: hostAdmission("revision-test", policyDocument) },
      deadline(),
    );
    assert.equal(applied.reply.applied, true);
    changePolicyRevision();
    const result = await engine.execute(
      randomUUID(),
      {
        ...input("start"),
        start: {
          policyHash,
          expiresAt: new Date(Date.now() + 50000).toISOString(),
          idempotencyKey: "stale-policy-start",
        },
      },
      deadline(),
    );
    assert.equal(result.success, false);
    assert.equal(result.errorCode, "sandbox_scope_changed");
    assert.equal(calls.some(({ args }) => args.includes("sandbox") && args.includes("start")), false);
  }));

test("physical inspection never promotes host observations to qualification", async () =>
  fixture(async ({ engine, enablePhysical, setPhase }) => {
    enablePhysical();
    setPhase("Ready");
    assert.deepEqual(
      (await engine.execute(randomUUID(), input("inspect"), deadline())).reply,
      {
        action: "inspect",
        state: "running",
        policyHash: null,
        imageDigest: input("inspect").imageDigest,
        generation: "1",
        controlsHealthy: false,
      },
    );
  }));

test("sandbox exec streams through pinned CLI argv without shell and journals no output or replay", async () => {
  let spawnCount = 0, stdinReceived = "", expectedSandboxId;
  const hooks = {
    spawnProcess(file, args, options) {
      spawnCount++;
      assert.ok(path.isAbsolute(file));
      assert.equal(options.shell, false);
      assert.deepEqual(options.stdio, ["pipe", "pipe", "pipe"]);
      const command = args.slice(4), execIndex = command.indexOf("exec");
      assert.ok(execIndex >= 0);
      assert.equal(command[execIndex + 2], scope.sandboxRef);
      assert.equal(command[command.indexOf("--expected-sandbox-id") + 1], expectedSandboxId);
      assert.ok(command.includes("--workdir"));
      const child = new EventEmitter();
      child.stdin = new PassThrough();
      child.stdin.on("data", chunk => { stdinReceived += chunk.toString("utf8"); });
      child.stdout = Readable.from([Buffer.from("fixture stdout")]);
      child.stderr = Readable.from([Buffer.from("fixture stderr")]);
      child.kill = () => true;
      setImmediate(() => child.emit("close", 0, null));
      return child;
    },
  };
  await fixture(async ({ engine, enablePhysical, setPhase, root, sandboxId }) => {
    enablePhysical();
    setPhase("Stopped");
    expectedSandboxId = sandboxId();
    await engine.execute(randomUUID(), {
      ...input("apply"),
      admission: hostAdmission("exec-stream-policy", policyDocument),
    }, deadline());
    await engine.execute(randomUUID(), {
      ...input("start"),
      start: { policyHash, expiresAt: new Date(Date.now() + 50000).toISOString(), idempotencyKey: "exec-stream-start" },
    }, deadline());
    const request = execRequest(deadline(), Buffer.from("fixture stdin").toString("base64"));
    const outputs = [];
    const scopeInput = { companyId: scope.companyId, bindingId: scope.bindingId, cellId: scope.cellId, cellGeneration: "1", sandboxRef: scope.sandboxRef };
    const result = await engine.executeStream({ scope: scopeInput, request, capabilityToken: "fixture-token" }, (stream, chunk) => outputs.push([stream, chunk.toString("utf8")]));
    assert.deepEqual(result, { exitCode: 0, timedOut: false });
    assert.deepEqual(outputs, [["stdout", "fixture stdout"], ["stderr", "fixture stderr"]]);
    assert.equal(stdinReceived, "fixture stdin");
    const journal = await readFile(path.join(root, "openshell-journal.json"), "utf8");
    assert.equal(journal.includes("fixture stdout"), false);
    assert.equal(journal.includes("fixture stderr"), false);
    await assert.rejects(engine.executeStream({ scope: scopeInput, request, capabilityToken: "fixture-token" }, () => {}), /exec_unknown/);
    assert.equal(spawnCount, 1);
  }, hooks);
});

test("sandbox broker capability enters through an expiring native provider, never CLI argv or workload env", async () => {
  let spawnedArgs = null, providerEnvSeen = false;
  const hooks = {
    brokerProfile,
    spawnProcess(_file, args, options) {
      spawnedArgs = args;
      assert.equal(options.shell, false);
      assert.equal(options.env.PAPERCLIP_SANDBOX_BROKER_TOKEN, undefined);
      const child = new EventEmitter();
      child.stdin = new PassThrough();
      child.stdout = Readable.from([Buffer.from("brokered output")]);
      child.stderr = Readable.from([]);
      child.kill = () => true;
      setImmediate(() => child.emit("close", 0, null));
      return child;
    },
    beforeCommand(_file, args) {
      if (args.includes("PAPERCLIP_SANDBOX_BROKER_TOKEN")) providerEnvSeen = true;
    },
  };
  await fixture(async ({ engine, enablePhysical, setPhase, calls, sandboxId }) => {
    enablePhysical();
    setPhase("Stopped");
    await engine.execute(randomUUID(), {
      ...input("apply"),
      admission: hostAdmission("broker-stream-policy", policyDocument),
    }, deadline());
    await engine.execute(randomUUID(), {
      ...input("start"),
      start: { policyHash, expiresAt: new Date(Date.now() + 50000).toISOString(), idempotencyKey: "broker-stream-start" },
    }, deadline());
    const { request, token } = brokerExecRequest();
    hooks.brokerToken = token;
    const outputs = [];
    const scopeInput = { companyId: scope.companyId, bindingId: scope.bindingId, cellId: scope.cellId, cellGeneration: "1", sandboxRef: scope.sandboxRef };
    const result = await engine.executeStream({ scope: scopeInput, request, capabilityToken: "fixture-token" }, (stream, chunk) => outputs.push([stream, chunk.toString("utf8")]));
    assert.deepEqual(result, { exitCode: 0, timedOut: false });
    assert.deepEqual(outputs, [["stdout", "brokered output"]]);
    assert.equal(providerEnvSeen, true);
    assert.ok(calls.some(call => call.args.slice(4).join(" ").includes("provider create")));
    assert.ok(calls.some(call => call.args.slice(4).join(" ").includes("credential-expires-at")));
    const providerAttaches = calls.filter(call => call.args.slice(4).join(" ").includes("provider attach"));
    const providerDetaches = calls.filter(call => call.args.slice(4).join(" ").includes("provider detach"));
    assert.ok(providerAttaches.length > 0);
    assert.ok(providerDetaches.length > 0);
    for (const call of [...providerAttaches, ...providerDetaches])
      assert.equal(call.args[call.args.indexOf("--expected-sandbox-id") + 1], sandboxId());
    assert.ok(calls.some(call => call.args.slice(4).join(" ").includes("provider delete")));
    assert.equal(calls.some(call => call.args.some(value => String(value).includes(token))), false);
    assert.equal(spawnedArgs.some(value => String(value).includes(token)), false);
    assert.equal(spawnedArgs.some(value => String(value).startsWith("PAPERCLIP_SANDBOX_BROKER_TOKEN=")), false);
  }, hooks);
});

test("a broker provider cannot be attached to a same-name replacement sandbox", async () => {
  let replaceBeforeAttach = () => {}, spawned = 0;
  const hooks = {
    brokerProfile,
    spawnProcess() { spawned += 1; throw new Error("replacement sandbox must not receive broker workload"); },
    beforeCommand(_file, args) {
      const command = args.slice(4);
      if (command[0] === "sandbox" && command[1] === "provider" && command[2] === "attach") replaceBeforeAttach();
    },
  };
  await fixture(async ({ engine, enablePhysical, setPhase, calls, replaceSandbox, sandboxId }) => {
    replaceBeforeAttach = replaceSandbox;
    enablePhysical();
    setPhase("Stopped");
    await engine.execute(randomUUID(), { ...input("apply"), admission: hostAdmission("broker-replacement-policy") }, deadline());
    await engine.execute(randomUUID(), { ...input("start"), start: { policyHash, expiresAt: new Date(Date.now() + 50000).toISOString(), idempotencyKey: "broker-replacement-start" } }, deadline());
    const expectedId = sandboxId();
    const { request, token } = brokerExecRequest();
    hooks.brokerToken = token;
    const scopeInput = { companyId: scope.companyId, bindingId: scope.bindingId, cellId: scope.cellId, cellGeneration: "1", sandboxRef: scope.sandboxRef };
    await assert.rejects(engine.executeStream({ scope: scopeInput, request, capabilityToken: "fixture-token" }, () => {}));
    assert.notEqual(sandboxId(), expectedId);
    assert.equal(spawned, 0);
    const attach = calls.find(call => call.args.slice(4).join(" ").includes("provider attach"));
    assert.ok(attach);
    assert.equal(attach.args[attach.args.indexOf("--expected-sandbox-id") + 1], expectedId);
  }, hooks);
});

test("broker use rejects a profile whose signed executable binding differs even when profile hash is current", async () => {
  let spawned = 0;
  const changedProfile = { ...brokerProfile, binaries: [{ path: "/usr/bin/python" }] };
  const hooks = { brokerProfile: changedProfile, spawnProcess() { spawned += 1; throw new Error("should-not-spawn"); } };
  await fixture(async ({ engine, enablePhysical, setPhase, calls }) => {
    enablePhysical(); setPhase("Stopped");
    await engine.execute(randomUUID(), { ...input("apply"), admission: hostAdmission("binary-token-policy") }, deadline());
    await engine.execute(randomUUID(), { ...input("start"), start: { policyHash, expiresAt: new Date(Date.now() + 50000).toISOString(), idempotencyKey: "binary-token-start" } }, deadline());
    const { request, token } = brokerExecRequest();
    hooks.brokerToken = token;
    request.brokerCredential.profileHash = createHash("sha256").update(JSON.stringify(canonical(changedProfile))).digest("hex");
    request.commandDigest = createHash("sha256").update(JSON.stringify(canonical({ argv: request.argv, cwd: request.cwd, env: request.env,
      stdinHash: createHash("sha256").update(Buffer.from(request.stdinBase64, "base64")).digest("hex"), timeoutDeadline: request.deadlineAt,
      brokerCapabilityHash: createHash("sha256").update(token).digest("hex"),
      brokerProviderProfile: { id: request.brokerCredential.profileId, hash: request.brokerCredential.profileHash },
      modelBrokerCapabilityHash: null, modelBrokerProviderProfile: null }))).digest("hex");
    const scopeInput = { companyId: scope.companyId, bindingId: scope.bindingId, cellId: scope.cellId, cellGeneration: "1", sandboxRef: scope.sandboxRef };
    await assert.rejects(engine.executeStream({ scope: scopeInput, request, capabilityToken: "fixture-token" }, () => {}), /sandbox_operation_unsupported/);
    assert.equal(spawned, 0);
    assert.equal(calls.some(call => call.args.slice(4).join(" ").includes("provider create")), false);
  }, hooks);
});

test("managed model capability uses its exact Messages route profile and stays out of workload env and argv", async () => {
  let spawnedArgs = null;
  const hooks = {
    modelBrokerProfile,
    spawnProcess(_file, args, options) {
      spawnedArgs = args;
      assert.equal(options.env.PAPERCLIP_SANDBOX_MODEL_TOKEN, undefined);
      const child = new EventEmitter(); child.stdin = new PassThrough(); child.stdout = Readable.from([]); child.stderr = Readable.from([]);
      child.kill = () => true; setImmediate(() => child.emit("close", 0, null)); return child;
    },
  };
  await fixture(async ({ engine, enablePhysical, setPhase, calls }) => {
    enablePhysical(); setPhase("Stopped");
    await engine.execute(randomUUID(), { ...input("apply"), admission: hostAdmission("model-policy", policyDocument) }, deadline());
    await engine.execute(randomUUID(), { ...input("start"), start: { policyHash, expiresAt: new Date(Date.now() + 50000).toISOString(), idempotencyKey: "model-start" } }, deadline());
    const { request, token } = modelBrokerExecRequest(); hooks.brokerToken = token;
    const scopeInput = { companyId: scope.companyId, bindingId: scope.bindingId, cellId: scope.cellId, cellGeneration: "1", sandboxRef: scope.sandboxRef };
    assert.deepEqual(await engine.executeStream({ scope: scopeInput, request, capabilityToken: "fixture-token" }, () => {}), { exitCode: 0, timedOut: false });
    assert.ok(calls.some(call => call.args.slice(4).join(" ").includes("provider create")));
    assert.ok(calls.some(call => call.args.slice(4).join(" ").includes("paperclip-model-broker")));
    assert.equal(calls.some(call => call.args.some(value => String(value).includes(token))), false);
    assert.equal(spawnedArgs.some(value => String(value).includes(token)), false);
    assert.equal(spawnedArgs.some(value => String(value).startsWith("PAPERCLIP_MANAGED_MODEL_BROKER_ORIGIN=")), true);
    assert.equal(spawnedArgs.some(value => String(value) === "PAPERCLIP_MANAGED_MODEL_INPUT_TOKENS_UPPER_BOUND=100000"), true);
    assert.equal(spawnedArgs.some(value => String(value) === "PAPERCLIP_MANAGED_MODEL_MAX_OUTPUT_TOKENS=1024"), true);
    assert.equal(spawnedArgs.some(value => String(value).startsWith("PAPERCLIP_SANDBOX_MODEL_TOKEN=")), false);
    const forged = structuredClone(request);
    forged.env.PAPERCLIP_MANAGED_MODEL_INPUT_TOKENS_UPPER_BOUND = "100001";
    forged.commandDigest = createHash("sha256").update(JSON.stringify(canonical({
      argv: forged.argv, cwd: forged.cwd, env: forged.env,
      stdinHash: createHash("sha256").update(Buffer.from(forged.stdinBase64, "base64")).digest("hex"),
      timeoutDeadline: forged.deadlineAt,
      brokerCapabilityHash: null, brokerProviderProfile: null,
      modelBrokerCapabilityHash: createHash("sha256").update(token).digest("hex"),
      modelBrokerProviderProfile: { id: forged.modelBrokerCredential.profileId, hash: forged.modelBrokerCredential.profileHash },
    }))).digest("hex");
    await assert.rejects(() => engine.executeStream({
      scope: scopeInput, request: forged, capabilityToken: "fixture-token",
    }, () => {}), /sandbox_scope_changed/);
  }, hooks);
});

test("sandbox exec preflight cancellation and deadline expiry never spawn the CLI", async () => {
  let holdInspect = false, enteredInspect = () => {}, releaseInspect = () => {}, inspectRelease = Promise.resolve();
  let spawnCount = 0;
  const hooks = {
    async beforeCommand(file, args) {
      if (holdInspect && file === "docker" && args[0] === "inspect") {
        holdInspect = false;
        enteredInspect();
        await inspectRelease;
      }
    },
    spawnProcess() { spawnCount++; throw new Error("must-not-spawn"); },
  };
  const holdNextInspection = () => {
    const inspectEntered = new Promise(resolve => { enteredInspect = resolve; });
    inspectRelease = new Promise(resolve => { releaseInspect = resolve; });
    holdInspect = true;
    return inspectEntered;
  };
  await fixture(async ({ engine, enablePhysical, setPhase }) => {
    enablePhysical();
    setPhase("Stopped");
    await engine.execute(randomUUID(), {
      ...input("apply"),
      admission: hostAdmission("exec-preflight-policy", policyDocument),
    }, deadline());
    await engine.execute(randomUUID(), {
      ...input("start"),
      start: { policyHash, expiresAt: new Date(Date.now() + 50000).toISOString(), idempotencyKey: "exec-preflight-start" },
    }, deadline());

    const abortedInspection = holdNextInspection();
    const controller = new AbortController();
    const abortedRequest = engine.executeStream({
      scope: { companyId: scope.companyId, bindingId: scope.bindingId, cellId: scope.cellId, cellGeneration: "1", sandboxRef: scope.sandboxRef },
      request: execRequest(), capabilityToken: "fixture-token",
    }, () => {}, controller.signal);
    await abortedInspection;
    controller.abort();
    releaseInspect();
    await assert.rejects(abortedRequest, /exec_unknown/);
    assert.equal(spawnCount, 0);

    const expiredInspection = holdNextInspection();
    const expiredDeadline = new Date(Date.now() + 1000).toISOString();
    const expiredRequest = engine.executeStream({
      scope: { companyId: scope.companyId, bindingId: scope.bindingId, cellId: scope.cellId, cellGeneration: "1", sandboxRef: scope.sandboxRef },
      request: execRequest(expiredDeadline), capabilityToken: "fixture-token",
    }, () => {});
    await expiredInspection;
    await new Promise(resolve => setTimeout(resolve, 1100));
    releaseInspect();
    await assert.rejects(expiredRequest, /exec_timeout/);
    assert.equal(spawnCount, 0);
  }, hooks);
});
