# Jev lifecycle and mandatory-notice final qualification r4

`source-pins.json` records the full captured source and reconstruction patch. `selected-source-pins.json` and `selected-source-files/` preserve the exact 18-path direct Jev/action-notice selector. The changed HTTP test is separately pinned in `supplemental-source-pins.json` and `supplemental-source-files/`. All 19 selected hashes match the live main source.

The prior r2 Jev/inventory/notice cohort passed 42/42 against its own pinned source. This r4 run covers later notice changes and uses fresh captured-source checks.

Selected tests passed:

- Same-family Action Needed HTTP cases: 2/2, one stable notice and earliest deadline for both profile orders.
- Model retirement notice service: 4/4, including the currently selected blocked worker profile.
- Mandatory Product Notices UI: 5/5.

Type and UI checks:

- Shared package typecheck: passed.
- Standard server package typecheck: passed, including runner vendor prebuild and server TSC.
- UI typecheck: passed.
- Four UI token gates and token synchronization checks: passed.
- Standalone direct server TSC was stopped after the standard server package typecheck passed; see `server-direct-tsc.skipped.txt`. Its exit 137 is retained and is not reported as a pass.

All r4 checks ran from `/workspace/v10-dep-qualification` serially under `/workspace/v10-preparation/v10-pg-tests.lock`.
