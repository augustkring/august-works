#!/usr/bin/env bash
set -euo pipefail
exec flock -x /workspace/v10-preparation/v10-pg-tests.lock bash -lc '
set -euo pipefail
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH
export PAPERCLIP_PLAYWRIGHT_EXECUTABLE=/usr/bin/chromium
out=/workspace/v10-preparation/native-auth-focus-e2e-r3-20261029
mkdir -p "$out"
socket=/tmp/.s.PGSQL.54329
lock=/tmp/.s.PGSQL.54329.lock
if [[ -e "$socket" || -e "$lock" ]]; then
  [[ -S "$socket" && -f "$lock" ]]
  pid="$(head -n 1 "$lock")"
  [[ "$pid" =~ ^[0-9]+$ ]]
  state="$(ps -p "$pid" -o stat= | tr -d " ")"
  [[ "$state" == Z* ]]
  ! ss -ltnp 2>/dev/null | rg -q ":54329\b"
  python3 - <<"PY"
import errno, socket
try:
    connection=socket.create_connection(("127.0.0.1",54329),timeout=2)
except OSError as error:
    if error.errno != errno.ECONNREFUSED:
        raise
else:
    connection.close()
    raise SystemExit("54329 accepted a live TCP connection")
PY
  unlink "$socket"
  unlink "$lock"
else
  ! ss -ltnp 2>/dev/null | rg -q ":54329\b"
fi
python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$out/source-pins.json" > "$out/snapshot.log" 2>&1
node /workspace/v10-preparation/check-snapshot-syntax.cjs "$out/source-pins.json" > "$out/syntax.log" 2>&1
cd /workspace/v10-dep-qualification
set +e
timeout --signal=TERM --kill-after=10s 600s node node_modules/@playwright/test/cli.js test --config tests/e2e/aw-v10-native-auth.config.ts tests/e2e/aw-v10-native-auth.spec.ts --grep "native CLI consent and account settings use real session and authenticator lifecycles" --reporter=line > "$out/e2e.log" 2>&1
rc=$?
printf "%s\n" "$rc" > "$out/e2e.exit"
exit "$rc"
'
