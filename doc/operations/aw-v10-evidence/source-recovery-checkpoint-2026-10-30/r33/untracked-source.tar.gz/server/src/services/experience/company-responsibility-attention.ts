import { and, asc, eq, isNull, sql } from "drizzle-orm";
import {
  agents, aiUseCases, authUsers, billingAccountCompanies, billingAccounts,
  companyAgentPackageInstallations, companyMemberships, companySkillPolicies, companies,
  decisions, issues, toolApplications, toolConnections, toolPolicies, workflows, type Db,
} from "@paperclipai/db";
import type { ExperienceCard, PermissionKey } from "@paperclipai/shared";
import type { AuthorizationAction, AuthorizationActor, AuthorizationResource } from "../authorization.js";
import { authorizationService } from "../authorization.js";
import { accessService } from "../access.js";
import { issueService } from "../issues.js";
import { resolveCurrentDefaultResponsibleHuman } from "../company-responsibility.js";
import { nativeSha256 } from "../native-runtime/canonical.js";
import { visibleIssueCondition } from "../issue-visibility.js";

const KIND_CAP = 40;
const TOTAL_CAP = 400; // ponytail: 200 routine + 400 cross-resource rows per reader request; raise only with a wider query budget.
type Candidate = { id: string; ownerUserId: string | null; updatedAt: Date; agentId?: string | null; issueId?: string | null; sourceCreatorUserId?: string | null };
type Kind = "agent" | "deployment" | "workflow" | "connector" | "skill_policy" |
  "decision" | "ai_use_case" | "policy" | "billing";
type Adapter = {
  kind: Kind; title: string; action: string; view: AuthorizationAction; ownerPermission: PermissionKey | null;
  readRows: (db: Db, companyId: string, actor: AuthorizationActor) => Promise<Candidate[]>;
};

/** Company responsibility inventory is an authorized, source-backed subset.
 * Each adapter reads its own native production rows and permission vocabulary;
 * the projection never assigns owners, changes lifecycle state, or copies grants. */
const adapters: Adapter[] = [
  { kind: "agent", title: "Co-worker", action: "/agents", view: "users:manage_permissions", ownerPermission: "agents:configure",
    readRows: (db, companyId) => db.select({ id: agents.id, ownerUserId: sql<string | null>`null`, updatedAt: agents.updatedAt, agentId: agents.id })
      .from(agents).where(and(eq(agents.companyId, companyId), sql`${agents.status} not in ('terminated','archived','deleted')`)).orderBy(asc(agents.id)).limit(KIND_CAP + 1) },
  { kind: "deployment", title: "Agent Package deployment", action: "/agents", view: "agents:configure", ownerPermission: "users:manage_permissions",
    readRows: (db, companyId) => db.select({ id: companyAgentPackageInstallations.id,
      ownerUserId: aiUseCases.ownerUserId, updatedAt: companyAgentPackageInstallations.updatedAt,
      agentId: companyAgentPackageInstallations.agentId })
      .from(companyAgentPackageInstallations)
      .innerJoin(agents, and(eq(agents.companyId, companyId), eq(agents.id, companyAgentPackageInstallations.agentId),
        sql`${agents.status} not in ('terminated','archived','deleted')`))
      .leftJoin(aiUseCases, and(eq(aiUseCases.companyId, companyId), eq(aiUseCases.id, companyAgentPackageInstallations.aiUseCaseId)))
      .where(and(eq(companyAgentPackageInstallations.companyId, companyId),
        sql`${companyAgentPackageInstallations.status} in ('active','readiness_blocked','degraded','needs_update')`))
      .orderBy(asc(companyAgentPackageInstallations.id)).limit(KIND_CAP + 1) },
  { kind: "workflow", title: "Workflow", action: "/workflows", view: "workflows:read", ownerPermission: "workflows:edit",
    readRows: (db, companyId) => db.select({ id: workflows.id, ownerUserId: sql<string | null>`null`, updatedAt: workflows.updatedAt })
      .from(workflows).where(and(eq(workflows.companyId, companyId), isNull(workflows.archivedAt), sql`${workflows.status} <> 'archived'`,
        sql`jsonb_array_length(${workflows.authoringSourceRunIds}) = 0`,
        sql`aw_workflow_authoring_source_erased(${companyId}::uuid, ${workflows.id}) = false`))
      .orderBy(asc(workflows.id)).limit(KIND_CAP + 1) },
  { kind: "connector", title: "Critical connector", action: "/apps", view: "tools:manage_connections", ownerPermission: "tools:manage_connections",
    readRows: (db, companyId) => db.select({ id: toolConnections.id, ownerUserId: toolApplications.ownerUserId,
      sourceCreatorUserId: toolConnections.createdByUserId, updatedAt: toolConnections.updatedAt }).from(toolConnections)
      .innerJoin(toolApplications, and(eq(toolApplications.companyId, toolConnections.companyId), eq(toolApplications.id, toolConnections.applicationId)))
      .where(and(eq(toolConnections.companyId, companyId), eq(toolConnections.status, "active"), eq(toolConnections.enabled, true),
        eq(toolApplications.status, "active"), isNull(toolApplications.archivedAt)))
      .orderBy(asc(toolConnections.id)).limit(KIND_CAP + 1) },
  { kind: "decision", title: "Material Decision", action: "/decisions", view: "decision_queue:read", ownerPermission: null,
    readRows: (db, companyId) => db.select({ id: decisions.id, ownerUserId: issues.responsibleUserId,
      updatedAt: decisions.updatedAt, issueId: issues.id }).from(decisions)
      .innerJoin(issues, and(eq(issues.companyId, decisions.companyId), eq(issues.id, decisions.originIssueId)))
      .where(and(eq(decisions.companyId, companyId), eq(decisions.status, "open"), sql`${decisions.expiresAt} > now()`, visibleIssueCondition()))
      .orderBy(asc(decisions.id)).limit(KIND_CAP + 1) },
  { kind: "ai_use_case", title: "AI Use Case", action: "/governance/ai-use-cases", view: "company_scope:read", ownerPermission: "users:manage_permissions",
    readRows: async (db, companyId) => {
      const rows = await db.select({ id: aiUseCases.id, ownerUserId: aiUseCases.ownerUserId, updatedAt: aiUseCases.updatedAt })
        .from(aiUseCases).where(and(eq(aiUseCases.companyId, companyId), sql`${aiUseCases.status} in ('approved','assessing','restricted','suspended')`))
        .orderBy(asc(aiUseCases.id)).limit(KIND_CAP + 1);
      return rows;
    } },
  { kind: "policy", title: "Policy", action: "/settings/agent-permissions", view: "tools:manage_profiles", ownerPermission: "tools:manage_profiles",
    readRows: async (db, companyId) => {
      const rows = await db.select({ id: toolPolicies.id, updatedAt: toolPolicies.updatedAt }).from(toolPolicies)
        .where(and(eq(toolPolicies.companyId, companyId), eq(toolPolicies.enabled, true))).orderBy(asc(toolPolicies.id)).limit(KIND_CAP + 1);
      return rows.map(row => ({ ...row, ownerUserId: null }));
    } },
  { kind: "skill_policy", title: "Company skill policy", action: "/company/settings/skills", view: "skill_config:update", ownerPermission: "skills:create",
    readRows: (db, companyId) => db.select({ id: companySkillPolicies.companyId, ownerUserId: sql<string | null>`null`, updatedAt: companySkillPolicies.updatedAt })
      .from(companySkillPolicies).where(eq(companySkillPolicies.companyId, companyId)).limit(KIND_CAP + 1) },
  { kind: "billing", title: "Billing responsibility", action: "/settings/billing", view: "billing:view", ownerPermission: "billing:manage",
    readRows: (db, companyId) => db.select({ id: billingAccounts.id, ownerUserId: billingAccounts.payerUserId, updatedAt: billingAccounts.updatedAt })
      .from(billingAccountCompanies).innerJoin(billingAccounts, eq(billingAccounts.id, billingAccountCompanies.billingAccountId))
      .where(and(eq(billingAccountCompanies.companyId, companyId), eq(billingAccountCompanies.status, "active"),
        eq(billingAccounts.status, "active"), isNull(billingAccounts.closedAt))).orderBy(asc(billingAccounts.id)).limit(KIND_CAP + 1) },
];

export async function readCompanyResponsibilityAttention(db: Db, actor: AuthorizationActor, companyId: string, signal: AbortSignal): Promise<{
  needsYou: ExperienceCard[]; coverage: { state: "partial"; reason: "overflow" | "source_stale" | "source_unavailable" };
}> {
  const empty = { needsYou: [] as ExperienceCard[] };
  if (actor.type !== "board" || !actor.userId || actor.source === "local_implicit") return empty;
  return db.transaction(async raw => {
    const tx = raw as unknown as Db;
    await tx.execute(sql`set local statement_timeout='1500ms'`);
    await tx.execute(sql`set local lock_timeout='200ms'`);
    const auth = authorizationService(tx), permissions = accessService(tx);
    const managerActor = { ...actor, isInstanceAdmin: false, ignoreInstanceAdmin: true };
    const allowed = async (action: AuthorizationAction, resource: AuthorizationResource = { type: "company", companyId }) => {
      signal.throwIfAborted();
      return (await auth.decide({ actor: managerActor, action, resource })).allowed;
    };
    const currentMembershipRole = async (principal: string) => {
      const [row] = await tx.select({ role: companyMemberships.membershipRole }).from(companyMemberships)
        .innerJoin(authUsers, and(eq(authUsers.id, companyMemberships.principalId), eq(authUsers.emailVerified, true)))
        .where(and(eq(companyMemberships.companyId, companyId), eq(companyMemberships.principalType, "user"),
          eq(companyMemberships.principalId, principal), eq(companyMemberships.status, "active"))).limit(1);
      return row?.role ?? null;
    };
    const currentMember = async (principal: string) => Boolean(await currentMembershipRole(principal));
    if (!await currentMember(actor.userId) || !await allowed("company_scope:read") ||
      !await allowed("users:manage_permissions")) return empty;
    const defaultOwner = await resolveCurrentDefaultResponsibleHuman(tx, companyId);
    const cards: ExperienceCard[] = [];
    let totalRowsScanned = 0;
    for (const adapter of adapters) {
      signal.throwIfAborted();
      if (!await allowed(adapter.view)) continue;
      const rows = await adapter.readRows(tx, companyId, managerActor);
      // All adapters retained here apply their current native visibility
      // boundary before LIMIT; this total bounds the complete visible subset.
      totalRowsScanned += rows.length;
      if (rows.length > KIND_CAP || totalRowsScanned > TOTAL_CAP)
        return { ...empty, coverage: { state: "partial", reason: "overflow" } };
      const readable: Candidate[] = [];
      for (const row of rows) {
        signal.throwIfAborted();
        if (adapter.kind === "agent" && row.agentId && !await allowed("agent:read", { type: "agent", companyId, agentId: row.agentId })) continue;
        if (adapter.kind === "decision" && row.issueId) {
          const issue = await issueService(tx).getById(row.issueId);
          if (!issue || issue.companyId !== companyId || !await allowed("issue:read", {
            type: "issue", companyId, issueId: issue.id, projectId: issue.projectId, parentIssueId: issue.parentId,
            status: issue.status, assigneeAgentId: issue.assigneeAgentId, assigneeUserId: issue.assigneeUserId,
          })) continue;
        }
        readable.push(row);
      }
      const orphans: Candidate[] = [];
      for (const row of readable) {
        const assigned = row.ownerUserId;
        let ownerValid = false;
        if (assigned && adapter.kind === "decision") {
          // This Human is the linked Issue's actual responsible Human; the
          // decider and issue assignee are not responsibility provenance.
          ownerValid = await currentMember(assigned);
        } else if (assigned && adapter.kind === "connector" && assigned === row.sourceCreatorUserId) {
          // The native connection route admits its creator or a company
          // connection manager; credential subjects do not confer access.
          ownerValid = await currentMember(assigned);
        } else if (assigned && adapter.ownerPermission) {
          ownerValid = await currentMember(assigned) &&
            await permissions.hasPermission(companyId, "user", assigned, adapter.ownerPermission);
        }
        if (!ownerValid && defaultOwner) {
          if (adapter.kind === "decision") {
            // Current same-company membership is the native read/respond
            // boundary for Decision queues; no responder is appointed here.
            ownerValid = await currentMember(defaultOwner);
          } else if (adapter.ownerPermission) {
            ownerValid = await currentMember(defaultOwner) &&
              await permissions.hasPermission(companyId, "user", defaultOwner, adapter.ownerPermission);
          }
        }
        if (!ownerValid) orphans.push(row);
      }
      if (!orphans.length) continue;
      const source = { domain: "company_responsibility" as const, companyId, resourceId: adapter.kind,
        version: nativeSha256(orphans.map(row => [row.id, row.updatedAt.toISOString()]).sort()), observedAt: new Date().toISOString() };
      cards.push({ id: `company-responsibility:${companyId}:${adapter.kind}`, kind: "recovery", source, freshness: "fresh",
        title: `Review ${adapter.title.toLowerCase()} responsibility`,
        whyYou: "You manage this company's people and access. This is only the subset you are currently authorized to read.",
        consequence: `${orphans.length} currently readable ${adapter.title.toLowerCase()} ${orphans.length === 1 ? "needs" : "need"} an authorized responsible Human. Review through its native owner flow; repair authority does not assign ownership.`,
        evidence: ["company_responsibility_authorized_subset", adapter.kind],
        actions: [{ id: "review-native-owner", label: `Review ${adapter.title.toLowerCase()}`, labelKey: "review", operation: "open",
          href: adapter.action, criticality: "C3", source, requiresCurrentAuthorization: true }] });
    }
    // Security and tenant support follow-up have no tenant-owned case/contact
    // row. Only the manager-visible company default-contact setting can cause
    // these generic repair links; private support cases never enter this scan.
    const [company] = await tx.select({ defaultResponsibleUserId: companies.defaultResponsibleUserId }).from(companies)
      .where(eq(companies.id, companyId)).limit(1);
    const defaultContactCanManage = defaultOwner ? await currentMember(defaultOwner) &&
      await permissions.hasPermission(companyId, "user", defaultOwner, "users:manage_permissions") : false;
    if (!defaultContactCanManage && company && await allowed("users:manage_permissions")) {
      const source = { domain: "company_responsibility" as const, companyId, resourceId: "company_contacts",
        version: nativeSha256([company.defaultResponsibleUserId]), observedAt: new Date().toISOString() };
      cards.push({ id: `company-responsibility:${companyId}:company_contacts`, kind: "recovery", source, freshness: "fresh",
        title: "Review company responsibility contacts", whyYou: "This review is based only on company responsibility settings visible to you.",
        consequence: "Set an authorized company default responsible Human for tenant security and support follow-up. This does not assign Platform Security or private support cases.",
        evidence: ["company_contact_setting_authorized_subset"], actions: [{ id: "review-company-contact", label: "Review company responsibility", labelKey: "review",
          operation: "open", href: "/company/settings/members", criticality: "C3", source, requiresCurrentAuthorization: true }] });
    }
    if (!await currentMember(actor.userId) || !await allowed("users:manage_permissions")) return empty;
    // Metrics, experiments, private workflow runs, admitted approvals, and
    // deployment-owned support/security sources still need native visibility
    // list adapters. Keep this boundary explicit until those readers exist.
    return { needsYou: cards, coverage: { state: "partial", reason: "source_unavailable" } };
  });
}
