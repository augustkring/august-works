import{t as o}from"./createLucideIcon-BqxdEa8D.js";var r=[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]],n=o("chevron-down",r);export{n as t};
