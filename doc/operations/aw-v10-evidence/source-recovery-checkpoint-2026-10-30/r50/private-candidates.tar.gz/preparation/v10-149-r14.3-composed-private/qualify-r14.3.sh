#!/usr/bin/env bash
set -uo pipefail
REPO=/workspace/blentera-v10
MIRROR=/workspace/v10-dep-qualification
CAND=/workspace/v10-preparation/v10-149-r14.3-composed-private
OUT=$CAND/qualification-r14.3
PROVER=/workspace/v10-preparation/tools/openshell-prover-v0.1.2/openshell-prover
EXPECTED_PROVER=3e80c0d041a7552d57cc338868bc825a6261e21b5f29a7d7527bcc7926d423f1
mkdir -m 700 "$OUT" || exit 73
exec 9>/workspace/v10-preparation/v10-pg-tests.lock
flock -x 9
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH
cd "$REPO" || exit 70
restore_sources() {
 python3 - "$CAND/source-pins.json" "$MIRROR" "$OUT/restore-files" "$OUT/restore.log" <<'PY'
from pathlib import Path
import hashlib,json,shutil,sys
pins=json.loads(Path(sys.argv[1]).read_text())['sourceFiles']; mirror=Path(sys.argv[2]); backup=Path(sys.argv[3]); log=Path(sys.argv[4]); failures=[]
for row in pins:
 p=row['path']; target=mirror/p; actual=hashlib.sha256(target.read_bytes()).hexdigest() if target.is_file() else None
 if actual==row['candidateSha256']:
  saved=backup/p
  if not saved.is_file() or hashlib.sha256(saved.read_bytes()).hexdigest()!=row['parentSha256']: failures.append(f'BASELINE_BACKUP_BAD {p}'); continue
  shutil.copy2(saved,target)
 elif actual!=row['parentSha256']: failures.append(f'RESTORE_GUARD_MISMATCH {p} actual={actual}')
for row in pins:
 p=row['path']; target=mirror/p; actual=hashlib.sha256(target.read_bytes()).hexdigest() if target.is_file() else None
 if actual!=row['parentSha256']: failures.append(f'POST_RESTORE_MISMATCH {p} actual={actual}')
log.write_text('\n'.join(failures)+('\n' if failures else 'tracked source overlay restored byte-for-byte\n'))
if failures: raise SystemExit(1)
PY
}
restore_build_state() {
 python3 - "$OUT/build-state" "$MIRROR" "$OUT/build-restore.log" <<'PY'
from pathlib import Path
import hashlib,shutil,sys
backup=Path(sys.argv[1]); mirror=Path(sys.argv[2]); log=Path(sys.argv[3]); failures=[]
def treehash(root): return [(p.relative_to(root).as_posix(),hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(root.rglob('*')) if p.is_file()]
for name in ('packages/shared/dist','packages/db/dist','server/dist'):
 src=backup/name; dst=mirror/name
 if not src.exists():
  if dst.exists(): failures.append(f'UNEXPECTED_NEW_DIST {name}')
  continue
 if treehash(src)!=treehash(dst):
  if dst.exists(): shutil.rmtree(dst)
  shutil.copytree(src,dst)
  if treehash(src)!=treehash(dst): failures.append(f'DIST_RESTORE_MISMATCH {name}')
prior={p.relative_to(backup/'tsbuildinfo').as_posix():p for p in (backup/'tsbuildinfo').rglob('*') if p.is_file()} if (backup/'tsbuildinfo').exists() else {}
current={p.relative_to(mirror).as_posix():p for p in mirror.rglob('*.tsbuildinfo') if p.is_file()}
for rel,p in current.items():
 if rel not in prior: p.unlink(); continue
 saved=prior[rel]
 if hashlib.sha256(p.read_bytes()).digest()!=hashlib.sha256(saved.read_bytes()).digest(): shutil.copy2(saved,p)
for rel,saved in prior.items():
 target=mirror/rel
 if not target.exists(): target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(saved,target)
 if hashlib.sha256(target.read_bytes()).digest()!=hashlib.sha256(saved.read_bytes()).digest(): failures.append(f'TSBUILDINFO_RESTORE_MISMATCH {rel}')
log.write_text('\n'.join(failures)+('\n' if failures else 'dist and tsbuildinfo restored byte-for-byte\n'))
if failures: raise SystemExit(1)
PY
}
cleanup() {
 if [[ -f "$OUT/overlay-ready" ]] && [[ $(cat "$OUT/overlay-ready") == 1 ]]; then restore_sources || echo restore_sources_failed=1 >> "$OUT/restore.log"; fi
 if [[ ${BUILD_BACKUP_READY:-0} == 1 ]]; then restore_build_state || echo restore_build_state_failed=1 >> "$OUT/build-restore.log"; fi
}
trap cleanup EXIT INT TERM
python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$OUT/snapshot-source-pins.json" > "$OUT/snapshot.log" 2>&1
rc=$?; printf '%s\n' "$rc" > "$OUT/snapshot.exit"; if ((rc)); then exit "$rc"; fi
node /workspace/v10-preparation/check-snapshot-syntax.cjs "$OUT/snapshot-source-pins.json" > "$OUT/snapshot-syntax.log" 2>&1
rc=$?; printf '%s\n' "$rc" > "$OUT/snapshot-syntax.exit"; if ((rc)); then exit "$rc"; fi
python3 - "$CAND/source-pins.json" "$CAND/files" "$REPO" "$MIRROR" "$OUT/restore-files" "$OUT/overlay-pins.json" "$OUT" "$OUT/snapshot-source-pins.json" <<'PY'
from pathlib import Path
import hashlib,json,shutil,sys
pinpath,candidate,repo,mirror,backup,pinout,out,snapshot=map(Path,sys.argv[1:]); rows=json.loads(pinpath.read_text())['sourceFiles']; snap={x['path']:x['sha256'] for x in json.loads(snapshot.read_text())['copiedFiles'] if 'sha256' in x}; records=[]
for row in rows:
 p=row['path']; main=repo/p; target=mirror/p; cand=candidate/p
 for label,file,want in [('MAIN baseline',main,row['parentSha256']),('mirror snapshot',target,row['parentSha256']),('candidate',cand,row['candidateSha256'])]:
  actual=hashlib.sha256(file.read_bytes()).hexdigest() if file.is_file() else None
  if actual!=want: raise SystemExit(f'{label} pin mismatch {p}: {actual} != {want}')
 if snap.get(p) is not None and snap[p]!=row['parentSha256']: raise SystemExit(f'snapshot source pin mismatch {p}: {snap.get(p)} != {row["parentSha256"]}')
 saved=backup/p; saved.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(target,saved)
 records.append({'path':p,'parentSha256':row['parentSha256'],'candidateSha256':row['candidateSha256']})
(out/'overlay-ready').write_text('0\n'); pinout.write_text(json.dumps({'files':records},indent=2)+'\n'); (out/'overlay-ready').write_text('1\n')
for row in records:
 shutil.copy2(candidate/row['path'],mirror/row['path'])
 if hashlib.sha256((mirror/row['path']).read_bytes()).hexdigest()!=row['candidateSha256']: raise SystemExit(f'overlay copy mismatch {row["path"]}')
PY
rc=$?; if ((rc)); then exit "$rc"; fi
mkdir -p "$OUT/build-state"
for d in packages/shared/dist packages/db/dist server/dist; do if [[ -d "$MIRROR/$d" ]]; then mkdir -p "$OUT/build-state/$(dirname "$d")"; cp -a "$MIRROR/$d" "$OUT/build-state/$d"; fi; done
mkdir -p "$OUT/build-state/tsbuildinfo"
find "$MIRROR" -name '*.tsbuildinfo' -type f -print0 | while IFS= read -r -d '' f; do rel=${f#"$MIRROR/"}; mkdir -p "$OUT/build-state/tsbuildinfo/$(dirname "$rel")"; cp -a "$f" "$OUT/build-state/tsbuildinfo/$rel"; done
BUILD_BACKUP_READY=1
run_step() { local name="$1"; shift; "$@" > "$OUT/$name.log" 2>&1; local rc=$?; printf '%s\n' "$rc" > "$OUT/$name.exit"; }
actual_prover=$(sha256sum "$PROVER" | awk '{print $1}'); printf '%s\n' "$actual_prover" > "$OUT/prover.sha256"
if [[ "$actual_prover" != "$EXPECTED_PROVER" ]]; then echo "unexpected prover hash $actual_prover" > "$OUT/prover-check.log"; printf '78\n' > "$OUT/prover-check.exit"; else printf '0\n' > "$OUT/prover-check.exit"; fi
run_step host-agent node --test "$MIRROR/deploy/v6/host-agent/openshell.test.mjs"
cd "$MIRROR" || exit 70
run_step shared-typecheck pnpm --filter @paperclipai/shared typecheck
cd "$MIRROR/server" || exit 70
run_step auth-policy-backend-tests env AW_V7_OPENSHELL_PROVER="$PROVER" pnpm exec vitest run src/__tests__/agent-auth-jwt.test.ts src/__tests__/v7-sandbox-policy.test.ts src/__tests__/v7-openshell-backend.test.ts --maxWorkers=1 --reporter=verbose
run_step tool-gateway-broker-test pnpm exec vitest run src/__tests__/tool-gateway.test.ts -t 'resolves broker bindings from the current run grant and assigned gateway without returning secrets' --maxWorkers=1 --reporter=verbose
run_step sandbox-host-integration pnpm exec vitest run src/__tests__/v7-sandbox-host-bridge.integration.test.ts --maxWorkers=1 --reporter=verbose
run_step qualification-fault-tests pnpm exec vitest run src/__tests__/v7-sandbox-qualification-faults.test.ts --maxWorkers=1 --reporter=verbose
run_step server-typecheck pnpm exec tsc --noEmit --singleThreaded
python3 - "$OUT" <<'PY'
from pathlib import Path
import json,sys
out=Path(sys.argv[1]); checks=['prover-check','host-agent','shared-typecheck','auth-policy-backend-tests','tool-gateway-broker-test','sandbox-host-integration','qualification-fault-tests','server-typecheck']; rows={n:int((out/f'{n}.exit').read_text().strip()) for n in checks}; (out/'result.json').write_text(json.dumps(rows,indent=2)+'\n'); print(rows)
if any(rows.values()): raise SystemExit(1)
PY
