# Private OpenShell RT-01 R5 integration candidate

This candidate packages the pinned NVIDIA/OpenShell v0.1.2 downstream patch with source verification and a dedicated, isolated GitHub Actions workflow. It remains **candidate-not-qualified** and profile admission remains closed. It does not modify the main checkout.

The upstream base is commit `6648bd0c290efbc41ba131ee9831ee45cd431f94`. The cumulative R5 patch SHA-256 is recorded in `third_party/openshell/rt01/source-pins.json`. It combines the previously qualified R4 API patch with the R10 Docker disk-limit/syscall-probe changes, the R11 validation correction, and a CLI transport regression proving an identity RPC's `UNIMPLEMENTED` error does not trigger a legacy name-only stop call. R11's Rust changes have not yet been compiled or tested. The exact changed paths and source hashes are pinned; metadata explicitly keeps runtime/profile qualification pending.

## Reproduce the source tree

From the repository root:

```sh
workdir="$(mktemp -d "${TMPDIR:-/tmp}/openshell-rt01.XXXXXX")"
scripts/openshell-rt01/fetch-and-apply.sh "$workdir/source"
```

The helper fetches the exact upstream commit, refuses a pre-existing destination, verifies the cumulative patch hash, applies the patch, and checks all changed paths and pinned files. The package retains the full upstream Apache-2.0 license and downstream attribution.

## Remote qualification

The dedicated workflow installs Rust 1.95.0 minimal, disables debug symbols and incremental compilation, and caps Cargo jobs and Rust test threads at two. It checks formatting, compiles the server, CLI, Docker driver and sandbox packages (including generated protobuf), then resolves and runs 15 named tests with `--exact`. A zero-test filtered command cannot pass: each must appear exactly once in Cargo's test listing and yield one passing, non-ignored result.

The selected cases cover the nine R4 identity-bound RPC/CLI checks, the CLI `UNIMPLEMENTED` no-fallback transport case, three Docker disk-limit validations (including external mount/image-volume rejection), and two sandbox seccomp behavior tests. The workflow retains fetch, format, compile, listing and test logs. It uses read-only repository contents, pinned checkout/upload actions and no provider credentials, model calls, deployed gateway or live host access.

The no-fallback test exercises the CLI over the test TLS transport; it is not a probe against a deployed older gateway. Likewise, disk-limit and seccomp unit tests do not establish physical Docker quota or target-host behavior. Those runtime/host qualifications remain open. See `metadata.json` and `source-pins.json` for exact pending state.
