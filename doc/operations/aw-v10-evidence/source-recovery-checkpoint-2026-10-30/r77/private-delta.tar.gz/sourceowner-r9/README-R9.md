# R9 comprehensive source inventory repair — WIP preview only

The earlier R1–R8 reviews compared known owner/cohort path sets. They did not prove complete relevant base→HEAD coverage. Running the real helper exposed188 missing paths. R9 repairs those memberships explicitly; no helper guard was relaxed and no Main/Mirror file changed.

- 183 paths exist at clean WIP HEADd60139d and join the66 prior current additions:249 current additions total.
- 5 paths exist at base81d3445 but not HEAD:0497/0498/0500/0501 migration snapshots and the old SCIM1.7.2 patch. They are added only to existing groups' deletedSourcePaths/base pins/provenance in a private seed successor. They are NOT current additions and are NOT resurrected.
- 155 paths reuse exact owner assignments from the earlier merged source inventory draft;18 keep that draft's explicit unresolved-owner classification and UNKNOWN accountability. The other33 have explicit existing-domain/sibling mappings with no automatic catch-all. Existing group writer/recovery/Human/status metadata and the full169 crosswalk stay unchanged.
- Absent-both0558–0561 snapshots and retired responsibility prototypes remain retirements; the unpublished copied qualification fixture remains NEVER_ADDED, not a deletion.

## Frozen inputs and actual exercise

Plan: updated-owner-plan-r9.json SHA `ce030e3f64b73a1176a7076cd0095c19c4bb5965f5618ca9bae466a3290b82c1`.

Seed: source-inventory-seed-r9.json SHA `79caf684d3781a91d3477625fb6261b66930f82394ff73b3a52a38521ac747f8`.

Helper UNCHANGED: edit-frozen-source-inventory-r2.py SHA `9f0619291221763b1e1d59e94af791d266672a7e5276d21bbda0414625135d29`.

The actual unchanged helper exited0 against exact tracked-clean WIP `d60139d2fac8911a2be89a27e7c20e3e01de6133`. Output `safe-change-source-wipd601-r9-preview.json` SHA `b6d8c6092f8ab4cabf69fff58fa9aa31b76dce2b526d157250374178bb46e779`; adjacent receipt/log identify1842 relevant source deltas,45 genuine base deletions,13720 total diff paths,50 groups,25 hotspots,169 crosswalk rows and zero untracked source candidates. Historical169 status digest e6630ae7… and full crosswalk e5a38122… remain unchanged. Main remained tracked-clean; Mirror was untouched.

This is an authorized private WIP readiness preview, not final activation, graph generation, Native/Host/Worker acceptance or release qualification. Rerun the exact helper on the eventual final accepted clean source HEAD and a NEW private output name. Do not reuse this WIP output as final source evidence or use old0bcd/R8 arguments for the full branch. Updated future arguments are in metadata-execution-readiness-r147-nov01/COMMANDS.md and final-freeze-sequence-nov01/PLAN-R9.md. The prior active/frozen R4 PLAN and R1–R8 JSON/helper artifacts remain unchanged.

The stricter snapshot candidate5f138 must be installed only AFTER final phase68 metadata and all named refs exist, under the canonical lock with no active helper reader. The restored phase64 still names a retired missing test; it must not be used to install that candidate early. Canonical snapshot helper remains Root-restoreddf80 until the explicit final metadata step.
