# Private OpenShell RT-01 repository integration candidate

This candidate is ready for review as a small, reproducible source integration. It does not modify the main checkout. It adds the private, hash-pinned NVIDIA/OpenShell patch and attribution, a fetch/apply/source-pin verifier, and a dedicated isolated GitHub Actions workflow. The only checked-out upstream revision is `6648bd0c290efbc41ba131ee9831ee45cd431f94`; the cumulative R3 patch SHA-256 is `bc7ea25a9c23a562707297a00d0da3adcb5e5cb527e2afb158db1e8bcf899cdc` (parent R2 patch `5d1556c605d4ea33cc896a718e179d985d33645f505a31c8f1c7719838a5542a`).

R3 remote CI passed `cargo check --locked -p openshell-server -p openshell-cli`, including generated protobuf, but its test-compilation step failed before running tests because `tonic::Code` was not imported in the sandbox test module. R4 adds only that test-module import; all other R3 pinned source files, including production files, are byte-identical. R4 remains **unqualified** until its remote workflow completes the new test build and all nine focused tests. Profile admission remains closed. Old-gateway `UNIMPLEMENTED` compatibility and physical target-host probes remain separate evidence.

The workflow checks that each named test exists exactly once and requires one passing, non-ignored result, so a filtered zero-test Cargo exit cannot pass. It retains fetch, formatting, compile and test logs. The workflow has read-only `contents` permission, pinned checkout/upload actions, no secrets, and no live-provider calls. It installs Rust 1.95.0 minimal and disables debug info/incremental builds with two Cargo jobs. Its logs are retained as a short-lived CI artifact for review.

## Stage list (repository-relative destinations)

See `STAGE-LIST.txt`. Copy these exact files into the repository working tree for review; do not stage anything else through this candidate package.
