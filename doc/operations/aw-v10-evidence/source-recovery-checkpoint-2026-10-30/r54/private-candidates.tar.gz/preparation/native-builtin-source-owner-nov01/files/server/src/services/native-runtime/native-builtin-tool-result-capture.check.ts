import assert from "node:assert/strict";
import { createHash, randomUUID } from "node:crypto";
import { chmod, mkdtemp, readFile, readdir, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import * as capture from "./native-builtin-tool-result-capture.js";
import { nativeSha256 } from "./canonical.js";
import { materializeAsset } from "./runtime-context.js";

const sha = (value: Buffer | string) => createHash("sha256").update(value).digest("hex");
const owner = { companyId:randomUUID(),runId:randomUUID() };
const workspaceId = randomUUID();
const emptyPolicy = { issueIds:[],projectIds:[],runIds:[owner.runId],memoryIds:[],foundationRevisionIds:[] };
const root = await mkdtemp(path.join(tmpdir(),"native-builtin-source-check-"));
const previousHome = process.env.PAPERCLIP_HOME, previousInstance = process.env.PAPERCLIP_INSTANCE_ID;
process.env.PAPERCLIP_HOME = root; process.env.PAPERCLIP_INSTANCE_ID = "capture-check";
async function writable(target:string) { const entries = await readdir(target,{withFileTypes:true}); await chmod(target,0o700);
  for (const entry of entries) { const child=path.join(target,entry.name); if(entry.isDirectory())await writable(child);else await chmod(child,0o600); } }
function snapshot(files:Record<string,string>, phase:"pre"|"post"="pre"):capture.NativeBuiltinWorkspaceSnapshot {
  const rows=Object.entries(files).sort(([a],[b])=>a<b?-1:1).map(([relativePath,text])=>{
    const bytes=Buffer.from(text);return {relativePath,exists:true as const,sha256:sha(bytes),size:bytes.length,contentBase64:bytes.toString("base64"),device:1,inode:1,mtimeMs:1}; });
  return {schema:"paperclip.native-workspace-witness.v1",phase,toolUseId:"tool-file-A",toolName:"Read",workspaceRootDigest:capture.nativeBuiltinWorkspaceRootDigest("/trusted/workspace"),
    snapshotDigest:`sha256:${nativeSha256(rows.map(file=>({path:file.relativePath,hash:file.sha256,size:file.size})))}`,
    fileCount:rows.length,totalBytes:rows.reduce((n,row)=>n+row.size,0),files:rows,excludedSymlinks:[]};
}
let checks=0;
try {
  const before=snapshot({"A.txt":"public A"}), after=snapshot({"A.txt":"public A","B.txt":"private B"},"post");
  const workspaceSource=capture.nativeBuiltinDeclaredWorkspaceSource({runId:owner.runId,executionWorkspaceId:workspaceId,sdkSessionId:"sdk-session",snapshot:before,
    captureId:"pre-A",eventSeq:1,attempt:1,turnId:"turn",normalizedSessionId:"native-session"});
  assert.notEqual(workspaceSource.contentHash,capture.nativeBuiltinDeclaredWorkspaceSource({runId:owner.runId,
    executionWorkspaceId:workspaceId,sdkSessionId:"sdk-session",snapshot:before,captureId:"different-pre",eventSeq:1,attempt:1,
    turnId:"turn",normalizedSessionId:"native-session"}).contentHash);checks++;
  const initial={policy:emptyPolicy,inputs:[workspaceSource]};
  const privateMemory={kind:"memory" as const,memoryId:randomUUID(),sourceVersion:"v1",contentHash:sha("private B")};
  const produced={policy:{...emptyPolicy,memoryIds:[privateMemory.memoryId]},inputs:[workspaceSource,privateMemory]};
  const fileSourcesBefore=capture.nativeBuiltinFileLineageBefore(before,null,initial);
  const fileSourcesAfter=capture.nativeBuiltinFileLineageAfter(before,after,fileSourcesBefore,produced);
  assert.deepEqual(fileSourcesAfter.find(file=>file.relativePath==="A.txt")!.sourceSet,initial);checks++;
  assert.deepEqual(fileSourcesAfter.find(file=>file.relativePath==="B.txt")!.sourceSet,produced);checks++;
  const call={tool_name:"Read",tool_use_id:"tool-file-A",tool_input:{file_path:"/trusted/workspace/A.txt"},tool_response:"1\tpublic A"};
  const workspace={executionWorkspaceId:workspaceId,sessionId:"sdk-session",rootPath:"/trusted/workspace",before,after:snapshot({"A.txt":"public A"},"post")};
  assert.deepEqual(capture.nativeBuiltinReadFileSourceSet(call,workspace,fileSourcesBefore),initial);checks++;
  assert.throws(()=>capture.nativeBuiltinReadFileSourceSet({...call,tool_input:{file_path:"/other/A.txt"}},workspace,fileSourcesBefore));checks++;
  assert.throws(()=>capture.nativeBuiltinReadFileSourceSet(call,{...workspace,after:snapshot({"A.txt":"changed"},"post")},fileSourcesBefore));checks++;
  assert.throws(()=>capture.validateNativeBuiltinWorkspaceSnapshot({...before,files:[{...before.files[0]!,contentBase64:Buffer.from("tampered!").toString("base64")}]}));checks++;
  assert.throws(()=>capture.validateNativeBuiltinWorkspaceSnapshot({...before,files:[{...before.files[0]!,relativePath:"../A.txt"}]}));checks++;
  const pre:capture.NativeBuiltinToolPreAsset={schema:"paperclip.native-builtin-tool-pre.v1",...owner,eventSeq:1,attempt:1,captureId:"pre-A",normalizedSessionId:"native-session",
    turnId:"turn",sdkSessionId:"sdk-session",executionWorkspaceId:workspaceId,rootPath:workspace.rootPath,call,snapshot:before,fileSources:fileSourcesBefore,previousCaptureDigest:null,sourceSet:initial};
  const retainedPre=await capture.materializeNativeBuiltinToolPreAsset(pre);
  const asset:capture.NativeBuiltinToolCaptureAsset={schema:"paperclip.native-builtin-tool-capture.v1",...owner,eventSeq:1,attempt:1,captureId:"capture-A",
    normalizedSessionId:"native-session",turnId:"turn",sdkSessionId:"sdk-session",batch:{session_id:"sdk-session",transcript_path:"/trusted/transcript.jsonl",cwd:workspace.rootPath,
      prompt_id:"prompt",permission_mode:"bypassPermissions",hook_event_name:"PostToolBatch",tool_calls:[call]},workspace,fileSourcesBefore,fileSourcesAfter:capture.nativeBuiltinFileLineageAfter(workspace.before,workspace.after,fileSourcesBefore,produced),
    producedSources:produced,resultSources:[{callId:call.tool_use_id,sourceSet:initial}]};
  const retained=await capture.materializeNativeBuiltinToolCaptureAsset(asset);
  assert.deepEqual(await capture.readNativeBuiltinToolCaptureAsset(retained.bundle,owner),asset);checks++;
  await assert.rejects(capture.readNativeBuiltinToolCaptureAsset(retained.bundle,{...owner,companyId:randomUUID()}));checks++;
  await assert.rejects(capture.readNativeBuiltinToolCaptureAsset(retained.bundle,{...owner,runId:randomUUID()}));checks++;
  const global=await materializeAsset([{path:"native-builtin-capture.json",content:Buffer.from(JSON.stringify(asset)),mode:0o444}]);
  await assert.rejects(capture.readNativeBuiltinToolCaptureAsset(global,owner));checks++;
  const row={nativeBuiltin:true,captureId:asset.captureId,captureAsset:retained.bundle,captureDigest:retained.captureDigest,
    preCaptureAsset:retainedPre.bundle,preCaptureDigest:retainedPre.captureDigest,workspaceSource,eventSeq:1,attempt:1,turnId:"turn",sdkSessionId:"sdk-session",executionWorkspaceId:workspaceId,
    callId:call.tool_use_id,tool:call.tool_name,argumentsHash:nativeSha256(call.tool_input),resultDigest:nativeSha256(call.tool_response),sourceSet:initial,sourceInputs:initial.inputs,
    source:{kind:"tool_result",runId:owner.runId,callId:call.tool_use_id,toolName:call.tool_name,invocationId:null,contentHash:nativeSha256(call.tool_response)}};
  await capture.assertNativeBuiltinToolCaptureRow(row,owner);checks++;
  await assert.rejects(capture.assertNativeBuiltinToolCaptureRow({...row,sourceSet:produced},owner));checks++;
  const intent={providerProtocol:"claude_messages",sdkSessionId:"sdk-session",reservationId:randomUUID(),responseContentHash:sha("wire"),consumedSourceSet:initial,
    consumedSourceSetHash:nativeSha256(initial),consumedSourceComponents:[],responseToolUses:[{id:call.tool_use_id,name:call.tool_name,argumentsHash:nativeSha256(call.tool_input)}]};
  capture.nativeBuiltinToolUseIntent({nativeAwModelWireIntents:[intent]},asset,call);checks++;
  for (const forged of [{...intent,providerProtocol:"opencode"},{...intent,sdkSessionId:"other"},{...intent,responseToolUses:[{...intent.responseToolUses[0],argumentsHash:sha("evil")}]}]) {
    assert.throws(()=>capture.nativeBuiltinToolUseIntent({nativeAwModelWireIntents:[forged]},asset,call));checks++;
  }
  assert.throws(()=>capture.nativeBuiltinToolUseIntent({nativeAwModelWireIntents:[intent,intent]},asset,call));checks++;
  const target=path.join(retained.bundle.rootPath,"native-builtin-capture.json");
  await chmod(target,0o600); const text=await readFile(target,"utf8");await writeFile(target,text.replace("public A","public X"));
  await assert.rejects(capture.readNativeBuiltinToolCaptureAsset(retained.bundle,owner));checks++;
  await chmod(retained.bundle.rootPath,0o700);await rm(target);await assert.rejects(capture.readNativeBuiltinToolCaptureAsset(retained.bundle,owner));checks++;
  const expected={captureId:"frame-capture",runId:owner.runId,normalizedSessionId:"native-session",turnId:"turn"};
  const sourceEvent={eventType:"runtime.native_tool_batch_capture",runId:owner.runId,turnId:"turn",sequence:1,
    payload:{captureId:"frame-capture",capture:{phase:"pre",sessionId:"acp-session",sdkHookToolUseId:"hook-id-not-tool-use-id",
      toolUseId:call.tool_use_id,toolName:call.tool_name,toolInput:call.tool_input,workspaceWitness:before,
      sdkHookInput:{session_id:"sdk-session",hook_event_name:"PreToolUse",tool_use_id:call.tool_use_id,tool_name:call.tool_name,tool_input:call.tool_input}}}};
  assert.throws(()=>capture.assertNativeBuiltinToolSourceSupported("WebFetch"),/tool_source_unsupported/);checks++;
  assert.throws(()=>capture.assertNativeBuiltinToolSourceSupported("Bash"),/tool_source_unsupported/);checks++;
  capture.assertNativeBuiltinToolWorkspaceAccess(call,"/trusted/workspace");checks++;
  for (const tool of ["Read","Write","Edit"]) {
    assert.throws(()=>capture.assertNativeBuiltinToolWorkspaceAccess({...call,tool_name:tool,tool_input:{file_path:"/outside/secret"}},"/trusted/workspace"),/workspace_scope_unsupported/);checks++;
  }
  const decoded=capture.nativeBuiltinToolCaptureRequestFromSourceEvent(sourceEvent,expected);
  assert.equal(decoded.phase,"pre");assert.equal(decoded.capture.sdkSessionId,"sdk-session");checks++;
  assert.throws(()=>capture.nativeBuiltinToolCaptureRequestFromSourceEvent({...sourceEvent,runId:randomUUID()},expected));checks++;
  assert.throws(()=>capture.nativeBuiltinToolCaptureRequestFromSourceEvent({...sourceEvent,payload:{...sourceEvent.payload,captureId:"replay"}},expected));checks++;
  assert.throws(()=>capture.nativeBuiltinToolCaptureRequestFromSourceEvent({...sourceEvent,payload:{...sourceEvent.payload,
    capture:{...sourceEvent.payload.capture,toolInput:{file_path:"other"}}}},expected));checks++;
  assert.throws(()=>capture.validateNativeBuiltinWorkspaceSnapshot({...before,snapshotDigest:`sha256:${"0".repeat(64)}`}));checks++;
  assert.throws(()=>capture.validateNativeBuiltinWorkspaceSnapshot({...before,excludedSymlinks:["secret-link"]} as unknown as capture.NativeBuiltinWorkspaceSnapshot));checks++;
  assert.throws(()=>capture.nativeBuiltinFileLineageBefore(snapshot({"A.txt":"unexplained change"}),asset,initial));checks++;
  process.stdout.write(`native builtin source owner: ${checks} checks passed\n`);
} finally {
  await writable(root);await rm(root,{recursive:true,force:true});
  if(previousHome===undefined)delete process.env.PAPERCLIP_HOME;else process.env.PAPERCLIP_HOME=previousHome;
  if(previousInstance===undefined)delete process.env.PAPERCLIP_INSTANCE_ID;else process.env.PAPERCLIP_INSTANCE_ID=previousInstance;
}
