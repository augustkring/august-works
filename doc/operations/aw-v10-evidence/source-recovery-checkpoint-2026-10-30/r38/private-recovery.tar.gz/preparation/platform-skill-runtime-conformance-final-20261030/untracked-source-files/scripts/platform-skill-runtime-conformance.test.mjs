import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { test } from "node:test";
import path from "node:path";
import { parseTestSummary, validateContract, validateSuites } from "./run-platform-skill-runtime-conformance.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

test("runtime conformance contract maps every common case and keeps external runtime profiles unqualified", async () => {
  const contract = JSON.parse(await readFile(path.join(root, "evals/platform-skill/runtime-conformance.json"), "utf8"));
  validateContract(contract);
  const ids = contract.scenarios.map(({ id }) => id);
  assert.deepEqual(ids, ["pinned-positive-delivery", "missing-or-stale-pin", "reserved-name-collision", "isolated-profile-boundary", "safe-recovery-boundary"]);
  for (const profile of contract.profiles) {
    assert.match(profile.qualification, /unqualified|not-GA/i);
    assert.equal(profile.exactInstalledVersion, null);
  }
  const runnable = contract.profiles.filter(({ suites }) => suites.length > 0);
  assert.equal(runnable.length, 3);
  assert.ok(runnable.every(({ commonSuiteComplete }) => commonSuiteComplete), "every source-implemented runtime must map all common scenarios");
  const pins = await validateSuites(contract);
  assert.ok(Object.keys(pins).length >= runnable.length);
});

test("A2A/custom profile cannot advertise a source test driver that does not exist", async () => {
  const contract = JSON.parse(await readFile(path.join(root, "evals/platform-skill/runtime-conformance.json"), "utf8"));
  const profile = contract.profiles.find(({ id }) => id === "a2a-or-custom");
  profile.suites = [{ path: "missing.test.ts", config: "vitest.config.ts", selection: "case", scenarios: [] }];
  assert.throws(() => validateContract(contract), /cannot claim suites without a delivery driver/);
});

test("test summary parser rejects all-skipped or unrecognized Vitest results", () => {
  assert.deepEqual(parseTestSummary("Tests 3 passed | 2 skipped (5)"), { passed: 3, failed: 0, skipped: 2, todo: 0, total: 5, parsed: true });
  assert.equal(parseTestSummary("Tests 5 skipped (5)").passed, 0);
  assert.equal(parseTestSummary("Test Files 1 passed (1)").parsed, false);
});
