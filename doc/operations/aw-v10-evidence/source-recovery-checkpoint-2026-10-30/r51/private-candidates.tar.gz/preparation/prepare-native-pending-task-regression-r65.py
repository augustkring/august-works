from pathlib import Path
import hashlib,json,difflib
root=Path('/workspace/blentera-v10');base=Path('/workspace/v10-preparation/native-before-predicate-r63-recovered');out=Path('/workspace/v10-preparation/native-pending-task-r65-candidate');rel='server/src/__tests__/native-payload-temporal-sources.integration.test.ts';old=(root/rel).read_text();a=(base/rel).read_text();s=a
s=s.replace('import { issueService } from "../services/issues.js";','import * as authorizationChecks from "../services/authorization.js";\nimport { issueService } from "../services/issues.js";',1)
needle='''    // An external callback can write owner families outside the four receipt
'''
addition='''    // A private pending Task reader must finish before an external callback
    // can perform an effect. Revoke the real represented Human immediately at
    // its actual deferred Task ACL query, then run the original SQL checker.
    await db.transaction(async rawTx => {
      const tx = rawTx as unknown as typeof db;
      const [memory] = await tx.select({ snapshot: memoryRecords.payloadSourceSnapshot }).from(memoryRecords)
        .where(and(eq(memoryRecords.companyId, first.companyId), eq(memoryRecords.id, memoryAId!)));
      const snapshot = nativePayloadSourceSnapshotSchema.parse(memory?.snapshot);
      const actualTaskReader = authorizationChecks.canActorReadPinnedIssuePrivacyBatch;
      let revoked = false;
      let callbackRan = false;
      const adoptions = nativeSourceMemoDiagnosticsForTest().pendingTaskAdoptions;
      const taskReader = vi.spyOn(authorizationChecks, "canActorReadPinnedIssuePrivacyBatch")
        .mockImplementation(async (...args) => {
          const actor = args[1];
          const representedAlice = actor.userId === first.aliceUserId || actor.onBehalfOfUserId === first.aliceUserId;
          if (!revoked && representedAlice && args[2] === first.companyId &&
              args[3].some(task => task.issueId === temporal.taskAId)) {
            expect(args[0]).toBe(tx);
            revoked = true;
            await tx.update(companyMemberships).set({ status: "suspended" }).where(aliceMembershipFilter);
          }
          return actualTaskReader(...args);
        });
      try {
        await expect(withNativeMemoryOutputSnapshotCurrent(tx, { companyId: first.companyId,
          recordId: memoryAId!, snapshot, actor: second.aliceActor }, async sourceDb => {
          expect(sourceDb).toBe(tx);
          callbackRan = true;
        })).rejects.toMatchObject({ status: 403 });
        expect(revoked).toBe(true);
        expect(callbackRan).toBe(false);
        expect(nativeSourceMemoDiagnosticsForTest().pendingTaskAdoptions).toBeGreaterThan(adoptions);
      } finally {
        taskReader.mockRestore();
        await tx.update(companyMemberships).set({ status: "active" }).where(aliceMembershipFilter);
      }
      await expect(withNativeMemoryOutputSnapshotCurrent(tx, { companyId: first.companyId,
        recordId: memoryAId!, snapshot, actor: second.aliceActor }, async sourceDb => {
        expect(sourceDb).toBe(tx);
        callbackRan = true;
      })).resolves.toBeUndefined();
      expect(callbackRan).toBe(true);
    });

'''
assert s.count(needle)==1;s=s.replace(needle,addition+needle,1)
p=out/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
(out/'pending-regression.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
(out/'native-payload-temporal-sources.integration.test.ts.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
m=json.loads((out/'manifest.json').read_text());m[rel]={'priorSha256':hashlib.sha256(old.encode()).hexdigest(),'candidateSha256':hashlib.sha256(s.encode()).hexdigest()};(out/'manifest.json').write_text(json.dumps(m,indent=2))
