#!/usr/bin/env bash
set -euo pipefail
exec flock -x /workspace/v10-preparation/v10-pg-tests.lock bash -lc '
set -euo pipefail
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH
out=/workspace/v10-preparation/native-auth-focus-unit-and-e2e-r1-20261029
mkdir -p "$out"
python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$out/source-pins.json" > "$out/snapshot.log" 2>&1
node /workspace/v10-preparation/check-snapshot-syntax.cjs "$out/source-pins.json" > "$out/syntax.log" 2>&1
cd /workspace/v10-dep-qualification/ui
set +e
timeout --signal=TERM --kill-after=10s 180s ../node_modules/.bin/vitest run src/pages/Auth.test.tsx -t "confirms fresh identity, reviews the challenge again, and requires a separate explicit approval" --maxWorkers=1 --reporter=verbose > "$out/unit.log" 2>&1
unit_rc=$?
printf "%s\n" "$unit_rc" > "$out/unit.exit"
if [[ "$unit_rc" -ne 0 ]]; then exit "$unit_rc"; fi
cd /workspace/v10-dep-qualification
set +e
timeout --signal=TERM --kill-after=10s 600s node node_modules/@playwright/test/cli.js test --config tests/e2e/aw-v10-native-auth.config.ts tests/e2e/aw-v10-native-auth.spec.ts --grep "native CLI consent and account settings use real session and authenticator lifecycles" --reporter=line > "$out/e2e.log" 2>&1
e2e_rc=$?
printf "%s\n" "$e2e_rc" > "$out/e2e.exit"
exit "$e2e_rc"
'
