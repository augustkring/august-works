#!/usr/bin/env bash
set -euo pipefail
exec flock -x /workspace/v10-preparation/v10-pg-tests.lock bash -lc '
set -euo pipefail
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH
out=/workspace/v10-preparation/native-auth-full-auth-and-token-gates-r1-20261029
mkdir -p "$out"
python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$out/source-pins.json" > "$out/snapshot.log" 2>&1
node /workspace/v10-preparation/check-snapshot-syntax.cjs "$out/source-pins.json" > "$out/syntax.log" 2>&1
cd /workspace/v10-dep-qualification/ui
set +e
timeout --signal=TERM --kill-after=10s 180s ../node_modules/.bin/vitest run src/pages/Auth.test.tsx --maxWorkers=1 --reporter=verbose > "$out/auth.log" 2>&1
unit_rc=$?
printf "%s\n" "$unit_rc" > "$out/auth.exit"
if [[ "$unit_rc" -ne 0 ]]; then exit "$unit_rc"; fi
cd /workspace/blentera-v10
set +e
pnpm check:token-gates > "$out/token-gates.log" 2>&1
gates_rc=$?
printf "%s\n" "$gates_rc" > "$out/token-gates.exit"
exit "$gates_rc"
'
