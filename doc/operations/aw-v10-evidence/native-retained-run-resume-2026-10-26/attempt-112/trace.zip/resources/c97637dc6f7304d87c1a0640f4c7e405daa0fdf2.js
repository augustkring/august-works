var a=Object.defineProperty;var e=(t,r)=>a(t,"name",{value:r,configurable:!0});import{Ur as i,_r as o}from"./dist-B1cqYVKS.js";function n(t){return i(o,t)}e(n,"datetime");export{n as t};
