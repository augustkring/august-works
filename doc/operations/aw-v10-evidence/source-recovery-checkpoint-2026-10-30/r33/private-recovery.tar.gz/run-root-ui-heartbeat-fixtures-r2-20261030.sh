#!/usr/bin/env bash
set -euo pipefail
exec flock -x /workspace/v10-preparation/v10-pg-tests.lock bash -lc '
set -euo pipefail
source /workspace/v10-preparation/env.sh
export NODE_OPTIONS=--max-old-space-size=3072
out=/workspace/v10-preparation/root-ui-heartbeat-fixtures-r2-20261030
mkdir "$out"
python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$out/source-pins.json" > "$out/snapshot.log" 2>&1
node /workspace/v10-preparation/check-snapshot-syntax.cjs "$out/source-pins.json" > "$out/syntax.log" 2>&1
set +e
cd /workspace/v10-dep-qualification/ui
timeout --signal=TERM --kill-after=10s 120s python3 /workspace/v10-preparation/run-with-owned-child-cleanup.py ../node_modules/.bin/vitest run src/pages/CustomerHelpCenter.test.tsx --reporter=verbose > "$out/ui.log" 2>&1
ui_rc=$?
printf "%s\n" "$ui_rc" > "$out/ui.exit"
cd /workspace/v10-dep-qualification/server
timeout --signal=TERM --kill-after=10s 180s python3 /workspace/v10-preparation/run-with-owned-child-cleanup.py ../node_modules/.bin/vitest run src/__tests__/heartbeat-lock-release-on-reassignment.test.ts --reporter=verbose > "$out/heartbeat.log" 2>&1
heartbeat_rc=$?
printf "%s\n" "$heartbeat_rc" > "$out/heartbeat.exit"
if [[ "$ui_rc" -ne 0 ]]; then exit "$ui_rc"; fi
exit "$heartbeat_rc"
'
