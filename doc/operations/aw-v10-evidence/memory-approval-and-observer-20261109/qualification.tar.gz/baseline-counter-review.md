# Native model socket observer counter fix (private candidate)

`candidate.patch` is a private, unapplied patch against current V10 HEAD. It changes only the observer, one bounded built-in Node regression, the existing privileged check's scanner hash, the three trusted workflow scanner pins plus the new test invocation, and the managed transport helper's scanner pin.

The scanner now counts visited numeric PIDs separately (limit 8192) from visited file descriptors (limit 131072). The full `/proc` scan and unique-owner requirement remain; no limit is raised, no early-match return is added, and the existing deadline and multi-owner denial behavior is unchanged. `observeSocketOwner` is exported and its CLI body is guarded so the existing injected-I/O function can be imported without starting the privileged stdin operation.

The new five-case test uses a small fake-procfs I/O factory. It covers a process with exactly 8192 nonmatching FDs followed by the unique owner; the unchanged 131072 FD cap; the unchanged 8192 PID cap; deadline failure during enumeration; and denial after scanning both PIDs when the socket has multiple owners. The multiple-owner test asserts both candidate owners were scanned, preserving the no-early-return rule. All five pass with the candidate. The HEAD implementation fails the cross-budget regression at `fd_readlink` and the exact 131072-FD boundary (it observes only 131071 FDs because the PID consumed one shared count); the other three controls pass.

Validation performed:

- Candidate `node --check scripts/fixtures/native-model-socket-observer.mjs`: passed.
- Candidate bounded Node test under clean environment and a 5-second timeout: 5/5 passed in about 128 ms.
- Baseline reproduction: expected 3/5 pass, 2/5 fail; the regression fails at `fd_readlink` after the first PID's 8192 descriptors, and the FD boundary observes 131071 instead of 131072.
- `git apply --check --whitespace=error candidate.patch` against the current shared checkout: passed.
- No Main files were edited. No `sudo`, privileged socket observer, PG, SDK, or compiler checks were run.

Candidate hashes:

- Scanner: `a2f1183beaa1594c452bb17956e29f53030dc3de36ef59f830e82b3e186c08f4`
- Regression test: `7978bfac57646d8675af2e321f5d231ba5825ce79babd546299a6ec7f7b4b8d1`
- Updated privileged check: `1f7081f83a2dfe63b4c76e80e9e83e8852d6b3ec94856542554cf4f8f2541a6a`
- Patch: `474a9a6714e822bc14cd4d96356c67e4db380c7707f114c1f7f77509e4239c8b`
