from pathlib import Path
import subprocess,json,hashlib,sys
main=Path('/workspace/blentera-v10');mirror=Path('/workspace/v10-dep-qualification');candidate=Path(__file__).resolve().parent;out=candidate/'qualification';out.mkdir(exist_ok=False)
parents=json.loads((candidate/'parents.json').read_text());saved={};expected={}
def sha(b):return hashlib.sha256(b).hexdigest()
def step(label,args,cwd=mirror):
 with (out/(label+'.log')).open('wb') as log:r=subprocess.run(args,cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
 (out/(label+'.exit')).write_text(str(r.returncode)+'\n')
 if r.returncode:raise RuntimeError(f'{label} failed: {r.returncode}')
try:
 step('snapshot',['python3','/workspace/v10-preparation/snapshot-current-source-for-dependency-check.py',str(out/'source-pins.json')])
 step('baseline-oxc',['node','/workspace/v10-preparation/check-snapshot-syntax.cjs',str(out/'source-pins.json')])
 for rel,parent in parents.items():
  assert sha((main/rel).read_bytes())==parent,('MAIN parent changed',rel)
  saved[rel]=(mirror/rel).read_bytes();assert sha(saved[rel])==parent,('mirror baseline mismatch',rel)
  b=(candidate/rel).read_bytes();expected[rel]=sha(b);(mirror/rel).write_bytes(b)
 (out/'overlay-pins.json').write_text(json.dumps(expected,indent=2)+'\n')
 step('focused-tests',['../node_modules/.bin/vitest','run','src/__tests__/v7-sandbox-qualification-faults.test.ts','src/__tests__/v7-sandbox-policy.test.ts','--reporter=verbose'],mirror/'server')
 step('server-typecheck',['timeout','300s','node','node_modules/typescript/bin/tsc','--noEmit','--singleThreaded','--incremental','false','-p','tsconfig.json'],mirror/'server')
 (out/'exit').write_text('0\n')
finally:
 rows=[]
 for rel,b in saved.items():
  assert sha((mirror/rel).read_bytes())==expected[rel],('overlay changed during tests',rel)
  (mirror/rel).write_bytes(b);assert (mirror/rel).read_bytes()==b;assert sha((main/rel).read_bytes())==parents[rel],('MAIN changed',rel)
  rows.append({'path':rel,'restoredSha256':sha(b),'candidateSha256':expected[rel]})
 (out/'restore.json').write_text(json.dumps({'files':rows,'restored':True},indent=2)+'\n')
