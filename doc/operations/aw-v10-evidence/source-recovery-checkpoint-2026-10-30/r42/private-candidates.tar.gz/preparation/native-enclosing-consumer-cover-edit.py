# Apply only after Root ends the all-MAIN source freeze.
from pathlib import Path
p=Path('/workspace/blentera-v10/server/src/services/native-direct-input.ts');s=p.read_text()
for name in ['assertNativePayloadSourceSetCurrentInScope', 'assertNativePayloadSourceSetCurrentUncachedInScope']:
 a=s.index('async function '+name+'(');b=s.index('): Promise<void> {',a);chunk=s[a:b]
 needle='siblingToolSourceProofs: NativeSiblingToolSourceProofs = new Map()';assert chunk.count(needle)==1
 chunk=chunk.replace(needle,needle+', consumerCover?: NativePayloadSourceSet',1);s=s[:a]+chunk+s[b:]
a=s.index('async function assertNativePayloadSourceSetCurrentInScope(');b=s.index('\n}\n',a);chunk=s[a:b]
needle='}, scope, true, completedTaskSourceProofs, validatedDispatchSources, siblingToolSourceProofs);';assert chunk.count(needle)==1
chunk=chunk.replace(needle,'}, scope, true, completedTaskSourceProofs, validatedDispatchSources, siblingToolSourceProofs, consumerCover);');s=s[:a]+chunk+s[b:]
a=s.index('      const prefixCoversProof = siblingProof &&');b=s.index('      if (siblingProof && prefixCoversProof',a)
s=s[:a]+'''      // The enclosing saved consumer was already matched against every full
      // original component and its exact ordered union. Component receipt and
      // evidence checks still use input.policy/inputs unchanged.
      const cover = consumerCover ?? { policy: policy.data, inputs: inputs.data };
      const prefixCoversProof = siblingProof && (siblingProof.requiredSets ?? [siblingProof]).every(set =>
        set.inputs.every(required => cover.inputs.some(candidate => isDeepStrictEqual(candidate, required))) &&
        (Object.keys(cover.policy) as (keyof NativePayloadSourcePolicy)[]).every(key =>
          set.policy[key].every(id => cover.policy[key].includes(id))));
'''+s[b:]
a=s.index('async function assertNativeManagedConsumedSourceSetCurrentUncached(');b=s.index('\n}\n',a);chunk=s[a:b]
needle='completedTaskSourceProofs, validatedDispatchSources, siblingToolSourceProofs);';assert chunk.count(needle)==1
chunk=chunk.replace(needle,'completedTaskSourceProofs, validatedDispatchSources, siblingToolSourceProofs, input.sourceSet);',1);s=s[:a]+chunk+s[b:]
p.with_suffix('.consumercover.tmp.ts').write_text(s)
