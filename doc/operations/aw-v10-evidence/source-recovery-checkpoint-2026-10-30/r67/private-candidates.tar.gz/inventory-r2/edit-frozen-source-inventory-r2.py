#!/usr/bin/env python3
"""Apply reviewed existing-owner membership to an exact tracked-clean frozen Git tree.
Writes only a NEW private JSON manifest and adjacent audit receipt; no graph/hash refresh.
"""
import argparse, copy, hashlib, json, subprocess
from pathlib import Path, PurePosixPath

BASE = '81d3445b98b1cd80ff400ede6bd44ea71d88d735'
STATUS = 'e6630ae7f08def7034bdc1fc25fed68a8ea8ce216a9fe9938256a25eae06e19f'
CROSSWALK = 'e5a38122df824b06c9dbc2c2ccf687cd4be004ac390df7081e66460d3664b8bd'
PRIVATE = Path('/workspace/v10-preparation').resolve()
EVIDENCE_PREFIX = 'doc/operations/aw-v10-evidence/'
NEVER_ADDED = 'server/src/__tests__/qualification-fixed-platform-echo.integration.test.ts'
RETIRED = {
    'server/src/services/experience/routine-responsibility-attention.ts',
    'server/src/__tests__/routine-responsibility-attention.integration.test.ts',
    *('packages/db/src/migrations/meta/0%d_snapshot.json' % n for n in range(558, 562)),
}
FIELDS = ('sourcePaths', 'deletedSourcePaths', 'changedSourcePaths', 'dependencyPaths', 'characterizationTests')

def require(ok, reason):
    if not ok:
        raise SystemExit(reason)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def canonical_digest(value):
    return digest(json.dumps(value, sort_keys=True, separators=(',', ':')).encode())

def relative(value):
    p = PurePosixPath(value)
    require(isinstance(value, str) and not p.is_absolute() and str(p) == value and
            '..' not in p.parts and '\\' not in value and '\0' not in value, 'invalid repository path')
    return value

# Existing source-inventory boundary from build-v10-safe-change-inventory-draft-current.py.
# This classifies coverage only; it never assigns a new owner or changes a status.
def relevant(p):
    ext = PurePosixPath(p).suffix
    name = PurePosixPath(p).name
    source_ext = {'.ts', '.tsx', '.js', '.mjs', '.sql', '.yml', '.yaml', '.json', '.sh', '.rs', '.toml', '.py', '.css', '.html', '.svg', '.patch'}
    if name.startswith('Dockerfile') or p in {'.gitattributes', '.gitignore', '.npmrc', '.nvmrc', '.node-version', '.tool-versions'}:
        return True
    if p.startswith('deploy/'):
        return ext in source_ext | {'.conf', '.service', '.timer', '.socket', '.tf', '.tfvars', '.hcl'} or name == 'Caddyfile' or p.endswith('.env.example')
    if p.startswith('doc/operations/') and p.count('/') == 2 and ext == '.json':
        return p not in {'doc/operations/v10-safe-change-graph.source.json', 'doc/operations/v10-safe-change-graph.json'}
    if '/' not in p or p.startswith('patches/'):
        return ext in source_ext
    if p.startswith(('skills/', 'skills-releases/', 'evals/')):
        return ext in source_ext or ext == '.md'
    if ext == '.md':
        return p.startswith(('server/src/onboarding-assets/', 'server/src/built-ins/agents/', 'packages/teams-catalog/')) or (p.startswith('packages/adapters/') and '/skills/' in p)
    return (p.startswith(('server/src/', 'ui/src/', 'ui/public/', 'packages/', 'cli/src/', 'tests/e2e/', 'scripts/', '.github/workflows/', 'third_party/')) and ext in source_ext) or p == 'ui/index.html'

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--frozen-root', type=Path, required=True)
    ap.add_argument('--expected-head', required=True)
    ap.add_argument('--source-manifest', type=Path, required=True)
    ap.add_argument('--expected-manifest-sha256', required=True)
    ap.add_argument('--owner-plan', type=Path, required=True)
    ap.add_argument('--expected-owner-plan-sha256', required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    root = args.frozen_root.resolve(strict=True)
    def git(*argv):
        return subprocess.check_output(['git', *argv], cwd=root, stderr=subprocess.PIPE)
    require(git('rev-parse', '--show-toplevel').decode().strip() == str(root), 'frozen-root must be a Git worktree root')
    named_paths = set()
    def frozen():
        require(git('rev-parse', 'HEAD').decode().strip() == args.expected_head and len(args.expected_head) == 40, 'HEAD is not the exact expected frozen commit')
        untracked_evidence = []
        for entry in git('status', '--porcelain=v1', '-z', '--untracked-files=all').split(b'\0'):
            if not entry:
                continue
            require(entry.startswith(b'?? '), 'freeze required: tracked worktree/index changes remain')
            untracked = entry[3:].decode()
            require(untracked.startswith(EVIDENCE_PREFIX) and untracked not in named_paths,
                    'freeze required: untracked file is outside unrelated evidence allowance or is a named source/input: ' + untracked)
            untracked_evidence.append(untracked)
        return untracked_evidence
    frozen()
    output = args.output.absolute()
    output_parent = output.parent.resolve(strict=True)
    output = output_parent / output.name
    require(output.is_relative_to(PRIVATE) and not output.is_relative_to(root), 'output must be private and outside the frozen worktree')
    for forbidden in (Path('/workspace/blentera-v10').resolve(), Path('/workspace/v10-dep-qualification').resolve()):
        require(not output.is_relative_to(forbidden), 'Main/Mirror output is forbidden')
    receipt_path = output.with_name(output.name + '.receipt.json')
    require(not output.exists() and not output.is_symlink() and not receipt_path.exists() and not receipt_path.is_symlink(), 'private outputs must be new files')
    raw = args.source_manifest.read_bytes(); raw_plan = args.owner_plan.read_bytes()
    require(digest(raw) == args.expected_manifest_sha256, 'source manifest input pin mismatch')
    require(digest(raw_plan) == args.expected_owner_plan_sha256, 'owner plan input pin mismatch')
    before = json.loads(raw); plan = json.loads(raw_plan); after = copy.deepcopy(before)
    require(before['schemaVersion'] == 2 and before['sourceBase']['commitSha'] == BASE, 'source schema/base changed')
    require(canonical_digest(before['requirementsCrosswalk']) == CROSSWALK, 'full historical crosswalk changed')
    records = {v['changeId']: v for v in after['changes']}
    require(len(records) == len(after['changes']) == 50, 'expected exact50 existing groups')
    hotspot_ids = {v['changeId'] for v in before['changes'] if v['recordKind'] == 'production_hotspot_owner_group'}
    require(len(hotspot_ids) == 25, 'expected exact25 existing hotspot groups')
    def tree(ref):
        result = {}
        for item in git('ls-tree', '-r', '-z', ref).split(b'\0'):
            if item:
                meta, name = item.split(b'\t', 1); mode, kind, oid = meta.decode().split()
                result[name.decode()] = (mode, kind, oid)
        return result
    base_tree = tree(BASE); head_tree = tree(args.expected_head)
    historical_path = 'doc/operations/aw-v10-evidence/recovery-2026-10-22/requirement-reconciliation.json'
    historical = json.loads(git('show', args.expected_head + ':' + historical_path))
    statuses = {v['id']: v['reconciliation'] for v in historical['items']}
    require(len(statuses) == 169 and canonical_digest(statuses) == STATUS, '169 historical status map changed')
    removed = RETIRED | {NEVER_ADDED}
    require(all(p not in base_tree and p not in head_tree for p in removed), 'retired/never-added path exists at base or frozen HEAD; review required')
    changed = {p.decode() for p in git('diff', '--no-renames', '--name-only', '-z', BASE, args.expected_head, '--').split(b'\0') if p}
    additions = plan['consolidatedAdditions']
    named_paths.update(p for record in before['changes'] for p in record['sourcePaths'])
    named_paths.update(v['path'] for v in additions)
    named_paths.update(v['path'] for v in before['sourceInputs'])
    named_paths.add(historical_path)
    for named_input in (args.source_manifest, args.owner_plan):
        resolved_input = named_input.resolve()
        if resolved_input.is_relative_to(root):
            named_paths.add(resolved_input.relative_to(root).as_posix())
    frozen()
    for p in named_paths - removed:
        relative(p)
        require(p in head_tree, 'named current source/input is not tracked at frozen HEAD: ' + p)
    expected_additions = plan.get('consolidatedAdditionCount', 53)
    require(type(expected_additions) is int and expected_additions > 0 and len(additions) == expected_additions and len({v['path'] for v in additions}) == expected_additions, 'reviewed owner addition count mismatch')
    for v in additions:
        p = relative(v['path']); owner = v['existingOwnerGroup']
        require(owner in records and p != NEVER_ADDED, 'unknown owner or unpublished copied test')
        require(p in head_tree, 'planned source absent from frozen HEAD: ' + p)
        records[owner]['sourcePaths'] = sorted(set(records[owner]['sourcePaths']) | {p})
    pin_cache = {}
    def pin(p):
        if p not in pin_cache:
            pin_cache[p] = {'path': p, 'baseCommitSha': BASE, 'status': 'present_at_base' if p in base_tree else 'absent_at_base',
                            'sha256': digest(git('cat-file', 'blob', base_tree[p][2])) if p in base_tree else None}
        return pin_cache[p]
    for record in after['changes']:
        originally_retired = set(record['sourcePaths']) & RETIRED
        paths = (set(record['sourcePaths']) | set(record.get('deletedSourcePaths', []))) - removed
        for p in paths:
            relative(p)
            require(p in head_tree or p in base_tree, 'unreviewed absent-at-base retirement: ' + p)
            if p in head_tree:
                require(head_tree[p][0] in ('100644', '100755') and head_tree[p][1] == 'blob', 'source is not a regular tracked blob: ' + p)
        record['sourcePaths'] = sorted(p for p in paths if p in head_tree)
        record['deletedSourcePaths'] = sorted(paths - set(record['sourcePaths']))
        record['changedSourcePaths'] = sorted(paths & changed)
        record['sourceBeforePins'] = [pin(p) for p in sorted(paths)]
        for key in ('dependencyPaths', 'characterizationTests'):
            if key in record:
                record[key] = [p for p in record[key] if p not in removed]
        if originally_retired:
            retirements = {v['path']: v for v in record.get('retiredBranchSourcePaths', [])}
            for p in originally_retired:
                retirements.setdefault(p, {'path': p, 'retirementKind': 'intermediate_migration_snapshot' if '/migrations/meta/' in p else 'superseded_branch_source',
                    'disposition': 'Absent at declared source base and frozen HEAD; historical recovery evidence retained separately. Not a base deletion or current source.'})
            record['retiredBranchSourcePaths'] = [retirements[p] for p in sorted(retirements)]
    covered = {p for r in after['changes'] for p in r['sourcePaths'] + r['deletedSourcePaths']}
    missing = sorted(p for p in changed if relevant(p) and p not in covered)
    require(not missing, 'new source paths lack an explicit reviewed existing owner: ' + json.dumps(missing))
    union_changed = {p for r in after['changes'] for p in r['changedSourcePaths']}
    union_deleted = {p for r in after['changes'] for p in r['deletedSourcePaths']}
    boundary = after['sourceInventoryBoundary']
    expected_keys = {'sourceDeltaPathCount', 'deletedSourcePathCount', 'untrackedSourceCandidateCount', 'ownerGroupCount', 'hotspotRegisterCount', 'requirementCrosswalkCount', 'fullDiffPathCount', 'note'}
    require(set(boundary) == expected_keys, 'sourceInventoryBoundary schema changed')
    boundary.update(sourceDeltaPathCount=len(union_changed), deletedSourcePathCount=len(union_deleted), untrackedSourceCandidateCount=0,
                    ownerGroupCount=50, hotspotRegisterCount=25, requirementCrosswalkCount=169, fullDiffPathCount=len(changed))
    require(after['sourceBase'] == before['sourceBase'] and set(records) == {v['changeId'] for v in before['changes']}, 'base/group identities changed')
    require({v['changeId'] for v in after['changes'] if v['recordKind'] == 'production_hotspot_owner_group'} == hotspot_ids, 'hotspot identities changed')
    require(canonical_digest(after['requirementsCrosswalk']) == CROSSWALK and after['requirementsCrosswalk'] == before['requirementsCrosswalk'], 'crosswalk changed')
    allowed = set(FIELDS) | {'sourceBeforePins', 'retiredBranchSourcePaths'}
    for old, new in zip(before['changes'], after['changes']):
        require({k: v for k, v in old.items() if k not in allowed} == {k: v for k, v in new.items() if k not in allowed}, 'owner metadata/status changed')
    allowed_untracked_evidence = frozen()
    require(digest(args.source_manifest.read_bytes()) == args.expected_manifest_sha256 and digest(args.owner_plan.read_bytes()) == args.expected_owner_plan_sha256, 'input changed during preparation')
    content = (json.dumps(after, indent=2) + '\n').encode()
    receipt = {'scope': 'PRIVATE manifest preparation; no current-source hash generation or acceptance upgrade', 'head': args.expected_head, 'sourceBase': BASE,
               'inputManifestSha256': args.expected_manifest_sha256, 'ownerPlanSha256': args.expected_owner_plan_sha256, 'outputManifestSha256': digest(content),
               'historicalStatusMapSha256': STATUS, 'requirementsCrosswalkSha256': CROSSWALK, 'preservedGroupCount': 50, 'preservedHotspotCount': 25,
               'allowedUntrackedEvidenceCount': len(allowed_untracked_evidence), 'allowedUntrackedEvidencePrefix': EVIDENCE_PREFIX,
               'addedOwnerMemberships': len(additions), 'retiredAbsentAtBase': sorted(RETIRED), 'neverAddedExcluded': NEVER_ADDED, 'sourceInventoryBoundary': boundary}
    # Exclusive creation prevents overwriting any historical private snapshot.
    with output.open('xb') as handle:
        handle.write(content)
    with receipt_path.open('x') as handle:
        json.dump(receipt, handle, indent=2); handle.write('\n')
    print(json.dumps({'output': str(output), 'receipt': str(receipt_path), 'sha256': digest(content)}))

if __name__ == '__main__':
    main()
