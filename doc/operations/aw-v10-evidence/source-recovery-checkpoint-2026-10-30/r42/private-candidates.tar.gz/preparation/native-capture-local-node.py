from pathlib import Path
p=Path('/workspace/blentera-v10/server/src/services/native-direct-input.ts');s=p.read_text()
needle='''  await assertNativeManagedConsumedSourceSetCurrentInScope(db, { companyId, issueId, runId: capture.runId,
      actor, components: capture.consumedSourceComponents, sourceSet: capture.sourceSet }, scope, siblingToolSourceProofs);
  for (const memoryId'''
replacement='''  const captureVisitKey = `capture-node:${nativeSha256({ companyId, issueId, runId: capture.runId,
    actor, actorScope: scope.actorKey, memoryTemporalIdentity: scope.context.memoryTemporalIdentity,
    capture, expectedToolName, conversationState })}`;
  const captureProofKey = `${captureVisitKey}:${depth}`;
  if (scope.active.has(captureVisitKey)) throw forbidden("The Native capture source graph contains a cycle");
  const captureProof = siblingToolSourceProofs.get(captureProofKey);
  const captureProofHit = captureProof &&
    !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, captureProof.descendants);
  addNativeSourceActiveVisit(scope, captureVisitKey);
  let captureProofStack = scope.context.ancestry.frozenTaskProofStacks.get(scope.actorKey);
  if (!captureProofStack) {
    captureProofStack = [];
    scope.context.ancestry.frozenTaskProofStacks.set(scope.actorKey, captureProofStack);
  }
  const captureFrame = { visitKey: captureVisitKey, descendants: new Set<string>() };
  captureProofStack.push(captureFrame);
  let captureCompleted = false;
  try {
  if (captureProofHit) {
    for (const descendant of captureProof.descendants) captureFrame.descendants.add(descendant);
    deferNativeSourceReaderCheck(scope, { companyId, runId: capture.runId, actor,
      policy: capture.sourceSet.policy, inputs: capture.sourceSet.inputs });
  } else {
    await assertNativeManagedConsumedSourceSetCurrentInScope(db, { companyId, issueId, runId: capture.runId,
      actor, components: capture.consumedSourceComponents, sourceSet: capture.sourceSet }, scope, siblingToolSourceProofs);
  }
  for (const memoryId'''
assert s.count(needle)==1;s=s.replace(needle,replacement)
needle='''  deferNativeSourceReaderCheck(scope, { companyId, runId: capture.runId, actor,
    policy: capture.sourceSet.policy, inputs: capture.sourceSet.inputs });
}

/** Revalidate a driver'''
replacement='''  deferNativeSourceReaderCheck(scope, { companyId, runId: capture.runId, actor,
    policy: capture.sourceSet.policy, inputs: capture.sourceSet.inputs });
  captureCompleted = true;
  } finally {
    scope.active.delete(captureVisitKey);
    if (captureProofStack.at(-1) === captureFrame) captureProofStack.pop();
    if (captureCompleted) {
      if (siblingToolSourceProofs.size < 512)
        siblingToolSourceProofs.set(captureProofKey, { descendants: captureFrame.descendants,
          policy: capture.sourceSet.policy, inputs: capture.sourceSet.inputs });
      for (const parent of captureProofStack)
        addNativeFrozenTaskDescendantClosure(parent.descendants, captureVisitKey, captureFrame.descendants);
    }
  }
}

/** Revalidate a driver'''
assert s.count(needle)==1;s=s.replace(needle,replacement)
# Capture hit already pays its entry work1; all output-specific live checks remain below it.
s=s.replace('const nativeSourceMemoDiagnostics = { siblingToolSourceProofHits: 0,','const nativeSourceMemoDiagnostics = { siblingToolSourceProofHits: 0, documentNodeHits: 0, captureNodeHits: 0,\n  workByCaller: {} as Record<string, number>,')
s=s.replace('  nativeSourceMemoDiagnostics.siblingToolSourceProofHits = 0;','  nativeSourceMemoDiagnostics.siblingToolSourceProofHits = 0;\n  nativeSourceMemoDiagnostics.documentNodeHits = 0;\n  nativeSourceMemoDiagnostics.captureNodeHits = 0;\n  nativeSourceMemoDiagnostics.workByCaller = {};')
s=s.replace('''function nativeSourceReadWork(scope: NativeSourceReadScope) {
  if (++scope.context.ancestry.work > 512) {''','''function nativeSourceReadWork(scope: NativeSourceReadScope) {
  if (nativeSourceMemoDiagnosticsEnabled()) {
    const caller = new Error().stack?.split("\\n")[2]?.match(/at ([A-Za-z0-9_.]+) /)?.[1] ?? "source-reader";
    const counts = nativeSourceMemoDiagnostics.workByCaller;
    if (Object.keys(counts).length < 32 || Object.hasOwn(counts, caller))
      counts[caller] = Math.min(1_000_000, (counts[caller] ?? 0) + 1);
  }
  if (++scope.context.ancestry.work > 512) {
    if (nativeSourceMemoDiagnosticsEnabled()) console.error("native_source_bounded_work_counts", JSON.stringify({
      work: scope.context.ancestry.work, counts: nativeSourceMemoDiagnostics.workByCaller,
      toolHits: nativeSourceMemoDiagnostics.siblingToolSourceProofHits,
      documentHits: nativeSourceMemoDiagnostics.documentNodeHits, captureHits: nativeSourceMemoDiagnostics.captureNodeHits }));''')
s=s.replace('''  if (captureProofHit) {
    for (const descendant''','''  if (captureProofHit) {
    if (nativeSourceMemoDiagnosticsEnabled()) nativeSourceMemoDiagnostics.captureNodeHits =
      Math.min(1_000_000, nativeSourceMemoDiagnostics.captureNodeHits + 1);
    for (const descendant''',1)
s=s.replace('''  if (documentProof && !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, documentProof.descendants)) {
    const sourceDispatch''','''  if (documentProof && !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, documentProof.descendants)) {
    if (nativeSourceMemoDiagnosticsEnabled()) nativeSourceMemoDiagnostics.documentNodeHits =
      Math.min(1_000_000, nativeSourceMemoDiagnostics.documentNodeHits + 1);
    const sourceDispatch''',1)
p.with_suffix('.capturenode.tmp.ts').write_text(s)
