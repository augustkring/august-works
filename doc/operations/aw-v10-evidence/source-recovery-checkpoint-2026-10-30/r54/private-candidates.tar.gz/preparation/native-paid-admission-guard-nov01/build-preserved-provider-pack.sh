#!/usr/bin/env bash
set -euo pipefail
REPO=/workspace/blentera-v10
PREP=/workspace/v10-preparation/native-paid-admission-guard-nov01
LOCK=/workspace/v10-preparation/v10-pg-tests.lock
EXPECTED_HEAD=254e5c998c9f41725708a2c8c404078397a3fcac
BUILD_PATH=/tmp/native-paid-admission-provider-pack-build
RUN_DIR="$PREP/provider-pack-build-$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$RUN_DIR"
exec 9>"$LOCK"
flock -x 9
[[ "$(git -C "$REPO" rev-parse HEAD)" == "$EXPECTED_HEAD" ]]
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH npm_config_offline=false npm_config_cache=/tmp/provider-pack-registry-cache-v10 npm_config_optional=true npm_config_include=optional npm_config_store_dir=/workspace/.cloud-setup/pnpm-store
df -B1 /workspace /tmp > "$RUN_DIR/disk-before.txt"
printf '%s\n' "$EXPECTED_HEAD" > "$RUN_DIR/repository-head.txt"
sha256sum "$REPO/pnpm-lock.yaml" "$REPO/packages/paperclip-runner/package.json" "$REPO/packages/paperclip-runner/scripts/build-provider-pack.mjs" > "$RUN_DIR/source-pins.sha256"
rm -rf "$BUILD_PATH"
cd "$REPO"
timeout --signal=TERM --kill-after=10s 480s node packages/paperclip-runner/scripts/build-provider-pack.mjs "$BUILD_PATH" > "$RUN_DIR/build.log" 2>&1
[[ -f "$BUILD_PATH/provider-pack.json" ]]
python3 - "$BUILD_PATH" "$RUN_DIR/provider-pack-receipt.json" <<'PY'
import hashlib,json,os,sys
root,receipt=sys.argv[1:]
manifest=json.load(open(os.path.join(root,'provider-pack.json'),encoding='utf8'))
h=hashlib.sha256()
for current,dirs,files in os.walk(root):
    dirs.sort(); files.sort()
    for name in files:
        path=os.path.join(current,name)
        rel=os.path.relpath(path,root).replace(os.sep,'/')
        if os.path.islink(path): payload=('symlink\0'+rel+'\0'+os.readlink(path)+'\n').encode()
        else: payload=('file\0'+rel+'\0'+hashlib.sha256(open(path,'rb').read()).hexdigest()+'\n').encode()
        h.update(payload)
digest=manifest.get('digest')
assert isinstance(digest,str) and digest.startswith('sha256:')
content_name='paperclip-runner-provider-pack-'+digest.removeprefix('sha256:')[:20]
final='/tmp/'+content_name
if os.path.exists(final):
    old=json.load(open(os.path.join(final,'provider-pack.json'),encoding='utf8'))
    assert old.get('digest')==digest
    import shutil; shutil.rmtree(root)
else:
    os.rename(root,final)
payload=manifest.get('payload',{})
result={'schema':'paperclip.provider-pack-source-pin.v1','path':final,'manifestDigest':digest,
        'runnerSourceRevision':payload.get('runnerSourceRevision'),'distDigest':payload.get('distDigest'),
        'bridgeDigest':payload.get('bridgeDigest'),'target':payload.get('target'),
        'repositoryHead':open(os.path.join(os.path.dirname(receipt),'repository-head.txt')).read().strip(),
        'sourcePinsSha256':open(os.path.join(os.path.dirname(receipt),'source-pins.sha256')).read().splitlines(),
        'packTreeSha256':h.hexdigest(),'packManifestSha256':hashlib.sha256(open(os.path.join(final,'provider-pack.json'),'rb').read()).hexdigest()}
open(receipt,'w',encoding='utf8').write(json.dumps(result,indent=2)+'\n')
print(final)
print(digest)
PY
df -B1 /workspace /tmp > "$RUN_DIR/disk-after.txt"
cat "$RUN_DIR/provider-pack-receipt.json"
