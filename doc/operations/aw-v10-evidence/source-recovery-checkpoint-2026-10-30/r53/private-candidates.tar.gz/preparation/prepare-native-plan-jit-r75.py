from pathlib import Path
import hashlib,json,difflib
r=Path('/workspace/blentera-v10');base=Path('/workspace/v10-preparation/native-envelope-r74-candidate');out=Path('/workspace/v10-preparation/native-plan-jit-r75-candidate');rels=list(json.loads((base/'manifest.json').read_text()))
for rel in rels:
 (out/rel).parent.mkdir(parents=True,exist_ok=True);(out/rel).write_bytes((base/rel).read_bytes())
rel='server/src/services/orchestration/native-tool-boundary.ts';old=(r/rel).read_text();s=old
needle='''  const bound = await scope(db, b);
  if (!bound) return null;
  const [plan] = await db'''
replacement='''  const bound = await scope(db, b);
  if (!bound) return null;
  // The pre/post tool fences read the same large retained-source predicate as
  // Native source scopes. Avoid LLVM startup on this mutation transaction.
  await db.execute(sql`set local jit='off'`);
  const [plan] = await db'''
assert s.count(needle)==1;s=s.replace(needle,replacement,1)
(out/rel).parent.mkdir(parents=True,exist_ok=True);(out/rel).write_text(s);(out/'r75-only.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)));rels.append(rel)
m={}
for rel in rels:
 a=(r/rel).read_bytes();b=(out/rel).read_bytes();m[rel]={'priorSha256':hashlib.sha256(a).hexdigest(),'candidateSha256':hashlib.sha256(b).hexdigest()}
(out/'manifest.json').write_text(json.dumps(m,indent=2));(out/'syntax-pins.json').write_text(json.dumps({'qualificationWorkspace':str(out),'copiedFiles':[{'path':rel} for rel in m]},indent=2))
(out/'deadline-validation-reuse.json').write_text(json.dumps({'attempt':'temporal9-envelope-private-r74-quiet-20261101','result':'12 passed; 6 unrelated skipped','files':{path:m[path] for path in rels if path.startswith('server/src/services/context/')}},indent=2))
p=Path('/workspace/v10-preparation');snapshot=(p/'snapshot-private-native-r74.py').read_text().replace('native-envelope-r74-candidate','native-plan-jit-r75-candidate');(p/'snapshot-private-native-r75.py').write_text(snapshot);runner=(p/'run-private-native-document-r72-quiet.sh').read_text().replace('snapshot-private-native-r72.py','snapshot-private-native-r75.py');(p/'run-private-native-plan-jit-r75-quiet.sh').write_text(runner)
print((out/'r75-only.diff').read_text())
