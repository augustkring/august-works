# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: smoke-lab-p1-p4.spec.ts >> Smoke Lab scenario catalog mirror (P1-P4) >> records the P1-P4 CI-safe Smoke Lab lifecycle into the results API @smoke-lab
- Location: tests/e2e/smoke-lab.shared.ts:316:3

# Error details

```
Error: page.goto: Page crashed
Call log:
  - navigating to "http://127.0.0.1:3199/SMO/activity?action=tool_", waiting until "load"

```

# Test source

```ts
  251 |     priority: number;
  252 |     selectors: Record<string, unknown>;
  253 |   },
  254 | ) {
  255 |   return await json<{ id: string }>(await request.post(`/api/companies/${companyId}/tools/policies`, { data: body }));
  256 | }
  257 | 
  258 | async function approveActionRequest(request: APIRequestContext, companyId: string, actionRequestId: string) {
  259 |   await json(await request.post(`/api/tool-gateway/action-requests/${actionRequestId}/approve`, {
  260 |     data: { companyId },
  261 |   }));
  262 | }
  263 | 
  264 | async function pollTestCall(
  265 |   request: APIRequestContext,
  266 |   connectionId: string,
  267 |   actionRequestId: string,
  268 |   expectedPhase: string,
  269 | ) {
  270 |   for (let i = 0; i < 40; i += 1) {
  271 |     const status = await json<{ phase: string }>(
  272 |       await request.get(`/api/tool-connections/${connectionId}/test-calls/${actionRequestId}`),
  273 |     );
  274 |     if (status.phase === expectedPhase) return status;
  275 |     await new Promise((resolve) => setTimeout(resolve, 250));
  276 |   }
  277 |   throw new Error(`Timed out waiting for test-call ${actionRequestId} phase ${expectedPhase}`);
  278 | }
  279 | 
  280 | async function expectAuditEvent(
  281 |   request: APIRequestContext,
  282 |   companyId: string,
  283 |   options: { connectionId: string; agentId: string; search: string },
  284 | ) {
  285 |   const audit = await json<{ events: Array<Json> }>(
  286 |     await request.get(
  287 |       `/api/tool-gateway/audit?companyId=${companyId}&app=${options.connectionId}&agent=${options.agentId}&search=${encodeURIComponent(options.search)}&limit=50`,
  288 |     ),
  289 |   );
  290 |   expect(audit.events.length, `expected audit/activity row matching ${options.search}`).toBeGreaterThan(0);
  291 | }
  292 | 
  293 | async function createGatewaySession(request: APIRequestContext, companyId: string, scout: Scout): Promise<GatewaySession> {
  294 |   const invoked = await json<{ id: string }>(await request.post(`/api/agents/${scout.id}/heartbeat/invoke`));
  295 |   return await json<GatewaySession>(
  296 |     await request.post("/api/tool-gateway/sessions", {
  297 |       data: { companyId, agentId: scout.id, runId: invoked.id, ttlMs: 60_000 },
  298 |     }),
  299 |   );
  300 | }
  301 | 
  302 | async function gatewayFetch(request: APIRequestContext, path: string, token: string, data?: Json) {
  303 |   const headers = { "x-paperclip-tool-gateway-token": token };
  304 |   if (data) return await request.post(path, { headers, data });
  305 |   return await request.get(path, { headers });
  306 | }
  307 | 
  308 | export const defineSmokeLabSuite = (label: string, scenarios: SmokeLabScenario[]) => test.describe.serial(`Smoke Lab scenario catalog mirror (${label})`, () => {
  309 |   // The lifecycle test walks all CI-safe scenarios and records eight steps per
  310 |   // scenario. Each scenario keeps one representative success screenshot, while
  311 |   // every failed step still captures its own evidence. On a loaded CI runner
  312 |   // the whole walk can take several minutes, so this ceiling keeps enough
  313 |   // headroom for runner variance without slowing a healthy run.
  314 |   test.setTimeout(360_000);
  315 | 
  316 |   test(`records the ${label} CI-safe Smoke Lab lifecycle into the results API @smoke-lab`, async ({ page, request }) => {
  317 |     const seed = await newCompany(request, "catalog");
  318 |     const scout = await createScout(request, seed.companyId);
  319 |     await enableSmokeLab(request);
  320 |     const smokeRun = await createSmokeRun(request, seed.companyId, scenarios.length);
  321 |     const failed: string[] = [];
  322 |     const isPartialRun = scenarios.length < ciSmokeLabScenarios.length;
  323 | 
  324 |     try {
  325 |       await startSmokeLabServices(request, seed.companyId);
  326 | 
  327 |       for (const scenario of scenarios) {
  328 |         const fixtures = await installFixtures(request, seed.companyId);
  329 |         const connection = connectionForScenario(fixtures, scenario);
  330 | 
  331 |         await runRecordedStep(page, request, seed, smokeRun.id, scenario, "connect", async () => {
  332 |           await navigateForEvidence(page, seed, connection.id, scenario);
  333 |           return scenario.lifecycle.connect;
  334 |         }, true);
  335 | 
  336 |         await runRecordedStep(page, request, seed, smokeRun.id, scenario, "discover-catalog", async () => {
  337 |           const discovered = await catalog(request, connection.id);
  338 |           expect(discovered.catalog.map((entry) => entry.toolName)).toContain(scenario.lifecycle.allowedRead.name);
  339 |           return `${scenario.lifecycle.discoverCatalog}: ${discovered.catalog.length} entries`;
  340 |         });
  341 | 
  342 |         await runRecordedStep(page, request, seed, smokeRun.id, scenario, "allowed-read", async () => {
  343 |           const read = await testCall(request, connection.id, scout, scenario.lifecycle.allowedRead);
  344 |           expect(read.decision).toBe("allowed");
  345 |           expect(read.error).toBeUndefined();
  346 |           await expectAuditEvent(request, seed.companyId, {
  347 |             connectionId: connection.id,
  348 |             agentId: scout.id,
  349 |             search: scenario.lifecycle.allowedRead.name,
  350 |           });
> 351 |           await page.goto(`/${seed.prefix}/activity?action=tool_`);
      |                      ^ Error: page.goto: Page crashed
  352 |           return `Allowed read ${scenario.lifecycle.allowedRead.name}`;
  353 |         });
  354 | 
  355 |         await runRecordedStep(page, request, seed, smokeRun.id, scenario, "ask-first-write-approved", async () => {
  356 |           await policy(request, seed.companyId, {
  357 |             name: `${scenario.path} require approval ${Date.now()}`,
  358 |             policyType: "require_approval",
  359 |             priority: 10,
  360 |             selectors: { connectionId: connection.id, toolNames: [scenario.lifecycle.askFirstWrite.name] },
  361 |           });
  362 |           const pending = await testCall(request, connection.id, scout, scenario.lifecycle.askFirstWrite);
  363 |           expect(pending.decision).toBe("ask_first");
  364 |           expect(pending.actionRequestId).toBeTruthy();
  365 |           await page.goto(`/${seed.prefix}/apps/${connection.id}/review`);
  366 |           await approveActionRequest(request, seed.companyId, pending.actionRequestId!);
  367 |           await pollTestCall(request, connection.id, pending.actionRequestId!, "done");
  368 |           return `Approved ask-first call ${scenario.lifecycle.askFirstWrite.name}`;
  369 |         });
  370 | 
  371 |         await runRecordedStep(page, request, seed, smokeRun.id, scenario, "denied-blocked-call", async () => {
  372 |           await policy(request, seed.companyId, {
  373 |             name: `${scenario.path} block ${Date.now()}`,
  374 |             policyType: "block",
  375 |             priority: 1,
  376 |             selectors: { connectionId: connection.id, toolNames: [scenario.lifecycle.deniedCall.name] },
  377 |           });
  378 |           const denied = await testCall(request, connection.id, scout, scenario.lifecycle.deniedCall);
  379 |           expect(denied.decision).toBe("off");
  380 |           expect(denied.error?.reasonCode).toBeTruthy();
  381 |           await page.goto(`/${seed.prefix}/apps/${connection.id}/review`);
  382 |           return `Blocked call ${scenario.lifecycle.deniedCall.name}: ${denied.error?.reasonCode}`;
  383 |         });
  384 | 
  385 |         await runRecordedStep(page, request, seed, smokeRun.id, scenario, "schema-change-quarantine", async () => {
  386 |           if (connection.transport !== "mcp_remote") {
  387 |             await page.goto(`/${seed.prefix}/activity?action=tool_`);
  388 |             return "Non-HTTP path records governance/quarantine evidence through fixture metadata.";
  389 |           }
  390 |           await json<ToolConnection>(await request.patch(`/api/tool-connections/${connection.id}`, {
  391 |             data: { config: { ...(connection.config ?? {}), quarantineNewEntries: true } },
  392 |           }));
  393 |           await policy(request, seed.companyId, {
  394 |             name: `${scenario.path} allow schema flip ${Date.now()}`,
  395 |             policyType: "allow",
  396 |             priority: 5,
  397 |             selectors: { connectionId: connection.id, toolNames: [scenario.lifecycle.schemaChangeQuarantine.name] },
  398 |           });
  399 |           const flipped = await testCall(request, connection.id, scout, scenario.lifecycle.schemaChangeQuarantine);
  400 |           expect(flipped.decision).toBe("allowed");
  401 |           expect(flipped.error).toBeUndefined();
  402 |           const refresh = await json<{ quarantinedCount: number }>(
  403 |             await request.post(`/api/tool-connections/${connection.id}/catalog/refresh`),
  404 |           );
  405 |           expect(refresh.quarantinedCount).toBeGreaterThan(0);
  406 |           await page.goto(`/${seed.prefix}/apps/connections`);
  407 |           return `Catalog refresh quarantined ${refresh.quarantinedCount} changed entries.`;
  408 |         });
  409 | 
  410 |         await runRecordedStep(page, request, seed, smokeRun.id, scenario, "revoke", async () => {
  411 |           if (scenario.transport === "gateway_session") {
  412 |             const session = await createGatewaySession(request, seed.companyId, scout);
  413 |             const listed = await gatewayFetch(request, session.toolsUrl, session.token);
  414 |             expect(listed.ok()).toBe(true);
  415 |             await json(await request.post(`/api/tool-gateway/sessions/${session.sessionId}/revoke`, {
  416 |               data: { companyId: seed.companyId },
  417 |             }));
  418 |             await expectError(await gatewayFetch(request, session.toolsUrl, session.token), 401);
  419 |             await page.goto(`/${seed.prefix}/activity?action=tool_`);
  420 |             return scenario.lifecycle.revoke;
  421 |           }
  422 |           const disabled = await json<ToolConnection>(await request.patch(`/api/tool-connections/${connection.id}`, {
  423 |             data: { enabled: false },
  424 |           }));
  425 |           expect(disabled.enabled).toBe(false);
  426 |           await page.goto(`/${seed.prefix}/apps/${connection.id}`);
  427 |           await json<ToolConnection>(await request.patch(`/api/tool-connections/${connection.id}`, {
  428 |             data: { enabled: true },
  429 |           }));
  430 |           return scenario.lifecycle.revoke;
  431 |         });
  432 | 
  433 |         await runRecordedStep(page, request, seed, smokeRun.id, scenario, "audit-evidence", async () => {
  434 |           await expectAuditEvent(request, seed.companyId, {
  435 |             connectionId: connection.id,
  436 |             agentId: scout.id,
  437 |             search: scenario.lifecycle.allowedRead.name,
  438 |           });
  439 |           await page.goto(`/${seed.prefix}/activity?action=tool_`);
  440 |           return scenario.lifecycle.auditEvidence;
  441 |         });
  442 |       }
  443 |     } catch (error) {
  444 |       failed.push(error instanceof Error ? error.message : String(error));
  445 |       throw error;
  446 |     } finally {
  447 |       await updateSmokeRun(request, seed.companyId, smokeRun.id, failed.length > 0 ? "failed" : "passed", {
  448 |         catalog: "tests/e2e/smoke-lab.catalog.ts",
  449 |         scenarioCount: scenarios.length,
  450 |         catalogScenarioCount: ciSmokeLabScenarios.length,
  451 |         partial: isPartialRun,
```