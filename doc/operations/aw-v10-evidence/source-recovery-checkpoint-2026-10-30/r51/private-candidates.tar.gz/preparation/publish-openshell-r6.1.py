from pathlib import Path
import json,hashlib,shutil,subprocess
root=Path('/workspace/blentera-v10');src=Path('/workspace/v10-preparation/openshell-rt01-repo-integration-candidate-r6');prefix='third_party/openshell/rt01/'
old=json.loads((root/(prefix+'source-pins.json')).read_text());new=json.loads((src/(prefix+'source-pins.json')).read_text())
assert old['patch']['sha256']=='9181ed297038877322ddb11991f819c4609d25205cf0905b8356447bb48383d5'
assert new['patch']['sha256']=='c5571c1418ccc23866b399682b4d9f6f48242103970bffb470c8c45b968c810b'
assert old['files'].keys()==new['files'].keys()
assert [p for p in old['files'] if old['files'][p]!=new['files'][p]]==['crates/openshell-driver-docker/src/lib.rs','crates/openshell-driver-docker/src/tests.rs']
assert hashlib.sha256((src/new['patch']['path']).read_bytes()).hexdigest()==new['patch']['sha256']
assert hashlib.sha256((src/(prefix+'source-pins.json')).read_bytes()).hexdigest()=='4b644b8cdbded54775f229dbccb5c75f9df919819e17a7502556cdba2587822e'
paths=[prefix+name for name in ['openshell-rt01.patch','source-pins.json','metadata.json','README.md']]
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--',*paths],cwd=root).strip()
for rel in paths:shutil.copy2(src/rel,root/rel)
subprocess.run(['git','diff','--check','--',*paths],cwd=root,check=True);subprocess.run(['git','add','--',*paths],cwd=root,check=True);subprocess.run(['git','commit','-m','fix: use pinned Docker log configuration model in OpenShell guard patch [skip ci]'],cwd=root,check=True)
