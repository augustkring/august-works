import ast,fcntl,gzip,hashlib,json,os,pathlib,signal,subprocess,time
root=pathlib.Path('/workspace/blentera-v10');prep=pathlib.Path('/workspace/v10-preparation');out=prep/'combined-b1-final-metadata-20261103';tmp=pathlib.Path('/tmp/combined-b1-final-metadata-20261103');work=tmp/'worktree';q=out/'qualification';q.mkdir(exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();node='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
p=json.loads((out/'preparation-proof.json').read_bytes());env={**os.environ,**p['alternateGitEnvironment'],'NODE_OPTIONS':'--max-old-space-size=128'};sourceManifest=json.loads((prep/'combined-b1-reviewed-source-20261103/source-manifest.json').read_bytes());changed=set(p['uniqueMetadataFiles'])|{r['path'] for r in sourceManifest['files']}
def mainstate():
 index=pathlib.Path(subprocess.check_output(['git','rev-parse','--path-format=absolute','--git-path','index'],cwd=root,text=True).strip());return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'indexSha256':sha(index.read_bytes()),'refsSha256':sha(subprocess.check_output(['git','show-ref','--head'],cwd=root)),'trackedStatus':subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root,text=True)}
def events():return dict(x.split() for x in pathlib.Path('/sys/fs/cgroup/memory.events').read_text().splitlines())
def free(path):s=os.statvfs(path);return s.f_bavail*s.f_frsize//1024
def headroom():return int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text())-int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text())
lock=open('/workspace/v10-preparation/v10-pg-tests.lock','a');startwait=time.monotonic()
while True:
 try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);break
 except BlockingIOError:
  if time.monotonic()-startwait>60:raise RuntimeError('Canonical flock wait exceeds60seconds')
  time.sleep(.1)
assert free('/workspace')>=120000 and free('/tmp')>=1048576 and headroom()>=512*1024*1024
originalmain=mainstate();initial=events();results=[]
# Pin every actual real file in this bounded read tree, omitting dependency links.
def pins():
 result={}
 for directory,dirs,files in os.walk(work,followlinks=False):
  dirs[:]=[d for d in dirs if d!='node_modules' and not (pathlib.Path(directory)/d).is_symlink()]
  for name in files:
   path=pathlib.Path(directory)/name
   if not path.is_symlink():result[str(path.relative_to(work))]=sha(path.read_bytes())
 return result
before=pins();(q/'input-pins.json.gz').write_bytes(gzip.compress((json.dumps(before,indent=2)+'\n').encode(),mtime=0))
commands=[('generate-capability',['cli/node_modules/tsx/dist/cli.mjs','scripts/generate-v10-capability-projection.ts'],0),('generate-safe-change',['scripts/generate-v10-safe-change-graph.mjs'],0),('capability-check',['scripts/check-v10-capability-projection.mjs'],0),('safe-change-check',['scripts/check-v10-safe-change-graph.mjs'],0),('phase-check',['scripts/check-v10-169-migration-phase-register.mjs'],0),('phase-six-regressions',['--test','--test-concurrency=1','scripts/check-v10-169-migration-phase-register.test.mjs'],0),('help-pure-current-source-validation',[str(out/'check-help-overlay.mjs')],0),('alias-check',['scripts/check-agent-native-tool-alias-compatibility.mjs'],0),('alias-negative-regressions',['--test','--test-concurrency=1','scripts/check-agent-native-tool-alias-compatibility.test.mjs'],0),('help-and-product-negative-controls',['--test','--test-concurrency=1','scripts/check-help-change-review.test.mjs','scripts/check-v10-security-fast-path.test.mjs','scripts/check-v10-security-regression-execution.test.mjs','scripts/v10-product-artifacts.test.mjs'],0)]
for label,args,expected in commands:
 assert free('/workspace')>=120000 and free('/tmp')>=1048576 and headroom()>=512*1024*1024
 start=time.monotonic();peak=0;stopped=None;cmd=[node,'--max-old-space-size=128',*args]
 with (q/(label+'.log')).open('wb') as log:
  proc=subprocess.Popen(cmd,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  while proc.poll() is None:
   rss=0
   for item in pathlib.Path('/proc').iterdir():
    if not item.name.isdigit():continue
    try:
     f=(item/'stat').read_text().rsplit(')',1)[1].split()
     if int(f[2])==proc.pid:rss+=int(f[21])*os.sysconf('SC_PAGE_SIZE')//1024
    except (OSError,ValueError,IndexError):pass
   peak=max(peak,rss)
   if rss>256*1024:stopped='RSS group cap'
   elif time.monotonic()-start>60:stopped='deadline'
   elif events()!=initial:stopped='memory event changed'
   if stopped:os.killpg(proc.pid,signal.SIGKILL);break
   time.sleep(.025)
  code=proc.wait()
 (q/(label+'.exit')).write_text(str(code)+'\n');row={'label':label,'command':cmd,'actualExitCode':code,'seconds':time.monotonic()-start,'peakProcessGroupRssKiB':peak,'stopped':stopped};results.append(row);(q/'progress.json').write_text(json.dumps({'results':results,'memoryBefore':initial,'memoryCurrent':events()},indent=2)+'\n')
 if code!=expected:print(json.dumps(row));raise SystemExit(1)
 # Stage actual generated/private bytes into the genuine alternate index only.
 if label=='generate-safe-change':
  for path in sorted(changed):
   blob=subprocess.check_output(['git','hash-object','-w','--stdin'],cwd=work,env=env,input=(work/path).read_bytes()).decode().strip();subprocess.run(['git','update-index','--add','--cacheinfo','100644',blob,path],cwd=work,env=env,check=True)
  actual=set(subprocess.check_output(['git','diff','--cached','--name-only','81d3445b98b1cd80ff400ede6bd44ea71d88d735'],cwd=work,env=env,text=True).splitlines());builder=pathlib.Path('/workspace/v10-preparation/build-v10-safe-change-inventory-draft-current.py').read_text();ns={'os':os,'source_ext':{'.ts','.tsx','.js','.mjs','.sql','.yml','.yaml','.json','.sh','.rs','.toml','.py','.css','.html','.svg','.patch'}}
  for n in ast.parse(builder).body:
   if isinstance(n,ast.FunctionDef) and n.name=='relevant':exec(compile(ast.Module(body=[n],type_ignores=[]),'<reviewed-source-filter>','exec'),ns)
  material={x for x in actual if ns['relevant'](x)};manifest=json.loads((work/'doc/operations/v10-safe-change-graph.source.json').read_bytes());mapped={x for g in manifest['changes'] for x in g['changedSourcePaths']};assert material==mapped and len(material)==1939
  (q/'alternate-index-proof.json').write_text(json.dumps({'actualIndexTree':subprocess.check_output(['git','write-tree'],cwd=work,env=env,text=True).strip(),'actualMaterialSourcePaths':len(material),'everyActualMaterialPathMapped':True,'sourceCountIs1939NotStale1934':True,'mainGitObjectsNotWritten':True,'objectDirectory':env['GIT_OBJECT_DIRECTORY'],'mainStateUnchanged':mainstate()==originalmain},indent=2)+'\n')
after=pins();expectedchanges={'doc/operations/v10-safe-change-graph.json'};delta={k for k in before if before[k]!=after[k]};assert delta<=expectedchanges,delta
assert mainstate()==originalmain;assert events()==initial
(q/'output-pins.json.gz').write_bytes(gzip.compress((json.dumps(after,indent=2)+'\n').encode(),mtime=0));receipt={'baseHead':originalmain['head'],'scope':'Exact composed source28 and approved metadata; original generators/checkers/tests, genuine alternate index/object store and private real read tree. Help uses its original pure validation interface over actual private bytes, not a fabricated Git HEAD. No SDK, PG, runtime or release qualification.','mainBefore':originalmain,'mainAfter':mainstate(),'allInputPinsUnchangedExceptExpectedGeneratedGraph':True,'actualReadTreeFiles':len(before),'generatedChanges':sorted(delta),'memoryBefore':initial,'memoryAfter':events(),'rootFreeKiB':free('/workspace'),'heapMiB':128,'groupRssCapMiB':256,'deadlineSeconds':60,'results':results};(q/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
