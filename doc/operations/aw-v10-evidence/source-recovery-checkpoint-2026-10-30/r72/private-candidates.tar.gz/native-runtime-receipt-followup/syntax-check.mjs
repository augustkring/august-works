import { and, asc, desc, eq, inArray, isNull, sql } from "drizzle-orm";
import { environmentLeases, heartbeatRunEvents, heartbeatRuns, runtimeHostCommands } from "@paperclipai/db";
import { appendHeartbeatRunEvent } from "./heartbeat-run-events.js";
import { nativeSha256 } from "./native-runtime/canonical.js";
const NATIVE_REMOTE_WORKLOAD_STOPPED = "native.remote_workload_stopped";
function remoteTerminationReceipt(lease, value) {
  const receipt = value;
  if (!lease.heartbeatRunId || !lease.provider || lease.provider === "local" || !lease.providerLeaseId || receipt?.providerLeaseId !== lease.providerLeaseId || !["stopped", "destroyed"].includes(String(receipt?.state))) return void 0;
  return {
    schema: "paperclip.remote-termination.v1",
    companyId: lease.companyId,
    runId: lease.heartbeatRunId,
    leaseId: lease.id,
    provider: lease.provider,
    providerLeaseId: lease.providerLeaseId,
    state: receipt.state,
    confirmedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}
async function currentRemoteTerminationReceipt(db, lease, value) {
  const [run] = lease.heartbeatRunId ? await db.select().from(heartbeatRuns).where(and(
    eq(heartbeatRuns.companyId, lease.companyId),
    eq(heartbeatRuns.id, lease.heartbeatRunId)
  )) : [];
  if (run?.runnerProfileJson && typeof run.runnerProfileJson === "object" && !Array.isArray(run.runnerProfileJson) && run.runnerProfileJson.nativeRemoteRuntimeAssetLocator !== void 0) {
    const { verifyNativeCleanupRuntimeState } = await import("./execution-sandbox/run-lease-cleanup.js");
    return await verifyNativeCleanupRuntimeState(db, { companyId: run.companyId, runId: run.id, leaseId: lease.id }, value);
  }
  return remoteTerminationReceipt(lease, value);
}
function hasRemoteTerminationReceipt(lease) {
  const receipt = lease.metadata?.remoteExecutionTermination;
  return Boolean(lease.releasedAt && lease.cleanupStatus === "success" && ["released", "expired", "failed"].includes(lease.status) && receipt && receipt.schema === "paperclip.remote-termination.v1" && receipt.companyId === lease.companyId && receipt.runId === lease.heartbeatRunId && receipt.leaseId === lease.id && receipt.provider === lease.provider && remoteTerminationReceipt(lease, receipt));
}
function remoteLeaseCleanupScope(lease) {
  return lease.provider && lease.provider !== "local" && lease.providerLeaseId ? JSON.stringify([lease.provider, lease.providerLeaseId]) : void 0;
}
async function stoppedRemoteCleanupScopes(db, companyId, runId) {
  const leases = await db.select().from(environmentLeases).where(and(
    eq(environmentLeases.companyId, companyId),
    eq(environmentLeases.heartbeatRunId, runId)
  ));
  if (leases.length === 0 || !leases.every(hasRemoteTerminationReceipt)) return null;
  const [run] = await db.select().from(heartbeatRuns).where(and(
    eq(heartbeatRuns.companyId, companyId),
    eq(heartbeatRuns.id, runId)
  ));
  if (run?.runnerProfileJson && typeof run.runnerProfileJson === "object" && !Array.isArray(run.runnerProfileJson) && run.runnerProfileJson.nativeRemoteRuntimeAssetLocator !== void 0) {
    if (!await verifiedNativeRemoteStopProofs(db, { companyId, runId }, run, leases)) return null;
  }
  return [...new Set(leases.map((lease) => remoteLeaseCleanupScope(lease)))];
}
async function remoteExecutionHasStopped(db, companyId, runId) {
  return await stoppedRemoteCleanupScopes(db, companyId, runId) !== null;
}
async function readNativeRemoteWorkloadIntent(db, input) {
  const [launch] = await db.select({
    id: heartbeatRunEvents.id,
    seq: heartbeatRunEvents.seq,
    createdAt: heartbeatRunEvents.createdAt
  }).from(heartbeatRunEvents).where(and(
    eq(heartbeatRunEvents.companyId, input.companyId),
    eq(heartbeatRunEvents.runId, input.runId),
    eq(heartbeatRunEvents.agentId, input.agentId),
    isNull(heartbeatRunEvents.sourceEventId),
    inArray(heartbeatRunEvents.eventType, ["native.process_start_requested", "native.process_identity_recorded"])
  )).orderBy(desc(heartbeatRunEvents.seq)).limit(1);
  if (!launch || !Number.isSafeInteger(launch.id) || launch.id < 1 || !Number.isSafeInteger(launch.seq) || launch.seq < 1) return null;
  return { eventId: String(launch.id), seq: String(launch.seq), createdAt: launch.createdAt.toISOString() };
}
async function verifiedNativeRemoteStopProofs(db, input, run, leases) {
  if (run.runtimeMode !== "native" || !run.runnerProfileJson?.nativeRemoteRuntimeAssetLocator || !leases.length || leases.some((lease) => !lease.provider || lease.provider === "local" || !hasRemoteTerminationReceipt(lease))) return null;
  const launch = await readNativeRemoteWorkloadIntent(db, { companyId: input.companyId, runId: input.runId, agentId: run.agentId });
  if (!launch) return null;
  const { verifyRunLeaseCleanupReceipt } = await import("./execution-sandbox/run-lease-cleanup.js");
  const proofs = [];
  try {
    for (const lease of leases) {
      const verified = await verifyRunLeaseCleanupReceipt(
        db,
        { companyId: input.companyId, runId: input.runId, leaseId: lease.id },
        lease.metadata?.remoteExecutionTermination
      );
      const proof = verified.sandboxStop;
      const afterIntent = sql`(select e.created_at from heartbeat_run_events e where e.id=${launch.eventId}::bigint
        and e.company_id=${input.companyId}::uuid and e.run_id=${input.runId}::uuid
        and e.agent_id=${run.agentId}::uuid and e.source_event_id is null)`;
      const currentProofs = await db.select({ id: runtimeHostCommands.id }).from(runtimeHostCommands).where(and(
        eq(runtimeHostCommands.companyId, input.companyId),
        eq(runtimeHostCommands.status, "SUCCEEDED"),
        inArray(runtimeHostCommands.id, [proof.stopCommandId, proof.inspectCommandId]),
        sql`${runtimeHostCommands.createdAt} > ${afterIntent}`,
        sql`${runtimeHostCommands.completedAt} > ${afterIntent}`
      ));
      if (currentProofs.length !== 2) return null;
      proofs.push({
        leaseId: lease.id,
        stopCommandId: proof.stopCommandId,
        inspectCommandId: proof.inspectCommandId,
        receiptDigest: nativeSha256(verified)
      });
    }
  } catch {
    return null;
  }
  const currentIntent = await readNativeRemoteWorkloadIntent(db, {
    companyId: input.companyId,
    runId: input.runId,
    agentId: run.agentId
  });
  if (!currentIntent || currentIntent.eventId !== launch.eventId || currentIntent.seq !== launch.seq || currentIntent.createdAt !== launch.createdAt) return null;
  return { launch, proofs };
}
async function recordNativeRemoteWorkloadStopped(db, input) {
  return await db.transaction(async (rawTx) => {
    const tx = rawTx;
    const [run] = await tx.select().from(heartbeatRuns).where(and(
      eq(heartbeatRuns.companyId, input.companyId),
      eq(heartbeatRuns.id, input.runId)
    )).for("update");
    const locator = run?.runnerProfileJson?.nativeRemoteRuntimeAssetLocator;
    if (!run || run.runtimeMode !== "native" || !locator) return false;
    const leases = await tx.select().from(environmentLeases).where(and(
      eq(environmentLeases.companyId, input.companyId),
      eq(environmentLeases.heartbeatRunId, input.runId)
    )).orderBy(asc(environmentLeases.id)).for("update");
    const current = await verifiedNativeRemoteStopProofs(tx, input, run, leases);
    if (!current) return false;
    const { launch, proofs } = current;
    const [latest] = await tx.select({ eventType: heartbeatRunEvents.eventType }).from(heartbeatRunEvents).where(and(
      eq(heartbeatRunEvents.companyId, input.companyId),
      eq(heartbeatRunEvents.runId, input.runId),
      eq(heartbeatRunEvents.agentId, run.agentId),
      isNull(heartbeatRunEvents.sourceEventId),
      inArray(heartbeatRunEvents.eventType, [
        "native.process_start_requested",
        "native.process_identity_recorded",
        "native.local_process_stopped",
        NATIVE_REMOTE_WORKLOAD_STOPPED
      ])
    )).orderBy(desc(heartbeatRunEvents.seq)).limit(1);
    if (latest?.eventType === NATIVE_REMOTE_WORKLOAD_STOPPED && run.nativeProcessCleanupPending === false) return true;
    await appendHeartbeatRunEvent(tx, {
      companyId: input.companyId,
      runId: input.runId,
      agentId: run.agentId,
      eventType: NATIVE_REMOTE_WORKLOAD_STOPPED,
      stream: "system",
      level: "info",
      message: "Native verified the remote workload stopped.",
      payload: {
        locatorDigest: nativeSha256(locator),
        leases: proofs,
        launchIntent: launch
      }
    });
    return true;
  });
}
export {
  NATIVE_REMOTE_WORKLOAD_STOPPED,
  currentRemoteTerminationReceipt,
  hasRemoteTerminationReceipt,
  readNativeRemoteWorkloadIntent,
  recordNativeRemoteWorkloadStopped,
  remoteExecutionHasStopped,
  remoteLeaseCleanupScope,
  remoteTerminationReceipt,
  stoppedRemoteCleanupScopes
};
