#!/usr/bin/env bash
set -uo pipefail
NAME=v10-069-private-r4-ui-publication-attempt3-20261030
OUT=/workspace/v10-preparation/$NAME
REPO=/workspace/blentera-v10
CAND=/workspace/v10-preparation/v10-069-private-candidate-r4
MIRROR=/workspace/v10-dep-qualification
SOURCE_OVERLAY_ACTIVE=0
OUTPUT_BACKUP_READY=0
mkdir -m 700 "$OUT" || exit 73
exec 9>/workspace/v10-preparation/v10-pg-tests.lock
flock -x 9
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH

restore_sources() {
  python3 - "$OUT" "$CAND" "$MIRROR" <<'PY'
import hashlib,sys
from pathlib import Path
out,cand,mirror=map(Path,sys.argv[1:])
candidate={}
baseline={}
for line in (cand/'candidate-source-pins.sha256').read_text().splitlines():
    h,rel=line.split(None,1); candidate[rel.strip()]=h
for line in (out/'mirror-baseline-pins.sha256').read_text().splitlines():
    h,rel=line.split(None,1); baseline[rel.strip()]=h
if set(candidate)!=set(baseline): raise SystemExit('source path sets differ')
actual={rel:hashlib.sha256((mirror/rel).read_bytes()).hexdigest() for rel in candidate}
for rel,h in actual.items():
    if h not in (candidate[rel],baseline[rel]): raise SystemExit(f'refusing changed mirror path {rel}: {h}')
for rel,h in actual.items():
    if h==candidate[rel] and candidate[rel]!=baseline[rel]: (mirror/rel).write_bytes((out/'mirror-baseline'/rel).read_bytes())
for rel,want in baseline.items():
    got=hashlib.sha256((mirror/rel).read_bytes()).hexdigest()
    if got!=want: raise SystemExit(f'source restore mismatch {rel}: {got}')
print(f'source restore verified: {len(baseline)} paths')
PY
}

restore_outputs() {
  [[ "$OUTPUT_BACKUP_READY" == 1 ]] || return 0
  rm -rf "$MIRROR/packages/db/dist" "$MIRROR/packages/shared/dist" "$MIRROR/ui/dist"
  cp -a "$OUT/compiled-baseline/packages/db/dist" "$MIRROR/packages/db/dist"
  cp -a "$OUT/compiled-baseline/packages/shared/dist" "$MIRROR/packages/shared/dist"
  cp -a "$OUT/compiled-baseline/ui/dist" "$MIRROR/ui/dist"
  for d in packages/db packages/shared ui; do
    find "$MIRROR/$d" -maxdepth 1 -type f -name '*.tsbuildinfo' -delete
    find "$OUT/compiled-baseline/$d" -maxdepth 1 -type f -name '*.tsbuildinfo' -exec cp -a '{}' "$MIRROR/$d/" \;
  done
  (cd "$MIRROR" && find packages/db/dist packages/shared/dist ui/dist -type f -print0 | sort -z | xargs -0 sha256sum) > "$OUT/compiled-output-restored.sha256"
  cmp "$OUT/compiled-output-baseline.sha256" "$OUT/compiled-output-restored.sha256" || return 1
  OUTPUT_BACKUP_READY=0
}

cleanup() {
  local rc=0
  if (( SOURCE_OVERLAY_ACTIVE )); then restore_sources >> "$OUT/cleanup.log" 2>&1 || rc=1; fi
  if (( OUTPUT_BACKUP_READY )); then restore_outputs >> "$OUT/cleanup.log" 2>&1 || rc=1; fi
  echo "$rc" > "$OUT/cleanup.exit"
  return "$rc"
}
trap cleanup EXIT INT TERM

cd "$REPO" || exit 70
sha256sum -c "$CAND/baseline-source-pins.sha256" > "$OUT/main-baseline-guard.log" 2>&1 || { echo 73 > "$OUT/exit"; exit 73; }
python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$OUT/source-pins.json" > "$OUT/snapshot.log" 2>&1
snapshot_rc=$?; echo "$snapshot_rc" > "$OUT/snapshot.exit"
if (( snapshot_rc )); then echo "$snapshot_rc" > "$OUT/exit"; exit "$snapshot_rc"; fi
python3 - "$REPO" "$MIRROR" "$OUT/source-pins.json" <<'PY' > "$OUT/r5-module-guard.log" 2>&1
import hashlib,json,sys
from pathlib import Path
repo,mirror,pins=map(Path,sys.argv[1:])
rel='server/src/services/experience/private-0565/member-continuity-preflight.ts'
want='792f451a52cffd83550105c371e281c999c699ffaf792076d6756f13a3bc0daf'
rows=json.loads(pins.read_text())['copiedFiles']; row=next((r for r in rows if r.get('path')==rel),None)
assert (repo/rel).is_file() and hashlib.sha256((repo/rel).read_bytes()).hexdigest()==want
assert (mirror/rel).is_file() and hashlib.sha256((mirror/rel).read_bytes()).hexdigest()==want
assert row and row['sha256']==want
print(f'R5 module verified {want}')
PY
r5_rc=$?; echo "$r5_rc" > "$OUT/r5-module-guard.exit"
if (( r5_rc )); then echo 75 > "$OUT/exit"; exit 75; fi

mkdir -p "$OUT/mirror-baseline" "$OUT/compiled-baseline/packages/db" "$OUT/compiled-baseline/packages/shared" "$OUT/compiled-baseline/ui"
python3 - "$OUT" "$CAND" "$MIRROR" <<'PY'
import hashlib,json,sys
from pathlib import Path
out,cand,mirror=map(Path,sys.argv[1:])
paths=[x.strip() for x in (cand/'owned-files.txt').read_text().splitlines() if x.strip()]
rows=[]; copied=[]
for rel in paths:
    src=mirror/rel; data=src.read_bytes(); h=hashlib.sha256(data).hexdigest()
    rows.append(f'{h}  {rel}\n')
    dest=out/'mirror-baseline'/rel; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(data)
    copied.append({'path':rel,'sha256':h})
(out/'mirror-baseline-pins.sha256').write_text(''.join(rows))
pins=json.loads((out/'source-pins.json').read_text())['copiedFiles']
source={r['path']:r['sha256'] for r in pins}
for row in copied:
    if source.get(row['path'])!=row['sha256']: raise SystemExit(f"snapshot/source mismatch {row['path']}")
for want,rel in (line.split(None,1) for line in (cand/'baseline-source-pins.sha256').read_text().splitlines()):
    if hashlib.sha256((mirror/rel).read_bytes()).hexdigest()!=want: raise SystemExit(f'baseline mismatch {rel}')
PY
capture_rc=$?; echo "$capture_rc" > "$OUT/mirror-baseline-guard.exit"
if (( capture_rc )); then echo 74 > "$OUT/exit"; exit 74; fi

cp -a "$MIRROR/packages/db/dist" "$OUT/compiled-baseline/packages/db/dist"
cp -a "$MIRROR/packages/shared/dist" "$OUT/compiled-baseline/packages/shared/dist"
cp -a "$MIRROR/ui/dist" "$OUT/compiled-baseline/ui/dist"
for d in packages/db packages/shared ui; do
  find "$MIRROR/$d" -maxdepth 1 -type f -name '*.tsbuildinfo' -exec cp -a '{}' "$OUT/compiled-baseline/$d/" \;
done
(cd "$MIRROR" && find packages/db/dist packages/shared/dist ui/dist -type f -print0 | sort -z | xargs -0 sha256sum) > "$OUT/compiled-output-baseline.sha256"
OUTPUT_BACKUP_READY=1

SOURCE_OVERLAY_ACTIVE=1
python3 - "$CAND" "$MIRROR" "$OUT" <<'PY'
import hashlib,json,sys
from pathlib import Path
cand,mirror,out=map(Path,sys.argv[1:])
paths=[x.strip() for x in (cand/'owned-files.txt').read_text().splitlines() if x.strip()]
rows=[]
for rel in paths:
    data=(cand/'candidate-files'/rel).read_bytes(); target=mirror/rel; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(data)
    rows.append({'path':rel,'sha256':hashlib.sha256(data).hexdigest()})
out.joinpath('overlay-pins.json').write_text(json.dumps({'qualificationWorkspace':str(mirror),'copiedFiles':rows},indent=2)+'\n')
PY
overlay_rc=$?; echo "$overlay_rc" > "$OUT/overlay.exit"
if (( overlay_rc )); then echo 1 > "$OUT/exit"; exit 1; fi
node /workspace/v10-preparation/check-snapshot-syntax.cjs "$OUT/overlay-pins.json" > "$OUT/oxc.log" 2>&1
oxc_rc=$?; echo "$oxc_rc" > "$OUT/oxc.exit"
if (( oxc_rc )); then echo "$oxc_rc" > "$OUT/exit"; exit "$oxc_rc"; fi

timeout 240s pnpm --dir "$MIRROR/packages/db" build > "$OUT/db-build.log" 2>&1
db_rc=$?; echo "$db_rc" > "$OUT/db-build.exit"
timeout 240s pnpm --dir "$MIRROR/packages/shared" build > "$OUT/shared-build.log" 2>&1
shared_rc=$?; echo "$shared_rc" > "$OUT/shared-build.exit"
if (( db_rc || shared_rc )); then echo 1 > "$OUT/exit"; exit 1; fi
timeout 600s pnpm --dir "$MIRROR/ui" typecheck > "$OUT/ui-typecheck.log" 2>&1
ui_rc=$?; echo "$ui_rc" > "$OUT/ui-typecheck.exit"
printf 'db_build=%s shared_build=%s ui_typecheck=%s oxc=%s\n' "$db_rc" "$shared_rc" "$ui_rc" "$oxc_rc" > "$OUT/result.txt"
if (( ui_rc )); then echo 1 > "$OUT/exit"; exit 1; fi

restore_sources > "$OUT/source-restore.log" 2>&1 || { echo 1 > "$OUT/exit"; exit 1; }
SOURCE_OVERLAY_ACTIVE=0
restore_outputs || { echo 1 > "$OUT/exit"; exit 1; }
echo 0 > "$OUT/cleanup.exit"

sha256sum -c "$CAND/baseline-source-pins.sha256" > "$OUT/prepublish-main-guard.log" 2>&1 || { echo 73 > "$OUT/exit"; exit 73; }
python3 - "$REPO" "$CAND" "$OUT" <<'PY' > "$OUT/publication-guard.log" 2>&1
import hashlib,sys
from pathlib import Path
repo,cand,out=map(Path,sys.argv[1:])
tool='server/src/services/tool-access.ts'
baseline=(cand/'baseline-files'/tool).read_text(); candidate=(cand/'candidate-files'/tool).read_text()
witness=[]
for line in (cand/'tool-access-excluded-root-hunks.txt').read_text().splitlines():
    if line.startswith('+') and not line.startswith('+++'):
        text=line[1:]
        if text.strip(): witness.append(text)
if not witness or any(text not in baseline or text not in candidate for text in witness):
    raise SystemExit('Root Project witness is not byte-preserved in baseline and candidate tool-access source')
for line in (cand/'baseline-source-pins.sha256').read_text().splitlines():
    h,rel=line.split(None,1)
    if hashlib.sha256((repo/rel).read_bytes()).hexdigest()!=h: raise SystemExit(f'MAIN changed before publication: {rel}')
print(f'prepublication baseline and {len(witness)} Root witness lines verified')
PY
pubguard_rc=$?; echo "$pubguard_rc" > "$OUT/publication-guard.exit"
if (( pubguard_rc )); then echo 73 > "$OUT/exit"; exit 73; fi
python3 - "$REPO" "$CAND" <<'PY' > "$OUT/publication.log" 2>&1
import hashlib,os,sys,tempfile
from pathlib import Path
repo,cand=map(Path,sys.argv[1:])
for rel in (cand/'owned-files.txt').read_text().splitlines():
    rel=rel.strip()
    if not rel: continue
    src=cand/'candidate-files'/rel; target=repo/rel
    fd,tmp=tempfile.mkstemp(prefix='.'+target.name+'.r4-',dir=target.parent)
    os.close(fd)
    Path(tmp).write_bytes(src.read_bytes()); os.chmod(tmp,src.stat().st_mode); os.replace(tmp,target)
for line in (cand/'candidate-source-pins.sha256').read_text().splitlines():
    want,rel=line.split(None,1); got=hashlib.sha256((repo/rel).read_bytes()).hexdigest()
    if got!=want: raise SystemExit(f'published hash mismatch {rel}: {got}')
print('published exact R4 candidate bytes for all eight owned paths')
PY
publish_rc=$?; echo "$publish_rc" > "$OUT/publication.exit"
if (( publish_rc )); then echo "$publish_rc" > "$OUT/exit"; exit "$publish_rc"; fi
echo 0 > "$OUT/exit"
