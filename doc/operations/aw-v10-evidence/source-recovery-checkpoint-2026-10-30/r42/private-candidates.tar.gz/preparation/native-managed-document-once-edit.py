from pathlib import Path
p=Path('/workspace/blentera-v10/server/src/services/native-direct-input.ts');s=p.read_text()
# Remove the zero-hit capture node; retain its original fresh checks and traversal.
a=s.index('  const captureProofKey = `capture-node:');b=s.index('  await assertNativeManagedConsumedSourceSetCurrentInScope',a);s=s[:a]+s[b:]
a=s.index('async function assertNativeModelOutputCaptureCurrentInScope(');b=s.index('\n}\n',a);c=s[a:b];assert c.rstrip().endswith('});');c=c.rstrip()[:-3]+'\n';s=s[:a]+c+s[b:]
# Undo generic depth extension (only the removed capture node used it).
s=s.replace('inputs: NativePayloadSourceInput[]; validatedDepth?: number }, read:', 'inputs: NativePayloadSourceInput[] }, read:')
s=s.replace('const proof = candidate && (input.validatedDepth === undefined || input.validatedDepth <= (candidate.validatedDepth ?? -1)) ? candidate : undefined;', 'const proof = candidate;')
s=s.replace('!!candidate && !proof, !!proof &&', 'false, !!proof &&')
s=s.replace('policy: input.policy, inputs: input.inputs, validatedDepth: input.validatedDepth === undefined ? undefined :\n          Math.max(input.validatedDepth, candidate?.validatedDepth ?? -1) });','policy: input.policy, inputs: input.inputs });')
# Authenticate the exact retained managed document capture before the graph walk.
a=s.index('async function assertNativeDocumentRevisionCurrentSourceAccessInScope(');b=s.index('\n}\n',a);c=s[a:b]
ownerStart=c.index('  const taskSourceIds =');dispatchStart=c.index('  const dispatchInputs = snapshot.inputs.filter',ownerStart);sourceStart=c.index('  const sourceDispatch = dispatchInputs.at(-1);',dispatchStart);readerStart=c.index('  const readerSet =',sourceStart)
owner=c[ownerStart:dispatchStart];dispatch=c[dispatchStart:sourceStart];sources=c[sourceStart:readerStart]
ids=''
for marker,after in [('  const taskSourceIds =','  const pinnedTaskSources ='),('  const projectSourceIds =','  for (const projectId of'),('  const memorySourceIds =','  for (const memoryId of')]:
 x=owner.index(marker);y=owner.index(after,x);ids+=owner[x:y];owner=owner[:x]+owner[y:]
needle='''    if (managed && managedCapture) await assertNativeModelOutputCaptureCurrentInScope(db, input.companyId, input.issueId,
      managedCapture, "write_document", scope, depth + 1, input.actor, "settled", siblingToolSourceProofs);''';assert dispatch.count(needle)==1
dispatch=dispatch.replace(needle,'''    if (managed && managedCapture) {
      // The capture's original saved components and ordered union exactly match
      // this snapshot before its own dispatch. Validate that graph once.
      await assertNativeModelOutputCaptureCurrentInScope(db, input.companyId, input.issueId,
        managedCapture, "write_document", scope, depth + 1, input.actor, "settled", siblingToolSourceProofs);
      managedDocumentSourcesValidated = true;
    }''')
replacement=ids+'  let managedDocumentSourcesValidated = false;\n'+dispatch+'  if (!managedDocumentSourcesValidated) {\n'+owner+sources+'  }\n'
c=c[:ownerStart]+replacement+c[readerStart:];s=s[:a]+c+s[b:]
Path('/workspace/v10-preparation/native-managed-document-once-candidate.ts').write_text(s)
