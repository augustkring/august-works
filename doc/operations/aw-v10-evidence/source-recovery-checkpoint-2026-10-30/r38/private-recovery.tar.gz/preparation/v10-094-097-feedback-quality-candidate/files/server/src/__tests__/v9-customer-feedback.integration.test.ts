import { createHash, randomUUID } from "node:crypto";
import express from "express";
import request from "supertest";
import { and, eq, sql } from "drizzle-orm";
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import {
  activityLog,
  authUsers,
  agents,
  issueComments,
  issues,
  feedbackExports,
  companies,
  companyMemberships,
  createDb,
  customerFeedback,
  customerFeedbackAccess,
  customerFeedbackEvents,
  customerFeedbackExperienceMeasures,
  customerFeedbackRetention,
  instanceSettings,
  saasNotifications,
} from "@paperclipai/db";
import { customerFeedbackRoutes } from "../routes/customer-feedback.js";
import { feedbackService } from "../services/feedback.js";
import { companyService } from "../services/companies.js";
import { companyPortabilityService } from "../services/company-portability.js";
import { customerFeedbackService } from "../services/customer-feedback.js";
import { instanceSettingsService } from "../services/instance-settings.js";
import { eraseAccountAccess } from "../services/saas/account-deletion.js";
import { assertDatabaseRestoreAdmission } from "../services/saas/database-admission.js";
import { errorHandler } from "../middleware/error-handler.js";
import { seedNativePasskeySession } from "./helpers/native-authentication-fixtures.js";
import {
  getEmbeddedPostgresTestSupport,
  startEmbeddedPostgresTestDatabase,
} from "./helpers/embedded-postgres.js";
const support = await getEmbeddedPostgresTestSupport();
(support.supported ? describe : describe.skip)(
  "V9 native customer feedback on migrated PostgreSQL",
  () => {
    let database: Awaited<ReturnType<typeof startEmbeddedPostgresTestDatabase>>,
      db: ReturnType<typeof createDb>,
      companyId: string,
      foreignId: string,
      userId: string,
      otherUser: string,
      operatorId: string;
    let operatorSessionId: string;
    beforeAll(async () => {
      database = await startEmbeddedPostgresTestDatabase("aw-v9-feedback-");
      db = createDb(database.connectionString);
    });
    afterAll(async () => {
      await database?.cleanup();
    });
    beforeEach(async () => {
      companyId = randomUUID();
      foreignId = randomUUID();
      userId = randomUUID();
      otherUser = randomUUID();
      operatorId = randomUUID();
      for (const id of [companyId, foreignId])
        await db.insert(companies).values({
          id,
          name: "Feedback company",
          issuePrefix: `F${id.slice(0, 7)}`,
        });
      await db.insert(authUsers).values({
        id: operatorId,
        name: "Operator",
        email: `${operatorId}@example.test`,
        emailVerified: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
      operatorSessionId = await seedNativePasskeySession(db, operatorId);
      for (const principalId of [userId, otherUser])
        await db.insert(companyMemberships).values({
          companyId,
          principalType: "user",
          principalId,
          status: "active",
          membershipRole: "viewer",
        });
      await instanceSettingsService(db).updateExperimental({
        customer_feedback_v9: true,
        experience_projection_v9: false,
        progressive_shell_v9: false,
        home_v9: false,
      });
    });
    const actor = (principal = userId, includeOperatorSession = true) => ({
      type: "board" as const,
      source: "session" as const,
      userId: principal,
      ...(principal === operatorId && includeOperatorSession ? { sessionId: operatorSessionId } : {}),
      companyIds: [companyId],
      memberships: [{ companyId, membershipRole: "viewer", status: "active" }],
    });
    function app(principal = userId, includeOperatorSession = true) {
      const application = express();
      application.use(express.json());
      application.use((req, _res, next) => {
        req.actor = actor(principal, includeOperatorSession);
        next();
      });
      application.use(
        "/api",
        customerFeedbackRoutes(db, { operatorUserIds: [operatorId] }),
      );
      application.use(errorHandler);
      return application;
    }
    const input = () => ({
      idempotencyKey: randomUUID(),
      category: "BUG",
      body: "An approval cannot be opened",
      goal: "Finish reviewing the proposal",
      omitName: true,
      context: {
        surfaceKey: "needs_you",
        locale: "en",
        timezone: "UTC",
        viewportClass: "wide",
      },
    });
    it("stores allow-listed reported context and original server-owned feature observation without exposing it in the customer receipt", async () => {
      const payload = input();
      const context = {
        ...payload.context,
        screenContractId: "NEEDS-YOU",
        clientReleaseBuildId: "a".repeat(40),
        clientEnvironment: {
          source: "reported_user_agent",
          browser: { family: "chrome", majorVersion: 143 },
          operatingSystem: { family: "windows", majorVersion: 10 },
        },
      };
      const submitted = { ...payload, context };
      const url = `/api/companies/${companyId}/customer-feedback`;
      const response = await request(app()).post(url).send(submitted).expect(201);
      const [row] = await db.select().from(customerFeedback).where(eq(customerFeedback.id, response.body.id));
      expect(row!.context).toEqual({ ...context, routeTemplate: "/needs-you", releaseBuildId: expect.any(String), relevantFeatureFlagIds: ["customer_feedback_v9"] });
      expect(response.body).not.toHaveProperty("context");
      expect(row!.submittedByUserId).toBeNull();
      await instanceSettingsService(db).updateExperimental({ experience_projection_v9: true, progressive_shell_v9: true, home_v9: true });
      const replay = await request(app()).post(url).send(submitted).expect(201);
      expect(replay.body.id).toBe(response.body.id);
      const [retained] = await db.select().from(customerFeedback).where(eq(customerFeedback.id, response.body.id));
      expect(retained!.context).toEqual(row!.context);
      expect((await request(app(otherUser)).get(url + `/${response.body.id}`)).status).toBe(404);
    });
    it("keeps optional satisfaction and effort consent in a private sidecar, reports bounded denominators, and erases ratings on withdrawal", async () => {
      const url = `/api/companies/${companyId}/customer-feedback`;
      const payload = { ...input(), experienceMeasure: { offered: true, consent: "granted", satisfaction: "satisfied", effort: "difficult" } };
      const submitted = await request(app()).post(url).send(payload).expect(201);
      await request(app()).post(url).send({ ...input(), experienceMeasure: { offered: true } }).expect(201);
      expect(submitted.body.experienceMeasureStatus).toBe("granted");
      expect(submitted.body).not.toHaveProperty("satisfaction");
      const [original] = await db.select().from(customerFeedback).where(eq(customerFeedback.id, submitted.body.id));
      expect(original!.context.experienceMeasure).toEqual({ offered: true, consent: "granted" });
      expect(await db.select().from(customerFeedbackExperienceMeasures).where(eq(customerFeedbackExperienceMeasures.feedbackId, submitted.body.id))).toMatchObject([
        { satisfaction: "satisfied", effort: "difficult" },
      ]);
      await expect(db.update(customerFeedbackExperienceMeasures).set({ satisfaction: "very_satisfied" })
        .where(eq(customerFeedbackExperienceMeasures.feedbackId, submitted.body.id))).rejects.toMatchObject({ cause: expect.objectContaining({ code: "23514" }) });
      const companyArchive = await companyPortabilityService(db).exportBundle(companyId, {
        include: { company: true, agents: false, projects: false, issues: false, skills: false, supportCases: false },
      }, { actor: actor() });
      expect(JSON.stringify(companyArchive)).not.toMatch(/AWF-|satisfied|difficult|customer_feedback_experience_measures/i);
      const internalUrl = `/api/internal/customer-feedback/${companyId}/${submitted.body.id}`;
      const ownerDetail = await request(app()).get(`${url}/${submitted.body.id}`).expect(200);
      expect(ownerDetail.body.experienceMeasure).toEqual({ satisfaction: "satisfied", effort: "difficult" });
      const ownerList = await request(app()).get(url).expect(200);
      expect(ownerList.body[0]).not.toHaveProperty("experienceMeasure");
      expect(ownerList.body[0].experienceMeasureStatus).toBe("granted");
      const before = await request(app(operatorId)).get(internalUrl).expect(200);
      expect(before.body.context.experienceMeasure).toEqual({ offered: true, consent: "granted", satisfaction: "satisfied", effort: "difficult" });
      const from = new Date(Date.now() - 60_000).toISOString(), to = new Date(Date.now() + 60_000).toISOString();
      const summary = await request(app(operatorId)).get(`/api/internal/customer-feedback/${companyId}/quality?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`).expect(200);
      expect(summary.body.denominator).toEqual({ offeredFeedbackSubmissions: 2, consentedResponses: 1, withdrawnResponses: 0, unconsentedSubmissions: 1, unavailableResponses: 0 });
      expect(summary.body.satisfaction).toMatchObject({ count: 1, distribution: { satisfied: 1 } });
      expect(summary.body.effort).toMatchObject({ count: 1, distribution: { difficult: 1 } });
      const idempotencyKey = randomUUID();
      const withdrawalUrl = `${url}/${submitted.body.id}/experience-measure/withdraw`;
      const withdrawn = await request(app()).post(withdrawalUrl).send({ idempotencyKey });
      expect(withdrawn.status, JSON.stringify(withdrawn.body)).toBe(200);
      expect(withdrawn.body.experienceMeasureStatus).toBe("withdrawn");
      await request(app()).post(withdrawalUrl).send({ idempotencyKey }).expect(200);
      expect(await db.select().from(customerFeedbackExperienceMeasures).where(eq(customerFeedbackExperienceMeasures.feedbackId, submitted.body.id))).toEqual([]);
      await expect(db.insert(customerFeedbackExperienceMeasures).values({ companyId, feedbackId: submitted.body.id, satisfaction: "satisfied", effort: "difficult" }))
        .rejects.toMatchObject({ cause: expect.objectContaining({ code: "23514" }) });
      const [retained] = await db.select().from(customerFeedback).where(eq(customerFeedback.id, submitted.body.id));
      expect(retained!.context).toEqual(original!.context);
      const afterWithdrawal = await request(app(operatorId)).get(internalUrl).expect(200);
      expect(afterWithdrawal.body.context.experienceMeasure).toEqual({ offered: true, availability: "withdrawn" });
      const ownerAfterWithdrawal = await request(app()).get(`${url}/${submitted.body.id}`).expect(200);
      expect(ownerAfterWithdrawal.body.experienceMeasureStatus).toBe("withdrawn");
      expect(ownerAfterWithdrawal.body).not.toHaveProperty("experienceMeasure");
      const afterSummary = await request(app(operatorId)).get(`/api/internal/customer-feedback/${companyId}/quality?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`).expect(200);
      expect(afterSummary.body.denominator).toEqual({ offeredFeedbackSubmissions: 2, consentedResponses: 0, withdrawnResponses: 1, unconsentedSubmissions: 1, unavailableResponses: 0 });
      expect(afterSummary.body.satisfaction).toMatchObject({ count: 0, distribution: { satisfied: 0 } });
      expect(afterSummary.body.effort).toMatchObject({ count: 0, distribution: { difficult: 0 } });
      const withdrawalEvent = await db.select().from(customerFeedbackEvents).where(eq(customerFeedbackEvents.feedbackId, submitted.body.id));
      expect(withdrawalEvent).toHaveLength(1);
      expect(withdrawalEvent[0]).toMatchObject({ body: "", customerVisible: false, linkType: "aw_feedback_measure_withdrawal_v1" });
      expect(JSON.stringify(withdrawalEvent)).not.toMatch(/satisfied|difficult|rating/i);
      await expect(db.delete(customerFeedbackEvents).where(eq(customerFeedbackEvents.id, withdrawalEvent[0]!.id)))
        .rejects.toMatchObject({ cause: expect.objectContaining({ code: "23514" }) });
      await expect(db.insert(customerFeedbackEvents).values({ companyId, feedbackId: submitted.body.id, kind: "product_message", body: "",
        internalNote: "Optional experience ratings withdrawn by the submitter.", linkType: "aw_feedback_measure_withdrawal_v1", customerVisible: false,
        requestKey: randomUUID(), requestHash: "marker-replay" }))
        .rejects.toMatchObject({ cause: expect.objectContaining({ code: "23505" }) });
      const auditRows = await db.select().from(activityLog).where(eq(activityLog.companyId, companyId));
      expect(JSON.stringify(auditRows)).not.toMatch(/satisfied|difficult|rating/i);
      // Replaying the original request key after withdrawal must never restore or replace the deleted values.
      const changedReplay = { ...payload, experienceMeasure: { offered: true, consent: "granted", satisfaction: "very_satisfied", effort: "easy" } };
      const replay = await request(app()).post(url).send(changedReplay).expect(201);
      expect(replay.body.id).toBe(submitted.body.id);
      expect(replay.body.experienceMeasureStatus).toBe("withdrawn");
      expect(await db.select().from(customerFeedbackExperienceMeasures).where(eq(customerFeedbackExperienceMeasures.feedbackId, submitted.body.id))).toEqual([]);
      await request(app()).post(withdrawalUrl).send({ idempotencyKey: randomUUID() }).expect(409);
      expect((await request(app(otherUser)).post(withdrawalUrl).send({ idempotencyKey })).status).toBe(404);
      const refreshed = await request(app(operatorId)).post(`/api/internal/customer-feedback/${companyId}/${submitted.body.id}/triage`).send({
        idempotencyKey: randomUUID(), expectedVersion: 0, internalState: "CLASSIFIED", problemClassification: { area: "task_completion", impact: "limited" },
      }).expect(200);
      expect(refreshed.body.version).toBe(1);
      expect((await request(app(operatorId)).get(internalUrl).expect(200)).body.customerProblemEvidence).toMatchObject({ classification: "task_completion", reportedImpact: "blocked", triageImpact: "limited", source: "product_feedback" });
    });
    it("original local company removal erases its feedback root and private descendants after rollout rollback while preserving another company", async () => {
      const result = await request(app()).post(`/api/companies/${companyId}/customer-feedback`).send({
        ...input(), experienceMeasure: { offered: true, consent: "granted", satisfaction: "satisfied", effort: "easy" },
      }).expect(201);
      expect(await db.select().from(customerFeedbackExperienceMeasures).where(eq(customerFeedbackExperienceMeasures.feedbackId, result.body.id))).toHaveLength(1);
      const withdrawn = await request(app()).post(`/api/companies/${companyId}/customer-feedback`).send({
        ...input(), experienceMeasure: { offered: true, consent: "granted", satisfaction: "very_satisfied", effort: "easy" },
      }).expect(201);
      await request(app()).post(`/api/companies/${companyId}/customer-feedback/${withdrawn.body.id}/experience-measure/withdraw`)
        .send({ idempotencyKey: randomUUID() }).expect(200);
      const foreignFeedbackId = randomUUID();
      await db.insert(customerFeedback).values({ id: foreignFeedbackId, companyId: foreignId, category: "OTHER", body: "Foreign private feedback", context: {} });
      await request(app(operatorId)).post(`/api/internal/customer-feedback/${companyId}/${result.body.id}/triage`).send({ idempotencyKey: randomUUID(), expectedVersion: 0, internalState: "NEEDS_INFO", customerMessage: "Private reply" }).expect(200);
      expect(await db.select().from(saasNotifications).where(eq(saasNotifications.companyId, companyId))).toHaveLength(1);
      await request(app()).post(`/api/companies/${companyId}/customer-feedback/${result.body.id}/follow-up`).send({ idempotencyKey: randomUUID(), expectedVersion: 1, body: "Private follow-up" }).expect(200);
      expect(await db.select().from(customerFeedbackAccess).where(eq(customerFeedbackAccess.companyId, companyId))).toHaveLength(2);
      expect(await db.select().from(customerFeedbackEvents).where(eq(customerFeedbackEvents.companyId, companyId))).toHaveLength(3);
      await instanceSettingsService(db).updateExperimental({ customer_feedback_v9: false });
      expect((await companyService(db).remove(companyId))?.id).toBe(companyId);
      expect(await db.select().from(companies).where(eq(companies.id, companyId))).toEqual([]);
      expect(await db.select().from(customerFeedback).where(eq(customerFeedback.companyId, companyId))).toEqual([]);
      expect(await db.select().from(customerFeedbackAccess).where(eq(customerFeedbackAccess.companyId, companyId))).toEqual([]);
      expect(await db.select().from(customerFeedbackEvents).where(eq(customerFeedbackEvents.companyId, companyId))).toEqual([]);
      expect(await db.select().from(customerFeedbackExperienceMeasures).where(eq(customerFeedbackExperienceMeasures.companyId, companyId))).toEqual([]);
      expect(await db.select().from(saasNotifications).where(eq(saasNotifications.companyId, companyId))).toEqual([]);
      expect(await db.select().from(customerFeedback).where(eq(customerFeedback.id, foreignFeedbackId))).toHaveLength(1);
      expect(await db.select().from(companies).where(eq(companies.id, foreignId))).toHaveLength(1);
    });
    it("retains the legacy immutable request hash without inserting defaults for new optional context", async () => {
      const payload = input();
      // Original closed schema field order/defaults, prior to adding optional context.
      const original = { idempotencyKey: payload.idempotencyKey, category: payload.category, body: payload.body, goal: payload.goal, blocksWork: false, omitName: true, context: payload.context, includeDiagnostics: false };
      const expectedHash = createHash("sha256").update(JSON.stringify(original)).digest("hex");
      const response = await request(app()).post(`/api/companies/${companyId}/customer-feedback`).send(payload).expect(201);
      const [access] = await db.select().from(customerFeedbackAccess).where(eq(customerFeedbackAccess.feedbackId, response.body.id));
      expect(access!.requestHash).toBe(expectedHash);
      const replay = await request(app()).post(`/api/companies/${companyId}/customer-feedback`).send(payload).expect(201);
      expect(replay.body.id).toBe(response.body.id);
    });
    it("refuses raw user-agent, forged server feature IDs and mismatched screen context before any feedback write", async () => {
      const payload = input();
      for (const patch of [{ userAgent: "private-ua-canary" }, { relevantFeatureFlagIds: ["home_v9"] }, { screenContractId: "SUPPORT-ACCESS" }]) {
        await request(app()).post(`/api/companies/${companyId}/customer-feedback`).send({ ...payload, context: { ...payload.context, ...patch } }).expect(400);
      }
      expect(await db.select().from(customerFeedback).where(eq(customerFeedback.companyId, companyId))).toHaveLength(0);
    });
    it("rechecks the actual rolled-back feature at native transaction admission before creating feedback", async () => {
      const reader = new Proxy(db, {
        get(target, key, receiver) {
          if (key === "transaction") return async (callback: Parameters<typeof db.transaction>[0]) => {
            await instanceSettingsService(db).updateExperimental({ customer_feedback_v9: false });
            return db.transaction(callback);
          };
          return Reflect.get(target, key, receiver);
        },
      });
      await expect(customerFeedbackService(reader).create(actor(), companyId, input())).rejects.toThrow("Customer feedback is not enabled");
      expect(await db.select().from(customerFeedback).where(eq(customerFeedback.companyId, companyId))).toHaveLength(0);
      expect(await db.select().from(customerFeedbackAccess).where(eq(customerFeedbackAccess.companyId, companyId))).toHaveLength(0);
    });
    it("keeps Privacy configuration distinct from qualified retention and never exposes private policy references", async () => {
      const preview = await request(app()).get("/api/customer-feedback/policy").expect(200);
      expect(preview.headers["cache-control"]).toBe("private, no-store");
      expect(preview.body.retention.status).toBe("owner_decision_required");
      expect(preview.body.ga.allowed).toBe(false);
      const application = express();
      application.use("/api", customerFeedbackRoutes(db, { runtimeEnv: {
        AW_FEEDBACK_DATA_PROCESSING_JSON: JSON.stringify({ schemaVersion: 1, privacyOwner: "never-expose-private-owner", policyVersion: "private-fixture-v1",
          policies: { submissionRetention: "private.submission", attachmentRetention: "private.attachment", followUpRetention: "private.followup", deletionDsr: "private.dsr", incidentLegalHold: "private.hold", aggregateLearningRetention: "private.aggregate" } }),
      } }));
      const declared = await request(application).get("/api/customer-feedback/policy").expect(200);
      expect(declared.headers["cache-control"]).toBe("private, no-store");
      expect(declared.body.retention.status).toBe("configured_execution_unqualified");
      expect(declared.body.ga.allowed).toBe(false);
      expect(declared.body.attachments.enabled).toBe(false);
      expect(JSON.stringify(declared.body)).not.toContain("never-expose");
      expect(JSON.stringify(declared.body)).not.toContain("private.submission");
      expect(() => customerFeedbackRoutes(db, { runtimeEnv: { AW_CUSTOMER_FEEDBACK_CHANNEL: "ga" } })).toThrow("all six Privacy-owned");
    });
    it("lets a current viewer submit actor-owned feedback and keeps no-name identity out of the canonical submission", async () => {
      const response = await request(app())
        .post(`/api/companies/${companyId}/customer-feedback`)
        .send(input())
        .expect(201);
      expect(response.body.feedbackId).toMatch(/^AWF-[A-F0-9]{32}$/);
      const [row] = await db
        .select()
        .from(customerFeedback)
        .where(eq(customerFeedback.id, response.body.id));
      expect(row!.submittedByUserId).toBeNull();
      expect(row!.diagnostics).toBeNull();
      expect(row!.context.routeTemplate).toBe("/needs-you");
      expect(response.body).not.toHaveProperty("submittedByUserId");
      expect(response.body).not.toHaveProperty("context");
      const [audit] = await db
        .select()
        .from(activityLog)
        .where(
          and(
            eq(activityLog.companyId, companyId),
            eq(activityLog.action, "customer_feedback.received"),
          ),
        );
      expect(audit!.entityId).not.toBe(row!.id);
      expect(audit!.details).toBeNull();
    });
    it("commits one immutable submission for concurrent/retried request keys and rejects changed content", async () => {
      const payload = input(),
        url = `/api/companies/${companyId}/customer-feedback`;
      const results = await Promise.all([
        request(app()).post(url).send(payload),
        request(app()).post(url).send(payload),
      ]);
      expect(results.map((r) => r.status)).toEqual([201, 201]);
      expect(results[0]!.body.id).toBe(results[1]!.body.id);
      await request(app())
        .post(url)
        .send({ ...payload, body: "Different text" })
        .expect(409);
      await expect(
        db
          .update(customerFeedback)
          .set({ body: "Overwritten original" })
          .where(eq(customerFeedback.id, results[0]!.body.id)),
      ).rejects.toThrow();
    });
    it("rejects raw-page metadata, diagnostics without consent, cross-tenant access, stale membership and account swaps", async () => {
      const url = `/api/companies/${companyId}/customer-feedback`;
      await request(app())
        .post(url)
        .send({
          ...input(),
          context: {
            ...input().context,
            rawUrl: "https://example.test/?token=private",
          },
        })
        .expect(400);
      await request(app())
        .post(url)
        .send({
          ...input(),
          diagnostics: { safeErrorCodes: [], correlationIds: [] },
        })
        .expect(400);
      await request(app())
        .post(`/api/companies/${foreignId}/customer-feedback`)
        .send(input())
        .expect(403);
      await request(app())
        .post(`${url}?expectedUserId=${otherUser}`)
        .send(input())
        .expect(409);
      await db
        .update(companyMemberships)
        .set({ status: "inactive" })
        .where(
          and(
            eq(companyMemberships.companyId, companyId),
            eq(companyMemberships.principalId, userId),
          ),
        );
      await request(app()).post(url).send(input()).expect(403);
    });
    it("reads an original actor-owned request without replay, exposes no foreign slot and preserves reads on rollout rollback", async () => {
      const payload = input(), url = `/api/companies/${companyId}/customer-feedback`,
        lookup = `${url}/requests/${payload.idempotencyKey}`;
      const absent = await request(app()).get(lookup).expect(200);
      expect(absent.body).toEqual({ requestKey: payload.idempotencyKey, receipt: null });
      const accepted = await request(app()).post(url).send(payload).expect(201);
      const before = await db.select().from(activityLog).where(eq(activityLog.companyId, companyId));
      await instanceSettingsService(db).updateExperimental({ customer_feedback_v9: false });
      const recovered = await request(app()).get(`${lookup}?expectedUserId=${userId}`).expect(200);
      expect(recovered.headers["cache-control"]).toBe("private, no-store");
      expect(recovered.body).toEqual({ requestKey: payload.idempotencyKey, receipt: accepted.body });
      expect((await request(app(otherUser)).get(lookup).expect(200)).body).toEqual({ requestKey: payload.idempotencyKey, receipt: null });
      await request(app()).get(`${lookup}?expectedUserId=${otherUser}`).expect(409);
      await request(app()).get(`/api/companies/${foreignId}/customer-feedback/requests/${payload.idempotencyKey}`).expect(403);
      expect(await db.select().from(activityLog).where(eq(activityLog.companyId, companyId))).toEqual(before);
      expect(await db.select().from(customerFeedback).where(eq(customerFeedback.companyId, companyId))).toHaveLength(1);
      await db.update(companyMemberships).set({ status: "inactive" }).where(and(eq(companyMemberships.companyId, companyId), eq(companyMemberships.principalId, userId)));
      await request(app()).get(lookup).expect(403);
    });
    it("keeps customer history private even from another company member", async () => {
      const response = await request(app())
        .post(`/api/companies/${companyId}/customer-feedback`)
        .send(input())
        .expect(201);
      const other = await request(app(otherUser))
        .get(`/api/companies/${companyId}/customer-feedback`)
        .expect(200);
      expect(other.body).toEqual([]);
      await request(app(otherUser))
        .get(
          `/api/companies/${companyId}/customer-feedback/${response.body.id}`,
        )
        .expect(404);
      await request(app(otherUser))
        .get(`/api/companies/${companyId}/customer-feedback/${randomUUID()}`)
        .expect(404);
    });
    it("preserves the native restore quarantine through feedback rollout and ordinary setting writes", async () => {
      const marker = {admission: "blocked", restoredAt: "2026-10-09T00:00:00.000Z"};
      try {
      await db.execute(sql`update instance_settings set general=general||jsonb_build_object('awV6RestoreQuarantine',${JSON.stringify(marker)}::jsonb) where singleton_key='default'`);
      const settings = instanceSettingsService(db, {runtimeEnv: {}});
      for (const enabled of [false, true, false]) {
        await settings.updateExperimental({customer_feedback_v9: enabled});
        await expect(assertDatabaseRestoreAdmission(db)).rejects.toThrow("remains quarantined");
        expect(await settings.getGeneral()).not.toHaveProperty("awV6RestoreQuarantine");
        expect((await settings.getGeneral()).outputFeedbackPolicyVersion).toBe("aw-v9-local-v1");
      }
      await settings.updateGeneral({keyboardShortcuts: true});
      await expect(assertDatabaseRestoreAdmission(db)).rejects.toThrow("remains quarantined");
      const [stored] = await db.execute(sql`select general from instance_settings where singleton_key='default'`);
      expect(stored!.general.awV6RestoreQuarantine).toEqual(marker);
      } finally {
        await db.execute(sql`update instance_settings set general=general-'awV6RestoreQuarantine' where singleton_key='default'`);
      }
    });
    it("pages private queues and operator history without losing PostgreSQL sub-millisecond ties or accepting foreign cursors", async () => {
      const submitted = await request(app())
        .post(`/api/companies/${companyId}/customer-feedback`)
        .send(input())
        .expect(201);
      const id = submitted.body.id;
      const rows = Array.from({ length: 26 }, () => ({
        id: randomUUID(),
        companyId,
        category: "OTHER",
        body: "Synthetic paging prerequisite",
        omitName: true,
        context: {
          ...input().context,
          routeTemplate: "/dashboard",
          releaseBuildId: "unverified:paging-fixture",
        },
        createdAt: sql`'2026-10-09 00:00:00.123456+00'::timestamptz`,
      }));
      await db.insert(customerFeedback).values(rows);
      await db.insert(customerFeedbackAccess).values(
        rows.map((row) => ({
          companyId,
          feedbackId: row.id,
          userId,
          requestKey: randomUUID(),
          requestHash: "paging-fixture",
        })),
      );
      for (const url of [
        `/api/companies/${companyId}/customer-feedback`,
        `/api/internal/customer-feedback/${companyId}`,
      ]) {
        const caller = url.includes("/internal/") ? app(operatorId) : app();
        const first = await request(caller).get(url).expect(200);
        const second = await request(caller)
          .get(`${url}?before=${first.body.at(-1).id}`)
          .expect(200);
        const ids = [...first.body, ...second.body].map(
          (value: { id: string }) => value.id,
        );
        expect(ids).toHaveLength(27);
        expect(new Set(ids).size).toBe(27);
        expect(new Set(ids)).toEqual(
          new Set([id, ...rows.map((row) => row.id)]),
        );
      }
      const events = Array.from({ length: 103 }, () => ({
        id: randomUUID(),
        companyId,
        feedbackId: id,
        kind: "product_message",
        body: "Customer-visible answer",
        internalNote: "Private note",
        customerVisible: true,
        requestKey: randomUUID(),
        requestHash: "paging-fixture",
        createdAt: sql`'2026-10-09 00:00:00.123456+00'::timestamptz`,
      }));
      await db.insert(customerFeedbackEvents).values(events);
      const url = `/api/internal/customer-feedback/${companyId}/${id}`;
      const first = await request(app(operatorId)).get(url).expect(200);
      expect(first.body.events).toHaveLength(100);
      expect(first.body.nextEventCursor).toBeTruthy();
      const second = await request(app(operatorId))
        .get(`${url}?beforeEvent=${first.body.nextEventCursor}`)
        .expect(200);
      expect(second.body.events).toHaveLength(3);
      expect(second.body.nextEventCursor).toBeNull();
      expect(
        new Set(
          [...first.body.events, ...second.body.events].map(
            (event: { id: string }) => event.id,
          ),
        ),
      ).toEqual(new Set(events.map((event) => event.id)));
      await request(app(operatorId))
        .get(`${url}?beforeEvent=${randomUUID()}`)
        .expect(404);
      await request(app(operatorId))
        .get(`/api/internal/customer-feedback/${foreignId}?before=${id}`)
        .expect(404);
      await request(app(operatorId))
        .get(`/api/internal/customer-feedback/${foreignId}/${id}`)
        .expect(404);
      const customer = await request(app())
        .get(`/api/companies/${companyId}/customer-feedback/${id}`)
        .expect(200);
      expect(JSON.stringify(customer.body)).not.toContain("Private note");
      expect(customer.body).not.toHaveProperty("events");
      await db
        .update(authUsers)
        .set({ emailVerified: false })
        .where(eq(authUsers.id, operatorId));
      await request(app(operatorId)).get(url).expect(403);
    });
    it("requires a native operator session before exposing internal feedback or accepting triage", async () => {
      const submitted = await request(app()).post(`/api/companies/${companyId}/customer-feedback`).send(input()).expect(201);
      const queue = `/api/internal/customer-feedback/${companyId}`;
      const triage = `${queue}/${submitted.body.id}/triage`;
      await request(app(operatorId, false)).get(queue).expect(403);
      await request(app(operatorId, false)).post(triage).send({ idempotencyKey: randomUUID(), expectedVersion: 0, internalState: "NEEDS_INFO", customerMessage: "Which browser?" }).expect(403);
      const [unchanged] = await db.select().from(customerFeedback).where(eq(customerFeedback.id, submitted.body.id));
      expect(unchanged!.status).toBe("RECEIVED");
      expect(unchanged!.version).toBe(0);
    });
    it("separates verified platform triage and customer messages, uses version fences and appends follow-ups", async () => {
      const response = await request(app())
          .post(`/api/companies/${companyId}/customer-feedback`)
          .send(input())
          .expect(201),
        id = response.body.id;
      const url = `/api/internal/customer-feedback/${companyId}/${id}/triage`,
        payload = {
          idempotencyKey: randomUUID(),
          expectedVersion: 0,
          internalState: "NEEDS_INFO",
          customerMessage: "Which browser were you using?",
          internalNote: "Confidential internal investigation",
        };
      await request(app()).post(url).send(payload).expect(403);
      const triage = await request(app(operatorId))
        .post(url)
        .send(payload)
        .expect(200);
      expect(triage.body.status).toBe("NEEDS_INFO");
      expect(JSON.stringify(triage.body)).not.toContain("Confidential");
      const notifications = await db
        .select()
        .from(saasNotifications)
        .where(eq(saasNotifications.companyId, companyId));
      expect(notifications).toHaveLength(1);
      expect(notifications[0]!.userId).toBe(userId);
      expect(JSON.stringify(notifications)).not.toContain("Which browser");
      expect(JSON.stringify(notifications)).not.toContain("Confidential");
      const internal = await request(app(operatorId))
        .get(`/api/internal/customer-feedback/${companyId}/${id}`)
        .expect(200);
      expect(JSON.stringify(internal.body)).toContain(payload.internalNote);
      expect(JSON.stringify(internal.body)).not.toContain(userId);
      expect(internal.body).not.toHaveProperty("access");
      await request(app(operatorId))
        .post(url)
        .send({ ...payload, idempotencyKey: randomUUID() })
        .expect(409);
      const follow = {
        idempotencyKey: randomUUID(),
        expectedVersion: 1,
        body: "Firefox 140",
      };
      const result = await request(app())
        .post(`/api/companies/${companyId}/customer-feedback/${id}/follow-up`)
        .send(follow)
        .expect(200)
        .expect("Cache-Control", "private, no-store");
      expect(result.body.status).toBe("REVIEWING");
      expect(result.body.body).toBe(input().body);
      expect(result.body.messages.map((m: { body: string }) => m.body)).toEqual(
        [payload.customerMessage, follow.body],
      );
      await request(app())
        .post(`/api/companies/${companyId}/customer-feedback/${id}/follow-up`)
        .send(follow)
        .expect(200);
      const events = await db
        .select()
        .from(customerFeedbackEvents)
        .where(eq(customerFeedbackEvents.feedbackId, id));
      expect(events).toHaveLength(2);
      await expect(
        db
          .update(customerFeedbackEvents)
          .set({ body: "Rewritten" })
          .where(eq(customerFeedbackEvents.feedbackId, id)),
      ).rejects.toThrow();
    });
    it("keeps the original feedback evidence intact when Human triage links an Issue", async () => {
      const sourceBody = "The approval is blocked and the support team should investigate";
      await db.insert(companyMemberships).values({ companyId, principalType: "user", principalId: operatorId,
        status: "active", membershipRole: "viewer" });
      const submitted = await request(app())
        .post(`/api/companies/${companyId}/customer-feedback`)
        .send({ ...input(), body: sourceBody, blocksWork: true })
        .expect(201);
      const [issue] = await db.insert(issues).values({ companyId, title: "Investigate blocked approval",
        createdByUserId: userId, responsibleUserId: userId }).returning();
      const triage = await request(app(operatorId))
        .post(`/api/internal/customer-feedback/${companyId}/${submitted.body.id}/triage`)
        .send({
          idempotencyKey: randomUUID(),
          expectedVersion: 0,
          internalState: "ACTIONABLE",
          internalNote: "Human triage keeps the original source and context authoritative",
          link: { type: "issue", id: issue!.id },
        })
        .expect(200);
      expect(triage.body.status).toBe("REVIEWING");
      const [source] = await db.select().from(customerFeedback).where(eq(customerFeedback.id, submitted.body.id));
      expect(source).toMatchObject({ category: "BUG", body: sourceBody, blocksWork: true, internalState: "ACTIONABLE" });
      const [event] = await db.select().from(customerFeedbackEvents).where(eq(customerFeedbackEvents.feedbackId, source!.id));
      expect(event).toMatchObject({ kind: "product_message", linkType: "issue", linkId: issue!.id });
      const [linkedIssue] = await db.select().from(issues).where(eq(issues.id, issue!.id));
      expect(linkedIssue!.description ?? "").not.toContain(sourceBody);
      const internalDetail = await request(app(operatorId))
        .get(`/api/internal/customer-feedback/${companyId}/${submitted.body.id}`)
        .expect(200);
      expect(internalDetail.body.customerProblemEvidence).toMatchObject({
        source: "product_feedback", sourceId: submitted.body.id, nativeCategory: "BUG",
        nativeLifecycle: "ACTIONABLE", reportedImpact: "blocked", classification: "unknown",
        linkedIssueIds: [issue!.id], linkCoverage: "complete",
      });
      await db.update(issues).set({ visibility: "private", privacyRootIssueId: issue!.id })
        .where(eq(issues.id, issue!.id));
      const restrictedDetail = await request(app(operatorId))
        .get(`/api/internal/customer-feedback/${companyId}/${submitted.body.id}`)
        .expect(200);
      expect(restrictedDetail.body.customerProblemEvidence).toMatchObject({
        classification: "unknown", linkedIssueIds: [], linkCoverage: "unavailable",
      });
      expect(restrictedDetail.body.events.at(-1)).toMatchObject({ linkType: null, linkId: null });
      expect(JSON.stringify(restrictedDetail.body)).not.toContain(issue!.id);
      const deniedLink = await request(app(operatorId))
        .post(`/api/internal/customer-feedback/${companyId}/${submitted.body.id}/triage`)
        .send({ idempotencyKey: randomUUID(), expectedVersion: 1, internalState: "ACTIONABLE",
          link: { type: "issue", id: issue!.id } })
        .expect(404);
      expect(JSON.stringify(deniedLink.body)).not.toContain(issue!.id);
      const [unchanged] = await db.select().from(customerFeedback).where(eq(customerFeedback.id, submitted.body.id));
      expect(unchanged!.version).toBe(1);
    });
    it("enforces compound tenant references and erases no-name feedback through native account deletion", async () => {
      const service = customerFeedbackService(db),
        result = await service.create(actor(), companyId, { ...input(), experienceMeasure: { offered: true, consent: "granted", satisfaction: "satisfied", effort: "easy" } });
      expect(await db.select().from(customerFeedbackExperienceMeasures).where(eq(customerFeedbackExperienceMeasures.feedbackId, result.id))).toHaveLength(1);
      await expect(
        db.insert(customerFeedbackAccess).values({
          companyId: foreignId,
          feedbackId: result.id,
          userId: otherUser,
          requestKey: randomUUID(),
          requestHash: "invalid",
        }),
      ).rejects.toThrow();
      await expect(db.insert(customerFeedbackExperienceMeasures).values({
        companyId: foreignId, feedbackId: result.id, satisfaction: "satisfied", effort: "easy",
      })).rejects.toThrow();
      await db.transaction((tx) => eraseAccountAccess(tx, userId));
      expect(
        await db
          .select()
          .from(customerFeedback)
          .where(eq(customerFeedback.id, result.id)),
      ).toHaveLength(0);
      expect(await db.select().from(customerFeedbackExperienceMeasures).where(eq(customerFeedbackExperienceMeasures.feedbackId, result.id))).toEqual([]);
      expect(
        await db
          .select()
          .from(customerFeedbackAccess)
          .where(eq(customerFeedbackAccess.feedbackId, result.id)),
      ).toHaveLength(0);
      await db.execute(sql`select 1`);
    });
    it("erases optional rating bytes during account deletion even when the parent complaint remains under hold", async () => {
      const service = customerFeedbackService(db), result = await service.create(actor(), companyId, {
        ...input(), experienceMeasure: { offered: true, consent: "granted", satisfaction: "satisfied", effort: "easy" },
      });
      await db.insert(customerFeedbackRetention).values({ companyId, feedbackId: result.id, version: 1, legalHold: true, holdReason: "Active incident hold" });
      expect(await db.select().from(customerFeedbackExperienceMeasures).where(eq(customerFeedbackExperienceMeasures.feedbackId, result.id))).toHaveLength(1);
      await db.transaction((tx) => eraseAccountAccess(tx, userId));
      expect(await db.select().from(customerFeedback).where(eq(customerFeedback.id, result.id))).toHaveLength(1);
      expect(await db.select().from(customerFeedbackExperienceMeasures).where(eq(customerFeedbackExperienceMeasures.feedbackId, result.id))).toEqual([]);
      expect(await db.select().from(customerFeedbackRetention).where(eq(customerFeedbackRetention.feedbackId, result.id))).toHaveLength(1);
    });
    it("does not reuse legacy output-sharing consent or capture trace bundles, even after flag rollback", async () => {
      const [agent] = await db
        .insert(agents)
        .values({
          companyId,
          name: "Helper",
          role: "engineer",
          status: "active",
          adapterType: "codex_local",
        })
        .returning();
      const [issue] = await db
        .insert(issues)
        .values({ companyId, title: "Review report" })
        .returning();
      const [comment] = await db
        .insert(issueComments)
        .values({
          companyId,
          issueId: issue!.id,
          authorAgentId: agent!.id,
          body: "Confidential generated report",
        })
        .returning();
      const settings = instanceSettingsService(db);
      await settings.updateGeneral({
        feedbackDataSharingPreference: "allowed",
      });
      const vote = await feedbackService(db).saveIssueVote({
        issueId: issue!.id,
        targetType: "issue_comment",
        targetId: comment!.id,
        vote: "up",
        authorUserId: userId,
        allowSharing: true,
      });
      expect(vote.sharingEnabled).toBe(false);
      expect(vote.traceId).toBeNull();
      expect(
        await db
          .select()
          .from(feedbackExports)
          .where(eq(feedbackExports.feedbackVoteId, vote.vote.id)),
      ).toHaveLength(0);
      await settings.updateExperimental({ customer_feedback_v9: false });
      expect((await settings.getGeneral()).outputFeedbackPolicyVersion).toBe(
        "aw-v9-local-v1",
      );
      const after = await feedbackService(db).saveIssueVote({
        issueId: issue!.id,
        targetType: "issue_comment",
        targetId: comment!.id,
        vote: "down",
        authorUserId: userId,
        allowSharing: true,
      });
      expect(after.sharingEnabled).toBe(false);
      expect(after.traceId).toBeNull();
      let uploads = 0;
      const exporter = feedbackService(db, {
        shareClient: {
          uploadTraceBundle: async () => {
            uploads++;
            return { objectKey: "unexpected" };
          },
        },
      });
      expect(await exporter.flushPendingFeedbackTraces()).toEqual({
        attempted: 0,
        sent: 0,
        failed: 0,
      });
      expect(uploads).toBe(0);
    });
    it("latches feedback local at SaaS settings admission when the feedback flag is disabled", async () => {
      const localSettings = instanceSettingsService(db, {
        runtimeEnv: { AW_DEPLOYMENT_PROFILE: "local" },
      });
      try {
        await localSettings.updateExperimental({ customer_feedback_v9: false });
        await db.execute(sql`update instance_settings set general = general - 'outputFeedbackPolicyVersion' where singleton_key = 'default'`);
        await localSettings.updateGeneral({ feedbackDataSharingPreference: "allowed" });
        expect((await localSettings.getGeneral()).outputFeedbackPolicyVersion).toBeUndefined();

        const deploymentEnv = { AW_DEPLOYMENT_PROFILE: "saas" };
        const saasSettings = instanceSettingsService(db, { runtimeEnv: deploymentEnv });
        const admittedGeneral = await saasSettings.getGeneral();
        expect(admittedGeneral.outputFeedbackPolicyVersion).toBe("aw-v9-local-v1");
        expect(admittedGeneral.feedbackDataSharingPreference).toBe("allowed");
        expect((await saasSettings.getExperimental()).customer_feedback_v9).toBe(false);

        deploymentEnv.AW_DEPLOYMENT_PROFILE = "local";
        expect((await saasSettings.getGeneral()).outputFeedbackPolicyVersion).toBe("aw-v9-local-v1");

        const [agent] = await db
          .insert(agents)
          .values({ companyId, name: "Helper", role: "engineer", status: "active", adapterType: "codex_local" })
          .returning();
        const [issue] = await db.insert(issues).values({ companyId, title: "Review report" }).returning();
        const [comment] = await db
          .insert(issueComments)
          .values({ companyId, issueId: issue!.id, authorAgentId: agent!.id, body: "Confidential generated report" })
          .returning();
        const vote = await feedbackService(db).saveIssueVote({
          issueId: issue!.id,
          targetType: "issue_comment",
          targetId: comment!.id,
          vote: "up",
          authorUserId: userId,
          allowSharing: true,
        });
        expect(vote.sharingEnabled).toBe(false);
        expect(vote.traceId).toBeNull();
        expect(await db.select().from(feedbackExports).where(eq(feedbackExports.feedbackVoteId, vote.vote.id))).toHaveLength(0);

        let uploads = 0;
        const exporter = feedbackService(db, {
          shareClient: {
            uploadTraceBundle: async () => {
              uploads++;
              return { objectKey: "unexpected" };
            },
          },
        });
        expect(await exporter.flushPendingFeedbackTraces()).toEqual({ attempted: 0, sent: 0, failed: 0 });
        expect(uploads).toBe(0);

        deploymentEnv.AW_DEPLOYMENT_PROFILE = "saas";
        await db.execute(sql`delete from instance_settings where singleton_key = 'default'`);
        expect((await saasSettings.getGeneral()).outputFeedbackPolicyVersion).toBe("aw-v9-local-v1");
      } finally {
        await localSettings.updateExperimental({ customer_feedback_v9: true });
      }
    });
    it("preserves the feedback privacy latch when a general settings write overlaps flag enablement", async () => {
      const settings = instanceSettingsService(db, { runtimeEnv: {} });
      await settings.updateExperimental({ customer_feedback_v9: false });
      await db.execute(sql`update instance_settings set general = general - 'outputFeedbackPolicyVersion' where singleton_key = 'default'`);

      let unlock!: () => void;
      const holdLock = new Promise<void>((resolve) => { unlock = resolve; });
      let locked!: () => void;
      let lockFailed!: (error: unknown) => void;
      const holderReady = new Promise<void>((resolve, reject) => { locked = resolve; lockFailed = reject; });
      const holder = db.transaction(async (tx) => {
        try {
          await tx.select({ id: instanceSettings.id }).from(instanceSettings)
            .where(eq(instanceSettings.singletonKey, "default")).for("update");
          locked();
          await holdLock;
        } catch (error) {
          lockFailed(error);
          throw error;
        }
      });

      let enableFeedback: Promise<unknown> | undefined;
      let updateGeneral: Promise<unknown> | undefined;
      try {
        await holderReady;
        enableFeedback = settings.updateExperimental({ customer_feedback_v9: true });

        const waitForSettingsBlockers = async (minimum: number) => {
          await vi.waitFor(async () => {
            const [row] = await db.execute<{ count: number }>(sql`
              select count(*)::int as count from pg_stat_activity
              where datname = current_database()
                and pid <> pg_backend_pid()
                and wait_event_type = 'Lock'
                and query ilike '%instance_settings%'`);
            expect(row!.count).toBeGreaterThanOrEqual(minimum);
          }, { timeout: 10_000, interval: 25 });
        };

        await waitForSettingsBlockers(1);
        updateGeneral = settings.updateGeneral({ censorUsernameInLogs: true });
        await waitForSettingsBlockers(2);

        unlock();
        await holder;
        await Promise.all([enableFeedback, updateGeneral]);
        expect((await settings.getGeneral()).outputFeedbackPolicyVersion).toBe("aw-v9-local-v1");
        expect((await settings.getGeneral()).censorUsernameInLogs).toBe(true);
      } finally {
        unlock();
        await Promise.allSettled([holder, ...(enableFeedback ? [enableFeedback] : []), ...(updateGeneral ? [updateGeneral] : [])]);
        await settings.updateExperimental({ customer_feedback_v9: true });
      }
    });
    it("fails closed when the rollout flag is disabled", async () => {
      await instanceSettingsService(db).updateExperimental({
        customer_feedback_v9: false,
      });
      await request(app())
        .post(`/api/companies/${companyId}/customer-feedback`)
        .send(input())
        .expect(404);
    });
  },
);
