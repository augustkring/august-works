from pathlib import Path
import json,hashlib,shutil,subprocess,tarfile
root=Path('/workspace/blentera-v10');src=Path('/workspace/v10-preparation/openshell-rt01-repo-integration-candidate-r6');proof=Path('/workspace/v10-preparation/openshell-r6-1-run-41051549768');prefix='third_party/openshell/rt01/'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
a=json.loads((root/(prefix+'source-pins.json')).read_text());b=json.loads((src/(prefix+'source-pins.json')).read_text());assert a['patch']['sha256']==b['patch']['sha256']=='c5571c1418ccc23866b399682b4d9f6f48242103970bffb470c8c45b968c810b';assert a['files']==b['files'],'source files must not change in evidence refresh'
assert sha(src/(prefix+'source-pins.json'))=='d1eba31372c0fc3768949527b21dd6adc762b62f0a913bdb1ebe784cb9081239'
archive=proof/'qualification.tar.gz';assert sha(archive)=='8be6460d60743a37ca8e6e3451e05b0fffe5f018a1b3581e8dd7b9936d50520a'
with tarfile.open(archive) as t:
 names=t.getnames();assert any(name.endswith('full-run.log') for name in names);assert any(name.endswith('source-pins.json') for name in names)
m=json.loads((src/(prefix+'metadata.json')).read_text());q=m['qualification'];assert q['R6_1HeadSha']=='4f7894452d67dc76d7349c940217bdb0be39fb40';assert q['R6_1FocusedTests']=={'configured':18,'passed':18,'failed':0,'skipped':0};assert m['profileAdmission']=='closed'
out=root/'doc/operations/aw-v10-evidence/openshell-rt01-provisioning-source-qualified-2026-10-30';out.mkdir(exist_ok=False);shutil.copy2(archive,out/'qualification.tar.gz');(out/'README.md').write_text((proof/'README.md').read_text()+'\nThis portable receipt qualifies pinned software source only. Physical target-host, deployed compatibility and whole V10 acceptance remain open.\n');(out/'manifest.json').write_text(json.dumps({'purpose':'scoped software qualification; not physical host or whole V10 acceptance','qualifiedRepositoryHead':q['R6_1HeadSha'],'workflowRun':q['R6_1Run'],'patchSha256':a['patch']['sha256'],'qualifiedManifestSha256':sha(proof/'source-pins.json'),'evidenceOnlyRefreshedManifestSha256':sha(src/(prefix+'source-pins.json')),'sourceFileHashesUnchanged':True,'exactTestsPassed':18,'compiledPackages':['openshell-server','openshell-cli','openshell-driver-docker','openshell-sandbox'],'archiveSha256':sha(archive),'archiveBytes':archive.stat().st_size},indent=2)+'\n')
paths=[prefix+n for n in ['source-pins.json','metadata.json','README.md']]
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--',*paths],cwd=root).strip()
for rel in paths:shutil.copy2(src/rel,root/rel)
paths.append(str(out.relative_to(root)));subprocess.run(['git','diff','--check','--',*paths],cwd=root,check=True);subprocess.run(['git','add','--',*paths],cwd=root,check=True);subprocess.run(['git','commit','-m','test: preserve passing OpenShell provisioning source qualification [skip ci]'],cwd=root,check=True)
