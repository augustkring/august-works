# Native Memory transaction-reuse CI qualification — 2026-10-30

This r5 qualification is pinned to source head `7c50fce45073140d836315a1aedd27c658afcbb3`. The capture includes 1,147 copied source files; the Vitest Vite/Oxc parser checked 979 files and passed. `source-pins.json`, the compressed source patch, and deterministic untracked source archive preserve reconstruction inputs.

The exact embedded-Postgres case passed with no skipped tests. Its valid-reader comparisons and savepoint test show Alice can read the sealed Native Memory output while her membership is active and that a nested same-transaction reader does not block behind the queued writer. After the fixture suspends Alice's company membership, Memory access remains denied: the per-Task output reader boundary returns HTTP 403. The assertion now checks that expected denial instead of assuming this boundary returns a boolean `false`.

Before and after guards both matched all 1,147 copied source pins. No Native production files were changed. No files are staged by this qualification.
