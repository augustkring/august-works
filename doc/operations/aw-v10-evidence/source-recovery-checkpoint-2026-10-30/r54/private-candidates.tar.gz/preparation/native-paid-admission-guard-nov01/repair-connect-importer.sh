#!/usr/bin/env bash
set -euo pipefail
REPO=/workspace/blentera-v10
LOCK=/workspace/v10-preparation/v10-pg-tests.lock
RECEIPT=/workspace/v10-preparation/native-paid-admission-guard-nov01/vercel-connect-dependency-repair-receipt.json
EXPECTED_HEAD=254e5c998c9f41725708a2c8c404078397a3fcac
LINK="$REPO/server/node_modules/@vercel/connect"
NEW_TARGET='../../../../v10-dep-qualification/node_modules/.pnpm/@vercel+connect@0.6.1_@chat-adapter+slack@4.39.0_patch_hash=226jj24akljccsfbw7bcxujz4u_ai@7.0_foabkcihxgxz3glm6bsbw7dcnm/node_modules/@vercel/connect'
exec 9>"$LOCK"
flock -x 9
[[ "$(git -C "$REPO" rev-parse HEAD)" == "$EXPECTED_HEAD" ]]
OLD_TARGET="$(readlink "$LINK")"
LOCK_SHA="$(sha256sum "$REPO/pnpm-lock.yaml" | awk '{print $1}')"
VIRTUAL_LOCK=/tmp/blentera-dependency-recovery-20261101/node_modules.partial/.pnpm/lock.yaml
STORE_INDEX=/workspace/.cloud-setup/pnpm-store/v3/files/a4/5be5d9d896101fcd60457d6285166bc8c1239f1c6863de68cb9899828b402f3f1627da21fa539c4a37b9b05bf0d07467bf387e42c5084279b980f365277fda-index.json
[[ "$(sha256sum "$VIRTUAL_LOCK" | awk '{print $1}')" == "$LOCK_SHA" ]]
[[ "$(readlink -f "$REPO/server/node_modules/@vercel/connect")" == "" ]] || true
python3 - "$REPO" "$LINK" "$OLD_TARGET" "$NEW_TARGET" "$LOCK_SHA" "$STORE_INDEX" "$RECEIPT" <<'PY'
import base64, hashlib, json, os, re, subprocess, sys
repo, link, old_target, new_target, lock_sha, store_index_path, receipt_path = sys.argv[1:]
lock_path=os.path.join(repo,'pnpm-lock.yaml')
lock_text=open(lock_path,encoding='utf8').read()
package_text=open(os.path.join(repo,'server/package.json'),encoding='utf8').read()
assert re.search(r'"@vercel/connect"\s*:\s*"0\.6\.1"', package_text)
package_block=lock_text.split("  '@vercel/connect@0.6.1':",1)[1].split("\n  '@vercel/oidc@",1)[0]
m=re.search(r"resolution:\s*\{integrity:\s*(sha512-[^}\s]+)",package_block)
assert m, 'lock integrity is missing'
locked_integrity=m.group(1)
index=json.load(open(store_index_path,encoding='utf8'))
assert index.get('name')=='@vercel/connect' and index.get('version')=='0.6.1'
new_abs=os.path.normpath(os.path.join(os.path.dirname(link),new_target))
new_real=os.path.realpath(new_abs)
assert os.path.isdir(new_real), new_real
installed=json.load(open(os.path.join(new_real,'package.json'),encoding='utf8'))
assert installed.get('name')=='@vercel/connect' and installed.get('version')=='0.6.1'
checks=[]
for rel, metadata in sorted(index['files'].items()):
    path=os.path.join(new_real,rel)
    data=open(path,'rb').read()
    actual='sha512-'+base64.b64encode(hashlib.sha512(data).digest()).decode('ascii')
    expected=metadata.get('integrity')
    if actual != expected:
        raise SystemExit(f'package file integrity mismatch: {rel}')
    checks.append(rel)
before={
 'symlinkTarget':old_target,
 'resolvedTarget':os.path.realpath(os.path.join(os.path.dirname(link),old_target)),
 'targetExists':os.path.exists(os.path.join(os.path.dirname(link),old_target)),
}
receipt={
 'schema':'paperclip.dependency-link-repair-receipt.v1',
 'repositoryHead':subprocess.check_output(['git','-C',repo,'rev-parse','HEAD'],text=True).strip(),
 'lockfileSha256':lock_sha,
 'importer':'server',
 'dependency':'@vercel/connect',
 'specifier':'0.6.1',
 'lockedPeerResolution':'@chat-adapter/slack@4.39.0(patch_hash=226jj24akljccsfbw7bcxujz4)(ai@7.0.130(zod@4.6.6))(zod@4.6.6), ai@7.0.130(zod@4.6.6), better-auth@1.7.7',
 'lockPackageIntegrity':locked_integrity,
 'storeIndexPath':store_index_path,
 'storeIndexSha256':hashlib.sha256(open(store_index_path,'rb').read()).hexdigest(),
 'storeIndexFileCount':len(index['files']),
 'verifiedInstalledFiles':checks,
 'installedPackageVersion':installed['version'],
 'installedPackageJsonSha256':hashlib.sha256(open(os.path.join(new_real,'package.json'),'rb').read()).hexdigest(),
 'installedTreeSha256':None,
 'before':before,
 'after':None,
}
hash_=hashlib.sha256()
for rel in sorted(index['files']):
    digest=hashlib.sha256(open(os.path.join(new_real,rel),'rb').read()).hexdigest()
    hash_.update(rel.encode()+b'\0'+digest.encode()+b'\n')
receipt['installedTreeSha256']=hash_.hexdigest()
# Persist the before receipt before mutating the dependency link.
receipt['after']={'pending':True}
open(receipt_path,'w',encoding='utf8').write(json.dumps(receipt,indent=2)+'\n')
PY
ln -sfn "$NEW_TARGET" "$LINK"
python3 - "$REPO" "$LINK" "$NEW_TARGET" "$LOCK_SHA" "$STORE_INDEX" "$RECEIPT" <<'PY'
import hashlib,json,os,subprocess,sys
repo,link,target,lock_sha,index_path,receipt_path=sys.argv[1:]
actual=os.readlink(link)
assert actual==target, actual
resolved=os.path.realpath(link)
assert os.path.isdir(resolved), resolved
package=json.load(open(os.path.join(resolved,'package.json'),encoding='utf8'))
assert package.get('version')=='0.6.1'
assert hashlib.sha256(open(os.path.join(repo,'pnpm-lock.yaml'),'rb').read()).hexdigest()==lock_sha
lock=json.load(open(receipt_path,encoding='utf8'))
lock['after']={
 'symlinkTarget':actual,
 'resolvedTarget':resolved,
 'targetExists':os.path.exists(link),
 'installedPackageVersion':package['version'],
 'lockPackageIntegrity':lock['lockPackageIntegrity'],
 'installedTreeSha256':lock['installedTreeSha256'],
}
open(receipt_path,'w',encoding='utf8').write(json.dumps(lock,indent=2)+'\n')
PY
cd "$REPO/server"
node --input-type=module -e 'const m=await import("@vercel/connect"); if (!m || typeof m !== "object") process.exit(2); console.log("@vercel/connect import ok")' > /tmp/native-paid-connect-import-check.log 2>&1
cat /tmp/native-paid-connect-import-check.log
sha256sum "$REPO/pnpm-lock.yaml" "$LINK/package.json" "$RECEIPT"
