# R6 coherent fixture source — review only

Prepared against clean pushed Main `249ea9e7d0bad179e76f73c1a9372ad934a01e94`. Thirteen derived source/test paths; zero production service changes. R5 and its actual pure10 receipt remain immutable. R6 has only Node strip-types syntax13/13 evidence: no typecheck/import/runtime test/SDK/Host acceptance.

## Composition

R5 eight paths + constructor Frame path = nine; new serial integration = ten; existing Source4 integration = eleven; Project helper + Project integration = thirteen. Shared Host/heartbeat overlap, so counts are union membership rather than sums of manifests.

The Host includes the exact published FD diagnostic delta. Project R3 was merged against its exact a30f original, not copied over the producer. Two structural conflicts were resolved by preserving the new producer import/function extraction and adding Project's import/optional scope. Its real Task/workspace/source transaction and current original lease checks remain. Project requires ordinary Worker scope before infrastructure effects; serial+Project explicitly rejects, preserving phase-one serial Agent-home scope. Its single-Run Project helper/integration are unchanged candidate bytes from their approved packets.

SourceMigration R3's authenticated observer and actual assigned-result observer were merged from the HTTP companion parent. Two adjacent conflicts retain both local fixed-denial counters and its authenticated ALS, and retain the observe flag in Host context before the unchanged Host model wrapper. Its exact verified claims→executionsByRun lookup, structuredClone body observation, original gateway arguments, actual completed assigned result and bound replay owner remain. Constructor HTTP forwarding covers the captured broker gateways plus the separate Host registry/scoped factory; the fixed one-use qualification echo branch remains its original owner.

## Gate A implementation

`observeModelOriginDenials:true` is an explicit fixture-only fixed-control opt-in. The heartbeat entry rejects it outside serial mode. It grants no token, Run, origin, profile, image or source override.

After a real selected SDK socket is successfully observed under the actual signed START/applied provider closure, the per-Run Host executes two fixed negative observations against that socket: wrong marker nonce, and wrong expected image digest. Both use the same actual attestor and actual current original provider closure. The temporary mismatched expectation is not a new authorized artifact manifest. Unexpected success closes the temporary observer and fails the fixture. The original successful channel is retained privately solely to check rejection after actual terminal Run/lease/canonical Stop/FD closure. No capability leaves the closure.

At the first real provider boundary for each Run, the existing legitimate request is paused. Two real Node-origin requests copy that actual model body in memory: direct TLS to the fixed broker, and raw CONNECT→TLS through its existing fixed proxy, with actual CA/hostname validation and **no** Authorization/API key/cookie. Unknown Node ancestry/executable receives no channel association; the existing authenticated route rejects it. Success requires two exact `scheduler_software_host_incoming_model_authority_invalid` observations, rejected HTTP status, unchanged provider/injection counts, unchanged exact Run reservation IDs and unchanged tool-invocation IDs. Thus a generic HTTP error by itself is insufficient. Both local client sockets have a fixed five-second bound and close in finally. No arbitrary URL/header/Run is accepted by the probe function, and no raw body/token is logged.

At B admission the existing A successor-ready proof runs first. The retained original A channel must reject; there is no fallback to B. This records closed-object denial, not a claim that a dead SDK network socket remained live across Stop. R5's actual CONNECT/TLS and synthetic tuple-reuse receipts remain separately scoped.

## Gate C implementation

The new whole `heartbeat-managed-serial-scheduler.integration.test.ts` uses actual issueService.create, orchestration create/decide(start), heartbeat.wakeup/drain for each lifecycle. One current Human/session, Agent and Task; two explicit capped Plans. If A made the Task done, B reopens it with the authenticated issueService.update owner, reloads updatedAt and quotes/starts a new Plan. It does not insert/mark Runs, attempts, Plans, leases or cleanup receipts. Fresh source owners reject live Task pointers before a second Plan.

Each Run must retain its own document, exact attempt/manifest, completed provider-wire reservations and source receipt, then prove canonical Stop, released cleanup-success lease, no pending Native cleanup, detached provider and Stop receipt. Distinct Run/lease/attempt/manifest/session keys and same installed Host/cell/environment/artifact authority are asserted. After B, A's source/issuer/reservation/provider facts remain unchanged except its explicit retirement/negative-observation facts. Failure retains database data and caller root; normal database stop is still attempted. A fixed initial 900000ms test envelope accommodates two original 300s Run bounds without renewing either live Run/sample. This is a two-lifecycle test, not a same-Plan retry/recovery claim.

## Next gates

Root reviews this concrete diff before checkpoint publication. Exact CI full recursive Typecheck/Release and genuine provider pack/prover/image-Node setup must pass on the new commit. Then actual origin-denial/two-Run case, existing unchanged default ordinary canary, existing unchanged default C7, Source4 and Project cases run sequentially under the approved CI/resource scope. No local SDK/browser at the current cgroup memory baseline. R6 does not include Code's app-level registered-gateway reuse/caller/browser files; merge those only from their separately approved pins. Operator/physical Host claims remain external.
