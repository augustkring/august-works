# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: connection-reviews.spec.ts >> connection review: approve, synchronized task history and actual continuation
- Location: tests/e2e/connection-reviews.spec.ts:108:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator:  getByText('Succeeded').first()
Expected: visible
Received: hidden
Timeout:  5000ms

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByText('Succeeded').first()
    4 × locator resolved to <button type="button" data-state="closed" aria-expanded="false" data-slot="collapsible-trigger" aria-label="Show result details" class="flex items-center gap-1.5 rounded-sm hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">…</button>
      - unexpected value "hidden"

```

```yaml
- link "Skip to Main Content":
  - /url: "#main-content"
- complementary:
  - button "Open Connection review E2E 1793058704949 organization switcher": C Connection review E2E 1793058704949
  - navigation:
    - text: Visning
    - combobox "Visning":
      - option "Medlem"
      - option "Leder" [selected]
      - option "Administrator"
      - option "Sikkerhedsadministrator"
    - link "Hjem":
      - /url: /CON/dashboard
    - link "Kræver dig":
      - /url: /CON/needs-you
    - link "Arbejde":
      - /url: /CON/work
    - link "Agenter":
      - /url: /CON/agents
    - link "Apps":
      - /url: /CON/apps
    - link "Indsigter":
      - /url: /CON/insights
    - link "Avanceret":
      - /url: /CON/advanced
    - button "Spørg Blentera"
    - link "Hjælp / Support":
      - /url: /CON/company/help
- button "Open account menu": BR Browser product reviewer
- separator "Resize sidebar"
- region "Globale funktioner":
  - button "Spørg Blentera"
  - text: Sprog
  - combobox "Sprog":
    - option "English"
    - option "Dansk" [selected]
  - link "Hjælp / Support":
    - /url: /CON/company/help
  - link "Kontakt support":
    - /url: mailto:support@blentera.com
  - link "Brugerkonto":
    - /url: /CON/company/settings/instance/profile
- navigation "breadcrumb":
  - list:
    - listitem:
      - link "Tasks":
        - /url: /CON/issues
    - listitem:
      - link "Done Read recent pages CON-1" [disabled]:
        - img "Done"
        - text: Read recent pages CON-1
- button "Hide properties"
- main:
  - tabpanel:
    - status "Loading conversation":
      - 'button "Change status (current: Done)"':
        - img "Done"
      - heading "Read recent pages" [level=2]
      - text: CON-1 No project BR
      - button "More task actions"
    - textbox "editable markdown":
      - paragraph
    - paragraph: Message Page reader — describe what you want done…
    - button "Attach file"
    - button "Auto mode"
    - button "Page reader"
    - button "Send" [disabled]
- complementary:
  - separator "Resize panel"
  - region "Side panel":
    - tablist:
      - tab "Properties" [selected]
      - button "Close Properties"
      - status
    - button "Open a new tab"
    - button "Maximize side panel"
    - button "Close side panel"
    - tabpanel "Properties":
      - text: Work Status
      - 'button "Change status (current: Done)"':
        - img "Done"
        - text: Done
      - text: Assignee
      - button "Page reader"
      - link:
        - /url: /CON/agents/590fa660-5224-4ded-87e9-aa13c9a82ab6
      - text: Project
      - button "None"
      - text: Labels
      - button "None"
      - text: Relationships Parent
      - button "None"
      - text: Blocked by
      - button "None"
      - text: Blocking None Subtasks
      - button "None"
      - text: Execution Reviewers
      - button "None"
      - text: Approvers
      - button "None"
      - text: Monitor
      - button "None"
      - text: Watchdog
      - button "None"
      - text: About Originating BR Browser product reviewer Started Oct 26, 2026, 11:51 PM Completed Oct 26, 2026, 11:52 PM Created Oct 26, 2026, 11:51 PM Updated just now
- heading "Command Palette" [level=2]
- paragraph: Search for a command to run...
```

# Test source

```ts
  228 |         .click();
  229 |       await expect(
  230 |         page.getByRole("button", { name: "Approve & run", exact: true }),
  231 |       ).toBeVisible();
  232 |       const queue = await context.newPage();
  233 |       await queue.goto(`/${seed.prefix}/apps/review`);
  234 |       await expect(
  235 |         queue.getByRole("button", { name: "Decline", exact: true }),
  236 |       ).toBeVisible({ timeout: 20_000 });
  237 |       if (journey === "restart") {
  238 |         const control = process.env.PAPERCLIP_REVIEW_RESTART_FILE!;
  239 |         const token = String(Date.now());
  240 |         await writeFile(control, `restart:${token}`);
  241 |         await expect
  242 |           .poll(() => readFile(control, "utf8"), { timeout: 60_000 })
  243 |           .toBe(`started:${token}`);
  244 |         await expect
  245 |           .poll(
  246 |             async () => {
  247 |               try {
  248 |                 return (await request.get("/api/health")).ok();
  249 |               } catch {
  250 |                 return false;
  251 |               }
  252 |             },
  253 |             { timeout: 60_000 },
  254 |           )
  255 |           .toBe(true);
  256 |         await page.reload();
  257 |         await queue.reload();
  258 |         await expect(
  259 |           page.getByRole("button", { name: "Approve & run", exact: true }),
  260 |         ).toBeVisible();
  261 |         expect(calls()).toBe(0);
  262 |       }
  263 |       if (journey === "decline") {
  264 |         // Resolve from Connections and observe the still-open task tab update.
  265 |         await queue
  266 |           .getByRole("button", { name: "Decline", exact: true })
  267 |           .click();
  268 | 
  269 |       } else {
  270 |         if (journey === "always") {
  271 |           await page.getByRole("button", { name: "Approval options", exact: true }).click();
  272 |           await page.getByRole("menuitem", { name: "Always allow", exact: true }).click();
  273 |         } else {
  274 |           await page.getByRole("button", { name: "Approve & run", exact: true }).click();
  275 |         }
  276 |       }
  277 |       await expect
  278 |         .poll(
  279 |           async () =>
  280 |             (
  281 |               await json<Array<{ body: string }>>(
  282 |                 await request.get(`/api/issues/${issue.id}/comments`),
  283 |               )
  284 |             )
  285 |               .map((c) => c.body)
  286 |               .join("\n"),
  287 |           { timeout: 60_000 },
  288 |         )
  289 |         .toContain(
  290 |           journey === "decline"
  291 |             ? "Review declined"
  292 |             : journey === "failure"
  293 |               ? "Read failed"
  294 |               : "Roadmap",
  295 |         );
  296 |       const replies = await json<Array<{ body: string; authorAgentId: string | null; createdByRunId: string | null }>>(await request.get(`/api/issues/${issue.id}/comments`));
  297 |       const reply = replies.find(comment => comment.authorAgentId === agent.id)!;
  298 |       expect(reply.createdByRunId).toBeTruthy();
  299 |       expect(originatingReview.sourceRunId).toBeTruthy();
  300 |       expect(reply.createdByRunId).not.toBe(originatingReview.sourceRunId);
  301 |       expect(reply.body).not.toContain('"content":');
  302 |       if (!["decline", "failure"].includes(journey)) {
  303 |         await expect(page.getByRole("button", { name: "Show result details" })).toBeVisible();
  304 |         await expect(page.locator("pre")).not.toBeVisible();
  305 |         await page.getByRole("button", { name: "Show result details" }).click();
  306 |         await expect(page.locator("pre")).toContainText('"content":');
  307 |         await page.getByRole("button", { name: "Hide result details" }).click();
  308 |       }
  309 |       expect(calls()).toBe(journey === "decline" ? 0 : 1);
  310 |       await expect(
  311 |         page.getByRole("button", { name: "Approve & run", exact: true }),
  312 |       ).not.toBeVisible();
  313 |       await expect(
  314 |         queue.getByRole("button", { name: "Decline", exact: true }),
  315 |       ).not.toBeVisible({ timeout: 20_000 });
  316 |       await page.reload();
  317 |       await expect(
  318 |         page
  319 |           .getByText(
  320 |             journey === "decline"
  321 |               ? "Declined"
  322 |               : journey === "failure"
  323 |                 ? "Execution failed"
  324 |                 : "Succeeded",
  325 |             { exact: false },
  326 |           )
  327 |           .first(),
> 328 |       ).toBeVisible();
      |         ^ Error: expect(locator).toBeVisible() failed
  329 |       await page.screenshot({
  330 |         path: testInfo.outputPath("resolved-review.png"),
  331 |       });
  332 |       if (journey === "always") {
  333 |         await configureAgent("different search options");
  334 |         const later = await json<{ id: string }>(
  335 |           await request.post(`/api/companies/${seed.companyId}/issues`, {
  336 |             data: {
  337 |               title: "Read pages with different arguments",
  338 |               status: "in_progress",
  339 |               assigneeAgentId: agent.id,
  340 |             },
  341 |           }),
  342 |         );
  343 |         await expect
  344 |           .poll(
  345 |             async () =>
  346 |               (
  347 |                 await json<Array<{ body: string }>>(
  348 |                   await request.get(`/api/issues/${later.id}/comments`),
  349 |                 )
  350 |               )
  351 |                 .map((c) => c.body)
  352 |                 .join("\n"),
  353 |             { timeout: 45_000 },
  354 |           )
  355 |           .toContain("Roadmap");
  356 |         expect(calls()).toBe(2);
  357 |         expect(
  358 |           await json<unknown[]>(
  359 |             await request.get(`/api/issues/${later.id}/interactions`),
  360 |           ),
  361 |         ).toHaveLength(0);
  362 |       }
  363 |       await testInfo.attach("journey", {
  364 |         body: JSON.stringify(
  365 |           {
  366 |             source: "local MCP fixture; no live Notion",
  367 |             journey,
  368 |             ...seed,
  369 |             issue,
  370 |             agent,
  371 |             providerCalls: calls(),
  372 |           },
  373 |           null,
  374 |           2,
  375 |         ),
  376 |         contentType: "application/json",
  377 |       });
  378 |       await queue.close();
  379 |     } finally {
  380 |       await provider.close();
  381 |     }
  382 |   });
  383 | }
  384 | 
```