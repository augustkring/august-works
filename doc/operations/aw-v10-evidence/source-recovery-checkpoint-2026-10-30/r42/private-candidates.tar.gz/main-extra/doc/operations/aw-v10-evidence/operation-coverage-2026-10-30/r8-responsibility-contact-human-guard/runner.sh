#!/usr/bin/env bash
set -uo pipefail
OUT=/workspace/v10-preparation/company-responsibility-contacts-human-owner-r3-20261030
MIRROR=/workspace/v10-dep-qualification
mkdir "$OUT"
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH
exec 9>/workspace/v10-preparation/v10-pg-tests.lock
flock -x 9
cd /workspace/blentera-v10
python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$OUT/source-pins.json" > "$OUT/snapshot.log" 2>&1
rc=$?; printf '%s\n' "$rc" > "$OUT/snapshot.exit"; [[ $rc -eq 0 ]] || exit "$rc"
node /workspace/v10-preparation/check-snapshot-syntax.cjs "$OUT/source-pins.json" > "$OUT/oxc.log" 2>&1
rc=$?; printf '%s\n' "$rc" > "$OUT/oxc.exit"; [[ $rc -eq 0 ]] || exit "$rc"
cd "$MIRROR/server"
timeout 300s ../node_modules/.bin/vitest run src/__tests__/company-branding-route.test.ts -t "responsibility contacts" --maxWorkers=1 --reporter=verbose > "$OUT/route-test.log" 2>&1
rc=$?; printf '%s\n' "$rc" > "$OUT/route-test.exit"
cd "$MIRROR"
python3 - "$OUT/source-pins.json" "$MIRROR" "$OUT/post-source-guard.json" <<'PY'
import hashlib,json,os,sys
pins=json.load(open(sys.argv[1])); root=sys.argv[2]; mismatches=[]
for row in pins.get('copiedFiles',[]):
 p=row['path']; f=os.path.join(root,p)
 ok=(not os.path.exists(f)) if row.get('deleted') else (os.path.isfile(f) and hashlib.sha256(open(f,'rb').read()).hexdigest()==row['sha256'])
 if not ok: mismatches.append(p)
json.dump({'status':'passed' if not mismatches else 'mismatch','copiedFiles':len(pins.get('copiedFiles',[])),'mismatches':mismatches},open(sys.argv[3],'w'),indent=2);open(sys.argv[3],'a').write('\n')
if mismatches: sys.exit(1)
PY
source_rc=$?; printf '%s\n' "$source_rc" > "$OUT/source-guard.exit"
printf 'route=%s source_guard=%s\n' "$rc" "$source_rc" > "$OUT/summary.txt"
[[ $rc -eq 0 && $source_rc -eq 0 ]]
