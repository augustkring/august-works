# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: aw-v9-experience.spec.ts >> feedback recovers an actually committed lost acknowledgement by reading its Original request
- Location: tests/e2e/aw-v9-experience.spec.ts:816:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('dialog').getByRole('alert')
Expected substring: "retry sends the same request"
Received string:    "Din feedback kunne ikke bekræftes. Den oprindelige tekst er låst; et genforsøg sender samme anmodning. Kontrollér Min feedback, før du starter en ny indsendelse."
Timeout: 5000ms

Call log:
  - Expect "toContainText" with timeout 5000ms
  - waiting for getByRole('dialog').getByRole('alert')
    13 × locator resolved to <p role="alert" tabindex="-1" class="outline-none">Din feedback kunne ikke bekræftes. Den oprindelig…</p>
       - unexpected value "Din feedback kunne ikke bekræftes. Den oprindelige tekst er låst; et genforsøg sender samme anmodning. Kontrollér Min feedback, før du starter en ny indsendelse."

```

```yaml
- alert: Din feedback kunne ikke bekræftes. Den oprindelige tekst er låst; et genforsøg sender samme anmodning. Kontrollér Min feedback, før du starter en ny indsendelse.
```

# Test source

```ts
  738 |     });
  739 |     await page.getByRole("button", { name: "Resume", exact: true }).click();
  740 |     await page
  741 |       .getByRole("button", { name: "Confirm resume", exact: true })
  742 |       .click();
  743 |     await expect(page.getByRole("dialog")).toContainText("This change could not be confirmed");
  744 |     await page.getByRole("button", { name: "Retry same request", exact: true }).click();
  745 |     await expectCurrentReceipt(/Resume confirmed for the original request/);
  746 |     expect(resumeChanges).toHaveLength(2);
  747 |     expect(resumeChanges[1]).toEqual(resumeChanges[0]);
  748 |     await page.unroute(lifecycleRoute);
  749 |     const resumed = await json(await request.get(`${base}/${created.id}`));
  750 |     expect(resumed.status).toBe("active");
  751 |     expect(resumed.publishedRevisionId).toBe(published.publishedRevisionId);
  752 |     expect(resumed.draftRevisionId).toBe(changed.draftRevisionId);
  753 |     await page
  754 |       .getByRole("link", { name: "Edit draft in Advanced", exact: true })
  755 |       .click();
  756 |     await expect(page).toHaveURL(new RegExp(`${path}/advanced$`));
  757 |     await expect(
  758 |       page.getByRole("button", { name: "Save draft", exact: true }),
  759 |     ).toBeVisible();
  760 |     await json(
  761 |       await request.patch("/api/instance/settings/experimental", {
  762 |         data: { progressive_shell_v9: false },
  763 |       }),
  764 |     );
  765 |     await page.goto(path);
  766 |     await expect(
  767 |       page.getByRole("button", { name: "Save draft", exact: true }),
  768 |     ).toBeVisible();
  769 |     await page.goto(runPath);
  770 |     await expect(
  771 |       page.getByRole("heading", { name: "Execution log", exact: true }),
  772 |     ).toBeVisible();
  773 |     await expect(
  774 |       page.getByRole("heading", { name: "Workflow run", exact: true }),
  775 |     ).toHaveCount(0);
  776 |     await json(
  777 |       await request.patch("/api/instance/settings/experimental", {
  778 |         data: { progressive_shell_v9: true },
  779 |       }),
  780 |     );
  781 |     await page.goto(path);
  782 |     await page.getByRole("button", { name: "Pause", exact: true }).click();
  783 |     await page
  784 |       .getByRole("button", { name: "Confirm pause", exact: true })
  785 |       .click();
  786 |     await expectCurrentReceipt(/Pause confirmed for the original request/);
  787 |     await page
  788 |       .getByRole("button", { name: "Retire workflow", exact: true })
  789 |       .click();
  790 |     await expect(page.getByRole("dialog")).toContainText(
  791 |       "Retirement is permanent",
  792 |     );
  793 |     await page
  794 |       .getByRole("button", { name: "Confirm retirement", exact: true })
  795 |       .click();
  796 |     await expectCurrentReceipt(/Retirement confirmed/);
  797 |     const retired = await json(await request.get(`${base}/${created.id}`));
  798 |     expect(retired.status).toBe("archived");
  799 |     expect(retired.draftRevisionId).toBeNull();
  800 |     expect(retired.publishedRevisionId).toBe(published.publishedRevisionId);
  801 |     await page.goto(runPath);
  802 |     await expect(
  803 |       page.getByRole("heading", { name: "Workflow run", exact: true }),
  804 |     ).toBeVisible();
  805 |     expect(errors).toEqual([]);
  806 |   } finally {
  807 |     await request.patch("/api/instance/settings/experimental", {
  808 |       data: Object.fromEntries(
  809 |         Object.keys(enabled).map((key) => [key, original[key]]),
  810 |       ),
  811 |     });
  812 |   }
  813 | });
  814 | 
  815 | 
  816 | test("feedback recovers an actually committed lost acknowledgement by reading its Original request", async ({ page, request }) => {
  817 |   const original = await json(await request.get("/api/instance/settings/experimental"));
  818 |   const session = await json(await request.get("/api/auth/get-session"));
  819 |   const expectedUserId = encodeURIComponent(session.user.id);
  820 |   const company = await json(await request.post("/api/companies", { data: { name: "Disposable committed feedback receipt fixture" } }));
  821 |   let posts = 0, committedId = "", requestKey = "";
  822 |   try {
  823 |     await json(await request.patch("/api/instance/settings/experimental", { data: {
  824 |       experience_projection_v9: true, progressive_shell_v9: true, home_v9: true, customer_feedback_v9: true,
  825 |     } }));
  826 |     await page.route(`**/api/companies/${company.id}/customer-feedback?*`, async route => {
  827 |       if (route.request().method() !== "POST") return route.continue();
  828 |       posts++; requestKey = route.request().postDataJSON().idempotencyKey;
  829 |       const response = await route.fetch(); expect(response.status()).toBe(201);
  830 |       committedId = (await response.json()).id;
  831 |       await route.abort("failed");
  832 |     });
  833 |     await page.goto(`/${company.issuePrefix}/dashboard`);
  834 |     const trigger = page.locator('[aria-label="Global utilities"]').getByRole("button", { name: "Feedback", exact: true });
  835 |     await trigger.click(); const dialog = page.getByRole("dialog");
  836 |     await dialog.getByRole("textbox").first().fill("Synthetic browser report whose canonical response is deliberately lost.");
  837 |     await dialog.getByRole("button", { name: "Send feedback", exact: true }).click();
> 838 |     await expect(dialog.getByRole("alert")).toContainText("retry sends the same request");
      |                                             ^ Error: expect(locator).toContainText(expected) failed
  839 |     expect(posts).toBe(1); expect(committedId).toBeTruthy();
  840 |     const response = page.waitForResponse(value => new URL(value.url()).pathname.endsWith(`/customer-feedback/requests/${requestKey}`));
  841 |     await dialog.getByRole("button", { name: "Check if received", exact: true }).click();
  842 |     expect((await response).headers()["cache-control"]).toBe("private, no-store");
  843 |     await expect(dialog.getByText("Thanks — feedback received", { exact: true })).toBeVisible();
  844 |     await expect(dialog.getByText("AWF-" + committedId.replaceAll("-", "").toUpperCase(), { exact: true })).toBeVisible();
  845 |     expect(posts).toBe(1);
  846 |     const history = await json(await request.get(`/api/companies/${company.id}/customer-feedback?expectedUserId=${expectedUserId}`));
  847 |     expect(history).toHaveLength(1); expect(history[0].id).toBe(committedId);
  848 |   } finally {
  849 |     await json(await request.patch("/api/instance/settings/experimental", { data: original }));
  850 |     await json(await request.delete(`/api/companies/${company.id}`));
  851 |   }
  852 | });
  853 | 
```