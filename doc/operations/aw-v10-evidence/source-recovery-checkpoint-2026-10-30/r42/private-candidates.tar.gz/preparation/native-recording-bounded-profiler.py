from pathlib import Path
p=Path('/workspace/blentera-v10/server/src/services/native-direct-input.ts');s=p.read_text()
s=s.replace('interface NativeSourceReadAncestry { work: number;', 'interface NativeSourceReadAncestry { work: number; workByCaller: Record<string, number>;',1)
s=s.replace('const nativeSourceMemoDiagnostics = { siblingToolSourceProofHits:', 'const nativeSourceMemoDiagnostics = {\n  lastWorkOverflow: null as { work: number; counts: Record<string, number> } | null,\n  graphProofKinds: {} as Record<string, { hits: number; misses: number }>, siblingToolSourceProofHits:',1)
s=s.replace('  nativeSourceMemoDiagnostics.frozenTaskMemoByKind = {};','  nativeSourceMemoDiagnostics.frozenTaskMemoByKind = {};\n  nativeSourceMemoDiagnostics.lastWorkOverflow = null;\n  nativeSourceMemoDiagnostics.graphProofKinds = {};',1)
s=s.replace('return { work: 0, activeByActor:', 'return { work: 0, workByCaller: {}, activeByActor:',1)
a=s.index('function nativeSourceReadWork(');b=s.index('\nfunction mergeNativeFrozenTaskProofMaps',a)
s=s[:a]+'''function nativeSourceReadWork(scope: NativeSourceReadScope) {
  if (nativeSourceMemoDiagnosticsEnabled()) {
    const caller = new Error().stack?.split("\\n")[2]?.match(/at ([A-Za-z0-9_.]+) /)?.[1] ?? "source-reader";
    const counts = scope.context.ancestry.workByCaller;
    if (Object.keys(counts).length < 32 || Object.hasOwn(counts, caller)) counts[caller] = (counts[caller] ?? 0) + 1;
  }
  if (++scope.context.ancestry.work > 512) {
    if (nativeSourceMemoDiagnosticsEnabled()) nativeSourceMemoDiagnostics.lastWorkOverflow = {
      work: scope.context.ancestry.work, counts: { ...scope.context.ancestry.workByCaller } };
    throw forbidden("The Native source graph exceeds its total-work bound");
  }
}
'''+s[b:]
needle='''  const proof = eligible ? proofs.get(key) : undefined;
  let stack'''
replacement='''  const proof = eligible ? proofs.get(key) : undefined;
  if (nativeSourceMemoDiagnosticsEnabled()) {
    const kind = key.split(":", 1)[0]!;
    if (Object.keys(nativeSourceMemoDiagnostics.graphProofKinds).length < 16 ||
      Object.hasOwn(nativeSourceMemoDiagnostics.graphProofKinds, kind)) {
      const stats = nativeSourceMemoDiagnostics.graphProofKinds[kind] ??= { hits: 0, misses: 0 };
      const outcome = proof && !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, proof.descendants) ? "hits" : "misses";
      stats[outcome] = Math.min(1_000_000, stats[outcome] + 1);
    }
  }
  let stack'''
assert s.count(needle)==1;s=s.replace(needle,replacement,1)
p.with_suffix('.recordprofile.tmp.ts').write_text(s)
p=Path('/workspace/blentera-v10/server/src/__tests__/native-payload-temporal-sources.integration.test.ts');s=p.read_text();needle='''    temporal = await buildTemporalFixture();''';replacement='''    try {
      temporal = await buildTemporalFixture();
    } catch (error) {
      if (process.env.PAPERCLIP_NATIVE_TEST_TOOL_RESULT_DIAGNOSTICS === "1") {
        const stats = nativeSourceMemoDiagnosticsForTest();
        console.error("native_graph_fixture_bounded_failure", JSON.stringify({ overflow: stats.lastWorkOverflow,
          graphProofKinds: stats.graphProofKinds, toolHits: stats.siblingToolSourceProofHits, documentHits: stats.documentNodeHits }));
      }
      throw error;
    }''';assert s.count(needle)==1;s=s.replace(needle,replacement);p.with_suffix('.recordprofile.tmp.ts').write_text(s)
