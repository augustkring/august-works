# R3 reporting controls — prepared only

The frozen R2 three-file candidate remains byte-identical to the verified R84 backup. This runner does not install it in Main or change any real suite. Current Main guard is003404c031dad874db43aa1ad8c07e80568bdd17. The old c80 candidate workflow is hash-checked/static only, not executed or claimed compatible with current003; a future reporting workflow composition must preserve kernel control SHA9654.

This is one small Python controller under canonical flock. It creates only tiny synthetic workspaces, copied candidate runner/reporter and four existing shard helper/data inputs. Node dependency entries are read-only symlinks inside a real private node_modules directory, so Vite's temporary config files cannot land in the shared dependency root. Vite caches, Node compile cache and package-manager cache stay private/disabled; there are no installs, builds, DBs, SDKs, browsers or paid calls.

Actual controls are finite:

1. Existing run-vitest-stable workspace-a entry runs one real UI-named synthetic module, then one real CLI-named synthetic module in two actual child Vitest invocations. Both pass; native JSON/lifecycle/final run/actual parent exit agree. Real worker metadata observes notice budgets20 then19. Output directories differ and later runs cannot overwrite either result.
2. One passing case with failing afterAll runs through the actual runner/server group. Native case remains passed, native module and lifecycle fail with the sentinel module error, final run fails and actual parent exit is nonzero. No body-pass→teardown-pass shortcut.
3. One owned Vitest worker first has an ordinary body then self-SIGKILLs. The actual parent must be nonzero, the crashed module cannot have a passed lifecycle and final/unhandled result cannot imply a complete successful run. The test never signals an unrelated PID.
4. No-reporting dry-run selectors from original and candidate runner match exactly. One real one-file candidate Vitest invocation then passes with reporting env absent, no new report directory and no reporter module load. This establishes actual opt-in/default behavior for the synthetic fixture only.

A separate small Node pure check imports the exact reporter exports: seven fixed failed-case data rows check five-name truncation, control-character/workflow escaping and pending-process wording. Fixed public task/module data then exercises the actual reporter cap branch with budget3 and five events; exactly two module notices plus one truncation notice are allowed, all five records remain, and invalid budget21 rejects. These fabricated formatter/cap records live outside actual result directories and are never counted as real Vitest case passes or any business/Host/source authority.

Source provenance uses a Node preload for the exact executed runner and unchanged native module-load/Vite transform observation for the exact reporter. Both validate private realpaths+SHA. All generated JSONL writers explicitly use String.fromCharCode(10), removing the reviewed Python/JS escape ambiguity. Completion requires actual newline-framed JSONL parsing and candidate runtime records, plus all input/copy hashes unchanged. The third workflow path is explicitly static provenance only.

Bounds: original Root120000KiB/TMP1048576KiB floors before and after preparation; Node heap512MiB; one owned process group at a time; controller+group total RSS ceiling768MiB; total60s including preparations/commands, then only-owned TERM2s/KILL3s/finalwait. No retries. Main HEAD/cleanliness/named sources, frozen R2 and all copies are checked afterward, together with unchanged cgroup memory events. Partial/nonzero results remain evidence, not invented success.

Only Python syntax and generated Node syntax/AST checks have run. The actual control runner has NOT run. Root must review this exact runner before GO.

This immutable runner-r2 successor differs only by the approved actual unset one-file invocation and its no-reporter-load assertion. Earlier R3 runner/pins remain unchanged.
