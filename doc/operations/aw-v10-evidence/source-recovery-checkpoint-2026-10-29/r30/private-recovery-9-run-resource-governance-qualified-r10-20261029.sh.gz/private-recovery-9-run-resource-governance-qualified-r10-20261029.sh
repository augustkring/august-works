#!/usr/bin/env bash
set -euo pipefail
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH GOMEMLIMIT=1536MiB GOGC=50
out=/workspace/v10-preparation/resource-governance-qualified-r10-20261029
main=/workspace/blentera-v10
mirror=/workspace/v10-dep-qualification
overlay=/workspace/v10-preparation/b-resource-0564-schema-overlay-20261029
companion=/workspace/v10-preparation/b-resource-governance-current.sql
mkdir "$out"
# Cargo links in both workspaces target this regenerable cache location.
mkdir -p /tmp/blentera-preserved-current-rust-target
trap 'rc=$?; printf "%s\n" "$rc" > "$out/exit"; exit "$rc"' EXIT
python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$out/source-pins.json" > "$out/snapshot.log" 2>&1
python3 - "$main" "$mirror" "$overlay" "$out" <<'PY'
import pathlib,sys,json,hashlib,shutil
main,mirror,overlay,out=map(pathlib.Path,sys.argv[1:]); manifest=json.loads((overlay/'manifest.json').read_text())
for x in manifest:
 p=main/x['path']; assert hashlib.sha256(p.read_bytes()).hexdigest()==x['shelvedMainSha256'],('source changed since overlay review',x['path'])
 src=overlay/x['path']; assert hashlib.sha256(src.read_bytes()).hexdigest()==x['overlaySha256'],('overlay checksum mismatch',x['path'])
 dest=mirror/x['path']; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src,dest)
(out/'overlay-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
resource_paths=[
 'packages/shared/src/resource-governance.ts','packages/shared/src/resource-governance.test.ts','packages/shared/src/index.ts','packages/shared/src/validators/instance.ts',
 'packages/db/src/schema/index.ts','packages/db/src/schema/heartbeat_runs.ts','packages/db/src/schema/heartbeat_run_events.ts',
 'packages/db/src/schema/native_run_finalizations.ts','packages/db/src/schema/environment_leases.ts','packages/db/src/schema/workflows.ts','packages/db/src/schema/memory_jobs.ts',
 'server/src/errors.ts','server/src/middleware/error-handler.ts','server/src/routes/instance-settings.ts','server/src/services/authorization.ts',
 'server/src/services/execution-blocker.ts','server/src/services/heartbeat.ts','server/src/services/instance-settings.ts',
 'server/src/services/resource-governance.ts','server/src/services/tool-gateway.ts','server/src/services/memory/memory-jobs.ts',
 'server/src/services/memory/memory-privacy.ts','server/src/services/memory/memory-retrieval.ts','server/src/services/workflows/workflow-executor.ts',
 'server/src/services/workflows/workflow-native-nodes.ts','server/src/__tests__/resource-governance.integration.test.ts',
 'server/src/__tests__/tool-gateway.test.ts','server/src/__tests__/helpers/embedded-postgres.ts','server/src/__tests__/helpers/current-human-source-fixture.ts']
pre={}
overlay_paths={x['path'] for x in manifest}
for rel in resource_paths:
 p=main/rel; mirrored=mirror/rel
 if p.is_file():
  pre[rel]=hashlib.sha256(p.read_bytes()).hexdigest()
  if rel not in overlay_paths: assert mirrored.is_file() and hashlib.sha256(mirrored.read_bytes()).hexdigest()==pre[rel],('resource source differs from qualification snapshot',rel)
 else:
  pre[rel]=None
  if rel not in overlay_paths: assert not mirrored.exists(),('resource source absence differs from qualification snapshot',rel)
(out/'resource-source-preconditions.json').write_text(json.dumps(pre,indent=2)+'\n')
syntax_pins=json.loads((out/'source-pins.json').read_text())
syntax_pins['copiedFiles']=[{'path':rel} for rel in resource_paths if (mirror/rel).is_file()]
for x in manifest:
 if x['path'].endswith(('.ts','.tsx','.js','.jsx')) and not any(i['path']==x['path'] for i in syntax_pins['copiedFiles']): syntax_pins['copiedFiles'].append({'path':x['path']})
(out/'resource-syntax-pins.json').write_text(json.dumps(syntax_pins,indent=2)+'\n')
(out/'source-before-migrations.json').write_text(json.dumps({str(p.relative_to(main)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (main/'packages/db/src/migrations').rglob('*') if p.is_file()},indent=2)+'\n')
for p in sorted((main/'packages/db/src/migrations/meta').glob('*_snapshot.json')):
 dst=out/'source-snapshots-before'/p.name; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(p,dst)
 assert hashlib.sha256(p.read_bytes()).hexdigest()==hashlib.sha256(dst.read_bytes()).hexdigest()
PY
node /workspace/v10-preparation/check-snapshot-syntax.cjs "$out/resource-syntax-pins.json" > "$out/syntax.log" 2>&1
cp "$companion" "$out/companion.sql"
sha256sum "$out/companion.sql" > "$out/companion.sha256"
cd "$mirror"
pnpm --filter @paperclipai/db generate > "$out/generate.log" 2>&1
python3 - "$mirror" "$out" <<'PY'
import pathlib,sys,json,shutil
root,out=map(pathlib.Path,sys.argv[1:]); m=root/'packages/db/src/migrations'; j=json.loads((m/'meta/_journal.json').read_text()); e=j['entries'][-1]; assert e['idx']==564,e
sql=m/(e['tag']+'.sql'); assert sql.exists(); generated=sql.read_bytes(); (out/'generated.sql').write_bytes(generated)
preamble=b"-- Bounded Resource governance cutover; drain Native heartbeat/event writers. Any failure rolls the whole migration back without a journal row.\nSET LOCAL lock_timeout='5s';\n--> statement-breakpoint\nSET LOCAL statement_timeout='30s';\n--> statement-breakpoint\nLOCK TABLE heartbeat_runs IN ACCESS EXCLUSIVE MODE;\n--> statement-breakpoint\nLOCK TABLE heartbeat_run_events IN SHARE ROW EXCLUSIVE MODE NOWAIT;\n--> statement-breakpoint\n"
assembled=preamble+generated+b'\n--> statement-breakpoint\n'+(out/'companion.sql').read_bytes()
sql.write_bytes(assembled); (out/'assembled.sql').write_bytes(assembled)
(out/'migration-tag').write_text(e['tag']+'\n')
snap=m/'meta/0564_snapshot.json'; assert snap.exists(); shutil.copyfile(snap,out/'snapshot-0564.json')
PY
python3 - "$mirror" "$out" <<'PY2'
import pathlib,sys,json,hashlib
root,out=map(pathlib.Path,sys.argv[1:]); pins=json.loads((out/'source-pins.json').read_text()); rows=[]
source_before=json.loads((out/'source-before-migrations.json').read_text())
pruned=sorted(rel for rel in source_before if rel.endswith('_snapshot.json') and not (root/rel).exists())
for item in pins['copiedFiles']:
 rel=item['path']; p=root/rel
 if item.get('deleted'):
  assert not p.exists(),('deleted source unexpectedly present',rel); rows.append({'path':rel,'deleted':True}); continue
 if rel in pruned:
  rows.append({'path':rel,'deletedByDrizzleSnapshotPrune':True,'sourceSha256':source_before[rel]}); continue
 assert p.is_file(),('missing source in executed mirror',rel)
 rows.append({'path':rel,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
tag=(out/'migration-tag').read_text().strip(); migrations=root/'packages/db/src/migrations'
for p in [migrations/(tag+'.sql'),migrations/'meta/_journal.json',migrations/'meta/0564_snapshot.json']:
 assert p.is_file(),str(p); rows.append({'path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
for item in json.loads((out/'overlay-manifest.json').read_text()):
 p=root/item['path']; rows.append({'path':item['path'],'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'overlay':True})
(out/'qualified-tree-source-pins.json').write_text(json.dumps({'qualificationBaseCommit':pins['qualificationBaseCommit'],'sourceHead':pins['sourceHead'],'qualifiedWorkspace':str(root),'preOverlaySourcePinsSha256':hashlib.sha256((out/'source-pins.json').read_bytes()).hexdigest(),'overlayManifestSha256':hashlib.sha256((out/'overlay-manifest.json').read_bytes()).hexdigest(),'companionSqlSha256':hashlib.sha256((out/'companion.sql').read_bytes()).hexdigest(),'prunedSnapshots':pruned,'copiedFiles':rows},indent=2)+'\n')
PY2
# Preserve the exact post-overlay/post-generation source state as a patch against
# the qualification base, including newly created migration and untracked source.
python3 - "$mirror" "$out" <<'PY2'
import pathlib,sys,subprocess,os,tempfile,json,hashlib
root,out=map(pathlib.Path,sys.argv[1:]); pins=json.loads((out/'source-pins.json').read_text()); base=pins['qualificationBaseCommit']
fd,name=tempfile.mkstemp(prefix='resource-qualified-index-',dir='/workspace/v10-preparation'); os.close(fd); pathlib.Path(name).unlink(missing_ok=True)
env={**os.environ,'GIT_INDEX_FILE':name}
try:
 subprocess.run(['git','read-tree',base],cwd=root,env=env,check=True)
 subprocess.run(['git','add','-A','--','.',':(exclude)doc/operations/'],cwd=root,env=env,check=True)
 patch=subprocess.check_output(['git','diff','--cached','--binary',base,'--','.',':(exclude)doc/operations/'],cwd=root,env=env)
finally: pathlib.Path(name).unlink(missing_ok=True)
(out/'qualified-source.patch').write_bytes(patch)
tracked=set(subprocess.check_output(['git','ls-tree','-r','--name-only',base],cwd=root,text=True).splitlines())
new=[]
pruned=set(json.loads((out/'qualified-tree-source-pins.json').read_text()).get('prunedSnapshots',[]))
extra=[x['path'] for x in pins['copiedFiles'] if not x.get('deleted') and x['path'] not in pruned]
tag=(out/'migration-tag').read_text().strip(); extra += ['packages/db/src/migrations/'+tag+'.sql','packages/db/src/migrations/meta/0564_snapshot.json']
for rel in sorted(set(extra)):
 p=root/rel
 if rel in tracked or not p.is_file(): continue
 dst=out/'qualified-untracked-source-files'/rel; dst.parent.mkdir(parents=True,exist_ok=True); dst.write_bytes(p.read_bytes())
 new.append({'path':rel,'preservedAt':str(dst),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'qualified-untracked-source-files.json').write_text(json.dumps(new,indent=2)+'\n')
PY2
pnpm --filter @paperclipai/db check:migrations > "$out/migration-check.log" 2>&1
pnpm --filter @paperclipai/db build > "$out/db-build.log" 2>&1
pnpm --filter @paperclipai/shared typecheck > "$out/shared-typecheck.log" 2>&1
node_modules/.bin/vitest run packages/shared/src/resource-governance.test.ts --reporter=verbose > "$out/shared-test.log" 2>&1
cat > "$out/preflight.mts" <<'MJS'
import fs from "node:fs";
import { createRequire } from "node:module";
const require = createRequire("/workspace/v10-dep-qualification/packages/db/package.json");
const postgres = require("postgres");
import { __startEmbeddedPostgresWithRetryForTests } from "/workspace/v10-dep-qualification/packages/db/src/test-embedded-postgres.ts";
const source = fs.readFileSync("/workspace/v10-preparation/b-resource-governance-current.sql", "utf8");
const functionSql = source.split("\n--> statement-breakpoint\n", 1)[0];
const { port, dataDir, instance } = await __startEmbeddedPostgresWithRetryForTests("resource-sql-preflight-");
const client = postgres(`postgres://paperclip:paperclip@127.0.0.1:${port}/postgres`);
try { await client.unsafe(functionSql); console.log("policy validation function parsed by embedded PostgreSQL"); }
finally {
  await client.end();
  await instance.stop().catch(() => {});
  fs.rmSync(dataDir, { recursive: true, force: true });
}
MJS
packages/db/node_modules/.bin/tsx "$out/preflight.mts" > "$out/sql-preflight.log" 2>&1
node_modules/.bin/vitest run server/src/__tests__/resource-governance.integration.test.ts --reporter=verbose > "$out/resource-pg-test.log" 2>&1
node_modules/.bin/vitest run server/src/__tests__/tool-gateway.test.ts -t 'shares configured company request and burst counters' --reporter=verbose > "$out/gateway-test.log" 2>&1
pnpm --filter @paperclipai/server typecheck > "$out/server-typecheck.log" 2>&1
du -sb /tmp/blentera-preserved-current-rust-target > "$out/rust-target-bytes.txt"
python3 - "$main" "$mirror" "$out" "$overlay" <<'PY'
import pathlib,sys,json,hashlib,os
main,mirror,out,overlay=map(pathlib.Path,sys.argv[1:]); before=json.loads((out/'source-before-migrations.json').read_text())
pins=json.loads((out/'source-pins.json').read_text()); overlay_manifest=json.loads((out/'overlay-manifest.json').read_text()); overlays={x['path'] for x in overlay_manifest}
qualified=json.loads((out/'qualified-tree-source-pins.json').read_text())
for item in qualified['copiedFiles']:
 p=mirror/item['path']
 if item.get('deleted') or item.get('deletedByDrizzleSnapshotPrune'):
  assert not p.exists(),('qualified deleted path reappeared',item['path'])
 else:
  assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],('qualified mirror source changed after pin',item['path'])
for x in overlay_manifest:
 assert hashlib.sha256((main/x['path']).read_bytes()).hexdigest()==x['shelvedMainSha256'],('overlay source changed during qualification',x['path'])
for rel,sha in json.loads((out/'resource-source-preconditions.json').read_text()).items():
 p=main/rel
 assert (not p.exists()) if sha is None else (p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==sha),('resource source changed during qualification',rel)
for rel,sha in before.items(): assert hashlib.sha256((main/rel).read_bytes()).hexdigest()==sha,('main migration source changed during qualification',rel)
tag=(out/'migration-tag').read_text().strip(); base=pathlib.Path('packages/db/src/migrations/')
pruned=json.loads((out/'qualified-tree-source-pins.json').read_text()).get('prunedSnapshots',[])
rels=[base/(tag+'.sql'),base/'meta/_journal.json',base/'meta/0564_snapshot.json'] + [pathlib.Path(p) for p in pruned]
for x in json.loads((out/'overlay-manifest.json').read_text()): rels.append(pathlib.Path(x['path']))
stage=out/'publish-staging'; stage.mkdir()
for rel in rels:
 src=mirror/rel; dst=stage/rel; dst.parent.mkdir(parents=True,exist_ok=True)
 if rel.as_posix() in pruned:
  assert not src.exists(),('snapshot should be pruned by official Drizzle generation',str(rel)); continue
 assert src.is_file(),str(src); dst.write_bytes(src.read_bytes())
# Publish only after all mirror checks passed; every destination is replaced from a complete staged file under this shared flock.
manifest=[]
for rel in rels:
 dst=main/rel
 if rel.as_posix() in pruned:
  assert dst.is_file() and hashlib.sha256(dst.read_bytes()).hexdigest()==before[str(rel)],('source snapshot changed before official prune',str(rel)); dst.unlink(); manifest.append({'path':str(rel),'deleted':True}); continue
 src=stage/rel; dst.parent.mkdir(parents=True,exist_ok=True); tmp=dst.with_name(dst.name+'.resource-governance-r10-tmp'); tmp.write_bytes(src.read_bytes()); os.replace(tmp,dst)
 manifest.append({'path':str(rel),'sha256':hashlib.sha256(dst.read_bytes()).hexdigest()})
(out/'published-files.json').write_text(json.dumps(manifest,indent=2)+'\n')
PY
trap - EXIT
printf '0\n' > "$out/exit"
