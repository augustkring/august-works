# Docker quota source verification (read-only research)

Checked 2026-10-30:

- Docker official CLI reference: https://docs.docker.com/reference/cli/docker/container/run/ — `--storage-opt` documents per-container storage driver options; the `size` option is supported for `btrfs`, `overlay2`, `windowsfilter`, and `zfs`. For `overlay2`, Docker requires an XFS backing filesystem mounted with `pquota`.
- Bollard 0.20.2 API docs: https://docs.rs/bollard/0.20.2/bollard/models/struct.HostConfig.html — `HostConfig.storage_opt` is `Option<HashMap<String, String>>` and its field docs show `{"size": "120G"}`.
- Moby overlay2 source (read-only corroboration): `CreateReadWrite` rejects `size` unless project quota is supported; initialization requires XFS and a working quota control for a configured size; `Create` sets the per-layer project quota. The host code still requires target-host exhaustion/restart probes before any capability is enabled.

Scope used by this candidate is narrower than Docker's general driver list: the selected V7 profile requires `overlay2`, XFS backing, successful exact create-time size option, and no user-writable external mounts. It does not claim btrfs/zfs support or infer physical enforcement from this documentation.
