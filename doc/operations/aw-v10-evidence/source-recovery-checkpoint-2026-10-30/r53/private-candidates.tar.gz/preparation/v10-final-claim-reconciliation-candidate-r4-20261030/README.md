# V10 final claim reconciliation candidate R4

Private, interim R4 candidate. It preserves the original 169 historical V10 statuses and V6–V9 predecessor records; the historical register is not promoted by this update. The semantic predecessor links remain only the three V7 blocker links to V10-149.

R4 adds the exact OpenShell R6.1 software receipt (run 41051549768, source head `4f7894452d67dc76d7349c940217bdb0be39fb40`, 18 focused tests passed, zero skipped, four Rust packages checked) and a current source review of V10-149 RT-03 provider paths. The review identifies a remaining forced-pre-spend software gap for direct Native Codex, Claude Managed Agents API and AWS AgentCore paths if they are admitted as managed hard-budget workloads. Existing plan/company-purpose reservation paths and the specific managed OpenCode gateway are source-backed. The new review is read-only and pins the dirty source snapshot; it does not claim end-to-end provider qualification.

RT-01 remains unqualified for physical Docker/kernel/runtime enforcement. Native full-nine and whole aggregate remain pending; Human/operator, hosted, production and release-profile decisions remain open. R6.1 is software-only and does not close RT-03. The Resource memory probe direct-exec fix is a private R14.6 candidate awaiting its regression and receipt, not current repository closure.

R4 current source pins are interim because the repository worktree was dirty at review time. Refresh all source pins, generated outputs, and checksums after Native and shared source lanes freeze. This candidate is not V10-149 closure, a global-green report, deployment authorization, or Human/release acceptance.
