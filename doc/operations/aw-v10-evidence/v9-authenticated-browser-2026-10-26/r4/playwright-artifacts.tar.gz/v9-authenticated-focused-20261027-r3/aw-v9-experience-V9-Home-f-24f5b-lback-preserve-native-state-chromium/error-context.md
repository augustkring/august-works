# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: aw-v9-experience.spec.ts >> V9 Home, feedback recovery and rollback preserve native state
- Location: tests/e2e/aw-v9-experience.spec.ts:17:1

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator: getByRole('dialog').getByRole('combobox', { name: 'Search or enter a command' })
Expected: focused
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeFocused" with timeout 5000ms
  - waiting for getByRole('dialog').getByRole('combobox', { name: 'Search or enter a command' })

```

```yaml
- link "Skip to Main Content":
  - /url: "#main-content"
- complementary:
  - button "Open V9 disposable browser company organization switcher": V V9 disposable browser company
  - navigation:
    - text: View
    - combobox "View":
      - option "Member"
      - option "Manager" [selected]
      - option "Admin"
      - option "Security admin"
    - link "Home":
      - /url: /VDI/dashboard
    - link "Needs You":
      - /url: /VDI/needs-you
    - link "Work":
      - /url: /VDI/work
    - link "Agents":
      - /url: /VDI/agents
    - link "Apps":
      - /url: /VDI/apps
    - link "Insights":
      - /url: /VDI/insights
    - link "Advanced":
      - /url: /VDI/advanced
    - button "Ask Blentera"
    - link "Help / Support":
      - /url: /VDI/company/help
- button "Open account menu": BR Browser product reviewer
- button "Feedback"
- separator "Resize sidebar"
- region "Global utilities":
  - button "Ask Blentera"
  - text: Language
  - combobox "Language":
    - option "English" [selected]
    - option "Dansk"
  - button "Feedback"
  - link "Help / Support":
    - /url: /VDI/company/help
  - link "Contact support":
    - /url: mailto:support@blentera.com
  - link "User account":
    - /url: /VDI/company/settings/instance/profile
- main:
  - heading "Home" [level=1]
  - button "Ask Blentera"
  - paragraph: Nothing needs your attention right now.
```

# Test source

```ts
  62  |       page.getByRole("heading", { name: "Home", exact: true }),
  63  |     ).toBeVisible();
  64  |     await expect(
  65  |       page.getByRole("heading", { name: "Home", exact: true }),
  66  |     ).toBeFocused();
  67  |     // The built Home entry must not fetch setup, triage or private history pages.
  68  |     // This checks real browser imports, not a mocked lazy component.
  69  |     expect(requestedPageChunks).toEqual([]);
  70  |     await expect(
  71  |       page.getByText("Nothing needs your attention right now.", {
  72  |         exact: true,
  73  |       }),
  74  |     ).toBeVisible();
  75  |     const projection = await json(
  76  |       await request.get(`${base}/experience?expectedUserId=${expectedUserId}`),
  77  |     );
  78  |     expect(projection.companyId).toBe(company.id);
  79  |     expect(projection.needsYou).toEqual([]);
  80  |     await page.goto(`/${company.issuePrefix}/needs-you`);
  81  |     await expect(
  82  |       page.getByRole("heading", { name: "Needs You", exact: true }),
  83  |     ).toBeVisible();
  84  |     await expect(
  85  |       page.getByRole("heading", { name: "Needs You", exact: true }),
  86  |     ).toBeFocused();
  87  |     await expect(
  88  |       page.getByText("Nothing needs your action in the current queue.", {
  89  |         exact: true,
  90  |       }),
  91  |     ).toBeVisible();
  92  |     await page
  93  |       .getByRole("link", { name: "Open full queue", exact: true })
  94  |       .click();
  95  |     await expect(page).toHaveURL(
  96  |       new RegExp(`/${company.issuePrefix}/decisions$`),
  97  |     );
  98  |     await page.goto(`/${company.issuePrefix}/work`);
  99  |     await expect(
  100 |       page.getByRole("heading", { name: "Work", exact: true }),
  101 |     ).toBeVisible();
  102 |     await expect(
  103 |       page.getByRole("heading", { name: "Work", exact: true }),
  104 |     ).toBeFocused();
  105 |     const workOwners = page.getByRole("navigation", {
  106 |       name: "Company work",
  107 |       exact: true,
  108 |     });
  109 |     for (const [label, path] of [
  110 |       ["Projects", "projects"],
  111 |       ["Tasks", "issues"],
  112 |       ["Routines", "routines"],
  113 |     ]) {
  114 |       await expect(
  115 |         workOwners.getByRole("link", { name: label, exact: true }),
  116 |       ).toHaveAttribute("href", `/${company.issuePrefix}/${path}`);
  117 |     }
  118 |     await expect(
  119 |       page.getByText(
  120 |         "No current tasks appear in this view. Open Tasks or Projects to review other work.",
  121 |         { exact: true },
  122 |       ),
  123 |     ).toBeVisible();
  124 |     await page.goto(`/${company.issuePrefix}/dashboard`);
  125 |     await expect(
  126 |       page.getByRole("heading", { name: "Home", exact: true }),
  127 |     ).toBeVisible();
  128 |     const homeEndpoint = `**/api/companies/${company.id}/experience?*`;
  129 |     await page.route(homeEndpoint, (route) =>
  130 |       route.fulfill({ status: 503, json: { error: "Temporary test outage" } }),
  131 |     );
  132 |     await page.reload();
  133 |     await expect(
  134 |       page.getByRole("alert").filter({ hasText: "Home could not be loaded" }),
  135 |     ).toBeVisible();
  136 |     await expect(
  137 |       page.getByRole("alert").filter({ hasText: "Home could not be loaded" }),
  138 |     ).toBeFocused();
  139 |     await expect(
  140 |       page.getByText("Nothing needs your attention right now.", {
  141 |         exact: true,
  142 |       }),
  143 |     ).toHaveCount(0);
  144 |     await page.unroute(homeEndpoint);
  145 |     await page.getByRole("button", { name: "Try again", exact: true }).click();
  146 |     await expect(
  147 |       page.getByRole("heading", { name: "Home", exact: true }),
  148 |     ).toBeVisible();
  149 |     await expect(
  150 |       page.getByRole("heading", { name: "Home", exact: true }),
  151 |     ).toBeFocused();
  152 |     const trigger = page
  153 |       .locator('[aria-label="Global utilities"]')
  154 |       .getByRole("button", { name: "Feedback", exact: true });
  155 |     const ask = page
  156 |       .locator('[aria-label="Global utilities"]')
  157 |       .getByRole("button", { name: "Ask Blentera", exact: true });
  158 |     await ask.click();
  159 |     let commands = page.getByRole("dialog");
  160 |     await expect(
  161 |       commands.getByRole("combobox", { name: "Search or enter a command" }),
> 162 |     ).toBeFocused();
      |       ^ Error: expect(locator).toBeFocused() failed
  163 |     await commands
  164 |       .getByRole("combobox")
  165 |       .fill("create workflow Send outreach every Monday");
  166 |     await expect(
  167 |       commands.getByText(/no model request or action has been sent/),
  168 |     ).toBeVisible();
  169 |     await page.keyboard.press("Escape");
  170 |     await expect(ask).toBeFocused();
  171 |     await page.keyboard.press("Control+k");
  172 |     commands = page.getByRole("dialog");
  173 |     await commands
  174 |       .getByRole("combobox")
  175 |       .fill("create task Browser typed draft");
  176 |     await commands
  177 |       .getByRole("option", { name: "Prepare a Task", exact: true })
  178 |       .click();
  179 |     await expect(
  180 |       page.getByRole("dialog").getByRole("textbox").first(),
  181 |     ).toHaveValue("Browser typed draft");
  182 |     expect((await json(await request.get(`${base}/issues`))).length).toBe(0);
  183 |     await page.keyboard.press("Escape");
  184 |     const feedbackPage = page.url();
  185 |     await page.goto(`/${company.issuePrefix}/company/settings`);
  186 |     await expect(
  187 |       page.getByRole("heading", { name: "Company", exact: true }),
  188 |     ).toBeFocused();
  189 |     await page
  190 |       .getByRole("searchbox", { name: "Search company settings", exact: true })
  191 |       .fill("team invites");
  192 |     await expect(
  193 |       page.getByRole("link", { name: "Members and invitations", exact: true }),
  194 |     ).toBeVisible();
  195 |     await expect(
  196 |       page.getByText("1 setting matches.", { exact: true }),
  197 |     ).toBeVisible();
  198 |     await expect(
  199 |       page.getByText(
  200 |         "Restricted access. Permissions are checked when opened.",
  201 |         { exact: true },
  202 |       ),
  203 |     ).toBeVisible();
  204 |     await page.goto(feedbackPage);
  205 |     await trigger.click();
  206 |     const dialog = page.getByRole("dialog");
  207 |     await expect(dialog.getByRole("combobox")).toBeFocused();
  208 |     for (const address of [
  209 |       "support@blentera.com",
  210 |       "privacy@blentera.com",
  211 |       "security@blentera.com",
  212 |     ])
  213 |       await expect(dialog.locator(`a[href="mailto:${address}"]`)).toHaveCount(
  214 |         1,
  215 |       );
  216 |     const localDraft = "Disposable unsent browser draft for explicit discard";
  217 |     await dialog.getByRole("textbox").first().fill(localDraft);
  218 |     await dialog.getByRole("combobox").selectOption("IDEA");
  219 |     await dialog.getByRole("button", { name: "Cancel", exact: true }).click();
  220 |     await expect(trigger).toBeFocused(); await trigger.click();
  221 |     await expect(dialog.getByRole("textbox").first()).toHaveValue(localDraft);
  222 |     await expect(dialog.getByRole("combobox")).toHaveValue("IDEA");
  223 |     await page.setViewportSize({ width: 390, height: 844 });
  224 |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  225 |     const discard = dialog.getByRole("button", { name: "Discard draft", exact: true });
  226 |     await discard.focus(); await page.keyboard.press("Enter");
  227 |     await expect(dialog).toHaveCount(0);
  228 |     expect(await json(await request.get(`${base}/customer-feedback?expectedUserId=${expectedUserId}`))).toEqual([]);
  229 |     await trigger.click();
  230 |     await expect(dialog.getByRole("textbox").first()).toHaveValue("");
  231 |     await expect(dialog.getByRole("combobox")).toHaveValue("BUG");
  232 |     await page.setViewportSize({ width: 1280, height: 720 });
  233 |     await dialog.getByRole("textbox").first().fill(body);
  234 |     await expect(
  235 |       dialog.getByRole("checkbox", { name: /diagnostic/i }),
  236 |     ).not.toBeChecked();
  237 |     const payloads: unknown[] = [];
  238 |     let failOnce = true;
  239 |     await page.route(
  240 |       `**/api/companies/${company.id}/customer-feedback?*`,
  241 |       async (route) => {
  242 |         if (route.request().method() !== "POST") return route.continue();
  243 |         payloads.push(route.request().postDataJSON());
  244 |         if (failOnce) {
  245 |           failOnce = false;
  246 |           return route.abort("failed");
  247 |         }
  248 |         return route.continue();
  249 |       },
  250 |     );
  251 |     await dialog
  252 |       .getByRole("button", { name: "Send feedback", exact: true })
  253 |       .click();
  254 |     await expect(dialog.getByRole("alert")).toBeVisible();
  255 |     await expect(dialog.getByRole("textbox").first()).toHaveValue(body);
  256 |     await expect(dialog.getByRole("textbox").first()).toBeDisabled();
  257 |     await expect(dialog.getByRole("combobox")).toBeDisabled();
  258 |     await dialog.getByRole("button", { name: "Check if received", exact: true }).click();
  259 |     await expect(dialog.getByText(/cannot confirm receipt yet/)).toBeVisible();
  260 |     expect(payloads).toHaveLength(1);
  261 |     await expect(dialog.getByRole("button", { name: "Discard draft", exact: true })).toBeDisabled();
  262 |     await expect(dialog.getByRole("alert")).toContainText(
```