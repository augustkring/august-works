# AgentAuthoring model-migration monitor qualification (r1)

This receipt records software-level checks for post-publication Agent model migration monitoring. It does not assert customer qualification, provider SLA, cohort expansion, or any external migration outcome.

The server/API/shared checks use the current source snapshot in `qualification-source/server-route-check-r19-source-pins.json` (source head `8d8499aef5c12bc6c524ae5fde5df0e34368990b`, base `886014cae5a7d6ed5a9ab99d62613ec7646308cb`). UI typecheck and focused tests use the snapshots in `qualification-source/ui-typecheck-r2-source-pins.json` and `ui-tests-r23-source-pins.json` at the same head. `source-manifest.json` lists the 28 selected §19 paths and their hashes. The portable checkpoint retains the selected untracked sources, source snapshots, and compressed source patches. The source list includes the publication service/helper, related UI validation and fixtures, and the V9 publication E2E source for dependency closure; that E2E file was snapshot- and syntax-checked but not executed. The shared barrel is listed only for its model-migration-monitor export, with resource-governance source files excluded from the selected path list.

The server cohort ran in `/workspace/v10-dep-qualification` under the shared PostgreSQL/compiler lock. Snapshot, Vite/Oxc syntax check, DB migration safety check, focused PostgreSQL flow, Human-only OpenAPI contract, and shared contract test passed. A fresh typecheck passed, and the route/OpenAPI suites passed 47/47 tests. Those route tests reject board API keys, Agent keys, and requests without a current session on each of the four monitor endpoints. OpenAPI marks those exact endpoints BoardSessionAuth-only; ordinary Agent draft routes retain their existing board-session/API-key contract. The PostgreSQL case exercised migration publication, original safe-test/conformance evidence, old-draft blocking, current migration discovery, fresh-draft hold then healthy records, exact request replay, immutable receipt protection, and retention after monitor-draft deletion.

The UI cohort, also run from the pinned dependency mirror and under the shared lock, passed Vite/Oxc syntax check, fresh typecheck, all four `AgentModelMigrationMonitor` tests, and all token gates. Tests cover healthy/hold recording, exact reviewed revision binding, prior-hold evidence refresh, and requiring a fresh current-baseline draft. The token gate scanned 1,452 files; all four gates were clean. The first UI typecheck found a nullable receipt access; the explicit null guard was added and the pinned rerun passed.

The implementation reads retained test evidence through the caller's existing transaction while keeping the root-bound Native gateway owner, avoiding a privacy-lock wait cycle. The UI binds receipt lookup, write, and success confirmation to `migrationRevisionId`, and carries the actual recorded decision through receipt refresh.

Migration 0563 remains the generated unreleased migration for this feature. The archived `0563-*` artifacts point to the original official Drizzle generation receipt (`model-migration-monitor-0563-regeneration-r4-20261029`); source and migration check hashes are preserved here. It uses an append-only update trigger and keeps delete/cascade behavior for company and Agent retention lifecycles. Migration safety check passed in the server cohort.

## Step receipts

- `server-pg-monitor.log` / `.exit`: focused real PostgreSQL Agent publication and monitoring flow, exit 0.
- `server-openapi-human.log` / `.exit`: Human-session-only route contract, exit 0.
- `server-shared-contract.log` / `.exit`: shared evidence schema tests, exit 0.
- `server-migration-check.log` / `.exit`: migration numbering and safety, exit 0.
- `ui-ui-monitor.log` / `.exit`: four focused UI tests, exit 0.
- `ui-token-gates.log` / `.exit`: design token gates, exit 0.
- `server-route-check-r19-*`: current server typecheck and 47 route/OpenAPI tests, both exit 0.
- `ui-typecheck-r2-*` and `ui-monitor-r23-*`: current UI typecheck and four focused UI tests, both exit 0.
- `qualification-source/`: pinned source receipts, source patches, and portable selected untracked files.
- `SHA256SUMS`: integrity hashes for archived receipt files.
