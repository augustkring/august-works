# Feedback quality software qualification

Date: 2026-10-30 UTC. This evidence accompanies the V10-094/097 Feedback-owned software change.

Optional structured satisfaction and effort ratings appear in the existing Feedback submission only when explicitly offered and consented to. Rating bytes live in a company-scoped child table; the original submission remains immutable. A submitter can withdraw, which deletes those bytes and appends a content-free marker in the same transaction. The current submitter's My Feedback detail and the internal source-owned quality report expose only the information authorized for those readers. Company portability archives explicitly exclude Product Feedback and its ratings.

The database guard checks consent against the immutable original Feedback context, forbids sidecar updates, and forbids restoring ratings after withdrawal. The withdrawal marker is unique, hidden, and content-free. Existing Feedback retention, account erasure, and company purge owners explicitly delete the sidecar where their parent Feedback record can remain retained.

## Executed software checks

- Official 0566 Drizzle generation after building current schema source, migration safety/numbering, DB build, and post-trigger DB typecheck passed. The SQL creates the sidecar, event constraint/index, and immutability guards; it contains no 0565 drops. Journal index 565 is preserved and 566 appended. Pruning removes exactly 0561.
- Fresh embedded PostgreSQL integration: 2 files, 44 tests passed.
- Full server typecheck passed.
- Shared contract tests: 2 files, 7 tests passed. Updated collection wording regression: 1 file, 2 tests passed.
- Feedback UI tests: 2 files, 37 tests passed. Full UI project typecheck passed.
- The isolated qualification mirror's backed-up code and DB build output were restored byte-for-byte.

This receipt qualifies software behavior and migration mechanics only. It makes no claim of live-provider, production, representative-customer, or operator/Human qualification. No live model or network evaluation was run.

The source and migration SHA-256 pins are in `source-pins.sha256`. Executed logs are under `logs/`; `stage-list.txt` is the exact publication closure including the one snapshot deletion.
