from pathlib import Path
p=Path('/workspace/blentera-v10/server/src/services/context/context-manifest.ts');s=p.read_text();a=s.index('    create: async (input: CreateContextManifestInput,');b=s.index('\n    },\n',a);c=s[a:b]
needle='''      const queryHash = hashContextQuery(input.query);''';assert c.count(needle)==1;c=c.replace(needle,'''      const phaseDiagnosticsEnabled = process.env.PAPERCLIP_NATIVE_CONTEXT_PHASE_DIAGNOSTICS === "1";
      const phaseStartedAt = Date.now();
      const phaseInitialRemainingMs = options.deadlineAt === undefined ? null : options.deadlineAt - phaseStartedAt;
      let phaseName = "references_and_retention";
      let phaseAt = phaseStartedAt;
      const phaseElapsed: Record<string, number> = {};
      const phaseNext = (name: string) => {
        if (!phaseDiagnosticsEnabled) return;
        const now = Date.now(); phaseElapsed[phaseName] = now - phaseAt; phaseName = name; phaseAt = now;
      };
'''+needle)
needle='''        const finalMemoryAclCurrent = !rootIds.length || await canActorReadMemorySourceSet''';assert c.count(needle)==1;c=c.replace(needle,'''        phaseNext("final_memory_acl");
'''+needle)
needle='''        for (const id of selectedTaskIds) {
          // `assertScopePrivacy` below''';assert c.count(needle)==1;c=c.replace(needle,'''        phaseNext("final_copied_task_acl");
'''+needle)
needle='''        await assertScopePrivacy();
        assertActive();

        let nativeBootstrapWitness''';assert c.count(needle)==1;c=c.replace(needle,'''        phaseNext("final_primary_scope");
'''+needle)
needle='''        let nativeBootstrapWitness: NativeBootstrapContextWitness | undefined;''';c=c.replace(needle,'''        phaseNext("capture_witness");
'''+needle)
needle='''        throw error;
      }''';assert c.count(needle)==1;c=c.replace(needle,'''        throw error;
      } finally {
        if (phaseDiagnosticsEnabled) {
          const now = Date.now(); phaseElapsed[phaseName] = now - phaseAt;
          console.error("native_context_manifest_phase_counts", JSON.stringify({ selectedCount: input.selected.length,
            initialRemainingMs: phaseInitialRemainingMs, elapsedMs: now - phaseStartedAt, phases: phaseElapsed }));
        }
      }''')
s=s[:a]+c+s[b:];Path('/workspace/v10-preparation/native-context-phase-diagnostic-candidate.ts').write_text(s)
