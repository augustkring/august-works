import { spawnSync } from "node:child_process";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(fileURLToPath(new URL("..", import.meta.url)));
const generator = resolve(root, "scripts/generate-v10-safe-change-graph.mjs");
const result = spawnSync(process.execPath, [generator, "--check"], { cwd: root, encoding: "utf8" });
if (result.status !== 0) {
  process.stderr.write(result.stderr || result.stdout || "V10 Safe Change graph is stale.\n");
  process.exit(result.status ?? 1);
}
process.stdout.write("V10 Safe Change graph matches its source manifest and current scoped source bytes.\n");
