import copy,gzip,hashlib,json,os,pathlib,shutil,subprocess,tarfile
root=pathlib.Path('/workspace/blentera-v10');prep=pathlib.Path('/workspace/v10-preparation');out=prep/'combined-b1-final-metadata-20261103';tmp=pathlib.Path('/tmp/combined-b1-final-metadata-20261103');work=tmp/'worktree';work.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest()
sourceout=prep/'combined-b1-reviewed-source-20261103';m=json.loads((sourceout/'source-manifest.json').read_bytes());proposal=json.loads((sourceout/'metadata-review-proposal.json').read_bytes());assert sha((sourceout/'source-manifest.json').read_bytes())==proposal['combinedSourceManifestSha256'];assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==m['baseHead']
phaseRel=pathlib.Path('doc/operations/aw-v10-evidence/v10-169-migration-phases-current-2026-10-30');phaseDir=prep/'v10-169-b1-recovered-20261103/sourcepatch'/phaseRel
phase=json.loads((phaseDir/'phase-matrix.json').read_bytes());oldphase=copy.deepcopy(phase)
with tarfile.open(prep/'v10-product-artifacts-b1-recovery-20261103/candidate.tar.gz','r:gz') as t:
 product={member.name:t.extractfile(member).read() for member in t.getmembers()}
graph=json.loads(product['doc/operations/v10-safe-change-graph.source.json']);oldgraph=copy.deepcopy(graph)
# Copy actual readable source roots with the exact alias scanner extensions.
# JSON supplies package/catalog/import data; SQL supplies the complete real migration subtree.
scanroots=['server/src','packages','cli/src','ui/src','scripts','skills','skills-releases'];extensions={'.ts','.tsx','.js','.jsx','.mjs','.md','.json','.sql'};copied={}
def copyfile(p):
 target=work/p;target.parent.mkdir(parents=True,exist_ok=True);content=(root/p).read_bytes();target.write_bytes(content);copied[p]=sha(content)
for rel in scanroots:
 for directory,dirs,files in os.walk(root/rel,followlinks=False):
  dirs[:]=[d for d in dirs if d not in {'node_modules','.git'} and not (pathlib.Path(directory)/d).is_symlink()]
  for name in files:
   p=pathlib.Path(directory)/name
   if p.is_symlink() or p.suffix not in extensions:continue
   copyfile(str(p.relative_to(root)))
# Explicit actual inputs outside scanner roots and original generated graph source paths.
needed={p for g in graph['changes'] for p in g['sourcePaths']}|{p['path'] for p in graph['sourceInputs']}|{p['path'] for p in phase['sourcePins']}
needed.update(['package.json','cli/package.json','tsconfig.json','docs/docs.json','docs/help/change-review.json','doc/operations/agent-native-tool-alias-compatibility.json','doc/experience/v9/coverage.json','doc/operations/v10-security-fast-path.json'])
for g in phase['groups']:needed.update(g['owners']+g['tests'])
for p in phase['phaseCases']:needed.update(p['evidence']);needed.update(c['path'] for c in p['cases'])
for directory in ['docs/help','docs/da/help','doc/experience/v9/contracts']:
 for p in (root/directory).rglob('*'):
  if p.is_file() and p.suffix in {'.md','.json'}:needed.add(str(p.relative_to(root)))
for p in sorted(needed):
 if (root/p).is_file() and p not in copied:copyfile(p)
for rel in ['node_modules','cli/node_modules','server/node_modules','packages/shared/node_modules']:
 target=work/rel;target.parent.mkdir(parents=True,exist_ok=True)
 if not target.exists():target.symlink_to(root/rel,target_is_directory=True)
# Whole source28 from the approved frozen packet, never reimplemented.
with tarfile.open(sourceout/'candidate-files.tar.gz','r:gz') as t:
 assert set(t.getnames())=={r['path'] for r in m['files']}
 for row in m['files']:
  content=t.extractfile(row['path']).read();assert sha(content)==row['candidateSha256'];target=work/row['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(content)
# Restore exact reviewed doc candidates; keep their dated evidence archives unchanged.
for name,content in product.items():target=work/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(content)
for p in phaseDir.iterdir():target=work/phaseRel/p.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
# Exactly two approved phase pin updates, with individual old/new reasons.
for delta in proposal['phase']['existingPinUpdates']:
 pin=next(p for p in phase['sourcePins'] if p['path']==delta['path']);assert pin['sha256']==delta['oldSha256'];pin['sha256']=delta['proposedSha256']
phase['approvedCombinedSource']={'baseHead':m['baseHead'],'sourceManifestSha256':sha((sourceout/'source-manifest.json').read_bytes()),'sourceFiles':28,'scope':'Private composed overlay, not the unchanged b1 tree; reviewed inventory-only pins, no combined runtime qualification.'}
phase['recoverySourceBasis']['qualification']='Initial recovery was pending at its first capture. Fresh b1 evidence is recorded separately; the present combined overlay requires its own scoped consistency capture. Archived checked input bytes remain unchanged.'
phase['registerConsistencyQualificationHistory']=[phase.pop('registerConsistencyQualification')]
(work/phaseRel/'phase-matrix.json').write_text(json.dumps(phase,indent=2)+'\n')
ledgerp=work/phaseRel/'source-revision-ledger.json';ledger=json.loads(ledgerp.read_bytes());ledger['approvedCombinedPinChanges']=proposal['phase']['existingPinUpdates'];ledger['combinedSourceManifestSha256']=sha((sourceout/'source-manifest.json').read_bytes());ledgerp.write_text(json.dumps(ledger,indent=2)+'\n')
# Exactly eight approved no_change review rows; articles and metadata stay identical.
helpdoc=json.loads((root/'docs/help/change-review.json').read_bytes());oldhelp=copy.deepcopy(helpdoc)
for delta in proposal['help']['rows']:
 row=helpdoc['reviews'][delta['reviewIndex']];assert row['source']==delta['source'] and row['articleId']==delta['articleId'] and row['sourceSha256']==delta['oldSourceSha256'];row['sourceSha256']=delta['proposedSourceSha256'];row['rationale']=delta['proposedCurrentRationale']
(work/'docs/help/change-review.json').write_text(json.dumps(helpdoc,indent=2,ensure_ascii=False)+'\n')
# Exactly eight alias source hashes. No mappings, consumers or lifecycle flags change.
alias=json.loads((root/'doc/operations/agent-native-tool-alias-compatibility.json').read_bytes());oldalias=copy.deepcopy(alias)
for delta in proposal['alias']['pinUpdates']:
 row=next(p for p in alias['sourcePins'] if p['path']==delta['path']);assert row['sha256']==delta['oldSha256'];row['sha256']=delta['proposedSha256']
(work/'doc/operations/agent-native-tool-alias-compatibility.json').write_text(json.dumps(alias,indent=2)+'\n')
# Five exact owner links approved by Root; leave nonlink assessments and169statuses unchanged.
for delta in proposal['safeChange']['newSourceLinks']:
 g=next(g for g in graph['changes'] if g['changeId']==delta['proposedOwnerGroup']);assert delta['path'] not in g['sourcePaths'];g['sourcePaths']=sorted(g['sourcePaths']+[delta['path']]);g['changedSourcePaths']=sorted(set(g['changedSourcePaths'])|{delta['path']});g['sourceBeforePins']=sorted(g['sourceBeforePins']+[delta['sourceBeforePin']],key=lambda p:p['path'])
 if '.test.' in delta['path']:g['characterizationTests']=sorted(set(g.get('characterizationTests',[]))|{delta['path']})
anchorPinChanges=[]
for g in graph['changes']:
 if g.get('hotspotSourcePin'):
  anchor=g['canonicalOwner'];digest=sha((work/anchor).read_bytes())
  if g['hotspotSourcePin']['currentAnchorSha256']!=digest:
   anchorPinChanges.append({'path':anchor,'oldSha256':g['hotspotSourcePin']['currentAnchorSha256'],'newSha256':digest,'reason':'Exact approved composed source bytes; descriptive current-anchor pin only, not a changed owner/qualification assessment.'});g['hotspotSourcePin']['currentAnchorSha256']=digest
assert len(anchorPinChanges)==4
graph['sourceInventoryBoundary']['sourceDeltaPathCount']=1939;graph['sourceInventoryBoundary']['fullDiffPathCount']+=1;graph['currentSourceRecovery']['approvedCombinedSourceManifestSha256']=sha((sourceout/'source-manifest.json').read_bytes());graph['sourceAfterGeneration']='Private exact reviewed composed overlay anchored at b1; no final runtime, release or capability qualification.'
(work/'doc/operations/v10-safe-change-graph.source.json').write_text(json.dumps(graph,indent=2)+'\n')
# Preserve original untouched callback sources and create only an explicit pure Help interface.
helpcheck=f'''import {{ readFileSync,writeFileSync }} from 'node:fs';
import {{ createHash }} from 'node:crypto';
import {{ readHelpArticleSources }} from {json.dumps((work/'scripts/check-help-docs.mjs').as_uri())};
import {{ validateHelpChangeReview }} from {json.dumps((work/'scripts/check-help-change-review.mjs').as_uri())};
const root={json.dumps(str(work))};
const articles=readHelpArticleSources(root);
const doc=JSON.parse(readFileSync(root+'/docs/help/change-review.json','utf8'));
const changed=JSON.parse(readFileSync({json.dumps(str(sourceout/'source-manifest.json'))},'utf8')).files.map(r=>r.path);
const result=validateHelpChangeReview({{articles,reviews:doc.reviews,changedPaths:changed,hashFile:path=>createHash('sha256').update(readFileSync(root+'/'+path)).digest('hex')}});
writeFileSync({json.dumps(str(out/'help-validation-result.json'))},JSON.stringify(result,null,2)+'\\n');
if(result.errors.length)throw new Error(result.errors.join('\\n'));
console.log('Validated '+doc.reviews.length+' Help source/article reviews against exact private composed bytes; '+result.evidence.length+' linked changed-source decisions.');
''';(out/'check-help-overlay.mjs').write_text(helpcheck)
# Actual alternate index/object store: no Main index, object or ref writes.
gitdir=subprocess.check_output(['git','rev-parse','--absolute-git-dir'],cwd=root,text=True).strip();objects=tmp/'objects';objects.mkdir(exist_ok=True);env={**os.environ,'GIT_DIR':gitdir,'GIT_WORK_TREE':str(work),'GIT_INDEX_FILE':str(tmp/'candidate.index'),'GIT_OBJECT_DIRECTORY':str(objects),'GIT_ALTERNATE_OBJECT_DIRECTORIES':str(pathlib.Path(subprocess.check_output(['git','rev-parse','--path-format=absolute','--git-common-dir'],cwd=root,text=True).strip())/'objects')}
subprocess.run(['git','read-tree',m['baseHead']],cwd=work,env=env,check=True)
changed=set(product)|{r['path'] for r in m['files']}|{'docs/help/change-review.json','doc/operations/agent-native-tool-alias-compatibility.json','doc/operations/v10-safe-change-graph.source.json'}|{str(phaseRel/p.name) for p in phaseDir.iterdir()}
for p in sorted(changed):
 blob=subprocess.check_output(['git','hash-object','-w','--stdin'],cwd=work,env=env,input=(work/p).read_bytes()).decode().strip();subprocess.run(['git','update-index','--add','--cacheinfo','100644',blob,p],cwd=work,env=env,check=True)
indexdiff=subprocess.check_output(['git','diff','--cached','--name-only','81d3445b98b1cd80ff400ede6bd44ea71d88d735'],cwd=work,env=env,text=True).splitlines();oldindexdiff=subprocess.check_output(['git','diff','--name-only','81d3445b98b1cd80ff400ede6bd44ea71d88d735','HEAD'],cwd=root,text=True).splitlines();newpaths=sorted(set(indexdiff)-set(oldindexdiff));graph['sourceInventoryBoundary']['fullDiffPathCount']=len(indexdiff)
(work/'doc/operations/v10-safe-change-graph.source.json').write_text(json.dumps(graph,indent=2)+'\n')
blob=subprocess.check_output(['git','hash-object','-w','--stdin'],cwd=work,env=env,input=(work/'doc/operations/v10-safe-change-graph.source.json').read_bytes()).decode().strip();subprocess.run(['git','update-index','--cacheinfo','100644',blob,'doc/operations/v10-safe-change-graph.source.json'],cwd=work,env=env,check=True)
assert 'server/src/services/adapter-process-stop.test.ts' in newpaths
# The other four owner files become material changed paths only in this overlay.
oldrows={g['changeId']:g for g in oldgraph['changes']};linkkeys={'sourcePaths','changedSourcePaths','sourceBeforePins','characterizationTests','hotspotSourcePin'}
for g in graph['changes']:
 for k,v in oldrows[g['changeId']].items():
  if k not in linkkeys:assert g[k]==v,(g['changeId'],k)
assert graph['requirementsCrosswalk']==oldgraph['requirementsCrosswalk'];assert phase['phaseCases']==oldphase['phaseCases'] and phase['promotion']==oldphase['promotion']
assert sha((work/'doc/operations/aw-v10-evidence/recovery-2026-10-22/requirement-reconciliation.json').read_bytes())=='63fc64316d59206557d94497f6efeb8c0c0f45123bd1513f7a9d2e53c30d84b3'
assert {k:v for k,v in alias.items() if k!='sourcePins'}=={k:v for k,v in oldalias.items() if k!='sourcePins'}
for i,row in enumerate(helpdoc['reviews']):
 for k,v in oldhelp['reviews'][i].items():
  if k not in {'sourceSha256','rationale'}:assert row[k]==v
# Persist every unique edited metadata file immediately, compressed; full source is reproducible TMP.
unique={p:(work/p).read_bytes() for p in changed if p not in {r['path'] for r in m['files']}}
import io
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as t:
 for p,b in sorted(unique.items()):
  info=tarfile.TarInfo(p);info.size=len(b);info.mtime=0;info.mode=0o644;t.addfile(info,io.BytesIO(b))
(out/'approved-metadata-prequalification.tar.gz').write_bytes(gzip.compress(buf.getvalue(),mtime=0))
receipt={'baseHead':m['baseHead'],'worktree':str(work),'copiedActualReadFiles':len(copied),'copiedBytes':sum((work/p).stat().st_size for p in copied),'alternateGitEnvironment':{k:env[k] for k in ['GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES']},'alternateIndexTree':subprocess.check_output(['git','write-tree'],cwd=work,env=env,text=True).strip(),'actualNewPathsAgainstB1BaseDiff':newpaths,'reviewedSourceFiles':28,'phasePinChanges':2,'helpRows':8,'aliasPins':8,'safeGraphNewPaths':5,'descriptiveCurrentAnchorPinUpdates':anchorPinChanges,'safeGraphMaterialDeltaCount':1939,'all169HistoryAnd50AssessmentsUnchanged':True,'noMainWrites':True,'newSdkOrRuntimeQualification':False,'uniqueMetadataFiles':{p:sha(b) for p,b in unique.items()}};(out/'preparation-proof.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k not in {'uniqueMetadataFiles','alternateGitEnvironment'}}))
