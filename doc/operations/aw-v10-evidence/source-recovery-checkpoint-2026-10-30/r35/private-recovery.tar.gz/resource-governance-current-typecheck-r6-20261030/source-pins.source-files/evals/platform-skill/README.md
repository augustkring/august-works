# Platform Skill Operating Knowledge audit

This is the source-owned V10-145 coverage audit for §§21B.28–.31 and 43.15. It binds the immutable reserved `blentera-platform` release to the current Operation Manifest, retained behavior cases, the existing Skill Lifecycle evaluation/promotion owner, and the Native/OpenClaw/Hermes source/test paths.

Run the deterministic source and case-binding gate with:

```sh
pnpm check:platform-skill-operating-knowledge
pnpm test:platform-skill-operating-knowledge
```

Run the current retained Promptfoo scenarios with the existing provider contract using `pnpm evals:platform-skill`. The command loads the exact current release files, includes only the one-level reference named by each scenario, reads the existing Promptfoo provider list, and passes all baseline and reviewed field cases to that runner. It makes model calls when invoked with configured provider credentials. Do not run it as part of offline source checks.

The corpus currently contains 13 contract scenarios and **zero production/support field regressions**. No genuine reviewed source case was available to seed, so none is represented as customer evidence. To add one, a Platform Skill owner manually reviews a confirmed failure and adds a structured entry to `cases.json` under `fieldRegressionCases`: choose an existing `scenario` enum and bounded signals; include only `sourceKind`, a SHA-256 digest of the reviewed source, `reviewedByRole: "platform_skill_owner"`, a canonical UTC `reviewedAt`, `privacyReview: "sanitized_scenario_only"`, and `copiedTranscript: false`. The checker rejects extra fields, freeform prompts, raw IDs, paths, URLs, credentials, and transcripts. The scenario is then executed by the same Promptfoo runner. There is no automatic collection or writeback from Feedback, Support, incidents, telemetry, or Learning.

Promptfoo text checks are screening evidence only. The efficiency cases retain provider token/cost/latency diagnostics without pass thresholds; this corpus does not observe runtime reference activation, tool calls, retries, or external side effects. Existing authorization and execution behavior remains enforced and tested by the current Native/Tool Gateway/adaptor owners and the governed `SkillEvaluationService`; this audit creates no second promotion policy.

Current profile boundaries are explicit: Native delivery source exists, while installed-runtime/customer qualification remains open; OpenClaw and Hermes are not claimed as GA here; A2A/custom runtime equivalence remains unknown and unqualified. The release registry's generic compatibility field does not qualify a runtime. No current source register supplies the GA profile inventory, so the audit does not manufacture one.
