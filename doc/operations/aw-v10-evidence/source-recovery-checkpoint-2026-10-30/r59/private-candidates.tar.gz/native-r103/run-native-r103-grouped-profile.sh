#!/bin/bash
set -euo pipefail
exec flock -x /workspace/v10-preparation/v10-pg-tests.lock bash -lc '
set -euo pipefail
source /workspace/v10-preparation/env.sh
export PAPERCLIP_NATIVE_CONTEXT_PHASE_DIAGNOSTICS=0
export PAPERCLIP_NATIVE_TEST_TOOL_RESULT_DIAGNOSTICS=1
export PAPERCLIP_NATIVE_SOURCE_MEMO_DIAGNOSTICS=1
p=/workspace/v10-preparation/native-r103-grouped-profile-20261101
python3 /workspace/v10-preparation/snapshot-private-native-r103.py "$p-pins.json" > "$p-snapshot.log" 2>&1
available=$(df -Pk /tmp | awk "NR==2 {print \$4}")
if (( available < 330000 )); then echo "replay requires330MBtmp" >&2; exit 78; fi
cluster="$(mktemp -d /tmp/native-r87-context-replay-pg-XXXXXX)"
pgctl=/tmp/blentera-dependency-recovery-20261101/node_modules.partial/.pnpm/@embedded-postgres+linux-x64@18.1.0-beta.16/node_modules/@embedded-postgres/linux-x64/native/bin/pg_ctl
original=/tmp/v10-native-payload-temporal-6iXDGY
sha256sum "$original/global/pg_control" > "$p-original-control-before.sha256"
cp -a "$original/." "$cluster/"
port="$(python3 -c "import socket;s=socket.socket();s.bind((\"127.0.0.1\",0));print(s.getsockname()[1]);s.close()")"
replaytest=/workspace/v10-dep-qualification/server/src/__tests__/native-r87-context-checkpoint-replay.integration.test.ts
cleanup() {
  rc=$?
  trap - EXIT
  "$pgctl" -D "$cluster" -m fast -w -t 20 stop > "$p-stop.log" 2>&1 || true
  sha256sum "$original/global/pg_control" > "$p-original-control-after.sha256"
  cmp "$p-original-control-before.sha256" "$p-original-control-after.sha256" || rc=99
  rm -f "$replaytest"
  if [[ ! -f "$cluster/postmaster.pid" ]]; then rm -rf "$cluster"; fi
  printf "%s\n" "$rc" > "$p.exit"
  exit "$rc"
}
trap cleanup EXIT
"$pgctl" -D "$cluster" -o "-p $port -h 127.0.0.1" -w -t 30 -l "$p-postgres.log" start > "$p-start.log" 2>&1
export NATIVE_CONTEXT_REPLAY_DATABASE_URL="postgres://paperclip:paperclip@127.0.0.1:$port/paperclip"
cp /workspace/v10-preparation/native-r103-grouped-profile.test.ts "$replaytest"
sha256sum "$replaytest" > "$p-replay-test.sha256"
cd /workspace/v10-dep-qualification/server
memory_path=server/src/services/memory/memory-privacy.ts
cp /workspace/v10-preparation/native-r103-without-final-principal-fence.ts /workspace/v10-dep-qualification/$memory_path
set +e
timeout 120 ../node_modules/.bin/vitest run src/__tests__/native-r87-context-checkpoint-replay.integration.test.ts -t "cancellation arrives during the final current-principal" --reporter=verbose > "$p-negative-control.log" 2>&1
control=$?
set -e
cp /workspace/v10-preparation/native-grouped-reader-profile-r103-candidate/$memory_path /workspace/v10-dep-qualification/$memory_path
if [[ $control != 1 ]] || ! rg -q "expected true to be false" "$p-negative-control.log"; then echo "negativecontrol didnotreach lateallow" >&2; exit 79; fi
printf "%s\n" "$control" > "$p-negative-control.exit"
timeout 180 ../node_modules/.bin/vitest run src/__tests__/native-r87-context-checkpoint-replay.integration.test.ts --reporter=verbose > "$p-test.log" 2>&1
'
