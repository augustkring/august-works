from pathlib import Path
import subprocess,json,gzip,tarfile,io,hashlib,datetime
root=Path('/workspace/blentera-v10');prep=Path('/workspace/v10-preparation');out=root/'doc/operations/aw-v10-evidence/source-recovery-checkpoint-2026-10-30/r49'
assert not out.exists();out.mkdir(parents=True)
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
def sha(b):return hashlib.sha256(b).hexdigest()
base=git('rev-parse','HEAD').decode().strip();patch=git('diff','--binary',base);z=gzip.compress(patch,mtime=0);(out/'working-source.patch.gz').write_bytes(z)
new=[p for p in git('ls-files','--others','--exclude-standard').decode().splitlines() if p.startswith(('server/','ui/','packages/','scripts/','tests/'))]
def pack(dest,files):
 rows=[]
 with tarfile.open(dest,'w:gz') as t:
  for name,p in sorted(files.items()):
   b=p.read_bytes();i=tarfile.TarInfo(name);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b));rows.append({'path':name,'bytes':len(b),'sha256':sha(b)})
 return rows
newrows=pack(out/'untracked-source.tar.gz',{p:root/p for p in new if (root/p).is_file()});files={}
for pattern in ['root-continuation-20261030-1045.md','root-continuation-latest.md','preserve-r49.py','publish-openshell-r5.py','run-final-workspace-aggregate-20261030.sh','prepare-v10-169-phase-pins-after-freeze.py','*safe-change*current.py','snapshot-current-source-for-dependency-check.py','pr42-body-current-20261030-1025.md','temporal9-node-work-r60-20261030-primary-accounting.txt','prepare-native-*r6*.py']:
 for p in prep.glob(pattern):
  if p.is_file():files['preparation/'+p.name]=p
for prefix in ['native-context-task-owner-r59-candidate','native-node-work-r60-candidate','native-ambient-prefix-r61-candidate','v10-149-native-provision-r1','v10-149-rt01-outer-disk-syscall-r12','v10-final-claim-reconciliation-candidate-r3-20261030','openshell-rt01-repo-integration-candidate-r5','qualification-capability-clock-r2']:
 d=prep/prefix
 if not d.exists():continue
 for p in d.rglob('*'):
  rel=p.relative_to(d)
  if not p.is_file() or any(x in rel.parts for x in ['.git','node_modules','__pycache__','qualification','qualification-r10','portable-r10','build-state','restore-files','source-bundle']):continue
  if p.stat().st_size>16_000_000:continue
  files['preparation/'+str(p.relative_to(prep))]=p
rows=pack(out/'private-candidates.tar.gz',files)
# Immutable archive pins record a recovery snapshot, not a claim that active candidates qualify.
m={'purpose':'recovery_only_not_qualification','savedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseCommit':base,'priorRecoveryCommit':'de909d89ae14f18f65f0b7a4d6851c65bb67a7a6','patchBytes':len(patch),'patchSha256':sha(patch),'archiveSha256':sha(z),'untrackedSourceFiles':newrows,'privateCandidateFiles':rows,'privateCandidateArchiveSha256':sha((out/'private-candidates.tar.gz').read_bytes())}
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');(out/'README.md').write_text('# Recoverable source checkpoint r49\n\nRecovery only; active Native diagnostics, host probes, provisioning and report candidates remain under development. Apply the working patch at the exact manifest base. Private candidates use preparation/ paths and require review; archived source-pin/patch files inside an unfinished candidate may describe its older parent. The full current files/ tree is saved independently. Prior checkpoint r48 retains older candidate history. No software, physical-host or release acceptance is inferred.\n');print(json.dumps({'output':str(out),'privateFiles':len(rows),'privateBytes':(out/'private-candidates.tar.gz').stat().st_size,'patchBytes':len(patch)}))
