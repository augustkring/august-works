# Private Resource 0565 candidate

This directory is intentionally not imported by the Experience service. It is an isolated implementation candidate for the approved responsibility cursor/pointer architecture. The matching PostgreSQL integration test is `server/src/__tests__/private-0565-responsibility-scan.integration.test.ts`.

Do not add migration journal entries, expose candidate pointers to callers, or wire a scheduler before the native metadata adapters and current per-domain authorization readers for all §17 classes are ready and Resource 0564 has been serialized. Candidate IDs and source versions are trusted-server metadata only; no public result may include them without a fresh domain-owner read and current source-version check.
