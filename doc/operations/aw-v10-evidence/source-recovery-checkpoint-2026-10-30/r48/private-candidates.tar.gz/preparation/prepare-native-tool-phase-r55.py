from pathlib import Path
import hashlib,json,difflib,re
r=Path('/workspace/blentera-v10');o=Path('/workspace/v10-preparation/native-tool-phase-r55-candidate');rel='server/src/services/native-runtime/native-session-executor.ts';a=(r/rel).read_text();s=a
needle='''    this.#assertCurrent();
    const execute = async () => {
      this.#assertCurrent();''';assert needle in s
s=s.replace(needle,'''    this.#assertCurrent();
    const phaseTool = ["self_remember", "read_context"].includes(call.tool) ? call.tool : "other";
    const phaseEnabled = process.env.PAPERCLIP_NATIVE_CONTEXT_PHASE_DIAGNOSTICS === "1";
    const phaseStart = phaseEnabled ? performance.now() : 0;
    let phasePrevious = phaseStart;
    const markPhase = (phase: string) => {
      if (!phaseEnabled) return;
      const now = performance.now();
      console.error("native_tool_source_phase_counts", JSON.stringify({ tool: phaseTool, phase,
        elapsedMs: now - phasePrevious, totalMs: now - phaseStart }));
      phasePrevious = now;
    };
    const execute = async () => {
      markPhase("queue_wait");
      this.#assertCurrent();''',1)
needle='''      const projectReadCapture: { value: NativeProjectToolResultSource | null }''';assert needle in s;s=s.replace(needle,'''      markPhase("dispatch_binding");
'''+needle,1)
needle='''      if (call.turnId && (call.tool === "read_document" || call.tool === "write_document" ||''';assert needle in s;s=s.replace(needle,'''      markPhase("authority_effect");
'''+needle,1)
needle='''      return result;
    };
    const run = async () => this.toolTrace ? this.toolTrace.execute(call, execute) : execute();''';assert needle in s
s=s.replace(needle,'''      markPhase("result_capture");
      return result;
    };
    const run = async () => {
      try { return await (this.toolTrace ? this.toolTrace.execute(call, execute) : execute()); }
      finally { markPhase("trace_and_return"); }
    };''',1)
# Existing static result-capture stages gain elapsed-only observations.
start=s.index('async function recordManagedOpenCodeToolResult(');end=s.index('\nasync function ',start+1);part=s[start:end]
needle='''  const projectRead = input.tool === "call_api" ? input.projectRead : undefined;''';assert needle in part
part=part.replace('  let diagnosticPhase: ', '  type CapturePhase = ',1)
part=part.replace(' = "capture_binding";', ';\n  let diagnosticPhase: CapturePhase = "capture_binding";',1)
part=part.replace(needle,'''  let phaseStarted = process.env.PAPERCLIP_NATIVE_CONTEXT_PHASE_DIAGNOSTICS === "1" ? performance.now() : null;
  const markResultPhase = (next: CapturePhase) => {
    if (phaseStarted !== null) {
      const now = performance.now();
      console.error("native_tool_capture_phase_counts", JSON.stringify({
        tool: ["self_remember", "read_context"].includes(input.tool) ? input.tool : "other",
        phase: diagnosticPhase, elapsedMs: now - phaseStarted }));
      phaseStarted = now;
    }
    diagnosticPhase = next;
  };
'''+needle,1)
part,n=re.subn(r'      diagnosticPhase = "([a-z_]+)";',r'      markResultPhase("\1");',part);assert n>=8,n
# Emit terminal stage on either success or error without altering error mapping.
needle='''      ? message : "managed_opencode_tool_result_persistence_failed");
  }
}''';assert needle in part
part=part.replace(needle,'''      ? message : "managed_opencode_tool_result_persistence_failed");
  } finally { markResultPhase(diagnosticPhase); }
}''',1)
s=s[:start]+part+s[end:]
p=o/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);(o/'candidate.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)));(o/'manifest.json').write_text(json.dumps({rel:{'priorSha256':hashlib.sha256(a.encode()).hexdigest(),'candidateSha256':hashlib.sha256(s.encode()).hexdigest()}},indent=2));(o/'baseline.ts').write_text(a)
