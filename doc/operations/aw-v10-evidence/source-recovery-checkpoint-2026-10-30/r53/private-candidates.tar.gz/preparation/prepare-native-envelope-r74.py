from pathlib import Path
import hashlib,json,difflib
r=Path('/workspace/blentera-v10');base=Path('/workspace/v10-preparation/native-document-producer-r72-candidate');out=Path('/workspace/v10-preparation/native-envelope-r74-candidate');rels=['server/src/services/native-direct-input.ts','server/src/__tests__/native-payload-temporal-sources.integration.test.ts']
for rel in rels:
 (out/rel).parent.mkdir(parents=True,exist_ok=True);(out/rel).write_bytes((base/rel).read_bytes())
rel='server/src/services/context/context-engine.ts';old=(r/rel).read_text();s=old
needle='''/** Native bootstrap invocations get up to 4s for source closure review: the
 * measured 3-candidate, two-pass Memory review takes 2.8s, leaving 350ms for
 * finalization and bounded scheduling margin. Generic Context stays at 1.5s. */
export const NATIVE_CONTEXT_BOOTSTRAP_TOTAL_DEADLINE_MS = 4_000;'''
replacement='''/** The retained multi-Run source graph takes about 5s across provider and
 * final owner review. Native bootstraps use the existing 8s review envelope;
 * generic Context and shorter caller deadlines retain their own limits. */
export const NATIVE_CONTEXT_BOOTSTRAP_TOTAL_DEADLINE_MS = MAX_CONTEXT_MEMORY_PROVIDER_TIMEOUT_MS;'''
assert s.count(needle)==1;s=s.replace(needle,replacement,1)
(out/rel).parent.mkdir(parents=True,exist_ok=True);(out/rel).write_text(s);(out/'r74-engine.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)));rels.append(rel)
rel='server/src/services/context/context-engine.test.ts';old=(r/rel).read_text();s=old;s=s.replace('bounds Native bootstraps at 4s','bounds Native bootstraps at 8s',1)
for needle in ['expect(NATIVE_CONTEXT_BOOTSTRAP_TOTAL_DEADLINE_MS).toBe(4_000);','expect(contextTotalDeadlineMs(undefined, true)).toBe(4_000);','expect(contextTotalDeadlineMs(30_000, true)).toBe(4_000);']:
 assert s.count(needle)==1;s=s.replace(needle,needle.replace('4_000','8_000'),1)
needle='    expect(contextTotalDeadlineMs(30_000, true)).toBe(8_000);';s=s.replace(needle,needle+'\n    expect(contextTotalDeadlineMs(400, true)).toBe(400);',1)
for needle in ['expect(contextMemoryProviderTimeoutMs(NATIVE_CONTEXT_BOOTSTRAP_TOTAL_DEADLINE_MS)).toBe(3_650);','expect(contextTaskProviderTimeoutMs(NATIVE_CONTEXT_BOOTSTRAP_TOTAL_DEADLINE_MS, true)).toBe(3_650);']:
 assert s.count(needle)==1;s=s.replace(needle,needle.replace('3_650','7_650'),1)
(out/rel).parent.mkdir(parents=True,exist_ok=True);(out/rel).write_text(s);(out/'r74-deadline-test.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)));rels.append(rel)
m={}
for rel in rels:
 a=(r/rel).read_bytes();b=(out/rel).read_bytes();m[rel]={'priorSha256':hashlib.sha256(a).hexdigest(),'candidateSha256':hashlib.sha256(b).hexdigest()}
(out/'manifest.json').write_text(json.dumps(m,indent=2));(out/'syntax-pins.json').write_text(json.dumps({'qualificationWorkspace':str(out),'copiedFiles':[{'path':rel} for rel in m]},indent=2))
p=Path('/workspace/v10-preparation');snapshot=(p/'snapshot-private-native-r72.py').read_text().replace('native-document-producer-r72-candidate','native-envelope-r74-candidate');(p/'snapshot-private-native-r74.py').write_text(snapshot);runner=(p/'run-private-native-document-r72-quiet.sh').read_text().replace('snapshot-private-native-r72.py','snapshot-private-native-r74.py');needle='cd "$ROOT/server"\n';assert runner.count(needle)==1;runner=runner.replace(needle,needle+'''../node_modules/.bin/vitest run src/services/context/context-engine.test.ts \\
  -t "Context provider deadline policy|Context total deadline policy" --reporter=verbose \\
  > "$OUT/$NAME-deadline-test.log" 2>&1
deadline_rc=$?
printf "%s\\n" "$deadline_rc" > "$OUT/$NAME-deadline-test.exit"
if [[ "$deadline_rc" -ne 0 ]]; then printf "%s\\n" "$deadline_rc" > "$OUT/$NAME.exit"; exit "$deadline_rc"; fi
''',1);(p/'run-private-native-envelope-r74-quiet.sh').write_text(runner)
print((out/'r74-engine.diff').read_text());print((out/'r74-deadline-test.diff').read_text())
