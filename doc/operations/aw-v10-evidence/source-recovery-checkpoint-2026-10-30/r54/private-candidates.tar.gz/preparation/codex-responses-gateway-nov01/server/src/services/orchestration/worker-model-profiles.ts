import { createHash } from "node:crypto";
import { readFileSync, realpathSync, statSync } from "node:fs";
import { z } from "zod";
import { forbidden } from "../../errors.js";
import {
  modelQualificationProfileSchema,
  checkModelQualificationProvider,
  assertModelQualificationMetadata,
  assertModelLifecycleAdmission,
} from "./read-only-model-profiles.js";

/** Price/token qualification is separate from independent judge calibration.
 * Exact server text, Messages and Responses protocol contracts are representable.
 * A contract entry alone does not qualify CLI egress or supply source closure. */
export const workerModelProfileSchema = modelQualificationProfileSchema
  .extend({
    workerAgentId: z.string().uuid(),
    transport: z.enum(["server-text-only-v1", "server-anthropic-messages-v1", "server-openai-responses-v1"]),
    providerBindingId: z.string().uuid(),
    providerSnapshotHash: z.string().regex(/^[a-f0-9]{64}$/),
    providerProfileRef: z.string().min(1).max(200),
    qualifiedConfigurationHash: z.string().regex(/^[a-f0-9]{64}$/),
  })
  .strict()
  .superRefine((profile, context) => {
    if (profile.transport === "server-openai-responses-v1") {
      if (profile.tariff.provider !== "openai" || profile.binding.provider !== "openai" ||
          profile.binding.method !== "api_key" || profile.binding.mode === "responsible_user")
        context.addIssue({ code: "custom", message: "An explicit installed OpenAI API-key grant is required" });
      if (!/^[a-zA-Z0-9_.:-]{1,200}$/.test(profile.tariff.model))
        context.addIssue({ code: "custom", message: "An exact OpenAI model revision is required" });
    } else checkModelQualificationProvider(profile, context);
    const expectedContract = profile.transport === "server-text-only-v1"
      ? "anthropic-text-messages-2023-06-01"
      : profile.transport === "server-openai-responses-v1" ? "openai-responses-tools-v1"
      : "anthropic-messages-tools-2023-06-01";
    if (profile.contract !== expectedContract)
      context.addIssue({ code: "custom", message: "Worker model transport and price qualification contract disagree" });
  });
export type WorkerModelProfile = z.infer<typeof workerModelProfileSchema>;

/** The current canonical configuration selects one installed qualification.
 * An unselected alternative never becomes a default or supplies another
 * presence's credential, price or qualification. */
export function selectWorkerModelProfile(profiles: readonly WorkerModelProfile[], input: {
  companyId: string; agentId: string; profileId?: string; configurationHash?: string; sourceSha: string; protectedEvidenceOrigin: string;
  purpose?: "runtime" | "candidate_evaluation";
  transport?: "server-text-only-v1" | "server-anthropic-messages-v1";
}) {
  if (input.profileId === undefined && input.configurationHash === undefined)
    throw forbidden("The exact installed worker model qualification is required");
  const matches = profiles.filter(p => p.companyId === input.companyId && p.workerAgentId === input.agentId &&
    (input.profileId === undefined || p.id === input.profileId) &&
    (input.configurationHash === undefined || p.qualifiedConfigurationHash === input.configurationHash));
  if (matches.length !== 1) throw forbidden("The exact installed worker model qualification is required");
  const selected = assertWorkerModelProfileCurrent(matches[0]!, input.sourceSha, input.protectedEvidenceOrigin, input.purpose);
  // The schema can retain future protocol qualifications. Selection is an
  // executable capability: Responses has no trusted Native broker/source path.
  if (selected.transport === "server-openai-responses-v1")
    throw forbidden("OpenAI Responses worker transport is not implemented; configuration_incomplete");
  if (input.transport !== undefined && selected.transport !== input.transport)
    throw forbidden("The selected worker model transport does not match this protocol endpoint");
  return selected;
}

export function assertWorkerModelProfileCurrent(
  raw: WorkerModelProfile,
  sourceSha: string,
  protectedOrigin: string,
  purpose: "runtime" | "candidate_evaluation" = "runtime",
  now = new Date(),
) {
  const p = workerModelProfileSchema.parse(raw);
  assertModelQualificationMetadata(p, sourceSha, protectedOrigin, now);
  assertModelLifecycleAdmission(p.lifecycle, purpose, now);
  return p;
}

export function loadWorkerModelProfiles(
  path: string | undefined,
  expectedSha256: string | undefined,
): WorkerModelProfile[] {
  if (!path && !expectedSha256) return [];
  if (
    !path?.startsWith("/") ||
    !expectedSha256 ||
    !/^[a-f0-9]{64}$/.test(expectedSha256)
  )
    throw new Error("worker_model_profile_pin_required");
  const real = realpathSync(path),
    stat = statSync(real);
  if (
    !stat.isFile() ||
    stat.size > 1048576 ||
    (stat.mode & 0o077) !== 0 ||
    (typeof process.getuid === "function" && stat.uid !== process.getuid())
  )
    throw new Error("worker_model_profile_file_not_private");
  const bytes = readFileSync(real);
  if (createHash("sha256").update(bytes).digest("hex") !== expectedSha256)
    throw new Error("worker_model_profile_digest_changed");
  let data: unknown;
  try {
    data = JSON.parse(bytes.toString("utf8"));
  } catch {
    throw new Error("worker_model_profile_json_invalid");
  }
  const profiles = z.array(workerModelProfileSchema).max(100).parse(data);
  if (
    new Set(profiles.map((p) => `${p.companyId}:${p.workerAgentId}:${p.qualifiedConfigurationHash}`)).size !==
      profiles.length ||
    new Set(profiles.map((p) => p.id)).size !== profiles.length
  )
    throw new Error("worker_model_profiles_ambiguous");
  return profiles;
}
