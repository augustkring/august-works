from pathlib import Path
import subprocess,json,gzip,tarfile,io,hashlib,datetime
root=Path('/workspace/blentera-v10'); prep=Path('/workspace/v10-preparation')
out=root/'doc/operations/aw-v10-evidence/source-recovery-checkpoint-2026-10-30/r46'
assert not out.exists();out.mkdir(parents=True)
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
def sha(b):return hashlib.sha256(b).hexdigest()
base=git('rev-parse','HEAD').decode().strip();patch=git('diff','--binary',base)
z=gzip.compress(patch,mtime=0);(out/'working-source.patch.gz').write_bytes(z)
new=[p for p in git('ls-files','--others','--exclude-standard').decode().splitlines() if p.startswith(('server/','ui/','packages/','scripts/','tests/'))]
def pack(dest,files):
 rows=[]
 with tarfile.open(dest,'w:gz') as t:
  for name,p in sorted(files.items()):
   b=p.read_bytes();i=tarfile.TarInfo(name);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b));rows.append({'path':name,'bytes':len(b),'sha256':sha(b)})
 return rows
newrows=pack(out/'untracked-source.tar.gz',{p:root/p for p in new if (root/p).is_file()})
files={}
for pattern in ['root-continuation-20261030-0800.md','help-closeout-review-proposal-20261030.json','snapshot-current-source-for-dependency-check.py','preserve-r46.py','root-continuation-latest.md','*safe-change*current.py','merge-safe-change-inventory-current.py','check-private-safe-change-merge.mjs','v10-169*current*20261030*','v10-001-060-current-gap-audit-20261030.json','v10-169-061-120-current-gap-audit-luna-20261030.json','pr42-body-current-20261030-0535.md','prepare-native-frozen-completed-obligations-r48.py','build-v10-final-claim-reconciliation-candidate.py','portable-refresh-v10-final-claim-reconciliation-candidate.py']:
 for p in prep.glob(pattern):
  if p.is_file() and p.stat().st_size<4_000_000:files['preparation/'+p.name]=p
for prefix in ['v10-final-claim-reconciliation-candidate-20261030','native-frozen-reader-pins-r48-candidate','native-model-watch-drain-r45-candidate','native-model-watch-r45-portable-receipt','native-local-reader-provenance-r46-candidate','native-reader-origin-r47-candidate','native-sql-compile-split-r44-candidate','native-memory-page-jit-r43-candidate']:
 directory=prep/prefix
 if not directory.exists():continue
 for p in directory.rglob('*'):
  if p.is_file() and not any(x in p.parts for x in ['source-pins.source-files','compiled-baseline','node_modules','__pycache__']) and p.stat().st_size<4_000_000:files['preparation/'+str(p.relative_to(prep))]=p
rows=pack(out/'private-candidates.tar.gz',files)
manifest={'purpose':'recovery_only_not_qualification','savedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseCommit':base,'patchBytes':len(patch),'patchSha256':sha(patch),'archiveSha256':sha(z),'untrackedSourceFiles':newrows,'privateCandidateFiles':rows,'privateCandidateArchiveSha256':sha((out/'private-candidates.tar.gz').read_bytes())}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(out/'README.md').write_text('# Recoverable source checkpoint r46\n\nRecovery only; ongoing diagnostics and candidates are not qualified. Apply working-source.patch.gz at the exact manifest base, then extract untracked-source.tar.gz. Private candidates use preparation/ and main-extra/ prefixes and must not be applied without review.\n')
print(json.dumps({'output':str(out),'files':len(rows),'privateBytes':(out/'private-candidates.tar.gz').stat().st_size,'patchBytes':len(patch)}))
