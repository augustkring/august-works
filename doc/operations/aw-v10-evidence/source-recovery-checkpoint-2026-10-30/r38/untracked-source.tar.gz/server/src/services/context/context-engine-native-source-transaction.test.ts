import { beforeEach, describe, expect, it, vi } from "vitest";
import { PgTransaction } from "drizzle-orm/pg-core";
import type { Db } from "@paperclipai/db";
import type { EvidenceItem } from "@paperclipai/shared";

const state = vi.hoisted(() => ({ active: false, remoteCalls: [] as Array<{ key: string; active: boolean }>,
  externalEvidence: [] as EvidenceItem[], manifests: [] as Array<{ db: object; store: unknown; active: boolean }>,
  memoryReads: [] as Array<{ db: object; store: unknown; active: boolean }> }));
vi.mock("../access.js", () => ({ accessService: () => ({ decide: async () => ({ allowed: true, explanation: "fixture" }) }) }));
vi.mock("../activity-log.js", () => ({ logActivity: async () => undefined }));
vi.mock("../foundation/foundation-index.js", () => ({ foundationIndexService: () => ({ search: async () => [] }) }));
vi.mock("../instance-settings.js", () => ({ instanceSettingsService: () => ({ getExperimental: async () => ({ enableCollectiveMemoryV1: true }) }) }));
vi.mock("../analytical-context-authority.js", () => ({ assertAnalyticalContextPayloadAccess: async () => undefined }));
vi.mock("../memory/cognitive-memory.js", () => ({ cognitiveMemoryActor: (actor: unknown) => ({ authorizationActor: actor }) }));
vi.mock("../memory/memory-retrieval.js", () => ({ retrieveEligibleMemory: async (db: object, input: { structuralProofMemoStore?: unknown }) => {
  state.memoryReads.push({ db, store: input.structuralProofMemoStore, active: state.active }); return [];
} }));
vi.mock("../memory/cognitive-context.js", () => ({ cognitiveContextProvider: () => ({ key: "cognitive_memory", requirement: "optional", retrieve: async () => {
  state.remoteCalls.push({ key: "cognitive_memory", active: state.active }); return { evidence: [] };
} }) }));
vi.mock("../memory/derived-context.js", () => ({ derivedMemoryContextProvider: () => ({ key: "derived_memory", requirement: "optional", retrieve: async () => {
  state.remoteCalls.push({ key: "derived_memory", active: state.active }); return { evidence: [] };
} }) }));
vi.mock("../knowledge/github-synced-connected-knowledge.js", () => ({ githubSyncedConnectedKnowledgeProvider: () => ({ descriptor: { key: "github" } }) }));
vi.mock("../knowledge/slack-live-connected-knowledge.js", () => ({ slackLiveConnectedKnowledgeProvider: () => ({ descriptor: { key: "slack" } }) }));
vi.mock("../knowledge/connected-knowledge.js", () => ({ createConnectedKnowledgeRegistry: () => ({}),
  connectedKnowledgeContextProvider: (_registry: unknown, key: string) => ({ key, requirement: "optional", retrieve: async () => {
    state.remoteCalls.push({ key, active: state.active }); return { evidence: key === "github" ? state.externalEvidence : [] };
  } }) }));
vi.mock("./context-manifest.js", async (importOriginal) => ({ ...(await importOriginal<typeof import("./context-manifest.js")>()), contextManifestService: (db: object) => ({ create: async (_input: unknown, _bootstrap: unknown,
  options: { structuralProofMemoStore?: unknown } = {}) => {
  state.manifests.push({ db, store: options.structuralProofMemoStore, active: state.active });
  return { manifest: { id: "55555555-5555-4555-8555-555555555555" }, items: [], roots: [] };
} }) }));
import { contextEngineService } from "./context-engine.js";

const input = { companyId: "11111111-1111-4111-8111-111111111111", agentId: "22222222-2222-4222-8222-222222222222",
  issueId: "33333333-3333-4333-8333-333333333333", runId: "44444444-4444-4444-8444-444444444444",
  responsibleUserId: "66666666-6666-4666-8666-666666666666", query: "current strategy", includeFoundation: false,
  authorizationActor: { type: "agent" as const, source: "agent_jwt" as const,
    companyId: "11111111-1111-4111-8111-111111111111", agentId: "22222222-2222-4222-8222-222222222222",
    runId: "44444444-4444-4444-8444-444444444444", onBehalfOfUserId: "66666666-6666-4666-8666-666666666666" } };
const externalEvidence: EvidenceItem = { id: "remote-guidance", companyId: input.companyId, sourceClass: "foundation",
  sourceProvider: "fixture", sourceType: "guidance", sourceRef: "fixture://guidance", title: "Current guidance",
  excerpt: "Current strategy", sourceVersion: "1", sourceUpdatedAt: "2026-10-30T00:00:00.000Z",
  observedAt: "2026-10-30T00:00:00.000Z", validFrom: null, validUntil: null, authorityDomain: "strategy",
  trustLevel: "high", sensitivity: "internal", citation: { label: "Guidance" }, metadata: {} };
function database() {
  const task = { id: input.issueId, companyId: input.companyId, status: "in_progress", title: "Current strategy",
    description: "Current source", updatedAt: new Date(), priority: "medium", identifier: "CTX-1" };
  const select = () => {
    const query = { from: () => query, where: () => query, limit: () => query,
      then: (resolve: (rows: typeof task[]) => unknown) => Promise.resolve([task]).then(resolve) };
    return query;
  };
  const tx = Object.assign(Object.create(PgTransaction.prototype), { select, execute: async () => [] });
  const transaction = vi.fn(async (read: (db: Db) => Promise<unknown>) => {
    expect(state.active).toBe(false); state.active = true;
    try { return await read(tx); } finally { state.active = false; }
  });
  return { db: { select, execute: async () => [], transaction } as unknown as Db, tx, transaction };
}
beforeEach(() => { state.active = false; state.remoteCalls = []; state.externalEvidence = []; state.manifests = []; state.memoryReads = []; });
describe("Native Context local source transaction", () => {
  it("retrieves external providers once outside the shared Task/Memory publication transaction", async () => {
    const { db, tx, transaction } = database();
    await contextEngineService(db).assembleNativeBootstrap(input);
    expect(state.remoteCalls).toEqual(["cognitive_memory", "derived_memory", "github", "slack"].map(key => ({ key, active: false })));
    expect(transaction).toHaveBeenCalledTimes(1);
    expect(state.memoryReads).toHaveLength(1);
    expect(state.memoryReads[0]).toMatchObject({ db: tx, active: true });
    expect(state.manifests).toHaveLength(1);
    expect(state.manifests[0]).toMatchObject({ db: tx, active: true });
    expect(state.manifests[0]!.store).toBe(state.memoryReads[0]!.store);
    expect(state.manifests[0]!.store).toMatchObject({ transaction: tx });
  });
  it("keeps external evidence and the original publication boundary without replaying retrieval", async () => {
    state.externalEvidence = [externalEvidence]; const { db } = database();
    const result = await contextEngineService(db).assembleNativeBootstrap(input);
    expect(result.packet.foundation).toContainEqual(externalEvidence);
    expect(state.remoteCalls).toHaveLength(4);
    expect(state.remoteCalls.every(call => !call.active)).toBe(true);
    expect(state.memoryReads[0]).toMatchObject({ db, active: false, store: undefined });
    expect(state.manifests[0]).toMatchObject({ db, active: false, store: undefined });
  });
  it("keeps custom provider execution outside the shared transaction", async () => {
    const { db, transaction } = database(); const retrieve = vi.fn(async () => {
      expect(state.active).toBe(false); return { evidence: [externalEvidence] };
    });
    await contextEngineService(db, { providers: [{ key: "custom", requirement: "mandatory", retrieve }] }).assembleNativeBootstrap(input);
    expect(retrieve).toHaveBeenCalledTimes(1); expect(transaction).not.toHaveBeenCalled();
    expect(state.manifests[0]).toMatchObject({ db, store: undefined, active: false });
  });
});
