from pathlib import Path
import hashlib,gzip,io,json,os,stat,tarfile,time,collections
prep=Path('/workspace/v10-preparation')
out=prep/'durable-closed-r38-host-backups-recovery-20261101'
if out.exists(): raise SystemExit('output exists')
out.mkdir(mode=0o700)
tmp=Path('/tmp')
targets=[tmp/f'blentera-r14.38.4.{n}-build-backup' for n in (16,17,27,28,29)]
donors=[tmp/'blentera-r14.12-build-backup']+[p for p in sorted(tmp.glob('blentera-r14.38.4.*-build-backup')) if p.is_dir() and not p.is_symlink() and p.name.split('r14.38.4.',1)[1].split('-',1)[0].isdigit() and int(p.name.split('r14.38.4.',1)[1].split('-',1)[0])<=17]
# Explicitly exclude target roots from donor inventory except when no previous canonical exists.
assert all(p.is_dir() and not p.is_symlink() for p in targets+donors)
assert all(not p.is_symlink() for p in targets+donors)

def sha_file(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
def snap_path(p):
 s=p.lstat(); base={'path':str(p),'mode':stat.S_IMODE(s.st_mode),'mtimeNs':s.st_mtime_ns,'atimeNs':s.st_atime_ns,'uid':s.st_uid,'gid':s.st_gid}
 if stat.S_ISLNK(s.st_mode): base.update(kind='link',target=os.readlink(p))
 elif stat.S_ISDIR(s.st_mode): base['kind']='directory'
 elif stat.S_ISREG(s.st_mode): base.update(kind='file',bytes=s.st_size,sha256=sha_file(p),blocks=s.st_blocks)
 else: raise RuntimeError('unsupported file type '+str(p))
 s2=p.lstat()
 if (s.st_mode,s.st_size,s.st_mtime_ns,s.st_uid,s.st_gid)!=(s2.st_mode,s2.st_size,s2.st_mtime_ns,s2.st_uid,s2.st_gid): raise RuntimeError('changed during inventory '+str(p))
 return base
# Full snapshots of all target trees, including dirs and links.
target_manifest=[]
for root in targets:
 for p in [root,*sorted(root.rglob('*'))]: target_manifest.append(snap_path(p))
# Hash candidate target files and find eligible prior canonical donors.
groups=collections.defaultdict(list)
for root in targets:
 for p in sorted(root.rglob('*')):
  s=p.lstat()
  if not stat.S_ISREG(s.st_mode): continue
  rec=snap_path(p); key=(rec['sha256'],rec['mode'],rec['uid'],rec['gid'],rec['bytes'])
  groups[key].append((p,rec))
donor_index=collections.defaultdict(list)
for root in donors:
 for p in sorted(root.rglob('*')):
  try:s=p.lstat()
  except FileNotFoundError: raise RuntimeError('donor vanished '+str(p))
  if not stat.S_ISREG(s.st_mode): continue
  rec=snap_path(p); key=(rec['sha256'],rec['mode'],rec['uid'],rec['gid'],rec['bytes'])
  donor_index[key].append((p,rec))
# Select all duplicate target paths, preferring a donor outside mutation set.
rows=[]; archive_hashes={}
target_set={str(x) for x in targets}
for key,entries in groups.items():
 existing=donor_index.get(key,[])
 canonical=existing[0] if existing else (entries[0] if len(entries)>1 else None)
 if canonical is None: continue
 cpath,crec=canonical
 for p,rec in entries:
  if str(p)==str(cpath): continue
  st=os.stat(p); cs=os.stat(cpath)
  if (st.st_dev,st.st_ino)==(cs.st_dev,cs.st_ino): continue
  if st.st_dev!=cs.st_dev: raise RuntimeError('cross-device hardlink rejected')
  # Reverify identity and metadata immediately before plan capture.
  if sha_file(p)!=key[0] or sha_file(cpath)!=key[0]: raise RuntimeError('hash changed')
  rows.append({'path':str(p),'canonical':str(cpath),'sha256':key[0],'bytes':key[-1],
   'mode':rec['mode'],'uid':rec['uid'],'gid':rec['gid'],'mtimeNs':rec['mtimeNs'],'atimeNs':rec['atimeNs'],
   'canonicalMtimeNs':crec['mtimeNs'],'canonicalAtimeNs':crec['atimeNs'],'blocks':st.st_blocks})
  archive_hashes[key[0]]=key[-1]
# Archive each unique content payload that will be replaced by a link, before any mutation.
archive_tmp=out/'original-content.tar.gz'
with tarfile.open(archive_tmp,'w:gz',compresslevel=6) as tar:
 for h,size in sorted(archive_hashes.items()):
  row=next(r for r in rows if r['sha256']==h)
  p=Path(row['path']); data=p.read_bytes()
  if len(data)!=size or hashlib.sha256(data).hexdigest()!=h: raise RuntimeError('archive input mismatch '+str(p))
  ti=tarfile.TarInfo(h); ti.size=size; ti.mode=0o600; ti.uid=0; ti.gid=0; ti.mtime=0
  tar.addfile(ti,io.BytesIO(data))
# Verify archive in streaming mode before any link changes.
seen={}
with tarfile.open(archive_tmp,'r|gz') as tar:
 for member in tar:
  if not member.isfile() or member.name not in archive_hashes or member.name in seen: raise RuntimeError('bad archive entry')
  f=tar.extractfile(member); h=hashlib.sha256(); n=0
  while True:
   b=f.read(1024*1024)
   if not b: break
   n+=len(b); h.update(b)
  if n!=archive_hashes[member.name] or h.hexdigest()!=member.name: raise RuntimeError('archive payload mismatch')
  seen[member.name]=n
if set(seen)!=set(archive_hashes): raise RuntimeError('archive content set mismatch')
archive_sha=sha_file(archive_tmp); archive_bytes=archive_tmp.stat().st_size
# Persist full target-tree manifest and selected rows before mutations.
plan={'scope':'Only closed generated TMP R38 backup roots .4.16, .4.17, .4.27, .4.28, .4.29. Active .4.30, MAIN/MIRROR, source, dependencies, provider packs and PG untouched. Unique original duplicate-content payloads are archived before links; original per-path file mtimes/atimes are recorded because hardlinks share inode metadata; directory timestamps restored. inode/ctime changes are expected.','targets':[str(x) for x in targets],'donorRoots':[str(x) for x in donors],'targetInventory':target_manifest,'rows':rows,'archiveSha256':archive_sha,'archiveBytes':archive_bytes,'uniqueArchivedContentBytes':sum(archive_hashes.values())}
plan_bytes=json.dumps(plan,separators=(',',':'),sort_keys=True).encode()
plan_gz=gzip.compress(plan_bytes,mtime=0)
(out/'pre-mutation-plan.json.gz').write_bytes(plan_gz)
# Verify plan/archive files are durable and hashes exact before linking.
assert hashlib.sha256((out/'pre-mutation-plan.json.gz').read_bytes()).hexdigest()==hashlib.sha256(plan_gz).hexdigest()
assert sha_file(archive_tmp)==archive_sha
# Recheck every target path from manifest before mutation.
for r in target_manifest:
 p=Path(r['path']); cur=snap_path(p)
 for k in ('kind','mode','mtimeNs','uid','gid'):
  if cur.get(k)!=r.get(k): raise RuntimeError('prelink metadata mismatch '+r['path'])
 if r['kind']=='file' and (cur['bytes']!=r['bytes'] or cur['sha256']!=r['sha256']): raise RuntimeError('prelink content mismatch '+r['path'])
 if r['kind']=='link' and cur['target']!=r['target']: raise RuntimeError('prelink symlink mismatch '+r['path'])
# Recheck donors and create links atomically only at target paths.
for r in rows:
 p=Path(r['path']); c=Path(r['canonical'])
 if p.is_symlink() or c.is_symlink() or not p.is_file() or not c.is_file(): raise RuntimeError('link endpoint changed')
 if sha_file(p)!=r['sha256'] or sha_file(c)!=r['sha256']: raise RuntimeError('link endpoint bytes changed')
 ps=p.stat(); cs=c.stat()
 if (ps.st_dev,ps.st_size,stat.S_IMODE(ps.st_mode),ps.st_uid,ps.st_gid)!=(cs.st_dev,cs.st_size,stat.S_IMODE(cs.st_mode),cs.st_uid,cs.st_gid): raise RuntimeError('link metadata mismatch')
 tmp_link=p.with_name(p.name+'.verified-dedup-link')
 if tmp_link.exists() or tmp_link.is_symlink(): raise RuntimeError('temp path exists')
 os.link(c,tmp_link); os.replace(tmp_link,p)
# Restore timestamps of all target directories, including roots, after link changes.
for r in target_manifest:
 if r['kind']=='directory': os.utime(r['path'],ns=(r['atimeNs'],r['mtimeNs']))
# Verify path sets, symlinks, file content/mode/ownership/size and directories.
after=[]
for root in targets:
 for p in [root,*sorted(root.rglob('*'))]: after.append(snap_path(p))
expected={r['path']:r for r in target_manifest}; observed={r['path']:r for r in after}
if set(expected)!=set(observed): raise RuntimeError('target path set changed')
for path,e in expected.items():
 a=observed[path]
 if e['kind']!=a['kind'] or e['mode']!=a['mode'] or e['uid']!=a['uid'] or e['gid']!=a['gid']: raise RuntimeError('after metadata mismatch '+path)
 if e['kind']=='file' and (e['bytes']!=a['bytes'] or e['sha256']!=a['sha256']): raise RuntimeError('after content mismatch '+path)
 if e['kind']=='link' and e['target']!=a['target']: raise RuntimeError('after link mismatch '+path)
 if e['kind']=='directory' and e['mtimeNs']!=a['mtimeNs']: raise RuntimeError('directory mtime mismatch '+path)
# Verify donors remain byte/mode/ownership/mtime-identical to recorded canonical metadata.
donor_after=[]
seen_donors={r['canonical'] for r in rows}
for path in sorted(seen_donors):
 p=Path(path); s=p.lstat(); donor_after.append({'path':path,'sha256':sha_file(p),'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtimeNs':s.st_mtime_ns,'nlink':s.st_nlink})
for row in rows:
 d=next(x for x in donor_after if x['path']==row['canonical'])
 if (d['sha256'],d['bytes'],d['mode'],d['uid'],d['gid'],d['mtimeNs'])!=(row['sha256'],row['bytes'],row['mode'],row['uid'],row['gid'],row['canonicalMtimeNs']): raise RuntimeError('donor content/metadata changed '+row['canonical'])
# Store a full after manifest (compressed) and receipt.
after_bytes=json.dumps(after,separators=(',',':'),sort_keys=True).encode(); (out/'after-mutation-manifest.json.gz').write_bytes(gzip.compress(after_bytes,mtime=0))
receipt={'scope':plan['scope'],'targetRoots':[str(p) for p in targets],'targetRegularFiles':sum(1 for r in target_manifest if r['kind']=='file'),'targetPathEntries':len(target_manifest),'hardlinkedTargetPaths':len(rows),'reclaimedLogicalBytes':sum(r['bytes'] for r in rows),'reclaimedAllocatedBytes':sum(r['blocks']*512 for r in rows),'uniqueArchivedHashes':len(archive_hashes),'uniqueArchivedOriginalBytes':sum(archive_hashes.values()),'archivePath':str(archive_tmp),'archiveSha256':archive_sha,'archiveBytes':archive_bytes,'preMutationManifestSha256':hashlib.sha256(plan_gz).hexdigest(),'afterMutationManifestSha256':sha_file(out/'after-mutation-manifest.json.gz'),'donorPathsVerified':len(donor_after),'donorManifest':donor_after,'restore':'For any original path requiring independent inode metadata, extract the unique SHA256 member from original-content.tar.gz to a same-directory temp file, verify size/hash, chmod/chown as recorded (uid/gid), set original atime/mtime from pre-mutation-plan.json.gz, then atomically replace; directory timestamps and all original path entries/modes/ownership are in the plan. All target file bytes/modes/ownership and directory mtimes verified after linking; file mtime/atime may now be shared with canonical donor and are exactly recoverable from plan+archive. inode/ctime/link-count changes are expected.'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['hardlinkedTargetPaths','reclaimedLogicalBytes','reclaimedAllocatedBytes','uniqueArchivedHashes','uniqueArchivedOriginalBytes','archiveBytes','preMutationManifestSha256','afterMutationManifestSha256','archiveSha256']}))
