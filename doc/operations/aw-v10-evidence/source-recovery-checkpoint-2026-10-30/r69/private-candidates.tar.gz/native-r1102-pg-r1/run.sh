#!/usr/bin/env bash
set -euo pipefail
CAND=/workspace/v10-preparation/native-provider-preparation-controls-r111
MIRROR=/workspace/v10-dep-qualification
OUT=$CAND/qualification-r1
mkdir -m700 "$OUT"
exec 9>/workspace/v10-preparation/v10-pg-tests.lock
flock -x 9
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH
python3 - "$CAND" "$MIRROR" "$OUT" <<'PY'
from pathlib import Path
import hashlib,json,shutil,stat,sys
cand,mirror,out=map(Path,sys.argv[1:]); pins=json.loads((cand/'test-pins.json').read_text());state=[]
for row in pins['sourceFiles']:
 src=Path(row['sourcePath']);assert hashlib.sha256(src.read_bytes()).hexdigest()==row['sha256']
 dst=mirror/row['path'];before=hashlib.sha256(dst.read_bytes()).hexdigest() if dst.is_file() else None
 saved=out/'backup'/row['path']
 if dst.is_file():saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(dst,saved)
 state.append({**row,'beforeSha256':before,'beforeMode':stat.S_IMODE(dst.stat().st_mode) if dst.is_file() else None})
(out/'state.json').write_text(json.dumps(state,indent=2)+'\n')
PY
restore() {
python3 - "$MIRROR" "$OUT" <<'PY'
from pathlib import Path
import hashlib,json,shutil,stat,sys
mirror,out=map(Path,sys.argv[1:]);errors=[]
for r in json.loads((out/'state.json').read_text()):
 p=mirror/r['path'];got=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
 if got not in [r['sha256'],r['beforeSha256']]:errors.append('guard:'+r['path']);continue
 if r['beforeSha256'] is None:p.unlink(missing_ok=True)
 else:shutil.copy2(out/'backup'/r['path'],p)
 got=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
 if got!=r['beforeSha256'] or (p.is_file() and stat.S_IMODE(p.stat().st_mode)!=r['beforeMode']):errors.append('restore:'+r['path'])
(out/'restore.log').write_text('\n'.join(errors)+'\n' if errors else 'All overlaid sources restored to actual-before bytes/modes.\n')
if errors:raise SystemExit(1)
PY
}
trap restore EXIT
python3 - "$CAND" "$MIRROR" <<'PY'
from pathlib import Path
import json,shutil,sys
cand,mirror=map(Path,sys.argv[1:])
for r in json.loads((cand/'test-pins.json').read_text())['sourceFiles']:
 dst=mirror/r['path'];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r['sourcePath'],dst)
PY
cd "$MIRROR/server"
set +e
timeout 120 pnpm exec vitest run src/__tests__/native-selected-provider-preparation.integration.test.ts --maxWorkers=1 --reporter=verbose > "$OUT/test.log" 2>&1
rc=$?
set -e
printf '%s\n' "$rc" > "$OUT/test.exit"
exit "$rc"
