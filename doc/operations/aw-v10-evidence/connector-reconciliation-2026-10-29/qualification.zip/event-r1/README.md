# Connector lifecycle projection and webhook reconciliation receipt

This is a bounded software receipt for V10-067/069/071 lifecycle status projection. It does not qualify provider-wide webhook completeness, missed-delivery detection, renewal, or deprecation.

The source-pinned mirror run used `run-pinned-native-test.sh` for `server/src/__tests__/github-connection-events.test.ts` with the exact pattern `applies installation events once`. Two parameterized cases passed: an installation-membership delivery invalidates the repository snapshot and projects full reconciliation as required; an event older than a newer verified snapshot leaves that snapshot available. The independent projector unit file passed 12/12 in the main workspace after the same source hashes were confirmed against the pinned manifest.

The test's `refreshed: true` setup advances the recorded access-refresh timestamp while retaining its preseeded repository snapshot; it does not call GitHub. Real GitHub refresh behavior remains in the existing `loadGitHubGrantMetadata` and managed OAuth refresh owners. This receipt makes no live provider claim. `gapDetection` stays `not_reported` because the leased Cloud delivery IDs are opaque and no provider feed watermark exists.

The pinned helper captured 1,080 changed/untracked source files for its temporary execution snapshot. The selected-path pins and copies support quick review; `qualification-source.zip` preserves the original full source patch and all captured untracked files, plus the original helper manifest, so the exact environment can be reconstructed without substituting later workspace bytes.

Run details, full and selected source pins, executable hash, syntax check, test log and exit codes are retained alongside the selected source copies. `test.exit` is the authoritative pinned integration process exit; `projector-unit.log` records 12 passing tests.
