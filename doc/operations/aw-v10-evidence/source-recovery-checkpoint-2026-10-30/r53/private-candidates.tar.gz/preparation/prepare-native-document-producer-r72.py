from pathlib import Path
import hashlib,json,difflib
r=Path('/workspace/blentera-v10');base=Path('/workspace/v10-preparation/native-capacity-r70-candidate');out=Path('/workspace/v10-preparation/native-document-producer-r72-candidate');rel='server/src/services/native-direct-input.ts';old=(base/rel).read_text();s=old
needle='''  const snapshot = parsed.data;
  excludeUnpinnedNativeSourceProofs(scope, snapshot.policy, snapshot.inputs);
  const documentProofKey'''
replacement='''  const snapshot = parsed.data;
  const dispatchInputs = snapshot.inputs.filter((source): source is Extract<NativePayloadSourceInput,
    { kind: "worker_model_dispatch" | "conversation_model_dispatch" }> =>
    source.kind === "worker_model_dispatch" || source.kind === "conversation_model_dispatch");
  const lastInput = snapshot.inputs.at(-1);
  const writerDispatch = lastInput?.kind === "worker_model_dispatch" || lastInput?.kind === "conversation_model_dispatch"
    ? lastInput : undefined;
  // The server writer appends its own dispatch after all retained inputs.
  // Earlier Runs remain sources; only this exact revision's producer may own
  // the write_document capture and the final appended marker.
  if (dispatchInputs.length > 64 || dispatchInputs.length > 0 && (!writerDispatch ||
    revision.createdByRunId !== writerDispatch.runId ||
    dispatchInputs.filter(source => isDeepStrictEqual(source, writerDispatch)).length !== 1))
    throw forbidden("The Native document source has ambiguous model dispatches");
  const dispatchRunId = writerDispatch?.runId;
  excludeUnpinnedNativeSourceProofs(scope, snapshot.policy, snapshot.inputs);
  const documentProofKey'''
assert s.count(needle)==1;s=s.replace(needle,replacement,1)
needle='''    const sourceDispatch = snapshot.inputs.find((source): source is Extract<NativePayloadSourceInput,
      { kind: "worker_model_dispatch" | "conversation_model_dispatch" }> =>
      source.kind === "worker_model_dispatch" || source.kind === "conversation_model_dispatch");'''
assert s.count(needle)==1;s=s.replace(needle,'    const sourceDispatch = writerDispatch;',1)
needle='''      runId: snapshot.inputs.find(source => source.kind === "worker_model_dispatch" || source.kind === "conversation_model_dispatch")?.runId ?? input.revisionId,'''
assert s.count(needle)==1;s=s.replace(needle,'      runId: dispatchRunId ?? input.revisionId,',1)
needle='''  const dispatchInputs = snapshot.inputs.filter((source): source is Extract<NativePayloadSourceInput, { kind: "worker_model_dispatch" | "conversation_model_dispatch" }> =>
    source.kind === "worker_model_dispatch" || source.kind === "conversation_model_dispatch");
  const dispatchRunId = dispatchInputs[0]?.runId;
  if (dispatchInputs.some(source => source.runId !== dispatchRunId) || dispatchInputs.length > 64)
    throw forbidden("The Native document source has ambiguous model dispatches");
'''
assert s.count(needle)==1;s=s.replace(needle,'',1)
needle='''        source.contentHash === result.resultDigest && bound.length === 1 && associations.length === 1) {'''
replacement='''        source.contentHash === result.resultDigest && bound.length === 1 && associations.length === 1 &&
        isDeepStrictEqual(bound[0]!.dispatch, writerDispatch)) {'''
assert s.count(needle)==1;s=s.replace(needle,replacement,1)
needle='    if (dispatchInputs.length === 1 && !dispatch) dispatch = dispatchInputs[0];';assert s.count(needle)==1;s=s.replace(needle,'    if (dispatchInputs.length === 1 && !dispatch) dispatch = writerDispatch;',1)
f=out/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s);(out/'r72-only.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
test='server/src/__tests__/native-payload-temporal-sources.integration.test.ts';t=(base/test).read_text();needle='''    await expect(assertNativeDocumentRevisionCurrentSourceAccess(db, { companyId: first.companyId,
      issueId: first.issueId, revisionId: revisionB.id, actor: second.bobActor, requireLatest: true })).rejects.toMatchObject({ status: 403 });
'''
addition='''
    // A later Run's document retains earlier dispatches while its exact
    // constructor-appended marker and revision writer identify one producer.
    const followupCapture = (second.toolResultSourceCaptures as Array<Record<string, unknown>>).find(value =>
      value.tool === "write_document" && value.documentRevision && typeof value.documentRevision === "object");
    const documentC = followupCapture?.documentRevision as { revisionId: string; issueId: string } | undefined;
    if (!documentC) throw new Error("The follow-up Run has no actual document capture");
    const [revisionC] = await db.select().from(documentRevisions).where(and(
      eq(documentRevisions.companyId, first.companyId), eq(documentRevisions.id, documentC.revisionId)));
    if (!revisionC) throw new Error("The follow-up Native document revision disappeared");
    const snapshotC = nativePayloadSourceSnapshotSchema.parse(revisionC.payloadSourceSnapshot);
    const dispatches = snapshotC.inputs.filter(source =>
      source.kind === "worker_model_dispatch" || source.kind === "conversation_model_dispatch");
    expect(new Set(dispatches.map(source => source.runId))).toEqual(new Set([first.runId, second.runId]));
    expect(snapshotC.inputs.at(-1)).toMatchObject({ runId: second.runId });
    expect(revisionC.createdByRunId).toBe(second.runId);
    const validateC = (sourceDb: typeof db) => assertNativeDocumentRevisionCurrentSourceAccess(sourceDb,
      { companyId: first.companyId, issueId: documentC.issueId, revisionId: revisionC.id, actor: second.aliceActor });
    await expect(validateC(db)).resolves.toBeUndefined();
    await expect(assertNativeDocumentRevisionCurrentSourceAccess(db, { companyId: first.companyId,
      issueId: documentC.issueId, revisionId: revisionC.id, actor: second.bobActor })).rejects.toMatchObject({ status: 403 });
    await db.transaction(async rawTx => {
      const tx = rawTx as unknown as typeof db;
      await tx.execute(sql`savepoint native_document_wrong_writer`);
      try {
        const earlier = dispatches.find(source => source.runId === first.runId)!;
        const { digest: _digest, ...body } = snapshotC;
        const wrongFinalWriter = { ...body, inputs: [...snapshotC.inputs, earlier] };
        await tx.update(documentRevisions).set({ payloadSourceSnapshot: sql`(select value || jsonb_build_object(
          'digest',encode(sha256(convert_to(value::text,'UTF8')),'hex'))
          from (select ${JSON.stringify(wrongFinalWriter)}::jsonb as value) supplied)` }).where(eq(documentRevisions.id, revisionC.id));
        await expect(validateC(tx)).rejects.toMatchObject({ status: 403,
          message: "The Native document source has ambiguous model dispatches" });
      } finally {
        await tx.execute(sql`rollback to savepoint native_document_wrong_writer`);
        await tx.execute(sql`release savepoint native_document_wrong_writer`);
      }
      await expect(validateC(tx)).resolves.toBeUndefined();
      const [run] = await tx.select({ profile: heartbeatRuns.runnerProfileJson }).from(heartbeatRuns)
        .where(and(eq(heartbeatRuns.companyId, first.companyId), eq(heartbeatRuns.id, second.runId)));
      const profile = run?.profile as Record<string, unknown>;
      const captures = profile.nativeToolResultSourceCaptures as Array<Record<string, unknown>>;
      try {
        await tx.update(heartbeatRuns).set({ runnerProfileJson: { ...profile,
          nativeToolResultSourceCaptures: [...captures, followupCapture] } }).where(eq(heartbeatRuns.id, second.runId));
        await expect(validateC(tx)).rejects.toMatchObject({ status: 403 });
      } finally {
        await tx.update(heartbeatRuns).set({ runnerProfileJson: profile }).where(eq(heartbeatRuns.id, second.runId));
      }
      await expect(validateC(tx)).resolves.toBeUndefined();
    });
'''
assert t.count(needle)==1;t=t.replace(needle,needle+addition,1);(out/test).parent.mkdir(parents=True,exist_ok=True);(out/test).write_text(t)
m={}
for path in [rel,test]:
 a=(r/path).read_bytes();b=(out/path).read_bytes();m[path]={'priorSha256':hashlib.sha256(a).hexdigest(),'candidateSha256':hashlib.sha256(b).hexdigest()};(out/(Path(path).name+'.diff')).write_text(''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+path,tofile='b/'+path)))
(out/'manifest.json').write_text(json.dumps(m,indent=2));(out/'syntax-pins.json').write_text(json.dumps({'qualificationWorkspace':str(out),'copiedFiles':[{'path':path} for path in m]},indent=2))
p=Path('/workspace/v10-preparation');snapshot=(p/'snapshot-private-native-r70.py').read_text().replace('native-capacity-r70-candidate','native-document-producer-r72-candidate');(p/'snapshot-private-native-r72.py').write_text(snapshot);runner=(p/'run-private-native-capacity-r70-quiet.sh').read_text().replace('snapshot-private-native-r70.py','snapshot-private-native-r72.py');(p/'run-private-native-document-r72-quiet.sh').write_text(runner)
print((out/'r72-only.diff').read_text())
