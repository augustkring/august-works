from pathlib import Path
p=Path('/workspace/blentera-v10/server/src/services/native-direct-input.ts');s=p.read_text()
s=s.replace('type NativeSiblingToolSourceProofs =','type NativeCompletedTaskSourceProofs = Map<string, { key: string; descendants: Set<string> }>;\ntype NativeSiblingToolSourceProofs =',1)
s=s.replace('completedTaskSourceProofs?: Map<string, string>','completedTaskSourceProofs?: NativeCompletedTaskSourceProofs')
s=s.replace('const completedTaskSourceProofs = new Map<string, string>();','const completedTaskSourceProofs: NativeCompletedTaskSourceProofs = new Map();')
s=s.replace('''        if (proofIdentity && completedTaskSourceProofs.has(proofIdentity)) {
          nativeSourceReadWork(scope);''','''        const taskProof = proofIdentity ? completedTaskSourceProofs?.get(proofIdentity) : undefined;
        if (taskProof && !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, taskProof.descendants)) {
          nativeSourceReadWork(scope);
          for (const parent of scope.context.ancestry.frozenTaskProofStacks.get(scope.actorKey) ?? [])
            for (const descendant of taskProof.descendants) parent.descendants.add(descendant);''',1)
needle='''        const snapshotDigest = await assertNativeTaskSourceInputCurrentInScope(db, input.companyId, input.actor, source, scope);
        if (proofIdentity && snapshotDigest) completedTaskSourceProofs!.set(proofIdentity,
          nativeManagedConsumedTaskSourceProofKey(input.companyId, input.actor, source, snapshotDigest,
            scope.context.memoryTemporalIdentity));'''
replacement='''        let taskProofStack = scope.context.ancestry.frozenTaskProofStacks.get(scope.actorKey);
        if (!taskProofStack) {
          taskProofStack = [];
          scope.context.ancestry.frozenTaskProofStacks.set(scope.actorKey, taskProofStack);
        }
        const taskFrame = { visitKey: proofIdentity ?? "", descendants: new Set<string>() };
        taskProofStack.push(taskFrame);
        try {
          const snapshotDigest = await assertNativeTaskSourceInputCurrentInScope(db, input.companyId, input.actor, source, scope);
          if (proofIdentity && snapshotDigest) completedTaskSourceProofs!.set(proofIdentity, {
            key: nativeManagedConsumedTaskSourceProofKey(input.companyId, input.actor, source, snapshotDigest,
              scope.context.memoryTemporalIdentity), descendants: taskFrame.descendants });
        } finally {
          if (taskProofStack.at(-1) === taskFrame) taskProofStack.pop();
        }'''
assert s.count(needle)==1;s=s.replace(needle,replacement)
needle='''          const taskProofAlreadyCurrent = Boolean(taskProofIdentity && completedTaskSourceProofs?.get(taskProofIdentity) ===
            nativeManagedConsumedTaskSourceProofKey(companyId, actor, taskSource, snapshot.data.digest,
              scope.context.memoryTemporalIdentity));'''
replacement='''          const taskProof = taskProofIdentity ? completedTaskSourceProofs?.get(taskProofIdentity) : undefined;
          const taskProofAlreadyCurrent = Boolean(taskProof && taskProof.key ===
            nativeManagedConsumedTaskSourceProofKey(companyId, actor, taskSource, snapshot.data.digest,
              scope.context.memoryTemporalIdentity) &&
            !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, taskProof.descendants));
          if (taskProofAlreadyCurrent && taskProof) {
            for (const parent of scope.context.ancestry.frozenTaskProofStacks.get(scope.actorKey) ?? [])
              for (const descendant of taskProof.descendants) parent.descendants.add(descendant);
          }'''
assert s.count(needle)==1;s=s.replace(needle,replacement)
p.with_suffix('.taskdescendants.tmp.ts').write_text(s)
