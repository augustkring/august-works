import fcntl,json,os,pathlib,signal,subprocess,sys,time
q=pathlib.Path(__file__).parent;phase=sys.argv[1];spec=json.loads((q/(phase+'.spec.json')).read_text());cap=spec['rssCapMiB']*1024;deadline=spec['deadlineSeconds'];prehead=spec.get('minimumHeadroomMiB',512)*1024*1024

def state():
 return {'rootFreeKiB':os.statvfs('/').f_bavail*os.statvfs('/').f_frsize//1024,'tmpFreeKiB':os.statvfs('/tmp').f_bavail*os.statvfs('/tmp').f_frsize//1024,'memoryCurrent':int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text()),'memoryMax':int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text()),'events':dict(line.split() for line in pathlib.Path('/sys/fs/cgroup/memory.events').read_text().splitlines())}
def processes():
 rows={}
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   s=(p/'stat').read_text();a=s[s.rfind(')')+2:].split();rss=next((int(l.split()[1]) for l in (p/'status').read_text().splitlines() if l.startswith('VmRSS:')),0);rows[int(p.name)]={'ppid':int(a[1]),'pgid':int(a[2]),'start':a[19],'rss':rss,'state':a[0]}
  except (OSError,ValueError,IndexError):pass
 return rows
fd=os.open('/workspace/v10-preparation/v10-pg-tests.lock',os.O_RDWR);start=time.monotonic()
while True:
 try:fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);break
 except BlockingIOError:
  if time.monotonic()-start>55:raise SystemExit('canonical lock unavailable; no runtime launched')
  time.sleep(.1)
pre=state();assert pre['rootFreeKiB']>=120000 and pre['tmpFreeKiB']>=1048576,pre;assert pre['memoryMax']-pre['memoryCurrent']>=prehead,pre
def mainProof():
 root=pathlib.Path('/workspace/blentera-v10');sha=lambda b:__import__('hashlib').sha256(b).hexdigest()
 git=lambda *args:subprocess.check_output(['git','--no-optional-locks','-C',str(root),*args])
 index=pathlib.Path(git('rev-parse','--git-path','index').decode().strip());index=index if index.is_absolute() else root/index
 return {'head':git('rev-parse','HEAD').decode().strip(),'indexSha256':sha(index.read_bytes()),'refsSha256':sha(git('for-each-ref','--format=%(refname) %(objectname)')),'trackedStatus':git('status','--porcelain=v1','--untracked-files=no').decode()}
beforeMain=mainProof() if spec.get('sourcePins') else None
if beforeMain:
 pins=json.loads(pathlib.Path(spec['sourcePins']).read_text());assert beforeMain['head']==pins['base'] and not beforeMain['trackedStatus'],beforeMain
 for row in pins['paths']:
  assert __import__('hashlib').sha256((pathlib.Path('/workspace/blentera-v10')/row['path']).read_bytes()).hexdigest()==row['baseSha256']
work=pathlib.Path(spec['cwd']);scratch=pathlib.Path(spec['scratch']);scratch.mkdir(parents=True,exist_ok=True)
env=os.environ.copy();env.update({'TMPDIR':str(scratch),'TMP':str(scratch),'TEMP':str(scratch),'XDG_CACHE_HOME':str(scratch/'cache'),'NODE_DISABLE_COMPILE_CACHE':'1','TSX_DISABLE_CACHE':'1','NODE_OPTIONS':'--max-old-space-size=256','GOMAXPROCS':'2','GOMEMLIMIT':spec.get('goMemoryLimit','1536MiB')});env.update(spec.get('env',{}))
log=scratch/(phase+'.log');seen={};peak=0;reason=None;started=time.monotonic();phaseStarted=started;lastPhase=None
with log.open('w') as out:
 child=subprocess.Popen(spec['argv'],cwd=work,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 while child.poll() is None:
  rows=processes();owned={child.pid}|{pid for pid,identity in seen.items() if pid in rows and rows[pid]['start']==identity};changed=True
  while changed:
   changed=False
   for pid,row in rows.items():
    if (row['ppid'] in owned or row['pgid']==child.pid) and pid not in owned:owned.add(pid);changed=True
  for pid in owned:
   if pid in rows:seen[pid]=rows[pid]['start']
  if spec.get('phaseSignalFile'):
   try:
    currentPhase=pathlib.Path(spec['phaseSignalFile']).read_text()
    if currentPhase!=lastPhase:lastPhase=currentPhase;phaseStarted=time.monotonic()
   except OSError:pass
  used=sum(rows[pid]['rss'] for pid in owned if pid in rows);peak=max(peak,used);current=state()
  if used>cap:reason='owned complete process-tree RSS cap'
  elif time.monotonic()-phaseStarted>deadline:reason='deadline'
  elif current['rootFreeKiB']<120000 or current['tmpFreeKiB']<1048576:reason='disk floor'
  elif current['events'].get('oom_kill')!=pre['events'].get('oom_kill'):reason='cgroup OOM'
  if reason:
   for pid,identity in seen.items():
    if pid in rows and rows[pid]['start']==identity:
     try:os.kill(pid,signal.SIGTERM)
     except ProcessLookupError:pass
   try:child.wait(timeout=2)
   except subprocess.TimeoutExpired:
    now=processes()
    for pid,identity in seen.items():
     if pid in now and now[pid]['start']==identity:
      try:os.kill(pid,signal.SIGKILL)
      except ProcessLookupError:pass
   break
  time.sleep(.05)
 child.wait()
remaining=[];lastRows=processes()
for pid,identity in seen.items():
 if pid in lastRows and lastRows[pid]['start']==identity and lastRows[pid]['state']!='Z':remaining.append(pid)
afterMain=mainProof() if beforeMain else None
if beforeMain!=afterMain:reason=reason or 'Main/index/refs changed during qualification'
if remaining:reason=reason or 'owned process leftovers'
receipt={'remainingOwnedPids':remaining,'mainBefore':beforeMain,'mainAfter':afterMain,'phase':phase,'argv':spec['argv'],'pre':pre,'post':state(),'peakOwnedRssKiB':peak,'reason':reason,'exitCode':child.returncode,'seconds':round(time.monotonic()-started,3),'log':str(log),'status':'PASS' if child.returncode==0 and reason is None else 'FAIL'};(q/(phase+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));__import__('gzip');durable=q/(phase+'.log.gz');durable.write_bytes(__import__('gzip').compress(log.read_bytes()));print(log.read_text()[-3000:] if not spec.get('sourcePins') else 'Raw runtime log retained privately: '+str(durable));sys.exit(0 if receipt['status']=='PASS' else 1)
