# Metadata execution readiness — pending final Root signal

NOT EXECUTED. `213f8bcb819f97f3dfffb107493f2313278f4e5f` and its CI successor `d60139d2fac8911a2be89a27e7c20e3e01de6133` are WIP checkpoints, not FINAL_SOURCE_HEAD: Native actual C7 is failing and owners are diagnosing it. Do not refresh current hashes, run metadata apply, or set V10_SOURCE_FREEZE merely because that checkpoint is tracked-clean. Root owns source publication and subsequent source-fix commits; do not rerun the one-time147 publisher or duplicate it here.

## Ready inputs and actual stale assumptions

* Inventory helper: `/workspace/v10-preparation/final-metadata-inventory-audit-nov01/edit-frozen-source-inventory-r2.py`, SHA `9f0619291221763b1e1d59e94af791d266672a7e5276d21bbda0414625135d29`.
* Latest comprehensive plan R9: `/workspace/v10-preparation/final-metadata-inventory-audit-nov01/updated-owner-plan-r9.json`, SHA `ce030e3f64b73a1176a7076cd0095c19c4bb5965f5618ca9bae466a3290b82c1`. It maps249 current additions and5 genuine base deletions in the seed. Earlier R1–R8 audits covered owner cohorts, not the full branch diff. R9 was ACTUALLY previewed with unchanged helper on clean WIPd60139d:1842 source deltas/45 deletions/50groups/25hotspots/169crosswalk, exit0. This preview is not final acceptance and must be rerun after Root final signal.
* USE the reviewed R9 private seed `/workspace/v10-preparation/final-metadata-inventory-audit-nov01/source-inventory-seed-r9.json`, SHA `79caf684d3781a91d3477625fb6261b66930f82394ff73b3a52a38521ac747f8`. It extends preserved0bcd only with5 genuine base-deletion memberships/pins/provenance and consistent counts. Do NOT use restored Main schema1 or the old0bcd seed alone: the latter omitted5 deleted paths. The183 current missing paths are in the R9 plan, not seed sourcePaths. Absent-both0558–0561 snapshots remain retirements, never base deletions.
* Private phase seed: `/workspace/v10-preparation/migration-phases-0569-inactive-nov01/phase-matrix.json`, SHA `26b7304f1b9e02515e5cbe656b019af08c8f5f2cc612c306c8b0bcf2c9a7d4cb`,68 assignments0502–0569. Main's restored phase index has64 rows/ends0565. Neither the older67-row plan nor Main's current index is the final candidate. The68-row source pins remain interim and require final pin refresh, not a check bypass.
* Alias inventory has131 pins and no automatic refresh flag. Refresh ONLY existing pin hashes, then let the existing scanner reject changed consumer/owner/alias/lifecycle sets; never invent a retirement/classification.
* Help7-file drafts are at `runtime-unavailable-help-nov01/manifest.json` (4files) and `runtime-unavailable-workflow-help-nov01/manifest.json` (3files). `docs/api/workflows.md` is documentation, not executable API code. Pair-review decisions/rationales require actual final source/article review; hashing alone is not that review.
* R4 refresh helper: `/workspace/v10-preparation/r4-final-refresh-procedure-nov01/refresh-r4-final.py`, SHA `1309421c075390070767dc4b75a427ae9716d7f88f0c1c31498f67bd5d8571eb`. Filled immutable historical baseline map is `historical-r4-baseline-pins.json` in THIS directory, SHA `6822c3612e91416929179836025934a9946fc1e6ac629fe68204f99b31f48167`. It matches the existing R4 integrity record; it is not a new current-source snapshot.

No historical169 statuses, full crosswalk, prior migration assignments/reasons, predecessor receipts or actualQualification fields may be rewritten. R8 candidate hashes are historical component references; the inventory helper intentionally derives base/HEAD membership from Git rather than pretending those older component hashes are final code pins.

## 1. Consume FINAL_SOURCE_HEAD from Root

After Native acceptance/source fixes and Root's explicit final signal, consume the resulting clean exact source HEAD. The source publisher already preserved/restored only the five deferred metadata paths. Do not stage/reset/stash other work, and do not reuse the earlier backup's05b25e2 HEAD as a current-parent assumption.

```sh
V10_REPO=/workspace/blentera-v10
V10_PREP=/workspace/v10-preparation
V10_METADATA_RUN="$V10_PREP/final-metadata-execution-<unique-id>"
FINAL_SOURCE_HEAD='<Root-declared-full-final-source-HEAD>'
mkdir "$V10_METADATA_RUN"
cd "$V10_REPO"
test "$(git rev-parse HEAD)" = "$FINAL_SOURCE_HEAD"
test -z "$(git status --porcelain=v1 --untracked-files=no)"
python3 "$V10_PREP/final-metadata-inventory-audit-nov01/edit-frozen-source-inventory-r2.py" \
 --frozen-root "$V10_REPO" --expected-head "$FINAL_SOURCE_HEAD" \
 --source-manifest "$V10_PREP/final-metadata-inventory-audit-nov01/source-inventory-seed-r9.json" \
 --expected-manifest-sha256 79caf684d3781a91d3477625fb6261b66930f82394ff73b3a52a38521ac747f8 \
 --owner-plan "$V10_PREP/final-metadata-inventory-audit-nov01/updated-owner-plan-r9.json" \
 --expected-owner-plan-sha256 ce030e3f64b73a1176a7076cd0095c19c4bb5965f5618ca9bae466a3290b82c1 \
 --output "$V10_METADATA_RUN/safe-change-graph.source.json"
```

The helper must see every named source tracked at FINAL_SOURCE_HEAD and refuses new unmapped paths. Only unrelated untracked evidence is allowed. If final fixes add paths, review a successor plan before this invocation; no guard is to be waived.

## 2. Prepare and commit METADATA_HEAD under the canonical lock

All writes below remain FUTURE actions after Root's signal. Hold `/workspace/v10-preparation/v10-pg-tests.lock` for metadata edits/checks, and recheck HEAD. Use the existing reviewed per-file manifests to verify parent/candidate bytes before copying ONLY their7 document paths. Review/update `docs/help/change-review.json` against the actual final source/article pairs, preserving locale coverage/maturity and real decisions/rationales. Then run:

```sh
node server/scripts/generate-company-search-help.mjs
node scripts/refresh-aw-v10-operation-coverage.mjs
# Persist only if the existing dry run reports reviewed coordinate/signature changes.
node scripts/refresh-aw-v10-operation-coverage.mjs --write
```

Create the alias candidate without changing alias semantics:

```sh
python3 - "$V10_REPO" "$V10_METADATA_RUN/aliases.json" <<'PY_ALIAS'
import json,sys,hashlib
from pathlib import Path
root=Path(sys.argv[1]); x=json.loads((root/'doc/operations/agent-native-tool-alias-compatibility.json').read_text())
for pin in x['sourcePins']: pin['sha256']=hashlib.sha256((root/pin['path']).read_bytes()).hexdigest()
with Path(sys.argv[2]).open('x') as f: json.dump(x,f,indent=2);f.write('\n')
PY_ALIAS
AGENT_NATIVE_TOOL_ALIAS_INVENTORY="$V10_METADATA_RUN/aliases.json" node scripts/check-agent-native-tool-alias-compatibility.mjs
```

If scanner sets/manifest mappings changed, stop for exact owner review; do not auto-edit them. Copy only the passing reviewed alias candidate to its canonical JSON path.

For phase68, use the existing private candidate, not the restored64-row index. Finalize its reviewed README/stage-list first. Refresh sourcePins from exact final code plus the reviewed metadata bytes; the phase README/stage-list are the two mutable self-references, while historical qualification receipts retain original hashes. Preserve all68 assignment/rationale entries and all phase statuses/gates. Resolve publication/source checkpoint fields to FINAL_SOURCE_HEAD, not the future metadata commit's own SHA. Write a NEW private `phase-matrix.final.json`; its185 interim pins must not simply be relabeled as fresh. Then:

```sh
node scripts/check-v10-169-migration-phase-register.mjs --root="$V10_REPO" --register="$V10_METADATA_RUN/phase-matrix.final.json"
```

Install ONLY the reviewed68-row matrix/README/stage-list/checksums at the existing canonical phase evidence path. Apply the private repaired Safe Change source manifest. Generate its graph LAST, after every named source/input/operational JSON and generated Help-search byte has settled:

```sh
cp -- "$V10_METADATA_RUN/safe-change-graph.source.json" doc/operations/v10-safe-change-graph.source.json
node scripts/generate-v10-safe-change-graph.mjs
node scripts/generate-v10-safe-change-graph.mjs --check
node scripts/check-v10-safe-change-graph.mjs
pnpm run check:help-docs
pnpm run test:help-docs
pnpm run check:aw-v10-operation-coverage
pnpm run test:aw-v10-operation-coverage
node scripts/check-agent-native-tool-alias-compatibility.mjs
pnpm run test:agent-native-tool-alias-compatibility
node scripts/check-v10-169-migration-phase-register.mjs
node --test scripts/check-v10-169-migration-phase-register.test.mjs
```

Stage/commit ONLY the explicit reviewed metadata/docs/generated-search cohort. Record `METADATA_HEAD`; do not `git add -A` or stage a source fix inadvertently. From that committed HEAD run:

```sh
METADATA_HEAD=$(git rev-parse HEAD)
node scripts/check-help-change-review.mjs --base '<reviewed-full-Help-base>' --head "$METADATA_HEAD" --evidence-out "$V10_METADATA_RUN/help-pairs.json"
node server/scripts/generate-company-search-help.mjs --check
node scripts/check-v10-safe-change-graph.mjs
node scripts/check-v10-169-migration-phase-register.mjs
```

The Help checker hashes at the checked-out committed snapshot; running it before the metadata commit would check the old articles/search context. On correction, amend/recommit ONLY the metadata cohort and repeat affected checks. Historical169/status/crosswalk invariants remain mandatory.

## Aggregate snapshot correction and actual invocation

The old snapshot helper copies phase-matrix.json but omits its nested pinned phase README/stage-list/receipts. This can create false stale/missing-input failures in MIRROR after metadata publication. The minimal private candidate in THIS directory adds only exact phase sourcePins/group owner/test/phase evidence/case and SafeChange sourceInputs paths through the existing contract_paths lane. It preserves dependency/binary/source-head/byte guards and fails on invalid/missing names. Syntax only; no copy/test ran.

Do NOT install during a source/WIP snapshot or while any reader expects originaldf80. Main's restored64-row phase register names a retired missing test, so the strict candidate correctly fails before phase refresh. Install ONLY AFTER canonical phase68 matrix plus its reviewed README/stage-list and all named inputs are in place (Root checked private68 has187 named refs/0missing), under the canonical lock with no active helper reader, BEFORE the final aggregate. Use CAS: original canonical helper SHA must still be `df80e1647511fef43169a05eac7447309bc41223aadbbd9647e8ab246dec0003`, candidate SHA `5f138341524f9fb029d5614b9f1a935c854acbebea5c555d5c05db6bec2ea5da`; preserve the original `.before.py` already supplied. `snapshot-delta-pins.json` pins both and the UNCHANGED aggregate runner. Do not overwrite a drifted helper.

The aggregate owns the canonical lock itself. Do not wrap it in another flock on that lock. Run only after METADATA_HEAD (or a genuinely claims-only clean successor), never at the source/WIP checkpoint:

```sh
V10_SOURCE_FREEZE=1 /workspace/v10-preparation/run-final-workspace-aggregate-20261101.sh "$METADATA_HEAD"
```

It snapshots Main→MIRROR, verifies exact copied bytes/head, runs builds/typechecks/Host/root tests/Rust/SDK mechanics, and retains failed output. Existing server typecheck already uses `--singleThreaded`; the aggregate's Cargo jobs2 is bounded and unchanged. The existing OpenCode paths currently exist and are the configured1.18.32 pin; no binary pin replacement is proposed. Cargo's missing legacy alias can be created by the existing guard; never replace a different existing target. Keep disk/dependency/prover/binary floors and exact source-status guards. Do not turn actual acceptance failures into metadata exemptions.

## 3. Refresh R4 from clean METADATA_HEAD, then claims-only commit

Only after the metadata commit/checks and actual owner receipts are available, fill the existing final-owner-receipt-map template with that exact METADATA_HEAD, reviewed explicit sourcePaths and actual pinned Native9/Host/guard receipts. Unavailable/failing dimensions stay pending/failed; no automatic pass or activation. Native9 pass requires the real complete9/0/0 exit0 owner declaration. Then:

```sh
FINAL_OWNER_MAP='<reviewed-final-owner-receipt-map.json>'
FINAL_OWNER_MAP_SHA='<reviewed-exact-map-SHA256>'
python3 "$V10_PREP/r4-final-refresh-procedure-nov01/refresh-r4-final.py" \
 --frozen-root "$V10_REPO" --expected-head "$METADATA_HEAD" \
 --baseline-r4 "$V10_PREP/v10-final-claim-reconciliation-candidate-r4-20261030" \
 --historical-amendment "$V10_PREP/v10-nov01-claim-amendment/claim-amendment.json" \
 --baseline-pins "$V10_PREP/metadata-execution-readiness-r147-nov01/historical-r4-baseline-pins.json" \
 --expected-baseline-pins-sha256 6822c3612e91416929179836025934a9946fc1e6ac629fe68204f99b31f48167 \
 --owner-receipt-map "$FINAL_OWNER_MAP" --expected-owner-map-sha256 "$FINAL_OWNER_MAP_SHA" \
 --output "$V10_METADATA_RUN/r4-overlay"
```

Publish only the compact overlay plus the exact existing baseline archive once under a nested claims evidence cohort, with the existing README's relative archive/extraction mapping. Absolute workspace paths remain provenance, not the only reader resolution. Commit CLAIMS_HEAD without rewriting source identity to its own SHA. If no named graph source/input changed, the graph remains identical; otherwise regenerate/check normally. All169 historical statuses, predecessor receipts and actualQualification fields remain unchanged. Overall production/provider/pricing/physical/hosted/Human/release acceptance is not supplied by this metadata procedure.

R9 correction: the actual full-diff helper preview replaced earlier cohort-only coverage assumptions. This readiness document now names R9/79caf inputs; older R4 invocation artifacts remain historical/currently unactivated until Root final signal. Original helper9f061 is unchanged.
