import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { test } from "node:test";
import path from "node:path";
import { parseSelectedTestResults, selectedAssertionsPassed, validateContract, validateSuites } from "./run-platform-skill-runtime-conformance.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

test("runtime conformance contract maps every common case and keeps external runtime profiles unqualified", async () => {
  const contract = JSON.parse(await readFile(path.join(root, "evals/platform-skill/runtime-conformance.json"), "utf8"));
  validateContract(contract);
  const ids = contract.scenarios.map(({ id }) => id);
  assert.deepEqual(ids, ["pinned-positive-delivery", "missing-or-stale-pin", "reserved-name-collision", "isolated-profile-boundary", "safe-recovery-boundary"]);
  for (const profile of contract.profiles) {
    assert.match(profile.qualification, /unqualified|not-GA/i);
    assert.equal(profile.exactInstalledVersion, null);
  }
  const runnable = contract.profiles.filter(({ suites }) => suites.length > 0);
  assert.equal(runnable.length, 3);
  assert.ok(runnable.every(({ commonSuiteComplete }) => commonSuiteComplete), "every source-implemented runtime must map all common scenarios");
  const pins = await validateSuites(contract);
  assert.ok(Object.keys(pins).length >= runnable.length);
});

test("source-only contract rejects external qualification, GA, and installed-version claims", async () => {
  const load = async () => JSON.parse(await readFile(path.join(root, "evals/platform-skill/runtime-conformance.json"), "utf8"));
  let contract = await load();
  contract.profiles[0].qualification = "externally-qualified";
  assert.throws(() => validateContract(contract), /cannot claim external qualification or GA status/);

  contract = await load();
  contract.profiles[0].qualification = "ga";
  assert.throws(() => validateContract(contract), /cannot claim external qualification or GA status/);

  contract = await load();
  contract.profiles[0].exactInstalledVersion = "1.2.3";
  assert.throws(() => validateContract(contract), /cannot claim an installed runtime version/);
});

test("A2A/custom profile cannot advertise a source test driver that does not exist", async () => {
  const contract = JSON.parse(await readFile(path.join(root, "evals/platform-skill/runtime-conformance.json"), "utf8"));
  const profile = contract.profiles.find(({ id }) => id === "a2a-or-custom");
  profile.suites = [{ path: "missing.test.ts", config: "vitest.config.ts", selection: "case", scenarios: [] }];
  assert.throws(() => validateContract(contract), /cannot claim suites without a delivery driver/);
});

test("selected scenario titles must each have one passed machine-readable assertion", () => {
  const suite = { path: "server/a.test.ts", selection: "required A|required B|required C" };
  const report = (statuses) => ({ testResults: [{
    name: "/repo/server/a.test.ts",
    assertionResults: statuses.map(([title, status]) => ({ title, fullName: title, status })),
  }] });
  const allPassed = parseSelectedTestResults(report([["required A", "passed"], ["required B", "passed"], ["required C", "passed"]]), suite, "/repo");
  assert.equal(allPassed.parsed, true);
  assert.ok(allPassed.requiredTitles.every(({ passed }) => passed));
  assert.equal(selectedAssertionsPassed(allPassed), true);

  const oneSkipped = parseSelectedTestResults(report([["required A", "passed"], ["required B", "skipped"], ["required C", "passed"]]), suite, "/repo");
  assert.ok(oneSkipped.requiredTitles.some(({ title, status, passed }) => title === "required B" && status === "skipped" && !passed));
  assert.equal(oneSkipped.requiredTitles.every(({ passed }) => passed), false);
  assert.equal(selectedAssertionsPassed(oneSkipped), false);

  const oneMissing = parseSelectedTestResults(report([["required A", "passed"], ["required C", "passed"]]), suite, "/repo");
  assert.ok(oneMissing.requiredTitles.some(({ title, matches, passed }) => title === "required B" && matches === 0 && !passed));
  assert.equal(oneMissing.requiredTitles.every(({ passed }) => passed), false);
  assert.equal(selectedAssertionsPassed(oneMissing), false);
});

