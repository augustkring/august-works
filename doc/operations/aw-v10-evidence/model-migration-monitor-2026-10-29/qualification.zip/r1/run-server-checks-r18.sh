#!/usr/bin/env bash
set -euo pipefail
exec flock -x /workspace/v10-preparation/v10-pg-tests.lock bash -s <<'LOCKED'
set -u
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH
ROOT=/workspace/blentera-v10
MIRROR=/workspace/v10-dep-qualification
OUT=/workspace/v10-preparation/model-migration-monitor-qualified-r18-20261029
mkdir "$OUT"
python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$OUT/source-pins.json" > "$OUT/snapshot.log" 2>&1
rc=$?; printf '%s\n' "$rc" > "$OUT/snapshot.exit"; if ((rc)); then exit "$rc"; fi
node /workspace/v10-preparation/check-snapshot-syntax.cjs "$OUT/source-pins.json" > "$OUT/syntax.log" 2>&1
rc=$?; printf '%s\n' "$rc" > "$OUT/syntax.exit"; if ((rc)); then exit "$rc"; fi
cd "$MIRROR"
run_step() {
  local name="$1"; shift
  set +e
  "$@" > "$OUT/$name.log" 2>&1
  local rc=$?
  set -e
  printf '%s\n' "$rc" > "$OUT/$name.exit"
  if ((rc)); then return "$rc"; fi
}
run_step migration-check timeout 90s pnpm --filter @paperclipai/db check:migrations || exit $?
cd "$MIRROR/server"
run_step pg-monitor timeout 300s ../node_modules/.bin/vitest run src/__tests__/v9-agent-publication.integration.test.ts -t 'tests a saved alternative, promotes its model migration' --maxWorkers=1 --reporter=verbose || exit $?
run_step openapi-human timeout 120s ../node_modules/.bin/vitest run src/__tests__/openapi-routes.test.ts -t 'documents AgentAuthoring model migration monitoring as Human-session-only' --maxWorkers=1 --reporter=verbose || exit $?
cd "$MIRROR"
run_step shared-contract timeout 120s node_modules/.bin/vitest run packages/shared/src/agent-model-migration-monitoring.test.ts --maxWorkers=1 --reporter=verbose || exit $?
cd "$MIRROR/ui"
run_step ui-monitor timeout 120s ../node_modules/.bin/vitest run src/components/AgentModelMigrationMonitor.test.tsx --maxWorkers=1 --reporter=verbose || exit $?
cd "$MIRROR"
run_step token-gates timeout 90s node scripts/check-token-gates.mjs || exit $?
sha256sum "$OUT"/*.log "$OUT"/*.exit "$OUT/source-pins.json" > "$OUT/SHA256SUMS"
LOCKED
