# V10-169 current migration phase index — 2026-10-30

This dated register supplements, and does not overwrite, the historical 169-row reconciliation at `doc/operations/aw-v10-evidence/recovery-2026-10-22/requirement-reconciliation.json`. That original V10-169 row remains `historical_partial_evidence_open`. The new JSON indexes every affected migration SQL file added since source-base commit `81d3445b98b1cd80ff400ede6bd44ea71d88d735` (0502–0566, 65 journal-delta/current-diff files at capture), cross-checks each with the current migration journal and one owner/phase group, records durable writers/state/compatibility/recovery expectations, pins source inputs, and links concrete tests.

This is a phase index, not whole-program, migration-fleet or release qualification. Source pins are interim through published 0566 at `bacec1d0d`; refresh all pins after Native source freeze. It does not claim hosted rollout, arbitrary backup restore, provider behavior, old/new binary fleet compatibility, operator execution, representative customer results or Human acceptance. Current software must refuse or quarantine old/unknown provenance when it cannot prove required ownership. Operators must keep admission closed or drain old writers where they cannot preserve current bindings. Do not run down migrations or rewrite migration history. Where old code cannot safely use current durable state, pause/isolate and roll forward or restore under the recovery owner.

The source-base diff includes 0502 board-key security-event audit fields/constraints; 0503 issue/project access grants, privacy lineage and private visibility; and 0504 bounded Memory/Project source provenance. Those are assigned to their authentication, privacy-lineage and Native provenance groups. The latest journal entry is 0566 (`0566_customer_feedback_experience_measures`), with exact source and software evidence at `doc/operations/aw-v10-evidence/feedback-quality-qualified-2026-10-30/` and portable bundle SHA-256 `4ad594982fdc5b9e46e47f14524ee6e14f19f9118adcec335cae6bbed02fad63`.

0566 adds an optional, explicitly consented satisfaction/effort sidecar to existing Product Feedback. The original Feedback row remains immutable; withdrawal deletes rating bytes and appends a content-free marker in one transaction. Database guards reject sidecar updates and reinsert after withdrawal. Existing Feedback retention, account deletion and company purge owners remove rating bytes, including when a parent Feedback complaint remains retained. Generated 0566 migration/schema/trigger qualification passed, PostgreSQL 44/44, server typecheck, shared contracts 7/7 plus metadata wording 2/2, UI 37/37 and UI typecheck. No backfill or inferred ratings are introduced. These are exact software receipts only; arbitrary backup restore, production/operator rollout and representative/Human satisfaction evidence remain open.

The seven phase labels remain qualification-limited. Concrete selected evidence includes:

- **Add/expand:** current Native payload snapshot binding and trust-grant cases; 0566 optional rating sidecar plus immutable consent/withdrawal guards.
- **Backfill/reconcile:** selected legacy Memory/import cases; 0566 intentionally performs no rating backfill.
- **Cutover/drain and rollback/roll-forward:** operational guidance exists; the deployed writer fleet, rollout window and compatible rollback are operator gates.
- **Restart/retry:** selected import/native recovery cases; 0566 withdrawal retry uses the same request key and rejects changed-key reuse.
- **Restore:** selected local restore and parent-erasure cases; 0566 account/retention erasure deletes rating sidecar bytes. This does not qualify arbitrary backup restore.
- **Unknown provenance:** legacy payload and current Context cases remain unknown; 0566 does not infer rating values or consent for old Feedback.

The source check discovers affected SQL by unioning the source-base git diff with current journal entries added after the base; it does not use a fixed lower bound. This includes 0502–0504 and published 0566. Negative tests reject missing migration owners, missing SQL-owner paths, stale source pins, missing/duplicated phase labels and unsupported `qualified` promotion. Package scripts and the V10 coverage workflow run the check and tests.

Run the lightweight consistency guard with:

```sh
node scripts/check-v10-169-migration-phase-register.mjs
```

It validates the source-base/journal migration inventory, current owners/tests and hashes, exact seven phase names and qualification limits. It does not execute the linked database suites; use each source-pinned qualification bundle for its recorded result.
