# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: aw-v9-runtime-candidates.spec.ts >> saved runtime selection survives reload and an unknown qualification uses only its Original receipt
- Location: tests/e2e/aw-v9-runtime-candidates.spec.ts:13:1

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: apiRequestContext.delete: Target page, context or browser has been closed
```

# Page snapshot

```yaml
- generic [ref=f1e4]:
  - link "Skip to Main Content" [ref=f1e5] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=f1e6]:
    - generic [ref=f1e7]:
      - generic [ref=f1e8]:
        - complementary [ref=f1e10]:
          - button "Open Disposable runtime proposal browser fixture organization switcher" [ref=f1e12]:
            - generic [ref=f1e13]:
              - generic [ref=f1e14]: D
              - generic "Disposable runtime proposal browser fixture" [ref=f1e17]
          - navigation [ref=f1e18]:
            - generic [ref=f1e19]:
              - link "Hjem" [ref=f1e20] [cursor=pointer]:
                - /url: /DISAAAAAAAAAA/dashboard
              - link "Kræver dig" [ref=f1e26] [cursor=pointer]:
                - /url: /DISAAAAAAAAAA/needs-you
              - link "Arbejde" [ref=f1e32] [cursor=pointer]:
                - /url: /DISAAAAAAAAAA/work
              - link "Agenter" [ref=f1e38] [cursor=pointer]:
                - /url: /DISAAAAAAAAAA/agents
              - link "Apps" [ref=f1e46] [cursor=pointer]:
                - /url: /DISAAAAAAAAAA/apps
              - status [ref=f1e56]: Yderligere navigation kunne ikke hentes. Prøv Hjem igen.
              - generic [ref=f1e57]:
                - button "Spørg Blentera" [ref=f1e58]
                - link "Hjælp / Support" [ref=f1e59] [cursor=pointer]:
                  - /url: /DISAAAAAAAAAA/company/help
        - button "Open account menu" [ref=f1e67]:
          - generic [ref=f1e68]: BR
          - generic [ref=f1e70]: Browser product reviewer
      - separator "Resize sidebar" [ref=f1e71]
    - generic [ref=f1e73]:
      - region "Globale funktioner" [ref=f1e75]:
        - button "Spørg Blentera" [ref=f1e76]
        - generic [ref=f1e79]:
          - generic [ref=f1e80]: Sprog
          - combobox "Sprog" [ref=f1e81]:
            - option "English"
            - option "Dansk" [selected]
        - link "Hjælp / Support" [ref=f1e82] [cursor=pointer]:
          - /url: /DISAAAAAAAAAA/company/help
        - link "Kontakt support" [ref=f1e83] [cursor=pointer]:
          - /url: mailto:support@blentera.com
        - link "Brugerkonto" [ref=f1e84] [cursor=pointer]:
          - /url: /DISAAAAAAAAAA/company/settings/instance/profile
      - main [ref=f1e92]:
        - generic [ref=f1e93]:
          - link "Dine udkast" [ref=f1e94] [cursor=pointer]:
            - /url: /DISAAAAAAAAAA/agents/custom
          - paragraph [ref=f1e95]: Tilpasset agent · Udkast v1 · 9 af 13
          - heading "Kørselsmiljø" [active] [level=1] [ref=f1e96]
          - paragraph [ref=f1e97]: Ændringer bliver i udkastet, indtil en bestemt version er gennemgået og udgivet.
          - link "Gennemgå den aktuelle agent" [ref=f1e98] [cursor=pointer]:
            - /url: /DISAAAAAAAAAA/agents/10000000-0000-4000-8000-000000000002
          - navigation "Trin i agentredigeringen" [ref=f1e99]:
            - button "Ansvar og ejer" [ref=f1e100]
            - button "Identitet" [ref=f1e101]
            - button "Instruktioner" [ref=f1e102]
            - button "Viden" [ref=f1e103]
            - button "Værktøjer og apps" [ref=f1e104]
            - button "Beføjelser" [ref=f1e105]
            - button "Hukommelse" [ref=f1e106]
            - button "Samarbejde" [ref=f1e107]
            - button "Kørselsmiljø" [ref=f1e108]
            - button "Test" [ref=f1e109]
            - button "Gennemgå ændringer" [ref=f1e110]
            - button "Udgiv" [ref=f1e111]
            - button "Følg op og forbedr" [ref=f1e112]
          - group [ref=f1e113]:
            - region "Opsætning til udførelse" [ref=f1e114]:
              - heading "Opsætning til udførelse" [level=2] [ref=f1e115]
              - status [ref=f1e116]: Denne agents egen runtime er ikke aktuelt kvalificeret. Konfigurer og valider den før Safe Test.
              - paragraph [ref=f1e117]: Validering af runtime og en repræsentativ Safe Test er separate. Denne visning starter intet arbejde og giver ingen rettigheder.
              - button "Kontrollér opsætningen igen" [ref=f1e118]
              - paragraph [ref=f1e119]: Denne kladde ændrer ikke agentens opsætning. Ændringer af en aktiv agent kræver en gemt kandidat, ny validering og Safe Test før særskilt publicering.
            - group [ref=f1e120]:
              - generic "Avancerede runtimealternativer" [ref=f1e121] [cursor=pointer]
            - paragraph [ref=f1e122]: En aktuel tilknytning kvalificerer ikke udkastets ændrede adfærd. Ændringer af kørselsmiljøet kræver ny evaluering.
            - generic [ref=f1e123]:
              - text: Valg af kørselsmiljø
              - combobox "Valg af kørselsmiljø" [ref=f1e124]:
                - option "Vælg et kvalificeret kørselsmiljø før test" [selected]
            - paragraph [ref=f1e125]: Ingen tilknytning til kørselsmiljø er tilgængelig for dette udkast.
          - generic [ref=f1e126]:
            - generic [ref=f1e127]:
              - button "Gem og afslut" [ref=f1e128]
              - button "Tilbage" [ref=f1e129]
              - button "Kassér udkast" [ref=f1e130]
            - button "Fortsæt" [ref=f1e131]
  - generic [ref=f1e132]:
    - heading "Command Palette" [level=2] [ref=f1e133]
    - paragraph [ref=f1e134]: Search for a command to run...
```

# Test source

```ts
  3   | import { V5_FEATURE_KEYS, agentAuthoringContentSchema, agentAuthoringDraftViewSchema } from "../../packages/shared/src/index.ts";
  4   | const axePath = createRequire(import.meta.url).resolve("axe-core/axe.min.js");
  5   | const id = (n: number) => `10000000-0000-4000-8000-${String(n).padStart(12, "0")}`;
  6   | async function json(response: APIResponse) {
  7   |   expect(response.ok(), `${response.status()}: ${await response.text()}`).toBe(true); return response.json();
  8   | }
  9   | 
  10  | // Built software journey with scoped intercepted responses. The actual Native
  11  | // probes, liability ledger and atomic promotion run in PostgreSQL integration
  12  | // tests; this fixture does not qualify a hosted provider or user pilot.
  13  | test("saved runtime selection survives reload and an unknown qualification uses only its Original receipt", async ({ page, request }) => {
  14  |   const company = await json(await request.post("/api/companies", { data: { name: "Disposable runtime proposal browser fixture" } }));
  15  |   try {
  16  |     const session = await json(await request.get("/api/auth/get-session"));
  17  |     const originalFlags = await json(await request.get("/api/instance/settings/experimental"));
  18  |     const flags = { ...originalFlags, ...Object.fromEntries(V5_FEATURE_KEYS.map(key => [key, true])), enableFoundationV1: true,
  19  |       enableContextEngineV1: true, saas_deployment_profile_v6: true, billing_v6: true, agent_packages_v7: true, hire_agent_v9: true,
  20  |       experience_projection_v9: true, progressive_shell_v9: true };
  21  |     let draft = agentAuthoringDraftViewSchema.parse({ id: id(1), companyId: company.id, agentId: id(2), createdByUserId: session.user.id,
  22  |       kind: "custom", version: 1, status: "draft", step: "runtime", baselineHash: "a".repeat(64),
  23  |       content: agentAuthoringContentSchema.parse({ name: "Runtime specialist", ownerUserId: session.user.id }),
  24  |       createdAt: "2026-10-13T00:00:00Z", updatedAt: "2026-10-13T00:00:00Z" });
  25  |     const candidate = { id: id(3), companyId: company.id, draftId: draft.id, agentId: id(2), modelProfileId: id(4),
  26  |       configurationHash: "a".repeat(64), recordedStatus: "draft", qualificationRequestId: null, qualificationCurrent: false,
  27  |       changesLive: false, createdAt: "2026-10-13T00:00:00Z" };
  28  |     let creations = 0, qualifications = 0, receipts = 0, originalRequest = "";
  29  |     await page.route("**/api/auth/get-session", route => route.fulfill({ json: { ...session, session: { ...session.session, localImplicit: false } } }));
  30  |     await page.route("**/api/instance/settings/experimental", route => route.fulfill({ json: flags }));
  31  |     await page.route(`**/api/companies/${company.id}/agent-identities`, route => route.fulfill({ json: [{ id: id(5), agentId: id(6), name: "Isolation peer" }] }));
  32  |     await page.route(`**/api/companies/${company.id}/agent-configuration-drafts/**`, async route => {
  33  |       const url = new URL(route.request().url()), path = url.pathname;
  34  |       expect(url.searchParams.get("expectedUserId")).toBe(session.user.id);
  35  |       if (path.endsWith("/runtime-candidates") && route.request().method() === "POST") {
  36  |         creations++; expect(route.request().postDataJSON()).toMatchObject({ modelProfileId: id(4), expectedVersion: 1 });
  37  |         return route.fulfill({ json: candidate });
  38  |       }
  39  |       if (path.endsWith("/runtime-candidates")) return route.fulfill({ json: { companyId: company.id, draftId: draft.id, version: draft.version,
  40  |         agentId: id(2), identityId: id(5), choices: [{ modelProfileId: id(4), model: "Software fixture model", configurationHash: "a".repeat(64),
  41  |           maxOutputTokens: 256, maximumMinorPerCall: 3, currency: "USD", requiresConformance: true, changesLive: false }] } });
  42  |       if (path.endsWith("/conformance-review")) return route.fulfill({ json: { companyId: company.id, draftId: draft.id, candidateId: id(3), version: draft.version,
  43  |         reviewHash: "b".repeat(64), canTest: true, blockers: [], maximumMinor: 12, currency: "USD", probeCount: 4, toolsGranted: false,
  44  |         changesLiveConfiguration: false, providerComputeStopConfirmed: false } });
  45  |       if (path.endsWith("/conformance")) {
  46  |         qualifications++; const body = route.request().postDataJSON(); originalRequest = body.requestId;
  47  |         expect(body).toMatchObject({ expectedVersion: 2, expectedReviewHash: "b".repeat(64), confirmBoundedConformance: true,
  48  |           confirmCompanyVisibleProbes: true, isolationPeer: { companyId: company.id, agentId: id(6) } });
  49  |         return route.fulfill({ status: 503, json: { error: "PRIVATE lost qualification response" } });
  50  |       }
  51  |       if (path.includes("/conformance/requests/")) {
  52  |         receipts++; expect(path.endsWith(originalRequest)).toBe(true); expect(route.request().method()).toBe("GET");
  53  |         return route.fulfill({ json: { companyId: company.id, draftId: draft.id, candidateId: id(3), requestId: originalRequest, status: "qualified",
  54  |           createdAt: "2026-10-13T00:00:00Z", finishedAt: "2026-10-13T00:01:00Z", runIds: [id(7), id(8), id(9), id(10)],
  55  |           reservationIds: [id(11), id(12), id(13), id(14)], reservedMinor: 12, unknownCharges: 1,
  56  |           changesLiveConfiguration: false, providerComputeStopConfirmed: false } });
  57  |       }
  58  |       if (path.endsWith("/options")) return route.fulfill({ json: { owners: [{ id: session.user.id, name: "Current author" }], knowledge: [], runtimes: [] } });
  59  |       if (path.endsWith("/preparation-review")) return route.fulfill({ status: 409, json: { error: "Existing software Agent" } });
  60  |       if (path.endsWith("/runtime")) return route.fulfill({ json: { draftId: draft.id, companyId: company.id, version: draft.version,
  61  |         agentId: id(2), runtimeBindingId: null, configurationHash: "a".repeat(64), status: "needs_setup", runtimeQualified: false,
  62  |         safeTestQualified: false, executionStarted: false } });
  63  |       if (path.endsWith("/tests")) return route.fulfill({ json: [] });
  64  |       if (path.endsWith(`/${draft.id}/save`)) {
  65  |         const body = route.request().postDataJSON(); expect(body.content.runtimeCandidateId).toBe(id(3));
  66  |         draft = { ...draft, content: body.content, version: 2, step: body.step }; return route.fulfill({ json: draft });
  67  |       }
  68  |       if (path.endsWith(`/${draft.id}`)) return route.fulfill({ json: draft });
  69  |       return route.fulfill({ status: 409, json: { error: "No other fixture operation is qualified" } });
  70  |     });
  71  |     await page.goto(`/${company.issuePrefix}/dashboard`);
  72  |     await expect(page.getByRole("main")).toBeVisible();
  73  |     await page.goto(`/${company.issuePrefix}/agents/custom/${draft.id}/runtime`);
  74  |     const advanced = page.locator("summary", { hasText: "Advanced runtime alternatives" });
  75  |     await advanced.click();
  76  |     await expect(page.getByRole("combobox", { name: "Installed model profile", exact: true }).locator("option", { hasText: "Software fixture model" })).toHaveCount(1);
  77  |     await page.getByRole("combobox", { name: "Installed model profile", exact: true }).selectOption(id(4));
  78  |     await expect(page.getByRole("combobox", { name: "Installed model profile", exact: true })).toHaveValue(id(4));
  79  |     await page.getByRole("button", { name: "Save runtime proposal", exact: true }).click();
  80  |     await expect(page.getByRole("main")).toContainText("Save your agent draft to retain this candidate selection");
  81  |     await page.getByRole("button", { name: "Save & exit", exact: true }).click();
  82  |     await expect.poll(() => draft.content?.runtimeCandidateId).toBe(id(3));
  83  |     await page.goto(`/${company.issuePrefix}/agents/custom/${draft.id}/runtime`);
  84  |     await advanced.click();
  85  |     await page.getByRole("combobox", { name: "Company with the approved isolation test agent", exact: true }).selectOption(company.id);
  86  |     await expect(page.getByRole("main")).toContainText("Maximum liability for four probes: USD 0.12");
  87  |     await page.getByLabel("I authorize four bounded model probes and their reviewed possible charges.", { exact: true }).check();
  88  |     await page.getByLabel("I understand that the synthetic probes and receipts are visible in the company.", { exact: true }).check();
  89  |     await page.getByRole("button", { name: "Run four qualification probes", exact: true }).click();
  90  |     await expect(page.getByRole("alert")).toBeFocused();
  91  |     await expect(page.getByRole("main")).not.toContainText("PRIVATE");
  92  |     await page.getByRole("button", { name: "Check original qualification receipt", exact: true }).click();
  93  |     await expect(page.getByRole("main")).toContainText("Complete representative tests and review publication");
  94  |     expect(creations).toBe(1); expect(qualifications).toBe(1); expect(receipts).toBe(1);
  95  |     await page.setViewportSize({ width: 390, height: 844 });
  96  |     await page.getByRole("combobox", { name: "Language", exact: true }).selectOption("da");
  97  |     await expect(page.locator("html")).toHaveAttribute("lang", "da");
  98  |     await page.addScriptTag({ path: axePath });
  99  |     expect(await page.evaluate(async () => (await (window as unknown as { axe: { run(scope: string): Promise<{ violations: unknown[] }> } }).axe.run("main")).violations)).toEqual([]);
  100 |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  101 |     expect(qualifications).toBe(1);
  102 |     expect(await json(await request.get(`/api/companies/${company.id}/agents`))).toEqual([]);
> 103 |   } finally { await json(await request.delete(`/api/companies/${company.id}`)); }
      |                                              ^ Error: apiRequestContext.delete: Target page, context or browser has been closed
  104 | });
  105 | 
```