# V10-094/097 Feedback quality private candidate

This directory preserves the owned delta before restoring MAIN imports during active qualification.

- `owned-deltas.patch` is the tracked-source patch captured before restoration.
- `customer_feedback_experience_measures.ts` is the proposed Feedback-owned, company-scoped child table source. Root approved a rating sidecar with cascade from the immutable Feedback root.
- The first PostgreSQL integration run proved that customer feedback submissions and feedback events are both immutable/append-only. The first withdrawal implementation failed at the native trigger, as expected; the candidate must store ratings in the child table and withdraw by deleting that row plus appending a content-free tombstone in the same transaction.
- Root approved appending a withdrawal tombstone with no rating values, source-owner authorization, and testing withdrawal/re-add/change/foreign owner/private links/parent erasure.
- Current ratings are available through the submitter-owned My Feedback detail read and the authorized Feedback internal detail; list receipts carry only response status. Withdrawal removes the sidecar values and the same detail returns `withdrawn` without values.
- Product Feedback and its optional rating values stay out of the company portability archive. The submitter's source-owned My Feedback detail/API is the portable representation for this scoped change; do not copy the separate Feedback source into company archives.
- The 0566 DB protection must reject all sidecar updates and reject re-insert after the append-only withdrawal marker exists. Generated table DDL plus the trigger will be qualified after the 0565 migration handoff; don't generate a hand-written journal.
- Human taxonomy assignment should use the existing triage event/version/idempotency path; avoid a new event type or independent event policy. Keep native `blocksWork` evidence separate from triaged impact.
- The exact 0566 Drizzle generation must wait for responsibility completion's qualified 0565 closure. Do not hand-write the migration journal or leave a runtime import in MAIN before the generated export exists.

No source in MAIN has been staged or committed for this candidate.
