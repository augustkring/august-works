#!/usr/bin/env bash
set -euo pipefail
REPO=/workspace/blentera-v10
MIRROR=/workspace/v10-dep-qualification
CAND=/workspace/v10-preparation/v10-149-r14.38.4.21-installed-profiles-canonical-fixture-private
OUT=$CAND/host-node-qualification
BAK=/tmp/blentera-r14.38.4.21-host-node-backup
mkdir -m 700 "$OUT"
exec 9>/workspace/v10-preparation/v10-pg-tests.lock
flock -x 9
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH
if [[ -e "$BAK" ]]; then echo "backup exists" > "$OUT/preflight.log"; exit 73; fi
python3 - "$CAND/source-pins.json" "$CAND/files" "$REPO" "$MIRROR" "$BAK" "$OUT" <<'PY'
from pathlib import Path
import hashlib,json,shutil,stat,sys
pins=json.loads(Path(sys.argv[1]).read_text())['sourceFiles']; cand=Path(sys.argv[2]); repo=Path(sys.argv[3]); mirror=Path(sys.argv[4]); backup=Path(sys.argv[5]); out=Path(sys.argv[6]); rows=[]
for row in pins:
 p=row['path']; want=row['candidateSha256']; parent=row['parentSha256']; mb=row.get('qualificationMirrorBaseSha256',parent)
 for label,root,digest in [('MAIN',repo,parent),('Mirror',mirror,mb),('candidate',cand,want)]:
  f=root/p; got=hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None
  if got!=digest: raise SystemExit(f'{label} mismatch {p}: {got} != {digest}')
 src=mirror/p; dst=backup/p
 rows.append({'path':p,'present':src.is_file(),'mode':stat.S_IMODE(src.stat().st_mode) if src.is_file() else None,
  'main':parent,'mirror':mb,'candidate':want})
 if src.is_file(): dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
 else: dst.parent.mkdir(parents=True,exist_ok=True)
(out/'overlay.json').write_text(json.dumps(rows,indent=2)+'\n')
PY
restore() {
 python3 - "$OUT/overlay.json" "$MIRROR" "$BAK" "$OUT/restore.log" <<'PY'
from pathlib import Path
import hashlib,json,shutil,stat,sys
rows=json.loads(Path(sys.argv[1]).read_text()); root=Path(sys.argv[2]); backup=Path(sys.argv[3]); errors=[]
for row in rows:
 p=row['path']; dst=root/p; saved=backup/p
 if row['present']:
  dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(saved,dst)
 else: dst.unlink(missing_ok=True)
 got=hashlib.sha256(dst.read_bytes()).hexdigest() if dst.is_file() else None
 expect=row['mirror']
 if got!=expect: errors.append(f'{p}: {got} != {expect}')
Path(sys.argv[4]).write_text('exact candidate source files restored to Mirror baseline\n' if not errors else '\n'.join(errors)+'\n')
if errors: raise SystemExit(1)
PY
 rm -rf "$BAK"
}
trap restore EXIT
python3 - "$CAND/source-pins.json" "$CAND/files" "$MIRROR" <<'PY'
from pathlib import Path
import hashlib,json,shutil,sys
pins=json.loads(Path(sys.argv[1]).read_text())['sourceFiles']; cand=Path(sys.argv[2]); mirror=Path(sys.argv[3])
for row in pins:
 p=row['path']; src=cand/p; dst=mirror/p; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
 if hashlib.sha256(dst.read_bytes()).hexdigest()!=row['candidateSha256']: raise SystemExit(f'overlay mismatch {p}')
PY
cd "$MIRROR"
set +e
node --test "$MIRROR/deploy/v6/host-agent/openshell.test.mjs" "$MIRROR/deploy/v6/host-agent/broker-profiles.test.mjs" > "$OUT/log" 2>&1
rc=$?
set -e
printf '%s\n' "$rc" > "$OUT/exit"
exit "$rc"
