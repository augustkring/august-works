# Private ACPX Claude paid-boundary candidate

Status: private component, not qualified or admission-enabled. MAIN unchanged.

The source patch adds strict complete server-owned model-broker environment propagation to the actual ACPX child sanitizer and tests that all reusable provider/OAuth/custom-header credentials are omitted. It uses the existing host-inspected `/runtime-tools/model/v1/messages` route and non-secret sentinel, with no new ledger or credential delivery API. Recovery state must not retain routing/authentication. Nine lightweight direct Node environment assertions passed without network or paid calls; Vitest runtime-sandbox cases remain unrun.

End-to-end activation remains blocked pending the actual ACPX Claude wire/source adapter. The pinned ACP implementation retains the Claude native preset system and built-in tools, while the current gateway requires the exact OpenCode-only system, schemas, settled assistant history and Native tool capture receipts. Native source ownership has no demonstrated authoritative Claude built-in filesystem/history result capture. This patch does not equate those sources or replace the checker.

Required remaining integration: distinct qualified Claude request/source authority derived from genuine canonical captures; profile/current-authority selection through existing gateway; capability mint and dispatch validation through runtime/control; exact runner handoff; reservation before actual provider send, duplicate/stale/revoked/unknown outcome regressions using the existing modelReservationService. Direct raw-credential paid paths are not claimed closed. No profile lifecycle flags enabled.
