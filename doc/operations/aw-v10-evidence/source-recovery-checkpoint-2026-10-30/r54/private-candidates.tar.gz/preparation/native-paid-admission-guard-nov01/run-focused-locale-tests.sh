#!/usr/bin/env bash
set -euo pipefail
REPO=/workspace/blentera-v10
PREP=/workspace/v10-preparation/native-paid-admission-guard-nov01
LOCK=/workspace/v10-preparation/v10-pg-tests.lock
EXPECTED_HEAD=fc718f90cc258c3d5c36082eacab29bced545dba
RUN_DIR="$PREP/test-focused-locale-$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$RUN_DIR/restore"
exec 9>"$LOCK"
flock -x 9
[[ "$(git -C "$REPO" rev-parse HEAD)" == "$EXPECTED_HEAD" ]]
files=(
  server/src/services/heartbeat.ts
  server/src/services/native-runtime/native-session-executor.ts
  server/src/services/native-runtime/native-session-executor.test.ts
  server/src/services/native-runtime/paid-transport-admission.ts
  server/src/services/native-runtime/paid-transport-admission.test.ts
  server/src/services/native-runtime/native-session-executor-admission.test.ts
  ui/src/lib/system-notice-humanizer.ts
  ui/src/lib/system-notice-humanizer.test.ts
  ui/src/components/task-chat/TaskChatSystemNotice.tsx
  ui/src/i18n/experience/en.json
  ui/src/i18n/experience/da.json
)
: > "$RUN_DIR/restore-manifest.txt"
for rel in "${files[@]}"; do
  src="$REPO/$rel"
  if [[ -e "$src" ]]; then mkdir -p "$RUN_DIR/restore/$(dirname "$rel")"; cp -p "$src" "$RUN_DIR/restore/$rel"; printf 'present %s %s\n' "$(sha256sum "$src" | awk '{print $1}')" "$rel" >> "$RUN_DIR/restore-manifest.txt"
  else printf 'absent - %s\n' "$rel" >> "$RUN_DIR/restore-manifest.txt"; fi
done
orig="$REPO/server/src/services/native-runtime/native-session-executor.ts.orig"
if [[ -e "$orig" ]]; then cp -p "$orig" "$RUN_DIR/native-session-executor.ts.orig"; printf 'orig-present %s\n' "$(sha256sum "$orig" | awk '{print $1}')" > "$RUN_DIR/orig-manifest.txt"
else printf 'orig-absent\n' > "$RUN_DIR/orig-manifest.txt"; fi
restore() {
  local code=$?
  trap - EXIT
  for rel in "${files[@]}"; do
    if [[ -e "$RUN_DIR/restore/$rel" ]]; then cp -p "$RUN_DIR/restore/$rel" "$REPO/$rel"; else rm -f "$REPO/$rel"; fi
  done
  if [[ -e "$RUN_DIR/native-session-executor.ts.orig" ]]; then cp -p "$RUN_DIR/native-session-executor.ts.orig" "$orig"; else rm -f "$orig"; fi
  local bad=0
  while read -r state digest rel; do
    if [[ "$state" == present ]]; then actual="$(sha256sum "$REPO/$rel" | awk '{print $1}')"; [[ "$actual" == "$digest" ]] || { echo "restore mismatch: $rel" >&2; bad=1; }
    elif [[ -e "$REPO/$rel" ]]; then echo "restore expected absent: $rel" >&2; bad=1; fi
  done < "$RUN_DIR/restore-manifest.txt"
  while read -r state digest; do
    if [[ "$state" == orig-present ]]; then [[ "$(sha256sum "$orig" | awk '{print $1}')" == "$digest" ]] || bad=1
    elif [[ -e "$orig" ]]; then bad=1; fi
  done < "$RUN_DIR/orig-manifest.txt"
  if (( bad )); then code=71; fi
  printf '%s\n' "$code" > "$RUN_DIR/exit"
  exit "$code"
}
trap restore EXIT
sha256sum "$PREP/native-paid-admission-guard.patch" > "$RUN_DIR/patch.sha256"
cd "$REPO"
patch --dry-run -p1 < "$PREP/native-paid-admission-guard.patch" > "$RUN_DIR/patch-dry-run.log"
patch -p1 < "$PREP/native-paid-admission-guard.patch" > "$RUN_DIR/patch-apply.log"
cd "$REPO/server"
../node_modules/.bin/vitest run src/services/native-runtime/paid-transport-admission.test.ts src/services/native-runtime/native-session-executor-admission.test.ts --reporter=verbose > "$RUN_DIR/server-vitest.log" 2>&1
cd "$REPO/ui"
../node_modules/.bin/vitest run src/lib/system-notice-humanizer.test.ts --reporter=verbose > "$RUN_DIR/ui-vitest.log" 2>&1
cat "$RUN_DIR/server-vitest.log" "$RUN_DIR/ui-vitest.log"
