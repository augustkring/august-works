from pathlib import Path
p=Path('/workspace/blentera-v10/server/src/services/native-direct-input.ts');s=p.read_text();a=s.index('async function assertNativeDocumentRevisionCurrentSourceAccessInScope(');b=s.index('\n}\n',a);chunk=s[a:b]
needle='''  addNativeSourceActiveVisit(scope, activeKey);
  // Re-read'''
assert chunk.count(needle)==1;chunk=chunk.replace(needle,'''  addNativeSourceActiveVisit(scope, activeKey);
  try {
  // Re-read''',1)
chunk+='''
  } finally {
    scope.active.delete(activeKey);
  }'''
s=s[:a]+chunk+s[b:];p.with_suffix('.activecleanup.tmp.ts').write_text(s)
p=Path('/workspace/blentera-v10/server/src/__tests__/native-payload-temporal-sources.integration.test.ts');s=p.read_text();needle='''        await sourceDb.update(toolInvocations).set({ status: "succeeded" }).where(and(
          eq(toolInvocations.companyId, first.companyId), eq(toolInvocations.id, invocationId)));
'''
assert s.count(needle)==1;s=s.replace(needle,needle+'''        await expect(assertNativeModelOutputCaptureCurrent(sourceDb, first.companyId, first.issueId, capture,
          selected.result.tool as string, second.aliceActor, "settled")).resolves.toBeUndefined();
''',1);p.with_suffix('.activecleanup.tmp.ts').write_text(s)
