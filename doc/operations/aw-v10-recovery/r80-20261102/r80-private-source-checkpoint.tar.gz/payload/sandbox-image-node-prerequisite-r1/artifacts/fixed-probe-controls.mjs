import assert from 'node:assert/strict';
import { readFileSync, realpathSync, lstatSync, statSync } from 'node:fs';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join, posix } from 'node:path';
import { pathToFileURL } from 'node:url';
import { spawnSync } from 'node:child_process';
import { stripTypeScriptTypes } from 'node:module';
import { randomUUID, createHash } from 'node:crypto';
const root = '/workspace/v10-preparation/managed-sandbox-image-node-prerequisite-20261102/r1';
const candidate = root + '/files/server/src/__tests__/helpers/managed-native-conversation-sandbox-host.ts';
const source = readFileSync(candidate, 'utf8');
const start = source.indexOf('function qualifiedFixtureImageNode(');
const end = source.indexOf('export async function configureManagedConversationSandboxHost', start);
assert.ok(start >= 0 && end > start);
const original = source.slice(start, end);
const stripped = stripTypeScriptTypes(original, { mode: 'strip' });
const select = new Function('posix', 'realpathSync', 'lstatSync', 'statSync', 'dirname', 'spawnSync', 'return (' + stripped + ')')
  (posix, realpathSync, lstatSync, statSync, dirname, spawnSync);
const { REMOTE_NATIVE_ERASER_ENV, REMOTE_NATIVE_RUNTIME_ASSET_ERASURE_PROBE_SCRIPT } = await import(
  pathToFileURL('/workspace/blentera-v10/server/src/services/native-runtime/remote-runner-identity.ts').href);
const controls = [];
assert.equal(select(undefined), process.execPath); controls.push('default_local_original_node_unchanged');
const qualifiedNode = select(process.execPath);
assert.equal(qualifiedNode, process.execPath); controls.push('actual_root_owned_current_node_bytes_accepted');
assert.throws(() => select('/usr/bin/sha256sum'), /fixture_image_node_bytes_mismatch/);
controls.push('actual_root_owned_wrong_executable_bytes_denied');
const home = await mkdtemp(join(tmpdir(), 'managed-image-node-controls-'));
try {
  const foreign = join(home, 'node'); await writeFile(foreign, '#!/bin/sh\nexit 0\n', { mode: 0o700 });
  assert.throws(() => select(foreign), /fixture_image_node_path_invalid/);
  controls.push('actual_tenant_writable_nonimage_node_denied');
  const digest = createHash('sha256').update(randomUUID()).digest('hex');
  const runId = randomUUID(), nonce = randomUUID();
  const result = spawnSync('/bin/sh', ['-c', REMOTE_NATIVE_RUNTIME_ASSET_ERASURE_PROBE_SCRIPT,
    'paperclip-native-asset-erasure-probe', home, digest, runId, nonce], {
    cwd: home, env: { ...REMOTE_NATIVE_ERASER_ENV,
      PATH: `${dirname(qualifiedNode)}:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin` },
    encoding: 'utf8', timeout: 15_000, maxBuffer: 64 * 1024,
  });
  assert.equal(result.error, undefined); assert.equal(result.signal, null);
  assert.equal(result.status, 0, 'actual fixed erasure probe must execute with qualified image Node');
  assert.equal(result.stdout.trim(), 'qualified'); controls.push('actual_unmodified_fixed_probe_qualified');
  assert.equal(Object.keys(REMOTE_NATIVE_ERASER_ENV).length, 8);
  assert.equal(Object.hasOwn(REMOTE_NATIVE_ERASER_ENV, 'PATH'), false);
  controls.push('signed_request_eight_scrub_keys_and_no_path_unchanged');
  console.log(JSON.stringify({ status: 'PASS', controls, candidateSha256: createHash('sha256').update(readFileSync(candidate)).digest('hex'),
    selectedNodeBytesSha256: createHash('sha256').update(readFileSync(qualifiedNode)).digest('hex'),
    scope: 'Actual extracted candidate initializer and actual fixed local erasure probe only; no Host/DB/SDK/remote physical qualification' }));
} finally { await rm(home, { recursive: true, force: true }); }
