# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: aw-v9-experience.spec.ts >> V9 workflow review preserves the account gate, separates revisions and keeps Advanced rollback
- Location: tests/e2e/aw-v9-experience.spec.ts:354:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('main').getByRole('status')
Expected substring: "Sign in with a verified account to describe a workflow."
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" with timeout 5000ms
  - waiting for getByRole('main').getByRole('status')
    2 × locator resolved to <p role="status">Loading current work…</p>
      - unexpected value "Loading current work…"

```

```yaml
- link "Skip to Main Content":
  - /url: "#main-content"
- complementary:
  - button "Open V9 disposable workflow company organization switcher": V V9 disposable workflow company
  - navigation:
    - text: View
    - combobox "View":
      - option "Member"
      - option "Manager" [selected]
      - option "Admin"
      - option "Security admin"
    - link "Home":
      - /url: /VDIA/dashboard
    - link "Needs You":
      - /url: /VDIA/needs-you
    - link "Work":
      - /url: /VDIA/work
    - link "Agents":
      - /url: /VDIA/agents
    - link "Apps":
      - /url: /VDIA/apps
    - link "Insights":
      - /url: /VDIA/insights
    - link "Advanced":
      - /url: /VDIA/advanced
    - button "Ask Blentera"
    - link "Help / Support":
      - /url: /VDIA/company/help
- button "Open account menu": BR Browser product reviewer
- separator "Resize sidebar"
- region "Global utilities":
  - button "Ask Blentera"
  - text: Language
  - combobox "Language":
    - option "English" [selected]
    - option "Dansk"
  - link "Help / Support":
    - /url: /VDIA/company/help
  - link "Contact support":
    - /url: mailto:support@blentera.com
  - link "User account":
    - /url: /VDIA/company/settings/instance/profile
- main:
  - heading "Workflows" [level=1]
  - paragraph: Review your processes, their current versions and the work that needs attention.
  - link "Describe a workflow":
    - /url: /VDIA/workflows/new
  - list
  - paragraph: There are no workflows in this current view.
  - paragraph: This view shows up to 20 recent workflows you can currently open. Older work may not appear.
- heading "Command Palette" [level=2]
- paragraph: Search for a command to run...
```

# Test source

```ts
  291 |       exact: true,
  292 |     });
  293 |     for (const name of ["Home", "Needs You", "Work", "Agents", "Apps"])
  294 |       await expect(
  295 |         mobileNavigation.getByRole("link", { name, exact: true }),
  296 |       ).toBeVisible();
  297 |     await page.screenshot({
  298 |       path: "test-results/aw-v9-home-compact.png",
  299 |       fullPage: true,
  300 |     });
  301 |     expect(
  302 |       await page.evaluate(
  303 |         () => document.documentElement.scrollWidth <= window.innerWidth,
  304 |       ),
  305 |     ).toBe(true);
  306 |     await page
  307 |       .getByRole("button", { name: "Open navigation", exact: true })
  308 |       .click();
  309 |     await page
  310 |       .locator("#mobile-sidebar")
  311 |       .getByRole("link", { name: "Advanced", exact: true })
  312 |       .click();
  313 |     await expect(
  314 |       page.getByRole("heading", { name: "Advanced", exact: true }),
  315 |     ).toBeVisible();
  316 |     await expect(
  317 |       page.getByRole("link", { name: "Skills", exact: true }),
  318 |     ).toBeVisible();
  319 |     await json(
  320 |       await request.patch("/api/instance/settings/experimental", {
  321 |         data: Object.fromEntries(
  322 |           Object.keys(enabled).map((key) => [key, false]),
  323 |         ),
  324 |       }),
  325 |     );
  326 |     expect(
  327 |       (
  328 |         await request.get(`${base}/experience?expectedUserId=${expectedUserId}`)
  329 |       ).status(),
  330 |     ).toBe(404);
  331 |     await page.goto(`/${company.issuePrefix}/work`);
  332 |     await expect(page).toHaveURL(new RegExp(`/${company.issuePrefix}/issues$`));
  333 |     await page.goto(`/${company.issuePrefix}/my-feedback`);
  334 |     await expect(
  335 |       page.getByRole("heading", { name: "My feedback", exact: true }),
  336 |     ).toBeVisible();
  337 |     expect(
  338 |       requestedPageChunks.some((path) => /\/MyFeedback-[^/]+\.js$/.test(path)),
  339 |     ).toBe(true);
  340 |     await page
  341 |       .getByRole("button", { name: new RegExp(history[0].feedbackId) })
  342 |       .click();
  343 |     await expect(page.getByText(body, { exact: true })).toBeVisible();
  344 |     expect(errors).toEqual([]);
  345 |   } finally {
  346 |     await request.patch("/api/instance/settings/experimental", {
  347 |       data: Object.fromEntries(
  348 |         Object.keys(enabled).map((key) => [key, original[key]]),
  349 |       ),
  350 |     });
  351 |   }
  352 | });
  353 | 
  354 | test("V9 workflow review preserves the account gate, separates revisions and keeps Advanced rollback", async ({
  355 |   page,
  356 |   request,
  357 |   browser,
  358 |   baseURL,
  359 | }) => {
  360 |   // This covers the whole Native lifecycle and explicit receipt recovery; it
  361 |   // is not an individual interaction or journey-performance timing budget.
  362 |   test.setTimeout(120_000);
  363 |   const original = await json(
  364 |     await request.get("/api/instance/settings/experimental"),
  365 |   );
  366 |   const enabled = {
  367 |     experience_projection_v9: true,
  368 |     progressive_shell_v9: true,
  369 |     enableWorkflowsV1: true,
  370 |     enableWorkflowBuilderV1: true,
  371 |   };
  372 |   await json(
  373 |     await request.patch("/api/instance/settings/experimental", {
  374 |       data: enabled,
  375 |     }),
  376 |   );
  377 |   const company = await json(
  378 |     await request.post("/api/companies", {
  379 |       data: { name: "V9 disposable workflow company" },
  380 |     }),
  381 |   );
  382 |   const base = `/api/companies/${company.id}/workflows`;
  383 |   const errors: string[] = [];
  384 |   page.on("pageerror", (error) => errors.push(error.message));
  385 |     // Verify the account gate with an actually anonymous browser context. The
  386 |     // default authenticated fixture is verified and must be able to proceed.
  387 |     const anonymousContext = await browser.newContext({ baseURL });
  388 |     try {
  389 |       const anonymousPage = await anonymousContext.newPage();
  390 |       await anonymousPage.goto(`/${company.issuePrefix}/workflows`);
> 391 |       await expect(anonymousPage.getByRole("main").getByRole("status")).toContainText(
      |                                                                         ^ Error: expect(locator).toContainText(expected) failed
  392 |         "Sign in with a verified account to describe a workflow.",
  393 |       );
  394 |     } finally {
  395 |       await anonymousContext.close();
  396 |     }
  397 |     // Native activity can withdraw an acknowledgement while its original change
  398 |     // commits. Model the user's explicit, bounded same-request recovery; never
  399 |     // create another command or relax current authority.
  400 |   async function expectCurrentReceipt(text: RegExp) {
  401 |     const receipt = page.getByText(text);
  402 |     const retry = page.getByRole("button", { name: "Retry same request", exact: true });
  403 |     for (let attempt = 0; attempt < 3; attempt++) {
  404 |       try { await expect(receipt).toBeVisible(); return; }
  405 |       catch (missingReceipt) {
  406 |         if (!(await retry.isVisible())) throw missingReceipt;
  407 |         try { await retry.click({ timeout: 1000 }); }
  408 |         catch (changedDialog) {
  409 |           // A late valid acknowledgement can close the dialog between the DOM
  410 |           // check and click. Do not leave a click waiting for a later command.
  411 |           if (await receipt.isVisible()) return;
  412 |           throw changedDialog;
  413 |         }
  414 |       }
  415 |     }
  416 |     await expect(receipt).toBeVisible();
  417 |   }
  418 |   try {
  419 |     const created = await json(
  420 |       await request.post(base, { data: { name: "Review deal opportunities" } }),
  421 |     );
  422 |     const path = `/${company.issuePrefix}/workflows/${created.id}`;
  423 |     await page.goto(path);
  424 |     await expect(
  425 |       page.getByRole("heading", {
  426 |         name: "Review deal opportunities",
  427 |         exact: true,
  428 |       }),
  429 |     ).toBeVisible();
  430 |     await expect(
  431 |       page.getByText("Draft — no active published revision", { exact: true }),
  432 |     ).toBeVisible();
  433 |     await expect(
  434 |       page.getByText(
  435 |         "This revision has no steps yet. It is not a tested process.",
  436 |         { exact: true },
  437 |       ),
  438 |     ).toBeVisible();
  439 |     const graph = (name: string) => ({
  440 |       version: 1,
  441 |       nodes: [
  442 |         {
  443 |           id: "start",
  444 |           type: "core.manual_trigger",
  445 |           name,
  446 |           position: { x: 0, y: 0 },
  447 |           config: {},
  448 |         },
  449 |         {
  450 |           id: "decision",
  451 |           type: "core.condition",
  452 |           name: "Check report",
  453 |           position: { x: 0, y: 1 },
  454 |           config: { expression: "true" },
  455 |         },
  456 |         {
  457 |           id: "yes",
  458 |           type: "core.merge",
  459 |           name: "Prepare report",
  460 |           position: { x: 0, y: 2 },
  461 |           config: { mode: "all" },
  462 |         },
  463 |         {
  464 |           id: "no",
  465 |           type: "core.merge",
  466 |           name: "Other report path",
  467 |           position: { x: 1, y: 2 },
  468 |           config: { mode: "all" },
  469 |         },
  470 |       ],
  471 |       edges: [
  472 |         { id: "start-check", source: "start", target: "decision" },
  473 |         {
  474 |           id: "check-yes",
  475 |           source: "decision",
  476 |           target: "yes",
  477 |           sourceHandle: "true",
  478 |         },
  479 |         {
  480 |           id: "check-no",
  481 |           source: "decision",
  482 |           target: "no",
  483 |           sourceHandle: "false",
  484 |         },
  485 |       ],
  486 |       variables: [],
  487 |       settings: { totalDeadlineSeconds: 60 },
  488 |     });
  489 |     const prepared = await json(
  490 |       await request.patch(`${base}/${created.id}/draft`, {
  491 |         data: {
```