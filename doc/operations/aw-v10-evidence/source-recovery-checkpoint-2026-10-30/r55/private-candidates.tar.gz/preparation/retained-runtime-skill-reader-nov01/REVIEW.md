The retained runtime Skill reader validates the original producer and the actual current reader separately. A completed producer supplies immutable evidence and never becomes a live or impersonated agent.

`assertRetainedRuntimeSkillSourceCurrent(db, { companyId, actor, producerRunId, source })` accepts a complete `runtime_skill` pin with a non-null `versionId`. It returns the selected Skill/version row; Native callers need not consume the return value.

The existing Skill resolver checks the actual reader's company access, Skill visibility and `skills.use` policy, current dependency state, and Learning/Memory/analytical source access. Only the retained entrypoint permits an exact superseded version, and it returns nothing until the producer proof passes. The live `assertRuntimeSkillSourceRetained` implementation is byte-for-byte unchanged.

Producer proof checks the persisted Native execution binding, receipt binding and PostgreSQL JSONB digests, exact runtime Skill pin, exact company/run-owned bundle reference and bytes, canonical execution manifest hash, immutable Skill item, original required manifest ID, and local Context company/run/agent/Task binding. The platform-only Fabric-off path requires the independent server-owned platform admission, exact bundled version inventory digest, no required original manifest marker, and no customer-derived Learning roots. Missing required manifests cannot fall back to this path.

Ordinary Learning roots retain exact original Context coverage and source versions; analytical cycles retain their complete original signal coverage. Current source ACL checks use the real reader. There is no whole-later-Run source union, new ledger, model-callable API, caller authority flag, or historical Run liveness requirement.

The shared helper performs the owned asset read once. Native versioned runtime Skill branches should delegate that read and source validation to this helper; versionless branches retain their existing exact bundle read. Native's existing deferred runtime Skill read obligations remain in place.

Focused PostgreSQL qualification uses no model/provider network. The synthetic DB producer records qualify the source reader component, not actual provider consumption or a paid runtime. The earlier signed software SandboxRelay run separately proved all 19 canonical qualification cases and one completed model reservation, but finalization still failed before this source fix.
