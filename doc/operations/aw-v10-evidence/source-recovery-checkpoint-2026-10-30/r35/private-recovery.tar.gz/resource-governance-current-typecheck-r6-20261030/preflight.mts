import fs from "node:fs";
import { createRequire } from "node:module";
const require = createRequire("/workspace/v10-dep-qualification/packages/db/package.json");
const postgres = require("postgres");
import { __startEmbeddedPostgresWithRetryForTests } from "/workspace/v10-dep-qualification/packages/db/src/test-embedded-postgres.ts";
const source = fs.readFileSync("/workspace/v10-preparation/b-resource-governance-current.sql", "utf8");
const functionSql = source.split("\n--> statement-breakpoint\n", 1)[0];
const { port, dataDir, instance } = await __startEmbeddedPostgresWithRetryForTests("resource-sql-preflight-");
const client = postgres(`postgres://paperclip:paperclip@127.0.0.1:${port}/postgres`);
try { await client.unsafe(functionSql); console.log("policy validation function parsed by embedded PostgreSQL"); }
finally {
  await client.end();
  await instance.stop().catch(() => {});
  fs.rmSync(dataDir, { recursive: true, force: true });
}
