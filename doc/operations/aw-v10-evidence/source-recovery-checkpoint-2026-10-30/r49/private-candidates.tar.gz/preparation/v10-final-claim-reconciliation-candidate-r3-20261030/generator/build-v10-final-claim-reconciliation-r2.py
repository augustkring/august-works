import json, hashlib, pathlib, subprocess
from datetime import date
ROOT=pathlib.Path('/workspace/blentera-v10')
PREP=pathlib.Path('/workspace/v10-preparation')
OUT=PREP/'v10-final-claim-reconciliation-candidate-r2-20261030'
MAP_PATH=PREP/'v10-169-full-current-evidence-map-20261030.json'
MAP=json.load(open(MAP_PATH))
QUALITY_AUDIT_PATH=PREP/'v10-001-060-current-gap-audit-20261030.json'
RESOURCE_AUDIT_PATH=PREP/'v10-169-061-120-current-gap-audit-luna-20261030.json'
TAIL_AUDIT_PATH=PREP/'v10-169-full-current-gap-audit-20261030.json'
QUALITY_AUDIT=json.load(open(QUALITY_AUDIT_PATH))
RESOURCE_AUDIT=json.load(open(RESOURCE_AUDIT_PATH))
TAIL_AUDIT=json.load(open(TAIL_AUDIT_PATH))
AUDIT_SPECS=[(QUALITY_AUDIT_PATH,QUALITY_AUDIT,1,60),(RESOURCE_AUDIT_PATH,RESOURCE_AUDIT,61,120),(TAIL_AUDIT_PATH,TAIL_AUDIT,121,169)]
HIST_PATH='doc/operations/aw-v10-evidence/recovery-2026-10-22/requirement-reconciliation.json'
CROSSWALK=PREP/'current-inherited-crosswalk-20261028'
def digest(path):
 p=pathlib.Path(path)
 return hashlib.sha256(p.read_bytes()).hexdigest()
def source_path(path):
 p=pathlib.Path(path)
 return p if p.is_absolute() else ROOT/path
def pin(path,roles):
 p=source_path(path)
 if p.is_file(): return {'path':path,'location':'repository' if not pathlib.Path(path).is_absolute() else 'preparation_workspace','state':'present_at_snapshot','sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'roles':sorted(roles)}
 if p.is_dir(): return {'path':path,'location':'repository' if not pathlib.Path(path).is_absolute() else 'preparation_workspace','state':'directory_present_no_file_hash','sha256':None,'roles':sorted(roles)}
 return {'path':path,'location':'repository' if not pathlib.Path(path).is_absolute() else 'preparation_workspace','state':'not_present_at_snapshot','sha256':None,'roles':sorted(roles)}
# Build exact paths per row and one deduplicated interim source inventory.
all_roles={}
rowpins={}
audit_rows={}
for pth,audit,start,end in AUDIT_SPECS:
 for ar in audit.get('rows',[]):
  audit_rows[ar['id']]={'path':str(pth),'audit':audit,'row':ar,'range':[start,end]}
for row in MAP['rows']:
 roles={}
 def add(path,role):
  if isinstance(path,str) and path:
   roles.setdefault(path,set()).add(role)
 add_many=row.get('explicitCurrentOwnerPaths',[])
 for p in add_many: add(p,'current_owner_navigation')
 for item in row.get('mappedSourceAndEvidenceLinksAtPriorSnapshot',[]): add(item.get('path'),'prior_candidate_navigation_refreshed_to_snapshot_hash')
 review=row.get('currentBoundedReview') or {}
 for item in review.get('currentOwners',[]): add(item.get('path'),'current_bounded_review_owner')
 for item in review.get('evidence',[]): add(item.get('path'),'scoped_receipt_or_source_evidence')
 extra=review.get('additionalQualificationUpdate') or {}
 for item in extra.get('receipts',[]): add(item.get('path'),'scoped_receipt_or_source_evidence')
 for item in row.get('currentCrosswalkReview',{}).get('predecessorInputs',[]): add(item.get('path'),'inherited_crosswalk_input')
 xref=row.get('currentCrosswalkReview',{}).get('crosswalkProposal',{})
 if xref.get('path'): add(xref['path'],'private_crosswalk_proposal_not_acceptance')
 audit_entry=audit_rows.get(row['id'])
 if audit_entry:
  add(audit_entry['path'],'bounded_read_only_gap_audit_not_qualification')
  def collect_paths(value):
   if isinstance(value,dict):
    candidate=value.get('path')
    if isinstance(candidate,str): add(candidate,'read_only_audit_owner_or_receipt_reference')
    for child in value.values(): collect_paths(child)
   elif isinstance(value,list):
    for child in value: collect_paths(child)
  collect_paths(audit_entry['row'])
 rowpins[row['id']]=roles
 for p,rs in roles.items(): all_roles.setdefault(p,set()).update(rs)
# Authoritative documents and predecessor registers used by the report, all hash refreshed at capture.
authoritative_paths=[
 'doc/reference/blentera-v10/Blentera_Master_Build_Brief_V10_FINAL_v4.0_2026-10-18.md',
 HIST_PATH,
 'doc/plans/2026-10-28-v10-current-reconciliation.md',
 'doc/operations/aw-v6-evidence.md',
 'doc/operations/aw-v8-source-acceptance.md',
 'doc/reference/aw-v9/README.md',
 'doc/reference/blentera-v10/recovery.json',
 'evals/aw-v7/pilot-readiness.json',
 'evals/aw-v8/readiness.json',
 'evals/aw-v9/readiness.json',
 'doc/experience/v9/coverage.json',
 str(QUALITY_AUDIT_PATH), str(RESOURCE_AUDIT_PATH), str(TAIL_AUDIT_PATH),
 '/workspace/v10-preparation/temporal9-reader-origin-r47-20261030-test.log',
 '/workspace/v10-preparation/temporal9-reader-origin-r47-20261030-test.exit',
]
for p in authoritative_paths: all_roles.setdefault(p,set()).add('authoritative_cross_version_source')
all_roles[str(CROSSWALK)]={'private_inherited_crosswalk_proposal_not_acceptance'}
source_inventory=[pin(p,roles) for p,roles in sorted(all_roles.items())]
pin_by={p['path']:p for p in source_inventory}
# Refresh current hashes per row. Historical original register status remains copied verbatim.
rows=[]
for source in MAP['rows']:
 review=source.get('currentBoundedReview')
 cross=source.get('currentCrosswalkReview')
 if review:
  disposition='scoped_current_review'
  software={'state':'bounded_only','assessment':review.get('assessment'),'finding':review.get('finding'),'remainingWork':review.get('remainingWork')}
  qualification={'localSourceAndTest':{'status':'bounded_scope_only','scope':review.get('evidenceScope'),'receipts':review.get('evidence',[])},'runtimeProvider':{'status':'not_established_by_this_source_report','scope':'No installed-runtime or live-provider qualification is inferred.'},'humanOperator':{'status':'not_established_by_this_source_report','scope':'Source authorization gates do not constitute Human/operator acceptance.'},'hostedProduction':{'status':'not_established_by_this_source_report','scope':'No deployment, production-population or hosted acceptance is inferred.'}}
 elif cross:
  disposition='inherited_crosswalk_only'
  software={'state':'not_independently_reassessed','assessment':'The crosswalk is navigation and predecessor-status analysis only; no current source implementation conclusion is inferred.'}
  qualification={'localSourceAndTest':{'status':'not_qualified','scope':'Crosswalk mapping only; no local source/test receipt.'},'runtimeProvider':{'status':'unknown_not_qualified'},'humanOperator':{'status':'unknown_not_qualified','scope':'H6/H7 meanings are unavailable in their canonical predecessor definitions.'},'hostedProduction':{'status':'not_established'},'exactReceipts':[]}
 else:
  disposition='prior_snapshot_navigation_only'
  software={'state':'not_independently_reassessed_at_this_snapshot','assessment':'Mapped source presence or missing receipt is not evidence of implementation, a software gap, or acceptance.'}
  qualification={'localSourceAndTest':{'status':'not_independently_assessed'},'runtimeProvider':{'status':'unknown_not_qualified'},'humanOperator':{'status':'unknown_not_qualified'},'hostedProduction':{'status':'not_established'},'exactReceipts':[]}
 rows.append({
  'id':source['id'],
  'requirement':source.get('work'),
  'historicalRegisterStatus':source['historicalStatus'],
  'historicalEvidence':source.get('historicalEvidence',[]),
  'historicalStatusUnchanged':True,
  'currentDisposition':disposition,
  'currentReviewState':source.get('currentReviewState'),
  'currentSoftwareImplementation':software,
  'actualQualification':qualification,
  'currentSourcePins':[pin_by[p] for p in sorted(rowpins[source['id']]) if p in pin_by],
  'boundedReadOnlyAudit':None,
  'navigationAndReviewDetail':source,
 })
 row_out=rows[-1]
 if source['id']=='V10-122':
  row_out['currentReviewState']='qualified_at_a3dd_commit_snapshot; current_source_pin_revalidation_pending'
  row_out['currentSoftwareImplementation']['assessment']='The sidecar and fail-closed compatibility gate were implemented and qualified at commit a3dd; do not treat that commit-local result as a current post-Native source pass.'
  row_out['currentSoftwareImplementation']['finding']='At the a3dd source snapshot, the sidecar mapped all 38 declared typed aliases to canonical operations/tools and domain owners, captured 17 literal source/test consumer paths plus runtime-instruction files, and guarded operation-manifest and Skill v3 hash drift. Every alias remained active. Three pinned source files have changed since that receipt; current revalidation is pending. No external use, runtime compatibility, deprecation, successful removal, or retirement is established.'
  row_out['actualQualification']['localSourceAndTest']={'status':'passed_at_a3dd_commit_snapshot_current_pin_revalidation_pending','scope':'Checker and 7 mutation tests passed at the a3dd source snapshot. Native/Auth/Gateway/MemoryService files pinned by that receipt have since changed; the checker and tests have not yet been rerun. All aliases remain active; no removal test or runtime qualification.' ,'receipts':review.get('evidence',[])}
  row_out['currentSourceFreshness']={'status':'stale_since_commit_qualification_recheck_pending','changedOwnerFamilies':['Native','authorization','Tool Gateway','MemoryService'],'requiredAction':'After final source freeze, refresh pins and run the checker plus all 7 mutation tests. Do not promote the commit-local pass.'}
 if source['id'] in audit_rows:

  ae=audit_rows[source['id']]
  audit_doc=ae['audit']
  nested=ae['row'].get('audit',{}).get('review',{}) if isinstance(ae['row'].get('audit'),dict) else {}
  row_out['boundedReadOnlyAudit']={'sourcePath':ae['path'],'sourceSha256':digest(ae['path']),'reviewRange':ae['range'],'auditMode':audit_doc.get('scope',audit_doc.get('method')),'rowDisposition':ae['row'].get('disposition',nested.get('disposition')),'row':ae['row'],'classification':'read_only_source_review_not_test_qualification','supersessionNote':('The tail audit predates the a3dd transition-guard implementation; that receipt supersedes only its per-alias inventory/removal-gate gap at that commit. Current pin revalidation, runtime qualification and actual alias removal remain open.' if source['id']=='V10-122' else None)}
# Exact current predecessor snapshots and their explicit limitations.
v7=json.load(open(ROOT/'evals/aw-v7/pilot-readiness.json'))
v8=json.load(open(ROOT/'evals/aw-v8/readiness.json'))
v9=json.load(open(ROOT/'evals/aw-v9/readiness.json'))
v9cov=json.load(open(ROOT/'doc/experience/v9/coverage.json'))
recovery=json.load(open(ROOT/'doc/reference/blentera-v10/recovery.json'))
alias_inventory_path=ROOT/'doc/operations/agent-native-tool-alias-compatibility.json'
alias_inventory=json.load(open(alias_inventory_path))
alias_pin_drift=[]
for item in alias_inventory.get('sourcePins',[]):
 p=ROOT/item['path']
 if p.is_file():
  current_hash=hashlib.sha256(p.read_bytes()).hexdigest()
  if current_hash != item['sha256']:
   alias_pin_drift.append({'path':item['path'],'qualifiedCommitSha256':item['sha256'],'currentSnapshotSha256':current_hash})
blockers=[]
for item in v7.get('implementationBlockers',[]): blockers.append({'id':item['id'],'status':item.get('status'),'wave':item.get('wave'),'source':item.get('source'),'qualificationLimit':item.get('verificationScope')})

# Exact predecessor claim inventories and the per-V10 launch-claim evidence matrix.
# Do not infer semantic links from similar wording or ordinal position.
V6_PATH='doc/operations/aw-v6-evidence.md'
V7_PATH='evals/aw-v7/pilot-readiness.json'
V8_PATH='evals/aw-v8/readiness.json'
V8_ACCEPTANCE_PATH='doc/operations/aw-v8-source-acceptance.md'
V9_PATH='evals/aw-v9/readiness.json'
V9_COVERAGE_PATH='doc/experience/v9/coverage.json'
CROSSWALK_JSON=json.load(open(CROSSWALK))
V6_CROSS=CROSSWALK_JSON['predecessorRegisters']['V6']
V7_CROSS=CROSSWALK_JSON['predecessorRegisters']['V7']
V8_CROSS=CROSSWALK_JSON['predecessorRegisters']['V8']
V9_CROSS=CROSSWALK_JSON['predecessorRegisters']['V9']

def current_pin_for(path):
 p=source_path(path)
 return {'path':path,'state':'present_at_snapshot','sha256':hashlib.sha256(p.read_bytes()).hexdigest()} if p.is_file() else {'path':path,'state':'not_present_at_snapshot','sha256':None}

def exact_meta_items():
 return [x['id'] for x in CROSSWALK_JSON['v10ReconciliationLinks'] if x['id'] in {'V10-001','V10-003','V10-157'}]
META_V10_ITEMS=exact_meta_items()

predecessor_claims=[]
def add_predecessor_claim(version, kind, key, source_register, text, raw=None, explicit_id=None,
                          predecessor_owner_paths=None, historical_refs=None, semantic_v10=None,
                          qualification_v10=None, mapping_basis=None):
 predecessor_owner_paths=predecessor_owner_paths or []
 historical_refs=historical_refs or []
 semantic_v10=semantic_v10 or []
 qualification_v10=qualification_v10 or []
 claim={
  'predecessorVersion':version,
  'recordKind':kind,
  'sourceClaimKey':key,
  'claimId':explicit_id,
  'claimText':text,
  'sourceRegister':current_pin_for(source_register),
  'sourceCoordinate':key if explicit_id else None,
  'predecessorOwnerPaths':[current_pin_for(p) for p in predecessor_owner_paths],
  'historicalEvidenceReferences':[current_pin_for(p) for p in historical_refs],
  'semanticV10RequirementLinks':semantic_v10,
  'qualificationV10WorkItemLinks':qualification_v10,
  'reconciliationV10WorkItemLinks':META_V10_ITEMS,
  'mappingBasis':mapping_basis or ('No authoritative predecessor-to-V10 semantic foreign key was present; link is deliberately unresolved.' if not semantic_v10 else 'Exact named predecessor blocker is explicitly included by the V10-149 inherited execution-blocker contract.'),
  'currentQualification':'not_reassessed_as_part_of_this_crosswalk',
  'externalHumanProviderHostedAndReleaseProfile':'not_established_or_unknown; see predecessor register status and global gates.',
 }
 if raw is not None: claim['retainedPredecessorRecord']=raw
 if explicit_id is None: claim['identifierStatus']='no_formal_claim_id_in_authoritative_source; coordinate retained without minting an ID'
 predecessor_claims.append(claim)

# V6 canonical register has wave/coverage categories but no per-H6 definitions. The IDs are copied
# from the successor crosswalk only as identifiers; the meaning and owner remain unresolved.
for item in V6_CROSS.get('legacyGateIds',[]):
 add_predecessor_claim('V6','legacy_human_gate',item['id'],V6_PATH,item.get('meaning',''),item,explicit_id=item['id'],
   qualification_v10=['V10-149'],mapping_basis='V6 H6 identifier is listed in successor registers, but the canonical V6 register has no definition/owner/acceptance pointer. V10-149 keeps H6/H7 operator gates separate; no semantic requirement mapping is inferred.')
for ix,item in enumerate(V6_CROSS.get('coverageRows',[]),1):
 add_predecessor_claim('V6','coverage_row_without_stable_id',f'coverageRows[{ix-1}]',V6_PATH,item.get('topic',''),item,
   predecessor_owner_paths=[],historical_refs=[],
   mapping_basis='V6 source register groups this work by wave/topic without a stable requirement ID; retain its source coordinate, do not invent a claim ID or V10 semantic link.')

# V7 stores named journeys/faults/cases/evidence and explicit blocker IDs. Only the three incomplete
# blocker IDs have an exact semantic link to the V10-149 table; other labels remain crosswalk-only.
for h7 in V7_CROSS.get('legacyGateIds',[]):
 add_predecessor_claim('V7','legacy_human_gate',h7['id'],V7_PATH,h7.get('meaning',''),h7,explicit_id=h7['id'],
   qualification_v10=['V10-149'],mapping_basis='V7 H7 identifier is listed but not individually defined in the canonical V7 manifest. V10-149 retains the H7 operator gate separately; no semantic source requirement mapping is inferred.')
for name in ['journey','faults','compoundCases','operatingEvidence']:
 values=v7.get(name,[])
 for ix,value in enumerate(values):
  key=value if isinstance(value,str) else value.get('id',f'{name}[{ix}]')
  label=value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,sort_keys=True)
  add_predecessor_claim('V7',name,key,V7_PATH,label,value,
    mapping_basis='The V7 register names this journey/fault/case/evidence category but supplies no authoritative V10 semantic foreign key; linked only to the reconciliation deliverables.')
for item in v7.get('implementationBlockers',[]):
 blocker_id=item['id']
 add_predecessor_claim('V7','implementation_blocker',blocker_id,V7_PATH,blocker_id,item,explicit_id=blocker_id,
   predecessor_owner_paths=[item['source']],historical_refs=[],semantic_v10=['V10-149'] if item.get('status')=='incomplete' else [],
   qualification_v10=['V10-149'],mapping_basis='The V10-149 brief clause names V7 sandbox/model/runtime owners and requires all three implementation groups to be enforced and qualified; the exact three incomplete blocker IDs in the V7 register are mapped here. The automated_read_only_semantic_consumer is not an incomplete blocker and is not mapped as one.')

# V8 has 28 exact §57 claim IDs and an explicit predecessor status. Preserve each exact row and source refs.
for item in V8_CROSS.get('requirementCrosswalkRows',[]):
 req_id=item.get('requirementId')
 refs=[p for p in item.get('historicalSourceAndVerificationRefs',[]) if isinstance(p,str) and p]
 add_predecessor_claim('V8','section57_requirement',req_id,V8_ACCEPTANCE_PATH,item.get('requirement',''),item,explicit_id=req_id,
   predecessor_owner_paths=refs,historical_refs=refs,
   mapping_basis='Exact V8-S57 requirement ID and retained V8 source-acceptance row; no V10 semantic ID is assigned because the checked-in predecessor crosswalk provides no V10 foreign key.')
 # The detailed row coordinates are transcribed in the private inherited crosswalk; keep that
 # provenance explicit instead of implying the JSON readiness file contains the 28-row table.
 predecessor_claims[-1]['predecessorRowTranscriptionSource']=current_pin_for(str(CROSSWALK))
 predecessor_claims[-1]['readinessStatusSource']=current_pin_for(V8_PATH)

# V9 screen and global-contract identifiers are exact in the V9 coverage manifest. Empty evidenceRefs
# and in_progress remain explicit; no line-number or ordinal mapping to V10 is inferred.
for item in v9cov.get('screens',[]):
 sid=item.get('screenId')
 owners=item.get('componentPaths',[])
 spec=item.get('specification',{})
 refs=[p for p in [spec.get('path'),item.get('contractPath')] if p]
 add_predecessor_claim('V9','experience_screen',sid,V9_COVERAGE_PATH,sid,item,explicit_id=sid,
   predecessor_owner_paths=owners,historical_refs=item.get('historicalEvidenceRefs',[]),
   mapping_basis='Exact V9 screen ID, spec and contract are retained from coverage.json; implementationStatus/evidenceRefs are manifest fields, not current acceptance, and no V10 semantic foreign key is present.')
for key in v9cov.get('globalContracts',[]):
 add_predecessor_claim('V9','global_contract',key,V9_COVERAGE_PATH,key,key,explicit_id=key,
   mapping_basis='Exact V9 global contract key retained. No V10 semantic foreign key is present in the source manifest.')

# V10-149 is the only direct semantic predecessor mapping supported by the exact brief table and V7 IDs.
semantic_v10_to_predecessors={}
for claim in predecessor_claims:
 for req_id in claim['semanticV10RequirementLinks']:
  semantic_v10_to_predecessors.setdefault(req_id,[]).append({'predecessorVersion':claim['predecessorVersion'],'claimId':claim['claimId'],'sourceClaimKey':claim['sourceClaimKey'],'mappingBasis':claim['mappingBasis']})
qualification_v10_to_predecessors={}
for claim in predecessor_claims:
 for req_id in claim['qualificationV10WorkItemLinks']:
  qualification_v10_to_predecessors.setdefault(req_id,[]).append({'predecessorVersion':claim['predecessorVersion'],'claimId':claim['claimId'],'sourceClaimKey':claim['sourceClaimKey'],'mappingBasis':claim['mappingBasis']})

# Build one explicit launch-claim row for every preserved V10 requirement, exposing its source owners,
# current and historical receipts, and distinct external/Human/release gates.
launch_claim_rows=[]
source_by_id={x['id']:x for x in MAP['rows']}
for outrow in rows:
 source=source_by_id[outrow['id']]
 review=source.get('currentBoundedReview') or {}
 current_receipts=review.get('evidence',[])+((review.get('additionalQualificationUpdate') or {}).get('receipts',[]))
 historical=[]
 for path in source.get('historicalEvidence',[]):
  historical.append({'path':path,'currentSnapshotPin':current_pin_for(path),'interpretation':'historical register reference; not current qualification'})
 launch_claim_rows.append({
  'v10RequirementId':outrow['id'],
  'requirement':outrow['requirement'],
  'bindingClause':source.get('bindingClause'),
  'historicalRegisterStatusPreserved':outrow['historicalRegisterStatus'],
  'currentSourceDisposition':outrow['currentDisposition'],
  'currentImplementationFinding':outrow['currentSoftwareImplementation'],
  'currentOwnerNavigationPaths':[current_pin_for(p) for p in source.get('explicitCurrentOwnerPaths',[])],
  'currentSnapshotSourcePins':outrow['currentSourcePins'],
  'currentScopedReceipts':current_receipts,
  'historicalReceiptReferences':historical,
  'exactSemanticPredecessorClaims':semantic_v10_to_predecessors.get(outrow['id'],[]),
  'predecessorQualificationGateReferences':qualification_v10_to_predecessors.get(outrow['id'],[]),
  'reportReconciliationInputs':META_V10_ITEMS if outrow['id'] in {'V10-001','V10-003','V10-157'} else [],
  'actualQualification':outrow['actualQualification'],
  'externalGates':{
    'runtimeProvider':'unknown_or_not_established_by_this_report',
    'humanOperator':'unknown_or_not_established; H6/H7 meanings remain unresolved where applicable',
    'hostedProduction':'not_established',
    'signedReleaseProfile':'not_established; predecessor V8/V9 readiness has no accepted releaseIdentity',
  },
  'historicalStatusWasRewritten':False,
 })

predecessor_claim_crosswalk={
 'schemaVersion':1,
 'kind':'predecessor-claim-to-v10-reconciliation-crosswalk',
 'sourcePins':{p:current_pin_for(p) for p in [V6_PATH,V7_PATH,V8_PATH,V8_ACCEPTANCE_PATH,V9_PATH,V9_COVERAGE_PATH]},
 'mappingPolicy':'Only an exact authoritative predecessor ID-to-V10 relationship is a semantic link. V10-001, V10-003 and V10-157 are report/traceability work items, not semantic equivalence. Unresolved links are represented as empty semanticV10RequirementLinks and not guessed by wording or ordinal.',
 'explicitSemanticMappings':[
  {'v10RequirementId':'V10-149','predecessorClaims':[x for x in semantic_v10_to_predecessors.get('V10-149',[])],
   'basis':'Master brief §39.1 table line 6746 names V7 sandbox/model/runtime owners; all three incomplete V7 implementation blockers are linked. H6/H7 stay qualification gates, not semantic feature mappings.'}
 ],
 'reconciliationWorkItems':META_V10_ITEMS,
 'predecessorClaims':predecessor_claims,
 'unresolvedHumanGates':[
  *[{'id':x['id'],'version':'V6','meaning':'unknown_not_defined_in_canonical_v6_register','identifierSource':current_pin_for(str(CROSSWALK)),'canonicalPredecessorRegister':current_pin_for(V6_PATH),'successorIdentifierSources':[current_pin_for(V8_PATH),current_pin_for(V9_PATH)], 'v10QualificationWorkItem':'V10-149'} for x in V6_CROSS.get('legacyGateIds',[])],
  *[{'id':x['id'],'version':'V7','meaning':'unknown_not_defined_in_canonical_v7_readiness_manifest','identifierSource':current_pin_for(str(CROSSWALK)),'canonicalPredecessorRegister':current_pin_for(V7_PATH),'successorIdentifierSources':[current_pin_for(V8_PATH),current_pin_for(V9_PATH)], 'v10QualificationWorkItem':'V10-149'} for x in V7_CROSS.get('legacyGateIds',[])],
 ],
 'releaseQualificationSummary':{
  'V6':{'status':'draft; rollout gates off','human':'H6-01..18 undefined; no closure inferred','releaseProfile':'not established','hosted':'not established'},
  'V7':{'status':v7.get('status','no top-level release acceptance field'),'incompleteBlockers':[b['id'] for b in v7.get('implementationBlockers',[]) if b.get('status')=='incomplete'],'human':'H7-01..03 undefined; no closure inferred','releaseProfile':'not established','hosted':'not established'},
  'V8':{'stage':v8.get('stage'),'sourceComplete':v8.get('sourceComplete'),'acceptedBy':v8.get('acceptedBy'),'releaseIdentity':v8.get('releaseIdentity'),'predecessorStatus':v8.get('predecessorStatus'),'releaseProfile':'not established','hosted':'not established'},
  'V9':{'stage':v9.get('stage'),'sourceComplete':v9.get('sourceComplete'),'acceptedBy':v9.get('acceptedBy'),'releaseIdentity':v9.get('releaseIdentity'),'inheritedPredecessorGates':v9.get('inheritedPredecessorGates'),'releaseProfile':'not established','hosted':'not established'},
 },
 'limitations':['This is a report/crosswalk draft, not owner acceptance.','Historical source/test receipts remain attached to their original predecessor claims and are not current-head qualification.','No signed release profile, hosted-production, external provider, H6/H7 Human/operator or named owner decision is supplied.','Unmapped predecessor claims are not absent; their authoritative V10 semantic mapping is unresolved.']
}

source='Current V10 brief §53/§55–56 and the private all-169 map distinguish current bounded owner evidence from release acceptance.'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
report={
 'schemaVersion':1,
 'kind':'private-v10-final-cross-version-and-launch-claim-reconciliation-candidate',
 'created':'2026-10-30',
 'status':'candidate_for_root_review_not_release_decision',
 'intent':'Reviewer-facing current/interim reconciliation of the preserved 169 V10 requirements against predecessor registers, exact bounded receipts and explicit external/Human/hosted qualification limits.',
 'scopeAndNonClaims':[
  'The October 22 canonical 169-row register and every historical status are preserved exactly.',
  'A row without a current bounded review is unreviewed at this snapshot; it is not classified as a missing feature or a failure.',
  'Mapped file presence, old receipts, local fixtures, source checks and partial tests are not promoted to universal acceptance.',
  'No production deployment, provider/runtime, Human/operator, customer-population, hosted, or GA claim is made here.',
  'Native-wide qualification, final aggregate and final CI remain pending; this report is not a global green.'
 ],
 'snapshot':{
  'headCommit':head,'worktreeDirty':True,'snapshotClass':'current/interim source hashes over a dirty worktree; regenerate after final source freeze',
  'historicalRegister':{'path':HIST_PATH,'sha256':digest(ROOT/HIST_PATH),'rows':169,'historicalStatusCounts':MAP['historicalRegister']['historicalStatusCounts'],'preservedExactly':True},
  'privateCurrentEvidenceMap':{'path':str(MAP_PATH),'sha256':digest(MAP_PATH),'scope':'all 169 historical rows, scoped current receipts and explicit unreviewed/crosswalk-only limits'},
  'currentInheritedCrosswalk':{'path':str(CROSSWALK),'sha256':digest(CROSSWALK),'classification':'private predecessor navigation proposal only; not canonical or acceptance evidence'},
  'sourceHashBasis':'Every listed present file was SHA-256 hashed from the repository/preparation workspace during this snapshot. Missing prior links are recorded as absent-at-snapshot and do not imply missing implementation. Source freezes have not occurred; Native/Auth/Gateway/MemoryService edits can make pins stale immediately.'
 },
 'bindingAuthority':{
  'brief':{'path':authoritative_paths[0],'sha256':digest(ROOT/authoritative_paths[0]),'clauses':['§40 re-ground catalogue','§50 acceptance evidence','§53 qualification versus missing code','§55 claim reconciliation','§56 migration/deprecation gates']},
  'originalRegister':{'path':HIST_PATH,'sha256':digest(ROOT/HIST_PATH)},
  'predecessorRegisters':[
   {'id':'V6','path':'doc/operations/aw-v6-evidence.md','sha256':digest(ROOT/'doc/operations/aw-v6-evidence.md')},
   {'id':'V7','path':'evals/aw-v7/pilot-readiness.json','sha256':digest(ROOT/'evals/aw-v7/pilot-readiness.json')},
   {'id':'V8','path':'evals/aw-v8/readiness.json','sha256':digest(ROOT/'evals/aw-v8/readiness.json')},
   {'id':'V8 source acceptance','path':'doc/operations/aw-v8-source-acceptance.md','sha256':digest(ROOT/'doc/operations/aw-v8-source-acceptance.md')},
   {'id':'V9 readiness','path':'evals/aw-v9/readiness.json','sha256':digest(ROOT/'evals/aw-v9/readiness.json')},
   {'id':'V9 experience coverage','path':'doc/experience/v9/coverage.json','sha256':digest(ROOT/'doc/experience/v9/coverage.json')},
   {'id':'V10 recovery baseline (dated 2026-10-22; not a current release verdict)','path':'doc/reference/blentera-v10/recovery.json','sha256':digest(ROOT/'doc/reference/blentera-v10/recovery.json')},
   {'id':'V10 current scoped reconciliation','path':'doc/plans/2026-10-28-v10-current-reconciliation.md','sha256':digest(ROOT/'doc/plans/2026-10-28-v10-current-reconciliation.md')}
  ]
 },
 'crossVersionSummary':{
  'V6':{'registerState':'The current inherited crosswalk cannot find canonical definitions for H6-01..H6-18; successor records list IDs only.','definitionStatus':'unknown; do not invent meanings or claim closure'},
  'V7':{'implementationBlockers':blockers,'interpretation':'Retain each V7 blocker at its original owner/status; bounded source receipts close only their named scope. H7-01..03 definitions remain absent from the checked-in V7 readiness manifest.'},
  'V8':{'predecessorStatus':v8.get('predecessorStatus'),'predecessorGateIds':v8.get('predecessorGateIds'),'interpretation':'V8 source acceptance is a historical scoped map; predecessor open gates do not become accepted from a V10 summary.'},
  'V9':{'stage':v9.get('stage'),'sourceComplete':v9.get('sourceComplete'),'acceptedBy':v9.get('acceptedBy'),'releaseIdentity':v9.get('releaseIdentity'),'inheritedPredecessorGates':v9.get('inheritedPredecessorGates'),'pendingEvidence':v9.get('pendingEvidence'),'experienceCoverage':{'screenCount':len(v9cov.get('screens',[])),'implementationStatusCounts':{},'evidenceRefPopulatedCount':sum(bool(x.get('evidenceRefs')) for x in v9cov.get('screens',[])),'interpretation':'Coverage manifest is not acceptance; assess its exact declared fields.'}},
  'V10':{'historicalRegisterRows':169,'historicalStatusCounts':MAP['historicalRegister']['historicalStatusCounts'],'currentBoundedOrUpdatedRows':MAP['counts']['rowsWithPriorBoundedReviewOrCurrentUpdate'],'rowsWithoutIndependentCurrentSourceReview':MAP['counts']['rowsNotIndependentlyReassessedAfterCandidateSnapshot'],'crosswalkOnlyRows':MAP['counts']['crosswalkOnlyCurrentReviewsNotCountedAsSourceReassessment'],'recoveryBaseline':{'implementationComplete':recovery.get('implementationComplete'),'prReady':recovery.get('prReady'),'date':recovery.get('date'),'previousTestResultsApplicable':recovery.get('previousTestResultsApplicable'),'interpretation':'Dated baseline document only; it is not current aggregate status.'}}
 },
 'boundedReadOnlyGapAudits':{
  'quality001_060':{'path':str(QUALITY_AUDIT_PATH),'sha256':digest(QUALITY_AUDIT_PATH),'scope':QUALITY_AUDIT.get('scope'),'findingCount':len(QUALITY_AUDIT.get('findings',[])),'interpretation':'Read-only narrow audit of concrete mandatory software defects only; zero findings is not feature-completeness or release acceptance.'},
  'resource061_120':{'path':str(RESOURCE_AUDIT_PATH),'sha256':digest(RESOURCE_AUDIT_PATH),'scope':RESOURCE_AUDIT.get('scope'),'confirmedMandatorySoftwareGaps':RESOURCE_AUDIT.get('result',{}).get('confirmedMandatorySoftwareGaps'),'confirmedRuntimeDefects':RESOURCE_AUDIT.get('result',{}).get('confirmedRuntimeDefects'),'interpretation':'Read-only source review, no tests or provider calls; bounded non-finding does not close historical status.'},
  'tail121_169':{'path':str(TAIL_AUDIT_PATH),'sha256':digest(TAIL_AUDIT_PATH),'scope':'Bounded current read-only tail review; rows 146..168 mostly deferred from Native/other owner-wide re-audit. Earlier V10-122 gate gap was addressed by a3dd source gate; active-alias removal and runtime qualification remain unproved.'},
  'synthesis':'The 001..060 and 061..120 bounded audits found no new confirmed mandatory software gap in their stated scopes. The tail audit identified a V10-122 lifecycle-gate gap now addressed at a3dd and a V10-121 inventory mismatch resolved by edee/R10 refresh. This does not establish full implementation, whole-program coverage, or absence of other defects in deferred Native rows.'
 },
 'aliasGuardCurrentStatus':{'qualifiedCommit':'a3ddabbb1686dcfc8edd2e1c2dc15d822c1977bb','qualificationAtCommit':'checker and 7 mutation tests passed; all aliases remained active','currentRevalidation':'pending; the current sidecar pin comparison found source drift after the commit. The checker and tests have not been rerun against changed pins. No alias removal or runtime qualification is claimed.','driftedPins':alias_pin_drift},
 'explicitReportDeliverables':[
  {'id':'V10-001','status':'candidate_draft_present_pending_final_source_freeze_and_owner_review','currentRead':'This candidate supplies a reviewer-facing current-master/V8/V9/V10 cross-version draft; the owner-approved per-ID/journey/source matrix remains interim pending source freeze and review.','humanUnknowns':'H6/H7 definitions remain absent; do not resolve or interpret.'},
  {'id':'V10-003','status':'candidate_draft_present_pending_final_source_freeze_and_owner_review','currentRead':'This candidate drafts the launch-claim/evidence structure. Final claim-by-claim owner review, exact frozen receipt links and external gates remain pending; do not infer launch or hosted acceptance.'},
  {'id':'V10-149','status':'candidate_draft_present_pending_original_owner_closure','currentRead':'This candidate keeps the three V7 implementation blockers and H6/H7 operator/Human gates distinct. Closure still requires exact evidence from each original owner; this summary does not close them.'},
  {'id':'V10-157','status':'candidate_draft_present_pending_final_source_freeze_and_owner_review','currentRead':'This candidate drafts exact claim-to-predecessor reconciliation, but final frozen claim/receipt links and owner review remain pending. Historical, source-only, fixture and bounded evidence are not hosted acceptance.'}
 ],
 'crossCuttingQualificationBlockers':{
  'nativeWide':{'status':'pending_not_green','latestCompletedAttempt':'Native R47 (temporal9-reader-origin-r47-20261030-test.log)','reportedResult':'Runner exit 1; 1 test passed and 8 were skipped, not a complete 9-test cohort. The executed case failed on “The Native source graph exceeds its total-work bound” (gateway 403); no timeout fired in this run.','currentBlocker':'Native is narrowing whole-context over-capture in reader sets while retaining completeness fallback and other obligations. Native R48 completed-obligation/frozen-provenance work is private and in progress, not qualified. Treat Native as active/pending, not a source acceptance result.'},
  'finalAggregate':{'status':'pending','note':'Final V10 aggregate has not been run against frozen, final source.'},
  'finalCI':{'status':'pending','note':'Final CI qualification awaits Native/source freeze and a completed aggregate run.'},
  'externalAndHuman':{'status':'unqualified_or_unknown','note':'No production/provider, installed-runtime, Human/operator, hosted, representative-customer, or release decision is inferred from this candidate.'}
 },
 'evidencePolicy':{
  'sourceImplementation':'Only explicit current owner findings are reported as bounded source slices; otherwise not independently assessed.',
  'localQualification':'Copy the exact source/test cohort and its limitations from the linked current row receipt.',
  'externalHumanHosted':'Keep distinct from local source qualification. Unknown means unknown, not passed and not a software defect.',
  'historicalStatuses':'Preserve from the October 22 register; do not rewrite as current acceptance.',
  'currentSourcePins':'Interim current/worktree SHA-256 pins, not stable release identities. Refresh after Native and final source freeze.'
 },
 'sourceHashInventory':source_inventory,
 'rows':rows,
 'refreshAfterFreeze':[
  'Regenerate every current/interim source hash for all row source pins and authoritative documents.',
  'Refresh current owner receipts for source paths changed by final Native, responsibility, phase/inventory/Help/SafeGraph work.',
  'Rerun the final aggregate and CI; update Native-wide status from an exact complete 9-test result only.',
  'Obtain owner-approved V10-001/003/149/157 report dispositions and H6/H7 definitions from their actual predecessor owners.',
  'Record external/provider/installed-runtime/Human/hosted evidence only when the actual owner supplies exact receipts.'
 ]
}
# Attach the exact cross-version claim matrix and a reviewable 169-row launch-claim/evidence matrix.
report['predecessorClaimTraceability']={
 'artifactPath':str(OUT/'predecessor-claim-crosswalk.json'),
 'claimCount':len(predecessor_claims),
 'exactSemanticV10Links':{'V10-149':len(semantic_v10_to_predecessors.get('V10-149',[]))},
 'unmappedSemanticLinks':sum(not c['semanticV10RequirementLinks'] for c in predecessor_claims),
 'method':'Exact predecessor IDs, source records, V10 semantic links, current owner pins, historical receipts and qualification gates are separate fields; no inferred H6/H7 meanings.'
}
report['launchClaimMatrix']={
 'artifactPath':str(OUT/'launch-claim-matrix.json'),
 'rowCount':len(launch_claim_rows),
 'historicalStatusPreserved':all(x['historicalStatusWasRewritten'] is False for x in launch_claim_rows),
 'currentSourceSnapshot':'interim_dirty_worktree; refresh after final source freeze',
 'releaseAndHostedAcceptance':'not established by this report'
}
report['explicitReportDeliverables']=[
 {'id':'V10-001','status':'reviewable_r2_draft_owner_review_and_final_source_pins_pending','currentRead':'The candidate now supplies a 169-row current-owner/evidence matrix and exact predecessor claim inventory. Semantic predecessor links remain empty unless an authoritative source supplies them; owner approval and final source freeze remain pending.','humanUnknowns':'H6/H7 meanings remain unknown and unassigned.'},
 {'id':'V10-003','status':'reviewable_r2_launch_claim_matrix_owner_review_and_release_evidence_pending','currentRead':'A 169-row launch-claim matrix now separates historical status, current owners/pins/receipts, and runtime/provider, Human/operator, hosted, and release-profile gates. No claim is promoted to accepted or hosted.'},
 {'id':'V10-149','status':'three_v7_incomplete_blockers_mapped; owner_qualification_pending','currentRead':'The exact three incomplete V7 blocker IDs map to V10-149; H6/H7 remain separately unresolved qualification gates. Current owners must provide exact final source/runtime/provider evidence.'},
 {'id':'V10-157','status':'reviewable_r2_exact_predecessor_traceability_draft; frozen_receipts_and_owner_review_pending','currentRead':'The exact V6/V7/V8/V9 claim inventory, explicit semantic links, unknown mappings, and 169 V10 claim rows are linked. Final frozen claim/source receipts, signed release profile and owner review are not established.'}
]
report['predecessorClaimTraceability']['artifactSha256']=hashlib.sha256(json.dumps(predecessor_claim_crosswalk,indent=2,ensure_ascii=False).encode()).hexdigest()
report['launchClaimMatrix']['artifactSha256']=hashlib.sha256(json.dumps(launch_claim_rows,indent=2,ensure_ascii=False).encode()).hexdigest()
(OUT/'predecessor-claim-crosswalk.json').write_text(json.dumps(predecessor_claim_crosswalk,indent=2,ensure_ascii=False)+'\n')
(OUT/'launch-claim-matrix.json').write_text(json.dumps({'schemaVersion':1,'kind':'v10-launch-claim-evidence-matrix','generatedBy':'existing v10 final claim reconciliation candidate builder r2','rows':launch_claim_rows},indent=2,ensure_ascii=False)+'\n')
# Populate V9 experience coverage counts accurately.
from collections import Counter
report['crossVersionSummary']['V9']['experienceCoverage']['implementationStatusCounts']=dict(Counter(x.get('implementationStatus','<missing>') for x in v9cov.get('screens',[])))
# Verify source pins and row history map.
assert len(rows)==169 and all(r['historicalStatusUnchanged'] for r in rows)
assert len(report['sourceHashInventory'])==len(all_roles)
(OUT/'reconciliation.json').write_text(json.dumps(report,indent=2)+'\n')
