from pathlib import Path
import hashlib,json,difflib
r=Path('/workspace/blentera-v10');base=Path('/workspace/v10-preparation/native-capacity-r70-candidate');out=Path('/workspace/v10-preparation/native-context-profile-r71-candidate')
rels=['server/src/services/native-direct-input.ts','server/src/__tests__/native-payload-temporal-sources.integration.test.ts']
for rel in rels:
 (out/rel).parent.mkdir(parents=True,exist_ok=True);(out/rel).write_bytes((base/rel).read_bytes())
rel='server/src/services/context/context-manifest.ts';old=(r/rel).read_text();s=old
needle='      const phaseTimes: Record<string, number> = {};';assert s.count(needle)==1;s=s.replace(needle,needle+'\n      const phaseBounds: Record<string, { startUs: number; endUs: number }> = {};\n      let phaseStartUs = Number(process.hrtime.bigint() / 1000n);',1)
needle='          const now = performance.now(), counts = readPhaseCounts();';assert s.count(needle)==1;s=s.replace(needle,needle+'\n          const endUs = Number(process.hrtime.bigint() / 1000n);\n          phaseBounds[phaseName] = { startUs: phaseStartUs, endUs };\n          phaseStartUs = endUs;',1)
needle='          nativeAppendOnlyCapture: phaseAppendOnly, phaseTimes, phaseCounts, phaseOrigins }));';assert s.count(needle)==1;s=s.replace(needle,'          nativeAppendOnlyCapture: phaseAppendOnly, phaseTimes, phaseCounts, phaseOrigins, phaseBounds }));',1)
(out/rel).parent.mkdir(parents=True,exist_ok=True);(out/rel).write_text(s);(out/'r71-only.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)));rels.append(rel)
m={}
for rel in rels:
 a=(r/rel).read_bytes();b=(out/rel).read_bytes();m[rel]={'priorSha256':hashlib.sha256(a).hexdigest(),'candidateSha256':hashlib.sha256(b).hexdigest()}
(out/'manifest.json').write_text(json.dumps(m,indent=2));(out/'syntax-pins.json').write_text(json.dumps({'qualificationWorkspace':str(out),'copiedFiles':[{'path':rel} for rel in m]},indent=2))
p=Path('/workspace/v10-preparation');snapshot=(p/'snapshot-private-native-r70.py').read_text().replace('native-capacity-r70-candidate','native-context-profile-r71-candidate');(p/'snapshot-private-native-r71.py').write_text(snapshot);runner=(p/'run-private-native-capacity-r70.sh').read_text().replace('snapshot-private-native-r70.py','snapshot-private-native-r71.py').replace('-t "$TEST_PATTERN" --reporter=verbose \\','-t "$TEST_PATTERN" --reporter=verbose --execArgv=--cpu-prof --execArgv=--cpu-prof-dir=/workspace/v10-preparation/native-context-cpu-r71-20261101 \\')
needle='cd "$ROOT/server"';assert runner.count(needle)==1;runner=runner.replace(needle,'mkdir -p /workspace/v10-preparation/native-context-cpu-r71-20261101\n'+needle,1);(p/'run-private-native-context-profile-r71.sh').write_text(runner)
assert runner.count('--cpu-prof-dir=')==2
print((out/'r71-only.diff').read_text())
