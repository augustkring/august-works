from pathlib import Path
p=Path('/workspace/blentera-v10/server/src/__tests__/native-payload-temporal-sources.integration.test.ts');s=p.read_text();a=s.index('  it("keeps repeated Native output proofs');b=s.index('  it("keeps earlier Task A',a);chunk=s[a:b];pos=chunk.rindex('  });')
addition='''    // Memory C inherited Task B's earlier producer. A fresh public validation
    // in this same physical transaction must reload that historical receipt.
    const [followupRun] = await db.select({ runnerProfileJson: heartbeatRuns.runnerProfileJson }).from(heartbeatRuns)
      .where(and(eq(heartbeatRuns.companyId, first.companyId), eq(heartbeatRuns.id, second.runId)));
    const followupProfile = followupRun?.runnerProfileJson as Record<string, unknown>;
    const followupReceipt = nativeRunInputSourceReceiptSchema.parse(followupProfile.nativeInputSourceReceipt);
    const memoryCCallId = second.toolResults.find(value => value.memoryId === temporal.memoryCId)?.callId;
    const followupResult = records(followupProfile.nativeToolResultSourceCaptures).find(value => value.callId === memoryCCallId);
    const followupAssociation = records(followupProfile.nativeToolCallDispatchAssociations).find(value => value.callId === memoryCCallId);
    const followupIntent = records(followupProfile.nativeAwModelWireIntents).find(value =>
      records(value.responseToolUses).some(use => use.id === memoryCCallId));
    const followupDispatch = followupReceipt.dispatches.flatMap(prefix => prefix.inputs).find(source =>
      (source.kind === "worker_model_dispatch" || source.kind === "conversation_model_dispatch") &&
      source.reservationId === followupIntent?.reservationId);
    if (!followupResult || !followupAssociation || !followupIntent || !followupDispatch)
      throw new Error("The real Memory C output lacks its settled follow-up producer capture");
    const followupCapture = { runId: second.runId, dispatch: followupDispatch,
      sourceSet: followupIntent.consumedSourceSet, consumedSourceComponents: followupIntent.consumedSourceComponents,
      managedOpenCodeToolUse: { callId: memoryCCallId, toolName: followupResult.tool,
        argumentsHash: followupAssociation.argumentsHash, responseContentHash: followupIntent.responseContentHash } }
      as Parameters<typeof assertNativeModelOutputCaptureCurrent>[3];
    await db.transaction(async rawTx => {
      const tx = rawTx as unknown as typeof db;
      expect(await withReadMemoryTemporalSources(tx, second.aliceActor, first.companyId, temporal.memoryCId!, async sourceDb => {
        await assertNativeModelOutputCaptureCurrent(sourceDb, first.companyId, second.issueId, followupCapture,
          followupResult.tool as string, second.aliceActor, "settled");
        try {
          await sourceDb.update(heartbeatRuns).set({ runnerProfileJson: { ...profile, nativeInputSourceReceipt: null } })
            .where(and(eq(heartbeatRuns.companyId, first.companyId), eq(heartbeatRuns.id, first.runId)));
          await expect(assertNativeModelOutputCaptureCurrent(sourceDb, first.companyId, second.issueId, followupCapture,
            followupResult.tool as string, second.aliceActor, "settled")).rejects.toMatchObject({ status: 403 });
        } finally {
          await sourceDb.update(heartbeatRuns).set({ runnerProfileJson: profile })
            .where(and(eq(heartbeatRuns.companyId, first.companyId), eq(heartbeatRuns.id, first.runId)));
        }
        await expect(assertNativeModelOutputCaptureCurrent(sourceDb, first.companyId, second.issueId, followupCapture,
          followupResult.tool as string, second.aliceActor, "settled")).resolves.toBeUndefined();
      })).not.toBe(false);
    });
'''
chunk=chunk[:pos]+addition+chunk[pos:];s=s[:a]+chunk+s[b:];p.with_suffix('.priorproducer.tmp.ts').write_text(s)
