# Operation coverage r6 — Feedback measure withdrawal

This receipt records the published 0566 submitter withdrawal call in the current mounted UI inventory. `ui/src/pages/MyFeedback.tsx` calls `customerFeedbackApi.withdrawExperienceMeasure`; the entry is `HUMAN_ONLY`, launch-critical for consent/privacy state, owned by `server/src/services/customer-feedback.ts`, with no Agent operation mapping or exemption.

The source rationale cites the route's Board actor requirement, expectedUserId binding, company-access check and the service's current active-source access and exact `customer_feedback_access.user_id` ownership query. The route explicitly maps local-implicit sessions to `local-board`; this row does not claim every Board principal is a persisted verified account. The service deletes only the submitter's rating sidecar, adds a content-free withdrawal marker and audits the action in one transaction.

The 0566 exact published software bundle is `doc/operations/aw-v10-evidence/feedback-quality-qualified-2026-10-30/qualification.tar.gz` (SHA-256 `4ad594982fdc5b9e46e47f14524ee6e14f19f9118adcec335cae6bbed02fad63`). Its bounded source/migration qualification includes PostgreSQL 44/44, server typecheck, shared 7/7 plus metadata 2/2, UI 37/37 and UI typecheck. It does not claim production, representative-customer or Human acceptance.

Canonical inventory verification passed: 6 Agent tool operations, 159 existing API-only contracts remain explicitly unqualified/tool-free, and 998 exact mounted UI callsites classified. Inventory tests passed 12/12; inventory `git diff --check` passed. The run is limited to this source-integrity guard and its unit tests; it is not a full workspace check.
