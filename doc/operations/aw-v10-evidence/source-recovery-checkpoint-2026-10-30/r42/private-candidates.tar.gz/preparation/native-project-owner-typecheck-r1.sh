#!/usr/bin/env bash
set -euo pipefail
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH
exec flock -x /workspace/v10-preparation/v10-pg-tests.lock bash -lc '
set -euo pipefail
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH GOMEMLIMIT=1536MiB GOGC=50
out=/workspace/v10-preparation/native-project-owner-typecheck-r1-20261029
mkdir -p "$out"
for file in source-pins.json snapshot.log snapshot.exit syntax.log syntax.exit server.log server.exit exit; do
  if [[ -e "$out/$file" ]]; then echo "attempt artifact already exists: $out/$file" >&2; exit 73; fi
done
set +e
python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$out/source-pins.json" > "$out/snapshot.log" 2>&1
rc=$?
printf "%s\n" "$rc" > "$out/snapshot.exit"
if [[ "$rc" -ne 0 ]]; then printf "%s\n" "$rc" > "$out/exit"; exit "$rc"; fi
node /workspace/v10-preparation/check-snapshot-syntax.cjs "$out/source-pins.json" > "$out/syntax.log" 2>&1
rc=$?
printf "%s\n" "$rc" > "$out/syntax.exit"
if [[ "$rc" -ne 0 ]]; then printf "%s\n" "$rc" > "$out/exit"; exit "$rc"; fi
cd /workspace/v10-dep-qualification/server
timeout 300s node node_modules/typescript/bin/tsc --noEmit --singleThreaded > "$out/server.log" 2>&1
rc=$?
printf "%s\n" "$rc" > "$out/server.exit"
printf "%s\n" "$rc" > "$out/exit"
exit "$rc"
'
