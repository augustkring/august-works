from pathlib import Path
import json,hashlib,difflib
repo=Path('/workspace/blentera-v10');out=Path('/workspace/v10-preparation/native-frozen-reader-pins-r48-candidate');m={};diff=[]
def save(rel,old,s):
 p=out/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);m[rel]={'priorSha256':hashlib.sha256(old.encode()).hexdigest(),'candidateSha256':hashlib.sha256(s.encode()).hexdigest()};diff.extend(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
rel='server/src/services/authorization.ts';old=(repo/rel).read_text();s=old
s=s.replace('routineRevisionSnapshotV1Schema, type AgentExecutionScope }','routineRevisionSnapshotV1Schema, type AgentExecutionScope, type NativePayloadSourceInput, type NativePayloadSourcePolicy }',1)
s=s.replace('import type { NativeToolEffectClaim } from "../agent-auth-jwt.js";','import type { NativeToolEffectClaim } from "../agent-auth-jwt.js";\nimport type { NativeSourceGraphObligationHandle } from "./native-direct-input.js";',1)
needle='export interface NativeMutableSourceDependencies { rows: Map<string, NativeMutableSourceRowDependency>; compatible: boolean }'
assert needle in s;s=s.replace(needle,'''export interface NativeMutableSourceDependencies { rows: Map<string, NativeMutableSourceRowDependency>; compatible: boolean;
  readerProof?: {
    readerSets: ReadonlyMap<string, { companyId: string; actor: AuthorizationActor; runId: string;
      policy: NativePayloadSourcePolicy; inputs: NativePayloadSourceInput[] }>;
    readerObligations: NativeSourceGraphObligationHandle;
  };
}''',1);save(rel,old,s)
rel='server/src/services/native-direct-input.ts';old=(repo/rel).read_text();s=old
s=s.replace('interface NativeSourceGraphObligationHandle {','export interface NativeSourceGraphObligationHandle {',1)
needle='''    if (reusable && cachedDescendants && !cachedCycle && mutableSourcesCurrent) {
      markNativeProofReaderSelectionIncomplete(scope);'''
new='''    const structuralHit = Boolean(reusable && cachedDescendants && !cachedCycle && mutableSourcesCurrent);
    const cachedReaderProof = !scope.context.ancestry.graphProofsDisabled ? cachedMutableSources?.readerProof : undefined;
    const sameReaderContext = cachedReaderProof?.readerObligations !== undefined &&
      cachedReaderProof.readerObligations === scope.context.readerObligations;
    const completedReaders = cachedReaderProof?.readerObligations.completed;
    let readerProofCurrent: boolean | undefined;
    if (structuralHit && cachedReaderProof && (sameReaderContext || completedReaders)) {
      const ownPin = (sameReaderContext ? scope.taskTemporalScopes : completedReaders?.taskPins)?.get(issueId);
      readerProofCurrent = Boolean(ownPin && ownPin.contentHash === snapshot.owner.contentHash &&
        ownPin.snapshotDigest === snapshot.digest && (sameReaderContext || completedReaders &&
          await replayNativeSourceGraphObligations(scope, completedReaders, cachedReaderProof.readerSets)));
    }
    if (structuralHit && cachedDescendants && readerProofCurrent === true) {
      // Other-context descriptors become reusable only after the original full
      // reader flush and company fence. The existing replay restores exact
      // Task pins and freshly checks Skills and every deferred owner family.
      recordNativeProofReaderSetUse(scope, readerProofCurrent ? cachedReaderProof?.readerSets : undefined);'''
assert needle in s;s=s.replace(needle,new,1)
needle='''    const proofFrame = { visitKey, descendants: new Set<string>(), mutableSources: newNativeMutableSources() };
    proofStack.push(proofFrame);'''
assert needle in s;s=s.replace(needle,'''    const readerObligations = !scope.context.ancestry.graphProofsDisabled && is(db, PgTransaction)
      ? (scope.context.readerObligations ??= {}) : undefined;
    const proofFrame: NativeSourceProofFrame = { visitKey, descendants: new Set<string>(), mutableSources: newNativeMutableSources(),
      readerSelection: { context: scope.context, sets: new Map(), complete: true } };
    proofStack.push(proofFrame);''',1)
needle='''          scope.frozenTaskSnapshots.set(completeKey, new Set(proofFrame.descendants));
          scope.frozenTaskMutableSources.set(completeKey, proofFrame.mutableSources);'''
new='''          scope.frozenTaskSnapshots.set(completeKey, new Set(proofFrame.descendants));
          const readerProof = proofFrame.readerSelection?.complete && readerObligations && !scope.context.ancestry.graphProofsDisabled
            ? { readerSets: new Map(proofFrame.readerSelection.sets), readerObligations } : undefined;
          scope.frozenTaskMutableSources.set(completeKey, { ...proofFrame.mutableSources,
            ...(readerProof ? { readerProof } : {}) });'''
assert needle in s;s=s.replace(needle,new,1)
assert 'export interface NativeSourceGraphObligationHandle' in s
save(rel,old,s)
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');(out/'candidate.diff').write_text(''.join(diff));print(json.dumps(m,indent=2))
