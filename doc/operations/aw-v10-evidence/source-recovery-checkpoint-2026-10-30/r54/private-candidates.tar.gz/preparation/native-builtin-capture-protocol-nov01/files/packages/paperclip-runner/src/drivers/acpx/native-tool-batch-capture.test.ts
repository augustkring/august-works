import { createHash } from "node:crypto";

import { describe, expect, it } from "vitest";

import {
  ACPX_NATIVE_TOOL_BATCH_CAPTURE_MAX_BYTES,
  NativeToolBatchCaptureBridge,
  parseNativeToolBatchCaptureHookRequest,
  type NativeToolBatchCapturePending,
} from "./native-tool-batch-capture.js";

const receiptDigest = `sha256:${"a".repeat(64)}`;

function canonical(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;
  if (typeof value === "object" && value !== null) {
    const record = value as Record<string, unknown>;
    return `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${canonical(record[key])}`).join(",")}}`;
  }
  return JSON.stringify(value) ?? "null";
}

function witness(content = "fixture bytes") {
  const bytes = Buffer.from(content);
  const file = {
    relativePath: "fixture.txt",
    sha256: createHash("sha256").update(bytes).digest("hex"),
    size: bytes.length,
    contentBase64: bytes.toString("base64"),
    device: 1,
    inode: 2,
    mtimeMs: 3,
  };
  const digestRows = [{ path: file.relativePath, hash: file.sha256, size: file.size }];
  return {
    schema: "paperclip.native-workspace-witness.v1",
    workspaceRootDigest: `sha256:${"b".repeat(64)}`,
    snapshotDigest: `sha256:${createHash("sha256").update(canonical(digestRows)).digest("hex")}`,
    fileCount: 1,
    totalBytes: bytes.length,
    files: [file],
    excludedSymlinks: [],
  };
}

function preRequest(toolInput: unknown = { file_path: "/run/workspace/fixture.txt" }) {
  const sdkHookInput = {
    session_id: "claude-session-1",
    transcript_path: "/run/transcript.jsonl",
    cwd: "/run/workspace",
    prompt_id: "prompt-1",
    permission_mode: "default",
    hook_event_name: "PreToolUse",
    tool_name: "Read",
    tool_input: toolInput,
    tool_use_id: "toolu-1",
  };
  return {
    phase: "pre" as const,
    sessionId: "acp-session-1",
    sdkHookInput,
    sdkHookToolUseId: "toolu-1",
    toolUseId: "toolu-1",
    toolName: "Read",
    toolInput,
    workspaceWitness: witness(),
  };
}

function postRequest() {
  const sdkHookInput = {
    session_id: "claude-session-1",
    transcript_path: "/run/transcript.jsonl",
    cwd: "/run/workspace",
    prompt_id: "prompt-1",
    permission_mode: "default",
    hook_event_name: "PostToolBatch",
    tool_calls: [{
      tool_name: "Read",
      tool_input: { file_path: "/run/workspace/fixture.txt" },
      tool_use_id: "toolu-1",
      tool_response: "line 1\nline 2\t",
    }],
  };
  return {
    phase: "post" as const,
    sessionId: "acp-session-1",
    sdkHookInput,
    toolUseIds: ["toolu-1"],
    workspaceWitness: witness("line 1\nline 2\n"),
    preReceiptDigests: { "toolu-1": receiptDigest },
  };
}

function startCapture(bridge: NativeToolBatchCaptureBridge, options: {
  runId?: string;
  turnId?: string;
  signal?: AbortSignal;
  request?: ReturnType<typeof preRequest> | ReturnType<typeof postRequest>;
  timeoutMs?: number;
} = {}) {
  let published: NativeToolBatchCapturePending | null = null;
  const promise = bridge.request({
    runId: options.runId ?? "run-1",
    turnId: options.turnId ?? "turn-1",
    request: options.request ?? preRequest(),
    signal: options.signal ?? new AbortController().signal,
    timeoutMs: options.timeoutMs,
    publish: (capture) => { published = capture; },
  });
  return { promise, get published() { return published; } };
}

describe("native ACP PostToolBatch capture bridge", () => {
  it("accepts the actual un-enriched SDK PreToolUse and PostToolBatch tuples", () => {
    const pre = {
      phase: "pre",
      sessionId: "backend-session",
      sdkHookInput: {
        hook_event_name: "PreToolUse",
        session_id: "agent-session",
        cwd: "/workspace",
        tool_name: "Read",
        tool_use_id: "tool-use-1",
        tool_input: { file_path: "README.md" },
      },
      sdkHookToolUseId: "tool-use-1",
    };
    expect(parseNativeToolBatchCaptureHookRequest(pre)).toEqual(pre);

    const post = {
      phase: "post",
      sessionId: "backend-session",
      sdkHookInput: {
        hook_event_name: "PostToolBatch",
        session_id: "agent-session",
        cwd: "/workspace",
        tool_calls: [{
          tool_name: "Read",
          tool_use_id: "tool-use-1",
          tool_input: { file_path: "README.md" },
          tool_response: "actual SDK response",
        }],
      },
    };
    expect(parseNativeToolBatchCaptureHookRequest(post)).toEqual(post);
  });

  it("holds the actual SDK pre-tool tuple until persistence acknowledges it", async () => {
    const bridge = new NativeToolBatchCaptureBridge();
    const capture = startCapture(bridge);
    expect(bridge.pendingCount).toBe(1);
    expect(capture.published?.capture).toEqual(preRequest());

    let settled = false;
    void capture.promise.then(() => { settled = true; });
    await Promise.resolve();
    expect(settled).toBe(false);
    expect(bridge.resolve({
      captureId: capture.published!.captureId,
      runId: "run-1",
      turnId: "turn-1",
      accepted: true,
      receiptDigest,
    })).toEqual({ resolved: true });
    await expect(capture.promise).resolves.toEqual({ accepted: true, receiptDigest });
    expect(bridge.pendingCount).toBe(0);
  });

  it("binds the post-tool batch to its exact SDK tuple and matching pre receipt", async () => {
    const bridge = new NativeToolBatchCaptureBridge();
    const capture = startCapture(bridge, { request: postRequest() });
    expect(capture.published?.capture).toEqual(postRequest());
    bridge.resolve({ captureId: capture.published!.captureId, runId: "run-1", turnId: "turn-1", accepted: true, receiptDigest });
    await expect(capture.promise).resolves.toEqual({ accepted: true, receiptDigest });
  });

  it("rejects wrong-scope, unknown, and replayed acknowledgements without settling another capture", async () => {
    const bridge = new NativeToolBatchCaptureBridge();
    const capture = startCapture(bridge);
    const captureId = capture.published!.captureId;
    expect(() => bridge.resolve({ captureId, runId: "run-2", turnId: "turn-1", accepted: true, receiptDigest }))
      .toThrow("native_tool_batch_capture_ack_scope_mismatch");
    expect(() => bridge.resolve({ captureId: "unknown", runId: "run-1", turnId: "turn-1", accepted: true, receiptDigest }))
      .toThrow("native_tool_batch_capture_unknown_or_replayed");
    expect(bridge.pendingCount).toBe(1);
    bridge.resolve({ captureId, runId: "run-1", turnId: "turn-1", accepted: true, receiptDigest });
    await expect(capture.promise).resolves.toEqual({ accepted: true, receiptDigest });
    expect(() => bridge.resolve({ captureId, runId: "run-1", turnId: "turn-1", accepted: true, receiptDigest }))
      .toThrow("native_tool_batch_capture_unknown_or_replayed");
  });

  it("fails closed on negative acknowledgements, timeout, abort, and turn termination", async () => {
    const bridge = new NativeToolBatchCaptureBridge();
    const rejected = startCapture(bridge);
    bridge.resolve({ captureId: rejected.published!.captureId, runId: "run-1", turnId: "turn-1", accepted: false, code: "source_unavailable" });
    await expect(rejected.promise).rejects.toThrow("native_tool_batch_capture_rejected:source_unavailable");

    const timeout = startCapture(bridge, { timeoutMs: 10 });
    await expect(timeout.promise).rejects.toThrow("native_tool_batch_capture_timeout");

    const controller = new AbortController();
    const aborted = startCapture(bridge, { signal: controller.signal });
    controller.abort();
    await expect(aborted.promise).rejects.toThrow("native_tool_batch_capture_cancelled");

    const ended = startCapture(bridge);
    bridge.rejectTurn("run-1", "turn-1");
    await expect(ended.promise).rejects.toThrow("native_tool_batch_capture_turn_ended");
    expect(bridge.pendingCount).toBe(0);
  });

  it("rejects malformed digests, over-budget captures, and too many concurrent captures", async () => {
    const bridge = new NativeToolBatchCaptureBridge();
    let published = 0;
    const publish = () => { published += 1; };
    expect(() => bridge.request({ runId: "run-1", turnId: "turn-1", request: { ...preRequest(), toolUseId: "other" }, signal: new AbortController().signal, publish }))
      .toThrow("native_tool_batch_capture_pre_hook_invalid");
    expect(() => bridge.request({ runId: "run-1", turnId: "turn-1", request: preRequest("x".repeat(ACPX_NATIVE_TOOL_BATCH_CAPTURE_MAX_BYTES)), signal: new AbortController().signal, publish }))
      .toThrow("native_tool_batch_capture_request_exceeds_limit");
    expect(published).toBe(0);

    const pending = Array.from({ length: 8 }, (_, index) => startCapture(bridge, { turnId: `turn-${index}` }));
    expect(bridge.pendingCount).toBe(8);
    expect(() => startCapture(bridge, { turnId: "overflow" })).toThrow("native_tool_batch_capture_pending_limit");
    bridge.rejectAll();
    await Promise.all(pending.map((capture) => expect(capture.promise).rejects.toThrow("native_tool_batch_capture_bridge_closed")));
    expect(bridge.pendingCount).toBe(0);
  });
});
