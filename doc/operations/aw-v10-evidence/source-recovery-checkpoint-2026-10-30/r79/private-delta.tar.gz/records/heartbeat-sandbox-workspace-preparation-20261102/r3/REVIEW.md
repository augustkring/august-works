# Private workspace and artifact owner R3

Frozen review source only. Oxc parsed 9 production, 2 existing test files and 1 existing fixture file. No TypeScript/test/PG/provider acceptance. Main/Mirror untouched; R1/R2 unchanged.

Retains approved R1 sealed-authority deferred workspace ordering and real Git/ignore discovery. Ordinary Worker probe, harness and artifact operations now use the same current Task/Human/manifest/lease/workspace/source owner with credentialless policy. Existing exact erasure/harness predicates are reused. Worker launcher model refresh and Stop request purposes remain unchanged.

The shared native-artifact-preparation module is used by executor and RuntimeControl. Existing immutable source authority pins the locally verified pack manifest, controller runner hash and one exact installed root. Server-process-only PAPERCLIP_RUNNER_REMOTE_PROVIDER_PACK_INSTALL_ROOT defaults to /opt/paperclip-runner/provider-pack; it must be normalized, absolute and non-root. No Agent environment, model, path suffix or hook selects it. The exact staged root remains supported. Current policy must prohibit writable projections overlapping the installed pack and satisfy the existing isolated process/image policy guard.

A fixed /bin/sh script uses absolute system checksum binaries and compares manifest-pinned Node bytes BEFORE executing Node. The verifier receives the existing closed startup environment, preventing NODE_OPTIONS/NODE_PATH/loader injection. The shared unchanged verifier binds canonical manifest, all artifact hashes and dist tree. Only afterward does the constructor execute version and link operations. Ordinary Worker runner bytes are staged from the pinned controller artifact, then checksum-checked before metadata.

The software Host fixture selects its actual image-pack symlink through operator process configuration and restores it on close. Its parent is R15 plus the ordinary Worker additions. Coherent composition must preserve newer R16 closure fixes with a three-way merge, never replace the helper wholesale.

Prepared tests reuse real locally verified pack bytes and the actual checksum script, including executable substitution and an untrusted PATH. They retain exact script/manifest/path/startup-environment, workspace command and callback bounds negatives. They have not run. The recovery78 and other domain fixture migrations remain unresolved. No physical qualification or complete ordinary Worker success is inferred.
