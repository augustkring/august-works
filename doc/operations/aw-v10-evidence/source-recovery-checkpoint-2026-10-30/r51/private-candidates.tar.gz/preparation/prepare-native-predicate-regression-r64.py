from pathlib import Path
import hashlib,json,difflib
r=Path('/workspace/blentera-v10');rel='server/src/__tests__/native-payload-temporal-sources.integration.test.ts';a=(r/rel).read_text();s=a
s=s.replace('import { activeMemoryTemporalContexts, canActorReadIssuePrivacy, withReadMemoryTemporalSources,','import { activeMemoryTemporalContexts, activeMemoryTemporalReadScopeIdentity, activeMemoryTemporalReadScopePredicateIdentity,\n  canActorReadIssuePrivacy, withReadMemoryTemporalSources,',1)
s=s.replace('  assertNativeModelOutputCaptureCurrent, nativeConsumedSourceComponentsContainCycle,','  assertNativeModelOutputCaptureCurrent, canActorReadNativeTaskSource, nativeConsumedSourceComponentsContainCycle,',1)
needle='''      // A different Memory owner in the same physical transaction has a
      // different temporal prefix and must receive an isolated proof set.
'''
addition='''      // Task A and Memory A retain different original owner identities while
      // representing the same complete temporal predicate. The secondary
      // certificate must preserve actor, company, physical Tx and every set.
      const taskPrefix = await withReadPinnedNativeTaskSnapshot(tx, second.aliceActor, first.companyId,
        temporal.taskAId!, async () => {
          expect(await canActorReadNativeTaskSource(tx, { companyId: first.companyId,
            actor: second.aliceActor, issueId: temporal.taskAId! })).toBe(true);
          expect(activeMemoryTemporalReadScopePredicateIdentity(tx, second.bobActor, first.companyId)).toBeNull();
          expect(activeMemoryTemporalReadScopePredicateIdentity(db, second.aliceActor, first.companyId)).toBeNull();
          expect(activeMemoryTemporalReadScopePredicateIdentity(tx, second.aliceActor, randomUUID())).toBeNull();
          return { original: activeMemoryTemporalReadScopeIdentity(tx, second.aliceActor),
            predicate: activeMemoryTemporalReadScopePredicateIdentity(tx, second.aliceActor, first.companyId) };
        });
      const memoryPrefix = await withReadMemoryTemporalSources(tx, second.aliceActor, first.companyId, memoryAId!,
        async () => ({ original: activeMemoryTemporalReadScopeIdentity(tx, second.aliceActor),
          predicate: activeMemoryTemporalReadScopePredicateIdentity(tx, second.aliceActor, first.companyId) }));
      if (!memoryPrefix) throw new Error("The original Memory A temporal owner is unavailable");
      expect(taskPrefix.original).not.toBeNull();
      expect(taskPrefix.original).not.toBe(memoryPrefix.original);
      expect(taskPrefix.predicate).not.toBeNull();
      expect(taskPrefix.predicate).toBe(memoryPrefix.predicate);
      const laterPredicate = await withReadMemoryTemporalSources(tx, second.aliceActor, first.companyId, memoryCId!,
        async () => activeMemoryTemporalReadScopePredicateIdentity(tx, second.aliceActor, first.companyId));
      expect(laterPredicate).not.toBe(false);
      expect(laterPredicate).not.toBeNull();
      expect(laterPredicate).not.toBe(memoryPrefix.predicate);
      expect(activeMemoryTemporalReadScopePredicateIdentity(tx, second.aliceActor, first.companyId)).toBeNull();

      // Validate an actual retained request prefix through the public reader.
      // Its Task-first walk enters Task A before revisiting Memory A, so equal
      // complete predicates can reuse a completed structural checkpoint.
      const [retainedRun] = await tx.select({ profile: heartbeatRuns.runnerProfileJson }).from(heartbeatRuns)
        .where(and(eq(heartbeatRuns.companyId, first.companyId), eq(heartbeatRuns.id, first.runId)));
      const retainedProfile = retainedRun?.profile as Record<string, unknown> | undefined;
      const retainedPrefix = nativeRunInputSourceReceiptSchema.parse(retainedProfile?.nativeInputSourceReceipt).dispatches.at(-1);
      if (!retainedPrefix) throw new Error("The real Native request prefix disappeared");
      const predicateHits = nativeSourceMemoDiagnosticsForTest().equivalentPredicateHits;
      await expect(assertNativePayloadSourceSetCurrent(tx, { companyId: first.companyId, issueId: first.issueId,
        runId: first.runId, actor: second.aliceActor, policy: retainedPrefix.policy, inputs: retainedPrefix.inputs }))
        .resolves.toBeUndefined();
      expect(nativeSourceMemoDiagnosticsForTest().equivalentPredicateHits).toBeGreaterThan(predicateHits);

'''
assert s.count(needle)==1;s=s.replace(needle,addition+needle,1)
o=Path('/workspace/v10-preparation/native-predicate-certificate-r64-candidate');p=o/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
(o/'regression.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
m=json.loads((o/'manifest.json').read_text());m[rel]={'priorSha256':hashlib.sha256(a.encode()).hexdigest(),'candidateSha256':hashlib.sha256(s.encode()).hexdigest()};(o/'manifest.json').write_text(json.dumps(m,indent=2))
