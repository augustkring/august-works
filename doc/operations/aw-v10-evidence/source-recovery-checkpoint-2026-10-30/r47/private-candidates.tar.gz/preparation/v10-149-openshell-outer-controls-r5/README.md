# OpenShell RT-01/02 private outer-controls candidate (r5)

Status: private implementation candidate for Root review. R5 adds the single missing bridge fixture argument found by R4 server typecheck: it passes the policy's actual compiled CPU, memory, and PID values. R4 remains preserved with its test receipts and failed typecheck. No canonical source, dependency mirror, database, provider, host profile, capability flag, or release state was changed. Source baseline is current repository `HEAD`; `source-pins-r5.json` binds all candidate files to baseline and candidate SHA-256 values. `source.patch` is the portable byte-preserving source diff. The unchanged `deploy/v6/host-agent/journal.mjs` is included as an exact runtime dependency and is marked unchanged in the pins.

## Candidate behavior

The existing OpenShell bridge now carries the canonical V7 CPU (`cpuMillis`), memory (`memoryBytes`), and PID (`pidsLimit`) envelope. The host validates bounded integers, updates Docker by the observed 64-character container ID, re-inspects that same ID, and requires exact `HostConfig.NanoCpus`, `Memory`, `MemorySwap`, and `PidsLimit` before persisting a policy pin or reporting that policy effective. Start rechecks those values and refuses the name-scoped OpenShell start call if the resource observation drifted. Credential grant resolution carries the exact requested binary through the existing signed broker binding; compilation checks grant equality, single-profile separability, policy allowlisting and read-only path constraints. R4 fixes review findings in this chain: mixed binary sets beginning with `null` no longer reach path checks as `null`; signed broker-claim parsing requires and validates the binary field; and grant resolution no longer rejects every non-null binary. Regression cases cover null-first mixed compilation, a signed token with a non-null executable, and ToolGateway preserving that executable through grant resolution. The host compares the inspected provider profile hash and complete binary list at policy application, then compares the signed binding with that profile again at broker use.

No capability was enabled: the host's resource/credential dimensions remain false or empty and overall `controlsHealthy` remains false. Existing admission therefore remains fail-closed pending the required capability snapshot and probes. These changes do not turn name-scoped OpenShell CLI lifecycle operations into atomic ID-bound operations.

## Qualification receipt

R4 qualification receipts are preserved in `qualification-r4-reused/`. They show: host-agent 30/30; shared typecheck passed; agent-auth/policy tests 66 passed and 8 skipped because `AW_V7_OPENSHELL_PROVER` was unset; ToolGateway broker resolver test 1/1; V7 sandbox-host integration 13/13; server TSC found the missing helper argument at the Native-owned test fixture. R5 changes only that fixture plus no production sources. Root requested a fresh source snapshot/overlay and full server TSC for R5, with other unchanged test cohorts reused. Target-host qualification remains external and unclaimed.

## Remaining source and operational dependencies

- OpenShell v0.1.2 public lifecycle/policy operations are selected by sandbox name without an expected immutable sandbox-ID precondition. The separate private upstream API/CLI candidate must be reviewed, qualified, and integrated before any start/apply result may be treated as race-safe. The Docker-ID resource update is narrowly safe, but cannot make the subsequent name-scoped policy mutation atomic.
- This runtime does not expose an arbitrary per-workload seccomp/syscall profile or a workspace disk quota. `allowedSyscalls` and `diskBytes` remain unsupported unless an actual pinned upstream/host enforcement owner is added and inspected; no capability flag may claim them.
- Docker `update` behavior and all effective resource bounds still require a target-host probe on the exact Docker/OpenShell versions, including CPU, memory/swap, PID overrun, restart/drift, and same-name replacement races. This candidate's mocks do not establish physical enforcement.
- Binary filtering here only binds the existing credential provider endpoint. It does not prove a general process-execution allowlist. Broker grant freshness/revocation, raw-secret isolation, redirects/DNS/egress, and the complete RT-02 fault corpus remain subject to existing owners and host qualification. Model calls remain on the existing reservation/gateway path.

## Candidate source paths

Changed paths are exactly the entries with `changed: true` in `source-pins-r5.json`. `deploy/v6/host-agent/journal.mjs` is an unchanged included dependency. No commit or staging action was performed.
