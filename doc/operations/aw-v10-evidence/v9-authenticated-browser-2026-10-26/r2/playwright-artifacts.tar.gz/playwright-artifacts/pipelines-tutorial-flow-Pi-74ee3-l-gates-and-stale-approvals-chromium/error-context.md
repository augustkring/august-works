# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: pipelines-tutorial-flow.spec.ts >> Pipelines tutorial UI flow >> covers agent fan-out, drift acknowledgement gates, child-terminal gates, and stale approvals
- Location: tests/e2e/pipelines-tutorial-flow.spec.ts:281:3

# Error details

```
Error: get item detail failed: 404 {"error":"Pipeline case not found"}
```

# Test source

```ts
  1   | import { randomUUID } from "node:crypto";
  2   | import { expect, request as pwRequest, test, type APIRequestContext, type APIResponse, type Locator, type Page } from "@playwright/test";
  3   | import { createLocalAgentJwt } from "../../server/src/agent-auth-jwt";
  4   | 
  5   | const PORT = Number(process.env.PAPERCLIP_E2E_PORT ?? 3199);
  6   | const BASE_URL = `http://127.0.0.1:${PORT}`;
  7   | 
  8   | type Stage = { id: string; key: string; name: string; kind: string; position: number };
  9   | type PipelineDetail = {
  10  |   id: string;
  11  |   name: string;
  12  |   stages: Stage[];
  13  |   transitions: Array<{ fromStageId: string; toStageId: string }>;
  14  | };
  15  | type CaseSummary = {
  16  |   id: string;
  17  |   caseKey: string;
  18  |   title: string;
  19  |   version: number;
  20  |   stageId: string;
  21  |   parentCaseVersion?: number | null;
  22  |   requestKey?: string | null;
  23  |   childCount?: number;
  24  |   terminalChildCount?: number;
  25  | };
  26  | type CaseRow = { case: CaseSummary; stage?: Stage };
  27  | type CaseDetail = CaseRow & {
  28  |   pipeline: { id: string; key: string; name: string };
  29  |   blockers?: Array<{ caseId: string; blockedByCaseId: string }>;
  30  | };
  31  | 
  32  | async function expectOk(response: APIResponse, label: string) {
  33  |   if (!response.ok()) {
> 34  |     throw new Error(`${label} failed: ${response.status()} ${await response.text()}`);
      |           ^ Error: get item detail failed: 404 {"error":"Pipeline case not found"}
  35  |   }
  36  | }
  37  | 
  38  | async function expectError(response: APIResponse, label: string, status: number, code: string, message?: RegExp) {
  39  |   const body = await response.json() as { code?: string; error?: string; message?: string };
  40  |   expect(response.status(), `${label} status: ${JSON.stringify(body)}`).toBe(status);
  41  |   expect(body.code, `${label} code: ${JSON.stringify(body)}`).toBe(code);
  42  |   if (message) expect(body.error ?? body.message ?? "", `${label} message`).toMatch(message);
  43  | }
  44  | 
  45  | async function createCompany(board: APIRequestContext) {
  46  |   const response = await board.post("/api/companies", {
  47  |     data: { name: `E2E Pipelines ${Date.now()}` },
  48  |   });
  49  |   await expectOk(response, "create company");
  50  |   return response.json() as Promise<{ id: string; issuePrefix: string }>;
  51  | }
  52  | 
  53  | async function createCompanyAgent(
  54  |   board: APIRequestContext,
  55  |   companyId: string,
  56  |   input: { name: string; role: string; title?: string; capabilities?: string },
  57  | ) {
  58  |   const response = await board.post(`/api/companies/${companyId}/agents`, {
  59  |     data: {
  60  |       name: input.name,
  61  |       role: input.role,
  62  |       title: input.title,
  63  |       capabilities: input.capabilities,
  64  |       adapterType: "process",
  65  |       adapterConfig: { command: process.execPath, args: ["-e", "process.stdout.write('ok\\n')"] },
  66  |     },
  67  |   });
  68  |   await expectOk(response, `create ${input.name}`);
  69  |   return response.json() as Promise<{ id: string }>;
  70  | }
  71  | 
  72  | async function createPipelineWriterAgentKey(board: APIRequestContext, companyId: string) {
  73  |   await createCompanyAgent(board, companyId, {
  74  |     name: "Pipeline CEO",
  75  |     role: "ceo",
  76  |     title: "CEO",
  77  |     capabilities: "Approves agent join requests during e2e setup.",
  78  |   });
  79  | 
  80  |   const inviteResponse = await board.post(`/api/companies/${companyId}/invites`, {
  81  |     data: {
  82  |       allowedJoinTypes: "agent",
  83  |       defaultsPayload: {
  84  |         agent: {
  85  |           grants: [
  86  |             { permissionKey: "pipelines:write", scope: null },
  87  |           ],
  88  |         },
  89  |       },
  90  |     },
  91  |   });
  92  |   await expectOk(inviteResponse, "create pipeline-writer invite");
  93  |   const invite = await inviteResponse.json() as { token: string };
  94  | 
  95  |   const acceptResponse = await board.post(`/api/invites/${invite.token}/accept`, {
  96  |     data: {
  97  |       requestType: "agent",
  98  |       agentName: "Pipeline Fanout Agent",
  99  |       adapterType: "process",
  100 |       capabilities: "Creates pipeline child work during e2e coverage.",
  101 |     },
  102 |   });
  103 |   await expectOk(acceptResponse, "accept pipeline-writer invite");
  104 |   const accepted = await acceptResponse.json() as { id: string };
  105 | 
  106 |   const approveResponse = await board.post(`/api/companies/${companyId}/join-requests/${accepted.id}/approve`);
  107 |   await expectOk(approveResponse, "approve pipeline-writer join");
  108 |   const approved = await approveResponse.json() as { createdAgentId: string };
  109 | 
  110 |   const runId = randomUUID();
  111 |   const token = createLocalAgentJwt(approved.createdAgentId, companyId, "process", runId);
  112 |   if (!token) throw new Error("PAPERCLIP_AGENT_JWT_SECRET is required for pipeline writer JWT setup");
  113 |   return { agentId: approved.createdAgentId, runId, token };
  114 | }
  115 | 
  116 | async function createPipeline(board: APIRequestContext, companyId: string) {
  117 |   const response = await board.post(`/api/companies/${companyId}/pipelines`, {
  118 |     data: {
  119 |       key: "content-production",
  120 |       name: "Content production",
  121 |       description: "Draft, review, and publish launch content.",
  122 |       enforceTransitions: true,
  123 |       stages: [
  124 |         { key: "drafting", name: "Drafting", kind: "working", position: 0, config: { variables: [] } },
  125 |         { key: "published", name: "Published", kind: "done", position: 2, config: { variables: [] } },
  126 |         { key: "dropped", name: "Dropped", kind: "cancelled", position: 3, config: { variables: [] } },
  127 |       ],
  128 |     },
  129 |   });
  130 |   await expectOk(response, "create pipeline");
  131 |   return response.json() as Promise<{ id: string; name: string }>;
  132 | }
  133 | 
  134 | async function createPrimitivePipeline(board: APIRequestContext, companyId: string) {
```