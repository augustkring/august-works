# Native-turn private Project design

**Status:** source-backed proposal for review; no production files changed. The Codex/private-project route stays fail-closed until the Native-turn prefix proof below is implemented and qualified.

## Decision

The current Native input receipt and dispatch association are reusable foundations, but they are not a complete private Project output proof. A Codex path must not be admitted from `projectToolContext`, a run JWT, or the existing call association alone. The existing `retained_run` source kind is only valid for a previous terminal run with a resume witness; it cannot represent the active producer run.

Support should use a distinct `native_turn` arm in the server-only Project output capture. It carries no OpenCode reservation, wire response hash, or `managedOpenCodeToolUse`. The OpenCode arm and its validator remain strict and unchanged. If the Native backend cannot provide an exact ordered prefix of earlier results returned to the model for this call, the Native-turn arm is not admissible and Codex private Project creation remains unavailable.

## Existing proof available

`recordNativeModelInputDispatchIntent` records the active Native dispatch identity and source closure in the current run receipt when the turn frame matches (`server/src/services/native-runtime/native-session-executor.ts:7529–7685, 7860–8003`). `recordNativeModelInputDispatchAcknowledgement` binds the actual Native turn ID to that dispatch and receipt (`:8090–8144`). `recordNativeToolCallDispatchAssociation` binds a backend-authenticated call ID, turn ID, tool name, argument hash, dispatch, launch event, and attempt (`:8197–8258`); `resolveNativeInputDispatchReceiptIdentity` checks the unique association (`server/src/services/native-runtime/paperclip-runner-tool-authority.ts:366–399`). These records provide an honest provider-neutral Native call identity without a broker reservation.

The current result ledger is incomplete for this purpose. `recordNativeInputToolResultIntent` accepts only four read tools and only adds a receipt input when its source set is qualified (`native-session-executor.ts:9085–9209`). Project GET capture stores a digest and call identity but explicitly does not prove provider consumption or complete closure (`:8967–9053, 9218–9249`). `assertNativeRunReadSourceHistoryQualified` validates only the four named read tools (`:6490–6519`). It does not prove that every earlier tool result was retained or source-qualified.

`nativeRetainedRunResumeWitness` (`server/src/services/native-runtime/native-session-resume.ts:271–352`) requires a terminal prior Native run, same session/provider/workspace/tool fingerprint, same accountable Human and conversation generation, valid checkpoint and source receipt. The `retained_run` validator uses that witness (`server/src/services/native-direct-input.ts:2107–2138`). Keep this for prior-run history only.

## Proposed capture contract

Add a discriminated server-only capture union in `server/src/services/native-runtime/native-execution-input.ts`:

- `managed_opencode`: preserve the existing exact provider-use capture and all reservation, response-hash, manifest, source-component, and managed-tool checks.
- `native_turn`: include the current run ID; exact acknowledged dispatch ID/event sequence/attempt/turn ID/input digest; exact call ID/tool/argument hash; accountable Human ID; a digest of the current run input-source receipt; and an ordered list of the qualified tool-result receipt identities that precede this call. The server constructs this object from retained Native records. Do not include fabricated model reservation IDs or provider-response hashes.

The `native_turn` validator must reconstruct the source prefix from the bound current-run receipt and earlier qualified Native result receipts, validate their order and exact result hashes, and recheck every source owner and current actor ACL under the existing Native source/privacy transaction. Prior completed-run sources may appear as `retained_run` only after the existing resume-witness check. Unknown, missing, duplicate, reordered, over-budget, or source-unqualified earlier results deny the current Project output.

Every Native tool result returned to the model needs a bounded ledger record, including call/turn/dispatch identity, argument hash, exact result digest, result order, accountable Human, and either its complete current source proof or an explicit unqualified disposition. Before a private Project effect, the owner must establish that all earlier results in the exact model-visible prefix have qualified provenance. The four-read whitelist is insufficient. If the backend cannot identify which ordered results were returned before this call, fail closed; do not treat array insertion order or a `turnId` alone as proof of model-visible order.

## One creation owner for both Native entry points

Normalize dedicated `create_project` and `call_api` POST to the same server-owned project command and domain owner. The dedicated tool currently goes through `callProjectTool` (`server/src/services/native-runtime/paperclip-runner-tool-authority.ts:821–859`; `server/src/services/project-tools.ts:18–50`). Direct `call_api` currently has a signed `NativeToolEffectClaim` for the exact API method/path/body (`paperclip-runner-tool-authority.ts:1125–1169`), but `routes/projects.ts` does not consume that claim. Add a distinct, strict effect identity for both Native entry points; do not let either HTTP body carry a capture.

The shared owner should be factored from `server/src/services/native-project-output.ts` and accept one of the two capture variants. In a single transaction it must:

1. Lock the current issue/privacy tree and Native run; renew/recheck the execution lease and current accountable Human; revalidate the exact Native dispatch/call/arguments and source prefix.
2. Require the current task-bound `projectToolContext(..., true)`, exact current Agent/conversation binding and session generation, `standard` or `skill_test` mode, current Agent issue-read ACL, current Human membership, and current Human project ownership. For private source, admit only the exact current authorized conversation path; unrelated private tasks remain denied.
3. Force the output Project private, retain source issue IDs and qualified source provenance, attach only the authorized Agent and accountable Human, retain workspace/repository validation, and recheck current source owners under the existing ACL locks.
4. Write the Project, workspaces, activity/idempotency receipt, immutable source snapshot, exact returned result digest, and Native result/source receipt atomically. Replay with the same call/arguments/source prefix returns the same result without duplicate rows; changed input conflicts.

The ordinary route retains its current private-source denial. It can delegate only when the strict server-signed Native effect identity resolves to a current server-owned capture and the shared owner accepts that capture. No caller-supplied visibility, task ID, Human ID, source set, sequence, or receipt can create this exception.

## Current feasibility gate

The Native-turn path is **not yet proven feasible end to end**. Existing call association contains the acknowledged input-turn identity, but the current generic result capture does not prove a complete ordered result prefix. The input-frame matcher rejects continuation frames (`native-session-executor.ts:7534`), and the existing server-owned result-prefix/response-hash proof is specific to managed model-wire intents (`native-direct-input.ts:1321–1417`). Before implementation, verify that the Codex Native backend exposes a server-authenticated ordering/boundary for each tool-result return and the exact next model-visible source prefix. If it does not, stop the Native-turn implementation at the fail-closed capability boundary and qualify the positive private Project browser journey only through the already-qualified managed OpenCode owner.

## Required focused regressions

- Positive Native-turn case: exact acknowledged call and ordered, source-qualified prior results create one private Project; the next Native turn receives the exact retained result/source; current Human can read it and an unauthorized same-company reader cannot.
- OpenCode parity: existing managed OpenCode create/receipt tests pass with their current broker/response checks intact.
- Dedicated-tool and direct `call_api` POST parity: both reach the same owner, produce the same receipt contract, and neither can invoke a private route exception without a valid server-owned capture.
- Fail closed for missing or invalid input-source receipt/digest, missing dispatch acknowledgement, wrong run/issue/company/Human/generation, stale lease/controller, wrong tool/call/arguments/path/body hash, forged or duplicate call/result identity, absent/ambiguous/reordered/unqualified earlier result, altered result digest/DTO/source snapshot/workspace, changed source ACL while waiting, and current-run/private-source mismatch.
- Atomicity/idempotency: every failed receipt/source check leaves no Project, workspace, source snapshot, activity, or success receipt; exact replay adds none; changed arguments or source prefix conflicts.

Do not alter the concurrent Temporal authorization memo or Native conversation-root/upload work while implementing this proposal. No browser fixture changes are included; root owns those.
