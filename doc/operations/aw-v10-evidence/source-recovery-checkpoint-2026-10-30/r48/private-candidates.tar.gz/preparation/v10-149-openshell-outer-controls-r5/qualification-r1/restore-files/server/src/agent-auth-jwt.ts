import { createHmac, timingSafeEqual } from "node:crypto";
import { normalizeAgentApiKeyScope, type AgentApiKeyScope } from "@paperclipai/shared";
import { resolvePaperclipInstanceId } from "./home-paths.js";

interface JwtHeader {
  alg: string;
  typ?: string;
}

export interface LocalAgentJwtClaims {
  sub: string;
  company_id: string;
  adapter_type: string;
  run_id: string;
  responsible_user_id?: string | null;
  key_scope?: AgentApiKeyScope | null;
  /** Server-minted, one HTTP effect binding for an authenticated native tool call. */
  native_tool_effect?: NativeToolEffectClaim;
  /** Dedicated non-API capability audiences. */
  purpose?: "sandbox_exec" | "sandbox_broker";
  sandbox_exec?: SandboxExecCapabilityClaim;
  sandbox_broker?: SandboxBrokerCapabilityClaim;
  iat: number;
  exp: number;
  iss?: string;
  aud?: string;
  instance_id?: string;
  jti?: string;
}

export interface SandboxExecCapabilityClaim {
  requestId: string;
  bindingId: string;
  cellId: string;
  generation: string;
  hostId: string;
  hostEpoch: number;
  runId: string;
  attemptId: string | null;
  attempt: number;
  manifestId: string;
  manifestHash: string;
  policySnapshotId: string;
  policyHash: string;
  commandDigest: string;
  deadlineAt: string;
}

export interface SandboxBrokerCapabilityClaim {
  parentRequestId: string;
  bindingId: string;
  cellId: string;
  generation: string;
  hostId: string;
  hostEpoch: number;
  runId: string;
  attemptId: string | null;
  attempt: number;
  manifestId: string;
  manifestHash: string;
  policySnapshotId: string;
  policyHash: string;
  brokerSessionId: string;
  endpointOrigin: string;
  bindings: SandboxBrokerBindingClaim[];
  expiresAt: string;
}

export interface SandboxBrokerBindingClaim {
  connectionId: string;
  grantVersionHash: string;
  gatewayPublicId: string;
  endpointPath: string;
  allowedTools: string[];
  destination: {
    hostname: string;
    port: number;
    method: "POST";
    path: string;
  };
}

export interface NativeToolEffectClaim {
  dispatchId: string;
  eventSeq: number;
  attempt: number;
  turnId: string;
  callId: string;
  tool: "call_api";
  operationId: string;
  method: string;
  pathAndQuery: string;
  bodyPresent: boolean;
  bodyHash: string;
  apiReceiptDigest: string;
  leaseOwner: string;
  leaseExpiresAt: string;
  controllerBootId: string;
  controllerPid: number;
  controllerProcessStartedAt: string;
}

const JWT_ALGORITHM = "HS256";

function parseNumber(value: string | undefined, fallback: number) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed <= 0) return fallback;
  return Math.floor(parsed);
}

function parseBooleanEnv(value: string | undefined): boolean {
  if (!value) return false;
  const normalized = value.trim().toLowerCase();
  return normalized === "1" || normalized === "true" || normalized === "yes" || normalized === "on";
}

function jwtConfig() {
  const secret = process.env.PAPERCLIP_AGENT_JWT_SECRET?.trim() || process.env.BETTER_AUTH_SECRET?.trim();
  if (!secret) return null;

  return {
    secret,
    // 48h default, matching DEFAULT_AGENT_JWT_TTL_SECONDS in cli/src/commands/env.ts
    // and the agent-authentication design doc. Run tokens are minted once at
    // adapter spawn and injected as env, so the TTL must cover the entire run —
    // including host-suspension gaps: heartbeats scheduled while a laptop lid is
    // closed fire during ~2s dark wakes, and the spawned session can then sit
    // frozen for over an hour before it first executes.
    ttlSeconds: parseNumber(process.env.PAPERCLIP_AGENT_JWT_TTL_SECONDS, 60 * 60 * 48),
    issuer: process.env.PAPERCLIP_AGENT_JWT_ISSUER ?? "paperclip",
    audience: process.env.PAPERCLIP_AGENT_JWT_AUDIENCE ?? "paperclip-api",
    // The control-plane instance this process belongs to. The live plane runs as
    // "default"; every worktree/fork instance gets a distinct id (its worktree
    // name) even though it deliberately shares PAPERCLIP_AGENT_JWT_SECRET with
    // the source instance. Folding this into the signing-key derivation is what
    // prevents a fork-minted token from authenticating against the live plane.
    instanceId: resolvePaperclipInstanceId(),
    disableLegacyFallback: parseBooleanEnv(process.env.PAPERCLIP_AGENT_JWT_DISABLE_LEGACY_FALLBACK),
  };
}

/**
 * Derive a per-instance, per-company signing key from the master JWT secret,
 * the control-plane instanceId, and a companyId.
 *
 * Two isolation properties fall out of this derivation:
 *  - Per-company: a JWT signed for company A cannot be reused to authenticate
 *    as an agent in company B, even if the raw token leaks.
 *  - Per-instance: a JWT minted by a worktree/fork control-plane instance
 *    cannot authenticate against the live plane, even though forks
 *    deliberately share the same master secret (it is copied into worktree
 *    envs by provisioning). The live plane derives its key from its own
 *    instanceId ("default"), so a fork token — signed under the fork's
 *    instanceId — never matches. See PAP-12896 for the incident this closes.
 *
 * The instance-wide master secret is never used to sign new tokens — it is
 * retained only as a verification fallback so that tokens issued before this
 * change continue to validate. NOTE: that legacy fallback is instance-agnostic
 * (it signs with the raw shared secret), so complete cryptographic instance
 * isolation additionally requires disabling it once outstanding legacy tokens
 * have expired (set PAPERCLIP_AGENT_JWT_DISABLE_LEGACY_FALLBACK=true). Normal
 * fork-minted run tokens are already rejected without that step because they
 * are signed with the derived key, not the raw master secret.
 *
 * The derivation domain-separates with the `jwt:` prefix so the same master
 * secret can safely be reused for other HMAC purposes without key reuse.
 */
function deriveCompanySigningKey(masterSecret: string, companyId: string, instanceId: string): string {
  return createHmac("sha256", masterSecret).update(`jwt:${instanceId}:${companyId}`).digest("hex");
}

function base64UrlEncode(value: string) {
  return Buffer.from(value, "utf8").toString("base64url");
}

function base64UrlDecode(value: string) {
  return Buffer.from(value, "base64url").toString("utf8");
}

function signPayload(secret: string, signingInput: string) {
  return createHmac("sha256", secret).update(signingInput).digest("base64url");
}

function parseJson(value: string): Record<string, unknown> | null {
  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === "object" ? parsed as Record<string, unknown> : null;
  } catch {
    return null;
  }
}

function safeCompare(a: string, b: string) {
  const left = Buffer.from(a);
  const right = Buffer.from(b);
  if (left.length !== right.length) return false;
  return timingSafeEqual(left, right);
}

export function createLocalAgentJwt(
  agentId: string,
  companyId: string,
  adapterType: string,
  runId: string,
  responsibleUserId?: string | null,
  keyScope: AgentApiKeyScope = { kind: "standard" },
  nativeToolEffect?: NativeToolEffectClaim,
) {
  const config = jwtConfig();
  if (!config) return null;

  const now = Math.floor(Date.now() / 1000);
  const parsedNativeToolEffect = nativeToolEffect ? parseNativeToolEffectClaim(nativeToolEffect) : null;
  if (nativeToolEffect && !parsedNativeToolEffect) return null;
  const exp = Math.min(now + config.ttlSeconds, parsedNativeToolEffect
    ? Math.floor(Date.parse(parsedNativeToolEffect.leaseExpiresAt) / 1000) : Number.MAX_SAFE_INTEGER);
  if (exp <= now) return null;
  const claims: LocalAgentJwtClaims = {
    sub: agentId,
    company_id: companyId,
    adapter_type: adapterType,
    run_id: runId,
    responsible_user_id: responsibleUserId?.trim() || null,
    ...(keyScope.kind === "standard" ? {} : { key_scope: keyScope }),
    ...(parsedNativeToolEffect ? { native_tool_effect: parsedNativeToolEffect } : {}),
    iat: now,
    exp,
    iss: config.issuer,
    aud: config.audience,
    instance_id: config.instanceId,
  };

  const header = {
    alg: JWT_ALGORITHM,
    typ: "JWT",
  };

  const signingInput = `${base64UrlEncode(JSON.stringify(header))}.${base64UrlEncode(JSON.stringify(claims))}`;
  // Sign with the per-instance, per-company derived key so a leaked token
  // cannot be reused across tenants and a fork-minted token cannot authenticate
  // against a different control-plane instance.
  const signingKey = deriveCompanySigningKey(config.secret, companyId, config.instanceId);
  const signature = signPayload(signingKey, signingInput);

  return `${signingInput}.${signature}`;
}

/** Mint only after the durable sandbox exec claim exists and all current run,
 * host, manifest and policy owners have been rechecked. */
export function createSandboxExecJwt(input: {
  agentId: string;
  companyId: string;
  adapterType: string;
  runId: string;
  responsibleUserId: string | null;
  claim: SandboxExecCapabilityClaim;
  parentExpiresAt: Date;
  nativeLeaseExpiresAt: Date;
}) {
  const config = jwtConfig();
  const diagnosticFailure = (reason: string) => {
    if (process.env.PAPERCLIP_MANAGED_OPENCODE_E2E_DIAGNOSTICS !== "1") return;
    const invalidFields: string[] = [];
    if (reason === "claim_invalid") {
      const claim = input.claim as unknown as Record<string, unknown>;
      const keys = ["requestId", "bindingId", "cellId", "generation", "hostId", "hostEpoch", "runId", "attemptId", "attempt", "manifestId", "manifestHash", "policySnapshotId", "policyHash", "commandDigest", "deadlineAt"];
      const uuid = /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i;
      const digest = /^[a-f0-9]{64}$/;
      if (Object.keys(claim).length !== keys.length || keys.some(key => !Object.hasOwn(claim, key))) invalidFields.push("claim_fields");
      for (const key of ["requestId", "bindingId", "cellId", "hostId", "runId", "manifestId", "policySnapshotId"])
        if (typeof claim[key] !== "string" || !uuid.test(claim[key] as string)) invalidFields.push(key);
      if (!(claim.attemptId === null || typeof claim.attemptId === "string" && uuid.test(claim.attemptId))) invalidFields.push("attemptId");
      if (!Number.isSafeInteger(claim.attempt) || (claim.attempt as number) < 1) invalidFields.push("attempt");
      if (typeof claim.generation !== "string" || !/^[1-9][0-9]{0,18}$/.test(claim.generation)) invalidFields.push("generation");
      if (!Number.isSafeInteger(claim.hostEpoch) || (claim.hostEpoch as number) < 1) invalidFields.push("hostEpoch");
      for (const key of ["manifestHash", "policyHash", "commandDigest"])
        if (typeof claim[key] !== "string" || !digest.test(claim[key] as string)) invalidFields.push(key);
      if (typeof claim.deadlineAt !== "string" || !Number.isFinite(Date.parse(claim.deadlineAt))) invalidFields.push("deadlineAt");
    }
    console.info("sandbox exec capability mint failure", JSON.stringify({ requestId: input.claim.requestId, reason, invalidFields }));
  };
  if (!config) { diagnosticFailure("jwt_config_unavailable"); return null; }
  if (!parseSandboxExecCapabilityClaim(input.claim)) { diagnosticFailure("claim_invalid"); return null; }
  const now = Math.floor(Date.now() / 1000);
  const deadlineAt = Date.parse(input.claim.deadlineAt);
  const exp = Math.min(
    now + 60,
    Math.floor(input.parentExpiresAt.getTime() / 1000),
    Math.floor(input.nativeLeaseExpiresAt.getTime() / 1000),
    Math.floor(deadlineAt / 1000),
  );
  if (exp <= now) { diagnosticFailure("capability_expired_before_mint"); return null; }
  const claims: LocalAgentJwtClaims = {
    sub: input.agentId,
    company_id: input.companyId,
    adapter_type: input.adapterType,
    run_id: input.runId,
    responsible_user_id: input.responsibleUserId,
    purpose: "sandbox_exec",
    sandbox_exec: input.claim,
    iat: now,
    exp,
    iss: config.issuer,
    aud: "paperclip-sandbox-exec",
    instance_id: config.instanceId,
    jti: input.claim.requestId,
  };
  const signingInput = `${base64UrlEncode(JSON.stringify({ alg: JWT_ALGORITHM, typ: "JWT" }))}.${base64UrlEncode(JSON.stringify(claims))}`;
  return `${signingInput}.${signPayload(deriveCompanySigningKey(config.secret, input.companyId, config.instanceId), signingInput)}`;
}

/** A per-exec attenuated capability for assigned ToolGateway operations. */
export function createSandboxBrokerJwt(input: {
  agentId: string;
  companyId: string;
  adapterType: string;
  runId: string;
  responsibleUserId: string | null;
  claim: SandboxBrokerCapabilityClaim;
  parentExpiresAt: Date;
  nativeLeaseExpiresAt: Date;
  execDeadlineAt: Date;
}) {
  const config = jwtConfig();
  if (!config || !parseSandboxBrokerCapabilityClaim(input.claim)) return null;
  const now = Math.floor(Date.now() / 1000);
  const exp = Math.min(
    now + 60,
    Math.floor(input.parentExpiresAt.getTime() / 1000),
    Math.floor(input.nativeLeaseExpiresAt.getTime() / 1000),
    Math.floor(input.execDeadlineAt.getTime() / 1000),
    Math.floor(Date.parse(input.claim.expiresAt) / 1000),
  );
  if (exp <= now) return null;
  const claims: LocalAgentJwtClaims = {
    sub: input.agentId,
    company_id: input.companyId,
    adapter_type: input.adapterType,
    run_id: input.runId,
    responsible_user_id: input.responsibleUserId,
    purpose: "sandbox_broker",
    sandbox_broker: input.claim,
    iat: now,
    exp,
    iss: config.issuer,
    aud: "paperclip-sandbox-broker",
    instance_id: config.instanceId,
    jti: input.claim.parentRequestId,
  };
  const signingInput = `${base64UrlEncode(JSON.stringify({ alg: JWT_ALGORITHM, typ: "JWT" }))}.${base64UrlEncode(JSON.stringify(claims))}`;
  return `${signingInput}.${signPayload(deriveCompanySigningKey(config.secret, input.companyId, config.instanceId), signingInput)}`;
}

function verifySignedLocalAgentJwt(token: string): LocalAgentJwtClaims | null {
  if (!token) return null;
  const config = jwtConfig();
  if (!config) return null;

  const parts = token.split(".");
  if (parts.length !== 3) return null;
  const [headerB64, claimsB64, signature] = parts;

  const header = parseJson(base64UrlDecode(headerB64));
  if (!header || header.alg !== JWT_ALGORITHM) return null;

  const claims = parseJson(base64UrlDecode(claimsB64));
  if (!claims) return null;
  const hasSandboxExec = Object.hasOwn(claims, "sandbox_exec");
  const hasSandboxBroker = Object.hasOwn(claims, "sandbox_broker");
  if ((Object.hasOwn(claims, "purpose") && !["sandbox_exec", "sandbox_broker"].includes(String(claims.purpose))) ||
    (hasSandboxExec && (claims.purpose !== "sandbox_exec" || hasSandboxBroker)) ||
    (hasSandboxBroker && (claims.purpose !== "sandbox_broker" || hasSandboxExec)) ||
    (claims.purpose === "sandbox_exec" && !hasSandboxExec) ||
    (claims.purpose === "sandbox_broker" && !hasSandboxBroker)) return null;

  const claimedCompanyId = typeof claims.company_id === "string" ? claims.company_id : null;
  if (!claimedCompanyId) return null;
  const dedicatedPurpose = claims.purpose === "sandbox_exec" || claims.purpose === "sandbox_broker";
  if (dedicatedPurpose && (claims.iss !== config.issuer || claims.instance_id !== config.instanceId ||
    claims.aud !== (claims.purpose === "sandbox_exec" ? "paperclip-sandbox-exec" : "paperclip-sandbox-broker") ||
    !Number.isSafeInteger(claims.iat) || !Number.isSafeInteger(claims.exp) ||
    (claims.exp as number) <= (claims.iat as number) || (claims.exp as number) - (claims.iat as number) > 60)) return null;

  const signingInput = `${headerB64}.${claimsB64}`;
  // Try the per-instance, per-company derived key first (current tokens),
  // deriving under THIS control plane's own instanceId. A token minted by a
  // worktree/fork instance was signed under a different instanceId, so it will
  // not match here — that is the boundary that keeps fork tokens out of the
  // live plane (PAP-12896/PAP-12899). Fall back to the raw master secret so
  // tokens issued before per-company derivation existed continue to verify —
  // this preserves backward compatibility for any outstanding tokens (TTL
  // bounds the legacy window naturally).
  //
  // Operators should set `PAPERCLIP_AGENT_JWT_DISABLE_LEGACY_FALLBACK=true`
  // approximately one JWT TTL (~48h by default, see PAPERCLIP_AGENT_JWT_TTL_SECONDS)
  // after deploying per-company signing. Once set, the master-secret fallback
  // is disabled and only tokens validating under the per-instance/per-company
  // derived key are accepted — closing the window in which a leaked master
  // secret could be used to forge tokens with arbitrary future `exp` values for
  // any tenant, and completing cryptographic isolation between control-plane
  // instances (the raw-secret fallback is instance-agnostic).
  const perCompanyKey = deriveCompanySigningKey(config.secret, claimedCompanyId, config.instanceId);
  const perCompanySig = signPayload(perCompanyKey, signingInput);
  let signatureOk = safeCompare(signature, perCompanySig);
  if (!signatureOk && !dedicatedPurpose && !config.disableLegacyFallback) {
    const legacySig = signPayload(config.secret, signingInput);
    signatureOk = safeCompare(signature, legacySig);
  }
  if (!signatureOk) return null;

  const sub = typeof claims.sub === "string" ? claims.sub : null;
  const adapterType = typeof claims.adapter_type === "string" ? claims.adapter_type : null;
  const runId = typeof claims.run_id === "string" ? claims.run_id : null;
  const responsibleUserClaim = Object.hasOwn(claims, "responsible_user_id")
    ? typeof claims.responsible_user_id === "string" && claims.responsible_user_id.trim()
      ? claims.responsible_user_id.trim()
      : null
    : undefined;
  const keyScopeClaim = Object.hasOwn(claims, "key_scope")
    ? normalizeAgentApiKeyScope(claims.key_scope)
    : undefined;
  if (keyScopeClaim === null) return null;
  const nativeToolEffect = parseNativeToolEffectClaim(claims.native_tool_effect);
  if (Object.hasOwn(claims, "native_tool_effect") && !nativeToolEffect) return null;
  const iat = typeof claims.iat === "number" ? claims.iat : null;
  const exp = typeof claims.exp === "number" ? claims.exp : null;
  if (!sub || !adapterType || !runId || !iat || !exp) return null;
  const companyId = claimedCompanyId;

  const now = Math.floor(Date.now() / 1000);
  if (exp <= now || (dedicatedPurpose && iat! > now)) return null;

  const issuer = typeof claims.iss === "string" ? claims.iss : undefined;
  const audience = typeof claims.aud === "string" ? claims.aud : undefined;
  if (issuer && issuer !== config.issuer) return null;
  if (audience && audience !== config.audience &&
    !(claims.purpose === "sandbox_exec" && audience === "paperclip-sandbox-exec") &&
    !(claims.purpose === "sandbox_broker" && audience === "paperclip-sandbox-broker")) return null;

  // Enforce the minting instance when the claim is present. The instance-scoped
  // signing key above is the real cryptographic boundary; this claim check is
  // defense-in-depth that yields a clean, cheap rejection (and, once legacy
  // tokens have aged out, guards the master-secret fallback path too). Legacy
  // tokens minted before this claim existed omit it and are still accepted, so
  // enforcement is conditional — matching how iss/aud are handled above.
  const instanceClaim = typeof claims.instance_id === "string" ? claims.instance_id : undefined;
  if (instanceClaim && instanceClaim !== config.instanceId) return null;

  return {
    sub,
    company_id: companyId,
    adapter_type: adapterType,
    run_id: runId,
    ...(responsibleUserClaim !== undefined ? { responsible_user_id: responsibleUserClaim } : {}),
    ...(keyScopeClaim !== undefined ? { key_scope: keyScopeClaim } : {}),
    ...(nativeToolEffect ? { native_tool_effect: nativeToolEffect } : {}),
    ...(claims.purpose === "sandbox_exec" ? { purpose: "sandbox_exec" as const } : {}),
    ...(claims.purpose === "sandbox_broker" ? { purpose: "sandbox_broker" as const } : {}),
    ...(hasSandboxExec ? { sandbox_exec: parseSandboxExecCapabilityClaim(claims.sandbox_exec) ?? undefined } : {}),
    ...(hasSandboxBroker ? { sandbox_broker: parseSandboxBrokerCapabilityClaim(claims.sandbox_broker) ?? undefined } : {}),
    iat,
    exp,
    ...(issuer ? { iss: issuer } : {}),
    ...(audience ? { aud: audience } : {}),
    ...(instanceClaim ? { instance_id: instanceClaim } : {}),
    jti: typeof claims.jti === "string" ? claims.jti : undefined,
  };
}

/** Ordinary API authentication must never accept an execution-only JWT. */
export function verifyLocalAgentJwt(token: string): LocalAgentJwtClaims | null {
  const claims = verifySignedLocalAgentJwt(token);
  return claims && !claims.purpose && !claims.sandbox_exec && !claims.sandbox_broker ? claims : null;
}

export function verifySandboxExecJwt(token: string): LocalAgentJwtClaims & {
  purpose: "sandbox_exec";
  sandbox_exec: SandboxExecCapabilityClaim;
} | null {
  const claims = verifySignedLocalAgentJwt(token);
  if (!claims || claims.purpose !== "sandbox_exec" || !claims.sandbox_exec || claims.sandbox_broker || claims.aud !== "paperclip-sandbox-exec") return null;
  return claims as LocalAgentJwtClaims & { purpose: "sandbox_exec"; sandbox_exec: SandboxExecCapabilityClaim };
}

export function verifySandboxBrokerJwt(token: string): LocalAgentJwtClaims & {
  purpose: "sandbox_broker";
  sandbox_broker: SandboxBrokerCapabilityClaim;
} | null {
  const claims = verifySignedLocalAgentJwt(token);
  if (!claims || claims.purpose !== "sandbox_broker" || !claims.sandbox_broker || claims.sandbox_exec || claims.aud !== "paperclip-sandbox-broker") return null;
  return claims as LocalAgentJwtClaims & { purpose: "sandbox_broker"; sandbox_broker: SandboxBrokerCapabilityClaim };
}

function parseSandboxExecCapabilityClaim(value: unknown): SandboxExecCapabilityClaim | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const claim = value as Record<string, unknown>;
  const keys = ["requestId", "bindingId", "cellId", "generation", "hostId", "hostEpoch", "runId", "attemptId", "attempt", "manifestId", "manifestHash", "policySnapshotId", "policyHash", "commandDigest", "deadlineAt"];
  const uuid = /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i;
  const digest = /^[a-f0-9]{64}$/;
  if (Object.keys(claim).length !== keys.length || keys.some(key => !Object.hasOwn(claim, key)) ||
    !["requestId", "bindingId", "cellId", "hostId", "runId", "manifestId", "policySnapshotId"].every(key => typeof claim[key] === "string" && uuid.test(claim[key] as string)) ||
    !(claim.attemptId === null || typeof claim.attemptId === "string" && uuid.test(claim.attemptId)) ||
    !Number.isSafeInteger(claim.attempt) || (claim.attempt as number) < 1 ||
    typeof claim.generation !== "string" || !/^[1-9][0-9]{0,18}$/.test(claim.generation) ||
    !Number.isSafeInteger(claim.hostEpoch) || (claim.hostEpoch as number) < 1 ||
    !["manifestHash", "policyHash", "commandDigest"].every(key => typeof claim[key] === "string" && digest.test(claim[key] as string)) ||
    typeof claim.deadlineAt !== "string" || !Number.isFinite(Date.parse(claim.deadlineAt))) return null;
  return claim as unknown as SandboxExecCapabilityClaim;
}

function parseSandboxBrokerCapabilityClaim(value: unknown): SandboxBrokerCapabilityClaim | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const claim = value as Record<string, unknown>;
  const keys = ["parentRequestId", "bindingId", "cellId", "generation", "hostId", "hostEpoch", "runId", "attemptId", "attempt", "manifestId", "manifestHash", "policySnapshotId", "policyHash", "brokerSessionId", "endpointOrigin", "bindings", "expiresAt"];
  const uuid = /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i;
  const digest = /^[a-f0-9]{64}$/;
  let endpoint: URL | null = null;
  try { endpoint = new URL(String(claim.endpointOrigin)); } catch { /* closed below */ }
  const bindings = Array.isArray(claim.bindings) ? claim.bindings as unknown[] : [];
  const bindingsValid = bindings.length >= 1 && bindings.length <= 32 && bindings.every(value => {
    if (!value || typeof value !== "object" || Array.isArray(value)) return false;
    const binding = value as Record<string, unknown>;
    const destination = binding.destination;
    if (!destination || typeof destination !== "object" || Array.isArray(destination)) return false;
    const target = destination as Record<string, unknown>;
    const tools = binding.allowedTools;
    return Object.keys(binding).sort().join(",") === "allowedTools,connectionId,destination,endpointPath,gatewayPublicId,grantVersionHash" &&
      typeof binding.connectionId === "string" && uuid.test(binding.connectionId) &&
      typeof binding.grantVersionHash === "string" && digest.test(binding.grantVersionHash) &&
      typeof binding.gatewayPublicId === "string" && /^[A-Za-z0-9_-]{1,128}$/.test(binding.gatewayPublicId) &&
      binding.endpointPath === `/mcp/gateways/${binding.gatewayPublicId}` &&
      Array.isArray(tools) && tools.length >= 1 && tools.length <= 64 && tools.every(tool => typeof tool === "string" && /^[A-Za-z0-9_.:-]{1,128}$/.test(tool)) &&
      new Set(tools).size === tools.length &&
      Object.keys(target).sort().join(",") === "hostname,method,path,port" &&
      typeof target.hostname === "string" && target.hostname.length <= 253 && /^[A-Za-z0-9.-]+$/.test(target.hostname) &&
      Number.isSafeInteger(target.port) && (target.port as number) >= 1 && (target.port as number) <= 65535 &&
      target.method === "POST" && typeof target.path === "string" && target.path.startsWith("/") && target.path.length <= 2048;
  });
  if (Object.keys(claim).length !== keys.length || keys.some(key => !Object.hasOwn(claim, key)) ||
    !["parentRequestId", "bindingId", "cellId", "hostId", "runId", "manifestId", "policySnapshotId", "brokerSessionId"].every(key => typeof claim[key] === "string" && uuid.test(claim[key] as string)) ||
    !(claim.attemptId === null || typeof claim.attemptId === "string" && uuid.test(claim.attemptId)) ||
    !Number.isSafeInteger(claim.attempt) || (claim.attempt as number) < 1 ||
    typeof claim.generation !== "string" || !/^[1-9][0-9]{0,18}$/.test(claim.generation) ||
    !Number.isSafeInteger(claim.hostEpoch) || (claim.hostEpoch as number) < 1 ||
    !["manifestHash", "policyHash"].every(key => typeof claim[key] === "string" && digest.test(claim[key] as string)) ||
    !endpoint || !["http:", "https:"].includes(endpoint.protocol) || endpoint.username || endpoint.password || endpoint.pathname !== "/" || endpoint.search || endpoint.hash ||
    typeof claim.endpointOrigin !== "string" || claim.endpointOrigin.length > 512 || `${endpoint.protocol}//${endpoint.host}/` !== claim.endpointOrigin ||
    !bindingsValid ||
    typeof claim.expiresAt !== "string" || !Number.isFinite(Date.parse(claim.expiresAt))) return null;
  return claim as unknown as SandboxBrokerCapabilityClaim;
}

function parseNativeToolEffectClaim(value: unknown): NativeToolEffectClaim | null {
  if (value === undefined) return null;
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const claim = value as Record<string, unknown>;
  const keys = ["dispatchId", "eventSeq", "attempt", "turnId", "callId", "tool", "operationId", "method", "pathAndQuery", "bodyPresent",
    "bodyHash", "apiReceiptDigest", "leaseOwner", "leaseExpiresAt", "controllerBootId", "controllerPid", "controllerProcessStartedAt"];
  if (Object.keys(claim).length !== keys.length || keys.some(key => !Object.hasOwn(claim, key))) return null;
  const uuidV4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  const digest = /^[0-9a-f]{64}$/;
  const printable = (raw: unknown, max: number) => typeof raw === "string" && raw.length > 0 && raw.length <= max && /^[\x21-\x7e]+$/.test(raw);
  if (typeof claim.dispatchId !== "string" || !uuidV4.test(claim.dispatchId) ||
    !Number.isSafeInteger(claim.eventSeq) || (claim.eventSeq as number) < 0 ||
    !Number.isSafeInteger(claim.attempt) || (claim.attempt as number) < 1 ||
    !printable(claim.turnId, 240) || !printable(claim.callId, 240) || claim.tool !== "call_api" ||
    typeof claim.operationId !== "string" || claim.operationId.length > 500 || !/^[\x20-\x7e]+$/.test(claim.operationId) ||
    !["POST", "PUT", "PATCH", "DELETE"].includes(String(claim.method)) ||
    !printable(claim.pathAndQuery, 16_384) || !String(claim.pathAndQuery).startsWith("/api/") ||
    typeof claim.bodyPresent !== "boolean" ||
    typeof claim.bodyHash !== "string" || !digest.test(claim.bodyHash) ||
    typeof claim.apiReceiptDigest !== "string" || !digest.test(claim.apiReceiptDigest) ||
    !printable(claim.leaseOwner, 500) || !Number.isFinite(Date.parse(String(claim.leaseExpiresAt))) ||
    !printable(claim.controllerBootId, 200) || !Number.isSafeInteger(claim.controllerPid) || (claim.controllerPid as number) < 1 ||
    !Number.isFinite(Date.parse(String(claim.controllerProcessStartedAt)))) return null;
  return claim as unknown as NativeToolEffectClaim;
}
