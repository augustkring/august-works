# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: aw-v9-experience.spec.ts >> V9 workflow review preserves the account gate, separates revisions and keeps Advanced rollback
- Location: tests/e2e/aw-v9-experience.spec.ts:354:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('main').getByRole('status')
Expected substring: "Sign in with a verified account to describe a workflow."
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" with timeout 15000ms
  - waiting for getByRole('main').getByRole('status')

```

```yaml
- main:
  - button "Switch to dark mode"
  - paragraph: Blentera
  - heading "Sign in to Blentera" [level=1]
  - paragraph: Use your email and password to access this instance.
  - text: Email
  - textbox "Email"
  - text: Password
  - textbox "Password"
  - button "Sign In" [disabled]
  - text: Need an account?
  - button "Create one"
```

# Test source

```ts
  294 |       await expect(
  295 |         mobileNavigation.getByRole("link", { name, exact: true }),
  296 |       ).toBeVisible();
  297 |     await page.screenshot({
  298 |       path: "test-results/aw-v9-home-compact.png",
  299 |       fullPage: true,
  300 |     });
  301 |     expect(
  302 |       await page.evaluate(
  303 |         () => document.documentElement.scrollWidth <= window.innerWidth,
  304 |       ),
  305 |     ).toBe(true);
  306 |     await page
  307 |       .getByRole("button", { name: "Open navigation", exact: true })
  308 |       .click();
  309 |     await page
  310 |       .locator("#mobile-sidebar")
  311 |       .getByRole("link", { name: "Advanced", exact: true })
  312 |       .click();
  313 |     await expect(
  314 |       page.getByRole("heading", { name: "Advanced", exact: true }),
  315 |     ).toBeVisible();
  316 |     await expect(
  317 |       page.getByRole("link", { name: "Skills", exact: true }),
  318 |     ).toBeVisible();
  319 |     await json(
  320 |       await request.patch("/api/instance/settings/experimental", {
  321 |         data: Object.fromEntries(
  322 |           Object.keys(enabled).map((key) => [key, false]),
  323 |         ),
  324 |       }),
  325 |     );
  326 |     expect(
  327 |       (
  328 |         await request.get(`${base}/experience?expectedUserId=${expectedUserId}`)
  329 |       ).status(),
  330 |     ).toBe(404);
  331 |     await page.goto(`/${company.issuePrefix}/work`);
  332 |     await expect(page).toHaveURL(new RegExp(`/${company.issuePrefix}/issues$`));
  333 |     await page.goto(`/${company.issuePrefix}/my-feedback`);
  334 |     await expect(
  335 |       page.getByRole("heading", { name: "My feedback", exact: true }),
  336 |     ).toBeVisible();
  337 |     expect(
  338 |       requestedPageChunks.some((path) => /\/MyFeedback-[^/]+\.js$/.test(path)),
  339 |     ).toBe(true);
  340 |     await page
  341 |       .getByRole("button", { name: new RegExp(history[0].feedbackId) })
  342 |       .click();
  343 |     await expect(page.getByText(body, { exact: true })).toBeVisible();
  344 |     expect(errors).toEqual([]);
  345 |   } finally {
  346 |     await request.patch("/api/instance/settings/experimental", {
  347 |       data: Object.fromEntries(
  348 |         Object.keys(enabled).map((key) => [key, original[key]]),
  349 |       ),
  350 |     });
  351 |   }
  352 | });
  353 | 
  354 | test("V9 workflow review preserves the account gate, separates revisions and keeps Advanced rollback", async ({
  355 |   page,
  356 |   request,
  357 |   browser,
  358 |   baseURL,
  359 | }) => {
  360 |   // This covers the whole Native lifecycle and explicit receipt recovery; it
  361 |   // is not an individual interaction or journey-performance timing budget.
  362 |   test.setTimeout(120_000);
  363 |   const original = await json(
  364 |     await request.get("/api/instance/settings/experimental"),
  365 |   );
  366 |   const enabled = {
  367 |     experience_projection_v9: true,
  368 |     progressive_shell_v9: true,
  369 |     enableWorkflowsV1: true,
  370 |     enableWorkflowBuilderV1: true,
  371 |   };
  372 |   await json(
  373 |     await request.patch("/api/instance/settings/experimental", {
  374 |       data: enabled,
  375 |     }),
  376 |   );
  377 |   const company = await json(
  378 |     await request.post("/api/companies", {
  379 |       data: { name: "V9 disposable workflow company" },
  380 |     }),
  381 |   );
  382 |   const base = `/api/companies/${company.id}/workflows`;
  383 |   const errors: string[] = [];
  384 |   page.on("pageerror", (error) => errors.push(error.message));
  385 |   // Verify the account gate with an actually anonymous browser context. The
  386 |   // default authenticated fixture is verified and must be able to proceed.
  387 |   const anonymousContext = await browser.newContext({
  388 |     baseURL,
  389 |     storageState: { cookies: [], origins: [] },
  390 |   });
  391 |   try {
  392 |     const anonymousPage = await anonymousContext.newPage();
  393 |     await anonymousPage.goto(`/${company.issuePrefix}/workflows`);
> 394 |     await expect(anonymousPage.getByRole("main").getByRole("status")).toContainText(
      |                                                                       ^ Error: expect(locator).toContainText(expected) failed
  395 |       "Sign in with a verified account to describe a workflow.",
  396 |       { timeout: 15_000 },
  397 |     );
  398 |   } finally {
  399 |     await anonymousContext.close();
  400 |   }
  401 |   // Native activity can withdraw an acknowledgement while its original change
  402 |   // commits. Model the user's explicit, bounded same-request recovery; never
  403 |   // create another command or relax current authority.
  404 |   async function expectCurrentReceipt(text: RegExp) {
  405 |     const receipt = page.getByText(text);
  406 |     const retry = page.getByRole("button", { name: "Retry same request", exact: true });
  407 |     for (let attempt = 0; attempt < 3; attempt++) {
  408 |       try { await expect(receipt).toBeVisible(); return; }
  409 |       catch (missingReceipt) {
  410 |         if (!(await retry.isVisible())) throw missingReceipt;
  411 |         try { await retry.click({ timeout: 1000 }); }
  412 |         catch (changedDialog) {
  413 |           // A late valid acknowledgement can close the dialog between the DOM
  414 |           // check and click. Do not leave a click waiting for a later command.
  415 |           if (await receipt.isVisible()) return;
  416 |           throw changedDialog;
  417 |         }
  418 |       }
  419 |     }
  420 |     await expect(receipt).toBeVisible();
  421 |   }
  422 |   try {
  423 |     const created = await json(
  424 |       await request.post(base, { data: { name: "Review deal opportunities" } }),
  425 |     );
  426 |     const path = `/${company.issuePrefix}/workflows/${created.id}`;
  427 |     await page.goto(path);
  428 |     await expect(
  429 |       page.getByRole("heading", {
  430 |         name: "Review deal opportunities",
  431 |         exact: true,
  432 |       }),
  433 |     ).toBeVisible();
  434 |     await expect(
  435 |       page.getByText("Draft — no active published revision", { exact: true }),
  436 |     ).toBeVisible();
  437 |     await expect(
  438 |       page.getByText(
  439 |         "This revision has no steps yet. It is not a tested process.",
  440 |         { exact: true },
  441 |       ),
  442 |     ).toBeVisible();
  443 |     const graph = (name: string) => ({
  444 |       version: 1,
  445 |       nodes: [
  446 |         {
  447 |           id: "start",
  448 |           type: "core.manual_trigger",
  449 |           name,
  450 |           position: { x: 0, y: 0 },
  451 |           config: {},
  452 |         },
  453 |         {
  454 |           id: "decision",
  455 |           type: "core.condition",
  456 |           name: "Check report",
  457 |           position: { x: 0, y: 1 },
  458 |           config: { expression: "true" },
  459 |         },
  460 |         {
  461 |           id: "yes",
  462 |           type: "core.merge",
  463 |           name: "Prepare report",
  464 |           position: { x: 0, y: 2 },
  465 |           config: { mode: "all" },
  466 |         },
  467 |         {
  468 |           id: "no",
  469 |           type: "core.merge",
  470 |           name: "Other report path",
  471 |           position: { x: 1, y: 2 },
  472 |           config: { mode: "all" },
  473 |         },
  474 |       ],
  475 |       edges: [
  476 |         { id: "start-check", source: "start", target: "decision" },
  477 |         {
  478 |           id: "check-yes",
  479 |           source: "decision",
  480 |           target: "yes",
  481 |           sourceHandle: "true",
  482 |         },
  483 |         {
  484 |           id: "check-no",
  485 |           source: "decision",
  486 |           target: "no",
  487 |           sourceHandle: "false",
  488 |         },
  489 |       ],
  490 |       variables: [],
  491 |       settings: { totalDeadlineSeconds: 60 },
  492 |     });
  493 |     const prepared = await json(
  494 |       await request.patch(`${base}/${created.id}/draft`, {
```