from pathlib import Path
import re
p=Path('/workspace/blentera-v10/server/src/services/native-direct-input.ts');s=p.read_text()
a=s.index('interface NativeGraphProofDiagnostic');b=s.index('interface NativeSourceReadAncestry',a);s=s[:a]+s[b:]
s=s.replace('proofDiagnostics?: Map<string, NativeGraphProofDiagnostic>; ', '')
s=s.replace('work: number; workByCaller: Record<string, number>; activeByActor:', 'work: number; activeByActor:')
a=s.index('function recordNativeGraphProofDiagnostic(');b=s.index('async function withNativeSourceGraphProof(',a);s=s[:a]+s[b:]
s,count=re.subn(r'^ +recordNativeGraphProofDiagnostic\([\s\S]*?\);\n','',s,flags=re.M);assert count==3,count
s=s.replace('  const candidate = eligible ? proofs.get(key) : undefined;\n  const proof = candidate;', '  const proof = eligible ? proofs.get(key) : undefined;')
a=s.index('  if (nativeSourceMemoDiagnosticsEnabled()) {\n    const kind = key.split(');b=s.index('  let stack =',a);s=s[:a]+s[b:]
a=s.index('const nativeSourceMemoDiagnostics = {');b=s.index('  frozenTaskMemoByKind:',a);s=s[:a]+'''const nativeSourceMemoDiagnostics = {
  siblingToolSourceProofHits: 0, documentNodeHits: 0,
'''+s[b:]
s=s.replace('  nativeSourceMemoDiagnostics.lastWorkOverflow = null;\n  nativeSourceMemoDiagnostics.graphProofKinds = {};\n','')
s=s.replace('return { work: 0, workByCaller: {}, activeByActor:', 'return { work: 0, activeByActor:')
a=s.index('function nativeSourceReadWork(');b=s.index('\nfunction mergeNativeFrozenTaskProofMaps',a)
s=s[:a]+'''function nativeSourceReadWork(scope: NativeSourceReadScope) {
  if (++scope.context.ancestry.work > 512)
    throw forbidden("The Native source graph exceeds its total-work bound");
}
''' +s[b:]
assert all(x not in s for x in ['workByCaller','lastWorkOverflow','graphProofKinds','proofDiagnostics','NativeGraphProofDiagnostic','recordNativeGraphProofDiagnostic'])
Path('/workspace/v10-preparation/native-final-clean-candidate.ts').write_text(s)
p=Path('/workspace/blentera-v10/server/src/__tests__/native-payload-temporal-sources.integration.test.ts');s=p.read_text();a=s.index('    try {\n      temporal = await buildTemporalFixture();');b=s.index('\n  }, 600_000);',a);s=s[:a]+'    temporal = await buildTemporalFixture();'+s[b:];Path('/workspace/v10-preparation/native-temporal-final-clean-candidate.ts').write_text(s)
