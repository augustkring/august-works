from pathlib import Path
import sys,subprocess,json,hashlib
root=Path(sys.argv[2]);manifest=Path(sys.argv[3])
paths=subprocess.check_output(['git','ls-files','-z','--','ui','packages','package.json','pnpm-lock.yaml','pnpm-workspace.yaml','scripts/prepare-server-ui-dist.sh'],cwd=root).decode().split('\0')
rows=[]
for rel in sorted(p for p in paths if p):
 p=root/rel
 if not p.is_file():rows.append({'path':rel,'missing':True});continue
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 rows.append({'path':rel,'sha256':h})
if sys.argv[1]=='record':manifest.write_text(json.dumps({'buildInputs':rows},indent=2)+'\n')
elif sys.argv[1]=='verify':
 assert rows==json.loads(manifest.read_text())['buildInputs'],'UI/package source changed between build and final pinned snapshot; reject this attempt'
 print(json.dumps({'verifiedBuildInputs':len(rows),'status':'passed'}))
else:raise ValueError('record or verify required')
