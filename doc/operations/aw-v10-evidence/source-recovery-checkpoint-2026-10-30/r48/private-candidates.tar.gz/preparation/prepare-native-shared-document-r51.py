from pathlib import Path
import hashlib,json,difflib
r=Path('/workspace/blentera-v10');o=Path('/workspace/v10-preparation/native-shared-document-r51-candidate');rel='server/src/services/native-direct-input.ts';a=(r/rel).read_text();s=a
needle='''  const documentProof = documentProofEligible ? siblingToolSourceProofs.get(documentProofKey) : undefined;
  if (documentProof && depth <= (documentProof.validatedDepth ?? -1) &&''';assert needle in s
s=s.replace(needle,'''  let documentProof = documentProofEligible ? siblingToolSourceProofs.get(documentProofKey) : undefined;
  // The exact owner/body/latest checks above stay fresh. Share only the
  // completed descendant walk within the existing sealed transaction tree.
  const documentLedger = !scope.context.ancestry.graphProofsDisabled && is(scope.context.db, PgTransaction)
    ? scope.context.ancestry.graphProofs : undefined;
  const documentLedgerKey = JSON.stringify([documentProofKey, depth]);
  const ownDocumentReaders = documentLedger ? (scope.context.readerObligations ??= {}) : undefined;
  if (documentProofEligible && (!documentProof || depth > (documentProof.validatedDepth ?? -1))) {
    const retained = documentLedger?.get(documentLedgerKey);
    const sameContext = retained?.readerObligations !== undefined && retained.readerObligations === ownDocumentReaders;
    const obligations = retained?.readerObligations?.completed;
    if (retained && depth <= (retained.validatedDepth ?? -1) && (sameContext || obligations) &&
      !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, retained.descendants) &&
      await nativeFrozenMutableSourcesCurrent(db, input.companyId, retained.mutableSources, scope) &&
      (sameContext || obligations && await replayNativeSourceGraphObligations(scope, obligations, retained.readerSets)))
      documentProof = retained;
  }
  if (documentProof && depth <= (documentProof.validatedDepth ?? -1) &&''',1)
needle='''    if (documentCompleted && documentProofEligible && siblingToolSourceProofs.size < 512)
      siblingToolSourceProofs.set(documentProofKey, { descendants: documentFrame.descendants, mutableSources: documentFrame.mutableSources,
        policy: snapshot.policy, inputs: snapshot.inputs,
        validatedDepth: Math.max(depth, documentProof?.validatedDepth ?? -1),
        ...(documentFrame.readerSelection?.complete ? { readerSets: new Map(documentFrame.readerSelection.sets) } : {}) });''';assert needle in s
s=s.replace(needle,'''    if (documentCompleted && documentProofEligible) {
      const completedProof = { descendants: documentFrame.descendants, mutableSources: documentFrame.mutableSources,
        policy: snapshot.policy, inputs: snapshot.inputs,
        validatedDepth: Math.max(depth, documentProof?.validatedDepth ?? -1),
        ...(ownDocumentReaders ? { readerObligations: ownDocumentReaders } : {}),
        ...(documentFrame.readerSelection?.complete ? { readerSets: new Map(documentFrame.readerSelection.sets) } : {}) };
      if (siblingToolSourceProofs.size < 512) siblingToolSourceProofs.set(documentProofKey, completedProof);
      if (documentLedger && !scope.context.ancestry.graphProofsDisabled && documentLedger.size < 512)
        documentLedger.set(documentLedgerKey, completedProof);
    }''',1)
p=o/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);(o/'candidate.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)));(o/'manifest.json').write_text(json.dumps({rel:{'priorSha256':hashlib.sha256(a.encode()).hexdigest(),'candidateSha256':hashlib.sha256(s.encode()).hexdigest()}},indent=2))
