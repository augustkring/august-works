DROP TABLE "responsibility_scan_candidates" CASCADE;--> statement-breakpoint
DROP TABLE "responsibility_scan_runs" CASCADE;--> statement-breakpoint
ALTER TABLE "companies" DROP COLUMN "security_contact_user_id";--> statement-breakpoint
ALTER TABLE "companies" DROP COLUMN "support_incident_contact_user_id";--> statement-breakpoint
CREATE FUNCTION aw_v10_customer_feedback_experience_measure_guard() RETURNS trigger LANGUAGE plpgsql SET search_path=pg_catalog,public,pg_temp AS $$
BEGIN
  IF TG_OP='UPDATE' THEN
    RAISE EXCEPTION 'Optional feedback experience ratings are immutable' USING ERRCODE='23514';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM customer_feedback f
    WHERE f.company_id=NEW.company_id AND f.id=NEW.feedback_id
      AND f.context->'experienceMeasure'->>'offered'='true'
      AND f.context->'experienceMeasure'->>'consent'='granted'
  ) THEN
    RAISE EXCEPTION 'Optional feedback ratings require the original consent marker' USING ERRCODE='23514';
  END IF;
  IF EXISTS (
    SELECT 1 FROM customer_feedback_events e
    WHERE e.company_id=NEW.company_id AND e.feedback_id=NEW.feedback_id
      AND e.link_type='aw_feedback_measure_withdrawal_v1'
  ) THEN
    RAISE EXCEPTION 'Withdrawn feedback ratings cannot be restored' USING ERRCODE='23514';
  END IF;
  RETURN NEW;
END $$;
--> statement-breakpoint
CREATE TRIGGER aw_v10_customer_feedback_experience_measure_guard
BEFORE INSERT OR UPDATE ON customer_feedback_experience_measures
FOR EACH ROW EXECUTE FUNCTION aw_v10_customer_feedback_experience_measure_guard();
--> statement-breakpoint
CREATE FUNCTION aw_v10_customer_feedback_experience_withdrawal_event_guard() RETURNS trigger LANGUAGE plpgsql SET search_path=pg_catalog,public,pg_temp AS $$
BEGIN
  IF NEW.link_type='aw_feedback_measure_withdrawal_v1' AND NOT EXISTS (
    SELECT 1 FROM customer_feedback f
    WHERE f.company_id=NEW.company_id AND f.id=NEW.feedback_id
      AND f.context->'experienceMeasure'->>'offered'='true'
      AND f.context->'experienceMeasure'->>'consent'='granted'
  ) THEN
    RAISE EXCEPTION 'Feedback withdrawal marker requires original consent' USING ERRCODE='23514';
  END IF;
  RETURN NEW;
END $$;
--> statement-breakpoint
CREATE TRIGGER aw_v10_customer_feedback_experience_withdrawal_event_guard
BEFORE INSERT ON customer_feedback_events
FOR EACH ROW EXECUTE FUNCTION aw_v10_customer_feedback_experience_withdrawal_event_guard();
--> statement-breakpoint
CREATE FUNCTION aw_v10_customer_feedback_experience_withdrawal_immutable() RETURNS trigger LANGUAGE plpgsql SET search_path=pg_catalog,public,pg_temp AS $$
BEGIN
  IF OLD.link_type='aw_feedback_measure_withdrawal_v1' AND pg_trigger_depth() <= 1 THEN
    RAISE EXCEPTION 'Feedback withdrawal markers are append-only' USING ERRCODE='23514';
  END IF;
  RETURN OLD;
END $$;
--> statement-breakpoint
CREATE TRIGGER aw_v10_customer_feedback_experience_withdrawal_immutable
BEFORE DELETE ON customer_feedback_events
FOR EACH ROW EXECUTE FUNCTION aw_v10_customer_feedback_experience_withdrawal_immutable();
