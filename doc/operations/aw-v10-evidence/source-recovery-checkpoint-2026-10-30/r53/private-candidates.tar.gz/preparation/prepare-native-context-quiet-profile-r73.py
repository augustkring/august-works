from pathlib import Path
import hashlib,json,difflib
r=Path('/workspace/blentera-v10');base=Path('/workspace/v10-preparation/native-document-producer-r72-candidate');out=Path('/workspace/v10-preparation/native-context-quiet-profile-r73-candidate');rels=['server/src/services/native-direct-input.ts','server/src/__tests__/native-payload-temporal-sources.integration.test.ts']
for rel in rels:
 (out/rel).parent.mkdir(parents=True,exist_ok=True);(out/rel).write_bytes((base/rel).read_bytes())
rel='server/src/services/context/context-manifest.ts';old=(r/rel).read_text();s=old
needle='      const phaseEnabled = process.env.PAPERCLIP_NATIVE_CONTEXT_PHASE_DIAGNOSTICS === "1";';assert s.count(needle)==1;s=s.replace(needle,needle+'''
      const profileEnabled = process.env.PAPERCLIP_NATIVE_CONTEXT_CPU_PROFILE === "1";
      const profileBounds: Record<string, { startUs: number; endUs: number }> = {};
      let profilePhase = "references", profileStartUs = profileEnabled ? Number(process.hrtime.bigint() / 1000n) : 0;''',1)
needle='      const phaseNext = (next: string) => {\n';assert s.count(needle)==1;s=s.replace(needle,needle+'''        if (profileEnabled) {
          const endUs = Number(process.hrtime.bigint() / 1000n);
          profileBounds[profilePhase] = { startUs: profileStartUs, endUs };
          profileStartUs = endUs; profilePhase = next;
        }
''',1)
needle='        phaseNext("complete");';assert s.count(needle)==1;s=s.replace(needle,needle+'''
        if (profileEnabled) console.error("native_manifest_profile_bounds", JSON.stringify(profileBounds));''',1)
(out/rel).parent.mkdir(parents=True,exist_ok=True);(out/rel).write_text(s);(out/'r73-manifest.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)));rels.append(rel)
rel='server/src/services/context/context-engine.ts';old=(r/rel).read_text();s=old;needle='        if (process.env.PAPERCLIP_NATIVE_CONTEXT_PHASE_DIAGNOSTICS === "1")';assert s.count(needle)==1;s=s.replace(needle,needle[:-1]+' ||\n          process.env.PAPERCLIP_NATIVE_CONTEXT_CPU_PROFILE === "1")',1)
(out/rel).parent.mkdir(parents=True,exist_ok=True);(out/rel).write_text(s);(out/'r73-engine.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)));rels.append(rel)
m={}
for rel in rels:
 a=(r/rel).read_bytes();b=(out/rel).read_bytes();m[rel]={'priorSha256':hashlib.sha256(a).hexdigest(),'candidateSha256':hashlib.sha256(b).hexdigest()}
(out/'manifest.json').write_text(json.dumps(m,indent=2));(out/'syntax-pins.json').write_text(json.dumps({'qualificationWorkspace':str(out),'copiedFiles':[{'path':rel} for rel in m]},indent=2))
p=Path('/workspace/v10-preparation');snapshot=(p/'snapshot-private-native-r72.py').read_text().replace('native-document-producer-r72-candidate','native-context-quiet-profile-r73-candidate');(p/'snapshot-private-native-r73.py').write_text(snapshot);runner=(p/'run-private-native-document-r72-quiet.sh').read_text().replace('snapshot-private-native-r72.py','snapshot-private-native-r73.py');needle='export PAPERCLIP_NATIVE_CONTEXT_PHASE_DIAGNOSTICS=0';assert runner.count(needle)==1;runner=runner.replace(needle,needle+'\nexport PAPERCLIP_NATIVE_CONTEXT_CPU_PROFILE=1',1);runner=runner.replace('cpu_profile=disabled','cpu_profile=node-cpu-prof-phase0');runner=runner.replace('-t "$TEST_PATTERN" --reporter=verbose \\','-t "$TEST_PATTERN" --reporter=verbose --execArgv=--cpu-prof --execArgv=--cpu-prof-dir=/workspace/v10-preparation/native-context-cpu-r73-20261101 \\');needle='cd "$ROOT/server"';assert runner.count(needle)==1;runner=runner.replace(needle,'mkdir -p /workspace/v10-preparation/native-context-cpu-r73-20261101\n'+needle,1);assert runner.count('--cpu-prof-dir=')==2;(p/'run-private-native-context-profile-r73.sh').write_text(runner)
print((out/'r73-manifest.diff').read_text());print((out/'r73-engine.diff').read_text())
