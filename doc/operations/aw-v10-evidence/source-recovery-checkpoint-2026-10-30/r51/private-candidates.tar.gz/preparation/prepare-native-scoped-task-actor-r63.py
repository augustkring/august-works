from pathlib import Path
import json,hashlib,difflib
r=Path('/workspace/blentera-v10');rel='server/src/services/native-direct-input.ts';a=(r/rel).read_text();s=a
old='''        const scope = context.scopes.get(nativeSha256(check.actor));
        if (!scope) throw forbidden("The Native scoped Task reader is unavailable");
        context.activeScopedTaskReads.add(key);
        try { await recheckNativeScopedTaskRead(scope, check); }
        finally { context.activeScopedTaskReads.delete(key); }'''
new='''        const scope = context.scopes.get(nativeSha256(check.actor));
        context.activeScopedTaskReads.add(key);
        try {
          if (scope) await recheckNativeScopedTaskRead(scope, check);
          else await withNativeSourceReadScope(context.db as Db, check.actor, check.companyId,
            actorScope => recheckNativeScopedTaskRead(actorScope, check));
        } finally { context.activeScopedTaskReads.delete(key); }'''
assert s.count(old)==1;s=s.replace(old,new,1)
o=Path('/workspace/v10-preparation/native-scoped-task-actor-r63-candidate');p=o/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
(o/'candidate.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
(o/'manifest.json').write_text(json.dumps({rel:{'priorSha256':hashlib.sha256(a.encode()).hexdigest(),'candidateSha256':hashlib.sha256(s.encode()).hexdigest()}},indent=2))
