# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: aw-v9-experience.spec.ts >> V9 workflow review preserves the account gate, separates revisions and keeps Advanced rollback
- Location: tests/e2e/aw-v9-experience.spec.ts:351:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('main').getByRole('status')
Expected substring: "Sign in with a verified account to describe a workflow."
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" with timeout 5000ms
  - waiting for getByRole('main').getByRole('status')
    - locator resolved to <p role="status">Loading current work…</p>
    - unexpected value "Loading current work…"
    3 × locator resolved to <p role="status">Henter aktuelt arbejde…</p>
      - unexpected value "Henter aktuelt arbejde…"

```

```yaml
- link "Skip to Main Content":
  - /url: "#main-content"
- complementary:
  - button "Open V9 disposable workflow company organization switcher": V V9 disposable workflow company
  - navigation:
    - text: Visning
    - combobox "Visning":
      - option "Medlem"
      - option "Leder" [selected]
      - option "Administrator"
      - option "Sikkerhedsadministrator"
    - link "Hjem":
      - /url: /VDIAA/dashboard
    - link "Kræver dig":
      - /url: /VDIAA/needs-you
    - link "Arbejde":
      - /url: /VDIAA/work
    - link "Agenter":
      - /url: /VDIAA/agents
    - link "Apps":
      - /url: /VDIAA/apps
    - link "Indsigter":
      - /url: /VDIAA/insights
    - link "Avanceret":
      - /url: /VDIAA/advanced
    - button "Spørg Blentera"
    - link "Hjælp / Support":
      - /url: /VDIAA/company/help
- button "Open account menu": BR Browser product reviewer
- separator "Resize sidebar"
- region "Globale funktioner":
  - button "Spørg Blentera"
  - text: Sprog
  - combobox "Sprog":
    - option "English"
    - option "Dansk" [selected]
  - link "Hjælp / Support":
    - /url: /VDIAA/company/help
  - link "Kontakt support":
    - /url: mailto:support@blentera.com
  - link "Brugerkonto":
    - /url: /VDIAA/company/settings/instance/profile
- main:
  - heading "Arbejdsgange" [level=1]
  - paragraph: Gennemgå dine processer, deres aktuelle versioner og det arbejde, der kræver opmærksomhed.
  - link "Beskriv en arbejdsgang":
    - /url: /VDIAA/workflows/new
  - list:
    - listitem:
      - link "Review deal opportunities":
        - /url: /VDIAA/workflows/443ea6bd-b1eb-45eb-9527-021038afca00
      - paragraph: Kladde — ingen aktiv udgivet version
  - paragraph: Visningen viser op til 20 nyere arbejdsgange, du aktuelt kan åbne. Ældre arbejde vises muligvis ikke.
- heading "Command Palette" [level=2]
- paragraph: Search for a command to run...
```

# Test source

```ts
  309 |       .click();
  310 |     await expect(
  311 |       page.getByRole("heading", { name: "Advanced", exact: true }),
  312 |     ).toBeVisible();
  313 |     await expect(
  314 |       page.getByRole("link", { name: "Skills", exact: true }),
  315 |     ).toBeVisible();
  316 |     await json(
  317 |       await request.patch("/api/instance/settings/experimental", {
  318 |         data: Object.fromEntries(
  319 |           Object.keys(enabled).map((key) => [key, false]),
  320 |         ),
  321 |       }),
  322 |     );
  323 |     expect(
  324 |       (
  325 |         await request.get(`${base}/experience?expectedUserId=${expectedUserId}`)
  326 |       ).status(),
  327 |     ).toBe(404);
  328 |     await page.goto(`/${company.issuePrefix}/work`);
  329 |     await expect(page).toHaveURL(new RegExp(`/${company.issuePrefix}/issues$`));
  330 |     await page.goto(`/${company.issuePrefix}/my-feedback`);
  331 |     await expect(
  332 |       page.getByRole("heading", { name: "My feedback", exact: true }),
  333 |     ).toBeVisible();
  334 |     expect(
  335 |       requestedPageChunks.some((path) => /\/MyFeedback-[^/]+\.js$/.test(path)),
  336 |     ).toBe(true);
  337 |     await page
  338 |       .getByRole("button", { name: new RegExp(history[0].feedbackId) })
  339 |       .click();
  340 |     await expect(page.getByText(body, { exact: true })).toBeVisible();
  341 |     expect(errors).toEqual([]);
  342 |   } finally {
  343 |     await request.patch("/api/instance/settings/experimental", {
  344 |       data: Object.fromEntries(
  345 |         Object.keys(enabled).map((key) => [key, original[key]]),
  346 |       ),
  347 |     });
  348 |   }
  349 | });
  350 | 
  351 | test("V9 workflow review preserves the account gate, separates revisions and keeps Advanced rollback", async ({
  352 |   page,
  353 |   request,
  354 | }) => {
  355 |   // This covers the whole Native lifecycle and explicit receipt recovery; it
  356 |   // is not an individual interaction or journey-performance timing budget.
  357 |   test.setTimeout(120_000);
  358 |   const original = await json(
  359 |     await request.get("/api/instance/settings/experimental"),
  360 |   );
  361 |   const enabled = {
  362 |     experience_projection_v9: true,
  363 |     progressive_shell_v9: true,
  364 |     enableWorkflowsV1: true,
  365 |     enableWorkflowBuilderV1: true,
  366 |   };
  367 |   await json(
  368 |     await request.patch("/api/instance/settings/experimental", {
  369 |       data: enabled,
  370 |     }),
  371 |   );
  372 |   const company = await json(
  373 |     await request.post("/api/companies", {
  374 |       data: { name: "V9 disposable workflow company" },
  375 |     }),
  376 |   );
  377 |   const base = `/api/companies/${company.id}/workflows`;
  378 |   const errors: string[] = [];
  379 |   page.on("pageerror", (error) => errors.push(error.message));
  380 |   // Native activity can withdraw an acknowledgement while its original change
  381 |   // commits. Model the user's explicit, bounded same-request recovery; never
  382 |   // create another command or relax current authority.
  383 |   async function expectCurrentReceipt(text: RegExp) {
  384 |     const receipt = page.getByText(text);
  385 |     const retry = page.getByRole("button", { name: "Retry same request", exact: true });
  386 |     for (let attempt = 0; attempt < 3; attempt++) {
  387 |       try { await expect(receipt).toBeVisible(); return; }
  388 |       catch (missingReceipt) {
  389 |         if (!(await retry.isVisible())) throw missingReceipt;
  390 |         try { await retry.click({ timeout: 1000 }); }
  391 |         catch (changedDialog) {
  392 |           // A late valid acknowledgement can close the dialog between the DOM
  393 |           // check and click. Do not leave a click waiting for a later command.
  394 |           if (await receipt.isVisible()) return;
  395 |           throw changedDialog;
  396 |         }
  397 |       }
  398 |     }
  399 |     await expect(receipt).toBeVisible();
  400 |   }
  401 |   try {
  402 |     const created = await json(
  403 |       await request.post(base, { data: { name: "Review deal opportunities" } }),
  404 |     );
  405 |     const path = `/${company.issuePrefix}/workflows/${created.id}`;
  406 |     await page.goto(`/${company.issuePrefix}/workflows`);
  407 |     // The customer index requires a verified account. This local-board fixture
  408 |     // must not borrow that admission; Original detail/rollback remain separate.
> 409 |     await expect(page.getByRole("main").getByRole("status")).toContainText(
      |                                                              ^ Error: expect(locator).toContainText(expected) failed
  410 |       "Sign in with a verified account to describe a workflow.",
  411 |     );
  412 |     await page.goto(path);
  413 |     await expect(
  414 |       page.getByRole("heading", {
  415 |         name: "Review deal opportunities",
  416 |         exact: true,
  417 |       }),
  418 |     ).toBeVisible();
  419 |     await expect(
  420 |       page.getByText("Draft — no active published revision", { exact: true }),
  421 |     ).toBeVisible();
  422 |     await expect(
  423 |       page.getByText(
  424 |         "This revision has no steps yet. It is not a tested process.",
  425 |         { exact: true },
  426 |       ),
  427 |     ).toBeVisible();
  428 |     const graph = (name: string) => ({
  429 |       version: 1,
  430 |       nodes: [
  431 |         {
  432 |           id: "start",
  433 |           type: "core.manual_trigger",
  434 |           name,
  435 |           position: { x: 0, y: 0 },
  436 |           config: {},
  437 |         },
  438 |         {
  439 |           id: "decision",
  440 |           type: "core.condition",
  441 |           name: "Check report",
  442 |           position: { x: 0, y: 1 },
  443 |           config: { expression: "true" },
  444 |         },
  445 |         {
  446 |           id: "yes",
  447 |           type: "core.merge",
  448 |           name: "Prepare report",
  449 |           position: { x: 0, y: 2 },
  450 |           config: { mode: "all" },
  451 |         },
  452 |         {
  453 |           id: "no",
  454 |           type: "core.merge",
  455 |           name: "Other report path",
  456 |           position: { x: 1, y: 2 },
  457 |           config: { mode: "all" },
  458 |         },
  459 |       ],
  460 |       edges: [
  461 |         { id: "start-check", source: "start", target: "decision" },
  462 |         {
  463 |           id: "check-yes",
  464 |           source: "decision",
  465 |           target: "yes",
  466 |           sourceHandle: "true",
  467 |         },
  468 |         {
  469 |           id: "check-no",
  470 |           source: "decision",
  471 |           target: "no",
  472 |           sourceHandle: "false",
  473 |         },
  474 |       ],
  475 |       variables: [],
  476 |       settings: { totalDeadlineSeconds: 60 },
  477 |     });
  478 |     const prepared = await json(
  479 |       await request.patch(`${base}/${created.id}/draft`, {
  480 |         data: {
  481 |           expectedRevisionId: created.draftRevisionId,
  482 |           graph: graph("Active manual start"),
  483 |         },
  484 |       }),
  485 |     );
  486 |     // Fixture-only native publication. This does not qualify the V9 test/publish journey.
  487 |     const published = await json(
  488 |       await request.post(`${base}/${created.id}/publish`, {
  489 |         data: {
  490 |           expectedDraftRevisionId: prepared.draftRevisionId,
  491 |           expectedPublishedRevisionId: null,
  492 |           approvalId: null,
  493 |         },
  494 |       }),
  495 |     );
  496 |     const changed = await json(
  497 |       await request.patch(`${base}/${created.id}/draft`, {
  498 |         data: {
  499 |           expectedRevisionId: published.draftRevisionId,
  500 |           graph: graph("Proposed manual start"),
  501 |         },
  502 |       }),
  503 |     );
  504 |     await page.reload();
  505 |     await expect(
  506 |       page.getByRole("heading", {
  507 |         name: "Step 1: Active manual start",
  508 |         exact: true,
  509 |       }),
```