from pathlib import Path
import subprocess,json,gzip,tarfile,io,hashlib,datetime
root=Path('/workspace/blentera-v10');prep=Path('/workspace/v10-preparation');out=root/'doc/operations/aw-v10-evidence/source-recovery-checkpoint-2026-10-30/r54'
assert not out.exists();out.mkdir(parents=True)
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
def sha(b):return hashlib.sha256(b).hexdigest()
base=git('rev-parse','HEAD').decode().strip();patch=git('diff','--binary',base);z=gzip.compress(patch,mtime=0);(out/'working-source.patch.gz').write_bytes(z)
new=[p for p in git('ls-files','--others','--exclude-standard').decode().splitlines() if p.startswith(('server/','ui/','packages/','scripts/','tests/'))]
def pack(dest,files):
 rows=[]
 with tarfile.open(dest,'w:gz') as t:
  for name,p in sorted(files.items()):
   b=p.read_bytes();i=tarfile.TarInfo(name);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b));rows.append({'path':name,'bytes':len(b),'sha256':sha(b)})
 return rows
newrows=pack(out/'untracked-source.tar.gz',{p:root/p for p in new if (root/p).is_file()});files={}
for pattern in ['root-continuation-20261101-current.md','root-continuation-latest.md','preserve-r54.py','run-final-workspace-aggregate-20261101.sh','snapshot-current-source-for-dependency-check.py','publish-parsed-source.cjs','*relocation-20261101*.json','old-provider-pack-archive-receipt-20261101.json','archive-old-provider-pack-20261101.py','relocate-resource-governance-r14-20261101.py','pr42-body-current-20261101.md']:
 for p in prep.glob(pattern):
  if p.is_file():files['preparation/'+p.name]=p
for prefix in ['native-work-envelope-r81-candidate','v10-149-r14.29-private','native-builtin-capture-protocol-nov01','native-builtin-source-owner-nov01','native-paid-admission-guard-nov01','codex-responses-gateway-nov01','v10-nov01-claim-amendment']:
 d=prep/prefix
 if not d.exists():continue
 for p in d.rglob('*'):
  rel=p.relative_to(d)
  if any(x.startswith('qualification') or x == 'build-backup' for x in rel.parts):continue
  if not p.is_file() or any(x in rel.parts for x in ['.git','node_modules','__pycache__','qualification','qualification-r10','portable-r10','build-state','restore-files','source-bundle','qualified-source-files','source-pins.source-files','node-state','target','runner-source','runner-private','rust-private','runtime','cargo-target']):continue
  if p.stat().st_size>16_000_000:continue
  files['preparation/'+str(p.relative_to(prep))]=p
rows=pack(out/'private-candidates.tar.gz',files)
# Immutable archive pins record a recovery snapshot, not a claim that active candidates qualify.
m={'purpose':'recovery_only_not_qualification','savedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseCommit':base,'priorRecoveryCommit':'fc718f90c','patchBytes':len(patch),'patchSha256':sha(patch),'archiveSha256':sha(z),'untrackedSourceFiles':newrows,'privateCandidateFiles':rows,'privateCandidateArchiveSha256':sha((out/'private-candidates.tar.gz').read_bytes())}
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');(out/'README.md').write_text('# Recoverable source checkpoint r54\n\nRecovery only; MAIN NativeR66 plus frozen private NativeR81, sandbox lifecycle R14.29, paid admission guard and paired UI notices, builtin capture source/protocol, Responses selection hardening and claim amendments remain under development. R81 and sandbox lifecycle qualification are pending; completed component tests are scoped in each candidate receipt. This later Nov1 checkpoint preserves all current MAIN tracked edits and named private source drafts after environment restart. R6.1 vendor source checks are separately qualified at committed evidence. Apply the working patch at the exact manifest base. Private candidates use preparation/ paths and require review; archived source-pin/patch files inside an unfinished candidate may describe its older parent. The full current files/ tree is saved independently. Prior checkpoints r51/r52/r53 retain older candidate history. No software, physical-host or release acceptance is inferred.\n');print(json.dumps({'output':str(out),'privateFiles':len(rows),'privateBytes':(out/'private-candidates.tar.gz').stat().st_size,'patchBytes':len(patch)}))
