# Trust document registry receipt immutability

The canonical source-pinned Postgres test file `server/src/__tests__/trust-document-registry-postgres.test.ts` passed all 3 current cases. The formerly failing case passed direct acceptance receipt UPDATE/DELETE rejection with SQLSTATE 55000 and company-erasure cascade; the other cases passed immutable notice/admin receipts, registry action semantics, gated grants and separate revocation receipts.

No production SQL or fixture change was made. The old 2026-10-28 receipt pins a different test source hash (`5c84fd…`); this current run pins `9c0490…`. Migration 0557 remains byte-identical to that earlier receipt (`458f7d…`). Since the prior failure did not recur on the current source, this run establishes current green behavior and does not certify the exact historical cause.

`qualification-source.zip` contains the original helper manifest, full captured source patch and captured untracked files. The `source/` copies are the exact selected registry test and SQL/schema owner files; their hashes match the full pin manifest. The test executed from the frozen dependency mirror under the shared PG lock.
