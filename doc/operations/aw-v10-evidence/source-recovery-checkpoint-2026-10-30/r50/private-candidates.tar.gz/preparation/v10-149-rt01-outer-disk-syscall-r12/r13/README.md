# V10-149 RT-01 private R13 credential host hardening

R13 is a two-file follow-up to the private R12 source candidate. It tightens the raw-read helper precondition to require an executable file and adds an assertion that no sandbox-exec argv contains the qualification token. The complete 12-path stage set is listed for the composed candidate; only `deploy/v6/host-agent/openshell.mjs` and `deploy/v6/host-agent/openshell.test.mjs` differ from R12. R12 remains available with its original hashes and receipts; `source.patch` here reconstructs only this follow-up from that exact R12 source.

The complete candidate pins are in `source-pins.json`. The host suite passed 51/51 under the canonical flock using mocked Docker and OpenShell CLI. The raw log is `openshell.test.log`. No Cargo compilation/tests, live credential issuer/provider call, or physical host qualification ran. These tests exercise host-side policy decisions and cleanup; they do not establish physical enforcement.
