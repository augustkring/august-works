import fs from 'node:fs';
import vm from 'node:vm';
import http from 'node:http';
import {once} from 'node:events';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
const require=createRequire('/workspace/v10-dep-qualification/package.json');
const {transformSync}=require('esbuild');
const root='/workspace/v10-preparation/native-http-request-overload-regression-r146';
const sources=[
 {name:'old-r5',path:'/workspace/v10-preparation/host-conversation-offline-erasure-factory-r5/files/server/src/__tests__/helpers/managed-native-conversation-sandbox-host.ts',sha:'efc7edc7043da1c940d61f6d8594fe9de79c6ee39dc44655ec5352fd238e78d5'},
 {name:'fixed-r6',path:'/workspace/v10-preparation/host-conversation-offline-erasure-factory-r6/files/server/src/__tests__/helpers/managed-native-conversation-sandbox-host.ts',sha:'16e9c5e9d9094a245f431c4501df74a84654123284af062e9cd35ffee443cebd'},
];
const hash=s=>createHash('sha256').update(s).digest('hex');
function wrapper(source){
 const bytes=fs.readFileSync(source.path);if(hash(bytes)!==source.sha)throw Error('source_pin_changed');
 const text=bytes.toString('utf8'),begin=text.indexOf('    http.request = ((');
 if(begin<0)throw Error('source_wrapper_missing');
 const finish=text.indexOf('}) as typeof http.request;',begin);if(finish<0)throw Error('source_wrapper_end_missing');
 const expression=text.slice(begin+'    http.request = '.length,finish+'}) as typeof http.request'.length);
 const js=transformSync(`const requestWrapper = ${expression};`,{loader:'ts',target:'node24',format:'cjs'}).code;
 const factory=vm.runInNewContext(`${js}\nrequestWrapper;`,{http,originalDockerHttpRequest:http.request,dockerHttpRequestBeforeFixture:http.request},{timeout:1000});
 return {request:factory,expressionSha256:hash(expression)};
}
const body='native-http-overload-fixture';
const server=http.createServer((_req,res)=>{res.writeHead(200,{'content-type':'text/plain','connection':'close'});res.end(body);});
server.listen(0,'127.0.0.1');await once(server,'listening');const address=server.address();
if(!address||typeof address==='string')throw Error('loopback_binding_missing');
const endpoint=new URL(`http://127.0.0.1:${address.port}/fixed`);const results=[];
async function call(request,form){return new Promise(resolve=>{
 let req,done=false;const finish=result=>{if(done)return;done=true;clearTimeout(timer);req?.destroy();resolve(result);};
 const timer=setTimeout(()=>finish({completed:false,reason:'callback_not_delivered'}),300);
 const receive=response=>{const chunks=[];response.on('data',c=>chunks.push(c));response.on('end',()=>finish({completed:true,status:response.statusCode,exactBody:Buffer.concat(chunks).toString('utf8')===body}));response.on('error',()=>finish({completed:false,reason:'response_error'}));};
 try{req=form==='url_options_callback'?request(endpoint,{method:'GET',agent:false},receive):request({hostname:'127.0.0.1',port:address.port,path:'/fixed',method:'GET',agent:false},receive);req.on('error',()=>finish({completed:false,reason:'request_error'}));req.end();}catch{finish({completed:false,reason:'request_threw'});}
 });}
try{
 for(const source of sources){const selected=wrapper(source);for(const form of ['options_callback','url_options_callback'])results.push({source:source.name,sourceSha256:source.sha,expressionSha256:selected.expressionSha256,form,...await call(selected.request,form)});if(hash(fs.readFileSync(source.path))!==source.sha)throw Error('source_changed_during_regression');}
 const old2=results.find(r=>r.source==='old-r5'&&r.form==='options_callback'),old3=results.find(r=>r.source==='old-r5'&&r.form==='url_options_callback');const fixed=results.filter(r=>r.source==='fixed-r6');
 if(!old2?.completed||old2.status!==200||!old2.exactBody||old3?.completed||fixed.length!==2||fixed.some(r=>!r.completed||r.status!==200||!r.exactBody))throw Error('differential_not_proven');
 const receipt={scope:'Exact helper wrapper expressions; real local HTTP; no Docker branch/PG/SDK/public seam or production change',passed:true,results};fs.writeFileSync(`${root}/qualification-receipt.json`,JSON.stringify(receipt,null,2)+'\n',{mode:0o600});console.log(JSON.stringify(receipt));
}finally{server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
