import { createHash } from "node:crypto";
import { constants } from "node:fs";
import { lstat, open, readdir, realpath } from "node:fs/promises";
import path from "node:path";

export const NATIVE_WORKSPACE_WITNESS_MAX_FILES = 512;
// A pair of base64 snapshots must fit within the authenticated runner control
// frame. The runner's 64 KiB outer frame hex-encodes ciphertext, leaving about
// 32 KiB for plaintext; keep each workspace phase small to reserve room for
// the exact SDK tool input and result.
export const NATIVE_WORKSPACE_WITNESS_MAX_BYTES = 4 * 1024;

export interface NativeWorkspaceWitnessFile {
  relativePath: string;
  sha256: string;
  size: number;
  contentBase64: string;
  device: number;
  inode: number;
  mtimeMs: number;
}

export interface NativeWorkspaceWitness {
  schema: "paperclip.native-workspace-witness.v1";
  workspaceRootDigest: string;
  snapshotDigest: string;
  fileCount: number;
  totalBytes: number;
  files: NativeWorkspaceWitnessFile[];
  excludedSymlinks: [];
}

/**
 * Hashes and retains a small source snapshot beneath the server-selected cwd.
 * Paths come from tool input only as relative targets; cwd/transcript values
 * supplied by the model are never used to choose the root.
 */
export async function captureNativeWorkspaceWitness(input: {
  trustedRoot: string;
  toolName: string;
  toolInput: unknown;
}): Promise<NativeWorkspaceWitness> {
  const root = await realpath(input.trustedRoot);
  const rootStat = await lstat(root);
  if (!rootStat.isDirectory() || rootStat.isSymbolicLink()) {
    throw new Error("native_workspace_root_invalid");
  }

  const files: NativeWorkspaceWitnessFile[] = [];
  let totalBytes = 0;

  const addFile = async (relativePath: string): Promise<void> => {
    const absolute = path.resolve(root, relativePath);
    const rel = path.relative(root, absolute);
    if (!rel || rel.startsWith(".." + path.sep) || path.isAbsolute(rel)) {
      throw new Error("native_workspace_path_outside_root");
    }
    const segments = rel.split(path.sep);
    let parent = root;
    for (const segment of segments.slice(0, -1)) {
      parent = path.join(parent, segment);
      let parentStat;
      try {
        parentStat = await lstat(parent);
      } catch (error) {
        throw error;
      }
      if (parentStat.isSymbolicLink() || !parentStat.isDirectory()) {
        throw new Error("native_workspace_path_component_unsafe");
      }
    }

    let before;
    try {
      before = await lstat(absolute);
    } catch (error) {
      throw error;
    }
    if (before.isSymbolicLink() || !before.isFile() || await realpath(absolute) !== absolute) {
      throw new Error("native_workspace_file_type_unsafe");
    }
    if (before.size > NATIVE_WORKSPACE_WITNESS_MAX_BYTES) {
      throw new Error("native_workspace_witness_byte_limit");
    }
    const handle = await open(absolute, constants.O_RDONLY | noFollowFlag());
    try {
      const opened = await handle.stat();
      if (
        !opened.isFile() ||
        opened.dev !== before.dev ||
        opened.ino !== before.ino ||
        opened.size !== before.size
      ) throw new Error("native_workspace_file_changed_during_capture");
      const content = await handle.readFile();
      const after = await handle.stat();
      const pathAfter = await lstat(absolute);
      if (
        content.byteLength !== opened.size ||
        after.dev !== opened.dev ||
        after.ino !== opened.ino ||
        after.size !== opened.size ||
        after.mtimeMs !== opened.mtimeMs ||
        pathAfter.isSymbolicLink() ||
        await realpath(absolute) !== absolute ||
        pathAfter.dev !== opened.dev ||
        pathAfter.ino !== opened.ino
      ) throw new Error("native_workspace_file_changed_during_capture");
      totalBytes += content.byteLength;
      if (totalBytes > NATIVE_WORKSPACE_WITNESS_MAX_BYTES) {
        throw new Error("native_workspace_witness_byte_limit");
      }
      files.push({
        relativePath: rel.split(path.sep).join("/"),
        sha256: createHash("sha256").update(content).digest("hex"),
        size: content.byteLength,
        contentBase64: content.toString("base64"),
        device: opened.dev,
        inode: opened.ino,
        mtimeMs: opened.mtimeMs,
      });
    } finally {
      await handle.close();
    }
  };

  await addTree(root, "", addFile, files);
  files.sort((a, b) => a.relativePath < b.relativePath ? -1 : a.relativePath > b.relativePath ? 1 : 0);
  if (files.length > NATIVE_WORKSPACE_WITNESS_MAX_FILES) {
    throw new Error("native_workspace_witness_file_limit");
  }
  const digestInput = files.map(({ relativePath, sha256, size }) => ({
    path: relativePath,
    hash: sha256,
    size,
  }));
  return {
    schema: "paperclip.native-workspace-witness.v1",
    workspaceRootDigest: `sha256:${createHash("sha256").update(root).digest("hex")}`,
    snapshotDigest: `sha256:${createHash("sha256").update(canonicalNativeJson(digestInput)).digest("hex")}`,
    fileCount: files.length,
    totalBytes,
    files,
    excludedSymlinks: [],
  };
}


async function addTree(
  root: string,
  relative: string,
  addFile: (relativePath: string) => Promise<void>,
  files: NativeWorkspaceWitnessFile[],
): Promise<void> {
  const directory = relative ? path.join(root, relative) : root;
  const before = await lstat(directory);
  if (before.isSymbolicLink() || !before.isDirectory() || await realpath(directory) !== directory) {
    throw new Error("native_workspace_directory_unsafe");
  }
  const entries = await readdir(directory, { withFileTypes: true });
  for (const entry of entries) {
    if (!entry.name || entry.name === "." || entry.name === ".." || entry.name.includes(path.sep)) {
      throw new Error("native_workspace_entry_name_invalid");
    }
    const child = relative ? path.join(relative, entry.name) : entry.name;
    const childPath = path.join(root, child);
    const childStat = await lstat(childPath);
    if (childStat.isSymbolicLink()) throw new Error("native_workspace_symlink_rejected");
    if (childStat.isDirectory()) {
      await addTree(root, child, addFile, files);
    } else if (childStat.isFile()) {
      if (files.length >= NATIVE_WORKSPACE_WITNESS_MAX_FILES) {
        throw new Error("native_workspace_witness_file_limit");
      }
      await addFile(child);
    } else {
      throw new Error("native_workspace_entry_type_unsafe");
    }
  }
  const after = await lstat(directory);
  if (after.isSymbolicLink() || after.dev !== before.dev || after.ino !== before.ino ||
      await realpath(directory) !== directory) {
    throw new Error("native_workspace_directory_changed_during_capture");
  }
}

function noFollowFlag(): number {
  const flag = constants.O_NOFOLLOW;
  if (typeof flag !== "number") throw new Error("native_workspace_no_follow_unavailable");
  return flag;
}

function canonicalNativeJson(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonicalNativeJson).join(",")}]`;
  if (typeof value === "object" && value !== null) {
    const record = value as Record<string, unknown>;
    return `{${Object.keys(record)
      .filter((key) => record[key] !== undefined)
      .sort()
      .map((key) => `${JSON.stringify(key)}:${canonicalNativeJson(record[key])}`)
      .join(",")}}`;
  }
  return JSON.stringify(value) ?? "null";
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
