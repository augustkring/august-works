from pathlib import Path
import hashlib,json,difflib
r=Path('/workspace/blentera-v10');rel='server/src/__tests__/native-payload-temporal-sources.integration.test.ts';a=(r/rel).read_text();s=a
needle='''      expect(await canActorReadMemorySourceSet(tx, first.companyId, second.bobActor,
        [memoryAId!, memoryCId!], undefined, store)).toBe(false);
'''
addition='''      // A warm child Task-prefix obligation is a current-owner witness, not
      // an allow result. Editing that retained Task in this same transaction
      // must invalidate the Memory reader, while rollback restores its prefix.
      await tx.execute(sql`savepoint native_scoped_task_owner_mutation`);
      try {
        await tx.update(issues).set({ description: sql`coalesce(${issues.description},'') || ${" Scoped Task owner changed"}` })
          .where(and(eq(issues.companyId, first.companyId), eq(issues.id, temporal.taskBId!)));
        expect(await canActorReadMemorySources(tx, first.companyId, second.aliceActor, memoryCId!,
          { structuralProofMemoStore: store })).toBe(false);
      } finally {
        await tx.execute(sql`rollback to savepoint native_scoped_task_owner_mutation`);
        await tx.execute(sql`release savepoint native_scoped_task_owner_mutation`);
      }
      expect(await canActorReadMemorySources(tx, first.companyId, second.aliceActor, memoryCId!,
        { structuralProofMemoStore: store })).toBe(true);
      expect(await canActorReadMemorySources(tx, first.companyId, second.bobActor, memoryCId!,
        { structuralProofMemoStore: store })).toBe(false);
      expect(await canActorReadMemorySources(tx, first.companyId, second.bobActor, memoryAId!,
        { structuralProofMemoStore: store })).toBe(true);
'''
assert s.count(needle)==1;s=s.replace(needle,needle+addition,1)
o=Path('/workspace/v10-preparation/native-task-prefix-scope-r62-candidate');p=o/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
(o/'regression.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
manifest=json.loads((o/'manifest.json').read_text());manifest[rel]={'priorSha256':hashlib.sha256(a.encode()).hexdigest(),'candidateSha256':hashlib.sha256(s.encode()).hexdigest()};(o/'manifest.json').write_text(json.dumps(manifest,indent=2))
