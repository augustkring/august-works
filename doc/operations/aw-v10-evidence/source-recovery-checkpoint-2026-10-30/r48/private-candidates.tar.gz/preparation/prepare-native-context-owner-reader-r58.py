from pathlib import Path
import hashlib,json,difflib
r=Path('/workspace/blentera-v10');o=Path('/workspace/v10-preparation/native-context-owner-reader-r58-candidate');rel='server/src/services/native-direct-input.ts';a=(r/rel).read_text();s=a
needle='''  historicalDocumentDepthHint = 0): Promise<void> {
  if (scope.active.has(key))''';assert needle in s;s=s.replace(needle,'''  historicalDocumentDepthHint = 0, deferSourceSetReader = true): Promise<void> {
  if (scope.active.has(key))''',1)
needle='''    recordNativeProofReaderSetUse(scope, proof.readerSets);
    deferNativeSourceReaderCheck(scope, input);
    propagateNativeMutableSources(scope, proof.mutableSources);''';assert needle in s
s=s.replace(needle,'''    recordNativeProofReaderSetUse(scope, proof.readerSets);
    if (deferSourceSetReader) deferNativeSourceReaderCheck(scope, input);
    else {
      // Owner-only nodes already registered their exact readers. A repeated
      // use after a flush must still schedule those current checks again.
      const readerKey = `${input.companyId}:${nativeSha256(input.actor)}`;
      if (scope.context.deferredReaderChecks.has(readerKey) && !scope.context.activeReaderChecks.has(readerKey))
        scope.context.pendingReaderChecks.add(readerKey);
    }
    propagateNativeMutableSources(scope, proof.mutableSources);''',1)
needle='''      deferNativeSourceReaderCheck(scope, reader);
    });
    // A hit carries the exact current Task pins/readers''';assert needle in s
s=s.replace(needle,'''    }, 0, false);
    // A hit carries the exact current Task pins/readers''',1)
p=o/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);(o/'candidate.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)));(o/'manifest.json').write_text(json.dumps({rel:{'priorSha256':hashlib.sha256(a.encode()).hexdigest(),'candidateSha256':hashlib.sha256(s.encode()).hexdigest()}},indent=2))
