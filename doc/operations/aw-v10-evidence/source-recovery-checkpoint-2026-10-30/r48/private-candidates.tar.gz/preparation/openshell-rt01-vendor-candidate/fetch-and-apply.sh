#!/usr/bin/env bash
set -euo pipefail

bundle_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
target="${1:?usage: fetch-and-apply.sh NEW_CHECKOUT_PATH}"
repository="https://github.com/NVIDIA/OpenShell.git"
revision="6648bd0c290efbc41ba131ee9831ee45cd431f94"
if [[ -e "$target" ]]; then
  echo "refusing fetch: destination already exists: $target" >&2
  exit 73
fi
mkdir -p "$(dirname -- "$target")"
git clone --filter=blob:none --no-checkout "$repository" "$target"
git -C "$target" checkout --detach "$revision"
actual="$(git -C "$target" rev-parse HEAD)"
if [[ "$actual" != "$revision" ]]; then
  echo "refusing patch: fetched commit does not match pinned revision" >&2
  exit 65
fi
"$bundle_dir/apply-patch.sh" "$target"
