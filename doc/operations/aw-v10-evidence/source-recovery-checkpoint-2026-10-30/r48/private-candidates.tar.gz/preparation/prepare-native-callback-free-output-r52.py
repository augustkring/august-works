from pathlib import Path
import hashlib,json,difflib
r=Path('/workspace/blentera-v10');o=Path('/workspace/v10-preparation/native-callback-free-output-r52-candidate');rel='server/src/services/native-direct-input.ts';a=(r/rel).read_text();s=a
needle='''  return withNativeMemoryOutputSnapshotCurrent(db, input, async () => undefined);''';assert s.count(needle)==1
s=s.replace(needle,'''  return inNativeSourceReadTransaction(db, tx => withNativeSourceReadScope(tx, input.actor, input.companyId, async scope => {
    await lockNativeSourceReadPrivacy(tx, input.companyId, scope);
    return assertNativeMemoryOutputSnapshotCurrentInScope(tx, input, scope);
  }));''',1)
p=o/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);(o/'candidate.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)));(o/'manifest.json').write_text(json.dumps({rel:{'priorSha256':hashlib.sha256(a.encode()).hexdigest(),'candidateSha256':hashlib.sha256(s.encode()).hexdigest()}},indent=2))
