from pathlib import Path
p=Path('/workspace/blentera-v10/server/src/services/native-direct-input.ts');s=p.read_text()
Path('/workspace/v10-preparation/native-before-speculative-memo-removal-20261030.ts').write_text(s)
s=s.replace('  completedNativeModelOutputCaptureProofs: Set<string>;\n','')
a=s.index('const nativeSourceReadTransactionOrdinals =');b=s.index('const nativeSourceMemoDiagnostics =',a);s=s[:a]+s[b:]
s=s.replace('return { work: 0, activeByActor: new Map(), completedNativeModelOutputCaptureProofs: new Set(),','return { work: 0, activeByActor: new Map(),')
a=s.index('  // Keep completed structural captures transaction-local');b=s.index('  const context: NativeSourceReadContext',a);s=s[:a]+s[b:]
a=s.index('  const proofKey = nativeSha256({ phase: "native-model-output-capture"');b=s.index('  if (scope.context.ancestry.work > 512)',a);s=s[:a]+s[b:]
a=s.index('  if (completedCaptureClosure) {');b=s.index('    await assertNativeManagedConsumedSourceSetCurrentInScope',a)
c=s.index('  for (const memoryId',b)
s=s[:a]+s[b:c].replace('    await assert','  await assert',1).replace('  }\n','',1)+s[c:]
s=s.replace('''  if (captureClosureMemoEligible && scope.context.ancestry.completedNativeModelOutputCaptureProofs.size < 512)
    scope.context.ancestry.completedNativeModelOutputCaptureProofs.add(proofKey);
''','')
a=s.index('  const captureInputs = input.proofCaptureInputs;');b=s.index('  const policy = snapshot.policy;',a);s=s[:a]+s[b:]
s=s.replace('  if (proofKey && documentProofs && documentProofs.size < 512) documentProofs.add(proofKey);\n','')
p.with_suffix('.nomemo.tmp.ts').write_text(s)
