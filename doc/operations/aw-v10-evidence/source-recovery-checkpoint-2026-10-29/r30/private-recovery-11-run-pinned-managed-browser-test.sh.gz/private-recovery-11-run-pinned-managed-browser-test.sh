#!/usr/bin/env bash
set -euo pipefail

# Fail before queueing a qualification if the real browser is unavailable.
export PAPERCLIP_PLAYWRIGHT_EXECUTABLE="${PAPERCLIP_PLAYWRIGHT_EXECUTABLE:-/usr/bin/chromium}"
if [[ ! -x "$PAPERCLIP_PLAYWRIGHT_EXECUTABLE" ]]; then
  echo "qualified managed browser requires an executable Chromium" >&2
  exit 78
fi
browser_version="$("$PAPERCLIP_PLAYWRIGHT_EXECUTABLE" --version 2>/dev/null)"
if [[ ! "$browser_version" =~ Chromium|Chrome ]]; then
  echo "PAPERCLIP_PLAYWRIGHT_EXECUTABLE must identify Chromium or Chrome" >&2
  exit 78
fi

name="${1:?usage: run-managed-opencode-baseline.sh UNIQUE_ATTEMPT_NAME}"
if [[ ! "$name" =~ ^[A-Za-z0-9][A-Za-z0-9._-]{1,100}$ ]]; then
  echo "invalid attempt name" >&2
  exit 64
fi
# Reject incorrect cwd-relative paths before occupying the serialized test queue.
test_file="${2:?test file relative to server}"
if [[ "$test_file" != src/*.test.ts || "$test_file" == *..* || ! -f "/workspace/blentera-v10/server/$test_file" ]]; then
  echo "test file must exist relative to server (src/..., without server/ prefix)" >&2
  exit 64
fi
exec flock -x /workspace/v10-preparation/v10-pg-tests.lock bash -lc '
set +e
source /workspace/v10-preparation/env.sh
# Bound each Node process so Chromium and the real Native runner retain headroom.
export NODE_OPTIONS=--max-old-space-size=3072
export PATH=/workspace/v10-preparation/pinned-bin:$PATH
NAME="$1"
TEST_FILE="$2"
TEST_PATTERN="$3"
TEST_TIMEOUT="${PAPERCLIP_PINNED_NATIVE_TEST_TIMEOUT_SECONDS:-240}"
OUT=/workspace/v10-preparation
ROOT=/workspace/v10-dep-qualification
BINARY=/workspace/.cloud-setup/lockfile/node_modules/.pnpm/opencode-linux-x64@1.18.32/node_modules/opencode-linux-x64/bin/opencode
EXPECTED=513f500a1a5ea1dc7d865547ac87b32a8936334e8d5abd5b3ff585c45a170080
if [[ ! "$TEST_TIMEOUT" =~ ^[0-9]{1,3}$ ]] || (( TEST_TIMEOUT < 240 || TEST_TIMEOUT > 600 )); then
  echo "pinned native test timeout must be an integer from 240 through 600 seconds" >&2
  exit 64
fi
printf "whole-suite timeout seconds: %s\n" "$TEST_TIMEOUT"
for suffix in source-pins.json snapshot.log snapshot.exit syntax.log syntax.exit binary.sha256 binary.path runner.txt test.log test.exit exit; do
  if [[ -e "$OUT/$NAME-$suffix" || -e "$OUT/$NAME.$suffix" ]]; then
    echo "attempt artifact already exists: $NAME" >&2
    exit 73
  fi
done
printf "node_heap_mb=3072\ntimeout_seconds=%s\ntest_file=%s\ntest_pattern=%s\n" "$TEST_TIMEOUT" "$TEST_FILE" "$TEST_PATTERN" \
  > "$OUT/$NAME-runner.txt"
actual="$(sha256sum "$BINARY" | awk "{print \$1}")"
printf "%s\n" "$actual" > "$OUT/$NAME-binary.sha256"
printf "%s\n" "$BINARY" > "$OUT/$NAME-binary.path"
if [[ "$actual" != "$EXPECTED" ]]; then
  echo "qualified OpenCode binary SHA mismatch" > "$OUT/$NAME-snapshot.log"
  printf "78\n" > "$OUT/$NAME.exit"
  exit 78
fi
export PAPERCLIP_QUALIFIED_OPENCODE_BINARY="$BINARY"
python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$OUT/$NAME-source-pins.json" > "$OUT/$NAME-snapshot.log" 2>&1
snap=$?
printf "%s\n" "$snap" > "$OUT/$NAME-snapshot.exit"
if [[ "$snap" -ne 0 ]]; then printf "%s\n" "$snap" > "$OUT/$NAME.exit"; exit "$snap"; fi
# Parse every copied current-source file, including the selected test and all
# changed dependencies, rather than a fixed list of six Native files.
node /workspace/v10-preparation/check-snapshot-syntax.cjs "$OUT/$NAME-source-pins.json" > "$OUT/$NAME-syntax.log" 2>&1
syntax_rc=$?
printf "%s\n" "$syntax_rc" > "$OUT/$NAME-syntax.exit"
if [[ "$syntax_rc" -ne 0 ]]; then printf "%s\n" "$syntax_rc" > "$OUT/$NAME.exit"; exit "$syntax_rc"; fi
cd "$ROOT/server"
if [[ "${PAPERCLIP_NATIVE_SOURCE_MEMO_DIAGNOSTICS:-0}" == "1" ]]; then
  PAPERCLIP_NATIVE_SOURCE_MEMO_DIAGNOSTICS=1 timeout --signal=TERM --kill-after=10s "${TEST_TIMEOUT}s" python3 /workspace/v10-preparation/run-with-owned-child-cleanup.py ../node_modules/.bin/vitest run \
    "$TEST_FILE" \
    -t "$TEST_PATTERN" --reporter=verbose \
    > "$OUT/$NAME-test.log" 2>&1
else
  timeout --signal=TERM --kill-after=10s "${TEST_TIMEOUT}s" python3 /workspace/v10-preparation/run-with-owned-child-cleanup.py ../node_modules/.bin/vitest run \
    "$TEST_FILE" \
    -t "$TEST_PATTERN" --reporter=verbose \
    > "$OUT/$NAME-test.log" 2>&1
fi
run_rc=$?
printf "%s\n" "$run_rc" > "$OUT/$NAME-test.exit"
executed="$(python3 - "$OUT/$NAME-test.log" <<"PY"
import re,sys
text=open(sys.argv[1],encoding="utf-8",errors="replace").read()
lines=re.findall(r"^\s*Tests\s+(.+?)\s+\((\d+)\)\s*$",text,re.M)
if not lines:
    print(0)
    raise SystemExit
parts,total=lines[-1]
counts={name:int(count) for count,name in re.findall(r"(\d+)\s+(passed|failed|skipped|todo|pending)",parts)}
print(counts.get("passed",0)+counts.get("failed",0))
PY
)"
if [[ "$executed" -lt 1 ]]; then
  echo "Vitest execution count is zero or unverified (all skipped or completion summary missing)" >> "$OUT/$NAME-test.log"
  guard_rc=79
else
  guard_rc=0
fi
if [[ "$run_rc" -ne 0 ]]; then final_rc="$run_rc"; else final_rc="$guard_rc"; fi
printf "%s\n" "$final_rc" > "$OUT/$NAME.exit"
exit "$final_rc"
' _ "$name" "${2:?test file relative to server}" "${3:?exact test title pattern}"
