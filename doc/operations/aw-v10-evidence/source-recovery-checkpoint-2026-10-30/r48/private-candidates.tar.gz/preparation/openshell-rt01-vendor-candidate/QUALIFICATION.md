# Private RT-01 expected-identity patch candidate

This bundle targets NVIDIA/OpenShell v0.1.2 at commit `6648bd0c290efbc41ba131ee9831ee45cd431f94`. It adds distinct identity-bound RPC names and CLI routing for Start, Stop, Delete, policy changes, and unary Exec. Existing RPCs keep their name-scoped contract. The distinct method names make an old gateway return `UNIMPLEMENTED` instead of silently ignoring an unknown field. The identity requests use the existing mutation-replay admission path, and their expected UUID is part of the replayed request fingerprint.

`fetch-and-apply.sh` clones the upstream repository and checks out the exact commit before applying. `apply-patch.sh` verifies the exact base commit, a clean checkout, and patch SHA256. These scripts only prepare a local source tree; they do not publish, contact maintainers, or qualify a runtime. The original source checkout used to prepare this patch remains untouched.

## Build and test route

OpenShell's protobuf generation is performed by `crates/openshell-core/build.rs` and `crates/openshell-server/build.rs` using the workspace's `protoc-bin-vendored` dependency; no system `protoc` installation is required. The dependency may still need to be fetched. Use Rust toolchain `1.97.1` explicitly because the pinned checkout's `rust-toolchain.toml` otherwise requests a different version.

After integrating into a clean checkout and measuring sufficient disk space for a cold Rust build, run these sequentially under the canonical qualification lock:

```sh
source /workspace/v10-preparation/env.sh
export RUSTUP_TOOLCHAIN=1.97.1
cargo fmt --all -- --check
cargo test --locked -p openshell-server identity_bound_stop_targets_the_observed_uuid_only
cargo test --locked -p openshell-server identity_delete_rejects_same_name_replacement_without_deleting_it
cargo test --locked -p openshell-server identity_delete_requires_an_expected_uuid
cargo test --locked -p openshell-server identity_policy_update_rejects_same_name_replacement_before_mutation
cargo test --locked -p openshell-server identity_exec_rejects_same_name_replacement_before_opening_relay
cargo test --locked -p openshell-cli sandbox_stop_and_start_accept_optional_names
cargo check --locked -p openshell-server -p openshell-cli
```

These focused tests cover UUID match, same-name replacement rejection without target effects, missing-ID rejection, unary exec replacement rejection, and CLI flag parsing. Existing lifecycle tests continue exercising absent-ID legacy behavior. Add a live old-gateway compatibility probe confirming each new RPC returns `UNIMPLEMENTED` before any host rollout. Physical RT-01 target-host probes from the binding brief remain separate and are not satisfied by this source patch.

## Current validation

`git diff --check` and `git apply --check` passed against the untouched pinned base. Rust formatting/parser checks now pass under the canonical flock. Protobuf generation, Cargo tests/check, old-server RPC probe, and physical runtime probes remain pending. Available disk is about 1.2 GB with no reusable Rust target tree, so no cold build was started.
