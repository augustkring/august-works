# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: aw-v9-insight-experiments.spec.ts >> Insights reads a stopped experiment without inventing an effect or exposing unit registers
- Location: tests/e2e/aw-v9-insight-experiments.spec.ts:24:1

# Error details

```
Error: 409: {"error":"Experiment owner must be a current company human"}

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Test source

```ts
  1  | import { createRequire } from "node:module";
  2  | import { readFile } from "node:fs/promises";
  3  | import { tmpdir } from "node:os";
  4  | import path from "node:path";
  5  | import { expect, test, type APIResponse } from "@playwright/test";
  6  | import { registerEnglishAccountLocaleIsolation } from "./account-locale-isolation";
  7  | import { createDb, closeRegisteredClients, issues, businessExperimentAnalyses } from "../../packages/db/src/index.ts";
  8  | import { eq } from "../../packages/db/node_modules/drizzle-orm/index.js";
  9  | import { businessMetricService } from "../../server/src/services/business-metrics/service.ts";
  10 | import { businessExperimentService } from "../../server/src/services/business-experiments/service.ts";
  11 | import { businessExperimentRecordingService } from "../../server/src/services/business-experiments/recording.ts";
  12 | import { businessExperimentAnalysisService } from "../../server/src/services/business-experiments/analysis.ts";
  13 | import { aiGovernanceService } from "../../server/src/services/ai-governance/governance-service.ts";
  14 | import { analyticalPurpose, metricDefinition } from "../../server/src/__tests__/helpers/business-metric-fixture.ts";
  15 | import { experimentDefinition } from "../../server/src/__tests__/helpers/business-experiment-fixture.ts";
  16 | import { ISSUE_STATUSES, insightExperimentSummarySchema, insightExperimentDetailSchema, insightExperimentPageSchema } from "../../packages/shared/src/index.ts";
  17 | const axePath = createRequire(import.meta.url).resolve("axe-core/axe.min.js");
  18 | registerEnglishAccountLocaleIsolation(test);
> 19 | async function json(response: APIResponse) { expect(response.ok(), `${response.status()}: ${await response.text()}`).toBe(true); return response.json(); }
     |                                                                                                                      ^ Error: 409: {"error":"Experiment owner must be a current company human"}
  20 | 
  21 | // Actual Native recording/stop/analysis/Source owners; explicit synthetic
  22 | // governance/activity/manager fixtures. No intervention, actual Human trial,
  23 | // causal effect, qualified numeric experiment or production outcome is claimed.
  24 | test("Insights reads a stopped experiment without inventing an effect or exposing unit registers", async ({ page, request }, info) => {
  25 |   const flags = await json(await request.get("/api/instance/settings/experimental"));
  26 |   const company = await json(await request.post("/api/companies", { data: { name: "Disposable experiment evidence" } }));
  27 |   const configPath = process.env.PAPERCLIP_E2E_SERVER_CONFIG!;
  28 |   expect(configPath.startsWith(path.join(tmpdir(), "paperclip-e2e-home-"))).toBe(true);
  29 |   const config = JSON.parse(await readFile(configPath, "utf8"));
  30 |   expect(path.resolve(config.database.embeddedPostgresDataDir)).toBe(path.join(path.dirname(configPath), "db"));
  31 |   const pid = await readFile(path.join(config.database.embeddedPostgresDataDir, "postmaster.pid"), "utf8");
  32 |   const databaseUrl = `postgres://paperclip:paperclip@127.0.0.1:${pid.split("\n")[3]}/paperclip`, db = createDb(databaseUrl);
  33 |   const actor = { type: "board" as const, source: "local_implicit" as const }, rationale = "Synthetic Human review for Native software verification only";
  34 |   let writes = 0; const responsePaths: string[] = [];
  35 |   page.on("request", req => { if (req.method() !== "GET" && /\/experiments/.test(req.url())) writes++; });
  36 |   page.on("response", response => { if (/\/experiments/.test(response.url())) responsePaths.push(new URL(response.url()).pathname); });
  37 |   try {
  38 |     await json(await request.patch("/api/instance/settings/experimental", { data: { experience_projection_v9: true, progressive_shell_v9: true,
  39 |       analytical_lineage_v8: true, business_metrics_v8: true, business_experiments_v8: true, ai_use_cases_v7: true, governance_evidence_v7: true } }));
  40 |     const purpose = analyticalPurpose(); purpose.analyticalPurpose!.capabilities = ["metrics", "experiment"];
  41 |     const policy = await aiGovernanceService(db).obligation(actor, company.id, purpose);
  42 |     const metrics = [], metricOwner = businessMetricService(db);
  43 |     for (const [index, status] of ["done", "cancelled", "in_progress"].entries()) {
  44 |       const created = await metricOwner.create(company.id, actor, { key: `trial_outcome_${index}`, definition: { ...metricDefinition(policy.id), calculation: { kind: "native_ratio", numerator: { entity: "issue", statuses: [status], projectId: null }, denominator: { entity: "issue", statuses: [...ISSUE_STATUSES], projectId: null } } } });
  45 |       await metricOwner.publish(company.id, actor, created.metric.id, { expectedRevision: 1, versionId: created.version.id }); metrics.push({ id: created.metric.id, versionId: created.version.id });
  46 |     }
  47 |     const definition = experimentDefinition(policy.id, metrics);
  48 |     definition.sampleOrDurationPlan.from = new Date(Date.now() + 1200).toISOString();
  49 |     definition.sampleOrDurationPlan.until = new Date(Date.parse(definition.sampleOrDurationPlan.from) + 60000).toISOString();
  50 |     definition.sampleOrDurationPlan.minimumAssignedUnits = 4;
  51 |     const registry = businessExperimentService(db), recording = businessExperimentRecordingService(db);
  52 |     const created = await registry.create(company.id, actor, { key: "recorded_stop", definition });
  53 |     await registry.transition(company.id, actor, created.experiment.id, { expectedRevision: 1, versionId: created.version.id, state: "in_review", rationale });
  54 |     await registry.transition(company.id, actor, created.experiment.id, { expectedRevision: 2, versionId: created.version.id, state: "ready", rationale });
  55 |     await recording.start(company.id, actor, created.experiment.id, { expectedRevision: 3, versionId: created.version.id, mode: "recording_only_human_attested_native_process", rationale });
  56 |     const remaining = Date.parse(definition.sampleOrDurationPlan.from) - Date.now() + 20;
  57 |     if (remaining > 0) await new Promise(resolve => setTimeout(resolve, remaining));
  58 |     const [unit] = await db.insert(issues).values({ companyId: company.id, status: "todo", title: "PRIVATE enrolled Source prose" }).returning();
  59 |     const assignment = await recording.assign(company.id, actor, created.experiment.id, { expectedRevision: 4, versionId: created.version.id, unitId: unit.id });
  60 |     await recording.recordExposure(company.id, actor, created.experiment.id, { expectedRevision: 4, versionId: created.version.id, assignmentId: assignment.id,
  61 |       exposure: { status: "not_applied", rationale: "Explicit synthetic non-application receipt; no actual intervention or Human trial" } });
  62 |     await recording.control(company.id, actor, created.experiment.id, { expectedRevision: 4, versionId: created.version.id, state: "completed", rationale,
  63 |       completion: { reason: "emergency_safety_stop", concurrentChangeReview: { assessment: "none_identified", rationale } } });
  64 |     const analyzed = await businessExperimentAnalysisService(db).analyze(company.id, actor, created.experiment.id, { expectedRevision: 5, versionId: created.version.id });
  65 |     expect(analyzed.analysis.result.numericallyQualified).toBe(false); expect(analyzed.analysis.result.metrics).toEqual([]);
  66 |     const summaryEndpoint = `/api/companies/${company.id}/experiments/${created.experiment.id}/versions/${created.version.id}/analysis-summary`;
  67 |     for (const [endpoint, schema] of [[`/api/companies/${company.id}/experiments`, insightExperimentPageSchema], [`/api/companies/${company.id}/experiments/${created.experiment.id}`, insightExperimentDetailSchema], [summaryEndpoint, insightExperimentSummarySchema]] as const) {
  68 |       const checked = schema.safeParse(await json(await request.get(endpoint)));
  69 |       expect(checked.success, checked.error?.issues.map(issue => `${issue.path.join(".")}: ${issue.message}`).join("; ")).toBe(true);
  70 |     }
  71 |     const initial = await db.select().from(businessExperimentAnalyses).where(eq(businessExperimentAnalyses.companyId, company.id));
  72 |     await page.route(`**/api/companies/${company.id}/experience?*`, route => route.fulfill({ headers: { "Cache-Control": "private, no-store" }, json: {
  73 |       companyId: company.id, profile: "manager", availableProfiles: ["member", "manager", "admin"], advancedLinks: [], generatedAt: new Date().toISOString(), dependencies: [], needsYou: [], inProgress: [], done: [], watch: [],
  74 |     } }));
  75 |     await page.goto(`/${company.issuePrefix}/insights`);
  76 |     const main = page.getByRole("main");
  77 |     await expect(main.getByRole("heading", { name: definition.name, exact: true })).toBeVisible();
  78 |     await expect(main).toContainText("The analysis is inconclusive."); await expect(main).toContainText("does not qualify a numerical effect");
  79 |     await expect(main).not.toContainText("PRIVATE enrolled"); await expect(main).not.toContainText("Difference:");
  80 |     expect(responsePaths.some(value => value.endsWith("/analysis-summary"))).toBe(true);
  81 |     expect(responsePaths.some(value => /\/(receipts|assignments|exposures)$/.test(value))).toBe(false);
  82 |     const summary = await json(await request.get(summaryEndpoint));
  83 |     expect(JSON.stringify(summary)).not.toContain(unit.id); expect(JSON.stringify(summary)).not.toContain(assignment.id);
  84 |     await page.setViewportSize({ width: 390, height: 844 });
  85 |     await page.getByRole("combobox", { name: "Language", exact: true }).selectOption("da");
  86 |     await expect(main.getByRole("heading", { name: "Gemte forsøgsresultater", exact: true })).toBeVisible(); await expect(main).toContainText("ikke en talmæssig effekt");
  87 |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  88 |     await page.addScriptTag({ path: axePath });
  89 |     expect((await page.evaluate(async () => (window as any).axe.run(document.querySelector("main"), { runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21aa"] } }))).violations).toEqual([]);
  90 |     await page.screenshot({ path: info.outputPath("insight-native-experiment-mobile-da.png"), fullPage: true });
  91 |     expect(writes).toBe(0); expect(await db.select().from(businessExperimentAnalyses).where(eq(businessExperimentAnalyses.companyId, company.id))).toEqual(initial);
  92 |     await db.update(issues).set({ hiddenAt: new Date() }).where(eq(issues.id, unit.id));
  93 |     expect((await request.get(summaryEndpoint)).status()).toBe(404);
  94 |     await page.reload(); await expect(main.getByRole("heading", { name: definition.name, exact: true })).toHaveCount(0);
  95 |   } finally {
  96 |     await page.goto("about:blank"); await request.patch("/api/instance/settings/experimental", { data: flags }); await closeRegisteredClients(databaseUrl);
  97 |   }
  98 | });
  99 | 
```