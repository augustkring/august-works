# V10-169 current migration phase index — 2026-10-30

This dated register supplements, and does not overwrite, the historical 169-row reconciliation at `doc/operations/aw-v10-evidence/recovery-2026-10-22/requirement-reconciliation.json`. That original V10-169 row remains `historical_partial_evidence_open`. The new JSON indexes every affected migration SQL file added since source-base commit `81d3445b98b1cd80ff400ede6bd44ea71d88d735` (0502–0564, 63 files at capture), cross-checking the current migration journal before assigning each to an owner group, records durable state/writer/compatibility/recovery expectations, pins the source inputs, and links concrete PostgreSQL test cases.

The register is intentionally a phase index, not a whole migration or release qualification. It does not claim hosted rollout, arbitrary backup restore, provider behavior, old/new binary fleet compatibility, operator execution, or Human acceptance. Current software refuses old or unknown provenance when it cannot prove the owner binding; operators must drain or keep admission closed where an old writer cannot preserve current bindings. No universal N-1 or zero-downtime promise is made. Use the state-specific gates in `phase-matrix.json`; do not run down migrations or rewrite migration history. Where old code is not valid against current durable state, pause/isolate and roll forward or restore into quarantine under the existing recovery owner.

The source-base diff includes: 0502 board-key security-event audit fields/constraints; 0503 issue/project access grants, privacy lineage and private visibility; and 0504 bounded Memory/Project source provenance. These earlier migrations are in the authentication, privacy-lineage and Native provenance groups respectively. The latest published official migration in this source pin is 0564 (`7c50fce45`); the checked-out HEAD is `45e3edba7a712d765636e6aa44a2e52844dcb4ff`; every pinned worktree file has an exact SHA-256, and dirty pinned paths are identified in the JSON. Private 0565 Responsibility and 0566 Feedback candidates are listed only as pending, unpublished and unqualified. When those migrations publish, extend this matrix with their writers, durable state, owner/tests, compatibility, recovery, and source pins before treating them as covered.

Concrete software cases linked by phase include:

- **Add/expand:** payload snapshot binding retained across operational updates and immutable gated trust grants.
- **Backfill/reconcile:** invalid legacy Memory snapshot is invalidated during migration; expired imports reconcile in bounded batches.
- **Cutover/drain and rollback:** operational guidance is linked, while the actual deployed writer fleet and chosen drain window remain operator evidence.
- **Restart/retry:** import worker death before receipt, restart-inconclusive cancellation, and Native cleanup admission while an executor settles.
- **Restore:** derived Memory tombstones replay after restore, late restored writes stay blocked, and pre-V9 erasure receipts upgrade to immutable identities.
- **Unknown provenance:** old payloads remain unknown, current body bytes do not upgrade unknown Context, and uncertain import effects remain reconcilable rather than replayed.

The source check discovers migration SQL from `git diff --name-status <sourceBaseCommit> -- packages/db/src/migrations`; it does not infer the lower bound from a fixed migration number. The test suite covers missing affected migration mapping, missing SQL owner, changed source pin, and an unsupported `qualified` promotion. Package scripts and the existing V10 coverage workflow run both checks.

Run the lightweight consistency guard with:

```sh
node scripts/check-v10-169-migration-phase-register.mjs
```

It fails if a migration SQL file added/changed since the pinned source base is missing/duplicated, its owner/test source is absent or no longer matches its pin, a phase lacks concrete cases or carries an unsupported status, 0565/0566 appear published without a refreshed register, or a broader qualification claim is introduced without replacing the guardrails. It does not execute those DB tests; use their own source-pinned qualification records for results.
