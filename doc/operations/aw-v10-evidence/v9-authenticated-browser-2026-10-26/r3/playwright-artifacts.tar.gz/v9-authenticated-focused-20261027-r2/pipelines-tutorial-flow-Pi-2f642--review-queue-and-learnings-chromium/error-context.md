# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: pipelines-tutorial-flow.spec.ts >> Pipelines tutorial UI flow >> walks setup, intake, board moves, item detail, review queue, and learnings
- Location: tests/e2e/pipelines-tutorial-flow.spec.ts:441:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Tighten the framing before publishing.')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByText('Tighten the framing before publishing.')

```

```yaml
- link "Skip to Main Content":
  - /url: "#main-content"
- complementary:
  - button "Open E2E Pipelines 1793060268871 organization switcher": E E2E Pipelines 1793060268871
  - navigation:
    - link "Home":
      - /url: /EEPA/dashboard
    - link "Needs You":
      - /url: /EEPA/needs-you
    - link "Work":
      - /url: /EEPA/work
    - link "Agents":
      - /url: /EEPA/agents
    - link "Apps":
      - /url: /EEPA/apps
    - status: Additional navigation could not be loaded. Try Home again.
    - button "Ask Blentera"
    - link "Help / Support":
      - /url: /EEPA/company/help
- button "Open account menu": BR Browser product reviewer
- separator "Resize sidebar"
- region "Global utilities":
  - button "Ask Blentera"
  - text: Language
  - combobox "Language":
    - option "English" [selected]
    - option "Dansk"
  - link "Help / Support":
    - /url: /EEPA/company/help
  - link "Contact support":
    - /url: mailto:support@blentera.com
  - link "User account":
    - /url: /EEPA/company/settings/instance/profile
- heading "Learnings" [level=1]
- main:
  - heading "Learnings" [level=1]
  - paragraph: Patterns from review decisions and hand moves, in plain words.
  - paragraph: 1-2
  - heading "Today" [level=2]
  - text: just now
  - link "Someone approved 'Launch blog post' moving to Published.":
    - /url: /EEPA/pipelines/5fafcfc3-0751-428f-8208-d3205770a6e6/items/d57acedf-db46-45c0-8527-7ee1a60b4ffb
  - text: Content production just now
  - 'link "''Launch tweet'' was moved by hand from Drafting to Published - reason: Tweet can skip review because the blog post already covers the announcement.."':
    - /url: /EEPA/pipelines/5fafcfc3-0751-428f-8208-d3205770a6e6/items/1f80553e-d325-4923-be8c-d5c74b9cfb8e
  - text: Content production
  - button "Previous" [disabled]
  - text: 1-2
  - button "Next" [disabled]
- heading "Command Palette" [level=2]
- paragraph: Search for a command to run...
```

# Test source

```ts
  553 |     const tweet = items.find((row) => row.case.title === "Launch tweet")?.case;
  554 |     expect(blog).toBeTruthy();
  555 |     expect(changelog).toBeTruthy();
  556 |     expect(tweet).toBeTruthy();
  557 | 
  558 |     const blogDragged = await dragCardToColumn(page, "Launch blog post", "Drafting", "Assets");
  559 |     if (blogDragged) {
  560 |       await expect(page.getByRole("heading", { name: "Move Launch blog post?" })).toBeVisible();
  561 |       await page.getByRole("button", { name: "Move it" }).click();
  562 |     } else {
  563 |       await moveItem(board, blog!.id, assets!.key);
  564 |       await page.reload();
  565 |     }
  566 |     await expect(page.getByLabel("Assets column").getByText("Launch blog post")).toBeVisible();
  567 | 
  568 |     await moveItem(board, changelog!.id, assets!.key);
  569 |     await page.reload();
  570 |     await expect(page.getByLabel("Assets column").getByText("Changelog entry")).toBeVisible();
  571 | 
  572 |     const tweetDragged = await dragCardToColumn(page, "Launch tweet", "Drafting", "Published");
  573 |     const overrideReason = "Tweet can skip review because the blog post already covers the announcement.";
  574 |     if (tweetDragged) {
  575 |       await expect(page.getByRole("heading", { name: "This skips the normal flow" })).toBeVisible();
  576 |       await page.getByLabel("Reason").fill(overrideReason);
  577 |       await expect(page.getByRole("button", { name: "Override and move" })).toBeEnabled();
  578 |       await page.getByRole("button", { name: "Override and move" }).click();
  579 |     } else {
  580 |       await moveItem(board, tweet!.id, published!.key, { reason: overrideReason, force: true });
  581 |       await page.reload();
  582 |     }
  583 |     await expect(page.getByLabel("Published column").getByText("Launch tweet")).toBeVisible();
  584 |     await expectProsumerVocabulary(page);
  585 | 
  586 |     const root = await createItem(board, pipeline.id, {
  587 |       title: "Pipeline primitives launch",
  588 |       stageKey: "drafting",
  589 |       fields: { content_type: "Blog post" },
  590 |     });
  591 |     await createItem(board, pipeline.id, {
  592 |       title: "Launch package draft",
  593 |       stageKey: "drafting",
  594 |       parentCaseId: root.id,
  595 |       fields: { content_type: "Blog post" },
  596 |     });
  597 |     await createItem(board, pipeline.id, {
  598 |       title: "Launch package changelog",
  599 |       stageKey: "drafting",
  600 |       parentCaseId: root.id,
  601 |       fields: { content_type: "Changelog entry" },
  602 |     });
  603 |     await suggestMove(board, root.id, assets!.key, "Draft is ready for the next review.");
  604 | 
  605 |     await page.goto(`${companyPath}/pipelines/${pipeline.id}/items/${root.id}`);
  606 |     await expect(page.getByRole("heading", { name: "Pipeline primitives launch" }).first()).toBeVisible();
  607 |     await expect(page.getByRole("heading", { name: "Ready to move to Assets?" })).toBeVisible();
  608 |     await expect(page.getByText("Draft is ready for the next review.")).toBeVisible();
  609 |     await expect(page.getByRole("heading", { name: "Built from 2 items" })).toBeVisible();
  610 |     await expect(page.getByText("Launch package draft")).toBeVisible();
  611 |     await expect(page.getByText("Launch package changelog")).toBeVisible();
  612 |     await expectProsumerVocabulary(page);
  613 | 
  614 |     await page.getByRole("button", { name: "Approve" }).click();
  615 |     await expect(page.getByText("Move approved")).toBeVisible();
  616 |     await expect(page.getByRole("heading", { name: "Ready to move to Assets?" })).toBeHidden();
  617 | 
  618 |     await page.goto(`${companyPath}/review-queue`);
  619 |     await expect(page.getByRole("heading", { name: "Review queue" }).first()).toBeVisible();
  620 |     await expect(page.getByText("Needs your attention")).toBeVisible();
  621 |     await expect(page.getByText("Final calls")).toBeVisible();
  622 | 
  623 |     const blogRow = reviewQueueRow(page, "Launch blog post");
  624 |     await expect(blogRow).toBeVisible();
  625 |     await blogRow.getByRole("button", { name: "Approve", exact: true }).click();
  626 |     await expect(blogRow).toBeHidden();
  627 | 
  628 |     const changelogRow = reviewQueueRow(page, "Changelog entry");
  629 |     await expect(changelogRow).toBeVisible();
  630 |     await changelogRow.getByRole("button", { name: "Request changes" }).click();
  631 |     const decisionDialog = page.getByRole("dialog");
  632 |     await expect(decisionDialog).toBeVisible();
  633 |     await decisionDialog.getByLabel("Note").fill("Tighten the framing before publishing.");
  634 |     await decisionDialog.getByRole("button", { name: "Request changes" }).click();
  635 |     await expect(changelogRow).toBeHidden();
  636 |     await expectProsumerVocabulary(page);
  637 | 
  638 |     await expect.poll(async () => {
  639 |       const refreshed = await listItems(board, pipeline.id);
  640 |       const approved = refreshed.find((row) => row.case.title === "Launch blog post");
  641 |       const sentBack = refreshed.find((row) => row.case.title === "Changelog entry");
  642 |       return {
  643 |         approvedStage: approved?.case.stageId,
  644 |         sentBackStage: sentBack?.case.stageId,
  645 |       };
  646 |     }).toEqual({
  647 |       approvedStage: published!.id,
  648 |       sentBackStage: configured.stages.find((stage) => stage.key === "drafting")!.id,
  649 |     });
  650 | 
  651 |     await page.goto(`${companyPath}/learnings`);
  652 |     await expect(page.getByRole("heading", { name: "Learnings" }).first()).toBeVisible();
> 653 |     await expect(page.getByText("Tighten the framing before publishing.")).toBeVisible();
      |                                                                            ^ Error: expect(locator).toBeVisible() failed
  654 |     await expect(page.getByText(overrideReason)).toBeVisible();
  655 |       await expectProsumerVocabulary(page);
  656 |     } finally {
  657 |       await expectOk(
  658 |         await board.patch("/api/instance/settings/experimental", { data: { enablePipelines: false } }),
  659 |         "disable pipelines experimental flag",
  660 |       );
  661 |       await board.dispose();
  662 |     }
  663 |   });
  664 | });
  665 | 
```