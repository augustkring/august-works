from pathlib import Path
import json,hashlib,shutil,subprocess
root=Path('/workspace/blentera-v10');src=Path('/workspace/v10-preparation/openshell-rt01-repo-integration-candidate-r5')
old=json.loads((root/'third_party/openshell/rt01/source-pins.json').read_text());new=json.loads((src/'third_party/openshell/rt01/source-pins.json').read_text())
assert old['patch']['sha256']=='e28fc7fc8b860df810e7bf7337f59a53f2348e3595af6c883992d4ea09bc27d7'
assert new['patch']['sha256']=='04e0e056d3187ea39c5171f1d6e254d6e2c73e786a3d380c0e6d0995f11bf12e'
assert hashlib.sha256((src/new['patch']['path']).read_bytes()).hexdigest()==new['patch']['sha256']
assert hashlib.sha256((src/'third_party/openshell/rt01/source-pins.json').read_bytes()).hexdigest()=='7c48738c8872151ace5cb6c217a98e8881c7199b853028482d45aff493aff6db'
rows=(src/'STAGE-LIST.txt').read_text().splitlines();paths=[p.removeprefix('DELETE ') for p in rows]
assert len(paths)==len(set(paths))==11
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--',*paths],cwd=root).strip(),'integration source changed locally'
for row in rows:
 rel=row.removeprefix('DELETE ');target=root/rel
 if row.startswith('DELETE '):assert rel=='third_party/openshell/rt01/openshell-rt01-expected-id.patch';target.unlink()
 else:target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src/rel,target)
subprocess.run(['git','diff','--check','--',*paths],cwd=root,check=True)
subprocess.run(['git','add','--',*paths],cwd=root,check=True)
subprocess.run(['git','commit','-m','build: qualify pinned OpenShell quota and syscall source guards [skip ci]'],cwd=root,check=True)
