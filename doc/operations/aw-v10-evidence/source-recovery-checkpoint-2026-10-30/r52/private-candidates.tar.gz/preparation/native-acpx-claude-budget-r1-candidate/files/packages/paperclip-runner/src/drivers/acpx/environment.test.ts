import { describe, expect, it } from "vitest";

import { createSanitizedAcpxSpawnInput } from "./environment.js";

describe("ACPX launch environment", () => {
  it("projects only the selected agent's credentials and runtime allowlist", () => {
    const source = {
      PATH: "/bin",
      LC_ALL: "C.UTF-8",
      HTTPS_PROXY: "https://proxy.example",
      OPENAI_API_KEY: "openai-secret",
      ANTHROPIC_API_KEY: "anthropic-secret",
      OPENROUTER_API_KEY: "openrouter-secret",
      PAPERCLIP_ACPX_CODEX_AUTH_JSON_SECRET:
        '{"tokens":{"access_token":"managed-secret"}}',
      PAPERCLIP_RUNNER_BOOTSTRAP_TICKET: "transport-secret",
      PAPERCLIP_NATIVE_MCP_TOKEN: "bridge-secret",
      UNRELATED_SECRET: "not-visible",
    };

    const codex = createSanitizedAcpxSpawnInput(source, "codex");
    expect(codex.env).toEqual({
      PATH: "/bin",
      LC_ALL: "C.UTF-8",
      HTTPS_PROXY: "https://proxy.example",
      OPENAI_API_KEY: "openai-secret",
    });
    expect(createSanitizedAcpxSpawnInput(source, "claude").env).toEqual({
      PATH: "/bin",
      LC_ALL: "C.UTF-8",
      HTTPS_PROXY: "https://proxy.example",
      ANTHROPIC_API_KEY: "anthropic-secret",
    });
    expect(createSanitizedAcpxSpawnInput(source, "pi").env).toEqual({
      PATH: "/bin",
      LC_ALL: "C.UTF-8",
      HTTPS_PROXY: "https://proxy.example",
      OPENROUTER_API_KEY: "openrouter-secret",
    });
    expect(codex.env).not.toHaveProperty("PAPERCLIP_NATIVE_MCP_TOKEN");
    expect(codex.env).not.toHaveProperty(
      "PAPERCLIP_ACPX_CODEX_AUTH_JSON_SECRET",
    );
    expect(Object.isFrozen(codex)).toBe(true);
    expect(Object.isFrozen(codex.env)).toBe(true);
  });

  it("routes a complete server tuple without copying provider credentials", () => {
    const result = createSanitizedAcpxSpawnInput({
      PAPERCLIP_MANAGED_MODEL_BROKER_ORIGIN: "https://broker.example.test/",
      PAPERCLIP_MANAGED_MODEL_INPUT_TOKENS_UPPER_BOUND: "12000",
      PAPERCLIP_MANAGED_MODEL_MAX_OUTPUT_TOKENS: "1024",
      ANTHROPIC_API_KEY: "paperclip-managed-model-broker",
      CLAUDE_CODE_OAUTH_TOKEN: "must-not-enter",
      ANTHROPIC_AUTH_TOKEN: "must-not-enter",
      ANTHROPIC_BASE_URL: "https://attacker.example/",
      ANTHROPIC_CUSTOM_HEADERS: "Authorization: other-secret",
      AWS_ACCESS_KEY_ID: "other-secret",
    }, "claude");
    expect(result.env.ANTHROPIC_BASE_URL).toBe("https://broker.example.test/runtime-tools/model");
    expect(result.env.ANTHROPIC_AUTH_TOKEN).toBe("paperclip-managed-model-broker");
    expect(JSON.stringify(result.env)).not.toContain("must-not-enter");
    expect(JSON.stringify(result.env)).not.toContain("other-secret");
    expect(result.env).not.toHaveProperty("ANTHROPIC_API_KEY");
    expect(result.env).not.toHaveProperty("CLAUDE_CODE_OAUTH_TOKEN");
  });

  it.each([
    { PAPERCLIP_MANAGED_MODEL_BROKER_ORIGIN: "https://user:pass@broker.example.test/" },
    { PAPERCLIP_MANAGED_MODEL_BROKER_ORIGIN: "http://broker.example.test/" },
    { PAPERCLIP_MANAGED_MODEL_BROKER_ORIGIN: "https://broker.example.test/other" },
    { PAPERCLIP_MANAGED_MODEL_MAX_OUTPUT_TOKENS: "01024" },
    { PAPERCLIP_MANAGED_MODEL_INPUT_TOKENS_UPPER_BOUND: "2000001" },
    { ANTHROPIC_API_KEY: "raw-provider-key" },
  ])("refuses malformed broker tuples rather than falling back to credentials", (override) => {
    expect(() => createSanitizedAcpxSpawnInput({
      PAPERCLIP_MANAGED_MODEL_BROKER_ORIGIN: "https://broker.example.test/",
      PAPERCLIP_MANAGED_MODEL_INPUT_TOKENS_UPPER_BOUND: "12000",
      PAPERCLIP_MANAGED_MODEL_MAX_OUTPUT_TOKENS: "1024",
      ANTHROPIC_API_KEY: "paperclip-managed-model-broker", ...override,
    }, "claude")).toThrow("broker tuple is invalid");
  });

  it("rejects unsafe or unbounded retained values", () => {
    expect(() =>
      createSanitizedAcpxSpawnInput({ PATH: "bad\0path" }, "codex"),
    ).toThrow("null byte");
    expect(() =>
      createSanitizedAcpxSpawnInput(
        {
          OPENAI_API_KEY: "x".repeat(64 * 1024),
        },
        "codex",
      ),
    ).toThrow("bounded launch size");
  });
});
