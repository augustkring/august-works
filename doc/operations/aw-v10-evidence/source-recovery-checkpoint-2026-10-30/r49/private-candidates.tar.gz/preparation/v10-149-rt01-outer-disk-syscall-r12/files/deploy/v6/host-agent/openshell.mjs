import { execFile, spawn } from "node:child_process";
import { promisify } from "node:util";
import { createHash, randomUUID } from "node:crypto";
import { readFile, stat, realpath, writeFile, unlink } from "node:fs/promises";
import path from "node:path";
import { atomicJson } from "./journal.mjs";

const runFile = promisify(execFile);
const uuid = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
const hash = (value) => createHash("sha256").update(value).digest("hex");
const DISK_CHANNEL_MOUNT = "/.openshell/channel";
const DISK_CA_TMPFS_MOUNT = "/run/openshell-supervisor-ca/material";
const MIN_DISK_BYTES = 1_048_576;
const MAX_DISK_BYTES = 1_099_511_627_776;
const probeContracts = Object.freeze({
  filesystem_allow: ["filesystemPolicy", "allow"],
  filesystem_deny: ["filesystemPolicy", "deny"],
  filesystem_escape: ["filesystemPolicy", "deny"],
  process_nonprivileged: ["processPrivilegePolicy", "observe"],
  process_privilege_denied: ["processPrivilegePolicy", "deny"],
  syscall_allow: ["syscallPolicy", "allow"],
  syscall_deny: ["syscallPolicy", "deny"],
  network_allow: ["networkDestinationPolicy", "allow"],
  network_host_port_deny: ["networkDestinationPolicy", "deny"],
  network_dns_redirect_deny: ["networkDestinationPolicy", "deny"],
  network_l7_allow: ["networkLayer7Policy", "allow"],
  network_l7_deny: ["networkLayer7Policy", "deny"],
  credential_allow: ["credentialBrokering", "allow"],
  credential_raw_read_deny: ["credentialBrokering", "deny"],
  credential_wrong_destination_deny: ["credentialBrokering", "deny"],
  credential_revoke_deny: ["credentialBrokering", "deny"],
  resource_exhaustion_contained: ["resourceLimits", "deny"],
  force_stop: ["forceStop", "observe"],
});
const actions = new Set([
  "capabilities",
  "prepare",
  "inspect",
  "effective_policy",
  "apply",
  "start",
  "probe",
  "revoke_providers",
  "stop",
  "destroy",
]);
/** Private native-host controller. The pinned CLI observes only supported
 * OpenShell controls. It cannot attest the complete AW outer boundary. */
export function openShellHostEngine({
  config,
  epoch,
  root = "/var/lib/aw-runtime",
  run = runFile,
  spawnProcess = spawn,
}) {
  const journalFile = path.join(root, "openshell-journal.json");
  let journal = { version: 2, scopes: {}, commands: {} },
    queue = Promise.resolve();
  function serial(work) {
    const next = queue.then(work);
    queue = next.catch(() => {});
    return next;
  }
  function validScope(scope) {
    return (
      scope &&
      Object.keys(scope).sort().join(",") ===
        "bindingId,cellGeneration,cellId,companyId,sandboxRef" &&
      [scope.companyId, scope.bindingId, scope.cellId].every(
        (v) => typeof v === "string" && uuid.test(v),
      ) &&
      /^[1-9][0-9]{0,18}$/.test(scope.cellGeneration) &&
      scope.sandboxRef === `aw-v7-${scope.bindingId}`
    );
  }
  function canonical(value) {
    if (Array.isArray(value)) return value.map(canonical);
    if (value && typeof value === "object")
      return Object.fromEntries(
        Object.keys(value).sort().map((key) => [key, canonical(value[key])]),
      );
    return value;
  }
  function sameDocument(left, right) {
    return JSON.stringify(canonical(left)) === JSON.stringify(canonical(right));
  }
  function deterministicUuidFromHash(digest) {
    if (!/^[a-f0-9]{64}$/.test(digest ?? "")) throw new Error("sandbox_scope_changed");
    const bytes = Buffer.from(digest.slice(0, 32), "hex");
    bytes[6] = (bytes[6] & 0x0f) | 0x50;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    const value = bytes.toString("hex");
    return `${value.slice(0, 8)}-${value.slice(8, 12)}-${value.slice(12, 16)}-${value.slice(16, 20)}-${value.slice(20)}`;
  }
  function validOpenShellDocument(value) {
    if (!value || typeof value !== "object" || Array.isArray(value) ||
      Object.keys(value).sort().join(",") !== "filesystem_policy,landlock,network_policies,process,version" ||
      value.version !== 1) return false;
    const fs = value.filesystem_policy;
    if (!fs || typeof fs !== "object" || Array.isArray(fs) ||
      Object.keys(fs).sort().join(",") !== "include_workdir,read_only,read_write" ||
      fs.include_workdir !== false || !Array.isArray(fs.read_only) || fs.read_only.length > 64 ||
      !Array.isArray(fs.read_write) || fs.read_write.length > 32 ||
      [...fs.read_only, ...fs.read_write].some(item => !canonicalFixturePath(item))) return false;
    const landlock = value.landlock;
    if (!landlock || typeof landlock !== "object" || Array.isArray(landlock) ||
      Object.keys(landlock).sort().join(",") !== "compatibility" ||
      landlock.compatibility !== "hard_requirement") return false;
    const process = value.process;
    if (!process || typeof process !== "object" || Array.isArray(process) ||
      Object.keys(process).sort().join(",") !== "run_as_group,run_as_user" ||
      !/^[1-9][0-9]{0,8}$/.test(process.run_as_user ?? "") ||
      !/^[0-9]{1,9}$/.test(process.run_as_group ?? "")) return false;
    const network = value.network_policies;
    if (!network || typeof network !== "object" || Array.isArray(network) || Object.keys(network).length > 64) return false;
    for (const [key, entry] of Object.entries(network)) {
      if (!/^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,99}$/.test(key) || !entry || typeof entry !== "object" ||
        Array.isArray(entry) || Object.keys(entry).sort().join(",") !== "binaries,endpoints,name" ||
        typeof entry.name !== "string" || entry.name.length > 100 || !Array.isArray(entry.binaries) ||
        entry.binaries.length > 32 || !Array.isArray(entry.endpoints) || entry.endpoints.length > 64) return false;
      if (entry.binaries.some(binary => !binary || typeof binary !== "object" || Array.isArray(binary) ||
        Object.keys(binary).join(",") !== "path" || !canonicalFixturePath(binary.path))) return false;
      for (const endpoint of entry.endpoints) {
        if (!endpoint || typeof endpoint !== "object" || Array.isArray(endpoint) ||
          Object.keys(endpoint).sort().join(",") !== "enforcement,host,port,protocol,rules" ||
          typeof endpoint.host !== "string" || endpoint.host.length < 1 || endpoint.host.length > 253 ||
          /[\r\n\0]/.test(endpoint.host) || !Number.isInteger(endpoint.port) || endpoint.port < 1 || endpoint.port > 65535 ||
          endpoint.protocol !== "rest" || endpoint.enforcement !== "enforce" ||
          !Array.isArray(endpoint.rules) || endpoint.rules.length > 224 ||
          endpoint.rules.some(rule => !rule || typeof rule !== "object" || Array.isArray(rule) ||
            Object.keys(rule).join(",") !== "allow" || !rule.allow || typeof rule.allow !== "object" ||
            Array.isArray(rule.allow) || Object.keys(rule.allow).sort().join(",") !== "method,path" ||
            typeof rule.allow.method !== "string" || rule.allow.method.length > 10 ||
            typeof rule.allow.path !== "string" || rule.allow.path.length > 1100)) return false;
      }
    }
    return true;
  }
  async function privateConfiguration() {
    if (
      !config ||
      !path.isAbsolute(config.executable ?? "") ||
      !/^[a-f0-9]{64}$/.test(config.executableSha256 ?? "") ||
      !/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,100}$/.test(config.gateway ?? "") ||
      !/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,100}$/.test(config.workspace ?? "") ||
      !path.isAbsolute(config.stateHome ?? "")
    )
      throw new Error("sandbox_host_unavailable");
    const executable = await realpath(config.executable),
      stateHome = await realpath(config.stateHome);
    const [binary, home] = await Promise.all([
      stat(executable),
      stat(stateHome),
    ]);
    const privateOwner = (info) =>
      info.uid === (process.getuid?.() ?? 0) && !(info.mode & 0o022);
    if (
      !binary.isFile() ||
      !(binary.mode & 0o100) ||
      binary.size > 100 * 1024 * 1024 ||
      !privateOwner(binary) ||
      !home.isDirectory() ||
      !privateOwner(home) ||
      home.mode & 0o077 ||
      hash(await readFile(executable)) !== config.executableSha256
    )
      throw new Error("sandbox_host_unavailable");
    return {
      executable,
      stateHome,
      env: { HOME: stateHome, PATH: "/usr/bin:/bin", LANG: "C", NO_COLOR: "1" },
    };
  }
  async function cli(args, deadlineAt, json = true, envOverrides = {}, timeoutCapMs = 6000) {
    const privateConfig = await privateConfiguration();
    const remaining = new Date(deadlineAt).getTime() - Date.now();
    if (!Number.isFinite(remaining) || remaining <= 0)
      throw new Error("sandbox_host_unavailable");
    const { stdout } = await run(
      privateConfig.executable,
      ["--gateway", config.gateway, "--workspace", config.workspace, ...args],
      {
        env: { ...privateConfig.env, ...envOverrides },
        timeout: Math.min(timeoutCapMs, remaining),
        maxBuffer: 262144,
        windowsHide: true,
        killSignal: "SIGKILL",
      },
    );
    return json ? JSON.parse(stdout) : stdout;
  }
  async function inspectBrokerProviderProfile(request, deadlineAt, model = false, expectedBinaries = null) {
    const broker = model ? request.modelBrokerCredential : request.brokerCredential;
    if (!broker) return null;
    const profile = await cli(["profile", "describe", broker.profileId, "--output", "json"], deadlineAt);
    if (!profile || profile.id !== broker.profileId || hash(JSON.stringify(canonical(profile))) !== broker.profileHash ||
      !Array.isArray(profile.credentials) || profile.credentials.length !== 1 ||
      !Array.isArray(profile.endpoints) || profile.endpoints.length !== 1 ||
      !Array.isArray(profile.binaries)) throw new Error("sandbox_operation_unsupported");
    if (expectedBinaries !== null) {
      const actualBinaries = profile.binaries.map(value => value?.path).sort();
      const wantedBinaries = [...expectedBinaries].sort();
      if (profile.binaries.some(value => !value || Object.keys(value).length !== 1 || typeof value.path !== "string") ||
        new Set(actualBinaries).size !== actualBinaries.length || new Set(wantedBinaries).size !== wantedBinaries.length ||
        JSON.stringify(actualBinaries) !== JSON.stringify(wantedBinaries)) throw new Error("sandbox_operation_unsupported");
    }
    const credential = profile.credentials[0];
    if (credential?.auth_style !== "bearer" || credential.header_name?.toLowerCase() !== "authorization" ||
      credential.env_vars?.length !== 1 || credential.env_vars[0] !== (model ? "PAPERCLIP_SANDBOX_MODEL_TOKEN" : "PAPERCLIP_SANDBOX_BROKER_TOKEN") ||
      credential.token_grant || credential.refresh) throw new Error("sandbox_operation_unsupported");
    const endpoint = profile.endpoints[0];
    const origin = new URL(request.env[model ? "PAPERCLIP_MANAGED_MODEL_BROKER_ORIGIN" : "PAPERCLIP_SANDBOX_BROKER_ENDPOINT_ORIGIN"] ?? "");
    const port = origin.port ? Number(origin.port) : origin.protocol === "https:" ? 443 : 80;
    const rules = endpoint?.rules;
    if (origin.protocol !== "https:" || endpoint?.host !== origin.hostname || endpoint?.port !== port ||
      endpoint.protocol !== "rest" || endpoint.enforcement !== "enforce" || endpoint.allow_uninspected_credentials === true ||
      endpoint.path || !Array.isArray(rules) || rules.length !== 1 ||
      rules[0]?.allow?.method !== "POST" || rules[0]?.allow?.path !== (model ? "/runtime-tools/model/v1/messages" : "/mcp/gateways/*"))
      throw new Error("sandbox_operation_unsupported");
    return { profile, origin };
  }
  async function attachBrokerProvider(request, scope, deadlineAt, providerName) {
    const broker = request.brokerCredential;
    if (!broker) return;
    if (Date.parse(broker.expiresAt) <= Date.now() || Date.parse(broker.expiresAt) > Date.parse(deadlineAt))
      throw new Error("exec_timeout");
    const decoded = (() => {
      try { return JSON.parse(Buffer.from(broker.capabilityToken.split(".")[1], "base64url").toString("utf8")); }
      catch { return null; }
    })();
    const capability = decoded?.sandbox_broker;
    if (!decoded || decoded.purpose !== "sandbox_broker" || decoded.aud !== "paperclip-sandbox-broker" ||
      !Array.isArray(capability?.bindings) || capability.bindings.some(binding => !binding ||
        !(binding.binary === null || typeof binding.binary === "string" && binding.binary.startsWith("/"))) ||
      decoded.jti !== request.requestId || capability?.parentRequestId !== request.requestId ||
      capability.bindingId !== request.bindingId || capability.cellId !== scope.cellId ||
      capability.generation !== scope.cellGeneration || capability.hostEpoch !== request.hostEpoch ||
      capability.runId !== request.runId || capability.attemptId !== request.attemptId || capability.attempt !== request.attempt ||
      capability.manifestId !== request.manifestId || capability.manifestHash !== request.manifestHash ||
      capability.policySnapshotId !== request.policySnapshotId || capability.policyHash !== request.policyHash ||
      capability?.endpointOrigin !== request.env.PAPERCLIP_SANDBOX_BROKER_ENDPOINT_ORIGIN ||
      capability?.brokerSessionId !== request.env.PAPERCLIP_SANDBOX_BROKER_SESSION_ID ||
      Date.parse(capability?.expiresAt ?? "") !== Date.parse(broker.expiresAt) || decoded.exp * 1000 > Date.parse(broker.expiresAt) + 999 ||
      decoded.company_id !== scope.companyId || decoded.run_id !== request.runId || !Number.isFinite(decoded.exp) || decoded.exp * 1000 <= Date.now())
      throw new Error("sandbox_scope_changed");
    const binaries = capability.bindings.map(binding => binding.binary ?? null);
    const expectedBinaries = binaries.some(binary => binary !== null)
      ? (binaries.every(binary => binary !== null) && new Set(binaries).size === 1 ? [binaries[0]] : null)
      : null;
    if (binaries.some(binary => binary !== null) && expectedBinaries === null)
      throw new Error("sandbox_operation_unsupported");
    const { origin } = await inspectBrokerProviderProfile(request, deadlineAt, false, expectedBinaries);
    if (origin.username || origin.password || origin.pathname !== "/" || origin.search || origin.hash)
      throw new Error("sandbox_operation_unsupported");
    const providerCredentialEnv = "PAPERCLIP_SANDBOX_BROKER_TOKEN";
    const providerEnv = { [providerCredentialEnv]: broker.capabilityToken };
    await cli(["provider", "create", "--name", providerName, "--type", broker.profileId, "--credential", providerCredentialEnv], deadlineAt, false, providerEnv);
    await cli(["provider", "update", providerName, "--credential-expires-at", `${providerCredentialEnv}=${broker.expiresAt}`], deadlineAt, false);
    const waitSeconds = Math.max(1, Math.min(15, Math.floor((Date.parse(deadlineAt) - Date.now()) / 1000)));
    const target = await observed(scope, deadlineAt);
    await cli(["sandbox", "provider", "attach", scope.sandboxRef, providerName, "--expected-sandbox-id", target.id, "--wait", "--timeout", String(waitSeconds), "--output", "json"], deadlineAt, true, {}, 18_000);
    const attached = await cli(["sandbox", "provider", "list", scope.sandboxRef, "--page-size", "16", "--output", "json"], deadlineAt);
    if (!Array.isArray(attached.providers) || !attached.providers.some(value => value?.name === providerName) || attached.next_page_token !== "")
      throw new Error("sandbox_observation_unavailable");
  }
  async function attachModelBrokerProvider(request, scope, deadlineAt, providerName) {
    const broker = request.modelBrokerCredential;
    if (!broker) return;
    if (Date.parse(broker.expiresAt) <= Date.now() || Date.parse(broker.expiresAt) > Date.parse(deadlineAt)) throw new Error("exec_timeout");
    const decoded = (() => { try { return JSON.parse(Buffer.from(broker.capabilityToken.split(".")[1], "base64url").toString("utf8")); } catch { return null; } })();
    if (!decoded || decoded.scope !== "worker_model" || decoded.company_id !== scope.companyId || decoded.run_id !== request.runId ||
      decoded.exp * 1000 <= Date.now() || decoded.exp * 1000 < Date.parse(broker.expiresAt) ||
      decoded.worker_model?.executionManifestId !== request.manifestId || !decoded.worker_model?.workerAttemptId)
      throw new Error("sandbox_scope_changed");
    const { origin } = await inspectBrokerProviderProfile(request, deadlineAt, true);
    if (origin.username || origin.password || origin.pathname !== "/" || origin.search || origin.hash) throw new Error("sandbox_operation_unsupported");
    const credentialEnv = "PAPERCLIP_SANDBOX_MODEL_TOKEN";
    await cli(["provider", "create", "--name", providerName, "--type", broker.profileId, "--credential", credentialEnv], deadlineAt, false, { [credentialEnv]: broker.capabilityToken });
    await cli(["provider", "update", providerName, "--credential-expires-at", `${credentialEnv}=${broker.expiresAt}`], deadlineAt, false);
    const waitSeconds = Math.max(1, Math.min(15, Math.floor((Date.parse(deadlineAt) - Date.now()) / 1000)));
    const target = await observed(scope, deadlineAt);
    await cli(["sandbox", "provider", "attach", scope.sandboxRef, providerName, "--expected-sandbox-id", target.id, "--wait", "--timeout", String(waitSeconds), "--output", "json"], deadlineAt, true, {}, 18_000);
    const attached = await cli(["sandbox", "provider", "list", scope.sandboxRef, "--page-size", "16", "--output", "json"], deadlineAt);
    if (!Array.isArray(attached.providers) || !attached.providers.some(value => value?.name === providerName) || attached.next_page_token !== "") throw new Error("sandbox_observation_unavailable");
  }
  async function detachAndDeleteBrokerProvider(scope, deadlineAt, providerName) {
    const target = await observed(scope, deadlineAt);
    await cli(["sandbox", "provider", "detach", scope.sandboxRef, providerName, "--expected-sandbox-id", target.id, "--wait", "--timeout", "15", "--output", "json"], deadlineAt, true, {}, 18_000);
    const attached = await cli(["sandbox", "provider", "list", scope.sandboxRef, "--page-size", "16", "--output", "json"], deadlineAt);
    if (!Array.isArray(attached.providers) || attached.providers.some(value => value?.name === providerName) || attached.next_page_token !== "")
      throw new Error("sandbox_observation_unavailable");
    await cli(["provider", "delete", providerName], deadlineAt, false);
  }
  async function deleteQuiescedBrokerProviders(scope, deadlineAt) {
    const pending = Object.values(journal.commands).flatMap(command => {
      return [command?.brokerProvider, command?.modelBrokerProvider].filter(provider => provider && validScope(provider.scope) && sameDocument(provider.scope, scope) &&
        /^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,100}$/.test(provider.name ?? "")).map(provider => provider.name);
    });
    const names = [...new Set(pending)].slice(0, 32);
    for (const name of names) await cli(["provider", "delete", name], deadlineAt, false);
    if (names.length) await serial(async () => {
      for (const command of Object.values(journal.commands)) {
        if (command?.brokerProvider && names.includes(command.brokerProvider.name) && validScope(command.brokerProvider.scope) && sameDocument(command.brokerProvider.scope, scope))
          delete command.brokerProvider;
        if (command?.modelBrokerProvider && names.includes(command.modelBrokerProvider.name) && validScope(command.modelBrokerProvider.scope) && sameDocument(command.modelBrokerProvider.scope, scope))
          delete command.modelBrokerProvider;
      }
      await atomicJson(journalFile, journal);
    });
  }
  async function docker(args, deadlineAt, json = true) {
    const privateConfig = await privateConfiguration();
    const remaining = new Date(deadlineAt).getTime() - Date.now();
    if (!Number.isFinite(remaining) || remaining <= 0)
      throw new Error("sandbox_host_unavailable");
    const { stdout } = await run("docker", args, {
      env: {
        ...privateConfig.env,
        PATH: process.env.PATH,
        DOCKER_HOST: "unix:///var/run/docker.sock",
      },
      timeout: Math.min(6000, remaining),
      maxBuffer: 262144,
      windowsHide: true,
      killSignal: "SIGKILL",
    });
    return json ? JSON.parse(stdout) : stdout;
  }
  function validResourceLimits(value) {
    return value && Number.isSafeInteger(value.cpuMillis) && value.cpuMillis >= 100 && value.cpuMillis <= 64000 &&
      Number.isSafeInteger(value.memoryBytes) && value.memoryBytes >= 67108864 && value.memoryBytes <= 137438953472 &&
      Number.isSafeInteger(value.diskBytes) && value.diskBytes >= MIN_DISK_BYTES && value.diskBytes <= MAX_DISK_BYTES &&
      Number.isSafeInteger(value.pidsLimit) && value.pidsLimit >= 16 && value.pidsLimit <= 16384;
  }
  function validateProvisioning(request) {
    const value = request?.provisioning;
    if (!value || typeof value !== "object" || Array.isArray(value) ||
      Object.keys(value).sort().join(",") !== "document,expiresAt,idleUntilUnixSeconds,operationKey,policyHash,provisioningHash,purpose,resourceLimits" ||
      !["qualification", "admission"].includes(value.purpose) ||
      typeof value.operationKey !== "string" || value.operationKey.length < 1 || value.operationKey.length > 300 ||
      /[\r\n\0]/.test(value.operationKey) || typeof value.expiresAt !== "string" ||
      !Number.isFinite(Date.parse(value.expiresAt)) || new Date(value.expiresAt).toISOString() !== value.expiresAt ||
      !Number.isSafeInteger(value.idleUntilUnixSeconds) || value.idleUntilUnixSeconds < 1 ||
      value.idleUntilUnixSeconds !== Math.floor(Date.parse(value.expiresAt) / 1000) ||
      Date.parse(value.expiresAt) - Date.now() > 86_400_000 ||
      !/^[a-f0-9]{64}$/.test(value.policyHash ?? "") || !/^[a-f0-9]{64}$/.test(value.provisioningHash ?? "") ||
      !validResourceLimits(value.resourceLimits) || !validOpenShellDocument(value.document))
      throw new Error("sandbox_scope_changed");
    const envelope = {
      scope: { companyId: request.scope.companyId, bindingId: request.scope.bindingId,
        cellId: request.scope.cellId, cellGeneration: request.scope.cellGeneration,
        sandboxRef: request.scope.sandboxRef },
      hostEpoch: epoch,
      imageDigest: request.imageDigest,
      purpose: value.purpose,
      operationKey: value.operationKey,
      expiresAt: value.expiresAt,
      idleUntilUnixSeconds: value.idleUntilUnixSeconds,
      policyHash: value.policyHash,
      document: canonical(value.document),
      resourceLimits: canonical(value.resourceLimits),
    };
    const provisioningHash = hash(JSON.stringify(canonical(envelope)));
    if (provisioningHash !== value.provisioningHash) throw new Error("sandbox_scope_changed");
    return { envelope, provisioningHash, requestId: deterministicUuidFromHash(provisioningHash),
      expired: Date.parse(value.expiresAt) <= Date.now() };
  }
  function dockerDiskStorageOptionMatches(container, limits) {
    const storageOpt = container?.HostConfig?.StorageOpt;
    return Number.isSafeInteger(limits?.diskBytes) &&
      storageOpt && Object.keys(storageOpt).length === 1 &&
      storageOpt.size === `${limits.diskBytes}B`;
  }
  function pathContains(parent, child) {
    if (typeof parent !== "string" || typeof child !== "string" ||
      !parent.startsWith("/") || !child.startsWith("/")) return false;
    const normalizedParent = path.posix.normalize(parent), normalizedChild = path.posix.normalize(child);
    return normalizedParent === "/" || normalizedChild === normalizedParent ||
      normalizedChild.startsWith(`${normalizedParent}/`);
  }
  function readOnlyPathAllows(document, target) {
    const paths = document?.filesystem_policy?.read_only;
    return Array.isArray(paths) && paths.some(value => pathContains(value, target));
  }
  function filesystemPathAllowed(document, target) {
    const paths = [...(document?.filesystem_policy?.read_only ?? []),
      ...(document?.filesystem_policy?.read_write ?? [])];
    return paths.some(value => pathContains(value, target));
  }
  function canonicalFixturePath(value, allowTraversal = false) {
    return typeof value === "string" && value.length > 0 && value.length <= 512 &&
      value.startsWith("/") && !/[\r\n\0]/.test(value) &&
      value.split("/").every(part => part !== "." && (allowTraversal || part !== "..")) &&
      (allowTraversal || path.posix.normalize(value) === value);
  }
  function filesystemProbeFixture() {
    const value = config?.qualificationFixtures?.filesystem;
    if (!value || Object.keys(value).sort().join(",") !==
      "allowedReadMarker,allowedReadPath,deniedReadMarker,deniedReadPath,escapeOperand,escapeReadMarker,escapeTargetPath,escapeViaRoot" ||
      !canonicalFixturePath(value.allowedReadPath) || !canonicalFixturePath(value.deniedReadPath) ||
      !canonicalFixturePath(value.escapeViaRoot) || !canonicalFixturePath(value.escapeTargetPath) ||
      !canonicalFixturePath(value.escapeOperand, true) || !value.escapeOperand.split("/").includes("..") ||
      path.posix.resolve(value.escapeOperand) !== value.escapeTargetPath ||
      !pathContains(value.escapeViaRoot, value.escapeOperand.split("/").slice(0, value.escapeOperand.split("/").indexOf(".." )).join("/")) ||
      !/^[A-Za-z0-9]$/.test(value.allowedReadMarker ?? "") ||
      !/^[A-Za-z0-9]$/.test(value.deniedReadMarker ?? "") ||
      !/^[A-Za-z0-9]$/.test(value.escapeReadMarker ?? "") ||
      value.allowedReadPath === value.deniedReadPath || value.deniedReadPath === value.escapeTargetPath)
      return null;
    return value;
  }
  function qualificationFixtureHash() {
    // Fixture config contains only non-secret, operator-owned canary metadata.
    // Credential material is generated by the existing broker owner at use.
    return hash(JSON.stringify(canonical(config?.qualificationFixtures ?? null)));
  }
  async function dockerCanaryRead(workload, uid, gid, target, marker, deadlineAt) {
    if (!/^[1-9][0-9]{0,8}$/.test(uid ?? "") || !/^[0-9]{1,9}$/.test(gid ?? "") ||
      !/^[A-Za-z0-9]$/.test(marker ?? "")) return null;
    try {
      const prefix = ["exec", "--user", `${uid}:${gid}`, workload.Id];
      const metadata = await docker([...prefix, "/usr/bin/stat", "-c", "%F:%a", target], deadlineAt, false);
      const match = metadata.trim().match(/^regular file:([0-7]{3,4})$/);
      if (!match || (Number.parseInt(match[1], 8) & 0o004) === 0) return null;
      const bytes = await docker([...prefix, "/usr/bin/head", "-c", "1", target], deadlineAt, false);
      return bytes === marker ? { marker, mode: match[1] } : null;
    } catch {
      return null;
    }
  }
  function dockerDiskMountsMatch(container, policyDocument) {
    const mounts = container?.Mounts;
    const labels = container?.Config?.Labels;
    const workdir = labels?.["openshell.ai/workspace-root"];
    if (!Array.isArray(mounts) || mounts.length > 32 ||
      typeof workdir !== "string" || !workdir.startsWith("/") ||
      path.posix.normalize(workdir) !== workdir || !labels) return false;
    const normalizedWorkdir = path.posix.normalize(workdir);
    const expectedChannelName = `openshell-channel-${hash(`${labels["openshell.ai/sandbox-namespace"]}\0${labels["openshell.ai/sandbox-id"]}`).slice(0, 32)}`;
    const hostTmpfs = container?.HostConfig?.Tmpfs;
    const caOption = hostTmpfs?.[DISK_CA_TMPFS_MOUNT];
    if (!hostTmpfs || Object.keys(hostTmpfs).length !== 1 ||
      typeof caOption !== "string" ||
      !/^rw,noexec,nosuid,nodev,size=1m,uid=\d+,gid=\d+,mode=0755$/.test(caOption)) return false;
    let channelCount = 0, caTmpfsCount = 0;
    for (const mount of mounts) {
      if (!mount || typeof mount.Destination !== "string" ||
        !mount.Destination.startsWith("/")) return false;
      const destination = path.posix.normalize(mount.Destination);
      if (pathContains(destination, normalizedWorkdir) || pathContains(normalizedWorkdir, destination)) return false;
      if (mount.RW === false) continue;
      if (destination === DISK_CHANNEL_MOUNT && mount.Type === "volume" &&
        mount.Name === expectedChannelName && mount.Driver === "local" && mount.RW === true) {
        channelCount += 1;
        continue;
      }
      if (destination === DISK_CA_TMPFS_MOUNT && mount.Type === "tmpfs" &&
        mount.RW === true && typeof mount.Mode === "string" &&
        (!mount.Mode || mount.Mode === "rw" || mount.Mode.includes("size=1m"))) {
        caTmpfsCount += 1;
        continue;
      }
      return false;
    }
    if (channelCount !== 1 || caTmpfsCount !== 1) return false;
    const writePaths = policyDocument?.filesystem_policy?.read_write;
    if (!Array.isArray(writePaths)) return false;
    for (const writable of writePaths) {
      if ([DISK_CHANNEL_MOUNT, DISK_CA_TMPFS_MOUNT].some(target =>
        pathContains(writable, target) || pathContains(target, writable))) return false;
    }
    return true;
  }
  function dockerPersistentLogsDisabled(container) {
    const log = container?.HostConfig?.LogConfig;
    return log?.Type === "none" && log.Config &&
      typeof log.Config === "object" && !Array.isArray(log.Config) &&
      Object.keys(log.Config).length === 0;
  }
  async function dockerSupervisorLogsDisabled(scope, sandbox, deadlineAt) {
    const idsOutput = await docker(["ps", "-aq",
      "--filter", `label=openshell.ai/sandbox-id=${sandbox.id}`,
      "--filter", "label=openshell.ai/isolation-role=supervisor"], deadlineAt, false);
    const ids = idsOutput.trim().split(/\s+/).filter(Boolean);
    if (ids.length !== 1 || !/^[a-f0-9]{64}$/.test(ids[0])) return false;
    const values = await docker(["inspect", ids[0]], deadlineAt);
    if (!Array.isArray(values) || values.length !== 1) return false;
    const supervisor = values[0];
    const labels = supervisor.Config?.Labels;
    const namespace = journal.scopes[scope.bindingId]?.namespace;
    if (!/^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,100}$/.test(namespace ?? "")) return false;
    const expected = {
      "openshell.ai/managed-by": "openshell",
      "openshell.ai/sandbox-id": sandbox.id,
      "openshell.ai/sandbox-name": scope.sandboxRef,
      "openshell.ai/sandbox-namespace": namespace,
      "openshell.ai/isolation-role": "supervisor",
    };
    return supervisor.Id === ids[0] && supervisor.Config?.Image === supervisor.Image &&
      Object.entries(expected).every(([key, value]) => labels?.[key] === value) &&
      dockerPersistentLogsDisabled(supervisor);
  }
  function resourceHostConfigMatches(container, limits, policyDocument) {
    const host = container?.HostConfig;
    // The only writable tmpfs exception is the driver's exact 1 MiB CA
    // mount, accounted by this same policy's Docker memory cgroup limit.
    return validResourceLimits(limits) && host?.NanoCpus === limits.cpuMillis * 1_000_000 &&
      host?.Memory === limits.memoryBytes && host?.MemorySwap === limits.memoryBytes &&
      host?.PidsLimit === limits.pidsLimit && dockerDiskStorageOptionMatches(container, limits) &&
      dockerPersistentLogsDisabled(container) && dockerDiskMountsMatch(container, policyDocument);
  }
  async function dockerDiskQuotaBackendSupported(deadlineAt) {
    const driver = (await docker(["info", "--format", "{{.Driver}}"], deadlineAt, false)).trim();
    if (driver !== "overlay2") return false;
    let status;
    try {
      status = JSON.parse(await docker(["info", "--format", "{{json .DriverStatus}}"], deadlineAt, false));
    } catch { return false; }
    return Array.isArray(status) && status.some(value =>
      Array.isArray(value) && value[0] === "Backing Filesystem" &&
      typeof value[1] === "string" && value[1].toLowerCase() === "xfs");
  }
  function dockerResourceUpdateArgs(containerId, limits) {
    if (!/^[a-f0-9]{64}$/.test(containerId ?? "") || !validResourceLimits(limits))
      throw new Error("sandbox_scope_changed");
    const cpus = (limits.cpuMillis / 1000).toFixed(3).replace(/\.?0+$/, "");
    return ["update", "--cpus", cpus, "--memory", String(limits.memoryBytes), "--memory-swap", String(limits.memoryBytes),
      "--pids-limit", String(limits.pidsLimit), containerId];
  }
  async function applyDockerResourceLimits(scope, sandbox, imageDigest, limits, deadlineAt, expectedContainerId, policyDocument) {
    const before = await container(scope, sandbox, imageDigest, deadlineAt);
    if (before.Id !== expectedContainerId || before.State.Running)
      throw new Error("sandbox_scope_changed");
    await docker(dockerResourceUpdateArgs(before.Id, limits), deadlineAt, false);
    const after = await container(scope, sandbox, imageDigest, deadlineAt);
    if (after.Id !== before.Id || !resourceHostConfigMatches(after, limits, policyDocument))
      throw new Error("sandbox_observation_unavailable");
    return after;
  }
  async function inspectCredentialProviderProfile(expected, deadlineAt) {
    if (!expected || !/^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,99}$/.test(expected.id ?? "") ||
      !/^[a-f0-9]{64}$/.test(expected.hash ?? "") || !Array.isArray(expected.binaries) || expected.binaries.length > 32)
      throw new Error("sandbox_operation_unsupported");
    const profile = await cli(["profile", "describe", expected.id, "--output", "json"], deadlineAt);
    if (!profile || profile.id !== expected.id || hash(JSON.stringify(canonical(profile))) !== expected.hash ||
      !Array.isArray(profile.binaries) || profile.binaries.length > 32 ||
      profile.binaries.some(value => !value || Object.keys(value).length !== 1 || typeof value.path !== "string")) {
      throw new Error("sandbox_operation_unsupported");
    }
    const actual = profile.binaries.map(value => value.path).sort();
    const wanted = [...expected.binaries].sort();
    if (new Set(actual).size !== actual.length || new Set(wanted).size !== wanted.length ||
      JSON.stringify(actual) !== JSON.stringify(wanted))
      throw new Error("sandbox_operation_unsupported");
  }
  async function sandboxExec(scope, sandboxId, argv, deadlineAt) {
    const remaining = Date.parse(deadlineAt) - Date.now();
    if (!Number.isFinite(remaining) || remaining < 1500) throw new Error("exec_timeout");
    const privateConfig = await privateConfiguration();
    try {
      const { stdout } = await run(
        privateConfig.executable,
        ["--gateway", config.gateway, "--workspace", config.workspace, "sandbox", "exec", "--name", scope.sandboxRef, "--expected-sandbox-id", sandboxId, "--no-login-shell", "--timeout", String(Math.min(3, Math.floor(remaining / 1000))), "--", ...argv],
        { env: privateConfig.env, timeout: Math.min(4500, remaining), maxBuffer: 8192, windowsHide: true, killSignal: "SIGKILL" },
      );
      return { exitCode: 0, stdout: String(stdout).slice(0, 256) };
    } catch (error) {
      const status = Number.isInteger(error?.code) ? error.code : Number.isInteger(error?.status) ? error.status : null;
      return { exitCode: status, stdout: "" };
    }
  }
  async function hostCapabilities(request, scope, deadlineAt) {
    const version = await cli(["--version"], deadlineAt, false);
    if (version.trim() !== "openshell 0.1.2") return null;
    const detail = await observed(scope, deadlineAt);
    const currentPolicy = await policy(scope, deadlineAt);
    const workload = await container(scope, detail, request.imageDigest, deadlineAt);
    if (!workload || !currentPolicy.policy || !currentPolicy.policy.filesystem_policy || !currentPolicy.policy.landlock || !currentPolicy.policy.process) return null;
    const fs = currentPolicy.policy.filesystem_policy;
    const process = currentPolicy.policy.process;
    const network = currentPolicy.policy.network_policies;
    const testedAt = new Date().toISOString();
    const evidence = {
      backend: "openshell", backendVersion: "0.1.2", sandboxId: detail.id,
      containerId: workload.Id, imageDigest: request.imageDigest,
      policyHash: currentPolicy.hash, policyVersion: currentPolicy.version,
      configRevision: currentPolicy.config_revision, phase: detail.phase,
      fixtureHash: qualificationFixtureHash(),
    };
    const qualificationHash = hash(JSON.stringify(canonical(evidence)));
    return {
      filesystemPolicy: fs.include_workdir === false && currentPolicy.policy.landlock.compatibility === "hard_requirement",
      processPrivilegePolicy: typeof process.run_as_user === "string" && typeof process.run_as_group === "string" && process.run_as_user !== "0",
      syscallPolicy: false,
      networkDestinationPolicy: Boolean(network && typeof network === "object" && Object.values(network).every(value => Array.isArray(value?.endpoints))),
      networkLayer7Policy: Boolean(network && typeof network === "object" && Object.values(network).every(value => (value?.endpoints ?? []).every(endpoint => endpoint?.protocol === "rest" && endpoint?.enforcement === "enforce" && Array.isArray(endpoint.rules)))),
      credentialBrokering: false,
      resourceLimits: false,
      // This is only a declaration that the pinned host can observe a live
      // target and the expected-ID stop/start path; the final control is earned
      // by the separate bounded force_stop transition probe.
      forceStop: detail.phase === "Ready" && workload.State.Running === true,
      backend: "openshell", backendVersion: "0.1.2", hostKernelVersion: null,
      sandboxImageDigest: request.imageDigest,
      filesystemEnforcementMode: currentPolicy.policy.landlock.compatibility === "hard_requirement" ? "hard_requirement" : "unknown",
      staticPolicyRequiresRecreate: true,
      dynamicNetworkPolicy: true,
      policyProverBoundaryCheck: false,
      policyProverCoverage: [], credentialBindingDimensions: [],
      testedAt, expiresAt: new Date(Date.now() + 120_000).toISOString(),
      qualificationHash, evidenceKind: "protected_host_report",
    };
  }
  async function probeBoundary(request, deadlineAt) {
    const probe = request.probe;
    const expected = probeContracts[probe.caseId];
    if (!expected || expected[0] !== probe.control || expected[1] !== probe.expected || !/^[a-f0-9]{64}$/.test(probe.contractHash ?? ""))
      throw new Error("sandbox_scope_changed");
    const detail = await observed(request.scope, deadlineAt);
    const effective = await policy(request.scope, deadlineAt);
    if (detail.phase !== "Ready")
      return { action: "probe", verdict: "unsupported", observationHash: null, contractHash: probe.contractHash };
    if (!["process_nonprivileged", "process_privilege_denied", "filesystem_allow", "filesystem_deny", "filesystem_escape", "syscall_allow", "syscall_deny", "resource_exhaustion_contained", "force_stop"].includes(probe.caseId))
      return { action: "probe", verdict: "unsupported", observationHash: null, contractHash: probe.contractHash };
    const workload = await container(request.scope, detail, request.imageDigest, deadlineAt);
    const targetQualificationHash = hash(JSON.stringify(canonical({
      backend: "openshell", backendVersion: "0.1.2", sandboxId: detail.id,
      containerId: workload.Id, imageDigest: request.imageDigest, policyHash: effective.hash,
      policyVersion: effective.version, configRevision: effective.config_revision, phase: detail.phase,
      fixtureHash: qualificationFixtureHash(),
    })));
    const probeReply = (verdict, observationHash) => ({ action: "probe", verdict, observationHash,
      contractHash: probe.contractHash, targetQualificationHash });
    if (probe.caseId === "resource_exhaustion_contained") {
      const pidsLimit = workload.HostConfig?.PidsLimit;
      const uid = effective.policy?.process?.run_as_user;
      const gid = effective.policy?.process?.run_as_group;
      const helper = "/.openshell/runtime/openshell-sandbox";
      if (!Number.isSafeInteger(pidsLimit) || pidsLimit < 2 || pidsLimit > 256 ||
        !/^[1-9][0-9]{0,8}$/.test(uid ?? "") || !/^[0-9]{1,9}$/.test(gid ?? "") ||
        !readOnlyPathAllows(effective.policy, helper) ||
        (effective.policy?.filesystem_policy?.read_write ?? []).some(value =>
          pathContains(value, helper) || pathContains(helper, value)))
        return probeReply("unsupported", null);
      try {
        const beforeLimit = (await docker(["exec", "--user", `${uid}:${gid}`, workload.Id,
          "/usr/bin/cat", "/sys/fs/cgroup/pids.max"], deadlineAt, false)).trim();
        if (beforeLimit !== String(pidsLimit)) return probeReply("unsupported", null);
        const before = await container(request.scope, detail, request.imageDigest, deadlineAt);
        if (before.Id !== workload.Id || !before.State.Running) throw new Error("sandbox_scope_changed");
        const result = await sandboxExec(request.scope, detail.id,
          [helper, "runtime-pids-probe", "--limit", String(pidsLimit)], deadlineAt);
        if (result.exitCode === 127 || result.exitCode === 124 || result.exitCode === null)
          return probeReply("unsupported", null);
        const after = await container(request.scope, detail, request.imageDigest, deadlineAt);
        const afterLimit = (await docker(["exec", "--user", `${uid}:${gid}`, workload.Id,
          "/usr/bin/cat", "/sys/fs/cgroup/pids.max"], deadlineAt, false)).trim();
        if (after.Id !== workload.Id || !after.State.Running || afterLimit !== String(pidsLimit))
          return probeReply("fail", null);
        if (result.exitCode !== 0) return probeReply("fail", null);
        let report;
        try { report = JSON.parse(result.stdout); } catch { return probeReply("fail", null); }
        const reportKeys = ["attempted", "baseline", "baseline_restored", "denied_errno", "limit", "reaped", "verdict", "version"];
        if (!report || Object.keys(report).sort().join("\0") !== reportKeys.join("\0") ||
          report.version !== 1 || report.verdict !== "pass" || report.limit !== pidsLimit ||
          report.denied_errno !== "EAGAIN" || report.baseline_restored !== true ||
          !Number.isInteger(report.baseline) || report.baseline < 1 || report.baseline >= pidsLimit ||
          report.attempted !== pidsLimit - report.baseline + 1 ||
          report.reaped !== report.attempted - 1)
          return probeReply("fail", null);
        const observation = { caseId: probe.caseId, contractHash: probe.contractHash,
          sandboxId: detail.id, containerId: workload.Id, imageDigest: request.imageDigest,
          policyHash: effective.hash, policyVersion: effective.version,
          configRevision: effective.config_revision, pidsLimit,
          cgroupLimitMatched: true, boundedChildrenReaped: true,
          excessPidDeniedWithEagain: true, sandboxStayedRunning: true };
        const hostConfig = workload.HostConfig;
        const cpuMillis = hostConfig?.NanoCpus / 1_000_000;
        const memoryBytes = hostConfig?.Memory;
        const diskBytes = Number(String(hostConfig?.StorageOpt?.size ?? "").replace(/B$/, ""));
        if (!Number.isSafeInteger(cpuMillis) || cpuMillis < 1 || cpuMillis > 3000 ||
          !Number.isSafeInteger(memoryBytes) || memoryBytes < 16 * 1024 * 1024 || memoryBytes > 256 * 1024 * 1024 ||
          hostConfig?.MemorySwap !== memoryBytes || !Number.isSafeInteger(diskBytes) ||
          diskBytes < 1024 * 1024 || diskBytes > 32 * 1024 * 1024 ||
          !dockerDiskStorageOptionMatches(workload, { diskBytes }) ||
          !dockerDiskMountsMatch(workload, effective.policy))
          return probeReply("unsupported", hash(JSON.stringify(canonical({ ...observation,
            completeResourceControl: false, missingDimensions: ["cpuMillis", "memoryBytes", "diskBytes"] }))));

        const cpuMax = (await docker(["exec", "--user", `${uid}:${gid}`, workload.Id,
          "/usr/bin/cat", "/sys/fs/cgroup/cpu.max"], deadlineAt, false)).trim().split(/\s+/);
        if (cpuMax.length !== 2 || !/^\d+$/.test(cpuMax[0]) || !/^\d+$/.test(cpuMax[1]))
          return probeReply("unsupported", null);
        const cpuQuota = Number(cpuMax[0]), cpuPeriod = Number(cpuMax[1]);
        if (!Number.isSafeInteger(cpuQuota) || !Number.isSafeInteger(cpuPeriod) || cpuPeriod < 1 ||
          Math.round(cpuQuota * 1000 / cpuPeriod) !== cpuMillis)
          return probeReply("unsupported", null);
        const workers = Math.ceil(cpuMillis / 1000) + 1;
        const cpuResult = await sandboxExec(request.scope, detail.id,
          [helper, "runtime-cpu-probe", "--workers", String(workers), "--millis", "250"], deadlineAt);
        if (cpuResult.exitCode !== 0) return probeReply("unsupported", hash(JSON.stringify(canonical({ ...observation, cpuCgroupMatched: true }))));
        let cpuReport;
        try { cpuReport = JSON.parse(cpuResult.stdout); } catch { return probeReply("fail", null); }
        if (!cpuReport || Object.keys(cpuReport).sort().join("\0") !==
          ["duration_ms", "period_us", "quota_us", "throttled_increased", "verdict", "version", "workers"].join("\0") ||
          cpuReport.version !== 1 || cpuReport.verdict !== "pass" || cpuReport.quota_us !== cpuQuota ||
          cpuReport.period_us !== cpuPeriod || cpuReport.workers !== workers || cpuReport.duration_ms !== 250 ||
          cpuReport.throttled_increased !== true)
          return probeReply("unsupported", hash(JSON.stringify(canonical({ ...observation, cpuCgroupMatched: true }))));

        const memoryMax = (await docker(["exec", "--user", `${uid}:${gid}`, workload.Id,
          "/usr/bin/cat", "/sys/fs/cgroup/memory.max"], deadlineAt, false)).trim();
        if (memoryMax !== String(memoryBytes)) return probeReply("unsupported", null);
        const memoryResult = await sandboxExec(request.scope, detail.id,
          [helper, "runtime-memory-probe", "--limit-bytes", String(memoryBytes)], deadlineAt);
        if (memoryResult.exitCode !== 0) return probeReply("unsupported", hash(JSON.stringify(canonical({
          ...observation, cpuThrottleObserved: true, memoryCgroupMatched: true }))));
        let memoryReport;
        try { memoryReport = JSON.parse(memoryResult.stdout); } catch { return probeReply("fail", null); }
        if (!memoryReport || Object.keys(memoryReport).sort().join("\0") !==
          ["child_reaped", "limit_bytes", "oom_kill_increased", "verdict", "version"].join("\0") ||
          memoryReport.version !== 1 || memoryReport.verdict !== "pass" ||
          memoryReport.limit_bytes !== memoryBytes || memoryReport.oom_kill_increased !== true ||
          memoryReport.child_reaped !== true)
          return probeReply("unsupported", hash(JSON.stringify(canonical({ ...observation,
            cpuThrottleObserved: true, memoryCgroupMatched: true }))));

        const workdir = workload.Config?.Labels?.["openshell.ai/workspace-root"];
        const writableRoots = effective.policy?.filesystem_policy?.read_write;
        if (typeof workdir !== "string" || !Array.isArray(writableRoots) ||
          !writableRoots.some(value => pathContains(value, workdir)))
          return probeReply("unsupported", null);
        const diskPath = path.posix.join(workdir, `.aw-v7-disk-probe-${randomUUID()}`);
        const diskResult = await sandboxExec(request.scope, detail.id,
          [helper, "runtime-disk-probe", "--limit-bytes", String(diskBytes), "--path", diskPath], deadlineAt);
        if (diskResult.exitCode !== 0) return probeReply("unsupported", hash(JSON.stringify(canonical({
          ...observation, cpuThrottleObserved: true, memoryOomObserved: true }))));
        let diskReport;
        try { diskReport = JSON.parse(diskResult.stdout); } catch { return probeReply("fail", null); }
        if (!diskReport || Object.keys(diskReport).sort().join("\0") !==
          ["enospc_observed", "limit_bytes", "temporary_file_removed", "verdict", "version"].join("\0") ||
          diskReport.version !== 1 || diskReport.verdict !== "pass" || diskReport.limit_bytes !== diskBytes ||
          diskReport.enospc_observed !== true || diskReport.temporary_file_removed !== true)
          return probeReply("unsupported", hash(JSON.stringify(canonical({ ...observation,
            cpuThrottleObserved: true, memoryOomObserved: true }))));
        const removed = await docker(["exec", "--user", `${uid}:${gid}`, workload.Id,
          "/usr/bin/test", "!", "-e", diskPath], deadlineAt, false);
        const afterDisk = await container(request.scope, detail, request.imageDigest, deadlineAt);
        if (removed !== "" || afterDisk.Id !== workload.Id || !afterDisk.State.Running)
          return probeReply("fail", null);
        return probeReply("pass", hash(JSON.stringify(canonical({ ...observation,
          cpuThrottleObserved: true, memoryOomObserved: true, diskEnospcObserved: true,
          temporaryFileRemoved: true, targetUnchangedAfterAllProbes: true }))));
      } catch {
        return probeReply("unsupported", null);
      }
    }
    if (probe.caseId === "force_stop") {
      if (!workload.State.Running || !dockerPersistentLogsDisabled(workload))
        return probeReply("unsupported", null);
      const initialPolicy = effective;
      try {
        await cli(["sandbox", "stop", request.scope.sandboxRef,
          "--expected-sandbox-id", detail.id], deadlineAt, false);
        const stoppedDetail = await observed(request.scope, deadlineAt);
        const stoppedWorkload = await container(request.scope, stoppedDetail,
          request.imageDigest, deadlineAt);
        if (stoppedDetail.id !== detail.id || stoppedDetail.phase !== "Stopped" ||
          stoppedWorkload.Id !== workload.Id || stoppedWorkload.State.Running)
          throw new Error("sandbox_stop_observation_failed");
        await cli(["sandbox", "start", request.scope.sandboxRef,
          "--expected-sandbox-id", detail.id], deadlineAt, false);
        const restartedDetail = await observed(request.scope, deadlineAt);
        const restartedWorkload = await container(request.scope, restartedDetail,
          request.imageDigest, deadlineAt);
        const restartedPolicy = await policy(request.scope, deadlineAt);
        if (restartedDetail.id !== detail.id || restartedDetail.phase !== "Ready" ||
          restartedWorkload.Id !== workload.Id || !restartedWorkload.State.Running ||
          restartedPolicy.hash !== initialPolicy.hash ||
          restartedPolicy.version !== initialPolicy.version ||
          restartedPolicy.config_revision !== initialPolicy.config_revision ||
          !sameDocument(restartedPolicy.policy, initialPolicy.policy) ||
          !dockerPersistentLogsDisabled(restartedWorkload))
          throw new Error("sandbox_restart_observation_failed");
        const observation = {
          caseId: probe.caseId, contractHash: probe.contractHash,
          sandboxId: detail.id, containerId: workload.Id, imageDigest: request.imageDigest,
          policyHash: initialPolicy.hash, policyVersion: initialPolicy.version,
          configRevision: initialPolicy.config_revision,
          stoppedObserved: true, restartedObserved: true,
          stopAndStartUsedExpectedSandboxId: true,
        };
        return probeReply("pass", hash(JSON.stringify(canonical(observation))));
      } catch {
        // A timed-out stop can have an unknown effect, so inspect the exact
        // UUID even when the CLI did not return. Restart only that same target.
        try {
          const current = await observed(request.scope, deadlineAt);
          if (current.id === detail.id && current.phase === "Stopped")
            await cli(["sandbox", "start", request.scope.sandboxRef,
              "--expected-sandbox-id", detail.id], deadlineAt, false);
        } catch {}
        return probeReply("unsupported", null);
      }
    }
    if (probe.caseId === "syscall_allow" || probe.caseId === "syscall_deny") {
      const helperPath = "/.openshell/runtime/openshell-sandbox";
      if (!readOnlyPathAllows(effective.policy, helperPath) ||
        (effective.policy?.filesystem_policy?.read_write ?? []).some(value =>
          pathContains(value, helperPath) || pathContains(helperPath, value)))
        return probeReply("unsupported", null);
      const result = await sandboxExec(request.scope, detail.id,
        [helperPath, "runtime-seccomp-probe"], deadlineAt);
      if (result.exitCode === 127 || result.exitCode === 124 || result.exitCode === null)
        return probeReply("unsupported", null);
      if (result.exitCode !== 0) return probeReply("fail", null);
      let report;
      try { report = JSON.parse(result.stdout); }
      catch { return probeReply("fail", null); }
      const expectedKeys = ["denied_errno", "getpid", "memfd_create", "profile", "version"];
      if (!report || Object.keys(report).sort().join("\0") !== expectedKeys.join("\0") ||
        report.version !== 1 || report.profile !== "openshell-linux-built-in-seccomp-v1" ||
        report.getpid !== "allowed" || report.memfd_create !== "denied" || report.denied_errno !== "EPERM")
        return probeReply("fail", null);
      const observation = {
        caseId: probe.caseId,
        contractHash: probe.contractHash,
        sandboxId: detail.id,
        containerId: workload.Id,
        imageDigest: request.imageDigest,
        policyHash: effective.hash,
        policyVersion: effective.version,
        configRevision: effective.config_revision,
        profile: report.profile,
        assertion: probe.caseId === "syscall_allow" ? "getpid_allowed" : "memfd_create_denied_eperm",
      };
      return probeReply("pass", hash(JSON.stringify(canonical(observation))));
    }
    let observation;
    if (probe.caseId === "process_nonprivileged") {
      const user = effective.policy?.process?.run_as_user;
      if (!/^[1-9][0-9]{0,8}$/.test(user ?? ""))
        return probeReply("unsupported", null);
      const result = await sandboxExec(request.scope, detail.id, ["/usr/bin/id", "-u"], deadlineAt);
      if (result.exitCode === 127 || result.exitCode === 124 || result.exitCode === null)
        return probeReply("unsupported", null);
      if (result.exitCode !== 0 || result.stdout.trim() !== user)
        return probeReply("fail", null);
      observation = { caseId: probe.caseId, contractHash: probe.contractHash, sandboxId: detail.id, policyHash: effective.hash, policyVersion: effective.version, configRevision: effective.config_revision, observedUid: Number(user) };
    } else if (probe.caseId === "process_privilege_denied") {
      const helper = "/.openshell/runtime/openshell-sandbox";
      if (!readOnlyPathAllows(effective.policy, helper) ||
        (effective.policy?.filesystem_policy?.read_write ?? []).some(value =>
          pathContains(value, helper) || pathContains(helper, value)))
        return probeReply("unsupported", null);
      const result = await sandboxExec(request.scope, detail.id, [helper, "runtime-privilege-probe"], deadlineAt);
      if (result.exitCode === 127 || result.exitCode === 124 || result.exitCode === null)
        return probeReply("unsupported", null);
      if (result.exitCode !== 0) return probeReply("fail", null);
      let report;
      try { report = JSON.parse(result.stdout); } catch { return probeReply("fail", null); }
      const passKeys = ["effective_capabilities_zero", "errno", "setuid_root", "uid_nonroot", "verdict", "version"];
      if (!report || Object.keys(report).sort().join("\0") !== passKeys.join("\0") || report.version !== 1)
        return probeReply("fail", null);
      if (report.verdict === "unsupported") return probeReply("unsupported", null);
      if (report.verdict !== "pass" || report.uid_nonroot !== true ||
        report.effective_capabilities_zero !== true || report.setuid_root !== "denied" || report.errno !== "EPERM")
        return probeReply("fail", null);
      observation = { caseId: probe.caseId, contractHash: probe.contractHash, sandboxId: detail.id,
        containerId: workload.Id, imageDigest: request.imageDigest, policyHash: effective.hash,
        policyVersion: effective.version, configRevision: effective.config_revision,
        assertion: "nonroot_zero_capabilities_setuid0_eperm" };
    } else if (["filesystem_allow", "filesystem_deny", "filesystem_escape"].includes(probe.caseId)) {
      const fixture = filesystemProbeFixture();
      if (!fixture) return probeReply("unsupported", null);
      const target = probe.caseId === "filesystem_allow" ? fixture.allowedReadPath :
        probe.caseId === "filesystem_deny" ? fixture.deniedReadPath : fixture.escapeTargetPath;
      const operand = probe.caseId === "filesystem_escape" ? fixture.escapeOperand : target;
      const expectedAllowed = probe.caseId === "filesystem_allow";
      if (filesystemPathAllowed(effective.policy, target) !== expectedAllowed ||
        (probe.caseId === "filesystem_escape" &&
          (!filesystemPathAllowed(effective.policy, fixture.escapeViaRoot) || filesystemPathAllowed(effective.policy, target))))
        return probeReply("unsupported", null);
      const marker = probe.caseId === "filesystem_allow" ? fixture.allowedReadMarker :
        probe.caseId === "filesystem_deny" ? fixture.deniedReadMarker : fixture.escapeReadMarker;
      const hostRead = await dockerCanaryRead(workload,
        effective.policy?.process?.run_as_user, effective.policy?.process?.run_as_group,
        target, marker, deadlineAt);
      if (!hostRead) return probeReply("unsupported", null);
      const before = await container(request.scope, detail, request.imageDigest, deadlineAt);
      if (before.Id !== workload.Id) throw new Error("sandbox_scope_changed");
      // /usr/bin/test reads metadata only. Docker exec verifies the same exact
      // immutable container and UID can see the canary outside OpenShell's
      // Landlock path; sandbox exec then tests the policy-bound path operand.
      const result = await sandboxExec(request.scope, detail.id, ["/usr/bin/head", "-c", "1", operand], deadlineAt);
      const after = await container(request.scope, detail, request.imageDigest, deadlineAt);
      if (after.Id !== workload.Id) throw new Error("sandbox_scope_changed");
      if (result.exitCode === 127 || result.exitCode === 124 || result.exitCode === null)
        return probeReply("unsupported", null);
      if (expectedAllowed && (result.exitCode !== 0 || result.stdout !== marker)) return probeReply("fail", null);
      if (!expectedAllowed && (result.exitCode !== 1 || result.stdout.length !== 0))
        return probeReply(result.exitCode === 0 ? "fail" : "unsupported", null);
      observation = { caseId: probe.caseId, contractHash: probe.contractHash, sandboxId: detail.id,
        containerId: workload.Id, imageDigest: request.imageDigest, policyHash: effective.hash,
        policyVersion: effective.version, configRevision: effective.config_revision,
        fixtureHash: qualificationFixtureHash(), targetPath: target,
        operandHash: hash(operand), canaryMarkerHash: hash(marker),
        hostCanaryMode: hostRead.mode, hostReadMatchedMarker: true,
        assertion: expectedAllowed ? "allowed_canary_read" : "host_readable_but_boundary_denied" };
    } else {
      // No other v0.1.2 probe is reported as passing without its dedicated
      // runtime assertion (including a policy_denied observation for denies).
      return probeReply("unsupported", null);
    }
    return probeReply("pass", hash(JSON.stringify(canonical(observation))));
  }
  async function observed(scope, deadlineAt) {
    const detail = await cli(
      ["sandbox", "get", scope.sandboxRef, "--output", "json"],
      deadlineAt,
    );
    const labels = {
      "aw.company_id": scope.companyId,
      "aw.binding_id": scope.bindingId,
      "aw.cell_id": scope.cellId,
      "aw.generation": scope.cellGeneration,
    };
    if (
      typeof detail.id !== "string" ||
      !uuid.test(detail.id) ||
      detail.name !== scope.sandboxRef ||
      detail.workspace !== config.workspace ||
      Object.entries(labels).some(
        ([key, value]) => detail.labels?.[key] !== value,
      )
    )
      throw new Error("sandbox_scope_changed");
    const pinned = journal.scopes[scope.bindingId];
    if (pinned) {
      if (
        Object.keys(scope).some((key) => pinned.scope[key] !== scope[key]) ||
        pinned.sandboxId !== detail.id
      ) throw new Error("sandbox_scope_changed");
    } else {
      if (Object.keys(journal.scopes).length >= 256)
        throw new Error("sandbox_host_unavailable");
      // The gateway's immutable sandbox ID is distinct from a reusable name.
      // Persist it before the first effect, so restart cannot adopt a replacement.
      journal.scopes[scope.bindingId] = { scope, sandboxId: detail.id };
      await atomicJson(journalFile, journal);
    }
    return detail;
  }
  async function policy(scope, deadlineAt) {
    const result = await cli(
      ["policy", "get", scope.sandboxRef, "--full", "--output", "json"],
      deadlineAt,
    );
    if (
      result.sandbox !== scope.sandboxRef ||
      result.status !== "effective" ||
      !/^[a-f0-9]{64}$/.test(result.hash ?? "") ||
      !Number.isSafeInteger(result.version) ||
      result.version < 0 ||
      !Number.isSafeInteger(result.config_revision) ||
      result.config_revision < 0 ||
      !result.policy
    )
      throw new Error("sandbox_observation_unavailable");
    await observed(scope, deadlineAt);
    return result;
  }
  async function container(scope, sandbox, imageDigest, deadlineAt) {
    const engineId = (await docker(["info", "--format", "{{.ID}}"], deadlineAt, false)).trim();
    if (!engineId || engineId.length > 200 || /[\r\n\0]/.test(engineId))
      throw new Error("sandbox_operation_unsupported");
    const engineIdHash = hash(engineId);
    const enginePin = journal.scopes[scope.bindingId]?.dockerEngineId;
    if (enginePin && enginePin !== engineIdHash)
      throw new Error("sandbox_scope_changed");
    const idsOutput = await docker(
      [
        "ps",
        "-aq",
        "--filter",
        `label=openshell.ai/sandbox-id=${sandbox.id}`,
        "--filter",
        "label=openshell.ai/isolation-role=sandbox",
      ],
      deadlineAt,
      false,
    );
    const ids = idsOutput.trim().split(/\s+/).filter(Boolean);
    if (ids.length !== 1 || !/^[a-f0-9]{64}$/.test(ids[0]))
      throw new Error("sandbox_operation_unsupported");
    const values = await docker(["inspect", ids[0]], deadlineAt);
    if (!Array.isArray(values) || values.length !== 1)
      throw new Error("sandbox_observation_unavailable");
    const value = values[0];
    const labels = value.Config?.Labels;
    const expectedLabels = {
      "openshell.ai/managed-by": "openshell",
      "openshell.ai/sandbox-id": sandbox.id,
      "openshell.ai/sandbox-name": scope.sandboxRef,
      "openshell.ai/sandbox-workspace": config.workspace,
      "openshell.ai/isolation-backend": "openshell-sandbox",
      "openshell.ai/isolation-role": "sandbox",
      "aw.company_id": scope.companyId,
      "aw.binding_id": scope.bindingId,
      "aw.cell_id": scope.cellId,
      "aw.generation": scope.cellGeneration,
    };
    if (
      value.Id !== ids[0] ||
      Object.entries(expectedLabels).some(([key, expected]) => labels?.[key] !== expected) ||
      !/^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,100}$/.test(labels?.["openshell.ai/sandbox-namespace"] ?? "") ||
      value.Config?.Image !== value.Image ||
      !Array.isArray(value.RepoDigests) ||
      !value.RepoDigests.includes(imageDigest) ||
      !/^sha256:[a-f0-9]{64}$/.test(value.Image ?? "") ||
      typeof value.State?.Running !== "boolean"
    )
      throw new Error("sandbox_scope_changed");
    const pinned = journal.scopes[scope.bindingId];
    if (pinned.containerId && pinned.containerId !== value.Id)
      throw new Error("sandbox_scope_changed");
    if (pinned.imageId && pinned.imageId !== value.Image)
      throw new Error("sandbox_scope_changed");
    if (
      pinned.namespace &&
      pinned.namespace !== labels["openshell.ai/sandbox-namespace"]
    )
      throw new Error("sandbox_scope_changed");
    if (!pinned.containerId || !pinned.dockerEngineId) {
      journal.scopes[scope.bindingId] = {
        ...pinned,
        containerId: value.Id,
        imageId: value.Image,
        namespace: labels["openshell.ai/sandbox-namespace"],
        dockerEngineId: engineIdHash,
      };
      await atomicJson(journalFile, journal);
    }
    return value;
  }
  async function contain(scope, imageDigest, deadlineAt) {
    try {
      await revokeProviders(scope, deadlineAt);
      const target = await observed(scope, deadlineAt);
      await cli(["sandbox", "stop", scope.sandboxRef, "--expected-sandbox-id", target.id], deadlineAt, false);
      const stopped = await observed(scope, deadlineAt);
      const workload = await container(scope, stopped, imageDigest, deadlineAt);
      if (stopped.phase !== "Stopped" || workload.State.Running)
        throw new Error("sandbox_observation_unavailable");
      await deleteQuiescedBrokerProviders(scope, deadlineAt);
    } catch {
      throw new Error("sandbox_host_unavailable");
    }
  }
  function staticPolicyMatches(left, right) {
    return (
      sameDocument(left.filesystem_policy, right.filesystem_policy) &&
      sameDocument(left.landlock, right.landlock) &&
      sameDocument(left.process, right.process)
    );
  }
  async function revokeProviders(scope, deadlineAt) {
    const before = await cli(
      ["sandbox", "provider", "list", scope.sandboxRef, "--page-size", "4", "--output", "json"],
      deadlineAt,
    );
    if (!Array.isArray(before.providers) || before.providers.length > 4 || before.next_page_token !== "")
      throw new Error("sandbox_operation_unsupported");
    for (const provider of before.providers) {
      const target = await observed(scope, deadlineAt);
      if (!/^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,100}$/.test(provider.name ?? ""))
        throw new Error("sandbox_observation_unavailable");
      await cli(
        ["sandbox", "provider", "detach", scope.sandboxRef, provider.name, "--expected-sandbox-id", target.id, "--wait", "--timeout", "2", "--output", "json"],
        deadlineAt,
      );
    }
    const after = await cli(
      ["sandbox", "provider", "list", scope.sandboxRef, "--page-size", "4", "--output", "json"],
      deadlineAt,
    );
    if (!Array.isArray(after.providers) || after.providers.length || after.next_page_token !== "")
      throw new Error("sandbox_observation_unavailable");
    await observed(scope, deadlineAt);
  }
  function samePolicyRevision(result, pinned) {
    return (
      result.hash === pinned.effectivePolicyHash &&
      result.version === pinned.policyVersion &&
      result.config_revision === pinned.configRevision &&
      sameDocument(result.policy, pinned.document)
    );
  }
  function provisioningLabels(scope, requestId, provisioningHash, operationKey) {
    return {
      "aw.company_id": scope.companyId,
      "aw.binding_id": scope.bindingId,
      "aw.cell_id": scope.cellId,
      "aw.generation": scope.cellGeneration,
      "aw.provisioning_request_id": requestId,
      "aw.provisioning_hash": provisioningHash,
      "aw.operation_key_hash": hash(operationKey),
    };
  }
  async function listProvisioningCandidates(scope, deadlineAt) {
    const result = await cli(["sandbox", "list", "--selector", `aw.binding_id=${scope.bindingId}`,
      "--page-size", "10", "--output", "json"], deadlineAt);
    if (!Array.isArray(result.sandboxes) || result.sandboxes.length > 10 || result.next_page_token !== "")
      throw new Error("sandbox_observation_unavailable");
    return result.sandboxes;
  }
  function verifyProvisioningMarker(value, scope, requestId, provisioningHash, operationKey) {
    const expectedLabels = provisioningLabels(scope, requestId, provisioningHash, operationKey);
    return value && value.name === scope.sandboxRef && typeof value.id === "string" && uuid.test(value.id) &&
      value.workspace === config.workspace && Object.entries(expectedLabels).every(([key, expected]) =>
        value.labels?.[key] === expected);
  }
  async function cleanupExpiredProvisioning(request, detail, workload, provisioning, deadlineAt) {
    if (detail.phase !== "Stopped" || workload.State.Running) {
      await cli(["sandbox", "stop", request.scope.sandboxRef,
        "--expected-sandbox-id", detail.id], deadlineAt, false);
      const stopped = await observed(request.scope, deadlineAt);
      const stoppedWorkload = await container(request.scope, stopped, request.imageDigest, deadlineAt);
      if (stopped.id !== detail.id || stopped.phase !== "Stopped" ||
        stoppedWorkload.Id !== workload.Id || stoppedWorkload.State.Running)
        throw new Error("sandbox_observation_unavailable");
    }
    await cli(["sandbox", "delete", request.scope.sandboxRef,
      "--expected-sandbox-id", detail.id], deadlineAt, false);
    const remaining = await listProvisioningCandidates(request.scope, deadlineAt);
    if (remaining.some(value => value.id === detail.id || value.name === request.scope.sandboxRef))
      throw new Error("sandbox_observation_unavailable");
    delete journal.scopes[request.scope.bindingId];
    await atomicJson(journalFile, journal);
    throw new Error("sandbox_scope_changed");
  }
  async function prepareProvisionedSandbox(request, deadlineAt) {
    const scope = request.scope;
    const { envelope, provisioningHash, requestId, expired } = validateProvisioning(request);
    const value = request.provisioning;
    const prior = journal.scopes[scope.bindingId];
    if (prior && (!sameDocument(prior.scope, scope) || !prior.provisioning ||
      prior.provisioning.provisioningHash !== provisioningHash ||
      prior.provisioning.requestId !== requestId ||
      !sameDocument(prior.provisioning.envelope, envelope)))
      throw new Error("sandbox_scope_changed");
    if (!prior && expired) throw new Error("sandbox_scope_changed");
    if (!prior && value.idleUntilUnixSeconds <= Math.floor(Date.now() / 1000) + 1)
      throw new Error("sandbox_scope_changed");
    if (!prior) {
      journal.scopes[scope.bindingId] = {
        scope,
        sandboxId: null,
        provisioning: {
          state: "claimed", envelope, provisioningHash, requestId,
          operationKeyHash: hash(value.operationKey), imageDigest: request.imageDigest,
          resourceLimits: value.resourceLimits, purpose: value.purpose,
          expiresAt: value.expiresAt, idleUntilUnixSeconds: value.idleUntilUnixSeconds,
        },
      };
      await atomicJson(journalFile, journal);
    }
    const labels = provisioningLabels(scope, requestId, provisioningHash, value.operationKey);
    let candidates = await listProvisioningCandidates(scope, deadlineAt);
    if (candidates.length > 1 || candidates.some(candidate => !verifyProvisioningMarker(
      candidate, scope, requestId, provisioningHash, value.operationKey)))
      throw new Error("sandbox_scope_changed");
    let candidate = candidates[0] ?? null;
    if (prior?.sandboxId && (!candidate || candidate.id !== prior.sandboxId))
      throw new Error("sandbox_scope_changed");
    if (candidate && prior?.sandboxId && candidate.id !== prior.sandboxId)
      throw new Error("sandbox_scope_changed");
    if (!candidate && expired) throw new Error("sandbox_scope_changed");

    if (!candidate) {
      const privateConfig = await privateConfiguration();
      const filename = path.join(privateConfig.stateHome, `provisioning-policy-${randomUUID()}.json`);
      const driverConfig = JSON.stringify({ docker: {
        disk_limit_bytes: String(value.resourceLimits.diskBytes),
        pids_limit: value.resourceLimits.pidsLimit,
      } });
      const labelsArgs = Object.entries(labels).flatMap(([key, label]) => ["--label", `${key}=${label}`]);
      const cpu = `${value.resourceLimits.cpuMillis}m`;
      const idle = ["/.openshell/runtime/openshell-sandbox", "runtime-idle-until",
        "--unix-seconds", String(value.idleUntilUnixSeconds)];
      try {
        await writeFile(filename, JSON.stringify(canonical(value.document)), { flag: "wx", mode: 0o600 });
        try {
          await cli(["sandbox", "create", "--request-id", requestId,
            "--no-auto-providers", "--name", scope.sandboxRef,
            "--from", request.imageDigest,
            "--driver-config-json", driverConfig,
            "--cpu", cpu,
            "--memory", String(value.resourceLimits.memoryBytes),
            "--policy", filename,
            ...labelsArgs,
            "--detach", "--output", "json", "--", ...idle], deadlineAt);
        } catch {
          // The gateway can commit a create while the CLI response is lost.
          // Resolve only through this already-journaled deterministic marker.
        }
        candidates = await listProvisioningCandidates(scope, deadlineAt);
        if (candidates.length !== 1 || !verifyProvisioningMarker(candidates[0], scope,
          requestId, provisioningHash, value.operationKey))
          throw new Error("sandbox_observation_unavailable");
        candidate = candidates[0];
      } finally {
        await unlink(filename).catch(() => {});
      }
    }
    if (!candidate || !verifyProvisioningMarker(candidate, scope, requestId,
      provisioningHash, value.operationKey))
      throw new Error("sandbox_scope_changed");

    const entry = journal.scopes[scope.bindingId];
    if (entry.sandboxId && entry.sandboxId !== candidate.id)
      throw new Error("sandbox_scope_changed");
    entry.sandboxId = candidate.id;
    entry.provisioning = { ...entry.provisioning, state: "observed", sandboxId: candidate.id };
    await atomicJson(journalFile, journal);
    const detail = await observed(scope, deadlineAt);
    if (detail.id !== candidate.id || !verifyProvisioningMarker(detail, scope, requestId,
      provisioningHash, value.operationKey))
      throw new Error("sandbox_scope_changed");
    const workload = await container(scope, detail, request.imageDigest, deadlineAt);
    const currentPolicy = await policy(scope, deadlineAt);
    if (workload.Config?.Labels?.["aw.provisioning_request_id"] !== requestId ||
      workload.Config?.Labels?.["aw.provisioning_hash"] !== provisioningHash ||
      workload.Config?.Labels?.["aw.operation_key_hash"] !== hash(value.operationKey) ||
      !sameDocument(currentPolicy.policy, value.document) ||
      !(await dockerDiskQuotaBackendSupported(deadlineAt)) ||
      !resourceHostConfigMatches(workload, value.resourceLimits, value.document) ||
      !(await dockerSupervisorLogsDisabled(scope, detail, deadlineAt)))
      throw new Error("sandbox_observation_unavailable");
    if (expired) return cleanupExpiredProvisioning(request, detail, workload, value, deadlineAt);
    if (detail.phase !== "Ready" || !workload.State.Running)
      throw new Error("sandbox_observation_unavailable");

    if (value.purpose === "admission") {
      await cli(["sandbox", "stop", scope.sandboxRef,
        "--expected-sandbox-id", detail.id], deadlineAt, false);
      const stopped = await observed(scope, deadlineAt);
      const stoppedWorkload = await container(scope, stopped, request.imageDigest, deadlineAt);
      if (stopped.id !== detail.id || stopped.phase !== "Stopped" ||
        stoppedWorkload.Id !== workload.Id || stoppedWorkload.State.Running ||
        !resourceHostConfigMatches(stoppedWorkload, value.resourceLimits, value.document))
        throw new Error("sandbox_observation_unavailable");
    }
    entry.containerId = workload.Id;
    entry.provisioning = { ...entry.provisioning, state: value.purpose === "qualification" ? "ready" : "stopped",
      containerId: workload.Id, observedPolicyHash: currentPolicy.hash,
      policyVersion: currentPolicy.version, configRevision: currentPolicy.config_revision };
    await atomicJson(journalFile, journal);
    return {
      action: "prepare", backendVersion: "0.1.2", imageDigest: request.imageDigest,
      hostEpoch: epoch, sandboxId: detail.id, containerId: workload.Id, provisioningHash,
    };
  }
  async function executeAction(request, deadlineAt) {
    const scope = request.scope;
    const sourceExpiry = request.action === "apply"
      ? request.admission?.expiresAt
      : request.action === "start"
        ? request.start?.expiresAt
        : null;
    if (sourceExpiry !== null && sourceExpiry !== undefined &&
      (!Number.isFinite(Date.parse(sourceExpiry)) ||
        Date.parse(sourceExpiry) <= Date.now() ||
        Date.parse(deadlineAt) > Date.parse(sourceExpiry))) {
      throw new Error("sandbox_scope_changed");
    }
    // Capabilities come from live CLI, gateway, policy and container
    // observations. Probes execute inside that observed sandbox; unavailable
    // runtimes never inherit a fixture or request-body success.
    if (!config && request.action === "capabilities") return { action: "capabilities", capabilities: null };
    if (!config && request.action === "probe") return { action: "probe", verdict: "unsupported", observationHash: null, contractHash: request.probe.contractHash };
    if (!config) throw new Error("sandbox_host_unavailable");
    const version = await cli(["--version"], deadlineAt, false);
    if (version.trim() !== "openshell 0.1.2") throw new Error("sandbox_host_unavailable");
    if (request.action === "capabilities") {
      try { return { action: "capabilities", capabilities: await hostCapabilities(request, scope, deadlineAt) }; }
      catch { return { action: "capabilities", capabilities: null }; }
    }
    if (request.action === "probe") return probeBoundary(request, deadlineAt);
    if (request.action === "prepare" && request.provisioning)
      return prepareProvisionedSandbox(request, deadlineAt);
    const detail = await observed(scope, deadlineAt);
    if (request.action === "inspect") {
      try {
        const workload = await container(scope, detail, request.imageDigest, deadlineAt);
        let policyHash = null;
        const pinnedPolicy = journal.scopes[scope.bindingId]?.policy;
        if (pinnedPolicy) {
          const currentPolicy = await policy(scope, deadlineAt);
          if (samePolicyRevision(currentPolicy, pinnedPolicy) &&
            await dockerDiskQuotaBackendSupported(deadlineAt) &&
            resourceHostConfigMatches(workload, pinnedPolicy.resourceLimits, pinnedPolicy.document))
            policyHash = pinnedPolicy.policyHash;
        }
        return {
          action: "inspect",
          state: detail.phase === "Error" ? "failed" :
            detail.phase === "Stopped" && !workload.State.Running ? "stopped" :
            detail.phase === "Ready" && workload.State.Running ? "running" : "unknown",
          policyHash,
          imageDigest: request.imageDigest,
          generation: scope.cellGeneration,
          // The command path has physical observations, but the release profile
          // still has no complete qualified capability snapshot.
          controlsHealthy: false,
        };
      } catch {
        return {
          action: "inspect",
          state: "unknown",
          policyHash: null,
          imageDigest: null,
          generation: scope.cellGeneration,
          controlsHealthy: false,
        };
      }
    }
    if (request.action === "prepare") {
      // Preparation is verification of a controller-pinned, pre-provisioned
      // sandbox. OpenShell v0.1.2's `sandbox get` does not expose the image,
      // so bind this receipt to the actual Docker daemon/container observation
      // rather than echoing the requested image digest. This action never
      // creates or adopts a sandbox and cannot qualify the physical controls.
      if (detail.phase !== "Stopped")
        throw new Error("sandbox_operation_unsupported");
      const workload = await container(scope, detail, request.imageDigest, deadlineAt);
      if (workload.State.Running)
        throw new Error("sandbox_operation_unsupported");
      return {
        action: "prepare",
        backendVersion: "0.1.2",
        imageDigest: request.imageDigest,
      };
    }
    if (request.action === "effective_policy") {
      const current = await policy(scope, deadlineAt);
      return { action: "effective_policy", document: current.policy };
    }
    if (request.action === "apply") {
      const admission = request.admission;
      if (!admission || Date.parse(admission.expiresAt) <= Date.now()) throw new Error("sandbox_scope_changed");
      const workload = await container(scope, detail, request.imageDigest, deadlineAt);
      if (detail.phase !== "Stopped" || workload.State.Running)
        throw new Error("sandbox_operation_unsupported");
      if (!validResourceLimits(admission.resourceLimits)) throw new Error("sandbox_scope_changed");
      if (admission.credentialProviderProfile) await inspectCredentialProviderProfile(admission.credentialProviderProfile, deadlineAt);
      await revokeProviders(scope, deadlineAt);
      const before = await policy(scope, deadlineAt);
      if (!staticPolicyMatches(before.policy, admission.document))
        return {
          action: "apply",
          applied: false,
          policyHash: null,
          requiresRecreate: true,
          effectivePolicyHash: before.hash,
        };
      if (!(await dockerDiskQuotaBackendSupported(deadlineAt)) ||
        !dockerDiskStorageOptionMatches(workload, admission.resourceLimits) ||
        !dockerPersistentLogsDisabled(workload) ||
        !(await dockerSupervisorLogsDisabled(scope, detail, deadlineAt)))
        return {
          action: "apply",
          applied: false,
          policyHash: null,
          requiresRecreate: true,
          effectivePolicyHash: before.hash,
        };
      if (!dockerDiskMountsMatch(workload, admission.document))
        throw new Error("sandbox_operation_unsupported");
      const boundedWorkload = await applyDockerResourceLimits(scope, detail, request.imageDigest,
        admission.resourceLimits, deadlineAt, workload.Id, admission.document);
      if (!resourceHostConfigMatches(boundedWorkload, admission.resourceLimits, admission.document))
        throw new Error("sandbox_observation_unavailable");
      const privateConfig = await privateConfiguration();
      const filename = path.join(privateConfig.stateHome, `policy-${randomUUID()}.json`);
      try {
        await writeFile(filename, JSON.stringify(admission.document), {
          flag: "wx",
          mode: 0o600,
        });
        const remaining = Math.floor(
          (new Date(deadlineAt).getTime() - Date.now()) / 1000,
        );
        if (remaining < 1) throw new Error("sandbox_host_unavailable");
        await cli(
          [
            "policy",
            "set",
            scope.sandboxRef,
            "--policy",
            filename,
            "--wait",
            "--timeout",
            String(Math.min(6, remaining)),
            "--expected-sandbox-id",
            detail.id,
          ],
          deadlineAt,
          false,
        );
      } catch (error) {
        let committed = false;
        try {
          committed = sameDocument(
            (await policy(scope, deadlineAt)).policy,
            admission.document,
          );
        } catch {}
        if (!committed) await contain(scope, request.imageDigest, deadlineAt);
        if (committed) {
          const observedPolicy = await policy(scope, deadlineAt);
          journal.scopes[scope.bindingId] = {
            ...journal.scopes[scope.bindingId],
            policy: {
              policyHash: admission.policyHash,
              effectivePolicyHash: observedPolicy.hash,
              policyVersion: observedPolicy.version,
              configRevision: observedPolicy.config_revision,
              document: observedPolicy.policy,
              resourceLimits: admission.resourceLimits,
              ...(admission.credentialProviderProfile ? { credentialProviderProfile: admission.credentialProviderProfile } : {}),
              appliedAt: new Date().toISOString(),
            },
          };
          await atomicJson(journalFile, journal);
          return {
            action: "apply",
            applied: true,
            policyHash: admission.policyHash,
            requiresRecreate: false,
            effectivePolicyHash: observedPolicy.hash,
          };
        }
        if ([
          "sandbox_host_unavailable",
          "sandbox_scope_changed",
          "sandbox_operation_unsupported",
          "sandbox_observation_unavailable",
        ].includes(error?.message)) throw error;
        throw new Error("sandbox_observation_unavailable");
      } finally {
        await unlink(filename).catch(() => {});
      }
      const after = await policy(scope, deadlineAt);
      if (!sameDocument(after.policy, admission.document)) {
        await contain(scope, request.imageDigest, deadlineAt);
        throw new Error("sandbox_observation_unavailable");
      }
      journal.scopes[scope.bindingId] = {
        ...journal.scopes[scope.bindingId],
        policy: {
          policyHash: admission.policyHash,
          effectivePolicyHash: after.hash,
          policyVersion: after.version,
          configRevision: after.config_revision,
          document: after.policy,
          resourceLimits: admission.resourceLimits,
          ...(admission.credentialProviderProfile ? { credentialProviderProfile: admission.credentialProviderProfile } : {}),
          appliedAt: new Date().toISOString(),
        },
      };
      await atomicJson(journalFile, journal);
      return {
        action: "apply",
        applied: true,
        policyHash: admission.policyHash,
        requiresRecreate: false,
        effectivePolicyHash: after.hash,
      };
    }
    if (request.action === "start") {
      const start = request.start;
      if (
        !start ||
        new Date(start.expiresAt) <= new Date() ||
        !/^[a-f0-9]{64}$/.test(start.policyHash)
      )
        throw new Error("sandbox_scope_changed");
      const pinnedPolicy = journal.scopes[scope.bindingId]?.policy;
      if (!pinnedPolicy || pinnedPolicy.policyHash !== start.policyHash)
        throw new Error("sandbox_scope_changed");
      await revokeProviders(scope, deadlineAt);
      const beforePolicy = await policy(scope, deadlineAt);
      if (!samePolicyRevision(beforePolicy, pinnedPolicy))
        throw new Error("sandbox_scope_changed");
      const beforeWorkload = await container(
        scope,
        detail,
        request.imageDigest,
        deadlineAt,
      );
      if (!(await dockerDiskQuotaBackendSupported(deadlineAt)))
        throw new Error("sandbox_operation_unsupported");
      if (detail.phase === "Ready" && beforeWorkload.State.Running) {
        if (!resourceHostConfigMatches(beforeWorkload, pinnedPolicy.resourceLimits, pinnedPolicy.document))
          throw new Error("sandbox_observation_unavailable");
        return {
          action: "start",
          started: true,
          operationId: hash(start.idempotencyKey),
          sandboxId: detail.id,
          containerId: beforeWorkload.Id,
          imageDigest: request.imageDigest,
          policyHash: start.policyHash,
          effectivePolicyHash: beforePolicy.hash,
        };
      }
      if (detail.phase !== "Stopped" || beforeWorkload.State.Running ||
        !resourceHostConfigMatches(beforeWorkload, pinnedPolicy.resourceLimits, pinnedPolicy.document))
        throw new Error("sandbox_operation_unsupported");
      try {
        await cli(["sandbox", "start", scope.sandboxRef, "--expected-sandbox-id", detail.id], deadlineAt, false);
      } catch {
        // A lost CLI response is resolved from independent gateway and Docker
        // observations below; it is never treated as success by itself.
      }
      const afterDetail = await observed(scope, deadlineAt);
      const afterPolicy = await policy(scope, deadlineAt);
      const afterWorkload = await container(
        scope,
        afterDetail,
        request.imageDigest,
        deadlineAt,
      );
      if (
        afterDetail.phase !== "Ready" ||
        !afterWorkload.State.Running ||
        !resourceHostConfigMatches(afterWorkload, pinnedPolicy.resourceLimits, pinnedPolicy.document) ||
        !(await dockerSupervisorLogsDisabled(scope, afterDetail, deadlineAt)) ||
        !samePolicyRevision(afterPolicy, pinnedPolicy)
      ) {
        await contain(scope, request.imageDigest, deadlineAt);
        throw new Error("sandbox_observation_unavailable");
      }
      return {
        action: "start",
        started: true,
        operationId: hash(start.idempotencyKey),
        sandboxId: afterDetail.id,
        containerId: afterWorkload.Id,
        imageDigest: request.imageDigest,
        policyHash: start.policyHash,
        effectivePolicyHash: afterPolicy.hash,
      };
    }
    if (request.action === "stop") {
      await cli(["sandbox", "stop", scope.sandboxRef, "--expected-sandbox-id", detail.id], deadlineAt, false);
      if ((await observed(scope, deadlineAt)).phase !== "Stopped")
        throw new Error("sandbox_observation_unavailable");
      return { action: "stop", stopped: true };
    }
    if (request.action === "destroy") {
      await cli(["sandbox", "delete", scope.sandboxRef, "--expected-sandbox-id", detail.id], deadlineAt, false);
      const remaining = await cli(
        [
          "sandbox",
          "list",
          "--selector",
          `aw.binding_id=${scope.bindingId}`,
          "--page-size",
          "10",
          "--output",
          "json",
        ],
        deadlineAt,
      );
      if (
        !Array.isArray(remaining.sandboxes) ||
        remaining.sandboxes.length > 10 ||
        remaining.next_page_token !== "" ||
        remaining.sandboxes.some((value) =>
          value.name === scope.sandboxRef || value.id === detail.id,
        )
      )
        throw new Error("sandbox_observation_unavailable");
      delete journal.scopes[scope.bindingId];
      await atomicJson(journalFile, journal);
      return { action: "destroy", destroyed: true };
    }
    if (request.action === "revoke_providers") {
      const providers = await cli(
        [
          "sandbox",
          "provider",
          "list",
          scope.sandboxRef,
          "--page-size",
          "4",
          "--output",
          "json",
        ],
        deadlineAt,
      );
      if (
        !Array.isArray(providers.providers) ||
        providers.providers.length > 4 ||
        providers.next_page_token !== ""
      )
        throw new Error("sandbox_operation_unsupported");
      for (const provider of providers.providers) {
        const target = await observed(scope, deadlineAt);
        if (!/^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,100}$/.test(provider.name))
          throw new Error("sandbox_observation_unavailable");
        await cli(
          [
            "sandbox",
            "provider",
            "detach",
            scope.sandboxRef,
            provider.name,
            "--expected-sandbox-id",
            target.id,
            "--wait",
            "--timeout",
            "2",
            "--output",
            "json",
          ],
          deadlineAt,
        );
      }
      const after = await cli(
        [
          "sandbox",
          "provider",
          "list",
          scope.sandboxRef,
          "--page-size",
          "4",
          "--output",
          "json",
        ],
        deadlineAt,
      );
      if (
        !Array.isArray(after.providers) ||
        after.providers.length ||
        after.next_page_token !== ""
      )
        throw new Error("sandbox_observation_unavailable");
      await observed(scope, deadlineAt);
      return { action: "revoke_providers", revoked: true };
    }
    // CLI sandbox detail does not expose an observed immutable image digest.
    // Configured image/labels therefore cannot earn a preparation receipt.
    throw new Error("sandbox_operation_unsupported");
  }
  async function executeStream(input, onOutput, signal) {
    const request = input?.request;
    const requestKeys = ["requestId", "bindingId", "hostEpoch", "runId", "attemptId", "attempt", "manifestId", "manifestHash", "policySnapshotId", "policyHash", "commandDigest", "deadlineAt", "sandboxRef", "imageDigest", "argv", "cwd", "env", "stdinBase64"];
    const requestVariants = [requestKeys, [...requestKeys, "brokerCredential"], [...requestKeys, "modelBrokerCredential"], [...requestKeys, "brokerCredential", "modelBrokerCredential"]];
    if (!input || !validScope(input.scope) || !request ||
      !requestVariants.some(keys => Object.keys(request).sort().join(",") === keys.slice().sort().join(",")) ||
      !uuid.test(request.requestId) || request.bindingId !== input.scope.bindingId ||
      request.hostEpoch !== epoch || !uuid.test(request.runId) ||
      (request.attemptId !== null && !uuid.test(request.attemptId)) ||
      !Number.isSafeInteger(request.attempt) || request.attempt < 1 ||
      !uuid.test(request.manifestId) || !/^[a-f0-9]{64}$/.test(request.manifestHash) ||
      !uuid.test(request.policySnapshotId) || !/^[a-f0-9]{64}$/.test(request.policyHash) ||
      !/^[a-f0-9]{64}$/.test(request.commandDigest) ||
      request.sandboxRef !== input.scope.sandboxRef ||
      !/^[a-z0-9./:_-]+@sha256:[a-f0-9]{64}$/i.test(request.imageDigest) ||
      !Array.isArray(request.argv) || request.argv.length < 1 || request.argv.length > 64 ||
      request.argv.some(value => typeof value !== "string" || !value.length || value.length > 8192) ||
      typeof request.cwd !== "string" || !path.isAbsolute(request.cwd) ||
      !request.env || typeof request.env !== "object" || Array.isArray(request.env) || Object.keys(request.env).length > 64 ||
      Object.entries(request.env).some(([key, value]) => !/^[A-Za-z_][A-Za-z0-9_]{0,127}$/.test(key) || typeof value !== "string" || value.length > 8192 ||
        (/(?:TOKEN|SECRET|PASSWORD|CREDENTIAL|API[_-]?KEY|PRIVATE[_-]?KEY|AUTHORIZATION)/i.test(key) &&
          !(request.modelBrokerCredential && (
            (key === "PAPERCLIP_MANAGED_MODEL_INPUT_TOKENS_UPPER_BOUND" && value === String(request.modelBrokerCredential.inputTokensUpperBound)) ||
            (key === "PAPERCLIP_MANAGED_MODEL_MAX_OUTPUT_TOKENS" && value === String(request.modelBrokerCredential.maxOutputTokens))
          )))) ||
      (request.brokerCredential !== undefined && (!request.brokerCredential || typeof request.brokerCredential.capabilityToken !== "string" || request.brokerCredential.capabilityToken.length > 16_384 ||
        typeof request.brokerCredential.profileId !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,99}$/.test(request.brokerCredential.profileId) ||
        typeof request.brokerCredential.profileHash !== "string" || !/^[a-f0-9]{64}$/.test(request.brokerCredential.profileHash) ||
        typeof request.brokerCredential.expiresAt !== "string" || !Number.isFinite(Date.parse(request.brokerCredential.expiresAt)))) ||
      (!!request.brokerCredential !== (typeof request.env.PAPERCLIP_SANDBOX_BROKER_ENDPOINT_ORIGIN === "string" && typeof request.env.PAPERCLIP_SANDBOX_BROKER_SESSION_ID === "string")) ||
      (request.modelBrokerCredential !== undefined && (!request.modelBrokerCredential || typeof request.modelBrokerCredential.capabilityToken !== "string" || request.modelBrokerCredential.capabilityToken.length > 16_384 ||
        typeof request.modelBrokerCredential.profileId !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,99}$/.test(request.modelBrokerCredential.profileId) ||
        typeof request.modelBrokerCredential.profileHash !== "string" || !/^[a-f0-9]{64}$/.test(request.modelBrokerCredential.profileHash) ||
        typeof request.modelBrokerCredential.expiresAt !== "string" || !Number.isFinite(Date.parse(request.modelBrokerCredential.expiresAt)) ||
        !Number.isSafeInteger(request.modelBrokerCredential.inputTokensUpperBound) || request.modelBrokerCredential.inputTokensUpperBound < 1 || request.modelBrokerCredential.inputTokensUpperBound > 2_000_000 ||
        !Number.isSafeInteger(request.modelBrokerCredential.maxOutputTokens) || request.modelBrokerCredential.maxOutputTokens < 256 || request.modelBrokerCredential.maxOutputTokens > 8192)) ||
      (!!request.modelBrokerCredential !== (typeof request.env.PAPERCLIP_MANAGED_MODEL_BROKER_ORIGIN === "string")) ||
      (request.modelBrokerCredential && (request.env.PAPERCLIP_MANAGED_MODEL_INPUT_TOKENS_UPPER_BOUND !== String(request.modelBrokerCredential.inputTokensUpperBound) ||
        request.env.PAPERCLIP_MANAGED_MODEL_MAX_OUTPUT_TOKENS !== String(request.modelBrokerCredential.maxOutputTokens))) ||
      typeof request.stdinBase64 !== "string" || request.stdinBase64.length > 512 * 1024 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(request.stdinBase64) ||
      typeof input.capabilityToken !== "string" || input.capabilityToken.length > 16384 ||
      typeof onOutput !== "function") throw new Error("sandbox_scope_changed");
    const deadlineAt = request.deadlineAt;
    if (!Number.isFinite(Date.parse(deadlineAt)) || Date.parse(deadlineAt) <= Date.now()) throw new Error("sandbox_host_unavailable");
    const commandDigest = hash(JSON.stringify(canonical({ argv: request.argv, cwd: request.cwd, env: request.env,
      stdinHash: hash(Buffer.from(request.stdinBase64, "base64")), timeoutDeadline: deadlineAt,
      brokerCapabilityHash: request.brokerCredential ? hash(request.brokerCredential.capabilityToken) : null,
      brokerProviderProfile: request.brokerCredential ? { id: request.brokerCredential.profileId, hash: request.brokerCredential.profileHash } : null,
      modelBrokerCapabilityHash: request.modelBrokerCredential ? hash(request.modelBrokerCredential.capabilityToken) : null,
      modelBrokerProviderProfile: request.modelBrokerCredential ? { id: request.modelBrokerCredential.profileId, hash: request.modelBrokerCredential.profileHash } : null,
    })));
    if (commandDigest !== request.commandDigest) throw new Error("sandbox_scope_changed");
    const detail = await observed(input.scope, deadlineAt);
    const pinnedPolicy = journal.scopes[input.scope.bindingId]?.policy;
    const effectivePolicy = await policy(input.scope, deadlineAt);
    const workload = await container(input.scope, detail, request.imageDigest, deadlineAt);
    if (!pinnedPolicy || pinnedPolicy.policyHash !== request.policyHash || !samePolicyRevision(effectivePolicy, pinnedPolicy) ||
      detail.phase !== "Ready" || !workload.State.Running) throw new Error("sandbox_operation_unsupported");
    if (signal?.aborted) throw new Error("exec_unknown");
    if (Date.parse(deadlineAt) <= Date.now()) throw new Error("exec_timeout");

    const requestHash = hash(JSON.stringify(canonical({ request: { ...request, stdinBase64: undefined }, stdinHash: hash(Buffer.from(request.stdinBase64, "base64")), scope: input.scope })));
    const privateConfig = await privateConfiguration();
    if (signal?.aborted) throw new Error("exec_unknown");
    if (Date.parse(deadlineAt) <= Date.now()) throw new Error("exec_timeout");
    await serial(async () => {
      const existing = journal.commands[request.requestId];
      if (existing) {
        if (existing.requestHash !== requestHash) throw new Error("sandbox_scope_changed");
        throw new Error("exec_unknown");
      }
      if (Object.keys(journal.commands).length >= 10256) throw new Error("sandbox_host_unavailable");
      journal.commands[request.requestId] = { requestHash, result: null, kind: "exec", state: "claimed",
        ...(request.brokerCredential ? { brokerProvider: {
          name: `awbr-${request.requestId.replaceAll("-", "")}`,
          expiresAt: request.brokerCredential.expiresAt,
          scope: input.scope,
        } } : {}),
        ...(request.modelBrokerCredential ? { modelBrokerProvider: {
          name: `awmb-${request.requestId.replaceAll("-", "")}`,
          expiresAt: request.modelBrokerCredential.expiresAt,
          scope: input.scope,
        } } : {}),
      };
      await atomicJson(journalFile, journal);
    });
    if (signal?.aborted) throw new Error("exec_unknown");
    if (Date.parse(deadlineAt) <= Date.now()) throw new Error("exec_timeout");
    const brokerProviderName = request.brokerCredential ? `awbr-${request.requestId.replaceAll("-", "")}` : null;
    const modelBrokerProviderName = request.modelBrokerCredential ? `awmb-${request.requestId.replaceAll("-", "")}` : null;
    if (brokerProviderName) await attachBrokerProvider(request, input.scope, deadlineAt, brokerProviderName);
    if (modelBrokerProviderName) await attachModelBrokerProvider(request, input.scope, deadlineAt, modelBrokerProviderName);
    const cliArgs = ["--gateway", config.gateway, "--workspace", config.workspace, "sandbox", "exec", "--name", input.scope.sandboxRef,
      "--expected-sandbox-id", detail.id, "--workdir", request.cwd];
    for (const key of Object.keys(request.env).sort()) cliArgs.push("--env", `${key}=${request.env[key]}`);
    cliArgs.push("--", ...request.argv);
    const remaining = Math.max(1, Math.min(60_000, Date.parse(deadlineAt) - Date.now()));
    if (signal?.aborted) throw new Error("exec_unknown");
    if (Date.parse(deadlineAt) <= Date.now()) throw new Error("exec_timeout");
    const child = spawnProcess(privateConfig.executable, cliArgs, {
      cwd: privateConfig.stateHome,
      env: privateConfig.env,
      stdio: ["pipe", "pipe", "pipe"],
      shell: false,
      windowsHide: true,
    });
    let timedOut = false, outputBytes = 0, settled = false;
    const terminate = () => { if (!settled) child.kill("SIGKILL"); };
    const onAbort = () => terminate();
    signal?.addEventListener("abort", onAbort, { once: true });
    const timeout = setTimeout(() => { timedOut = true; terminate(); }, remaining);
    timeout.unref?.();
    const forward = async (stream, source) => {
      for await (const chunk of source) {
        outputBytes += chunk.length;
        if (outputBytes > 64 * 1024 * 1024) { terminate(); throw new Error("exec_rejected"); }
        await onOutput(stream, Buffer.from(chunk));
      }
    };
    const readOutput = Promise.all([forward("stdout", child.stdout), forward("stderr", child.stderr)]);
    child.stdin.end(Buffer.from(request.stdinBase64, "base64"));
    let exitCode;
    try {
      const exited = new Promise((resolve, reject) => {
        child.once("error", reject);
        child.once("close", (code, signalName) => resolve({ code, signalName }));
      });
      const result = await exited;
      await readOutput;
      settled = true;
      exitCode = Number.isInteger(result.code) ? result.code : (timedOut ? 124 : 1);
    } catch (error) {
      terminate();
      await Promise.allSettled([readOutput]);
      throw error;
    } finally {
      settled = true;
      clearTimeout(timeout);
      signal?.removeEventListener("abort", onAbort);
    }
    if (timedOut) throw new Error("exec_unknown");
    if (brokerProviderName) await detachAndDeleteBrokerProvider(input.scope, deadlineAt, brokerProviderName);
    if (modelBrokerProviderName) await detachAndDeleteBrokerProvider(input.scope, deadlineAt, modelBrokerProviderName);
    await serial(async () => {
      journal.commands[request.requestId] = { requestHash, result: { exitCode, timedOut }, kind: "exec", state: "completed" };
      await atomicJson(journalFile, journal);
    });
    return { exitCode, timedOut };
  }
  return {
    async initialize() {
      try {
        journal = JSON.parse(await readFile(journalFile, "utf8"));
      } catch (error) {
        if (error.code !== "ENOENT")
          throw new Error("sandbox_host_unavailable");
      }
      if (journal.version === 1 && journal.scopes && !Array.isArray(journal.scopes)) {
        // Old observations never recorded an immutable gateway ID. Keep them
        // fenced instead of silently adopting whichever instance now owns a name.
        journal = {
          ...journal,
          version: 2,
          scopes: Object.fromEntries(Object.entries(journal.scopes).map(
            ([id, scope]) => [id, { scope, sandboxId: null }],
          )),
        };
      }
      if (
        journal.version !== 2 ||
        !journal.scopes ||
        !journal.commands ||
        Array.isArray(journal.scopes) ||
        Array.isArray(journal.commands) ||
        Object.keys(journal.scopes).length > 256 ||
        Object.entries(journal.scopes).some(([id, v]) =>
          !v || !validScope(v.scope) || id !== v.scope.bindingId ||
          (v.sandboxId !== null && !uuid.test(v.sandboxId ?? "")),
        ) ||
        Object.keys(journal.commands).length > 10256
      )
        throw new Error("sandbox_host_unavailable");
    },
    execute(id, request, deadlineAt) {
      return serial(async () => {
        if (
          !uuid.test(id) ||
          !validScope(request?.scope) ||
          request.version !== 1 ||
          request.hostEpoch !== epoch ||
          !actions.has(request.action) ||
          !/^[a-z0-9./:_-]+@sha256:[a-f0-9]{64}$/.test(
            request.imageDigest ?? "",
          ) ||
          (!request.cleanupAttestation && (typeof request.requesterUserId !== "string" ||
            request.requesterUserId.length < 1 || request.requesterUserId.length > 200)) ||
          !Number.isFinite(new Date(deadlineAt).getTime()) ||
          new Date(deadlineAt) <= new Date()
        )
          throw new Error("sandbox_scope_changed");
        if (
          (request.action === "probe") !== Boolean(request.probe) ||
          (request.action === "apply") !== Boolean(request.admission) ||
          (request.action === "start") !== Boolean(request.start) ||
          (request.provisioning !== undefined && request.action !== "prepare") ||
          (request.action === "prepare" && request.provisioning !== undefined && !request.provisioning) ||
          (Boolean(request.cleanupAttestation) &&
            (!['capabilities', 'probe'].includes(request.action) ||
              request.requesterUserId !== undefined ||
              Object.keys(request.cleanupAttestation).length !== 8 ||
              Object.keys(request.cleanupAttestation).some(key => ![
                "version", "jobId", "jobKey", "attemptNumber", "executionOwnerId",
                "locatorDigest", "companyPurgeOperationId", "startBindingDigest",
              ].includes(key)) ||
              request.cleanupAttestation.version !== 1 ||
              !uuid.test(request.cleanupAttestation.jobId ?? "") ||
              typeof request.cleanupAttestation.jobKey !== "string" ||
              request.cleanupAttestation.jobKey.length < 1 || request.cleanupAttestation.jobKey.length > 300 ||
              !Number.isSafeInteger(request.cleanupAttestation.attemptNumber) ||
              request.cleanupAttestation.attemptNumber < 1 ||
              typeof request.cleanupAttestation.executionOwnerId !== "string" ||
              request.cleanupAttestation.executionOwnerId.length < 1 ||
              request.cleanupAttestation.executionOwnerId.length > 300 ||
              !/^[a-f0-9]{64}$/.test(request.cleanupAttestation.locatorDigest ?? "") ||
              !(request.cleanupAttestation.companyPurgeOperationId === null ||
                uuid.test(request.cleanupAttestation.companyPurgeOperationId ?? "")) ||
              !/^[a-f0-9]{64}$/.test(request.cleanupAttestation.startBindingDigest ?? ""))) ||
          Object.keys(request).some(
            (key) =>
              ![
                "version",
                "scope",
                "action",
                "hostEpoch",
                "imageDigest",
                "requesterUserId",
                "probe",
                "admission",
                "start",
                "provisioning",
                "cleanupAttestation",
                "claimToken",
              ].includes(key),
          )
        )
          throw new Error("sandbox_scope_changed");
        const { claimToken: _, ...immutable } = request;
        const requestHash = hash(JSON.stringify(immutable));
        const existing = journal.commands[id];
        if (existing) {
          if (existing.requestHash !== requestHash)
            throw new Error("sandbox_scope_changed");
          // An intent persisted before an effect without its completion receipt
          // is ambiguous. Never replay the external operation after that point.
          return existing.result ?? {
            success: false,
            reply: null,
            errorCode: "sandbox_observation_unavailable",
          };
        }
        if (
          Object.keys(journal.commands).length >=
          (["stop", "destroy", "revoke_providers"].includes(request.action)
            ? 10256
            : 10000)
        )
          throw new Error("sandbox_host_unavailable");
        journal.commands[id] = { requestHash, result: null };
        await atomicJson(journalFile, journal);
        let result;
        try {
          result = {
            success: true,
            reply: await executeAction(request, deadlineAt),
            errorCode: null,
          };
        } catch (error) {
          result = {
            success: false,
            reply: null,
            errorCode: [
              "sandbox_host_unavailable",
              "sandbox_scope_changed",
              "sandbox_operation_unsupported",
              "sandbox_observation_unavailable",
            ].includes(error.message)
              ? error.message
              : "sandbox_host_unavailable",
          };
        }
        journal.commands[id] = { requestHash, result };
        await atomicJson(journalFile, journal);
        return result;
      });
    },
    executeStream,
    acknowledge(id) {
      return serial(async () => {
        delete journal.commands[id];
        await atomicJson(journalFile, journal);
      });
    },
    fenceAll() {
      return serial(async () => {
        let incomplete = false;
        for (const { scope } of Object.values(journal.scopes)) {
          try {
            const deadlineAt = new Date(Date.now() + 15000).toISOString();
            const detail = await observed(scope, deadlineAt);
            await cli(["sandbox", "stop", scope.sandboxRef, "--expected-sandbox-id", detail.id], deadlineAt, false);
            if ((await observed(scope, deadlineAt)).phase !== "Stopped")
              incomplete = true;
          } catch {
            incomplete = true;
          }
        }
        if (incomplete) throw new Error("sandbox_host_unavailable");
      });
    },
  };
}
