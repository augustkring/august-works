#!/bin/bash
set -euo pipefail
source /workspace/v10-preparation/env.sh
OUT=/workspace/v10-preparation/host-exec-stdin-epipe-nov01
python3 - <<'PY'
from pathlib import Path
import hashlib,json,shutil
p=Path('/workspace/v10-preparation/host-exec-stdin-epipe-nov01');sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
facts={'freeKiB':{s:shutil.disk_usage(s).free//1024 for s in ['/workspace','/tmp']},'mainMirrorSourceOverlay':False,'hostSource':{str(q.relative_to(p/'qualification-workspace')):sha(q) for q in (p/'qualification-workspace/deploy/v6/host-agent').glob('*.mjs')},'qualifiedSharedDist':{str(q.relative_to('/workspace/v10-dep-qualification/packages/shared/dist')):sha(q) for q in Path('/workspace/v10-dep-qualification/packages/shared/dist').rglob('*.js')}}
(p/'node-preflight.json').write_text(json.dumps(facts,indent=2)+'\n')
assert facts['freeKiB']['/workspace']>=120000,'root disk floor not met'
print('Node-only preflight free KiB:',facts['freeKiB'])
PY
cd "$OUT/qualification-workspace"
set +e
node --test deploy/v6/host-agent/openshell.test.mjs deploy/v6/host-agent/broker-profiles.test.mjs deploy/v6/host-agent/sandbox-host-contracts.test.mjs deploy/v6/host-agent/engine.test.mjs deploy/v6/host-agent/backup.test.mjs > "$OUT/whole-five-node.log" 2>&1
status=$?
printf '%s\n' "$status" > "$OUT/whole-five-node.exit"
tail -45 "$OUT/whole-five-node.log"
exit "$status"
