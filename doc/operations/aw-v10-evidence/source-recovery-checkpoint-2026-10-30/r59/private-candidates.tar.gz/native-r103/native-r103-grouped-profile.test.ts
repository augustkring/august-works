import { randomUUID } from "node:crypto";
import { PgDialect } from "drizzle-orm/pg-core";
import { canActorReadMemorySources, canActorReadMemorySourceSet } from "../services/memory/memory-privacy.js";
import { nativeRunInputSourceReceiptSchema } from "@paperclipai/shared";
import { issueService } from "../services/issues.js";
import { readFile } from "node:fs/promises";
import { afterAll, beforeAll, expect, it, vi } from "vitest";
import { and, eq, sql } from "drizzle-orm";
import * as database from "@paperclipai/db";
import { assertNativeMemorySourceInputCurrent, assertNativeManagedConsumedSourceSetCurrent, nativeMemoryReviewTransitionStateHash } from "../services/native-direct-input.js";
import { nativeSha256 } from "../services/native-runtime/canonical.js";
const connection = process.env.NATIVE_CONTEXT_REPLAY_DATABASE_URL!;
const root = "/tmp/native-payload-temporal-X0vcAM";
const checkpoint = JSON.parse(await readFile(`${root}/native-source-failure-checkpoint.json`, "utf8"));
vi.stubEnv("PAPERCLIP_HOME", root); vi.stubEnv("PAPERCLIP_INSTANCE_ID", checkpoint.instanceId);
const db = database.createDb(connection);
afterAll(async () => { await database.closeRegisteredClients(connection); vi.unstubAllEnvs(); });
let memory: typeof database.memoryRecords.$inferSelect;
let actor: any;
let source: any;
beforeAll(async () => {
  const run = checkpoint.runs.find((value: { status: string }) => value.status === "running");
  const invocations = await db.select().from(database.toolInvocations).where(and(eq(database.toolInvocations.runId, run.id), eq(database.toolInvocations.toolName, "paperclip-self:remember"), eq(database.toolInvocations.status, "succeeded")));
  expect(invocations).toHaveLength(1);
  const result = invocations[0]!.workflowResultJson as { data: { record: { id: string } } };
  [memory] = await db.select().from(database.memoryRecords).where(eq(database.memoryRecords.id, result.data.record.id));
  expect(memory).toBeTruthy();
  actor = { type: "agent", source: "none", companyId: checkpoint.companyId, agentId: run.agentId, runId: run.id, onBehalfOfUserId: checkpoint.aliceUserId };
  source = { kind: "memory", memoryId: memory!.id, sourceVersion: memory!.updatedAt.toISOString(), contentHash: nativeSha256(memory!.content), reviewStateAtCapture: memory!.reviewState, verificationStateAtCapture: memory!.verificationState, reviewTransitionStateHash: nativeMemoryReviewTransitionStateHash(memory!) };
  for (const name of ["alice", "bob"] as const) {
    const memoryActor = name === "alice" ? checkpoint.aliceMemoryActor : checkpoint.bobMemoryActor;
    const oldActor = memoryActor.authorizationActor;
    const [user] = await db.select({ version: database.authUsers.authenticatorVersion }).from(database.authUsers).where(eq(database.authUsers.id, oldActor.userId));
    expect((await db.select({ id: database.authPasskeys.id }).from(database.authPasskeys).where(eq(database.authPasskeys.userId, oldActor.userId))).length).toBeGreaterThan(0);
    const now = new Date(), sessionId = randomUUID();
    await db.insert(database.authSessions).values({ id: sessionId, userId: oldActor.userId, token: randomUUID(), createdAt: now, updatedAt: now, expiresAt: new Date(now.getTime()+3_600_000), authenticationMethod: "passkey", authenticatedAt: now, authenticatorVersion: user!.version });
    memoryActor.authorizationActor = { ...oldActor, sessionId };
    if (name === "alice") checkpoint.aliceActor = memoryActor.authorizationActor;
  }
});
const rollback = new Error("fixture_rollback");
async function borrowed(read: (tx: any) => Promise<void>) {
  await expect(db.transaction(async tx => {
    await tx.execute(sql`set local plan_cache_mode=force_custom_plan`);
    await read(tx);
    expect((await tx.execute<{ mode: string }>(sql`select current_setting('plan_cache_mode') as mode`))[0]?.mode).toBe("force_custom_plan");
    throw rollback;
  })).rejects.toBe(rollback);
}
it("qualifies the exact persisted result and restores its borrowed planner mode", async () => {
  await borrowed(async tx => {
    const start = performance.now();
    await assertNativeMemorySourceInputCurrent(tx, { companyId: checkpoint.companyId, actor, source });
    console.info("native_scoped_memory_capture", JSON.stringify({ outcome: "success", elapsedMs: performance.now()-start }));
  });
}, 30_000);
it("keeps Bob denied by the exact private source closure and restores settings", async () => {
  await borrowed(async tx => {
    await expect(assertNativeMemorySourceInputCurrent(tx, { companyId: checkpoint.companyId, actor: checkpoint.bobMemoryActor.authorizationActor, source })).rejects.toMatchObject({ status: 403 });
  });
}, 30_000);
for (const fault of ["caller_abort", "deadline", "planner_admission_abort"] as const) it(`withholds an allow when ${fault} occurs during planner cleanup`, async () => {
  await borrowed(async tx => {
    const controller = new AbortController();
    const dialect = new PgDialect();
    const originalNow = performance.now.bind(performance);
    let offset = 0, cleanupReached = false;
    const clock = vi.spyOn(performance, "now").mockImplementation(() => originalNow()+offset);
    const proxy = new Proxy(tx, { get(target, key, receiver) {
      if (key !== "execute") return Reflect.get(target, key, receiver);
      return async (query: any) => {
        const result = await target.execute(query);
        const statement = dialect.sqlToQuery(query).sql;
        if (fault === "planner_admission_abort" && statement.includes("set local plan_cache_mode=force_generic_plan")) {
          cleanupReached = true;
          controller.abort(new Error("fixture_abort_after_planner_admission"));
        }
        if (statement.includes("select set_config('plan_cache_mode',")) {
          cleanupReached = true;
          if (fault === "caller_abort") controller.abort(new Error("fixture_abort_after_planner_cleanup"));
          else if (fault === "deadline") offset = 9000;
        }
        return result;
      };
    } });
    try {
      expect(await canActorReadMemorySources(proxy, checkpoint.companyId, actor, memory.id, { signal: controller.signal, nativeInspection: true })).toBe(false);
      expect(cleanupReached).toBe(true);
    } finally { clock.mockRestore(); }
  });
}, 30_000);
it("restores the prior parent mode after a failed SQL savepoint", async () => {
  await borrowed(async parent => {
    let injected = false;
    const original = database.executePrivacyIdSelect;
    const spy = vi.spyOn(database, "executePrivacyIdSelect").mockImplementation(async (owner, query) => {
      if (!injected) {
        const [mode] = await owner.execute<{ mode: string }>(sql`select current_setting('plan_cache_mode') as mode`);
        if (mode?.mode === "force_generic_plan") { injected = true; await owner.execute(sql`select 1/0`); }
      }
      return original(owner, query);
    });
    try { await expect(parent.transaction((child: any) => assertNativeMemorySourceInputCurrent(child, { companyId: checkpoint.companyId, actor, source }))).rejects.toThrow(); expect(injected).toBe(true); }
    finally { spy.mockRestore(); }
  });
}, 30_000);
it("rechecks the current Task body after a canonical effect in the same transaction", async () => {
  await borrowed(async tx => {
    await assertNativeMemorySourceInputCurrent(tx, { companyId: checkpoint.companyId, actor, source });
    await issueService(tx).update(checkpoint.taskBId, { description: "Fixture source changed after the exact captured Memory version", actorUserId: checkpoint.aliceUserId, privacyActor: checkpoint.aliceActor });
    await expect(assertNativeMemorySourceInputCurrent(tx, { companyId: checkpoint.companyId, actor, source })).rejects.toMatchObject({ status: 403 });
  });
}, 40_000);

for (const mode of ["native_capture", "generic_memory", "shorter_caller", "native_abort"] as const) it(`keeps the initial inspection profile and original caller bound (${mode})`, async () => {
  const [earlier] = await db.select().from(database.memoryRecords).where(eq(database.memoryRecords.id, checkpoint.memoryAId));
  expect(earlier?.payloadSourceProtocolVersion).toBe(1);
  const earlierSource = { kind: "memory" as const, memoryId: earlier!.id, sourceVersion: earlier!.updatedAt.toISOString(), contentHash: nativeSha256(earlier!.content), reviewStateAtCapture: earlier!.reviewState, verificationStateAtCapture: earlier!.verificationState, reviewTransitionStateHash: nativeMemoryReviewTransitionStateHash(earlier!) };
  await borrowed(async tx => {
    const controller = new AbortController(), dialect = new PgDialect();
    const originalNow = performance.now.bind(performance), started = originalNow();
    let offset = 0, cleanupReached = false;
    const clock = vi.spyOn(performance, "now").mockImplementation(() => originalNow()+offset);
    const proxy = new Proxy(tx, { get(target, key, receiver) {
      if (key !== "execute") return Reflect.get(target, key, receiver);
      return async (query: any) => {
        const result = await target.execute(query);
        if (dialect.sqlToQuery(query).sql.includes("select set_config('plan_cache_mode',")) {
          cleanupReached = true;
          if (mode === "native_abort") controller.abort(new Error("fixture_native_profile_abort"));
          else offset = Math.max(0, (mode === "shorter_caller" ? 10_500 : 8_500) - (originalNow()-started));
        }
        return result;
      };
    } });
    try {
      if (mode === "native_capture") await assertNativeMemorySourceInputCurrent(proxy, { companyId: checkpoint.companyId, actor, source: earlierSource });
      else expect(await canActorReadMemorySources(proxy, checkpoint.companyId, actor, earlier!.id,
        mode === "generic_memory" ? {} : { nativeInspection: true, signal: controller.signal,
          ...(mode === "shorter_caller" ? { deadlineAt: Date.now()+10_000 } : {}) })).toBe(false);
      expect(cleanupReached).toBe(true);
    } finally { clock.mockRestore(); }
  });
}, 30_000);

for (const bound of ["already_aborted", "already_expired"] as const) it(`withholds Native inspection before SQL for an initial ${bound} caller bound`, async () => {
  await borrowed(async tx => {
    const controller = new AbortController();
    if (bound === "already_aborted") controller.abort(new Error("fixture_initial_abort"));
    let reads = 0;
    const proxy = new Proxy(tx, { get(target, key, receiver) {
      if (key !== "select" && key !== "execute") return Reflect.get(target, key, receiver);
      return (...args: any[]) => { reads++; return target[key](...args); };
    } });
    expect(await canActorReadMemorySources(proxy, checkpoint.companyId, actor, checkpoint.memoryAId,
      { nativeInspection: true, signal: controller.signal, ...(bound === "already_expired" ? { deadlineAt: Date.now()-1 } : {}) })).toBe(false);
    expect(reads).toBe(0);
  });
});
for (const mode of ["trusted_native_group_union", "trusted_native_policy_only"] as const) it(`measures the existing current-reader grouped owner (${mode})`, async () => {
  const [earlier] = await db.select().from(database.memoryRecords).where(eq(database.memoryRecords.id, checkpoint.memoryAId));
  const earlierSource = { kind: "memory" as const, memoryId: earlier!.id, sourceVersion: earlier!.updatedAt.toISOString(), contentHash: nativeSha256(earlier!.content), reviewStateAtCapture: earlier!.reviewState, verificationStateAtCapture: earlier!.verificationState, reviewTransitionStateHash: nativeMemoryReviewTransitionStateHash(earlier!) };
  const run = checkpoint.runs.find((value: { status: string }) => value.status === "running");
  const stats = { calls: 0, elapsedMs: 0 };
  const original = database.executePrivacyIdSelect;
  const spy = vi.spyOn(database, "executePrivacyIdSelect").mockImplementation(async (owner, query) => {
    const start = performance.now();
    try { return await original(owner, query); }
    finally { stats.calls++; stats.elapsedMs += performance.now()-start; }
  });
  let outcome = false, reason: string | null = null;
  const start = performance.now(), cpu = process.cpuUsage();
  try {
    const rollback = new Error("fixture_rollback");
    await db.transaction(async tx => {
      if (mode === "raw_group_one") outcome = await canActorReadMemorySourceSet(tx as any, checkpoint.companyId, actor, [memory.id], undefined,
        { transaction: tx as object, proofsByOwnerPrefix: new Map() });
      else {
        const [consumer] = await tx.select().from(database.heartbeatRuns).where(eq(database.heartbeatRuns.id, run.id));
        const profile = consumer!.runnerProfileJson as Record<string, unknown>;
        const receipt = nativeRunInputSourceReceiptSchema.parse(profile.nativeInputSourceReceipt);
        const component = { responsibleUserId: checkpoint.aliceUserId,
          policy: { issueIds: [], projectIds: [], runIds: [], memoryIds: [earlier!.id, memory.id].sort(), foundationRevisionIds: [] },
          inputs: mode === "trusted_native_policy_only" ? [] : [earlierSource, source] };
        const { digest: _digest, ...body } = { ...receipt, additionalInputs: [...receipt.additionalInputs, component] };
        const [sealed] = await tx.execute<{ receipt: unknown }>(sql`select value || jsonb_build_object(
          'digest',encode(sha256(convert_to(value::text,'UTF8')),'hex')) as receipt from (select ${JSON.stringify(body)}::jsonb as value) supplied`);
        const updatedReceipt = nativeRunInputSourceReceiptSchema.parse(sealed!.receipt);
        await tx.update(database.heartbeatRuns).set({ runnerProfileJson: { ...profile, nativeInputSourceReceipt: updatedReceipt } }).where(eq(database.heartbeatRuns.id, run.id));
        await assertNativeManagedConsumedSourceSetCurrent(tx, { companyId: checkpoint.companyId, issueId: checkpoint.taskBId, runId: run.id, actor,
          components: [{ kind: "additional_input", ...component }], sourceSet: { policy: component.policy, inputs: component.inputs } });
        outcome = true;
      }
      throw rollback;
    }).catch(error => { if (error !== rollback) throw error; });
  } catch (error) {
    expect((error as { status: number }).status).toBe(403);
    reason = (error as Error).message;
    expect(["A Native source Memory is unavailable", "The Native source graph exceeds its total-work bound"]).toContain(reason);
  } finally { spy.mockRestore(); }
  expect(outcome).toBe(true);
  const used = process.cpuUsage(cpu);
  console.info("native_grouped_memory_checkpoint_measurement", JSON.stringify({ mode, outcome, reason,
    elapsedMs: performance.now()-start, cpuMs: (used.user+used.system)/1000, privacy: stats }));
}, 40_000);

for (const mode of ["generic_source_set", "native_source_set", "shorter_caller", "native_abort"] as const) it(`keeps the grouped inspection's original caller bound (${mode})`, async () => {
  const controller = new AbortController(), dialect = new PgDialect();
  await borrowed(async tx => {
    const originalNow = performance.now.bind(performance), started = originalNow();
    let offset = 0, cleanupReached = false;
    const clock = vi.spyOn(performance, "now").mockImplementation(() => originalNow()+offset);
    const proxy = new Proxy(tx, { get(target, key, receiver) {
      if (key !== "execute") return Reflect.get(target, key, receiver);
      return async (query: any) => {
        const result = await target.execute(query);
        if (dialect.sqlToQuery(query).sql.includes("select set_config('plan_cache_mode',")) {
          cleanupReached = true;
          if (mode === "native_abort") controller.abort(new Error("fixture_grouped_profile_abort"));
          else offset = Math.max(0, (mode === "shorter_caller" ? 10_500 : 8_500) - (originalNow()-started));
        }
        return result;
      };
    } });
    try {
      expect(await canActorReadMemorySourceSet(proxy, checkpoint.companyId, actor, [checkpoint.memoryAId], undefined, undefined,
        mode === "generic_source_set" ? {} : { nativeInspection: true, signal: controller.signal,
          ...(mode === "shorter_caller" ? { deadlineAt: Date.now()+10_000 } : {}) })).toBe(mode === "native_source_set");
      expect(cleanupReached).toBe(true);
    } finally { clock.mockRestore(); }
  });
}, 30_000);
it("withholds a grouped allow when cancellation arrives during the final current-principal read", async () => {
  const controller = new AbortController(), dialect = new PgDialect();
  let restored = false, currentReadReached = false;
  await borrowed(async tx => {
    const proxy = new Proxy(tx, { get(target, key, receiver) {
      if (key === "execute") return async (query: any) => {
        const result = await target.execute(query);
        if (dialect.sqlToQuery(query).sql.includes("select set_config('plan_cache_mode',")) restored = true;
        return result;
      };
      if (key === "select") return (...fields: any[]) => {
        const builder = target.select(...fields), from = builder.from.bind(builder);
        builder.from = (...tables: any[]) => {
          const query = from(...tables), then = query.then.bind(query);
          query.then = (resolve: any, reject: any) => then((rows: unknown) => {
            if (restored) { currentReadReached = true; controller.abort(new Error("fixture_abort_during_final_principal_read")); }
            return resolve ? resolve(rows) : rows;
          }, reject);
          return query;
        };
        return builder;
      };
      return Reflect.get(target, key, receiver);
    } });
    expect(await canActorReadMemorySourceSet(proxy, checkpoint.companyId, actor, [checkpoint.memoryAId], undefined, undefined,
      { nativeInspection: true, signal: controller.signal })).toBe(false);
    expect(currentReadReached).toBe(true);
  });
}, 30_000);
