import hashlib,json,pathlib
root=pathlib.Path('/workspace/blentera-v10');out=pathlib.Path('/workspace/v10-preparation/v10-product-artifacts-b1-recovery-20261103');tmp=pathlib.Path('/tmp/v10-product-artifacts-b1-recovery-20261103');q=out/'qualification';q.mkdir(exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();proofs=[]
source=tmp/'v10-safe-change-graph.source.json';graph=tmp/'v10-safe-change-graph.json';cap=tmp/'v10-capability-projection.json'
wrapper=f'''import {{ readFileSync, writeFileSync }} from 'node:fs';
import {{ resolve }} from 'node:path';
import {{ buildGraph }} from {json.dumps((root/'scripts/generate-v10-safe-change-graph.mjs').as_uri())};
const source = {json.dumps(str(source))};
const destination = {json.dumps(str(graph))};
const rendered = JSON.stringify(buildGraph(JSON.parse(readFileSync(source, 'utf8')), path => readFileSync(path === 'doc/operations/v10-capability-projection.json' ? {json.dumps(str(cap))} : resolve({json.dumps(str(root))}, path))), null, 2) + '\\n';
if(process.argv.includes('--check')) {{
  if(readFileSync(destination,'utf8')!==rendered) throw new Error('Private Safe Change graph is stale against actual original generator');
}} else writeFileSync(destination, rendered);
'''
(out/'private-safe-change-generator.mjs').write_text(wrapper)
def adapt(originalrel,name,subs):
 original=(root/originalrel).read_text();changed=original
 for a,b in subs:assert changed.count(a)==1,(name,a);changed=changed.replace(a,b,1)
 inverse=changed
 for a,b in reversed(subs):assert inverse.count(b)==1;inverse=inverse.replace(b,a,1)
 assert inverse==original;(out/name).write_text(changed);proofs.append({'originalPath':originalrel,'originalSha256':sha(original.encode()),'harnessPath':name,'harnessSha256':sha(changed.encode()),'substitutions':[{'original':a,'private':b} for a,b in subs],'exactInverse':True,'scope':'Path bootstrap/private artifact locations only; original checks and test callback bodies unchanged.'})
rootline='const root = resolve(fileURLToPath(new URL("..", import.meta.url)));'
adapt('scripts/check-v10-capability-projection.mjs','private-capability-check.mjs',[(rootline,f'const root = {json.dumps(str(root))};'),('[runner, generator, "--check"]',f'[runner, generator, "--out", {json.dumps(str(cap))}, "--check"]')])
adapt('scripts/check-v10-safe-change-graph.mjs','private-safe-change-check.mjs',[(rootline,f'const root = {json.dumps(str(root))};'),('const generator = resolve(root, "scripts/generate-v10-safe-change-graph.mjs");',f'const generator = {json.dumps(str(out/"private-safe-change-generator.mjs"))};'),('readFileSync(resolve(root, "doc/operations/v10-safe-change-graph.json"), "utf8")',f'readFileSync({json.dumps(str(graph))}, "utf8")')])
private={'doc/operations/v10-capability-projection.json':str(cap),'doc/operations/v10-safe-change-graph.json':str(graph),'doc/operations/v10-safe-change-graph.source.json':str(source)}
adapt('scripts/v10-product-artifacts.test.mjs','private-product-artifacts.test.mjs', [('from "./generate-v10-safe-change-graph.mjs"',f'from {json.dumps((root/"scripts/generate-v10-safe-change-graph.mjs").as_uri())}'),('const root = resolve(import.meta.dirname, "..");',f'const root = {json.dumps(str(root))};'),('const readJson = (path) => JSON.parse(readFileSync(resolve(root, path), "utf8"));',f'const privateArtifacts = {json.dumps(private)};\nconst readJson = (path) => JSON.parse(readFileSync(privateArtifacts[path] ?? resolve(root, path), "utf8"));')])
(q/'path-bootstrap-proofs.json').write_text(json.dumps(proofs,indent=2)+'\n');print(json.dumps({'harnesses':len(proofs),'allExactInverse':True,'candidateSourceSha256':sha(source.read_bytes())}))
