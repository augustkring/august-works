import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { validateSecurityFastPath, selectSecurityFastPath } from "./check-v10-security-fast-path.mjs";

const root = resolve(import.meta.dirname, "..");
const map = JSON.parse(readFileSync(resolve(root, "doc/operations/v10-security-fast-path.json"), "utf8"));

test("security fast path resolves every protected owner path to existing regression files", () => {
  assert.deepEqual(validateSecurityFastPath(map), []);
});

test("a changed protected path selects only its mapped regression files, deduplicated", () => {
  assert.deepEqual(selectSecurityFastPath(map, ["server/src/services/workflows/workflow-executor.ts"]), [
    "server/src/__tests__/v9-workflow-authoring-api.integration.test.ts",
    "server/src/__tests__/v9-workflow-authoring-sources.integration.test.ts",
  ]);
});

test("an unowned protected path cannot silently acquire a CI job owner", () => {
  const altered = structuredClone(map);
  altered.regressions[0].ciJob = "server-general";
  assert.ok(validateSecurityFastPath(altered).some((error) => error.includes("CI job ownership")));
});
