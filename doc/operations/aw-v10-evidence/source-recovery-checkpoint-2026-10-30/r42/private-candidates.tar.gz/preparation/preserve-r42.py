from pathlib import Path
import subprocess,json,gzip,tarfile,io,hashlib,datetime
root=Path('/workspace/blentera-v10'); prep=Path('/workspace/v10-preparation')
out=root/'doc/operations/aw-v10-evidence/source-recovery-checkpoint-2026-10-30/r42'
assert not out.exists();out.mkdir(parents=True)
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
def sha(b):return hashlib.sha256(b).hexdigest()
base=git('rev-parse','HEAD').decode().strip();patch=git('diff','--binary',base)
z=gzip.compress(patch,mtime=0);(out/'working-source.patch.gz').write_bytes(z)
new=[p for p in git('ls-files','--others','--exclude-standard').decode().splitlines() if p.startswith(('server/','ui/','packages/','scripts/','tests/'))]
def pack(dest,files):
 rows=[]
 with tarfile.open(dest,'w:gz') as t:
  for name,p in sorted(files.items()):
   b=p.read_bytes();i=tarfile.TarInfo(name);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b));rows.append({'path':name,'bytes':len(b),'sha256':sha(b)})
 return rows
newrows=pack(out/'untracked-source.tar.gz',{p:root/p for p in new if (root/p).is_file()})
files={}
for p in prep.iterdir():
 if p.is_file() and (p.name.startswith(('root-continuation-','native-','v10-169-current','build-v10-safe','preserve-r42'))):
  if p.stat().st_size<2_000_000:files['preparation/'+p.name]=p
 if p.is_dir() and p.name.startswith('company-settings-contacts-r'):
  for q in p.rglob('*'):
   if q.is_file() and q.stat().st_size<2_000_000:files['preparation/'+str(q.relative_to(prep))]=q
for prefix in ['doc/operations/aw-v10-evidence/operation-coverage-2026-10-30','doc/operations/aw-v10-evidence/v10-169-migration-phases-current-2026-10-30']:
 for p in (root/prefix).rglob('*'):
  if p.is_file() and p.stat().st_size<4_000_000:files['main-extra/'+str(p.relative_to(root))]=p
rows=pack(out/'private-candidates.tar.gz',files)
manifest={'purpose':'recovery_only_not_qualification','savedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseCommit':base,'patchBytes':len(patch),'patchSha256':sha(patch),'archiveSha256':sha(z),'untrackedSourceFiles':newrows,'privateCandidateFiles':rows,'privateCandidateArchiveSha256':sha((out/'private-candidates.tar.gz').read_bytes())}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(out/'README.md').write_text('# Recoverable source checkpoint r42\n\nRecovery only; ongoing diagnostics and candidates are not qualified. Apply working-source.patch.gz at the exact manifest base, then extract untracked-source.tar.gz. Private candidates use preparation/ and main-extra/ prefixes and must not be applied without review.\n')
print(json.dumps({'output':str(out),'files':len(rows),'privateBytes':(out/'private-candidates.tar.gz').stat().st_size,'patchBytes':len(patch)}))
