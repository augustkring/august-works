# V10-149 RT-01 outer disk and syscall controls — private R10 candidate

R10 composes the private R8 expected-sandbox-ID security callers and R9 disk/syscall host controls onto the exact current MAIN R6 baseline (`dcd25504b`), then adds Quality's three V7 `diskBytes` fixture changes. R8 was never published, so R10's two host files carry the complete R8 security delta plus R9 controls. The prior R8/R9/Quality candidates remain immutable. No MAIN files were changed; `resourceLimits` and `syscallPolicy` remain false.

`exact-stage-paths.txt` and `source-pins.json` contain the complete 12-path candidate. Non-vendor paths are pinned to current MAIN R6 (`openshell.mjs` `9d15143c…`, host test `97d2baac…`, and exact pins for the remaining paths); five Rust files are pinned to the OpenShell expected-ID R2 vendor source. The source lineage records the private R8/R9 patch hashes and Quality's fixture patch hash. `source.patch` and component patches reconstruct the candidate.

The Docker driver accepts a canonical decimal `disk_limit_bytes` in existing opaque Docker config, validates 1 MiB–1 TiB, and applies `HostConfig.StorageOpt.size` only during create. On the selected Docker `overlay2` + XFS `pquota` path, the host requires the exact inspected size, trusted workspace label, and inspected mount inventory; it rejects unbounded writable external mounts and replacement/drift. It requires recreation on a storage mismatch before updating CPU/memory/PID limits. The fixed built-in seccomp helper checks `getpid` allowed and `memfd_create` denied with `EPERM`, executed using the exact sandbox UUID-bound CLI path. No custom syscall allowlist or runtime quota-update path is introduced.

## Qualification

The snapshot-first private dependency-mirror run used the canonical flock and fresh current-source snapshot. All results below passed:

- Host-agent suite: 37/37.
- Agent JWT, V7 policy, and actual NVIDIA/OpenShell v0.1.2 prover backend suites: 74/74 across three test files; prover SHA-256 `3e80c0d041a7552d57cc338868bc825a6261e21b5f29a7d7527bcc7926d423f1`.
- Focused tool-gateway broker binding test: 1/1.
- V7 sandbox-host bridge integration: 13/13.
- Shared typecheck and full server typecheck: exit 0.
- Rustfmt 1.97.1 parse/format check and all source patch apply checks: exit 0.
- Snapshot, source overlay restore, and dist/tsbuildinfo restore: verified byte-for-byte.

The Rust code was not compiled or cargo-tested. No Docker host, image, quota exhaustion/restart, or physical syscall probes ran. Docker docs require overlay2's XFS backing filesystem to use `pquota`; code checks observed backend and configured size but the target host still needs real quota, restart, and syscall probes before any capability flag can be enabled. This candidate does not claim physical enforcement qualification.
