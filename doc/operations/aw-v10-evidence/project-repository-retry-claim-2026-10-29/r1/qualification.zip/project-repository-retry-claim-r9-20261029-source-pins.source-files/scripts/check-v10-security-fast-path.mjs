import { readFileSync, existsSync } from "node:fs";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(fileURLToPath(new URL("..", import.meta.url)));
const mapPath = "doc/operations/v10-security-fast-path.json";

export function validateSecurityFastPath(map, exists = (path) => existsSync(resolve(root, path))) {
  const errors = [];
  if (map?.schemaVersion !== 1 || map?.requirement !== "V10-013" || !Array.isArray(map.regressions)) {
    return ["Invalid V10 security fast-path map shape"];
  }
  const ids = new Set();
  const protectedPaths = new Set();
  for (const row of map.regressions) {
    if (!row.id || ids.has(row.id)) errors.push(`Missing or duplicate regression ID: ${row.id ?? "<unknown>"}`);
    ids.add(row.id);
    if (!row.canonicalOwner || !row.ownerDisposition) errors.push(`${row.id}: owner/disposition must be explicit, including unknown`);
    if (!Array.isArray(row.protectedPaths) || row.protectedPaths.length === 0) errors.push(`${row.id}: no protected source paths`);
    if (!Array.isArray(row.selectors) || row.selectors.length === 0) errors.push(`${row.id}: no regression selector`);
    if (!Array.isArray(row.triggers) || row.triggers.length === 0) errors.push(`${row.id}: no change trigger`);
    if (row.ciJob !== null || row.ciJobDisposition !== "unknown") errors.push(`${row.id}: CI job ownership must remain explicitly unknown until sourced`);
    for (const path of [...(row.protectedPaths ?? []), ...(row.selectors ?? [])]) {
      if (!exists(path)) errors.push(`${row.id}: missing mapped path ${path}`);
    }
    for (const path of row.protectedPaths ?? []) protectedPaths.add(path);
  }
  if (!protectedPaths.has("server/src/services/authorization.ts") ||
      !protectedPaths.has("server/src/services/memory/memory-privacy.ts") ||
      !protectedPaths.has("server/src/services/workflows/workflow-executor.ts")) {
    errors.push("Security fast path is missing a core authorization, privacy, or workflow-recovery protected path");
  }
  return errors;
}

export function selectSecurityFastPath(map, changedFiles) {
  const changed = new Set(changedFiles.map((path) => path.replaceAll("\\", "/")));
  return [...new Set(map.regressions
    .filter((row) => row.protectedPaths.some((path) => changed.has(path)))
    .flatMap((row) => row.selectors))].sort();
}

function main() {
  const args = process.argv.slice(2);
  const changedFiles = [];
  for (let i = 0; i < args.length; i += 1) {
    if (args[i] === "--changed-file") changedFiles.push(args[++i] ?? "");
    else throw new Error(`Unknown argument: ${args[i]}`);
  }
  const map = JSON.parse(readFileSync(resolve(root, mapPath), "utf8"));
  const errors = validateSecurityFastPath(map);
  if (errors.length) throw new Error(errors.join("\n"));
  if (changedFiles.length) {
    const selectors = selectSecurityFastPath(map, changedFiles);
    process.stdout.write(selectors.length ? `${selectors.join("\n")}\n` : "No mapped security selectors for supplied paths.\n");
  } else {
    process.stdout.write(`Validated ${map.regressions.length} security regression groups; ${map.regressions.reduce((n, row) => n + row.protectedPaths.length, 0)} protected path mappings.\n`);
  }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) main();
