from pathlib import Path
p=Path('/workspace/blentera-v10/server/src/services/authorization.ts');s=p.read_text();s=s.replace('  executePrivacyIdSelect,','  executePrivacyIdSelect as executePrivacyIdSelectCurrent,',1)
a=s.index('type DbTransaction =');s=s[:a]+'''const nativePrivacyReadSqlDiagnostics = {
  issue: { calls: 0, elapsedMs: 0, maxMs: 0 }, run: { calls: 0, elapsedMs: 0, maxMs: 0 },
};
export function nativePrivacyReadSqlDiagnosticsForTest() { return structuredClone(nativePrivacyReadSqlDiagnostics); }
async function executePrivacyIdSelect(db: Parameters<typeof executePrivacyIdSelectCurrent>[0],
  query: Parameters<typeof executePrivacyIdSelectCurrent>[1], family: "issue" | "run" = "issue") {
  if (process.env.PAPERCLIP_NATIVE_CONTEXT_PHASE_DIAGNOSTICS !== "1") return executePrivacyIdSelectCurrent(db, query);
  const startedAt = performance.now();
  try { return await executePrivacyIdSelectCurrent(db, query); }
  finally {
    const elapsedMs = performance.now() - startedAt;
    const stats = nativePrivacyReadSqlDiagnostics[family];
    stats.calls += 1; stats.elapsedMs += elapsedMs; stats.maxMs = Math.max(stats.maxMs, elapsedMs);
  }
}

'''+s[a:]
a=s.index('export async function canActorReadHeartbeatRunPrivacy(');b=s.index('\n}\n',a);c=s[a:b];assert c.count('executePrivacyIdSelect(db, readQuery)')==1;c=c.replace('executePrivacyIdSelect(db, readQuery)','executePrivacyIdSelect(db, readQuery, "run")');s=s[:a]+c+s[b:]
needle='''      eq(heartbeatRuns.companyId, companyId), inArray(heartbeatRuns.id, group.ids), condition)));''';assert s.count(needle)==1;s=s.replace(needle,'''      eq(heartbeatRuns.companyId, companyId), inArray(heartbeatRuns.id, group.ids), condition)), "run");''')
Path('/workspace/v10-preparation/authorization-privacy-sql-timing-candidate.ts').write_text(s)
p=Path('/workspace/blentera-v10/server/src/services/context/context-manifest.ts');s=p.read_text();s=s.replace('import {authorizationService,','import {nativePrivacyReadSqlDiagnosticsForTest,authorizationService,',1);needle='''          taskHits: traceNativeStats?.().frozenTaskMemoByKind.task?.hits ?? 0 };''';assert s.count(needle)==1;s=s.replace(needle,'''          taskHits: traceNativeStats?.().frozenTaskMemoByKind.task?.hits ?? 0,
          readerSql: nativePrivacyReadSqlDiagnosticsForTest() };''');Path('/workspace/v10-preparation/context-native-privacy-sql-timing-candidate.ts').write_text(s)
