from pathlib import Path
import subprocess,hashlib,json,shutil,difflib,stat
out=Path(__file__).parent;main=Path('/workspace/blentera-v10');dest=out/'files'
items=[
('/workspace/v10-preparation/tool-effect-copy-nov01/current-paid-admission-with-tool-copy.patch','21ba275512a5273ae9de240d31fdbae1ad5a007e38a2f88ef33047947d3a7f94'),
('/workspace/v10-preparation/opaque-mcp-company-purpose-nov01/opaque-mcp-company-purpose.patch','0f3ac2f76b51551536b828e073fb8e7a41e31d32f1cba73df13a2fd0c8991b82'),
('/workspace/v10-preparation/opaque-mcp-baseline-expectations-nov01/baseline-expectations.patch','dc9f610b365e077118faa1b57b8ca931b6af0d786a59240433d1f6c4c3c97217'),
('/workspace/v10-preparation/qualification-original-owner-nov01/qualification-original-owner.patch','f10eb1877fb897be5db8c5c084a2c47ca215675345e1c34c626ea9e6b6b93d2c'),
('/workspace/v10-preparation/workflow-http-availability-copy-nov01/workflow-http-availability-copy.patch','aa285b4148330c8822a253300524e9db064b176124f59708d8c72813f55363be'),
('/workspace/v10-preparation/qualification-boundary-followup-nov01/qualification-boundary-followup.patch','17975fe5e2e5d0ccb6c5b61df98690e2aac711658f8b9ffdf63936210ed43422'),
('/workspace/v10-preparation/tool-gateway-universal-fence-tests-nov01/tool-gateway-baseline-migration.patch','4a83ec2a556b5959926949d1e5806917b3fe79c54b176ad7e756ce27d359548c'),
('/workspace/v10-preparation/adapter-paid-probe-baseline-nov01/adapter-paid-probe-baseline.patch','697fcd2bca61e6c5bf5be62f2bf7df280d75d6fcc9d17d4fb67044b6f62c2bb7'),
('/workspace/v10-preparation/host-provisioning-assertion-merge-nov01/host-provisioning-assertion.patch','12e54c4f0bf18bb0d65a5700d9c525eceae164c5444ee795d05c2ace3c9d4039')]
sha=lambda b:hashlib.sha256(b).hexdigest()
for name,expected in items:assert sha(Path(name).read_bytes())==expected,(name,'patch changed')
bridgeRel='server/src/services/execution-sandbox/native-host-bridge.ts';bridge=Path('/workspace/v10-preparation/v10-149-r14.38.4.11-provisioning-hash-private/files')/bridgeRel
assert sha(bridge.read_bytes())=='3e79bb27a8ce4acd6f581684a30df373aac456b1afe9e9e1524aa50404a87c06'
paths=sorted({line[6:].strip() for name,_ in items for line in Path(name).read_text().splitlines() if line.startswith('+++ b/')}|{bridgeRel})
assert not dest.exists(),'immutable final output already exists'
mainDiff=sha(subprocess.check_output(['git','-C',str(main),'diff','--binary']))
parents=[];dest.mkdir()
for rel in paths:
 p=main/rel;q=dest/rel;assert q.resolve().is_relative_to(dest.resolve())
 if p.exists():q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
 parents.append({'path':rel,'mainParentSha256':sha(p.read_bytes()) if p.exists() else None,'mainParentMode':stat.S_IMODE(p.stat().st_mode) if p.exists() else None})
for name,_ in items:
 subprocess.run(['git','apply','--check',name],cwd=dest,check=True)
 subprocess.run(['git','apply',name],cwd=dest,check=True)
shutil.copy2(bridge,dest/bridgeRel)
patch=[]
for row in parents:
 rel=row['path'];p=main/rel;q=dest/rel;before=p.read_bytes() if p.exists() else b'';after=q.read_bytes() if q.exists() else b''
 row.update({'finalSha256':sha(after) if q.exists() else None,'finalMode':stat.S_IMODE(q.stat().st_mode) if q.exists() else None})
 if before!=after:patch.append(''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+rel if p.exists() else '/dev/null',tofile='b/'+rel if q.exists() else '/dev/null')))
(out/'final-paid-boundary.patch').write_text(''.join(patch))
assert mainDiff==sha(subprocess.check_output(['git','-C',str(main),'diff','--binary'])),'MAIN dirty patch changed while copying'
d={'head':subprocess.check_output(['git','-C',str(main),'rev-parse','HEAD'],text=True).strip(),'mainDirtyPatchSha256':mainDiff,'compositionOrder':[{'patch':n,'sha256':h} for n,h in items],'hostCompanion':{'source':str(bridge),'path':bridgeRel,'sha256':sha(bridge.read_bytes()),'qualification':'Host4.11 owner receipt is separate; component37 before this hash companion is historical, not a new combined qualification'},'files':parents,'finalFileCount':sum((dest/r['path']).exists() for r in parents),'combinedPatchSha256':sha((out/'final-paid-boundary.patch').read_bytes()),'allNineSequentialApplyChecks':'PASS','scope':'MAIN-based guard/test boundary; Host/C7 changed owners MUST three-way merge against these recorded MAIN parents. Excludes prepared-unapplied942 assertion delta and any unavailable customer/runtime qualification.'}
(out/'source-pins.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({'files':d['finalFileCount'],'patch':d['combinedPatchSha256'],'pins':sha((out/'source-pins.json').read_bytes()),'mainDiff':mainDiff}))
