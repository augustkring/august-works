import assert from "node:assert/strict";
import request from "supertest";
import { constants, generateKeyPairSync, privateDecrypt, randomBytes, randomUUID, sign } from "node:crypto";
import { createHash } from "node:crypto";
import { spawn } from "node:child_process";
import { lstatSync, mkdirSync, mkdtempSync, readFileSync, rmSync, symlinkSync, writeFileSync } from "node:fs";
import { createRequire } from "node:module";
import { createServer } from "node:http";
import { once } from "node:events";
import { realpath } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join, posix } from "node:path";
import express from "express";
import { WebSocket } from "ws";
import { and, desc, eq, gte, inArray, isNull, sql } from "drizzle-orm";
import {
  agentPresenceRuntimeBindings, connectionGrants, toolApplications, toolCatalogEntries, toolConnections, toolProfileBindings, toolProfileEntries, toolProfiles,
  agentProviderBindings, billingAccounts, billingAccountCompanies, billingSubscriptions, createDb,
  agents, agentExecutionManifests, environmentLeases, heartbeatRuns, heartbeatRunEvents, orchestrationModelReservations, issues, runtimeCapacityProfiles, runtimeCells, runtimeHosts, runtimeHostRequestNonces,
  runtimeVersionCatalog, runtimeHostCommands, sandboxQualificationRuns,
} from "@paperclipai/db";
import { SANDBOX_CONTROLS, runtimeRequestSigningInput, type SandboxQualificationProbeFixture, type SandboxCapabilitySnapshot } from "@paperclipai/shared";
import type { AuthorizationActor } from "../../services/authorization.js";
import { environmentService } from "../../services/environments.js";
import { environmentRuntimeService } from "../../services/environment-runtime.js";
import { executionSandboxService } from "../../services/execution-sandbox/sandbox-service.js";
import { sandboxProbeCases, type SandboxIdentity, type SandboxProbeCase } from "../../services/execution-sandbox/backend.js";
import { nativeSandboxHostTransport } from "../../services/execution-sandbox/native-host-bridge.js";
import { agentProviderBindingService } from "../../services/agent-provider-bindings.js";
import { discoverNativeCapabilities } from "../../services/native-provider-conformance.js";
import { makeProviderCapabilitySnapshot, providerConformanceRequirements } from "../../services/provider-capabilities.js";
import { instanceSettingsService } from "../../services/instance-settings.js";
import { runtimeControlService } from "../../services/runtime/control.js";
import type { workerModelGateway } from "../../services/orchestration/worker-model-gateway.js";
import type { SaasPlatformConfig } from "../../saas-platform-config.js";
import { policyFixture } from "./sandbox-fixture.js";
import { findNativeChatWorkspaceScope, nativeChatWorkspaceCwd } from "../../services/native-runtime/native-chat-workspace.js";
import { createToolGatewayService } from "../../services/tool-gateway.js";
import { toolAccessService } from "../../services/tool-access.js";
import { secretService } from "../../services/secrets.js";
import { registerAssignedMcpGateway } from "../../services/native-runtime/assigned-mcp-tools.js";
import { mcpGatewayProtocolRoutes } from "../../routes/tool-gateway.js";
import { errorHandler } from "../../middleware/error-handler.js";
import { projectOpenShellQualificationProbePolicy, projectOpenShellPolicy } from "../../services/execution-sandbox/openshell-policy.js";
import { open as unseal } from "../../services/saas/crypto.js";
import { nativeSha256 } from "../../services/native-runtime/canonical.js";
import { compileSandboxPolicy } from "../../services/execution-sandbox/policy-compiler.js";
import { readNativeRuntimeAssetText } from "../../services/native-runtime/runtime-context.js";
import { nativeRuntimeAssetsRoot } from "../../services/native-runtime/runtime-asset-retention.js";
import { resolvePaperclipInstanceRoot } from "../../home-paths.js";
import { verifyRuntimeToolsToken } from "../../runtime-tools-token.js";

const hostAgentRequire = createRequire(import.meta.url);
const { openShellHostEngine } = hostAgentRequire("../../../../deploy/v6/host-agent/openshell.mjs") as {
  openShellHostEngine: (input: Record<string, unknown>) => any;
};

const imageDigest = `fixture.invalid/openshell@sha256:${"a".repeat(64)}`;
const qualificationPolicyGolden = JSON.parse(readFileSync(new URL("../fixtures/openshell-qualification-policy-golden.json", import.meta.url), "utf8")) as { fixture: SandboxQualificationProbeFixture };
const goldenQualificationProbeFixture = qualificationPolicyGolden.fixture;
const conversationRequiredControls = [...SANDBOX_CONTROLS];
const { fixtureHash: _qualificationFixtureHash, ...qualificationFixtureBody } = goldenQualificationProbeFixture;
if (nativeSha256(qualificationFixtureBody) !== goldenQualificationProbeFixture.fixtureHash)
  throw new Error("conversation_software_host_qualification_fixture_hash_mismatch");

function signedRelayProof(hostId: string, privateKey: ReturnType<typeof generateKeyPairSync>["privateKey"]) {
  const fields = { hostId, epoch: 1, timestamp: String(Date.now()), nonce: randomBytes(32).toString("base64url") };
  const raw = Buffer.from(JSON.stringify({ hostId, epoch: 1 }));
  const message = runtimeRequestSigningInput("WS", "/api/internal/runtime/relay", createHashHex(raw), fields);
  return { nonce: fields.nonce, proof: { ...fields, signature: sign("sha256", Buffer.from(message), {
    key: privateKey, padding: constants.RSA_PKCS1_PSS_PADDING, saltLength: 32,
  }).toString("base64url") } };
}

function createHashHex(value: Buffer) {
  return createHash("sha256").update(value).digest("hex");
}

function safeSandboxFailureClass(error: unknown): string {
  const message = error instanceof Error ? error.message : "";
  const known: Array<[string, string]> = [
    ["runner_process_status_unavailable", "runner_process_status_unavailable"],
    ["Current active native Task run is required", "current_native_task_not_active"],
    ["Sandbox execution source changed before claim admission", "source_changed_before_claim"],
    ["A previous sandbox execution on this Task attempt has an unknown outcome", "previous_sandbox_exec_unknown"],
    ["Sandbox execution deadline expired", "sandbox_exec_deadline_expired"],
    ["Sandbox execution scope is stale", "sandbox_exec_scope_stale"],
    ["Sandbox execution capability is no longer active", "sandbox_exec_capability_inactive"],
  ];
  const exact = known.find(([prefix]) => message === prefix || message.startsWith(`${prefix}:`));
  if (exact) return exact[1];
  if (/^[a-z][a-z0-9_:-]{0,99}$/.test(message)) return message;
  return error instanceof Error ? `unclassified_${error.name.toLowerCase().replace(/[^a-z0-9]+/g, "_").slice(0, 40)}` : "non_error_throwable";
}

function safeErrorSourceFrames(error: unknown): Array<{ functionName: string | null; sourceFile: string; line: number }> {
  const stack = error instanceof Error ? error.stack?.split("\n").slice(1) ?? [] : [];
  const frames: Array<{ functionName: string | null; sourceFile: string; line: number }> = [];
  for (const line of stack) {
    const match = /^\s*at (?:(.*?) \()?(.+?):(\d+):\d+\)?$/.exec(line);
    if (!match) continue;
    const sourceFile = match[2]!.split(/[\\/]/).at(-1)!;
    const row = Number(match[3]);
    if (!/^[-\w.]+\.(?:ts|js|mjs|cjs)$/.test(sourceFile) || !Number.isSafeInteger(row)) continue;
    frames.push({ functionName: match[1] || null, sourceFile, line: row });
    if (frames.length >= 8) break;
  }
  return frames;
}

function safeNativePreReceiptFailedChecks(error: unknown): string[] {
  const message = error instanceof Error ? error.message : "";
  const prefix = "Native pre-receipt command is outside the current conversation Run, input, Human and workspace scope:";
  if (!message.startsWith(prefix)) return [];
  const allowed = new Set(["provider", "execution_input", "human_run_manifest", "comment_source", "workspace_roots",
    "trusted_command", "runtime_context_source_authority", "runtime_context_target", "credential_shape", "task_source_owner",
    "workload_credentials"]);
  return message.slice(prefix.length).split(",").filter((value, index, all) => all.indexOf(value) === index && allowed.has(value)).slice(0, 11);
}


export async function configureManagedConversationSandboxHost(input: {
  db: ReturnType<typeof createDb>;
  actor: AuthorizationActor;
  companyId: string;
  agentId: string;
  providerBindingId: string;
  gateway: ReturnType<typeof workerModelGateway>;
  profile: import("../../services/orchestration/worker-model-profiles.js").WorkerModelProfile;
  root: string;
  opencodeBinary: string;
  brokerOrigin: string;
  brokerProxyOrigin: string | null;
  certBundlePath: string;
  setBrokerToken: (token: string) => void;
}) {
  const { db, actor, companyId, agentId, providerBindingId } = input;
  const brokerOrigin = new URL(input.brokerOrigin).origin;
  const taskWorkspaceNamespace = join(await realpath(resolvePaperclipInstanceRoot()), "chat-workspaces", companyId, agentId);
  const runtime = runtimeControlService(db, { runtime: { suspectSeconds: 90, unreachableSeconds: 600, relayPort: 3102 } } as SaasPlatformConfig,
    undefined, { credentialBrokerOrigin: brokerOrigin, workerModels: input.gateway as any });
  const purposesByCommandDigest = new Map<string, Array<string | null>>();
  const purposeByRequestId = new Map<string, string | null>();
  const relayCommandOwnerByRequestId = new Map<string, string>();
  const sandboxRelayRequestByError = new WeakMap<object, {
    requestId: string; requestDigest: string; harnessCommandDigest: string; purpose: string | null; sequence: number;
  }>();
  let sandboxRelayRequestSequence = 0;
  const relayRequestFactsForError = (error: unknown) => {
    let candidate: unknown = error;
    for (let depth = 0; depth < 4 && candidate && typeof candidate === "object"; depth++) {
      const facts = sandboxRelayRequestByError.get(candidate);
      if (facts) return facts;
      candidate = "cause" in candidate ? candidate.cause : null;
    }
    return undefined;
  };
  const commandDigest = (command: string, args: readonly string[]) => nativeSha256({ command, args });
  let nativeSessionStartCredentialNegativeControls: { missingTokenDenied: boolean; mismatchedTokenDenied: boolean } | null = null;
  const executeOpenShell = runtime.relay.executeOpenShell.bind(runtime.relay);
  runtime.relay.executeOpenShell = async relayInput => {
    const request = relayInput.request;
    const harnessCommandDigest = commandDigest(request.argv[0]!, request.argv.slice(1));
    const purposeQueue = purposesByCommandDigest.get(harnessCommandDigest);
    const purpose = purposeQueue?.shift() ?? null;
    const requestFacts = { requestId: request.requestId, requestDigest: request.commandDigest,
      harnessCommandDigest, purpose, sequence: ++sandboxRelayRequestSequence };
    purposeByRequestId.set(request.requestId, purpose);
    const credential = request.modelBrokerCredential;
    if (!nativeSessionStartCredentialNegativeControls && request.argv[0] === "sh" &&
      request.argv[3] === "paperclip-runner-launch" && credential) {
      const expectDenied = async (tampered: typeof relayInput.request) => {
        try { await executeOpenShell({ ...relayInput, request: tampered }); return false; }
        catch { return true; }
      };
      const missingTokenDenied = await expectDenied({ ...request, modelBrokerCredential: undefined });
      const mismatchedTokenDenied = await expectDenied({ ...request,
        modelBrokerCredential: { ...credential, capabilityToken: "invalid-model-capability" } });
      nativeSessionStartCredentialNegativeControls = { missingTokenDenied, mismatchedTokenDenied };
    }
    try {
      return await executeOpenShell(relayInput);
    } catch (error) {
      if (error && typeof error === "object") sandboxRelayRequestByError.set(error, requestFacts);
      throw error;
    } finally {
      purposeByRequestId.delete(request.requestId);
    }
  };
  const hostKeys = generateKeyPairSync("rsa", { modulusLength: 3072 });
  await instanceSettingsService(db).updateExperimental({
    sandbox_abstraction_v7: true, openshell_v7: true, runtime_host_agent_v6: true,
    hosted_openclaw_v6: true,
    saas_deployment_profile_v6: true, billing_v6: true, billing_entitlements_v6: true, billing_usage_v6: true,
  });
  await db.insert(runtimeVersionCatalog).values({ imageDigest, providerVersion: "fixture-software-host",
    stateFormat: "v1", hostAgentMinimumVersion: "6.0.0", conformance: { controlledSoftwareHost: true }, status: "approved" });
  const conversationHostCapacity = { cpuMillis: 1000, memoryBytes: 1073741824n, diskBytes: 10737418240n, pidsLimit: 128 };
  await db.insert(runtimeCapacityProfiles).values({ key: "conversation-software-host", ...conversationHostCapacity, qualified: true });
  const [host] = await db.insert(runtimeHosts).values({ environment: "test", region: "local", capacityClass: "software-fixture",
    cpuTotalMillis: 4000, memoryTotalBytes: 8000000000n, diskTotalBytes: 40000000000n,
    publicKeyPem: hostKeys.publicKey.export({ type: "spki", format: "pem" }).toString(), status: "READY",
    hostAgentVersion: "6.0.2", lastHeartbeatAt: new Date() }).returning();
  if (!host) throw new Error("conversation_software_host_row_missing");
  const payerUserId = actor.userId;
  if (!payerUserId) throw new Error("conversation_software_host_payer_missing");
  const [account] = await db.insert(billingAccounts).values({ displayName: "Conversation software host fixture", payerUserId }).returning();
  if (!account) throw new Error("conversation_software_host_billing_account_missing");
  await db.insert(billingAccountCompanies).values({ companyId, billingAccountId: account.id });
  for (const productKeys of [["platform", "runtime_standard"], ["runtime_standard"]])
    await db.insert(billingSubscriptions).values({ billingAccountId: account.id,
      providerSubscriptionId: `conversation-software-${randomUUID()}`, status: "active", productKeys,
      currentPeriodEnd: new Date(Date.now() + 86_400_000), providerUpdatedAt: new Date(), sourceHash: "controlled-software-host-fixture" });
  const [cell] = await db.insert(runtimeCells).values({ companyId, billingAccountId: account.id,
    capacityProfile: "conversation-software-host", desiredImageDigest: imageDigest, status: "STOPPED",
    isolationMode: "company_cell", runtimeHostId: host.id, providerBindingId }).returning();
  if (!cell) throw new Error("conversation_software_host_cell_missing");
  // This fixture represents a V6-qualified profile and the existing reservation owned by this STOPPED cell.
  // Sandbox qualification must reuse this bounded profile, not allocate untracked capacity.
  await db.update(runtimeHosts).set({ cpuReservedMillis: conversationHostCapacity.cpuMillis,
    memoryReservedBytes: conversationHostCapacity.memoryBytes, diskReservedBytes: conversationHostCapacity.diskBytes })
    .where(eq(runtimeHosts.id, host.id));
  const [provider] = await db.select().from(agentProviderBindings).where(eq(agentProviderBindings.id, providerBindingId)).limit(1);
  if (!provider) throw new Error("conversation_software_host_provider_binding_missing");
  const providerService = agentProviderBindingService(db);
  await providerService.attach(actor, companyId, agentId, {
    providerBindingId, providerProfileRef: `aw:cell:${cell.id}:generation:${cell.generation}`,
  });
  const [agent] = await db.select().from(agents).where(eq(agents.id, agentId)).limit(1);
  if (!agent) throw new Error("conversation_software_host_agent_missing");
  const providerSnapshot = makeProviderCapabilitySnapshot(await discoverNativeCapabilities({ companyId,
    adapterType: agent.adapterType, config: agent.adapterConfig }));
  const providerSnapshotInput = Object.fromEntries(Object.entries(providerSnapshot).filter(([key]) => key !== "hash")) as Omit<typeof providerSnapshot, "hash">;
  await providerService.recordDiscovery(companyId, agentId, providerSnapshotInput,
    Object.fromEntries(providerConformanceRequirements(providerSnapshot, "isolated_per_presence").map(check => [check, true])));
  const qualifiedProvider = await providerService.assertRuntime(companyId, agentId);
  const providerProfileRef = qualifiedProvider.runtime.providerProfileRef;
  if (!providerProfileRef) throw new Error("conversation_software_host_provider_profile_missing");
  input.profile.providerProfileRef = providerProfileRef;
  const providerSnapshotHash = qualifiedProvider.provider.capabilitySnapshotHash;
  if (!providerSnapshotHash) throw new Error("conversation_software_host_provider_snapshot_missing");
  input.profile.providerSnapshotHash = providerSnapshotHash;
  const environment = await environmentService(db).ensureManagedSandboxEnvironment({ companyId,
    name: `Conversation managed sandbox ${agentId}`, provider: "fake", stockVersion: "conversation-software-host-v1",
    config: { image: "ubuntu:24.04", reuseLease: false } }).then(result => result.environment);
  await db.update(agents).set({ defaultEnvironmentId: environment.id }).where(eq(agents.id, agentId));

  // Qualification-only canary and runtime connection have independent owners
  // and grants: revoking the canary must leave runtime credentials active.
  const canarySecretValue = `qualification-secret-${randomUUID()}`;
  const runtimeSecretValue = `runtime-secret-${randomUUID()}`;
  const secrets = secretService(db);
  const canarySecret = await secrets.create(companyId, {name:`Qualification canary ${randomUUID()}`,
    key:`qualification_canary_${randomUUID().replace(/-/g,"")}`,provider:"local_encrypted",value:canarySecretValue});
  const runtimeSecret = await secrets.create(companyId, {name:`Runtime broker ${randomUUID()}`,
    key:`runtime_broker_${randomUUID().replace(/-/g,"")}`,provider:"local_encrypted",value:runtimeSecretValue});
  const schemas = {
    read_canary:{type:"object",properties:{fixtureId:{type:"string"},caseId:{type:"string"},nonce:{type:"string"}},required:["fixtureId","caseId","nonce"],additionalProperties:false},
    read_record:{type:"object",properties:{id:{type:"string"}},required:["id"],additionalProperties:false},
  };
  const fixtureToolAccess = toolAccessService(db,{
    remoteHttpEndpointLookup:async()=>[{address:"8.8.8.8",family:4}],
    remoteHttpRequest:async(url,init)=>{
      const rpc=JSON.parse(String(init.body)) as {id:unknown;method:string};
      assert.equal(rpc.method,"tools/list");
      const tool=url === `${brokerOrigin}/mcp/qualification/credential-echo` ? "read_canary" : url === "https://provider.example.test/mcp" ? "read_record" : null;
      assert.ok(tool,"Unknown software fixture destination");
      return new Response(JSON.stringify({jsonrpc:"2.0",id:rpc.id,result:{tools:[{name:tool,
        description:"Read fixed software fixture",inputSchema:schemas[tool],annotations:{readOnlyHint:true}}]}}),
        {status:200,headers:{"content-type":"application/json"}});
    },
  });
  const makeConnection=async(kind:"canary"|"runtime",secretId:string)=>{
    const applicationKey=`conversation-${kind}-${randomUUID().replace(/-/g,"")}`;
    const [application]=await db.insert(toolApplications).values({companyId,applicationKey,name:`Conversation ${kind} fixture`,type:"mcp_http",status:"active"}).returning();
    assert.ok(application);
    const url=kind === "canary" ? `${brokerOrigin}/mcp/qualification/credential-echo` : "https://provider.example.test/mcp";
    const credentialSecretRefs=[{secretId,versionSelector:"latest" as const,configPath:"credentials.authorization",required:true,label:`${kind} fixture credential`}];
    const connection=await fixtureToolAccess.createConnection(companyId,{applicationId:application.id,name:`Conversation ${kind} fixture`,
      connectionPurpose:"tool",authKind:"api_key",ownership:"customer",connectionKind:"managed",
      transport:"mcp_remote",status:"active",enabled:true,config:{url},transportConfig:{url},
      credentialRefs:[{name:"credentials.authorization",secretId,version:"latest",placement:"header",key:"Authorization",prefix:"Bearer "}],
      credentialSecretRefs},{actorType:"user",actorId:payerUserId});
    const upstream=kind === "canary" ? "read_canary" : "read_record";
    await db.insert(toolCatalogEntries).values({companyId,applicationId:application.id,connectionId:connection.id,entryKind:"tool",
      name:`${upstream}-${randomUUID()}`,toolName:upstream,title:`Read ${kind}`,description:"Read fixed software fixture",
      inputSchema:schemas[upstream],annotations:{readOnlyHint:true},riskLevel:"read",isReadOnly:true,isWrite:false,isDestructive:false,
      status:"active",versionHash:randomUUID(),quarantinedAt:null});
    const health=await fixtureToolAccess.checkHealth(connection.id,{actorType:"user",actorId:payerUserId});
    assert.equal(health.connection.healthStatus,"ok");
    const [grant]=await db.select().from(connectionGrants).where(and(eq(connectionGrants.companyId,companyId),
      eq(connectionGrants.connectionId,connection.id),eq(connectionGrants.status,"active"),eq(connectionGrants.isDefault,true))).limit(1);
    assert.ok(grant);assert.equal(grant.kind,"organization");
    const toolName=`mcp.${applicationKey.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"")}-${connection.id.replace(/-/g,"").slice(0,8)}:${upstream.replace(/_/g,"-")}`;
    return {connection,grant,toolName,credentialSecretRefs};
  };
  const canary=await makeConnection("canary",canarySecret.id),runtimeConnection=await makeConnection("runtime",runtimeSecret.id);
  assert.notEqual(canary.connection.id,runtimeConnection.connection.id);assert.notEqual(canary.grant.id,runtimeConnection.grant.id);
  const [runtimeToolProfile]=await db.insert(toolProfiles).values({companyId,profileKey:`conversation-runtime-${randomUUID()}`,
    name:"Conversation runtime broker fixture",defaultAction:"deny"}).returning();
  assert.ok(runtimeToolProfile);
  await db.insert(toolProfileBindings).values({companyId,profileId:runtimeToolProfile.id,targetType:"agent",targetId:agentId});
  await db.insert(toolProfileEntries).values({companyId,profileId:runtimeToolProfile.id,selectorType:"tool_name",effect:"include",toolName:runtimeConnection.toolName});
  const [gatewayProfile]=await db.insert(toolProfiles).values({companyId,profileKey:`conversation-gateway-${randomUUID()}`,
    name:"Conversation qualification gateway",defaultAction:"deny"}).returning();assert.ok(gatewayProfile);
  await db.insert(toolProfileEntries).values([canary,runtimeConnection].map(item=>({companyId,profileId:gatewayProfile.id,
    selectorType:"connection" as const,effect:"include" as const,connectionId:item.connection.id})));
  let qualificationCredentialFixture: NonNullable<SandboxCapabilitySnapshot["qualificationCredentialFixture"]>;
  const qualificationToolResponses:Array<{caseId:string;status:number;reasonCode:string|null;marker:string|null;replayDenied?:boolean}>=[];
  const gatewayOptions:Parameters<typeof createToolGatewayService>[1]={operatorUserIds:[payerUserId],qualificationBrokerOrigin:brokerOrigin,toolActionSigningSecret:"conversation-software-canary",
    remoteHttpRequest:async(url,init)=>{
      assert.equal(url,`${brokerOrigin}/mcp/qualification/credential-echo`);
      const authorization=new Headers(init.headers).get("authorization");assert.ok(authorization === `Bearer ${canarySecretValue}`,"Qualification provider credential did not match its separate canary grant");
      assert.equal(init.method,"POST");assert.equal(init.redirect,"manual");
      const http=request(qualificationProtocolApp).post("/mcp/qualification/credential-echo");
      new Headers(init.headers).forEach((value,key)=>http.set(key,value));
      const response=await http.send(JSON.parse(String(init.body)));
      assert.ok(!JSON.stringify(response.body).includes(canarySecretValue),"Qualification echo reflected its credential");
      return new Response(JSON.stringify(response.body),{status:response.status,headers:{"content-type":"application/json"}});
    }};
  const qualificationGateway=createToolGatewayService(db,gatewayOptions);
  registerAssignedMcpGateway(db,qualificationGateway,scopedDb=>createToolGatewayService(scopedDb,gatewayOptions));
  const namedGateway=await qualificationGateway.createNamedGateway({companyId,body:{name:"Conversation qualification and runtime gateway",profileId:gatewayProfile.id}});
  const credentialFixtureBase={version:1 as const,fixtureId:`conversation-canary-${randomUUID()}`,profileId:"paperclip-qualification",profileHash:nativeSha256({gatewayProfileId:gatewayProfile.id}),
    binaries:["/usr/bin/curl"] as ["/usr/bin/curl"],wrongBinaryPath:"/usr/bin/wget" as const,origin:brokerOrigin,port:Number(new URL(brokerOrigin).port || 443),method:"POST" as const,
    gatewayPublicId:namedGateway.gatewayPublicId,toolName:canary.toolName,wrongToolName:"wrong_scope_canary",
    argumentTemplateHash:nativeSha256({caseId:"<caseId>",fixtureId:"<fixtureId>",nonce:"<nonce>"}),marker:"paperclip-qualification-credential-ok-v1"};
  qualificationCredentialFixture={...credentialFixtureBase,fixtureHash:nativeSha256(credentialFixtureBase)};
  const {fixtureHash:_goldenHash,...goldenBody}=goldenQualificationProbeFixture;
  const qualificationBody={...goldenBody,credential:qualificationCredentialFixture};
  const qualificationProbeFixture={...qualificationBody,fixtureHash:nativeSha256(qualificationBody)};
  await fixtureToolAccess.updateConnection(canary.connection.id,{config:{...(canary.connection.config as Record<string,unknown>),sandboxQualificationCanary:{
    argumentTemplateHash:qualificationCredentialFixture.argumentTemplateHash,endpointOrigin:brokerOrigin,endpointPath:"/mcp/qualification/credential-echo",
    fixtureHash:qualificationCredentialFixture.fixtureHash,fixtureId:qualificationCredentialFixture.fixtureId,gatewayPublicId:namedGateway.gatewayPublicId,
    grantId:canary.grant.id,kind:"platform_owned_qualification_echo",marker:qualificationCredentialFixture.marker,noSideEffects:true,
    purpose:"sandbox_qualification",readOnly:true,setupOnly:true,toolName:canary.toolName,version:1,wrongToolName:qualificationCredentialFixture.wrongToolName,
  }}});
  const qualificationProtocolApp=express();qualificationProtocolApp.use(express.json());
  qualificationProtocolApp.use(mcpGatewayProtocolRoutes(qualificationGateway));qualificationProtocolApp.use(errorHandler);
  const [runtimePresence]=await db.select({id:agentPresenceRuntimeBindings.id}).from(agentPresenceRuntimeBindings).where(and(
    eq(agentPresenceRuntimeBindings.companyId,companyId),eq(agentPresenceRuntimeBindings.agentId,agentId),eq(agentPresenceRuntimeBindings.status,"active"))).limit(1);
  assert.ok(runtimePresence);
  const runtimeBrokerBinding={connectionId:runtimeConnection.connection.id,grantVersionHash:"",hostname:"provider.example.test",port:443,
    methods:["POST"] as ["POST"],pathPrefixes:["/mcp"],binary:null,ttlSeconds:120};

  let protectedQualificationTarget: Record<string, any> | null = null;
  const projectedQualification=projectOpenShellQualificationProbePolicy(qualificationProbeFixture);
  assert.deepEqual(projectedQualification.unsupportedFeatures,[]);assert.ok(projectedQualification.document);
  const qualificationDocument=projectedQualification.document;
  const softwareProbeObservations:Array<{caseId:string;passed:boolean;observationHash:string}>=[];
  const filesystemAllowed=(value:string)=>{
    const normalized=posix.normalize(value);
    return [...qualificationDocument.filesystem_policy.read_only,...qualificationDocument.filesystem_policy.read_write]
      .some(root=>normalized === root || normalized.startsWith(`${root.replace(/\/$/,"")}/`));
  };
  const policyCanary=express();
  policyCanary.use((req,res)=>{
    const target=new URL(String(req.headers["x-fixture-url"])),binary=String(req.headers["x-fixture-binary"]);
    const resolved=String(req.headers["x-fixture-resolve"] ?? "203.0.113.7");
    const endpoints=Object.values(qualificationDocument.network_policies).filter(policy=>policy.binaries.some(item=>item.path === binary))
      .flatMap(policy=>policy.endpoints);
    const allowed=resolved === "203.0.113.7" && endpoints.some(endpoint=>endpoint.host === target.hostname && endpoint.port === Number(target.port || 443) &&
      endpoint.rules.some(rule=>rule.allow.method === req.method && new RegExp(`^${rule.allow.path.replace(/[.+^${}()|[\]\\]/g,"\\$&").replace(/\?/g,".")}$`).test(target.pathname)));
    if (!allowed || target.pathname.startsWith("/redirect/")) {res.status(403).json({denied:true});return;}
    res.json({marker:qualificationProbeFixture.network.allow.marker});
  });
  const requestPolicyCanary=async(template:string,method:string,resolve?:string)=>{
    const target=template.replace("{nonce}",randomBytes(16).toString("hex"));
    const call=request(policyCanary)[method.toLowerCase() as "get"|"post"]("/")
      .set("x-fixture-url",target).set("x-fixture-binary","/usr/bin/curl");
    if(resolve)call.set("x-fixture-resolve",resolve);
    const response=await call;
    return {status:response.status,marker:response.body?.marker ?? null};
  };
  const observeSoftwareBoundary=async(test:SandboxProbeCase)=>{
    const fixture=qualificationProbeFixture;
    let passed=false,observation:Record<string,unknown>;
    switch(test.caseId){
      case "filesystem_allow":case "filesystem_deny":case "filesystem_escape":{
        const operand=test.caseId === "filesystem_allow" ? fixture.filesystem.allowedReadPath : test.caseId === "filesystem_deny"
          ? fixture.filesystem.deniedReadPath : fixture.filesystem.escapeOperand;
        const allowed=filesystemAllowed(operand);passed=allowed === (test.expected === "allow");
        observation={operand,normalized:posix.normalize(operand),allowed};break;
      }
      case "process_nonprivileged":case "process_privilege_denied":{
        const effectiveUid=qualificationDocument.process.run_as_user,effectiveGid=qualificationDocument.process.run_as_group;
        const privilegedRequestAllowed=effectiveUid === "0" || effectiveGid === "0";
        passed=!privilegedRequestAllowed && effectiveUid === fixture.runAsUser && effectiveGid === fixture.runAsGroup;
        observation={effectiveUid,effectiveGid,privilegedRequestAllowed};break;
      }
      case "syscall_allow":case "syscall_deny":{
        // Controlled software kernel decision: unprivileged read/write are
        // available; privileged namespace/mount requests are refused. This
        // fixture is not evidence of a physical OpenShell kernel boundary.
        const syscall=test.caseId === "syscall_allow" ? "read" : "mount";
        const allowed=["read","write"].includes(syscall) && qualificationDocument.process.run_as_user !== "0";
        passed=allowed === (test.expected === "allow");observation={syscall,allowed,uid:qualificationDocument.process.run_as_user};break;
      }
      case "network_allow":case "network_l7_allow":case "network_l7_deny":{
        const route=test.caseId === "network_allow" ? fixture.network.allow : test.caseId === "network_l7_allow" ? fixture.network.l7Allow : fixture.network.l7Deny;
        const response=await requestPolicyCanary(route.urlTemplate,route.method);
        passed=test.expected === "allow" ? response.status === 200 && response.marker === route.marker : response.status === 403 && response.marker === null;
        observation={...response,method:route.method};break;
      }
      case "network_host_port_deny":{
        const responses=await Promise.all([fixture.network.hostPortDeny,fixture.network.wrongHostDeny,fixture.network.redirectDeny]
          .map(route=>requestPolicyCanary(route.urlTemplate,route.method)));
        passed=responses.every(response=>response.status === 403 && response.marker === null);observation={responses};break;
      }
      case "network_dns_redirect_deny":{
        const route=fixture.network.dnsRedirectDeny,response=await requestPolicyCanary(route.urlTemplate,route.method,route.resolveIp);
        passed=response.status === 403 && response.marker === null;observation={...response,resolveIp:route.resolveIp};break;
      }
      case "resource_exhaustion_contained":{
        const limits=protectedQualificationTarget?.resourceLimits;
        passed=Boolean(limits && limits.cpuMillis > 0 && limits.cpuMillis <= conversationHostCapacity.cpuMillis &&
          limits.memoryBytes > 0 && limits.memoryBytes <= Number(conversationHostCapacity.memoryBytes) &&
          limits.diskBytes > 0 && limits.diskBytes <= Number(conversationHostCapacity.diskBytes) && limits.pidsLimit > 0 && limits.pidsLimit <= conversationHostCapacity.pidsLimit);
        observation={limits,cellReservation: {cpuMillis:conversationHostCapacity.cpuMillis,memoryBytes:Number(conversationHostCapacity.memoryBytes),
          diskBytes:Number(conversationHostCapacity.diskBytes),pidsLimit:conversationHostCapacity.pidsLimit}};break;
      }
      case "force_stop":{
        const child=spawn(process.execPath,["-e","setInterval(()=>{},1000)"],{stdio:"ignore"});
        await once(child,"spawn");const closed=once(child,"close");child.kill("SIGTERM");
        const [code,signal]=await closed;passed=signal === "SIGTERM" && code === null;observation={code,signal};break;
      }
      default:throw new Error(`conversation_software_probe_unsupported:${test.caseId}`);
    }
    const observationHash=nativeSha256({kind:"controlled_software_boundary",caseId:test.caseId,documentHash:projectedQualification.documentHash,observation});
    softwareProbeObservations.push({caseId:test.caseId,passed,observationHash});
    return {action:"probe",verdict:passed ? "pass" : "fail",observationHash,contractHash:test.contractHash,targetQualificationHash:protectedQualificationTarget?.targetHash};
  };

  const identity: SandboxIdentity = { companyId, bindingId: randomUUID(), cellId: cell.id,
    cellGeneration: cell.generation.toString(), sandboxRef: `aw-v7-${cell.id}` };
  const transport = nativeSandboxHostTransport(db, { operatorUserIds: [actor.userId!] });
  const state = new Map<string, "stopped" | "ready" | "running">();
  const policies = new Map<string, string>();
  let capabilityTestedAt = new Date(Date.now() - 1000).toISOString();
  // Keep the admitted protected report short-lived so the managed erasure
  // integration test can observe natural expiry after its real provider turn.
  let capabilityExpiresAt = new Date(Date.now() + 150_000).toISOString();
  const capabilities = (fresh = false) => {
    const now = Date.now();
    const preflight = protectedQualificationTarget === null;
    const target = protectedQualificationTarget;
    const implementedControls=SANDBOX_CONTROLS.filter(control=>{
      if(control === "credentialBrokering")return canary.connection.createdByUserId === payerUserId && canary.grant.id !== runtimeConnection.grant.id && Boolean(qualificationProtocolApp);
      const cases=sandboxProbeCases(target?.policyHash ?? qualificationProbeFixture.fixtureHash,[control]);
      return cases.length > 0 && cases.every(test=>softwareProbeObservations.some(observation=>observation.caseId === test.caseId && observation.passed));
    });
    if(preflight){capabilityTestedAt=new Date(now-1000).toISOString();capabilityExpiresAt=new Date(now+150_000).toISOString();}
    return { ...Object.fromEntries(SANDBOX_CONTROLS.map(control => [control, !preflight && implementedControls.includes(control)])),
      backend: "openshell", backendVersion: "0.1.2", hostKernelVersion: "controlled-software-host",
      sandboxImageDigest: imageDigest, filesystemEnforcementMode: "hard_requirement", staticPolicyRequiresRecreate: true,
      dynamicNetworkPolicy:!preflight && implementedControls.includes("networkDestinationPolicy"),
      policyProverBoundaryCheck:!preflight && conversationRequiredControls.every(control=>implementedControls.includes(control)),
      policyProverCoverage:preflight ? [] : implementedControls,
      credentialBindingDimensions: preflight ? [] : ["company","presence","host","port","method","path","binary","expiry","revocation"],
      credentialBrokerProviderProfile:{id:qualificationCredentialFixture.profileId,hash:qualificationCredentialFixture.profileHash},
      modelBrokerProviderProfile: { id: hostModelProfile.id, hash:nativeSha256(hostModelProfile) },
      qualificationCredentialFixture,
      testedAt: fresh ? new Date(now - 1000).toISOString() : capabilityTestedAt,
      expiresAt: fresh ? new Date(now + 86_400_000).toISOString() : capabilityExpiresAt,
      qualificationHash: target?.targetHash ?? qualificationProbeFixture.fixtureHash, evidenceKind: "protected_host_report",
      ...(target ? { qualificationTarget: target } : {}),
      qualificationProbeFixture,
    };
  };
  const service = executionSandboxService(db, { operatorUserIds: [actor.userId!], credentialBrokerOrigin: brokerOrigin,
    assertRuntimeStartAdmission: (tx, start) => runtime.assertSandboxStartAdmission(tx, start),
    recordRuntimeWorkloadState: (tx, stateChange) => runtime.recordSandboxWorkloadState(tx, stateChange),
    backendFor: (_binding: unknown, currentActor: AuthorizationActor) => {
      const bridge = transport.bridge(currentActor);
      return {
        backend: "openshell", evidenceKind: "protected_host_report",
        capabilities: async () => bridge.capabilities(identity),
        prepareSandbox: async (_scope:SandboxIdentity,intent?:import("../../services/execution-sandbox/backend.js").SandboxProvisioningIntent)=>{
          if(!intent)return transport.bridge(currentActor).prepare(identity);
          if(intent.purpose === "qualification"){
            const preflight=await bridge.capabilities(identity);
            assert.ok(preflight);assert.deepEqual(preflight.qualificationProbeFixture,qualificationProbeFixture);
            assert.equal(preflight.qualificationHash,qualificationProbeFixture.fixtureHash);
            assert.equal(preflight.policyProverBoundaryCheck,false);assert.deepEqual(preflight.policyProverCoverage,[]);
            for(const control of SANDBOX_CONTROLS)assert.equal(preflight[control],false);
          }
          const document=intent.purpose === "qualification" ? qualificationDocument : projectOpenShellPolicy(intent.policy!.compiledPolicy,intent.policy!.modelBrokerEndpoint).document;
          const policyHash=intent.purpose === "qualification" ? nativeSha256(document) : nativeSha256(intent.policy!);
          const resources=intent.purpose === "qualification" ? policyFixture().resources : intent.policy!.compiledPolicy.resources;
          const prepared=await bridge.prepare(identity,{purpose:intent.purpose,operationKey:intent.operationKey,bindingVersion:intent.bindingVersion,
            expiresAt:intent.expiresAt,policyHash,document,resourceLimits:{cpuMillis:resources.cpuMillis,memoryBytes:resources.memoryBytes,diskBytes:resources.diskBytes,pidsLimit:resources.pidsLimit},
            ...(intent.purpose === "qualification" ? {probeFixtureHash:qualificationProbeFixture.fixtureHash,qualificationProbeFixture} : {})});
          return {...prepared,bindingVersion:intent.bindingVersion,policyHash,probePolicyHash:nativeSha256(document),
            resourceLimits:{cpuMillis:resources.cpuMillis,memoryBytes:resources.memoryBytes,diskBytes:resources.diskBytes,pidsLimit:resources.pidsLimit}};
        },
        // Admission and command execution must consume the exact response from
        // the authenticated Native host relay, including its `generation`
        // field. A local fixture map is not an observed workload receipt.
        inspectWorkload: async (scope: SandboxIdentity) => bridge.inspect(scope),
        applyPolicy: async (value: { policy: unknown; expiresAt: string }) => {
          const policyHash = nativeSha256(value.policy);
          const resources = (value.policy as any).compiledPolicy.resources;
          const reply = await bridge.apply({ ...identity, document: projectOpenShellPolicy((value.policy as any).compiledPolicy).document,
            policyHash, expiresAt: value.expiresAt, idempotencyKey: `conversation-software-policy:${policyHash}`,
            resourceLimits: { cpuMillis: resources.cpuMillis, memoryBytes: resources.memoryBytes, diskBytes: resources.diskBytes, pidsLimit: resources.pidsLimit } });
          state.set(identity.cellId, reply.applied ? "ready" : "stopped"); policies.set(identity.cellId, policyHash);
          return { applied: reply.applied, requiresRecreate: reply.requiresRecreate, observedPolicyHash: reply.policyHash, unsupportedFeatures: [] };
        },
        startWorkload: async (value: { expiresAt: string; policy: unknown; idempotencyKey: string }) => {
          const policyHash = nativeSha256(value.policy);
          const reply = await bridge.start({ ...identity, expiresAt: value.expiresAt, policyHash, idempotencyKey: value.idempotencyKey });
          state.set(identity.cellId, "running"); return { operationId: reply.operationId };
        },
        stopWorkload: async (value: { idempotencyKey: string }) => { const reply = await bridge.stop({ ...identity, idempotencyKey: value.idempotencyKey }); state.set(identity.cellId, "stopped"); return { operationId: reply.operationId }; },
        destroySandbox: (value: { idempotencyKey: string }) => bridge.destroy({ ...identity, idempotencyKey: value.idempotencyKey }),
        probeBoundary: async (value: { test: SandboxProbeCase }) => {
          return await bridge.probe({ ...identity, test:value.test });
        },
      } as any;
    } });
  let binding: Awaited<ReturnType<typeof service.create>>;
  let sessionHostEngine: any = null;
  const hostCliOperations: string[] = [];
  let observedSandboxPhase: "Ready" | "Stopped" = "Stopped";
  const modelBrokerSessionReceipts: Array<{ phase: string; sessionKey: string; capabilityHash: string;
    expiresAt: string; sessionDeadlineAt: string }> = [];
  const sessionProviders = new Map<string, { type: string; credential: string | null; expiresAt: string | null;
    family: "worker_model" | "conversation_model" | null }>();
  const attachedSessionProviders = new Set<string>();
  const hostModelProfile = {
    id: "paperclip-model-broker",
    credentials: [{ name: "model_token", env_vars: ["PAPERCLIP_SANDBOX_MODEL_TOKEN"], required: true,
      auth_style: "bearer", header_name: "Authorization" }],
    endpoints: [{ host: new URL(brokerOrigin).hostname, port: Number(new URL(brokerOrigin).port || 443),
      protocol: "rest", enforcement: "enforce", path: "", rules: [{ allow: { method: "POST",
        path: "/runtime-tools/model/v1/messages" } }] }],
    binaries: [{ path: input.opencodeBinary }],
  };
  const initializeSessionHostEngine = async () => {
    if (sessionHostEngine) return;
    const hostRoot = join(input.root, ".openshell-session-engine");
    const stateHome = join(hostRoot, "state");
    mkdirSync(stateHome, { recursive: true, mode: 0o700 });
    const executable = join(stateHome, "openshell-cli.fixture");
    const executableBytes = "controlled OpenShell session fixture CLI\n";
    writeFileSync(executable, executableBytes, { mode: 0o700 });
    let sandboxId = randomUUID();
    let sandboxPhase: "Ready" | "Stopped" = "Ready";
    observedSandboxPhase = sandboxPhase;
    let containerId = "d".repeat(64);
    const supervisorContainerId = "c".repeat(64);
    const imageId = `sha256:${"e".repeat(64)}`;
    let currentImageDigest = imageDigest;
    let currentDocument: any = structuredClone(qualificationDocument);
    let currentProvisioning: Record<string, string> = {};
    let currentWorkdir = qualificationProbeFixture.filesystem.workdirPath;
    let currentResource = { NanoCpus: 0, Memory: 0, MemorySwap: 0, PidsLimit: 128,
      StorageOpt: { size: `${policyFixture().resources.diskBytes}B` } };
    let policyRevision = 1;
    const scopeNow = () => ({ companyId, bindingId: binding.id, cellId: cell.id,
      cellGeneration: cell.generation.toString(), sandboxRef: binding.sandboxRef ?? `aw-v7-${binding.id}` });
    const labelsNow = () => ({
      "openshell.ai/managed-by": "openshell", "openshell.ai/sandbox-id": sandboxId,
      "openshell.ai/sandbox-name": scopeNow().sandboxRef, "openshell.ai/sandbox-namespace": "fixture-namespace",
      "openshell.ai/sandbox-workspace": "fixture-company", "openshell.ai/workspace-root": currentWorkdir,
      "openshell.ai/isolation-backend": "openshell-sandbox", "openshell.ai/isolation-role": "sandbox",
      "aw.company_id": companyId, "aw.binding_id": binding.id, "aw.cell_id": cell.id,
      "aw.generation": cell.generation.toString(), ...currentProvisioning,
    });
    const dockerContainer = (role: "sandbox" | "supervisor") => role === "supervisor" ? ({
      Id: supervisorContainerId, Image: imageId, Config: { Image: imageId, Labels: {
        "openshell.ai/managed-by": "openshell", "openshell.ai/sandbox-id": sandboxId,
        "openshell.ai/sandbox-name": scopeNow().sandboxRef, "openshell.ai/sandbox-namespace": "fixture-namespace",
        "openshell.ai/isolation-role": "supervisor",
      } }, HostConfig: { LogConfig: { Type: "none", Config: {} } },
    }) : ({
      Id: containerId, Image: imageId, RepoDigests: [currentImageDigest],
      Config: { Image: imageId, WorkingDir: currentWorkdir, Env: [], Labels: labelsNow() },
      HostConfig: { ...currentResource, LogConfig: { Type: "none", Config: {} },
        Tmpfs: { "/run/openshell-supervisor-ca/material": "rw,noexec,nosuid,nodev,size=1m,uid=1000,gid=1000,mode=0755" } },
      Mounts: [
        { Type: "volume", Name: `openshell-channel-${createHash("sha256").update(`fixture-namespace\0${sandboxId}`).digest("hex").slice(0, 32)}`,
          Driver: "local", Destination: "/.openshell/channel", RW: true },
        { Type: "tmpfs", Destination: "/run/openshell-supervisor-ca/material",
          Mode: "rw,noexec,nosuid,nodev,size=1m,uid=1000,gid=1000,mode=0755", RW: true },
      ], State: { Running: sandboxPhase === "Ready" },
    });
    const hostRun = async (file: string, args: string[], options: { env?: NodeJS.ProcessEnv }) => {
      if (file === "docker") {
        if (args[0] === "info" && args.includes("{{.ID}}")) return { stdout: "fixture-docker-engine\n", stderr: "" };
        if (args[0] === "info" && args.includes("{{.Driver}}")) return { stdout: "overlay2\n", stderr: "" };
        if (args[0] === "info" && args.includes("{{json .DriverStatus}}"))
          return { stdout: JSON.stringify([["Backing Filesystem", "xfs"]]), stderr: "" };
        if (args[0] === "info" && args.includes("{{.KernelVersion}}")) return { stdout: "fixture-kernel\n", stderr: "" };
        if (args[0] === "ps" && args.includes("-aq")) {
          const role = args.find(value => value.includes("label=openshell.ai/isolation-role="))?.split("=").at(-1);
          return { stdout: role === "supervisor" ? `${supervisorContainerId}\n` : `${containerId}\n`, stderr: "" };
        }
        if (args[0] === "inspect") return { stdout: JSON.stringify([dockerContainer(
          args[1] === supervisorContainerId ? "supervisor" : "sandbox")]), stderr: "" };
        if (args[0] === "update") {
          const option = (name: string) => args[args.indexOf(name) + 1];
          currentResource = { ...currentResource, NanoCpus: Math.round(Number(option("--cpus")) * 1e9),
            Memory: Number(option("--memory")), MemorySwap: Number(option("--memory-swap")), PidsLimit: Number(option("--pids-limit")) };
          return { stdout: "fixture update\n", stderr: "" };
        }
        if (args[0] === "exec") {
          const operation = args.slice(4).join(" ");
          if (operation.includes("/sys/fs/cgroup/cpu.max")) return { stdout: "100000 100000\n", stderr: "" };
          if (operation.includes("/sys/fs/cgroup/memory.max")) return { stdout: `${currentResource.Memory}\n`, stderr: "" };
          if (operation.includes("/sys/fs/cgroup/memory.swap.max")) return { stdout: `${currentResource.MemorySwap}\n`, stderr: "" };
          if (operation.includes("/sys/fs/cgroup/pids.max")) return { stdout: `${currentResource.PidsLimit}\n`, stderr: "" };
          if (operation.includes("/sys/fs/cgroup/memory.oom.group")) return { stdout: "0\n", stderr: "" };
          if (operation.includes("/usr/bin/stat")) return { stdout: "regular file:444\n", stderr: "" };
          if (operation.includes("/usr/bin/head")) return { stdout: "a", stderr: "" };
          if (operation.includes("/usr/bin/test")) return { stdout: "", stderr: "" };
          return { stdout: "", stderr: "" };
        }
        if (args[0] === "cp") {
          const destination = args.at(-1);
          if (typeof destination === "string") writeFileSync(destination, "fixture pinned runtime binary\\n", { mode: 0o600 });
          return { stdout: "", stderr: "" };
        }
        throw new Error(`fixture_docker_command_${args[0] ?? "missing"}`);
      }
      const command = args.slice(4);
      const operation = command[0] ?? "unknown";
      const isNamedOperation = ["sandbox", "profile", "policy", "provider"].includes(operation);
      const safeOperation = file === "docker" ? "docker:" + operation :
        operation + (isNamedOperation ? ":" + (command[1] ?? "unknown") : "");
      hostCliOperations.push(safeOperation);
      if (hostCliOperations.length > 96) hostCliOperations.shift();
      if (command[0] === "--version") return { stdout: "openshell 0.1.2\n", stderr: "" };
      if (command[0] === "profile" && command[1] === "describe") return { stdout: JSON.stringify(hostModelProfile), stderr: "" };
      if (command[0] === "sandbox" && command[1] === "list") return { stdout: JSON.stringify({
        sandboxes: [{ id: sandboxId, name: scopeNow().sandboxRef, workspace: "fixture-company", labels: {
          "aw.company_id": companyId, "aw.binding_id": binding.id, "aw.cell_id": cell.id,
          "aw.generation": cell.generation.toString(), ...currentProvisioning,
        } }], next_page_token: "" }), stderr: "" };
      if (command[0] === "sandbox" && command[1] === "get") return { stdout: JSON.stringify({
        id: sandboxId, name: scopeNow().sandboxRef, workspace: "fixture-company", phase: sandboxPhase,
        labels: { "aw.company_id": companyId, "aw.binding_id": binding.id, "aw.cell_id": cell.id,
          "aw.generation": cell.generation.toString(), ...currentProvisioning },
      }), stderr: "" };
      if (command[0] === "sandbox" && command[1] === "create") {
        const option = (name: string) => command[command.indexOf(name) + 1];
        sandboxId = randomUUID(); containerId = createHash("sha256").update(`fixture:${sandboxId}`).digest("hex");
        currentImageDigest = option("--from");
        const policyPath = option("--policy"); currentDocument = JSON.parse(readFileSync(policyPath, "utf8"));
        const resources = JSON.parse(option("--driver-config-json")).docker;
        currentResource = { NanoCpus: Math.round(Number(option("--cpu").slice(0, -1)) * 1e6),
          Memory: Number(option("--memory")), MemorySwap: Number(option("--memory")),
          PidsLimit: Number(resources.pids_limit), StorageOpt: { size: `${resources.disk_limit_bytes}B` } };
        currentProvisioning = Object.fromEntries(command.flatMap((value, index) => value === "--label"
          ? [command[index + 1].split(/=(.*)/s).slice(0, 2)] : []));
        currentWorkdir = currentDocument?.filesystem_policy?.read_write?.[0] ?? qualificationProbeFixture.filesystem.workdirPath;
        sandboxPhase = "Ready"; observedSandboxPhase = sandboxPhase;
        return { stdout: "{}", stderr: "" };
      }
      if (command[0] === "sandbox" && command[1] === "start") { sandboxPhase = "Ready"; observedSandboxPhase = sandboxPhase; return { stdout: "Started", stderr: "" }; }
      if (command[0] === "sandbox" && command[1] === "stop") { sandboxPhase = "Stopped"; observedSandboxPhase = sandboxPhase; return { stdout: "Stopped", stderr: "" }; }
      if (command[0] === "sandbox" && command[1] === "delete") { sandboxPhase = "Stopped"; observedSandboxPhase = sandboxPhase; return { stdout: "Deleted", stderr: "" }; }
      if (command[0] === "policy" && command[1] === "get") return { stdout: JSON.stringify({ sandbox: scopeNow().sandboxRef,
        status: "effective", version: policyRevision, config_revision: policyRevision,
        hash: nativeSha256(currentDocument), policy: currentDocument }), stderr: "" };
      if (command[0] === "policy" && command[1] === "set") {
        currentDocument = JSON.parse(readFileSync(command[command.indexOf("--policy") + 1], "utf8"));
        policyRevision += 1; return { stdout: "Policy updated", stderr: "" };
      }
      if (command[0] === "provider" && command[1] === "create") {
        const name = command[command.indexOf("--name") + 1], type = command[command.indexOf("--type") + 1];
        const env = command[command.indexOf("--credential") + 1];
        const credential = options.env?.[env] ?? null;
        const family = credential ? (verifyRuntimeToolsToken(credential, "worker_model") ? "worker_model" :
          verifyRuntimeToolsToken(credential, "conversation_model") ? "conversation_model" : null) : null;
        sessionProviders.set(name, { type, credential, expiresAt: null, family });
        return { stdout: "provider created", stderr: "" };
      }
      if (command[0] === "provider" && command[1] === "update") {
        const provider = sessionProviders.get(command[2]);
        const credentialArg = command.indexOf("--credential");
        const env = credentialArg >= 0 ? command[credentialArg + 1] : null;
        const expiryArg = command.indexOf("--credential-expires-at");
        const expiry = expiryArg >= 0 ? command[expiryArg + 1].slice(command[expiryArg + 1].indexOf("=") + 1) : null;
        if (provider) {
          if (env) provider.credential = options.env?.[env] ?? provider.credential;
          if (expiry) provider.expiresAt = expiry;
          sessionProviders.set(command[2], provider);
        }
        return { stdout: JSON.stringify(provider ?? {}), stderr: "" };
      }
      if (command[0] === "provider" && command[1] === "list") return { stdout: JSON.stringify({
        providers: [...sessionProviders.entries()].map(([name, provider]) => ({ name, type: provider.type,
          credential_expires_at: provider.expiresAt })), next_page_token: "" }), stderr: "" };
      if (command[0] === "provider" && command[1] === "delete") {
        sessionProviders.delete(command[2]); return { stdout: "provider deleted", stderr: "" };
      }
      if (command[0] === "sandbox" && command[1] === "provider" && command[2] === "attach") {
        attachedSessionProviders.add(command[4]); return { stdout: "{}", stderr: "" };
      }
      if (command[0] === "sandbox" && command[1] === "provider" && command[2] === "detach") {
        attachedSessionProviders.delete(command[4]);
        return { stdout: "{}", stderr: "" };
      }
      if (command[0] === "sandbox" && command[1] === "provider" && command[2] === "list")
        return { stdout: JSON.stringify({ providers: [...attachedSessionProviders].map(name => ({ name })), next_page_token: "" }), stderr: "" };
      if (command[0] === "sandbox" && command[1] === "exec") return { stdout: "", stderr: "" };
      throw new Error(`fixture_openshell_command_${command.slice(0, 2).join("_")}`);
    };
    const spawnSandboxWorkload = (_file: string, args: string[], options: { env?: NodeJS.ProcessEnv; cwd?: string;
      stdio?: unknown; shell?: boolean; windowsHide?: boolean }) => {
      const separator = args.indexOf("--");
      if (separator < 0) throw new Error("fixture_sandbox_exec_separator_missing");
      const cli = args.slice(4, separator);
      const workdirIndex = cli.indexOf("--workdir");
      const cwd = workdirIndex >= 0 ? cli[workdirIndex + 1] : input.root;
      const softwarePath = [...new Set([dirname(process.execPath), "/usr/local/bin", "/usr/bin", "/bin"])].join(":");
      const env: NodeJS.ProcessEnv = { PATH: softwarePath, HOME: providerImageHome ?? input.root };
      for (let index = 0; index < cli.length; index++) {
        if (cli[index] !== "--env") continue;
        const entry = cli[++index];
        if (typeof entry !== "string") throw new Error("fixture_sandbox_exec_env_missing");
        const split = entry.indexOf("=");
        if (split <= 0) throw new Error("fixture_sandbox_exec_env_invalid");
        env[entry.slice(0, split)] = entry.slice(split + 1);
      }
      const workload = args.slice(separator + 1);
      const requestedExecutable = workload[0];
      if (typeof requestedExecutable !== "string" || !requestedExecutable) throw new Error("fixture_sandbox_exec_argv_invalid");
      const fixtureExecutables: Record<string, string> = { sh: "/bin/sh", node: process.execPath,
        base64: "/usr/bin/base64", rm: "/usr/bin/rm" };
      const executable = fixtureExecutables[requestedExecutable] ?? requestedExecutable;
      if (!posix.isAbsolute(executable)) throw new Error("fixture_sandbox_exec_argv_invalid");
      // The production Host has already authorized argv. This software-only
      // adapter resolves the image's shell and Node from the trusted fixture
      // image, while the Host journal owns provider credentials and attachment.
      return spawn(executable, workload.slice(1), { cwd, env, shell: false, windowsHide: true,
        stdio: options.stdio as ["pipe", "pipe", "pipe"] });
    };
    sessionHostEngine = openShellHostEngine({ config: { executable,
      executableSha256: createHash("sha256").update(executableBytes).digest("hex"), stateHome,
      gateway: "fixture-gateway", workspace: "fixture-company", qualificationFixtures: qualificationProbeFixture },
      epoch: 1, root: hostRoot, run: hostRun, spawnProcess: spawnSandboxWorkload });
    const { fixtureHash: expectedFixtureHash, ...fixtureBody } = qualificationProbeFixture;
    assert.equal(expectedFixtureHash, nativeSha256(fixtureBody), "Host and credential echo qualification fixture must share the exact source hash");
    await sessionHostEngine.initialize();
  };
  const createBindingForRun=async(credentialBinding: typeof runtimeBrokerBinding)=>{
    binding = await service.create(actor, companyId, { runtimeCellId: cell.id,
    expectedCellGeneration: cell.generation.toString(), backend: "openshell", profile: "development", boundaryPolicy: (() => {
      const boundary = policyFixture(); boundary.riskClass = "C3"; boundary.requiredControls = [...conversationRequiredControls];
      // The durable maximum is confined to this company/Agent's server-owned
      // chat workspace namespace. Per-run compilation below narrows it again
      // to the exact canonical issue taskRoot before host admission.
      boundary.filesystem.readPaths = [taskWorkspaceNamespace];
      boundary.filesystem.writePaths = [taskWorkspaceNamespace];
      boundary.filesystem.deniedPaths = []; boundary.process.allowedBinaries = []; boundary.process.allowedSyscalls = [];
      boundary.network.destinations = []; boundary.credentials={mode:"brokered",bindings:[credentialBinding]}; return boundary;
    })() });
  const actualIdentity: SandboxIdentity = { ...identity, bindingId: binding.id, sandboxRef: binding.sandboxRef ?? `aw-v7-${binding.id}` };
  await db.update(runtimeCells).set({ providerBindingId }).where(eq(runtimeCells.id, cell.id));
  // Keep the original bridge identity pinned to the durable binding.
  identity.bindingId = binding.id;
  identity.sandboxRef = actualIdentity.sandboxRef;
  await initializeSessionHostEngine();

  };

  const workloadStates = state, workloadPolicies = policies;
  const completeHostCommand = async (commandId: string, raw: Parameters<typeof transport.complete>[2], metadata: { action: string; probeCaseId?: string }) => {
    try {
      return await transport.complete(host.id, commandId, raw);
    } catch (error) {
      const record = error && typeof error === "object" ? error as Record<string, unknown> : {};
      const issues = Array.isArray(record.issues) ? record.issues.slice(0, 20).map(issue => {
        const value = issue && typeof issue === "object" ? issue as Record<string, unknown> : {};
        return { code: typeof value.code === "string" ? value.code : "unknown",
          path: Array.isArray(value.path) ? value.path.map(part => typeof part === "string" || typeof part === "number" ? part : "?") : [] };
      }) : [];
      sandboxExecutionFailures.push({ phase: "host_completion_schema", action: metadata.action,
        ...(metadata.probeCaseId ? { probeCaseId: metadata.probeCaseId } : {}), issues });
      throw error;
    }
  };
  const driveHost = async <T>(work: Promise<T>): Promise<T> => {
    let settled = false;
    const result = work.then(value => ({ value }), error => ({ error })).then(value => { settled = true; return value; });
    const deadline = Date.now() + 30_000;
    while (!settled && Date.now() < deadline) {
      const claim = await transport.claim(host.id);
      if (!claim) { await new Promise(resolve => setTimeout(resolve, 2)); continue; }
      const secret = privateDecrypt({ key: hostKeys.privateKey, padding: constants.RSA_PKCS1_OAEP_PADDING, oaepHash: "sha256",
        oaepLabel: Buffer.from("aw-runtime-command-v6") }, Buffer.from(claim.envelope.encryptedKey, "base64url"));
      const command = unseal<Record<string, any>>(claim.envelope.ciphertext, secret.toString("hex"), `command:${claim.id}:${host.id}:1`);
      const action = command.action as string;
      const snapshot = capabilities(Boolean(command.cleanupAttestation));
      const common = { generation: command.scope.cellGeneration, imageDigest: command.imageDigest };
      const policyHash = typeof command.admission?.policyHash === "string" ? command.admission.policyHash : "";
      let reply: Record<string, any>;
      if (action === "capabilities") reply = { action, capabilities: snapshot };
      else if (action === "prepare" && command.provisioning) {
        const provisioning = command.provisioning as Record<string, any>;
        if(provisioning.purpose === "qualification"){
          if(provisioning.probeFixtureHash !== qualificationProbeFixture.fixtureHash || nativeSha256(provisioning.qualificationProbeFixture) !== nativeSha256(qualificationProbeFixture) ||
            nativeSha256(provisioning.document) !== projectedQualification.documentHash || provisioning.policyHash !== projectedQualification.documentHash)
            throw new Error("conversation_software_host_protected_qualification_provisioning_mismatch");
        }else if(provisioning.purpose !== "admission" || !protectedQualificationTarget)
          throw new Error("conversation_software_host_protected_admission_provisioning_mismatch");
        const targetBase = {
          hostEpoch: command.hostEpoch, companyId: command.scope.companyId, bindingId: command.scope.bindingId,
          bindingVersion: provisioning.bindingVersion, cellId: command.scope.cellId,
          cellGeneration: command.scope.cellGeneration, sandboxRef: command.scope.sandboxRef,
          sandboxId: randomUUID(), containerId:nativeSha256({hostId:host.id,commandId:claim.id,kind:"software-container"}), imageDigest: command.imageDigest,
          hostKernelVersion: "controlled-software-host",
          runtimeBinarySha256:createHashHex(readFileSync(new URL("../../../../deploy/v6/host-agent/index.mjs",import.meta.url))),
          openshellCliSha256:createHashHex(readFileSync(new URL("../../../../deploy/v6/host-agent/openshell.mjs",import.meta.url))),
          dockerEngineIdHash:nativeSha256({kind:"controlled-software-host",hostId:host.id}),
          policyHash: provisioning.policyHash, provisioningHash: provisioning.provisioningHash,
          resourceLimits: provisioning.resourceLimits, policyVersion: 1, configRevision: "conversation-software-host-v1",
          phase:provisioning.purpose === "qualification" ? "Ready" : "Stopped", mechanism: "openshell_create_sandbox_v0.1.2",
          probePolicyHash:nativeSha256(provisioning.document),probeFixtureHash:provisioning.probeFixtureHash ?? protectedQualificationTarget?.probeFixtureHash,
          qualificationCredentialFixture,
        };
        protectedQualificationTarget = { ...targetBase, targetHash: nativeSha256(targetBase) };
        if(provisioning.purpose === "qualification"){
          for(const test of sandboxProbeCases(provisioning.policyHash,conversationRequiredControls).filter(test=>test.control !== "credentialBrokering")){
            const observed=await observeSoftwareBoundary(test);assert.equal(observed.verdict,"pass");
          }
          capabilityTestedAt=new Date(Date.now()-1000).toISOString();capabilityExpiresAt=new Date(Date.now()+150_000).toISOString();
        }
        reply = { action, backendVersion: "0.1.2", imageDigest: command.imageDigest, hostEpoch: command.hostEpoch,
          sandboxId: protectedQualificationTarget.sandboxId, containerId: protectedQualificationTarget.containerId,
          provisioningHash: provisioning.provisioningHash, bindingVersion: provisioning.bindingVersion,
          policyHash: provisioning.policyHash, probePolicyHash: nativeSha256(provisioning.document),
          resourceLimits: provisioning.resourceLimits, requiresRecreate: false };
      } else if (action === "prepare") reply = { action, backendVersion: "0.1.2", imageDigest };
      else if(action === "probe"){
        if(command.probe.qualificationCredentialCapability){
          const test=command.probe,fixture=qualificationCredentialFixture,tool=test.caseId === "credential_wrong_destination_deny" ? fixture.wrongToolName : fixture.toolName;
          const persisted=await db.select({payload:runtimeHostCommands.payload}).from(runtimeHostCommands).where(eq(runtimeHostCommands.id,claim.id));
          const serializedPayload=JSON.stringify(persisted[0]?.payload);
          assert.ok(!serializedPayload.includes(test.qualificationCredentialCapability));assert.ok(!serializedPayload.includes(test.qualificationCredentialNonce));
          const call=request(qualificationProtocolApp).post(`/mcp/gateways/${fixture.gatewayPublicId}`);
          if(test.caseId !== "credential_wrong_binary_deny")call.set("Authorization",`Bearer ${test.qualificationCredentialCapability}`);
          const body={jsonrpc:"2.0",id:claim.id,method:"tools/call",params:{name:tool,arguments:{fixtureId:fixture.fixtureId,caseId:test.caseId,nonce:test.qualificationCredentialNonce}}};
          const response=await call.send(body),reasonCode=response.body?.error?.data?.reasonCode ?? null,marker=response.body?.result?.structuredContent?.marker ?? null;
          const serialized=JSON.stringify(response.body);
          for(const value of [canarySecretValue,runtimeSecretValue,test.qualificationCredentialCapability,"qualification-provider-output-sentinel"])assert.ok(!serialized.includes(value));
          if(response.status === 200){assert.deepEqual(response.body.result.content,[{type:"text",text:fixture.marker}]);assert.deepEqual(response.body.result.structuredContent,{marker:fixture.marker});}
          let replayDenied:boolean|undefined;
          if(test.caseId === "credential_allow"){
            const replay=await request(qualificationProtocolApp).post(`/mcp/gateways/${fixture.gatewayPublicId}`)
              .set("Authorization",`Bearer ${test.qualificationCredentialCapability}`).send(body);
            replayDenied=replay.status === 409 && JSON.stringify(replay.body).includes("sandbox_qualification_capability_replayed");assert.ok(replayDenied);
          }
          const passed=test.caseId === "credential_allow" || test.caseId === "credential_raw_read_deny" ? response.status === 200 && marker === fixture.marker
            : test.caseId === "credential_wrong_destination_deny" ? response.status === 403 && reasonCode === "sandbox_qualification_tool_mismatch"
            : test.caseId === "credential_wrong_binary_deny" ? response.status === 401 && reasonCode === "sandbox_qualification_credential_required"
            : test.caseId === "credential_revoke_deny" && response.status === 403 && reasonCode === "sandbox_qualification_grant_revoked";
          qualificationToolResponses.push({caseId:test.caseId,status:response.status,reasonCode,marker,...(replayDenied !== undefined ? {replayDenied} : {})});
          reply={action,verdict:passed ? "pass" : "fail",observationHash:nativeSha256({caseId:test.caseId,status:response.status,reasonCode,marker}),contractHash:test.contractHash,targetQualificationHash:protectedQualificationTarget?.targetHash};
        }else reply=await observeSoftwareBoundary(command.probe);
      }
      else if (action === "inspect") reply = { action, ...common, state: workloadStates.get(command.scope.cellId) ?? "stopped", policyHash: workloadPolicies.get(command.scope.cellId) ?? null, controlsHealthy: true };
      else if (action === "apply") { workloadStates.set(command.scope.cellId, "ready"); workloadPolicies.set(command.scope.cellId, command.admission.policyHash); reply = { action, applied: true, requiresRecreate: false, policyHash: command.admission.policyHash, effectivePolicyHash: command.admission.policyHash }; }
      else if (action === "start") { workloadStates.set(command.scope.cellId, "running"); workloadPolicies.set(command.scope.cellId, command.start.policyHash); reply = { action, started: true, operationId: claim.id, sandboxId:protectedQualificationTarget?.sandboxId,containerId:protectedQualificationTarget?.containerId,imageDigest,policyHash:command.start.policyHash, effectivePolicyHash: command.start.policyHash }; }
      else if (action === "stop") { workloadStates.set(command.scope.cellId, "stopped"); reply = { action, stopped: true }; }
      else if (action === "revoke_providers") reply = { action, revoked: true };
      else if (action === "destroy") reply = { action, destroyed: true };
      else reply = { action, document: projectOpenShellPolicy(policyFixture()).document, policyHash };
      const needsEngineReceipt = sessionHostEngine && (
        (action === "prepare" && command.provisioning) ||
        (action === "capabilities" && snapshot?.qualificationTarget) ||
        action === "apply" || action === "start");
      if (needsEngineReceipt) {
        const now = Date.now();
        const deadlines = [command.deadlineAt, command.provisioning?.expiresAt,
          command.admission?.expiresAt, command.start?.expiresAt]
          .map(value => typeof value === "string" ? Date.parse(value) : Number.NaN)
          .filter(value => Number.isFinite(value));
        const hostDeadlineAt = new Date(Math.min(now + 30_000, ...deadlines)).toISOString();
        const observed = await sessionHostEngine.execute(claim.id, command, hostDeadlineAt);
        if (!observed.success) {
          const errorCode = typeof observed.errorCode === "string" && /^[a-z][a-z0-9_:-]{0,99}$/.test(observed.errorCode)
            ? observed.errorCode : "sandbox_host_unavailable";
          const allowedRequestKeys = ["version", "scope", "action", "hostEpoch", "imageDigest", "requesterUserId",
            "probe", "admission", "start", "provisioning", "cleanupAttestation", "claimToken"].sort();
          const requestKeys = Object.keys(command).sort();
          const provision = command.provisioning && typeof command.provisioning === "object" ? command.provisioning : {};
          sandboxExecutionFailures.push({ phase: "host_engine_receipt", action, errorCode,
            hostCliOperations: [...hostCliOperations],
            requestFacts: {
              versionOne: command.version === 1,
              allowedRequestKeysOnly: requestKeys.every(key => allowedRequestKeys.includes(key)),
              scopeKeysExact: Object.keys(command.scope ?? {}).sort().join(",") === "bindingId,cellGeneration,cellId,companyId,sandboxRef",
              scopeMatchesHost: command.scope?.companyId === companyId && command.scope?.bindingId === binding.id &&
                command.scope?.cellId === cell.id && command.scope?.cellGeneration === cell.generation.toString(),
              epochOne: command.hostEpoch === 1,
              requesterPresent: typeof command.requesterUserId === "string" && command.requesterUserId.length > 0,
              imageDigestWellFormed: typeof command.imageDigest === "string" &&
                /^[a-z0-9./:_-]+@sha256:[a-f0-9]{64}$/.test(command.imageDigest),
              provisioningPresent: Boolean(command.provisioning),
              qualificationFixtureHashMatches: provision.probeFixtureHash === qualificationProbeFixture.fixtureHash,
              qualificationFixtureBodyMatches: nativeSha256(provision.qualificationProbeFixture) === nativeSha256(qualificationProbeFixture),
              policyDocumentHashMatches: typeof provision.document === "object" && nativeSha256(provision.document) === provision.policyHash,
              projectedQualificationPolicyMatches: provision.policyHash === projectedQualification.documentHash,
            } });
          await completeHostCommand(claim.id, { claimToken: command.claimToken,
            generation: command.scope.cellGeneration, success: false, reply: null, errorCode },
            { action, ...(command.probe?.caseId ? { probeCaseId: command.probe.caseId } : {}) });
          continue;
        }
      }
      await completeHostCommand(claim.id, { claimToken: command.claimToken, generation: command.scope.cellGeneration,
        success: true, reply, errorCode: null }, { action, ...(command.probe?.caseId ? { probeCaseId: command.probe.caseId } : {}) });
    }
    if (!settled) throw new Error("conversation_software_host_command_timeout");
    const output = await result;
    if ("error" in output) throw output.error;
    return output.value;
  };
  let qualificationEvidence:Record<string,unknown>|null=null;
  const qualifyHost=async()=>{
  const qualification = await driveHost(service.qualify(actor, companyId, binding.id, 1));
    const [report] = qualification.qualificationRunId ? await db.select({ status: sandboxQualificationRuns.status,
      suiteVersion: sandboxQualificationRuns.suiteVersion, evidenceKind: sandboxQualificationRuns.evidenceKind,
      results: sandboxQualificationRuns.results, exceptions: sandboxQualificationRuns.exceptions })
      .from(sandboxQualificationRuns).where(eq(sandboxQualificationRuns.id, qualification.qualificationRunId)).limit(1) : [];
    const results = Array.isArray(report?.results) ? report.results.map(result => ({
      caseId: result.caseId, control: result.control, verdict: result.verdict,
      observationHashPresent: typeof result.observationHash === "string" && /^[a-f0-9]{64}$/.test(result.observationHash),
    })) : [];
    const exceptions = Array.isArray(report?.exceptions) ? report.exceptions.filter((value): value is string =>
      typeof value === "string" && /^[a-z0-9_:-]{1,100}$/.test(value)).slice(0, 32) : [];
    qualificationEvidence={bindingStatus:qualification.status,reportStatus:report?.status ?? null,suiteVersion:report?.suiteVersion ?? null,
      evidenceKind:report?.evidenceKind ?? null,results,exceptions};
    if(process.env.PAPERCLIP_NATIVE_SOURCE_CLOSURE_DIAGNOSTICS === "1")console.info("conversation_software_host_qualification",JSON.stringify(qualificationEvidence));
    if(qualification.status !== "ready")throw new Error("conversation_software_host_qualification_failed");
    assert.equal(results.length,19);assert.equal(new Set(results.map(result=>result.caseId)).size,19);
    assert.ok(results.every(result=>result.verdict === "pass" && result.observationHashPresent));
    const [canaryState]=await db.select({status:connectionGrants.status}).from(connectionGrants).where(eq(connectionGrants.id,canary.grant.id));
    const [runtimeState]=await db.select({status:connectionGrants.status}).from(connectionGrants).where(eq(connectionGrants.id,runtimeConnection.grant.id));
    assert.equal(canaryState?.status,"revoked");assert.equal(runtimeState?.status,"active");
    assert.equal(qualificationToolResponses.length,5);
  };
  let expectedRunId: string | null = null;
  let expectedIssueId: string | null = null;
  let expectedTaskRoot: string | null = null;
  let acquiredLeaseExpiresAt: string | null = null;
  let preAdmissionObservation: { state: string; generationMatches: boolean; imageDigestMatches: boolean; controlsHealthy: boolean } | null = null;
  let prepareHostForRun: ((runId: string, leaseId: string) => Promise<void>) | null = null;
  let providerImageHome: string | null = null;
  const hostAdmissionByRun = new Map<string, { leaseId: string; promise: Promise<void> }>();
  const sandboxExecutionChecks: Array<Record<string, boolean | number | string | null>> = [];
  const sandboxExecutionFailures: Array<Record<string, unknown>> = [];
  let sandboxExecInvocationSequence = 0;
  let preparationStage="not_started";
  let negativeAdmissionControls: {wrongRunDenied:boolean;wrongLeaseDenied:boolean;wrongCwdDenied:boolean;wrongPolicyDenied:boolean}|null=null;
  let negativeNativeSessionStartControls: { wrongCommandDenied: boolean; wrongRootDenied: boolean; noExecution: boolean } | null = null;
  const executeSandboxTask: typeof runtime.executeSandboxTask = async execInput => {
    if (!execInput.runId || !execInput.leaseId || !prepareHostForRun)
      throw new Error("conversation_software_host_run_binding_unavailable");
    await heartbeatHost();
    // The first runtime command is workspace preparation, before the Native
    // provider callback. Admit the same real manifest-bound host here, at the
    // original RuntimeControl execution seam, before delegating its signed exec.
    await prepareHostForRun(execInput.runId, execInput.leaseId);
    const commandName = execInput.command.toLowerCase().split("/").at(-1) ?? "";
    const args = execInput.args ?? [];
    const runnerLaunch = commandName === "sh" && args[2] === "paperclip-runner-launch";
    if (execInput.runId && (sandboxExecutionChecks.length < 8 || runnerLaunch)) {
      const [run] = await db.select({ status: heartbeatRuns.status, startedAt: heartbeatRuns.startedAt,
        agentId: heartbeatRuns.agentId, nativeIssueId: heartbeatRuns.nativeIssueId,
        responsibleUserId: heartbeatRuns.responsibleUserId, runtimeMode: heartbeatRuns.runtimeMode,
        contextSnapshot: heartbeatRuns.contextSnapshot, resultJson: heartbeatRuns.resultJson })
        .from(heartbeatRuns).where(and(eq(heartbeatRuns.companyId, companyId), eq(heartbeatRuns.id, execInput.runId))).limit(1);
      const runContext = run?.contextSnapshot && typeof run.contextSnapshot === "object"
        ? run.contextSnapshot as Record<string, unknown> : {};
      const contextIssueId = typeof runContext.issueId === "string" ? runContext.issueId : null;
      const [contextIssue] = contextIssueId ? await db.select({ conversationAgentId: issues.conversationAgentId,
        conversationUserId: issues.conversationUserId, executionRunId: issues.executionRunId,
        conversationSessionGeneration: issues.conversationSessionGeneration }).from(issues)
        .where(and(eq(issues.companyId, companyId), eq(issues.id, contextIssueId))).limit(1) : [];
      const [lease] = await db.select({ status: environmentLeases.status, expiresAt: environmentLeases.expiresAt,
        heartbeatRunId: environmentLeases.heartbeatRunId }).from(environmentLeases)
        .where(and(eq(environmentLeases.companyId, companyId), eq(environmentLeases.id, execInput.leaseId))).limit(1);
      const cancellation = run?.resultJson?.executionCancellation;
      const cancellationRequested = Boolean(cancellation && typeof cancellation === "object" &&
        "state" in cancellation && cancellation.state === "requested");
      const commandKind = commandName.includes("opencode") ? "opencode" : commandName.includes("runner") ? "runner" :
        commandName.includes("rsync") ? "rsync" : commandName === "git" ? "git" :
          commandName === "bash" ? "bash" : commandName === "sh" ? "shell" :
            commandName === "tar" ? "tar" : commandName === "node" ? "node" : "other";
      const commandScript = args[1] ?? "";
      const commandOwner = runnerLaunch ? "runner_process_launch" : args[2] === "paperclip-runner-monitor"
        ? "runner_process_monitor" : args[2] === "paperclip-runner-process-identity"
          ? "runner_process_identity_read" : args[2] === "paperclip-runner-diagnostics"
            ? "runner_diagnostic_tail" : commandScript.startsWith("command -v ")
              ? "managed_runtime_install_probe" : commandScript.startsWith("mkdir -p ")
                ? "managed_runtime_directory_prepare" : commandScript.startsWith("umask 077; install -d -m 0700 ")
                  ? "runner_harness_directory_prepare" : commandScript.includes("runner-state.json") && commandScript.includes("base64 <")
                    ? "runner_harness_state_read" : commandScript.includes("base64 -d")
                      ? "managed_runtime_file_transfer" : commandScript.includes("tar -xf")
                        ? "managed_runtime_archive_extract" : commandScript.startsWith("rm -rf ")
                          ? "managed_runtime_remove" : commandScript.startsWith("chmod ")
                            ? "managed_runtime_permissions" : commandScript.startsWith("test -")
                              ? "managed_runtime_path_probe" : commandScript.startsWith("if ")
                                ? "managed_runtime_listing" : commandScript.startsWith("set ")
                                  ? "managed_runtime_sync" : "other";
      const managedGitContextProbe = commandName === "sh" && args[0] === "-c" && args[2] === "paperclip-git-context" &&
        (args[3] === "managed" || args[3] === "host");
      const unstartedSessionClaimProbe = commandName === "sh" && args[0] === "-c" && args[2] === "paperclip-runner-claim-unstarted-session";
      const credentialEnvNames = Object.keys(execInput.env ?? {})
        .filter(name => /(?:TOKEN|SECRET|PASSWORD|CREDENTIAL|API[_-]?KEY|PRIVATE[_-]?KEY|AUTHORIZATION)/i.test(name))
        .sort().slice(0, 16).join(",");
      const nativePreparationPurpose = execInput.nativePreparationPurpose ?? null;
      sandboxExecutionChecks.push({ expectedRun: execInput.runId === expectedRunId,
        commandKind, commandOwner, stdinBytes: Buffer.byteLength(execInput.stdin ?? "", "utf8"),
        cwdAbsolute: Boolean(execInput.cwd?.startsWith("/")), argumentCount: (execInput.args ?? []).length,
        runnerLaunch,
        nativePreparationPurpose,
        managedGitContextProbe, unstartedSessionClaimProbe, credentialEnvNames,
        runtimeMode: run?.runtimeMode ?? null, runStatus: run?.status ?? null, runStatusRunning: run?.status === "running",
        startedAtPresent: Boolean(run?.startedAt), agentIdPresent: Boolean(run?.agentId),
        nativeIssueIdPresent: Boolean(run?.nativeIssueId), responsibleUserIdPresent: Boolean(run?.responsibleUserId),
        cancellationRequested, leaseActiveForRun: lease?.status === "active" && lease.heartbeatRunId === execInput.runId,
        leaseExpiryPresent: Boolean(lease?.expiresAt), leaseUnexpired: Boolean(lease?.expiresAt && lease.expiresAt > new Date()),
        contextIssuePresent: Boolean(contextIssueId), contextWakeCommentPresent: typeof runContext.wakeCommentId === "string",
        contextConversationOwnerMatches: contextIssue?.conversationAgentId === agentId && contextIssue?.conversationUserId === actor.userId,
        contextIssueGenerationPresent: contextIssue?.conversationSessionGeneration !== null && contextIssue?.conversationSessionGeneration !== undefined,
        contextIssueExecutionRunMatches: contextIssue?.executionRunId === execInput.runId,
        nativeIssueMatchesContext: Boolean(run?.nativeIssueId && contextIssueId && run.nativeIssueId === contextIssueId) });
    }
    const commandKey = commandDigest(execInput.command, execInput.args ?? []);
    const purposeQueue = purposesByCommandDigest.get(commandKey) ?? [];
    purposeQueue.push(execInput.nativePreparationPurpose ?? null);
    purposesByCommandDigest.set(commandKey, purposeQueue);
    const sandboxExecSequence = ++sandboxExecInvocationSequence;
    const sandboxExecStartedAt = new Date();
    try {
      // Keep the controlled signed host fresh under the long OpenCode prep
      // sequence; the periodic timer alone can be delayed by a busy test loop.
      await heartbeatHost();
      const result = await runtime.executeSandboxTask(execInput);
      if (!result) return null;
      if ((runnerLaunch || result.exitCode === 126 || result.timedOut) &&
          sandboxExecutionFailures.length < 16 && (result.exitCode !== 0 || result.timedOut)) {
        sandboxExecutionFailures.push({
          commandKind: commandName.includes("runner") ? "runner" : commandName === "sh" ? "shell" : "other",
          runnerLaunch,
          nativePreparationPurpose: execInput.nativePreparationPurpose ?? null,
          exitCode: result.exitCode,
          timedOut: result.timedOut,
        });
      }
      return result;
    } catch (error) {
      if ((runnerLaunch || sandboxExecutionFailures.length < 16) && sandboxExecutionFailures.length < 16) {
        let runtimeAssetDiagnostics:unknown[]|null=null;
        if(execInput.runId && safeErrorSourceFrames(error).some(frame=>frame.functionName?.includes("assertNativeDocumentRuntimeSkillCurrent"))){
          try{
            const [currentRun]=await db.select({profile:heartbeatRuns.runnerProfileJson}).from(heartbeatRuns).where(and(
              eq(heartbeatRuns.companyId,companyId),eq(heartbeatRuns.id,execInput.runId),eq(heartbeatRuns.agentId,agentId)));
            const profile=currentRun?.profile as Record<string,unknown>|undefined;
            const execution=profile?.nativeExecutionInput as {runtimeContext?:{skills?:Array<{key:string;bundle:Parameters<typeof readNativeRuntimeAssetText>[0]}>}}|undefined;
            runtimeAssetDiagnostics=[];
            for(const skill of execution?.runtimeContext?.skills ?? []){
              const bundle=skill.bundle;let failureCode:string|null=null;
              try{await readNativeRuntimeAssetText(bundle,256000,{companyId,runId:execInput.runId});}
              catch(failure){
                const message=failure instanceof Error ? failure.message : "";
                const code=failure && typeof failure === "object" ? (failure as {code?:unknown}).code : null;
                failureCode=/^native_text_asset_[a-z_]+$/.test(message) ? message
                  :typeof code === "string" && /^[A-Z0-9_]{1,80}$/.test(code) ? code
                  :message.startsWith("runtime context asset digest mismatch") ? "runtime_asset_digest_mismatch"
                  :failure instanceof Error ? failure.name : "unknown";
              }
              runtimeAssetDiagnostics.push({key:skill.key,totalBytes:bundle.totalBytes,fileCount:bundle.fileCount,digest:bundle.digest,
                ownerRootMatch:bundle.rootPath === join(nativeRuntimeAssetsRoot({companyId,runId:execInput.runId}),"bundles",bundle.digest),failureCode});
            }
            console.info("conversation_software_host_runtime_asset_diagnostic",JSON.stringify(runtimeAssetDiagnostics));
          }catch{/* source diagnostics must preserve the original failure */}
        }
        const rawCode = error && typeof error === "object" && "code" in error ? error.code : null;
        const requestFacts = relayRequestFactsForError(error);
        let claim: { status: string; errorCode: string | null; commandDigest: string | null;
          nativePreparationPurpose: string | null; requestId: string; createdAt: Date } | undefined;
        let unresolvedClaims: Array<{ requestId: string; status: string; errorCode: string | null;
          commandDigest: string | null; nativePreparationPurpose: string | null; attempt: number; createdAt: Date }> = [];
        if (requestFacts) {
          try {
            [claim] = await db.select({
              requestId: runtimeHostCommands.idempotencyKey,
              status: runtimeHostCommands.status,
              errorCode: runtimeHostCommands.errorCode,
              commandDigest: sql<string | null>`${runtimeHostCommands.payload}->>'commandDigest'`,
              nativePreparationPurpose: sql<string | null>`${runtimeHostCommands.payload}->>'nativePreparationPurpose'`,
              createdAt: runtimeHostCommands.createdAt,
            }).from(runtimeHostCommands).where(and(
              eq(runtimeHostCommands.idempotencyKey, requestFacts.requestId),
              eq(runtimeHostCommands.commandType, "sandbox_exec"),
            )).limit(1);
          } catch { /* diagnostics never replace the original sandbox error */ }
        }
        if (!claim && execInput.runId) {
          try {
            [claim] = await db.select({
              requestId: runtimeHostCommands.idempotencyKey,
              status: runtimeHostCommands.status,
              errorCode: runtimeHostCommands.errorCode,
              commandDigest: sql<string | null>`${runtimeHostCommands.payload}->>'commandDigest'`,
              nativePreparationPurpose: sql<string | null>`${runtimeHostCommands.payload}->>'nativePreparationPurpose'`,
              createdAt: runtimeHostCommands.createdAt,
            }).from(runtimeHostCommands).where(and(
              eq(runtimeHostCommands.commandType, "sandbox_exec"),
              sql`${runtimeHostCommands.payload}->>'runId' = ${execInput.runId}`,
              sql`${runtimeHostCommands.payload}->>'nativePreparationPurpose' = ${execInput.nativePreparationPurpose ?? null}`,
              gte(runtimeHostCommands.createdAt, sandboxExecStartedAt),
            )).orderBy(desc(runtimeHostCommands.createdAt)).limit(1);
          } catch { /* diagnostics never replace the original sandbox error */ }
        }
        if (execInput.runId) {
          try {
            unresolvedClaims = await db.select({
              requestId: runtimeHostCommands.idempotencyKey,
              status: runtimeHostCommands.status,
              errorCode: runtimeHostCommands.errorCode,
              commandDigest: sql<string | null>`${runtimeHostCommands.payload}->>'commandDigest'`,
              nativePreparationPurpose: sql<string | null>`${runtimeHostCommands.payload}->>'nativePreparationPurpose'`,
              attempt: runtimeHostCommands.attempt,
              createdAt: runtimeHostCommands.createdAt,
            }).from(runtimeHostCommands).where(and(
              eq(runtimeHostCommands.companyId, companyId),
              eq(runtimeHostCommands.commandType, "sandbox_exec"),
              sql`${runtimeHostCommands.payload}->>'runId' = ${execInput.runId}`,
              inArray(runtimeHostCommands.status, ["PENDING", "CLAIMED"]),
            )).orderBy(desc(runtimeHostCommands.createdAt)).limit(8);
          } catch { /* diagnostics never replace the original sandbox error */ }
        }
        sandboxExecutionFailures.push({
          commandKind: commandName.includes("runner") ? "runner" : commandName === "sh" ? "shell" : "other",
          runnerLaunch,
          nativePreparationPurpose: execInput.nativePreparationPurpose ?? null,
          failureClass: safeSandboxFailureClass(error),
          requestAssociationSource: requestFacts ? "signed_relay_request" : claim ? "persisted_command_claim" : "pre_claim_error",
          requestSequence: requestFacts?.sequence ?? sandboxExecSequence,
          requestId: requestFacts?.requestId ?? claim?.requestId ?? null,
          requestDigest: requestFacts?.requestDigest ?? claim?.commandDigest ?? null,
          harnessCommandDigest: requestFacts?.harnessCommandDigest ?? commandKey,
          claimStatus: claim?.status ?? null,
          claimErrorCode: claim?.errorCode ?? null,
          claimCommandDigest: claim?.commandDigest ?? null,
          claimNativePreparationPurpose: claim?.nativePreparationPurpose ?? null,
          claimAgeMs: claim ? Math.max(0, Date.now() - claim.createdAt.getTime()) : null,
          unresolvedClaims: unresolvedClaims.map(row => ({ requestId: row.requestId, status: row.status,
            errorCode: row.errorCode, commandDigest: row.commandDigest,
            nativePreparationPurpose: row.nativePreparationPurpose, attempt: row.attempt,
            ageMs: Math.max(0, Date.now() - row.createdAt.getTime()),
            relayCommandOwner: relayCommandOwnerByRequestId.get(row.requestId) ?? null })),
          argumentCount: (execInput.args ?? []).length,
          monitorLabelPresent: (execInput.args ?? []).includes("paperclip-runner-monitor"),
          monitorScriptPrefix: (execInput.args?.[1] ?? "").startsWith("set -eu; identity_path=$1;"),
          errorName: error instanceof Error && ["Error", "HttpError", "TypeError"].includes(error.name) ? error.name : "other",
          errorCode: typeof rawCode === "string" && /^[a-z0-9_:-]{1,100}$/i.test(rawCode) ? rawCode : null,
          errorSourceFrames: safeErrorSourceFrames(error),runtimeAssetDiagnostics,
          nativePreReceiptFailedChecks: safeNativePreReceiptFailedChecks(error),
        });
      }
      throw error;
    } finally {
      if (purposeQueue.length === 0) purposesByCommandDigest.delete(commandKey);
    }
  };
  const environmentRuntime = environmentRuntimeService(db, { executeSandboxTask });
  const relayServer = createServer(); runtime.relay.attach(relayServer);
  relayServer.listen(0, "127.0.0.1"); await once(relayServer, "listening");
  await runtime.relay.listen(0);
  const relayAddress = relayServer.address();
  if (!relayAddress || typeof relayAddress === "string") throw new Error("conversation_software_host_relay_listen_failed");
  const relayHost = new WebSocket(`ws://127.0.0.1:${relayAddress.port}/api/internal/runtime/relay`);
  await once(relayHost, "open");
  const proof = signedRelayProof(host.id, hostKeys.privateKey); relayHost.send(JSON.stringify({ type: "hello", proof: proof.proof }));
  let authenticated = false;
  for (let i = 0; i < 150; i++) {
    const [nonce] = await db.select({ nonce: runtimeHostRequestNonces.nonce }).from(runtimeHostRequestNonces)
      .where(eq(runtimeHostRequestNonces.nonce, proof.nonce)).limit(1);
    if (nonce) { authenticated = true; break; }
    await new Promise(resolve => setTimeout(resolve, 10));
  }
  if (!authenticated) throw new Error("conversation_software_host_relay_auth_failed");
  let hostHeartbeatCount = 0;
  let hostHeartbeatFailed = false;
  let hostHeartbeatInFlight: Promise<void> | null = null;
  const postgresLockSnapshots: Array<Record<string, unknown>> = [];
  let postgresLockProbeInFlight = false;
  const probePostgresLocks = async () => {
    if (process.env.PAPERCLIP_RUNTIME_LOCK_DIAGNOSTICS !== "1" || postgresLockProbeInFlight || postgresLockSnapshots.length >= 20) return;
    postgresLockProbeInFlight = true;
    try {
      const [sample] = await db.execute(sql`
        select coalesce(json_agg(json_build_object(
          'pid', activity.pid,
          'applicationName', left(regexp_replace(coalesce(activity.application_name, ''), '[^A-Za-z0-9_.-]', '', 'g'), 64),
          'state', activity.state,
          'waitEventType', activity.wait_event_type,
          'waitEvent', activity.wait_event,
          'xactAgeMs', case when activity.xact_start is null then null
            else greatest(0, (extract(epoch from clock_timestamp() - activity.xact_start) * 1000)::int) end,
          'queryAgeMs', case when activity.query_start is null then null
            else greatest(0, (extract(epoch from clock_timestamp() - activity.query_start) * 1000)::int) end,
          'queryKind', case when activity.query ilike '%pg_advisory_%lock%' then 'advisory_lock'
            when activity.query ilike '%heartbeat_runs%' then 'heartbeat_runs'
            when activity.query ilike '%native_run_finalizations%' then 'native_run_finalizations'
            when activity.query ilike '%runtime_host_commands%' then 'runtime_host_commands'
            when activity.query ilike '%context_manifests%' then 'context_manifests'
            when activity.query ilike '%memory_records%' then 'memory_records'
            else lower(split_part(activity.query, ' ', 1)) end,
          'blockedBy', pg_blocking_pids(activity.pid),
          'locks', (select coalesce(json_agg(json_build_object(
              'lockType', lock.locktype, 'mode', lock.mode, 'granted', lock.granted,
              'classId', case when lock.locktype = 'advisory' then lock.classid::bigint else null end,
              'objectId', case when lock.locktype = 'advisory' then lock.objid::bigint else null end,
              'objectSubId', case when lock.locktype = 'advisory' then lock.objsubid else null end,
              'lockPurpose', case
                when lock.locktype = 'advisory' and lock.objsubid = 1 and
                  lock.classid::bigint = ((hashtextextended(${`business-events:${companyId}`}, 0) >> 32) & 4294967295) and
                  lock.objid::bigint = (hashtextextended(${`business-events:${companyId}`}, 0) & 4294967295)
                  then 'business_events_privacy'
                when lock.locktype = 'advisory' and lock.objsubid = 1 and
                  lock.classid::bigint = ((hashtextextended(${`memory:privacy:${companyId}`}, 0) >> 32) & 4294967295) and
                  lock.objid::bigint = (hashtextextended(${`memory:privacy:${companyId}`}, 0) & 4294967295)
                  then 'memory_privacy'
                else null end,
              'relation', case when lock.relation is null then null else lock.relation::regclass::text end,
              'transactionId', lock.transactionid)), '[]'::json)
            from pg_locks lock where lock.pid = activity.pid and
              (lock.locktype in ('advisory', 'transactionid') or lock.relation = 'heartbeat_runs'::regclass))
        ) order by activity.xact_start asc nulls last), '[]'::json) as sessions
        from pg_stat_activity activity
        where activity.datname = current_database() and activity.pid <> pg_backend_pid()
          and (cardinality(pg_blocking_pids(activity.pid)) > 0 or activity.pid = any(
            select unnest(pg_blocking_pids(waiter.pid)) from pg_stat_activity waiter
            where waiter.datname = current_database() and waiter.pid <> pg_backend_pid()
              and cardinality(pg_blocking_pids(waiter.pid)) > 0
          ) or (activity.xact_start < clock_timestamp() - interval '2 seconds' and exists (
            select 1 from pg_locks held where held.pid = activity.pid and held.relation = 'heartbeat_runs'::regclass
          )))
      `) as unknown as Array<{ sessions: unknown }>;
      const sessions = sample?.sessions;
      if (Array.isArray(sessions) && sessions.length > 0 && postgresLockSnapshots.length < 20)
        postgresLockSnapshots.push({ at: new Date().toISOString(), sessions });
    } catch {
      // The bounded diagnostic must never alter or mask runtime behavior.
    } finally {
      postgresLockProbeInFlight = false;
    }
  };
  const postgresLockProbeTimer = process.env.PAPERCLIP_RUNTIME_LOCK_DIAGNOSTICS === "1"
    ? setInterval(() => { void probePostgresLocks(); }, 250) : null;
  postgresLockProbeTimer?.unref();
  void probePostgresLocks();
  const heartbeatHost = async () => {
    if (hostHeartbeatInFlight) return await hostHeartbeatInFlight;
    const run = async () => {
      const inventoryRows = await db.select({
        cellId: runtimeCells.id, companyId: runtimeCells.companyId, generation: runtimeCells.generation,
        activeImageDigest: runtimeCells.activeImageDigest, desiredImageDigest: runtimeCells.desiredImageDigest,
        status: runtimeCells.status, capacityProfile: runtimeCells.capacityProfile,
      }).from(runtimeCells).where(and(eq(runtimeCells.runtimeHostId, host.id), isNull(runtimeCells.deletedAt)));
      const profileNames = [...new Set(inventoryRows.map(row => row.capacityProfile))];
      const profiles = profileNames.length ? await db.select().from(runtimeCapacityProfiles)
        .where(inArray(runtimeCapacityProfiles.key, profileNames)) : [];
      const profileByName = new Map(profiles.map(profile => [profile.key, profile]));
      const cells = inventoryRows.map(row => {
        const profile = profileByName.get(row.capacityProfile);
        if (!profile) throw new Error("conversation_software_host_capacity_profile_missing");
        const status = row.status === "HEALTHY" ? "healthy" : row.status === "STOPPED" ? "stopped" :
          row.status === "FENCED" ? "fenced" : row.status === "DEGRADED" || row.status === "FAILED" ? "failed" : "starting";
        return { cellId: row.cellId, companyId: row.companyId, generation: row.generation.toString(),
          imageDigest: row.activeImageDigest ?? row.desiredImageDigest, status,
          cpuMillis: profile.cpuMillis, memoryBytes: profile.memoryBytes.toString(), diskBytes: profile.diskBytes.toString() };
      });
      await runtime.heartbeat(host.id, { agentVersion: "6.0.2", cells });
      hostHeartbeatCount++;
    };
    const inFlight = run().catch(error => { hostHeartbeatFailed = true; throw error; });
    hostHeartbeatInFlight = inFlight;
    try { await inFlight; }
    finally { if (hostHeartbeatInFlight === inFlight) hostHeartbeatInFlight = null; }
  };
  await heartbeatHost();
  let lastProgressSnapshot = "";
  const reportProgress = async () => {
    if (!expectedRunId) return;
    try {
      const [run] = await db.select({status:heartbeatRuns.status,errorCode:heartbeatRuns.errorCode})
        .from(heartbeatRuns).where(and(eq(heartbeatRuns.companyId,companyId),eq(heartbeatRuns.id,expectedRunId)));
      const events = await db.select({type:heartbeatRunEvents.eventType,seq:heartbeatRunEvents.seq})
        .from(heartbeatRunEvents).where(eq(heartbeatRunEvents.runId,expectedRunId)).orderBy(desc(heartbeatRunEvents.seq)).limit(5);
      const reservations = await db.select({status:orchestrationModelReservations.status,purpose:orchestrationModelReservations.purpose,
        responsePresent:sql<boolean>`${orchestrationModelReservations.providerResponseHash} is not null`})
        .from(orchestrationModelReservations).where(eq(orchestrationModelReservations.conversationRunId,expectedRunId));
      const snapshot=JSON.stringify({stage:preparationStage,run,events,reservations});
      if(snapshot!==lastProgressSnapshot){lastProgressSnapshot=snapshot;console.info("conversation_software_host_progress",snapshot);}
    } catch {/* progress sampling never controls execution */}
  };
  const hostHeartbeatTimer = setInterval(() => {
    void reportProgress();
    if (!hostHeartbeatInFlight) void heartbeatHost().catch(() => {});
  }, 20_000);
  hostHeartbeatTimer.unref();
  const execFacts: Array<{ executable: string; cwdExact: boolean; modelCredentialPresent: boolean;
    managedModelBrokerOriginPresent: boolean;
    assignedMcpEnvironmentAbsent: boolean; credentialEnvironmentAbsent: boolean;
    nativePreparationPurpose: string | null; providerPackImageProbe: boolean;
    exitCode: number | null; timedOut: boolean; erasureFailureGuard: string | null; hostSessionErrorCode: string | null }> = [];
  relayHost.on("message", raw => {
    let message: Record<string, any>;
    try { message = JSON.parse(raw.toString()) as Record<string, any>; } catch { return; }
    if (message.type !== "exec_open" || !Array.isArray(message.request?.argv) || typeof message.channelId !== "string") return;
    const request = message.request as Record<string, any>;
    const requestEnv = request.env && typeof request.env === "object" ? request.env as Record<string, unknown> : {};
    const requestArgv = request.argv as string[];
    const nativePreparationPurpose = purposeByRequestId.get(request.requestId) ??
      (requestArgv[3] === "paperclip-native-asset-erasure" ? "native_provider_data_erasure" : null);
    const requestLabel = requestArgv[0] === "sh" && requestArgv[1] === "-c" ? requestArgv[2] : null;
    relayCommandOwnerByRequestId.set(request.requestId, requestLabel === "paperclip-runner-monitor"
      ? "runner_monitor" : requestLabel === "paperclip-runner-process-identity"
        ? "runner_identity_read" : requestLabel === "paperclip-runner-signal"
          ? "runner_signal" : requestLabel === "paperclip-runner-diagnostics"
            ? "runner_diagnostic_read" : requestLabel === "paperclip-runner-launch"
              ? "runner_launch" : requestLabel === "paperclip-runner-failure-check"
                ? "runner_failure_cleanup" : "other");
    const noBrokerPreparation = ["provider_artifact", "native_harness_state", "native_workspace_prepare", "native_runtime_context_prepare",
      "native_provider_data_erasure", "native_provider_data_erasure_probe"]
      .includes(nativePreparationPurpose ?? "");
    const managedModelOriginMatches = requestEnv.PAPERCLIP_MANAGED_MODEL_BROKER_ORIGIN === brokerOrigin &&
      Boolean(request.modelBrokerCredential);
    const noCredentialEnvironment = !Object.keys(requestEnv).some(name =>
      /(?:TOKEN|SECRET|PASSWORD|CREDENTIAL|API[_-]?KEY|PRIVATE[_-]?KEY|AUTHORIZATION)/i.test(name));
    const credentialFreePreparation = noBrokerPreparation && !managedModelOriginMatches &&
      !request.modelBrokerCredential && !request.brokerCredential && noCredentialEnvironment;
    if (!managedModelOriginMatches && !credentialFreePreparation) {
      relayHost.send(JSON.stringify({ type: "exec_exit", channelId: message.channelId, exitCode: 126, timedOut: false }));
      return;
    }
    const modelToken = request.modelBrokerCredential?.capabilityToken;
    const modelCredentialPresent = typeof modelToken === "string";
    const argv = request.argv as string[];
    const cwd = typeof request.cwd === "string" && request.cwd.startsWith("/") ? request.cwd : input.root;
    const assignedMcpEnvironmentAbsent = !requestEnv.PAPERCLIP_NATIVE_MCP_NAME &&
      !requestEnv.PAPERCLIP_NATIVE_MCP_URL && !requestEnv.PAPERCLIP_NATIVE_MCP_TOKEN;
    const providerPackImageProbe = nativePreparationPurpose === "provider_artifact" && argv[0] === "sh" &&
      typeof argv[2] === "string" && argv[2].includes("$HOME/.local/share/paperclip-runner/provider-pack");
    const fact = { executable: argv[0] ?? "", cwdExact: cwd === expectedTaskRoot, modelCredentialPresent,
      managedModelBrokerOriginPresent: requestEnv.PAPERCLIP_MANAGED_MODEL_BROKER_ORIGIN === brokerOrigin,
      assignedMcpEnvironmentAbsent, credentialEnvironmentAbsent: noCredentialEnvironment,
      nativePreparationPurpose, providerPackImageProbe,
      exitCode: null as number | null, timedOut: false, erasureFailureGuard: null as string | null,
      hostSessionErrorCode: null as string | null };
    execFacts.push(fact);
    void (async () => {
      try {
        if (!sessionHostEngine || typeof message.capabilityToken !== "string") throw new Error("sandbox_host_unavailable");
        const result = await sessionHostEngine.executeStream({ scope: {
          companyId, bindingId: identity.bindingId, cellId: identity.cellId,
          cellGeneration: identity.cellGeneration, sandboxRef: identity.sandboxRef,
        }, request, capabilityToken: message.capabilityToken }, (stream: "stdout" | "stderr", chunk: Buffer) => {
          if (nativePreparationPurpose === "native_provider_data_erasure" && stream === "stderr") {
            const text = chunk.toString("utf8");
            const identityCleanup = /^remote_identity_cleanup_failed:([a-z_]{1,40}):([0-9]{1,3})\s*$/m.exec(text);
            const erasure = /^remote_erasure_failed:([a-z_]{1,40}):([0-9]{1,3})\s*$/m.exec(text);
            if (identityCleanup) fact.erasureFailureGuard = `process_stop/${identityCleanup[1]}:${identityCleanup[2]}`;
            else if (erasure) fact.erasureFailureGuard = `${erasure[1]}:${erasure[2]}`;
          }
          relayHost.send(JSON.stringify({ type: "exec_output", channelId: message.channelId,
            stream, base64: chunk.toString("base64") }));
        });
        if (result.modelBrokerSessionReceipt) modelBrokerSessionReceipts.push({
          phase: request.modelBrokerSession?.phase ?? "unknown",
          sessionKey: result.modelBrokerSessionReceipt.sessionKey,
          capabilityHash: result.modelBrokerSessionReceipt.capabilityHash,
          expiresAt: result.modelBrokerSessionReceipt.expiresAt,
          sessionDeadlineAt: request.modelBrokerSession?.sessionDeadlineAt ?? "",
        });
        fact.exitCode = result.exitCode;
        relayHost.send(JSON.stringify({ type: "exec_exit", channelId: message.channelId,
          exitCode: result.exitCode, timedOut: result.timedOut,
          ...(result.modelBrokerSessionReceipt ? { modelBrokerSessionReceipt: result.modelBrokerSessionReceipt } : {}) }));
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "";
        fact.hostSessionErrorCode = /^[a-z][a-z0-9_:-]{0,99}$/.test(errorMessage) ? errorMessage : "unclassified_host_error";
        fact.exitCode = 126;
        relayHost.send(JSON.stringify({ type: "exec_exit", channelId: message.channelId, exitCode: 126, timedOut: false }));
      }
    })();
  });

  const beforeNativeExecution = async ({ runId, issueId }: { runId: string; issueId: string | null }) => {
    if (!issueId) throw new Error("conversation_software_host_issue_missing");
    if (!prepareHostForRun) throw new Error("conversation_software_host_admission_unavailable");
    const [lease] = await db.select({ id: environmentLeases.id }).from(environmentLeases)
      .where(and(eq(environmentLeases.companyId, companyId), eq(environmentLeases.heartbeatRunId, runId),
        eq(environmentLeases.status, "active"), eq(environmentLeases.environmentId, environment.id))).limit(1);
    if (!lease) throw new Error("conversation_software_host_run_lease_missing");
    await prepareHostForRun(runId, lease.id);
    if (expectedIssueId !== issueId) throw new Error("conversation_software_host_issue_binding_changed");
    return { PATH: `${input.opencodeBinary.slice(0, input.opencodeBinary.lastIndexOf("/"))}:${process.env.PATH ?? ""}`,
      OPENCODE_DISABLE_DEFAULT_PLUGINS: "true", OPENCODE_DISABLE_MODELS_FETCH: "true",
      NODE_EXTRA_CA_CERTS: input.certBundlePath, SSL_CERT_FILE: input.certBundlePath,
      ...(input.brokerProxyOrigin ? { HTTP_PROXY: "", http_proxy: "", HTTPS_PROXY: input.brokerProxyOrigin,
        https_proxy: input.brokerProxyOrigin, ALL_PROXY: "", all_proxy: "",
        NO_PROXY: "localhost,127.0.0.1,::1", no_proxy: "localhost,127.0.0.1,::1" } : {}) };
  };

  const prepareHostForRunOnce = async (runId: string, expectedLeaseId: string) => {
    if (expectedRunId === runId && expectedTaskRoot && acquiredLeaseExpiresAt) return;
    if (expectedRunId !== null && expectedRunId !== runId)
      throw new Error("conversation_software_host_run_changed");
    expectedRunId = runId;preparationStage="read_run";
    const [run] = await db.select({ status: heartbeatRuns.status, runtimeMode: heartbeatRuns.runtimeMode,
      nativeIssueId: heartbeatRuns.nativeIssueId, responsibleUserId: heartbeatRuns.responsibleUserId,
      contextSnapshot: heartbeatRuns.contextSnapshot }).from(heartbeatRuns)
      .where(and(eq(heartbeatRuns.companyId, companyId), eq(heartbeatRuns.id, runId))).limit(1);
    if (!run || run.status !== "running" || run.runtimeMode !== "native" ||
      run.responsibleUserId !== actor.userId || !run.nativeIssueId)
      throw new Error("conversation_software_host_native_run_binding_invalid");
    const runContext = run.contextSnapshot && typeof run.contextSnapshot === "object"
      ? run.contextSnapshot as Record<string, unknown> : {};
    const issueId = typeof runContext.issueId === "string" ? runContext.issueId : null;
    if (!issueId || issueId !== run.nativeIssueId)
      throw new Error("conversation_software_host_issue_binding_invalid");
    if (expectedIssueId !== null && expectedIssueId !== issueId)
      throw new Error("conversation_software_host_issue_changed");
    expectedIssueId = issueId;
    const [manifest] = await db.select().from(agentExecutionManifests).where(eq(agentExecutionManifests.runId, runId)).limit(1);
    if (!manifest) throw new Error("conversation_software_host_manifest_missing");
    const conversationGeneration = run?.contextSnapshot && typeof run.contextSnapshot === "object" &&
      "conversationSessionGeneration" in run.contextSnapshot &&
      typeof run.contextSnapshot.conversationSessionGeneration === "number"
        ? run.contextSnapshot.conversationSessionGeneration : null;
    const scope = await findNativeChatWorkspaceScope(db, { adapterType: "paperclip_runner", environmentDriver: "sandbox",
      companyId, agentId, issueId, runId, responsibleUserId: run?.responsibleUserId,
      conversationSessionGeneration: conversationGeneration });
    const taskRoot = scope && scope.projectId === null ? nativeChatWorkspaceCwd(scope, null, false) : null;
    if (!taskRoot) throw new Error("conversation_software_host_private_task_root_missing");
    expectedTaskRoot = taskRoot;
    preparationStage="resolve_runtime_broker";
    const resolvedRuntimeBroker=await qualificationGateway.resolveSandboxCredentialBrokerPolicyBindings({companyId,agentId,runId,
      responsibleUserId:actor.userId!,presenceId:runtimePresence.id,bindings:[{...runtimeBrokerBinding,grantVersionHash:"0".repeat(64)}]});
    const grantVersionHash=resolvedRuntimeBroker.authorizedConnectionGrantHashes[runtimeConnection.connection.id];
    assert.ok(grantVersionHash);assert.ok(resolvedRuntimeBroker.bindings[0]?.allowedTools.includes(runtimeConnection.toolName));
    preparationStage="create_binding";
    await createBindingForRun({...runtimeBrokerBinding,grantVersionHash});
    preparationStage="qualify";await qualifyHost();preparationStage="compile";
    const boundary = policyFixture(); boundary.riskClass = "C3"; boundary.requiredControls = [...conversationRequiredControls];
    boundary.filesystem.readPaths = [taskWorkspaceNamespace];
    boundary.filesystem.writePaths = [taskWorkspaceNamespace];
    boundary.filesystem.readPaths = [taskRoot]; boundary.filesystem.writePaths = [taskRoot]; boundary.filesystem.deniedPaths = [];
    boundary.process.allowedBinaries = []; boundary.process.allowedSyscalls = []; boundary.network.destinations = [];
    const candidate = structuredClone(boundary);
    candidate.network.destinations = [{ hostname: new URL(brokerOrigin).hostname,
      port: Number(new URL(brokerOrigin).port || 443), methods: ["POST"], pathPrefixes: ["/runtime-tools/model/v1/messages"] }];
    const compiled = await service.compile(actor, companyId, binding.id, { expectedVersion: 2,
      executionManifestId: manifest.id, candidatePolicy: candidate });
    if (compiled.status !== "qualified") {
      const proof = compiled.compilation as { proverResult?: unknown; failedBoundaries?: unknown; unsupportedFeatures?: unknown } | null;
      const safeNames = (value: unknown) => Array.isArray(value)
        ? value.filter((entry): entry is string => typeof entry === "string" && /^[a-z0-9_:-]{1,80}$/.test(entry)).slice(0, 24)
        : [];
      throw new Error(`conversation_software_host_policy_compile_failed_${JSON.stringify({
        status: compiled.status,
        proverResult: proof && typeof proof.proverResult === "string" ? proof.proverResult : null,
        failedBoundaries: safeNames(proof?.failedBoundaries),
        unsupportedFeatures: safeNames(proof?.unsupportedFeatures),
      })}`);
    }
    preparationStage="inspect";
    const observedBeforeAdmission = await driveHost(transport.bridge(actor).inspect(identity));
    preAdmissionObservation = { state: observedBeforeAdmission.state,
      generationMatches: observedBeforeAdmission.generation === identity.cellGeneration,
      imageDigestMatches: observedBeforeAdmission.imageDigest === imageDigest,
      controlsHealthy: observedBeforeAdmission.controlsHealthy };
    if (observedBeforeAdmission.state !== "stopped" || observedBeforeAdmission.generation !== identity.cellGeneration ||
      observedBeforeAdmission.imageDigest !== imageDigest || !observedBeforeAdmission.controlsHealthy)
      throw new Error(`conversation_software_host_pre_admission_observation_invalid_${JSON.stringify(preAdmissionObservation)}`);
    preparationStage="admit";
    const admittedPromise = service.admit(actor, companyId, binding.id, { expectedVersion: 3, policySnapshotId: compiled.id });
    const admitted = await driveHost(admittedPromise);
    if (admitted.binding.status !== "running") throw new Error("conversation_software_host_workload_not_running");
    const [lease] = await db.select().from(environmentLeases).where(and(eq(environmentLeases.companyId, companyId),
      eq(environmentLeases.id, expectedLeaseId), eq(environmentLeases.heartbeatRunId, runId),
      eq(environmentLeases.environmentId, environment.id), eq(environmentLeases.status, "active"))).limit(1);
    if (!lease) throw new Error("conversation_software_host_run_lease_missing");
    if (!lease.expiresAt || lease.expiresAt <= new Date())
      throw new Error("conversation_software_host_provider_lease_expiry_missing");
    acquiredLeaseExpiresAt = lease.expiresAt.toISOString();
    const expectDenied = async (work: Promise<unknown>) => {
      try { await work; return false; } catch { return true; }
    };
    const wrongRunDenied = await expectDenied(runtime.executeSandboxTask({ companyId, runId: randomUUID(), leaseId: lease.id,
      command: "true", cwd: taskRoot, timeoutMs: 1000 }));
    const wrongLeaseDenied = await expectDenied(runtime.executeSandboxTask({ companyId, runId, leaseId: randomUUID(),
      command: "true", cwd: taskRoot, timeoutMs: 1000 }));
    const wrongCwdDenied = await expectDenied(runtime.executeSandboxTask({ companyId, runId, leaseId: lease.id,
      command: "true", cwd: `${taskRoot}/outside`, timeoutMs: 1000 }));
    const execCountBeforeStartProbes = execFacts.length;
    const wrongSessionStartCommandDenied = await expectDenied(runtime.executeSandboxTask({ companyId, runId, leaseId: lease.id,
      command: "sh", args: ["-c", "exit 0", "paperclip-not-runner-launch"], cwd: taskRoot, timeoutMs: 1000,
      nativePreparationPurpose: "native_session_start" }));
    const wrongSessionStartRootDenied = await expectDenied(runtime.executeSandboxTask({ companyId, runId, leaseId: lease.id,
      command: "sh", args: ["-c", "exit 0", "paperclip-runner-launch"], cwd: `${taskRoot}/outside`, timeoutMs: 1000,
      nativePreparationPurpose: "native_session_start" }));
    const wrongSessionStartExecuted = execFacts.length !== execCountBeforeStartProbes;
    const broadened = structuredClone(candidate);
    broadened.filesystem.writePaths = ["/"];
    const wrongPolicy = compileSandboxPolicy({ boundary, candidate: broadened, capabilities: capabilities() as any,
      authorizedConnectionGrantHashes: {}, credentialBrokerOrigin: brokerOrigin, credentialBrokerBindings: [], sourcePolicyRefs: [] });
    const wrongPolicyDenied = wrongPolicy.failedBoundaries.includes("filesystem_write_expansion");
    negativeAdmissionControls={wrongRunDenied,wrongLeaseDenied,wrongCwdDenied,wrongPolicyDenied};
    if (!wrongRunDenied || !wrongLeaseDenied || !wrongCwdDenied || !wrongPolicyDenied ||
      !wrongSessionStartCommandDenied || !wrongSessionStartRootDenied || wrongSessionStartExecuted)
      throw new Error("conversation_software_host_negative_admission_control_failed");
    negativeNativeSessionStartControls = { wrongCommandDenied: wrongSessionStartCommandDenied,
      wrongRootDenied: wrongSessionStartRootDenied, noExecution: !wrongSessionStartExecuted };
  };
  prepareHostForRun = async (runId, leaseId) => {
    const existing = hostAdmissionByRun.get(runId);
    if (existing) {
      if (existing.leaseId !== leaseId) throw new Error("conversation_software_host_lease_binding_changed");
      return await existing.promise;
    }
    const promise = prepareHostForRunOnce(runId, leaseId);
    hostAdmissionByRun.set(runId, { leaseId, promise });
    try {
      await promise;
    } catch (error) {
      const chain:Record<string,unknown>[]=[];
      let current:unknown=error;
      for(let depth=0;depth<4 && current && typeof current === "object";depth++){
        const row=current as Record<string,unknown>;
        const reason=typeof row.reasonCode === "string" ? row.reasonCode : typeof row.code === "string" ? row.code : null;
        chain.push({name:current instanceof Error ? current.name : "unknown",
          reason:reason && /^[A-Za-z][A-Za-z0-9_:-]{0,99}$/.test(reason) ? reason : null,
          failureClass:safeSandboxFailureClass(current),sourceFrames:safeErrorSourceFrames(current)});
        current=row.cause;
      }
      const failure={phase:preparationStage,chain};sandboxExecutionFailures.push(failure);
      if(process.env.PAPERCLIP_NATIVE_SOURCE_CLOSURE_DIAGNOSTICS === "1")console.error("conversation_software_host_preparation_failed",JSON.stringify(failure));
      hostAdmissionByRun.delete(runId);
      throw error;
    }
  };

  const providerPackRoot = process.env.PAPERCLIP_RUNNER_REMOTE_PROVIDER_PACK_PATH?.trim();
  if (!providerPackRoot || !lstatSync(providerPackRoot).isDirectory())
    throw new Error("conversation_software_host_provider_pack_image_missing");
  providerImageHome = mkdtempSync(join(tmpdir(), "paperclip-managed-provider-image-"));
  const preinstalledPack = join(providerImageHome, ".local", "share", "paperclip-runner", "provider-pack");
  mkdirSync(join(providerImageHome, ".local", "share", "paperclip-runner"), { recursive: true, mode: 0o700 });
  symlinkSync(providerPackRoot, preinstalledPack, "dir");

  return {
    sandboxExec: runtime.executeSandboxTask,
    eraseRemoteNativeRuntimeAsset: (
      locator: Parameters<typeof runtime.eraseRemoteNativeRuntimeAsset>[0],
      input: Parameters<typeof runtime.eraseRemoteNativeRuntimeAsset>[1],
    ) => driveHost(runtime.eraseRemoteNativeRuntimeAsset(locator, input)),
    environmentRuntime,
    beforeNativeExecution,
    modelRequest: async (body: unknown, signal?: AbortSignal) => {
      if (state.get(identity.cellId) !== "running" || !expectedRunId || !binding || observedSandboxPhase !== "Ready")
        throw new Error("sandbox_session_provider_not_running");
      const names = [...attachedSessionProviders].filter(name => name.startsWith("awms-"));
      if (names.length !== 1) throw new Error("sandbox_session_provider_observation_unavailable");
      const provider = sessionProviders.get(names[0]!);
      if (!provider?.credential || !provider.expiresAt || Date.parse(provider.expiresAt) <= Date.now())
        throw new Error("sandbox_session_provider_credential_unavailable");
      const claims = provider.family ? verifyRuntimeToolsToken(provider.credential, provider.family) : null;
      if (!claims || claims.scope !== provider.family || claims.company_id !== companyId || claims.run_id !== expectedRunId ||
        claims.sub !== agentId || claims.exp * 1000 <= Date.now())
        throw new Error("sandbox_session_provider_authority_changed");
      return await (input.gateway as any).callManagedMessages(claims, body, signal ?? new AbortController().signal);
    },
    facts: () => {
      if(process.env.PAPERCLIP_NATIVE_SOURCE_CLOSURE_DIAGNOSTICS === "1")console.info("conversation_software_host_preparation",JSON.stringify({phase:preparationStage,
        expectedRunBound:Boolean(expectedRunId),bindingPresent:Boolean(binding),execCount:execFacts.length,
        executables:[...new Set(execFacts.map(fact=>fact.executable.split("/").at(-1)))],lastExecs:execFacts.slice(-6),credentialProbes:qualificationToolResponses,
        softwareProbeCount:softwareProbeObservations.length,qualificationEvidence,failures:sandboxExecutionFailures}));
      const sandboxStageCounts = execFacts.reduce<Record<string, { calls: number; nonzeroExits: number; timeouts: number }>>((counts, fact) => {
        const stage = fact.nativePreparationPurpose ?? "unclassified";
        const count = counts[stage] ?? { calls: 0, nonzeroExits: 0, timeouts: 0 };
        count.calls++;
        if (fact.exitCode !== null && fact.exitCode !== 0) count.nonzeroExits++;
        if (fact.timedOut) count.timeouts++;
        counts[stage] = count;
        return counts;
      }, {});
      return { mode: "controlled_signed_host_relay", hostId: host.id, cellId: cell.id,
      bindingId:binding?.id ?? null,qualificationEvidence,qualificationToolResponses,softwareProbeObservations, environmentId: environment.id, relayAuthenticated: relayHost.readyState === WebSocket.OPEN,
      providerAttestedLeaseExpiresAt: acquiredLeaseExpiresAt,
      preAdmissionObservation,
      modelBrokerSessionReceipts: [...modelBrokerSessionReceipts],
      attachedModelBrokerProviderCount: [...attachedSessionProviders].filter(name => name.startsWith("awms-")).length,
      hostHeartbeatCount,
      hostHeartbeatFailed,
      hostCliOperations: [...hostCliOperations],
      postgresLockSnapshots,
      relayCommandOwners: [...relayCommandOwnerByRequestId.entries()]
        .map(([requestId, owner]) => ({ requestId, owner })).slice(-256),
      sandboxExecutionChecks,
      sandboxExecutionFailures,
      sandboxStageCounts,
      execCount: execFacts.length, exactPrivateCwdCount: execFacts.filter(fact => fact.cwdExact).length,
      managedModelCredentialCount: execFacts.filter(fact => fact.modelCredentialPresent).length,
      execFacts,
      assignedMcpEnvironmentAbsentCount: execFacts.filter(fact => fact.assignedMcpEnvironmentAbsent).length,
      preparationStage,negativeControls:negativeAdmissionControls,
      negativeNativeSessionStartControls,
      nativeSessionStartCredentialNegativeControls,
      executableNames: [...new Set(execFacts.map(fact => fact.executable.split("/").pop() ?? ""))] };
    },
    close: async () => { clearInterval(hostHeartbeatTimer); if (postgresLockProbeTimer) clearInterval(postgresLockProbeTimer);
      if (postgresLockProbeInFlight) await new Promise(resolve => setTimeout(resolve, 20));
      if (hostHeartbeatInFlight) await hostHeartbeatInFlight;
      relayHost.close(); await new Promise<void>(resolve => relayServer.close(() => resolve())); await runtime.relay.stop();
      if (providerImageHome) rmSync(providerImageHome, { recursive: true, force: true }); },
  };
}
