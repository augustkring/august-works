# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: aw-v9-experience.spec.ts >> V9 Home, feedback recovery and rollback preserve native state
- Location: tests/e2e/aw-v9-experience.spec.ts:17:1

# Error details

```
Test timeout of 120000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=f4e4]:
  - link "Skip to Main Content" [ref=f4e5] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=f4e6]:
    - generic [ref=f4e7]:
      - generic [ref=f4e8]:
        - complementary [ref=f4e10]:
          - button "Open V9 disposable browser company organization switcher" [ref=f4e12]:
            - generic [ref=f4e13]:
              - generic [ref=f4e14]: V
              - generic "V9 disposable browser company" [ref=f4e17]
          - navigation [ref=f4e18]:
            - generic [ref=f4e19]:
              - generic [ref=f4e20]:
                - text: View
                - combobox "View" [ref=f4e21]:
                  - option "Member"
                  - option "Manager" [selected]
                  - option "Admin"
                  - option "Security admin"
              - link "Home" [ref=f4e22] [cursor=pointer]:
                - /url: /VDI/dashboard
              - link "Needs You" [ref=f4e28] [cursor=pointer]:
                - /url: /VDI/needs-you
              - link "Work" [ref=f4e34] [cursor=pointer]:
                - /url: /VDI/work
              - link "Agents" [ref=f4e40] [cursor=pointer]:
                - /url: /VDI/agents
              - link "Apps" [ref=f4e48] [cursor=pointer]:
                - /url: /VDI/apps
              - link "Insights" [ref=f4e58] [cursor=pointer]:
                - /url: /VDI/insights
              - link "Advanced" [ref=f4e63] [cursor=pointer]:
                - /url: /VDI/advanced
              - generic [ref=f4e67]:
                - button "Ask Blentera" [ref=f4e68]
                - link "Help / Support" [ref=f4e69] [cursor=pointer]:
                  - /url: /VDI/company/help
        - generic [ref=f4e76]:
          - button "Open account menu" [ref=f4e77]:
            - generic [ref=f4e78]: BR
            - generic [ref=f4e80]: Browser product reviewer
          - button "Feedback" [ref=f4e81]
      - separator "Resize sidebar" [ref=f4e84]
    - generic [ref=f4e86]:
      - region "Global utilities" [ref=f4e88]:
        - button "Ask Blentera" [ref=f4e89]
        - generic [ref=f4e92]:
          - generic [ref=f4e93]: Language
          - combobox "Language" [ref=f4e94]:
            - option "English" [selected]
            - option "Dansk"
        - button "Feedback" [ref=f4e95]
        - link "Help / Support" [ref=f4e96] [cursor=pointer]:
          - /url: /VDI/company/help
        - link "Contact support" [ref=f4e97] [cursor=pointer]:
          - /url: mailto:support@blentera.com
        - link "User account" [ref=f4e98] [cursor=pointer]:
          - /url: /VDI/company/settings/instance/profile
      - main [ref=f4e106]:
        - generic [ref=f4e107]:
          - heading "Home" [active] [level=1] [ref=f4e108]
          - button "Ask Blentera" [ref=f4e109]
          - paragraph [ref=f4e110]: Nothing needs your attention right now.
```