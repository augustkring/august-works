from pathlib import Path
p=Path('/workspace/blentera-v10/server/src/services/native-direct-input.ts')
s=p.read_text()
s=s.replace('const nativeSourceReadContextOrdinals = new WeakMap<object, number>();\n','').replace('const nativeSourceReadAncestryOrdinals = new WeakMap<object, number>();\n','').replace('let nextNativeSourceReadContextOrdinal = 1;\n','').replace('let nextNativeSourceReadAncestryOrdinal = 1;\n','')
a=s.index('const nativeSourceMemoDiagnostics =')
b=s.index('function nativeSourceMemoDiagnosticsEnabled()',a)
s=s[:a]+'''const nativeSourceMemoDiagnostics = { frozenTaskMemoByKind: {} as Record<string,
  { eligibleCalls: number; ineligibleCalls: number; hits: number; misses: number }> };
'''+s[b:]
a=s.index('  nativeSourceMemoDiagnostics.documentSourceClosure =')
b=s.index('\n}',a)
s=s[:a]+s[b:]
a=s.index('    if (nativeSourceMemoDiagnosticsEnabled() && !nativeSourceMemoDiagnostics.outputCaptureClosure.overflowLogged)')
b=s.index('    throw forbidden("The Native source graph exceeds its total-work bound");',a)
s=s[:a]+s[b:]
a=s.index('  if (nativeSourceMemoDiagnosticsEnabled()) {\n    const profile = nativeSourceMemoDiagnostics.outputCaptureClosure;')
b=s.index('  const completedCaptureClosure',a)
s=s[:a]+s[b:]
a=s.index('  if (nativeSourceMemoDiagnosticsEnabled()) {\n    const stats = nativeSourceMemoDiagnostics.documentSourceClosure;')
b=s.index('  if (proofKey && documentProofs?.has(proofKey))',a)
s=s[:a]+s[b:]
p.with_suffix('.cleanup.tmp.ts').write_text(s)
p=Path('/workspace/blentera-v10/server/src/__tests__/native-payload-temporal-sources.integration.test.ts')
s=p.read_text();s=s.replace('''    if (process.env.PAPERCLIP_NATIVE_SOURCE_MEMO_DIAGNOSTICS === "1")
      console.error("native_document_source_proof_profile", JSON.stringify(
        nativeSourceMemoDiagnosticsForTest().documentSourceClosure));
''','')
p.with_suffix('.cleanup.tmp.ts').write_text(s)
