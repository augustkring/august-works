import { randomUUID } from "node:crypto";
import express from "express";
import request from "supertest";
import { and, eq, sql } from "drizzle-orm";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import { agents, companies, createDb, heartbeatRuns, instanceSettings, memoryJobs } from "@paperclipai/db";
import type { ResourceGovernancePolicy } from "@paperclipai/shared";
import { startEmbeddedPostgresTestDatabase } from "./helpers/embedded-postgres.js";
import { seedCurrentHumanSourceActor } from "./helpers/current-human-source-fixture.js";
import { instanceSettingsRoutes } from "../routes/instance-settings.js";
import { errorHandler } from "../middleware/error-handler.js";
import { instanceSettingsService } from "../services/instance-settings.js";
import { memoryJobService } from "../services/memory/memory-jobs.js";
import { admitAnalyticalRequest, isResourceAdmissionDeferred } from "../services/resource-governance.js";

describe("configured original-owner resource admission", () => {
  let database: Awaited<ReturnType<typeof startEmbeddedPostgresTestDatabase>>, db: ReturnType<typeof createDb>;
  let a: string, b: string, agentA: string;
  const empty: ResourceGovernancePolicy = { version: 1, pools: [], rates: [] };
  beforeAll(async () => { database = await startEmbeddedPostgresTestDatabase("v10-resource-admission-"); db = createDb(database.connectionString); }, 60000);
  afterAll(async () => { await database?.cleanup(); });
  beforeEach(async () => {
    await db.execute(sql`truncate companies cascade`);
    await instanceSettingsService(db).updateGeneral({ resourceGovernance: empty });
    a = randomUUID(); b = randomUUID(); agentA = randomUUID();
    await db.insert(companies).values([{ id: a, name: "Bursty tenant", issuePrefix: "RA" }, { id: b, name: "Peer tenant", issuePrefix: "RB" }]);
    await db.insert(agents).values({ id: agentA, companyId: a, name: "Original run owner", adapterType: "paperclip_runner", status: "active" });
  });
  async function configure(resource: "durable_execution" | "analytical_request", hardLimit: number, companyLimit = 1) {
    const policy: ResourceGovernancePolicy = { version: 1, rates: [], pools: [{ resource,
      unit: resource === "durable_execution" ? "active_work_item" : "admitted_request", hardLimit,
      onSoftLimit: "observe", onHardLimit: resource === "durable_execution" ? "defer" : "reject", exceptionOwner: "Measured fixture operator",
      companies: [a,b].map(companyId => ({ companyId, hardLimit: companyLimit, fairnessClass: "shared", priority: 2 })) }] };
    await instanceSettingsService(db).updateGeneral({ resourceGovernance: policy });
    return policy;
  }
  // Skeletal rows test admission/claim custody only, never successful private
  // Memory computation. The original worker must still refuse their sources.
  async function queue(companyId: string, operationType: "dedupe" | "retention" = "dedupe", submittedAt = new Date()) {
    return (await db.insert(memoryJobs).values({ companyId, operationType, jobKey: randomUUID(), sourceRefJson: {}, submittedAt }).returning())[0]!;
  }
  async function pending(id: string) { return (await db.select().from(memoryJobs).where(eq(memoryJobs.id, id)))[0]!; }

  it("has no invented capacity when the operator configured none", async () => {
    const one = await queue(a), two = await queue(a);
    const worker = memoryJobService(db);
    expect((await worker.claimNext())?.id).toBe(one.id);
    expect((await worker.claimNext())?.id).toBe(two.id);
  });

  it("serializes competing original heartbeat and Memory positive claims across real database sessions", async () => {
    await configure("durable_execution", 1);
    const runId = randomUUID(), job = await queue(b);
    await db.insert(heartbeatRuns).values({ id: runId, companyId: a, agentId: agentA, status: "queued" });
    const other = createDb(database.connectionString);
    const results = await Promise.all([
      db.update(heartbeatRuns).set({ status: "running" }).where(eq(heartbeatRuns.id, runId)).returning()
        .then(rows => rows.length, error => { expect(isResourceAdmissionDeferred(error)).toBe(true); return 0; }),
      memoryJobService(other).claimNext().then(row => row ? 1 : 0),
    ]);
    expect(results.reduce((sum, value) => sum + value, 0)).toBe(1);
    const [count] = await db.execute<{ count: string }>(sql`select public.aw_v10_resource_durable_occupancy(null)::text as count`);
    expect(count.count).toBe("1");
    const [run] = await db.select().from(heartbeatRuns).where(eq(heartbeatRuns.id, runId));
    expect([run.status, (await pending(job.id)).status].sort()).toEqual(["queued", "running"]);
  });

  it("skips a saturated company while preserving its pending work and a peer's slot", async () => {
    await configure("durable_execution", 2);
    const worker = memoryJobService(db), first = await queue(a);
    expect((await worker.claimNext())?.id).toBe(first.id);
    const backlog = await queue(a), peer = await queue(b);
    expect((await worker.claimNext())?.id).toBe(peer.id);
    expect((await pending(backlog.id)).status).toBe("queued");
    expect(await worker.claimNext()).toBeNull();
  });

  it("serves an eligible peer ahead of an older tenant burst without reversing company FIFO", async () => {
    await configure("durable_execution", 1);
    const worker = memoryJobService(db), old = new Date(Date.now() - 60000);
    const first = await queue(a, "dedupe", old), second = await queue(a, "dedupe", new Date(old.getTime() + 1));
    await queue(a, "dedupe", new Date(old.getTime() + 2));
    const peer = await queue(b);
    const admitted = await worker.claimNext(); expect(admitted?.id).toBe(first.id);
    await worker.executeClaimed(admitted!);
    expect((await pending(first.id)).status).toBe("failed"); // Original Source/feature refusal, never seeded success.
    const next = await worker.claimNext(); expect(next?.id).toBe(peer.id);
    expect((await pending(second.id)).status).toBe("queued");
    await worker.executeClaimed(next!);
    expect((await worker.claimNext())?.id).toBe(second.id);
  });

  it("does not free original claim capacity from an expired lease clock alone", async () => {
    await configure("durable_execution", 1);
    const worker = memoryJobService(db), first = await queue(a), second = await queue(b);
    const admitted = await worker.claimNext(); expect(admitted?.id).toBe(first.id);
    await db.update(memoryJobs).set({ leaseExpiresAt: new Date(Date.now() - 1000) }).where(eq(memoryJobs.id, first.id));
    expect(await worker.claimNext()).toBeNull();
    expect((await pending(second.id)).status).toBe("queued");
    await worker.recoverExpiredLeases(new Date());
    expect((await pending(first.id)).status).toBe("failed");
    expect(await worker.claimNext()).not.toBeNull();
  });

  it("admits original retention cleanup and renewal while positive capacity is occupied", async () => {
    await configure("durable_execution", 1);
    const worker = memoryJobService(db); await queue(a);
    const admitted = await worker.claimNext(); expect(admitted).not.toBeNull();
    const cleanup = await queue(b, "retention");
    expect((await worker.claimNext())?.id).toBe(cleanup.id);
    await db.update(memoryJobs).set({ leaseExpiresAt: new Date(Date.now() + 60000) }).where(eq(memoryJobs.id, admitted!.id));
    await db.update(memoryJobs).set({ status: "failed" }).where(eq(memoryJobs.id, admitted!.id));
    expect((await pending(cleanup.id)).status).toBe("running");
  });

  it("holds configured analytical request slots until the actual request transaction settles", async () => {
    await configure("analytical_request", 2);
    let entered!: () => void, release!: () => void;
    const ready = new Promise<void>(resolve => { entered = resolve; }), held = new Promise<void>(resolve => { release = resolve; });
    const active = db.transaction(async raw => { await admitAnalyticalRequest(raw as unknown as typeof db, a); entered(); await held; });
    await ready;
    try {
      await expect(db.transaction(tx => admitAnalyticalRequest(tx as unknown as typeof db, a))).rejects.toMatchObject({ status: 429 });
      await db.transaction(tx => admitAnalyticalRequest(tx as unknown as typeof db, b));
    } finally { release(); await active; }
    await db.transaction(tx => admitAnalyticalRequest(tx as unknown as typeof db, a));
    await expect(db.transaction(async tx => { await admitAnalyticalRequest(tx as unknown as typeof db, a); throw new Error("Original request rollback"); })).rejects.toThrow("Original request rollback");
    await db.transaction(tx => admitAnalyticalRequest(tx as unknown as typeof db, a));
  });

  it("requires actual current operator admission and withholds peer policy from ordinary readers", async () => {
    const human = await seedCurrentHumanSourceActor(db, [a], randomUUID());
    const peer = await seedCurrentHumanSourceActor(db, [b], randomUUID());
    const policy = await configure("durable_execution", 2);
    const app = (actor: typeof human) => {
      const server = express(); server.use(express.json()); server.use((req, _res, next) => { req.actor = actor; next(); });
      server.use("/api", instanceSettingsRoutes(db, { deploymentProfile: "saas", operatorUserIds: [human.userId!] }));
      server.use(errorHandler); return server;
    };
    const denied = await request(app(peer)).patch("/api/instance/settings/general").send({ resourceGovernance: empty });
    expect(denied.status).toBe(403);
    expect((await request(app(peer)).get("/api/instance/settings/general")).body).not.toHaveProperty("resourceGovernance");
    expect((await request(app(peer)).get("/api/instance/settings")).body.general).not.toHaveProperty("resourceGovernance");
    expect((await request(app(human)).get("/api/instance/settings/general")).body.resourceGovernance).toEqual(policy);
    const saved = await request(app(human)).patch("/api/instance/settings/general").send({ resourceGovernance: policy });
    expect(saved.status).toBe(200);
    const stale = { ...human, sessionId: randomUUID() };
    expect((await request(app(stale)).patch("/api/instance/settings/general").send({ resourceGovernance: empty })).status).toBe(403);
    expect((await instanceSettingsService(db).getGeneral()).resourceGovernance).toEqual(policy);
  });

  it("fails closed on restored malformed operator policy instead of admitting work", async () => {
    const policy = await configure("durable_execution", 1);
    const invalid = { ...policy, pools: [{ ...policy.pools[0], hardLimit: "1", paidBypass: true }] };
    await db.update(instanceSettings).set({ general: { resourceGovernance: invalid } }).where(eq(instanceSettings.singletonKey, "default"));
    const runId = randomUUID();
    await db.insert(heartbeatRuns).values({ id: runId, companyId: a, agentId: agentA, status: "queued" });
    await expect(db.update(heartbeatRuns).set({ status: "running" }).where(eq(heartbeatRuns.id, runId))).rejects.toMatchObject({ cause: { code: "23514" } });
    expect((await db.select().from(heartbeatRuns).where(and(eq(heartbeatRuns.id, runId), eq(heartbeatRuns.status, "queued"))))).toHaveLength(1);
  });
});
