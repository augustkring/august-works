CREATE FUNCTION public.aw_v10_resource_policy_valid(p jsonb) RETURNS boolean LANGUAGE plpgsql IMMUTABLE AS $$
DECLARE v jsonb; c jsonb; seen text[] := '{}'; companies text[]; resource text;
BEGIN
 IF jsonb_typeof(p) IS DISTINCT FROM 'object' OR p->'version' IS DISTINCT FROM '1'::jsonb
  OR jsonb_typeof(p->'pools') IS DISTINCT FROM 'array' OR jsonb_typeof(p->'rates') IS DISTINCT FROM 'array'
  OR EXISTS(SELECT 1 FROM jsonb_object_keys(p) k WHERE k NOT IN ('version','pools','rates')) THEN RETURN false; END IF;
 IF jsonb_array_length(p->'pools')>2 OR jsonb_array_length(p->'rates')>10000 THEN RETURN false; END IF;
 FOR v IN SELECT * FROM jsonb_array_elements(p->'pools') LOOP
  IF jsonb_typeof(v) IS DISTINCT FROM 'object' THEN RETURN false; END IF;
  resource:=v->>'resource';
  IF resource IS NULL OR resource NOT IN ('durable_execution','analytical_request') OR resource=ANY(seen) THEN RETURN false; END IF;
  seen:=array_append(seen,resource);
  IF EXISTS(SELECT 1 FROM jsonb_object_keys(v) k WHERE k NOT IN
   ('resource','unit','hardLimit','softLimit','onSoftLimit','onHardLimit','exceptionOwner','companies'))
   OR v->>'unit' IS DISTINCT FROM CASE WHEN resource='durable_execution' THEN 'active_work_item' ELSE 'admitted_request' END
   OR v->>'onHardLimit' IS DISTINCT FROM CASE WHEN resource='durable_execution' THEN 'defer' ELSE 'reject' END
   OR v->>'onSoftLimit' IS DISTINCT FROM 'observe' OR jsonb_typeof(v->'exceptionOwner') IS DISTINCT FROM 'string'
   OR length(btrim(v->>'exceptionOwner')) NOT BETWEEN 1 AND 200
   OR jsonb_typeof(v->'hardLimit') IS DISTINCT FROM 'number' OR coalesce(v->>'hardLimit','') !~ '^[1-9][0-9]{0,9}$'
   OR (v->>'hardLimit')::bigint>2147483647 OR jsonb_typeof(v->'companies') IS DISTINCT FROM 'array' THEN RETURN false; END IF;
  IF v ? 'softLimit' THEN
   IF jsonb_typeof(v->'softLimit') IS DISTINCT FROM 'number' OR coalesce(v->>'softLimit','') !~ '^[1-9][0-9]{0,9}$'
    OR (v->>'softLimit')::bigint>(v->>'hardLimit')::bigint THEN RETURN false; END IF;
  END IF;
  IF jsonb_array_length(v->'companies')>10000 THEN RETURN false; END IF;
  companies:='{}';
  FOR c IN SELECT * FROM jsonb_array_elements(v->'companies') LOOP
   IF jsonb_typeof(c) IS DISTINCT FROM 'object' THEN RETURN false; END IF;
   IF EXISTS(SELECT 1 FROM jsonb_object_keys(c) k WHERE k NOT IN ('companyId','hardLimit','fairnessClass','priority'))
    OR jsonb_typeof(c->'companyId') IS DISTINCT FROM 'string' OR coalesce(c->>'companyId','') !~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    OR lower(c->>'companyId')=ANY(companies) OR jsonb_typeof(c->'hardLimit') IS DISTINCT FROM 'number'
    OR coalesce(c->>'hardLimit','') !~ '^[1-9][0-9]{0,9}$' OR (c->>'hardLimit')::bigint>2147483647
    OR jsonb_typeof(c->'fairnessClass') IS DISTINCT FROM 'string' OR length(btrim(c->>'fairnessClass')) NOT BETWEEN 1 AND 80
    OR jsonb_typeof(c->'priority') IS DISTINCT FROM 'number' OR coalesce(c->>'priority','') !~ '^-?[0-9]{1,10}$'
    OR (c->>'priority')::bigint NOT BETWEEN -2147483648 AND 2147483647 THEN RETURN false; END IF;
   companies:=array_append(companies,lower(c->>'companyId'));
  END LOOP;
 END LOOP;
 companies:='{}';
 FOR c IN SELECT * FROM jsonb_array_elements(p->'rates') LOOP
  IF jsonb_typeof(c) IS DISTINCT FROM 'object' THEN RETURN false; END IF;
  IF EXISTS(SELECT 1 FROM jsonb_object_keys(c) k WHERE k NOT IN
   ('resource','scope','companyId','hardLimit','burst','windowMs','onHardLimit','exceptionOwner'))
   OR c->>'resource' IS DISTINCT FROM 'gateway_request' OR c->>'scope' IS DISTINCT FROM 'company'
   OR c->>'onHardLimit' IS DISTINCT FROM 'reject' OR jsonb_typeof(c->'exceptionOwner') IS DISTINCT FROM 'string'
   OR length(btrim(c->>'exceptionOwner')) NOT BETWEEN 1 AND 200
   OR jsonb_typeof(c->'companyId') IS DISTINCT FROM 'string' OR coalesce(c->>'companyId','') !~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
   OR lower(c->>'companyId')=ANY(companies)
   OR jsonb_typeof(c->'hardLimit') IS DISTINCT FROM 'number' OR coalesce(c->>'hardLimit','') !~ '^[1-9][0-9]{0,9}$'
   OR jsonb_typeof(c->'burst') IS DISTINCT FROM 'number' OR coalesce(c->>'burst','') !~ '^[0-9]{1,10}$'
   OR (c->>'hardLimit')::bigint+(c->>'burst')::bigint>2147483647
   OR jsonb_typeof(c->'windowMs') IS DISTINCT FROM 'number' OR coalesce(c->>'windowMs','') !~ '^[1-9][0-9]{0,9}$'
   OR (c->>'windowMs')::bigint>2147483647 THEN RETURN false; END IF;
  companies:=array_append(companies,lower(c->>'companyId'));
 END LOOP;
 RETURN true;
EXCEPTION WHEN OTHERS THEN RETURN false;
END $$;
--> statement-breakpoint
-- Original active-work-item admission. No billing rows, queue or physical-success ledger.
CREATE FUNCTION public.aw_v10_resource_durable_occupancy(target_company uuid DEFAULT NULL)
RETURNS bigint LANGUAGE sql VOLATILE AS $$
 WITH occupied AS (
  SELECT h.company_id, 'heartbeat:'||h.id::text AS owner FROM heartbeat_runs h
  LEFT JOIN LATERAL (SELECT e.event_type FROM heartbeat_run_events e WHERE e.company_id=h.company_id
   AND e.run_id=h.id AND e.source_event_id IS NULL AND e.event_type IN
    ('native.process_start_requested','native.process_identity_recorded','native.local_process_stopped') ORDER BY e.seq DESC LIMIT 1) last_local ON true
  WHERE h.status='running' OR (h.runtime_mode='native' AND h.status NOT IN ('queued','running')
   AND (last_local.event_type IN ('native.process_start_requested','native.process_identity_recorded')
    OR ((h.process_pid IS NOT NULL OR h.process_group_id IS NOT NULL) AND last_local.event_type IS DISTINCT FROM 'native.local_process_stopped')))
  UNION
  SELECT l.company_id, CASE WHEN l.heartbeat_run_id IS NOT NULL THEN 'heartbeat:'||l.heartbeat_run_id::text
   WHEN l.metadata->>'_nativeHeartbeatRunId' ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    THEN 'heartbeat:'||(l.metadata->>'_nativeHeartbeatRunId') ELSE 'lease:'||l.id::text END
  FROM environment_leases l WHERE (l.provider_lease_id IS NOT NULL OR l.metadata->>'_nativeHostPrepareCommandId' IS NOT NULL)
   AND (l.status NOT IN ('released','expired','failed') OR l.cleanup_status IS DISTINCT FROM 'success')
  UNION ALL SELECT w.company_id, 'workflow:'||w.id::text FROM workflow_runs w WHERE w.status IN ('running','recovering','cancelling')
  UNION ALL SELECT m.company_id, 'memory:'||m.id::text FROM memory_jobs m WHERE m.status='running'
 ) SELECT count(*) FROM occupied WHERE target_company IS NULL OR company_id=target_company
$$;
--> statement-breakpoint
CREATE FUNCTION public.aw_v10_resource_durable_admission() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE policy jsonb; pool jsonb; company_rule jsonb; occupied bigint; hard_limit bigint;
BEGIN
 -- Renewal/replay, terminal cleanup, erasure and Stop are not positive work admission.
 IF NEW.status<>'running' OR (TG_OP='UPDATE' AND OLD.status IN ('running','recovering') AND OLD.company_id=NEW.company_id) THEN RETURN NEW; END IF;
 IF TG_TABLE_NAME='memory_jobs' THEN
  IF NEW.operation_type='retention' THEN RETURN NEW; END IF;
 END IF;
 SELECT general->'resourceGovernance' INTO policy FROM instance_settings WHERE singleton_key='default' FOR SHARE;
 IF policy IS NULL THEN RETURN NEW; END IF;
 IF NOT public.aw_v10_resource_policy_valid(policy) THEN RAISE EXCEPTION 'resource_policy_invalid' USING ERRCODE='23514'; END IF;
 IF jsonb_typeof(policy) IS DISTINCT FROM 'object' OR policy->>'version' IS DISTINCT FROM '1' OR jsonb_typeof(policy->'pools') IS DISTINCT FROM 'array' THEN
  RAISE EXCEPTION 'resource_policy_invalid' USING ERRCODE='23514'; END IF;
 IF (SELECT count(*) FROM jsonb_array_elements(policy->'pools') p WHERE p->>'resource'='durable_execution')>1 THEN
  RAISE EXCEPTION 'resource_policy_invalid' USING ERRCODE='23514'; END IF;
 SELECT p INTO pool FROM jsonb_array_elements(policy->'pools') p WHERE p->>'resource'='durable_execution';
 IF pool IS NULL THEN RETURN NEW; END IF;
 IF pool->>'unit' IS DISTINCT FROM 'active_work_item' OR pool->>'onHardLimit' IS DISTINCT FROM 'defer' OR pool->>'onSoftLimit' IS DISTINCT FROM 'observe'
  OR coalesce(pool->>'exceptionOwner','')='' OR jsonb_typeof(pool->'companies') IS DISTINCT FROM 'array'
  OR jsonb_typeof(pool->'hardLimit') IS DISTINCT FROM 'number' OR coalesce(pool->>'hardLimit','') !~ '^[1-9][0-9]{0,9}$' OR (pool->>'hardLimit')::bigint>2147483647 THEN
  RAISE EXCEPTION 'resource_policy_invalid' USING ERRCODE='23514'; END IF;
 IF current_setting('transaction_isolation')<>'read committed' THEN RAISE EXCEPTION 'resource_admission_requires_read_committed' USING ERRCODE='23514'; END IF;
 -- All three ORIGINAL owners serialize the final admission and original row CAS.
 -- Do not wait while holding original row/privacy locks: contention defers
 -- the original row, avoiding an owner-row/global-fence inversion. Volatile
 -- occupancy reads use the current READ COMMITTED snapshot.
 IF NOT pg_try_advisory_xact_lock(740020,1) THEN
  RAISE EXCEPTION 'resource_durable_execution_deferred' USING ERRCODE='P0001';
 END IF;
 hard_limit := (pool->>'hardLimit')::bigint;
 occupied := public.aw_v10_resource_durable_occupancy(NULL);
 IF occupied>=hard_limit THEN RAISE EXCEPTION 'resource_durable_execution_deferred' USING ERRCODE='P0001'; END IF;
 IF (SELECT count(*) FROM jsonb_array_elements(pool->'companies') c WHERE lower(c->>'companyId')=NEW.company_id::text)>1 THEN
  RAISE EXCEPTION 'resource_policy_invalid' USING ERRCODE='23514'; END IF;
 SELECT c INTO company_rule FROM jsonb_array_elements(pool->'companies') c WHERE lower(c->>'companyId')=NEW.company_id::text;
 IF company_rule IS NOT NULL THEN
  IF jsonb_typeof(company_rule->'hardLimit') IS DISTINCT FROM 'number' OR coalesce(company_rule->>'hardLimit','') !~ '^[1-9][0-9]{0,9}$' OR (company_rule->>'hardLimit')::bigint>2147483647 THEN
   RAISE EXCEPTION 'resource_policy_invalid' USING ERRCODE='23514'; END IF;
  IF public.aw_v10_resource_durable_occupancy(NEW.company_id)>=(company_rule->>'hardLimit')::bigint THEN
   RAISE EXCEPTION 'resource_durable_execution_deferred' USING ERRCODE='P0001'; END IF;
 END IF;
 IF pool ? 'softLimit' THEN
  IF jsonb_typeof(pool->'softLimit') IS DISTINCT FROM 'number' OR coalesce(pool->>'softLimit','') !~ '^[1-9][0-9]{0,9}$'
   OR (pool->>'softLimit')::bigint>hard_limit THEN RAISE EXCEPTION 'resource_policy_invalid' USING ERRCODE='23514'; END IF;
  IF occupied+1>=(pool->>'softLimit')::bigint THEN
   INSERT INTO activity_log(company_id,actor_type,actor_id,action,entity_type,entity_id,details)
   VALUES(NEW.company_id,'system','resource-governance','resource.admission_soft_limit',TG_TABLE_NAME,NEW.id::text,
    jsonb_build_object('resource','durable_execution','unit','active_work_item'));
  END IF;
 END IF;
 RETURN NEW;
END $$;
--> statement-breakpoint
CREATE TRIGGER aw_v10_resource_heartbeat_admission BEFORE INSERT OR UPDATE ON heartbeat_runs FOR EACH ROW EXECUTE FUNCTION public.aw_v10_resource_durable_admission();
--> statement-breakpoint
CREATE TRIGGER aw_v10_resource_workflow_admission BEFORE INSERT OR UPDATE ON workflow_runs FOR EACH ROW EXECUTE FUNCTION public.aw_v10_resource_durable_admission();
--> statement-breakpoint
CREATE TRIGGER aw_v10_resource_memory_admission BEFORE INSERT OR UPDATE ON memory_jobs FOR EACH ROW EXECUTE FUNCTION public.aw_v10_resource_durable_admission();
