# Managed starter composite qualification — 2026-10-30

This folder preserves the existing r33 qualification and a focused patch for the managed starter composite change. No 119-test rerun was performed during this review.

## Qualification

- `v10-118-agent-packages-full-r33-20261030-test.log`: full `v7-agent-packages.integration.test.ts` cohort passed, 119/119 in 171.94s. It includes the managed starter browser journey, activation read-lock regression, and package fixture cases.
- The browser journey uses the authenticated UI, starts the first task through the activation endpoint, drains the original Native runner, observes the persisted succeeded run and saved document, records a human review through the UI, records and completes activation, submits support intake, then reloads the completed activation. Its model transport is deterministic and local to the software fixture; it does not establish live provider qualification or customer acceptance.
- `v10-118-agent-packages-full-r33-20261030-syntax.log`: Vite/Oxc parsed 962 files successfully. Snapshot, syntax, and test exit receipts are `0`.
- Static UI build passed. `v10-118-agent-packages-full-r33-20261030-ui-build-inputs-verified.log` records 5,999 verified inputs; UI build exit is `0`. The build log has a chunk-size advisory, but completed successfully.
- `token-gates-2026-10-30.log`: `node scripts/check-token-gates.mjs` passed on this checkout after review (1,452 files; all gates clean). The wrapper `pnpm check:token-gates` also passed, including palette and ClipLab sync checks. `token-gates-source-pins.json` pins every scanned TS/TSX/JS/JSX file plus the scanner, allowlist CSS, and package manifest.
- `prior-token-gate-receipt-2026-10-25.log` is retained as historical context only; the 2026-10-30 check above is the applicable receipt.

## Source identity and reconstruction

`qualified-source-matches.tsv` compares each of the eight proposed source files against both the r33 integration-test source pin and the r33 static-build source pin. All eight current SHA-256 hashes match both receipts.

`reconstruction/managed-starter-composite.patch` is the focused current diff for the eight files in `stage-list.txt`. The complete r33 reconstruction pin and patch are preserved beside captured source files. `qualification-newfiles.tar.gz` preserves the run's captured untracked source files needed to reconstruct its broader qualification snapshot; those files are not part of this composite's proposed commit.

The qualification runner used the pinned OpenCode binary whose path and SHA-256 are recorded in `v10-118-agent-packages-full-r33-20261030-binary.*`. `source-pins.json` records the qualification base and captured source hashes. Static build pins, input manifest, build log, and distribution hashes are also included.

## Proposed stage set

See `stage-list.txt` for the exact eight paths. Do not stage `server/src/middleware/error-handler.ts` as part of this change: its current diff handles resource-governance admission and the activation busy conversion is implemented in the activation owner/service. Other unstaged repository changes are outside this composite.

No files were staged or committed during this review.
