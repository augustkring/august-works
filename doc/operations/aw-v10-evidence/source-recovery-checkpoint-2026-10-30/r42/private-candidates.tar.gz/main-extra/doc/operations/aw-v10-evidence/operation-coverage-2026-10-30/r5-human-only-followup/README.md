# V10 operation inventory HumanOnly followup, 2026-10-30

This receipt records the published-source inventory update for the responsibility-contact UI call and the callsite-specific company-update authorization review.

The responsibility-contact PATCH admits same-company CEO Agents through `assertCompanyDefaultsAdmin`; the additional owner/admin membership condition is Board-specific. The UI call is therefore `AGENT_ACCESSIBLE_UNMAPPED`, with no Agent tool/API manifest mapping. The route only labels active verified Human members as contacts; that label grants no permission.

Company update calls are classified by their actual payload. Branding payloads accepted by the strict Agent schema remain `DIRECT_AGENT`; general settings, governance/approval, and reactivation payloads with fields outside that schema are `HUMAN_ONLY`. The private 0566 feedback sidecar endpoints are not included: their source is pending qualification and publication.

Canonical gates run from `/workspace/blentera-v10`:

- `pnpm check:aw-v10-operation-coverage` — exit 0; 6 Agent tool operations, 159 unqualified existing API-only contracts, 997 exact mounted UI callsites.
- `pnpm test:aw-v10-operation-coverage` — exit 0; 12 passed, 0 failed.
- `git diff --check -- doc/operations/agent-native-ui-operation-coverage.json` — exit 0.

Runner scope is limited to the canonical mounted UI operation inventory checker and its unit tests. No mirror, database, build, or heavy suite was run.
