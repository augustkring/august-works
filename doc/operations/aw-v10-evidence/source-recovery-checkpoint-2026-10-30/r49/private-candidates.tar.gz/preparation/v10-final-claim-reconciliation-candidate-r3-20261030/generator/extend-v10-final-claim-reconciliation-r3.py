import hashlib, json, pathlib, shutil, subprocess, tarfile

PREP = pathlib.Path('/workspace/v10-preparation')
ROOT = pathlib.Path('/workspace/blentera-v10')
OUT = PREP / 'v10-final-claim-reconciliation-candidate-r3-20261030'
R2 = PREP / 'v10-final-claim-reconciliation-candidate-r2-20261030'

# The R3 builder and portable refresher run first. This extension only adds the
# supplemental implementation lane to those freshly generated R3 artifacts.


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pin(path):
    p = pathlib.Path(path)
    return {'path': str(p), 'state': 'present_at_r3_snapshot' if p.is_file() else 'not_present_at_r3_snapshot',
            'sha256': sha(p) if p.is_file() else None}

# Receipt inputs copied into source-bundle/implementation-updates/. These are the
# evidence and source snapshots themselves, not product acceptance claims.
inputs = {
 '/workspace/blentera-v10/doc/operations/aw-v10-evidence/openshell-resource-credential-binding-qualified-2026-10-30/README.md':'source-bundle/implementation-updates/resource-r6/README.md',
 '/workspace/blentera-v10/doc/operations/aw-v10-evidence/openshell-resource-credential-binding-qualified-2026-10-30/manifest.json':'source-bundle/implementation-updates/resource-r6/manifest.json',
 '/workspace/blentera-v10/doc/operations/aw-v10-evidence/openshell-resource-credential-binding-qualified-2026-10-30/qualification.tar.gz':'source-bundle/implementation-updates/resource-r6/qualification.tar.gz',
 '/workspace/blentera-v10/doc/operations/aw-v10-evidence/openshell-rt01-identity-api-qualified-2026-10-30/README.md':'source-bundle/implementation-updates/rt01-api-r4/README.md',
 '/workspace/blentera-v10/doc/operations/aw-v10-evidence/openshell-rt01-identity-api-qualified-2026-10-30/manifest.json':'source-bundle/implementation-updates/rt01-api-r4/manifest.json',
 '/workspace/blentera-v10/doc/operations/aw-v10-evidence/openshell-rt01-identity-api-qualified-2026-10-30/qualification.tar.gz':'source-bundle/implementation-updates/rt01-api-r4/qualification.tar.gz',
 '/workspace/v10-preparation/openshell-rt01-r4-qualification-evidence-candidate/README.md':'source-bundle/implementation-updates/rt01-api-r4/raw-artifact-README.md',
 '/workspace/v10-preparation/openshell-rt01-r4-qualification-evidence-candidate/run.json':'source-bundle/implementation-updates/rt01-api-r4/run.json',
 '/workspace/v10-preparation/openshell-rt01-r4-qualification-evidence-candidate/source-pins.json':'source-bundle/implementation-updates/rt01-api-r4/source-pins.json',
 '/workspace/v10-preparation/openshell-rt01-r4-qualification-evidence-candidate/openshell-rt01-r4-qualification-logs.zip':'source-bundle/implementation-updates/rt01-api-r4/full-workflow-artifact.zip',
 '/workspace/v10-preparation/qualification-capability-clock-r2/qualification/overlay-pins.json':'source-bundle/implementation-updates/qualification-clock-r2/overlay-pins.json',
 '/workspace/v10-preparation/qualification-capability-clock-r2/qualification/source-pins.json':'source-bundle/implementation-updates/qualification-clock-r2/source-pins.json',
 '/workspace/v10-preparation/qualification-capability-clock-r2/qualification/source-pins.source.patch':'source-bundle/implementation-updates/qualification-clock-r2/source-pins.source.patch',
 '/workspace/v10-preparation/qualification-capability-clock-r2/qualification/focused-tests.log':'source-bundle/implementation-updates/qualification-clock-r2/focused-tests.log',
 '/workspace/v10-preparation/qualification-capability-clock-r2/qualification/focused-tests.exit':'source-bundle/implementation-updates/qualification-clock-r2/focused-tests.exit',
 '/workspace/v10-preparation/qualification-capability-clock-r2/qualification/server-typecheck.log':'source-bundle/implementation-updates/qualification-clock-r2/server-typecheck.log',
 '/workspace/v10-preparation/qualification-capability-clock-r2/qualification/server-typecheck.exit':'source-bundle/implementation-updates/qualification-clock-r2/server-typecheck.exit',
 '/workspace/v10-preparation/qualification-capability-clock-r2/qualification/restore.json':'source-bundle/implementation-updates/qualification-clock-r2/restore.json',
 '/workspace/v10-preparation/qualification-capability-clock-r2/prior-attempt.json':'source-bundle/implementation-updates/qualification-clock-r2/prior-attempt.json',
 '/workspace/blentera-v10/doc/operations/aw-v10-evidence/sandbox-qualification-report-timestamps-2026-10-30/README.md':'source-bundle/implementation-updates/qualification-clock-r2/README.md',
 '/workspace/blentera-v10/doc/operations/aw-v10-evidence/sandbox-qualification-report-timestamps-2026-10-30/manifest.json':'source-bundle/implementation-updates/qualification-clock-r2/manifest.json',
 '/workspace/blentera-v10/doc/operations/aw-v10-evidence/sandbox-qualification-report-timestamps-2026-10-30/qualification.tar.gz':'source-bundle/implementation-updates/qualification-clock-r2/qualification.tar.gz',
 '/workspace/v10-preparation/openshell-r5-qualification-evidence-candidate/source-smoke.txt':'source-bundle/implementation-updates/vendor-r5/source-smoke.txt',
 '/workspace/blentera-v10/third_party/openshell/rt01/openshell-rt01.patch':'source-bundle/implementation-updates/vendor-r5/openshell-rt01.patch',
 '/workspace/blentera-v10/third_party/openshell/rt01/source-pins.json':'source-bundle/implementation-updates/vendor-r5/source-pins.json',
 '/workspace/blentera-v10/doc/operations/aw-v10-evidence/model-authority-watch-drain-qualified-2026-10-30/README.md':'source-bundle/implementation-updates/model-watch/README.md',
 '/workspace/blentera-v10/doc/operations/aw-v10-evidence/model-authority-watch-drain-qualified-2026-10-30/SHA256SUMS':'source-bundle/implementation-updates/model-watch/SHA256SUMS',
 '/workspace/blentera-v10/doc/operations/aw-v10-evidence/model-authority-watch-drain-qualified-2026-10-30/qualification.tar.gz':'source-bundle/implementation-updates/model-watch/qualification.tar.gz',
 '/workspace/v10-preparation/native-node-work-r60-candidate/manifest.json':'source-bundle/implementation-updates/native-r60/manifest.json',
 '/workspace/v10-preparation/native-node-work-r60-candidate/candidate.diff':'source-bundle/implementation-updates/native-r60/candidate.diff',
 '/workspace/v10-preparation/native-final-clean-candidate-regenerated-r60.json':'source-bundle/implementation-updates/native-r60/clean-candidate-map.json',
 '/workspace/v10-preparation/native-graph-ledger-handoff-20261030.md':'source-bundle/implementation-updates/native-r60/owner-handoff.md',
 '/workspace/v10-preparation/v10-149-native-provision-r1/files/packages/db/src/schema/execution_sandbox.ts':'source-bundle/implementation-updates/native-provision-r12/packages/db/src/schema/execution_sandbox.ts',
 '/workspace/v10-preparation/v10-149-native-provision-r1/files/packages/shared/src/execution-sandbox.ts':'source-bundle/implementation-updates/native-provision-r12/packages/shared/src/execution-sandbox.ts',
 '/workspace/v10-preparation/v10-149-native-provision-r1/files/packages/shared/src/sandbox-host-contracts.ts':'source-bundle/implementation-updates/native-provision-r12/packages/shared/src/sandbox-host-contracts.ts',
 '/workspace/v10-preparation/v10-149-native-provision-r1/files/server/src/services/execution-sandbox/sandbox-service.ts':'source-bundle/implementation-updates/native-provision-r12/server/src/services/execution-sandbox/sandbox-service.ts',
 '/workspace/v10-preparation/v10-149-native-provision-r1/files/server/src/services/execution-sandbox/openshell-policy.ts':'source-bundle/implementation-updates/native-provision-r12/server/src/services/execution-sandbox/openshell-policy.ts',
 '/workspace/v10-preparation/v10-149-native-provision-r1/files/server/src/services/execution-sandbox/qualification.ts':'source-bundle/implementation-updates/native-provision-r12/server/src/services/execution-sandbox/qualification.ts',
 '/workspace/v10-preparation/v10-149-native-provision-r1/files/server/src/services/execution-sandbox/openshell-backend.ts':'source-bundle/implementation-updates/native-provision-r12/server/src/services/execution-sandbox/openshell-backend.ts',
 '/workspace/v10-preparation/v10-149-native-provision-r1/files/server/src/services/execution-sandbox/backend.ts':'source-bundle/implementation-updates/native-provision-r12/server/src/services/execution-sandbox/backend.ts',
 '/workspace/v10-preparation/v10-149-native-provision-r1/files/server/src/services/execution-sandbox/native-host-bridge.ts':'source-bundle/implementation-updates/native-provision-r12/server/src/services/execution-sandbox/native-host-bridge.ts',
 '/workspace/blentera-v10/scripts/check-v10-safe-change-graph.mjs':'source-bundle/qualification-guards/check-v10-safe-change-graph.mjs',
 '/workspace/blentera-v10/scripts/generate-v10-safe-change-graph.mjs':'source-bundle/qualification-guards/generate-v10-safe-change-graph.mjs',
 '/workspace/blentera-v10/doc/operations/v10-safe-change-graph.source.json':'source-bundle/qualification-guards/v10-safe-change-graph.source.json',
 '/workspace/blentera-v10/doc/operations/v10-safe-change-graph.json':'source-bundle/qualification-guards/v10-safe-change-graph.json',
 '/workspace/blentera-v10/scripts/check-v10-169-migration-phase-register.mjs':'source-bundle/qualification-guards/check-v10-169-migration-phase-register.mjs',
 '/workspace/blentera-v10/scripts/check-aw-v10-operation-coverage.mjs':'source-bundle/qualification-guards/check-aw-v10-operation-coverage.mjs',
 '/workspace/blentera-v10/scripts/aw-v9-release-prerequisites.mjs':'source-bundle/qualification-guards/aw-v9-release-prerequisites.mjs',
 '/workspace/blentera-v10/doc/operations/aw-v10-evidence/v10-169-migration-phases-current-2026-10-30/README.md':'source-bundle/qualification-guards/current-phase-matrix-README.md',
 '/workspace/blentera-v10/doc/operations/aw-v10-evidence/v10-169-migration-phases-current-2026-10-30/phase-matrix.json':'source-bundle/qualification-guards/current-phase-matrix.json',
 '/workspace/blentera-v10/doc/operations/aw-v10-evidence/source-recovery-checkpoint-2026-10-30/r48/README.md':'source-bundle/qualification-guards/root-source-recovery-r48-README.md',
 '/workspace/blentera-v10/doc/operations/aw-v10-evidence/source-recovery-checkpoint-2026-10-30/r48/manifest.json':'source-bundle/qualification-guards/root-source-recovery-r48-manifest.json',
}

# Extract the exact qualified source members and hash pins from the Resource R6 receipt.
resource_manifest_path = ROOT / 'doc/operations/aw-v10-evidence/openshell-resource-credential-binding-qualified-2026-10-30/manifest.json'
resource_manifest = json.load(open(resource_manifest_path))
resource_source_members=[]
for item in resource_manifest.get('files',[]):
    p=item.get('path','')
    if p.startswith('candidate-r6/files/'):
        repo_path=p[len('candidate-r6/files/'):]
        current=ROOT/repo_path
        resource_source_members.append({'repositoryPath':repo_path,
          'qualifiedSnapshotSha256':item['sha256'],
          'currentRepositoryPin':{'path':repo_path,'state':'present_at_r3_snapshot','sha256':sha(current)} if current.is_file() else {'path':repo_path,'state':'not_present_at_r3_snapshot','sha256':None},
          'qualificationArchiveMember':p})

updates = [
 {'id':'V10-149-R6-resource-and-broker-binary','owner':'Resource / execution-sandbox and broker owners','currentImplementationUpdate':'The R6 source snapshot carries CPU/memory/PID limits through native host admission and observes the immutable Docker container ID; resolved credential binaries are checked against the complete compiled/provider profile at apply/use. This is a bounded implementation update, not physical host qualification.','supportingV7BlockerIds':['native_openshell_host_bridge','credential_use_broker_and_revocation'],'state':'bounded_source_and_local_qualification_receipt; affected profiles remain closed','sourceSnapshot':{'repositoryHead':'receipt-pinned candidate snapshot; see qualification archive','sourceFiles':resource_source_members},'qualification':{'hostAgentMockedTestsPassed':30,'authAndPolicyTestsPassed':66,'actualPolicyProverBackendPassed':8,'actualPolicyProverSkipped':0,'brokerResolverPassed':1,'sandboxHostPostgresPassed':13,'sharedTypecheck':'passed','serverTypecheck':'passed at R5; R6 changed only backend-test expected resource constants'},'receiptInputs':[pin(resource_manifest_path),pin(resource_manifest_path.parent/'README.md'),pin(resource_manifest_path.parent/'qualification.tar.gz')],'limits':['No actual Docker/kernel/target-host qualification.','Credential lifetime, lifecycle/name replacement, disk quota, arbitrary syscall enforcement and physical stop remain distinct open boundaries.','No production deployment, hosted acceptance, Human acceptance or release-profile closure.']},
 {'id':'V10-149-RT01-API-R4-nine-Rust-tests','owner':'RT-01 API / Native host API owner','currentImplementationUpdate':'The exact upstream R4 workflow artifact records generated-protobuf/server/CLI cargo check plus nine filtered Rust tests, all passing, against the declared source commit and cumulative vendor patch. This adds scoped source/CI evidence only.','supportingV7BlockerIds':['native_openshell_host_bridge'],'state':'bounded_upstream_workflow_qualification; separate target-host and compatibility limits remain','sourceSnapshot':{'qualifiedRepositoryHead':'4ed298feacdc4f287608b5d392eeeb77a26ff671','vendorPatchSha256':'e28fc7fc8b860df810e7bf7337f59a53f2348e3595af6c883992d4ea09bc27d7','workflowRun':41038249001,'job':124004345291,'exactRustTestsPassed':9,'fullRawArtifactIncluded':True},'receiptInputs':[pin(ROOT/'doc/operations/aw-v10-evidence/openshell-rt01-identity-api-qualified-2026-10-30/manifest.json'),pin(ROOT/'doc/operations/aw-v10-evidence/openshell-rt01-identity-api-qualified-2026-10-30/README.md'),pin(ROOT/'doc/operations/aw-v10-evidence/openshell-rt01-identity-api-qualified-2026-10-30/qualification.tar.gz'),pin(PREP/'openshell-rt01-r4-qualification-evidence-candidate/run.json'),pin(PREP/'openshell-rt01-r4-qualification-evidence-candidate/openshell-rt01-r4-qualification-logs.zip')],'limits':['Scoped upstream compile and nine tests only.','Does not establish old-gateway compatibility, physical target-host behavior, production profile admission, or whole V10 qualification.']},
 {'id':'V10-149-qualification-report-clock-r2','owner':'Sandbox qualification-report clock owner','currentImplementationUpdate':'The report freshness/expiry fix passed 51 focused fault cases and a full server typecheck at its exact source head. The preserved expiry/target-evidence tests remain scoped source qualification, not live host attestations.','supportingV7BlockerIds':['native_openshell_host_bridge'],'state':'bounded_source_and_local_qualification_passed; no physical host qualification','sourceSnapshot':{'sourceHead':'93a57970ea7a3b5bd6801c5684028b4857370bf7','qualificationOverlay':json.load(open(PREP/'qualification-capability-clock-r2/qualification/overlay-pins.json')),'focusedTestsPassed':51,'serverTypecheckExit':0},'receiptInputs':[pin(PREP/'qualification-capability-clock-r2/qualification/overlay-pins.json'),pin(PREP/'qualification-capability-clock-r2/qualification/source-pins.json'),pin(PREP/'qualification-capability-clock-r2/qualification/focused-tests.log'),pin(PREP/'qualification-capability-clock-r2/qualification/server-typecheck.log'),pin(PREP/'qualification-capability-clock-r2/qualification/restore.json'),pin(ROOT/'doc/operations/aw-v10-evidence/sandbox-qualification-report-timestamps-2026-10-30/manifest.json'),pin(ROOT/'doc/operations/aw-v10-evidence/sandbox-qualification-report-timestamps-2026-10-30/qualification.tar.gz')],'limits':['No actual host observations or physical sandbox enforcement.','The source head and overlay are historical to this receipt; do not infer current final-source qualification.']},
 {'id':'V10-149-cumulative-vendor-r5','owner':'RT-01 vendor / OpenShell integration owner','currentImplementationUpdate':'The cumulative vendor patch source smoke verified formatting, clean-clone application and all 23 patched-file pins. The owner reports a four-package / 15-test CI scope on run 41042077640 as pending; no pass is recorded here.','supportingV7BlockerIds':['native_openshell_host_bridge','credential_use_broker_and_revocation'],'state':'source-smoke-passed; current-CI-run-pending','sourceSnapshot':{'reportedCurrentSourceCommitShort':'169f1b6de','reportedCurrentCommitSource':'owner status update; short identifier retained as supplied','upstreamBase':'6648bd0c290efbc41ba131ee9831ee45cd431f94','cumulativeVendorPatchSha256':'04e0e056d3187ea39c5171f1d6e254d6e2c73e786a3d380c0e6d0995f11bf12e','sourcePinsSha256':'7c48738c8872151ace5cb6c217a98e8881c7199b853028482d45aff493aff6db','cleanClonePatchAndPinSmoke':'passed','currentCiRun':41042077640,'currentCiStatus':'pending','reportedCiScope':{'packages':4,'tests':15,'qualificationStatus':'pending_not_passed'}},'receiptInputs':[pin(PREP/'openshell-r5-qualification-evidence-candidate/source-smoke.txt'),pin(ROOT/'third_party/openshell/rt01/openshell-rt01.patch'),pin(ROOT/'third_party/openshell/rt01/source-pins.json')],'limits':['The local smoke is not Rust compilation or test qualification.','Run 41042077640 is pending; four-package/15-test scope is reported by the owner but is not a pass.','No physical host, production, Human or release profile acceptance.']},
 {'id':'V10-149-model-authority-watch-drain','owner':'Model authority / Tool Gateway owner','currentImplementationUpdate':'Both model transports await in-flight periodic authority checks before final checks/replies and cleanup. Three focused gateway regressions cover normal completion, membership revocation and provider failure. This receipt explicitly does not claim a complete Native-wide suite.','supportingV7BlockerIds':['pre_spend_model_reservation'],'state':'bounded_gateway_source_and_focused_tests_passed; whole-Native pending','receiptInputs':[pin(ROOT/'doc/operations/aw-v10-evidence/model-authority-watch-drain-qualified-2026-10-30/README.md'),pin(ROOT/'doc/operations/aw-v10-evidence/model-authority-watch-drain-qualified-2026-10-30/SHA256SUMS'),pin(ROOT/'doc/operations/aw-v10-evidence/model-authority-watch-drain-qualified-2026-10-30/qualification.tar.gz')],'qualification':{'focusedGatewayRegressionsPassed':3,'NativeWide':'not qualified by this receipt'},'limits':['Does not resolve Native-wide fixture/context deadline or prior skipped cohort.','No provider/hosted production, financial outcome, Human or release acceptance.']},
 {'id':'V10-149-native-r60-and-r12-open-work','owner':'Native source / RT-01 provision owners','currentImplementationUpdate':'R60 diagnostic work and R12 probe/provision changes remain private candidates. Per current owner status, the latest completed Native-wide result remains 1 passed / 8 skipped from R59; R60 is not a complete replacement cohort. These candidate files are navigation and pending work only.','supportingV7BlockerIds':['native_openshell_host_bridge','pre_spend_model_reservation'],'state':'private_candidate_pending; no new completed Native-wide qualification','sourceSnapshot':{'nativeR60Manifest':pin(PREP/'native-node-work-r60-candidate/manifest.json'),'nativeR60Diff':pin(PREP/'native-node-work-r60-candidate/candidate.diff'),'nativeR60CleanCandidateMap':pin(PREP/'native-final-clean-candidate-regenerated-r60.json'),'nativeR12ProvisionSourceFiles':[pin(p) for p in sorted((PREP/'v10-149-native-provision-r1/files').rglob('*')) if p.is_file()]},'receiptInputs':[pin(PREP/'native-graph-ledger-handoff-20261030.md')],'limits':['R60 is diagnostic/private and has no complete qualifying nine-case result.','R12 probe/provision work is private and pending.','Do not infer Native closure, physical target-host acceptance, or a passed current aggregate.']},
]

# Root-maintained guards are supplied as provenance for the final qualification path,
# not as evidence that the aggregate or release preflight has already passed.
guard_paths = [
 ROOT/'scripts/check-v10-safe-change-graph.mjs',
 ROOT/'scripts/generate-v10-safe-change-graph.mjs',
 ROOT/'doc/operations/v10-safe-change-graph.source.json',
 ROOT/'doc/operations/v10-safe-change-graph.json',
 ROOT/'scripts/check-v10-169-migration-phase-register.mjs',
 ROOT/'scripts/check-aw-v10-operation-coverage.mjs',
 ROOT/'scripts/aw-v9-release-prerequisites.mjs',
 ROOT/'doc/operations/aw-v10-evidence/v10-169-migration-phases-current-2026-10-30/README.md',
 ROOT/'doc/operations/aw-v10-evidence/v10-169-migration-phases-current-2026-10-30/phase-matrix.json',
 ROOT/'doc/operations/aw-v10-evidence/source-recovery-checkpoint-2026-10-30/r48/README.md',
 ROOT/'doc/operations/aw-v10-evidence/source-recovery-checkpoint-2026-10-30/r48/manifest.json',
]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
guards=[]
for p in guard_paths:
    rel=p.relative_to(ROOT).as_posix()
    try:
        committed_sha=subprocess.check_output(['git','rev-parse',f'HEAD:{rel}'],cwd=ROOT,text=True,stderr=subprocess.DEVNULL).strip()
    except subprocess.CalledProcessError:
        committed_sha=None
    current=pin(p)
    guards.append({'sourcePin':current,'committedHeadPin':{'repositoryHead':head,'path':rel,'sha256':committed_sha},'worktreeMatchesCommittedHead':bool(committed_sha and current.get('sha256')==committed_sha),'role':'current aggregate/source/release preflight guard; navigation/provenance only','qualificationClaim':'none'})

report=json.load(open(OUT/'reconciliation.json'))
launch=json.load(open(OUT/'launch-claim-matrix.json'))
report['kind']='private-v10-final-cross-version-and-launch-claim-reconciliation-candidate-r3'
report['status']='candidate_r3_supplemental_updates_pending_owner_and_final_source_review'
row149=next(r for r in report['rows'] if r['id']=='V10-149')
launch149=next(r for r in launch['rows'] if r['v10RequirementId']=='V10-149')
row149['supplementalCurrentImplementationUpdates']=[u['id'] for u in updates]
launch149['supplementalCurrentImplementationUpdateReferences']=[u['id'] for u in updates]
report['currentImplementationUpdates']={
 'schemaVersion':1,
 'lane':'supplemental current source-backed implementation and qualification updates; distinct from historical 169-status register and semantic predecessor crosswalk',
 'requirementId':'V10-149',
 'sourceFreeze':'interim_snapshot; R60/R12 private changes remain pending; refresh after final source freeze',
 'updates':updates,
 'rootQualificationGuards':guards,
 'invariants':['Historical 169 statuses are preserved exactly.','No existing currentOwnerPaths are replaced or narrowed.','No semantic predecessor links are added; the only exact links remain the three incomplete V7 blockers to V10-149.','A scoped local/upstream receipt does not imply physical host, production, external Human, hosted, or release-profile acceptance.','The cumulative vendor R5 CI run is pending and is not represented as passing.'],
}
for deliverable in report.get('explicitReportDeliverables',[]):
    if deliverable.get('id')=='V10-001':
        deliverable['status']='reviewable_r3_draft_owner_review_and_final_source_pins_pending'
        deliverable['currentRead']='The R3 draft adds a distinct source-backed V10-149 update lane to the 169-row current-owner/evidence matrix. Historical statuses and release gates remain unchanged; final source freeze and owner approval remain pending.'
    elif deliverable.get('id')=='V10-003':
        deliverable['status']='reviewable_r3_launch_claim_matrix_owner_review_and_release_evidence_pending'
        deliverable['currentRead']='The R3 matrix includes supplemental scoped implementation/qualification updates while separating their source pins and test scopes from Native-wide, Human, hosted, production, and release-profile acceptance.'
    elif deliverable.get('id')=='V10-149':
        deliverable['status']='supplemental_scoped_updates_recorded; Native_and_vendor_CI_pending; owner_closure_open'
        deliverable['currentRead']='R3 records bounded resource/broker, API, qualification-clock and model-watch receipts, plus a pending vendor CI run and private Native/R12 work. These updates do not close all three implementation groups or H6/H7 Human/operator gates.'
    elif deliverable.get('id')=='V10-157':
        deliverable['status']='reviewable_r3_exact_predecessor_traceability_draft; frozen_receipts_and_owner_review_pending'
        deliverable['currentRead']='The exact V6/V7/V8/V9 traceability and 169 V10 rows remain intact. R3 adds a separate V10-149 evidence lane; no predecessor semantic mappings or acceptance states are inferred from it.'
report['crossCuttingQualificationBlockers']['nativeWide']={
 'status':'pending_not_green',
 'latestCompletedAttempt':'Native R59 per current Native owner report',
 'reportedResult':'1 passed and 8 skipped; this is not a complete Native-wide cohort.',
 'currentDiagnostic':'Native R60 is diagnostic/private and does not supply a new complete nine-case result. R12 probes/provision remain private and pending.',
 'sourceNavigation':[pin(PREP/'native-node-work-r60-candidate/manifest.json'),pin(PREP/'native-node-work-r60-candidate/candidate.diff')],
 'qualificationBoundary':'Keep Native-wide qualification open. The scoped R6/R4/clock/model-watch receipts above do not substitute for the complete current Native cohort.'
}
# Preserve all historical status cells and do not change the three exact predecessor links.
assert len(report['rows'])==169 and all(r['historicalStatusUnchanged'] for r in report['rows'])
assert len(launch['rows'])==169 and sum(len(r['exactSemanticPredecessorClaims']) for r in launch['rows'])==3
assert len(next(r for r in launch['rows'] if r['v10RequirementId']=='V10-149')['exactSemanticPredecessorClaims'])==3
# Replace host-local absolute receipt locations with their portable bundle paths.
input_relative={original:relative for original,relative in inputs.items()}
def portable_receipt_pin(item):
    original=item['path']
    if original in input_relative:
        item['path']=input_relative[original]
        item['state']='bundled_at_r3_snapshot'
    return item
for update in report['currentImplementationUpdates']['updates']:
    update['receiptInputs']=[portable_receipt_pin(dict(x)) for x in update.get('receiptInputs',[])]
    if 'sourceSnapshot' in update:
        snap=update['sourceSnapshot']
        if 'nativeR60Manifest' in snap:
            for key in ['nativeR60Manifest','nativeR60Diff','nativeR60CleanCandidateMap']:
                item=snap[key]; original=item['path']; item['path']=input_relative.get(original,original); item['state']='bundled_at_r3_snapshot'
            for item in snap['nativeR12ProvisionSourceFiles']:
                original=item['path']; item['path']=input_relative.get(original,original); item['state']='bundled_at_r3_snapshot'
for item in report['currentImplementationUpdates']['rootQualificationGuards']:
    original=item['sourcePin']['path']; item['sourcePin']['path']=input_relative.get(original,'source-bundle/qualification-guards/'+pathlib.Path(original).name); item['sourcePin']['state']='bundled_guard_source_at_r3_snapshot'
native_paths={original:relative for original,relative in inputs.items() if 'native-r60/' in relative or 'native-provision-r12/' in relative}
for item in report['crossCuttingQualificationBlockers']['nativeWide']['sourceNavigation']:
    original=item['path']; item['path']=native_paths.get(original,original); item['state']='bundled_private_navigation_at_r3_snapshot'
report['currentImplementationUpdates']['artifactPath']='source-bundle/implementation-updates/v10-149-current-implementation-updates.json'
launch['generatedBy']='existing V10 final claim reconciliation builder R3; historical R2 rows plus supplemental V10-149 update references'
report['launchClaimMatrix']['artifactPath']='source-bundle/traceability/launch-claim-matrix.json'
report['launchClaimMatrix']['artifactSha256']=hashlib.sha256(json.dumps(launch['rows'],indent=2,ensure_ascii=False).encode()).hexdigest()
(OUT/'v10-149-current-implementation-updates.json').write_text(json.dumps(report['currentImplementationUpdates'],indent=2,ensure_ascii=False)+'\n')
report['currentImplementationUpdates']['artifactSha256']=sha(OUT/'v10-149-current-implementation-updates.json')
(OUT/'launch-claim-matrix.json').write_text(json.dumps(launch,indent=2,ensure_ascii=False)+'\n')
(OUT/'reconciliation.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
# Copy the supplemental evidence into its private bundle using literal paths and hashes.
impldir=OUT/'source-bundle/implementation-updates'
if impldir.exists(): shutil.rmtree(impldir)
for original,relative in inputs.items():
    src=pathlib.Path(original)
    if not src.is_file():
        continue
    dst=OUT/relative
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(src,dst)
updates_copy=OUT/'source-bundle/implementation-updates/v10-149-current-implementation-updates.json'
updates_copy.parent.mkdir(parents=True,exist_ok=True)
shutil.copyfile(OUT/'v10-149-current-implementation-updates.json',updates_copy)
# Package the root guards in their separate, non-qualification role.
for item in guards:
    source=pathlib.Path(item['sourcePin']['path'])
    if not source.is_file():
        continue
    rel='source-bundle/qualification-guards/'+source.name
    dst=OUT/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(source,dst)
# Include a source map of every new supplemental input and the retained artifact references.
source_map=json.load(open(OUT/'portable-source-map.json'))
seen={x['originalPrivatePath'] for x in source_map.get('mapping',[])}
for original,relative in inputs.items():
    src=pathlib.Path(original)
    if original not in seen:
        source_map['mapping'].append({'originalPrivatePath':original,'portablePath':relative if src.is_file() else None,'availability':'bundled' if src.is_file() else 'unavailable_navigation_only','originalSha256':sha(src) if src.is_file() else None,'portableSha256':sha(OUT/relative) if src.is_file() else None})
source_map['mapping'].append({'originalPrivatePath':str(OUT/'v10-149-current-implementation-updates.json'),'portablePath':'source-bundle/implementation-updates/v10-149-current-implementation-updates.json','availability':'bundled','originalSha256':sha(OUT/'v10-149-current-implementation-updates.json'),'portableSha256':sha(updates_copy)})
(OUT/'portable-source-map.json').write_text(json.dumps(source_map,indent=2,ensure_ascii=False)+'\n')
# Keep the original R2 archive members and add every R3 source file; deterministic path ordering.
with tarfile.open(OUT/'source-bundle.tar.gz','w:gz') as tf:
    for p in sorted((OUT/'source-bundle').rglob('*')):
        if p.is_file(): tf.add(p,arcname=p.relative_to(OUT).as_posix())
# R3 README is deliberately explicit about pending/owner-reported states.
readme='''# V10 final claim reconciliation candidate R3\n\nPrivate, interim R3 of the existing final-claim reconciliation builder. It preserves the 169 historical V10 statuses and all 178 V6–V9 predecessor records from R2. The exact semantic predecessor links remain only the three incomplete V7 blockers to V10-149.\n\nR3 adds a separate V10-149 current implementation update lane with bounded resource/broker, RT-01 API, qualification-clock and model-watch receipts; it also records the cumulative vendor R5 source smoke and current-CI-pending state. Native R60 diagnostics and R12 provision work are private and unqualified. Root-maintained aggregate/source/release preflight inputs are bundled as guard provenance only, not as evidence of a passing aggregate. Existing owner paths and historical status fields are unchanged.\n\nCurrent source pins are interim. R3 is not V10-149 closure, a complete Native result, physical host/runtime acceptance, production deployment, Human/operator acceptance, hosted acceptance, or a signed release-profile decision. The current CI run 41042077640 remains pending in this snapshot.\n'''
(OUT/'README.md').write_text(readme)
manifest_files=['README.md','reconciliation.json','predecessor-claim-crosswalk.json','launch-claim-matrix.json','v10-149-current-implementation-updates.json','portable-source-map.json','source-bundle.tar.gz','generator/build-v10-final-claim-reconciliation-r3.py','generator/portable-refresh-v10-final-claim-reconciliation-r3.py','generator/extend-v10-final-claim-reconciliation-r3.py']
(OUT/'SHA256SUMS').write_text(''.join(f"{sha(OUT/name)}  {name}\n" for name in manifest_files))
print('updates',len(updates),'resource source paths',len(resource_source_members),'guard inputs',len(guards),'R3 source evidence copied',sum(pathlib.Path(x).is_file() for x in inputs))
