import { randomUUID } from "node:crypto";
import { eq } from "drizzle-orm";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { agents, authUsers, companies, companyMemberships, createDb, toolPolicies, workflows, EMBEDDED_POSTGRES_TEST_TIMEOUT_MS, principalPermissionGrants } from "@paperclipai/db";
import { readCompanyResponsibilityAttention } from "../services/experience/company-responsibility-attention.js";
import { grantsForHumanRole } from "../services/company-member-roles.js";
import { enableV5ForTest } from "./helpers/v5-fixtures.js";
import { startEmbeddedPostgresTestDatabase } from "./helpers/embedded-postgres.js";

describe("company cross-resource responsibility attention", () => {
  let database: Awaited<ReturnType<typeof startEmbeddedPostgresTestDatabase>>;
  let db: ReturnType<typeof createDb>;
  beforeAll(async () => {
    database = await startEmbeddedPostgresTestDatabase("company-responsibility-attention-");
    db = createDb(database.connectionString, { maxConnections: 4 });
    await enableV5ForTest(db);
  }, EMBEDDED_POSTGRES_TEST_TIMEOUT_MS);
  afterAll(async () => { await database?.cleanup(); }, 30_000);

  it("uses only the configured, currently authorized default and omits unreadable source identities", async () => {
    const companyId = randomUUID(), managerId = `responsibility-${randomUUID()}`, staleId = `stale-${randomUUID()}`;
    const now = new Date();
    await db.insert(companies).values({ id: companyId, name: "Responsibility fixture", issuePrefix: `RC${companyId.slice(0, 6)}` });
    await db.insert(authUsers).values([
      { id: managerId, name: "Current manager", email: `${managerId}@test.invalid`, emailVerified: true, createdAt: now, updatedAt: now },
      { id: staleId, name: "Archived manager", email: `${staleId}@test.invalid`, emailVerified: true, createdAt: now, updatedAt: now },
    ]);
    await db.insert(companyMemberships).values([
      { companyId, principalType: "user", principalId: managerId, status: "active", membershipRole: "owner" },
      { companyId, principalType: "user", principalId: staleId, status: "archived", membershipRole: "owner" },
    ]);
    await db.insert(principalPermissionGrants).values(grantsForHumanRole("owner").map(grant => ({
      companyId, principalType: "user" as const, principalId: managerId, ...grant,
    })));
    const [agent] = await db.insert(agents).values({ companyId, name: `Canary coworker ${randomUUID()}`, role: "general", status: "idle" }).returning();
    const [workflow] = await db.insert(workflows).values({ companyId, name: `Canary workflow ${randomUUID()}` }).returning();
    const [policy] = await db.insert(toolPolicies).values({ companyId, name: `Canary policy ${randomUUID()}`, policyType: "block" }).returning();
    const read = () => readCompanyResponsibilityAttention(db, { type: "board", source: "session", userId: managerId }, companyId, new AbortController().signal);

    const unresolved = await read();
    const coWorkers = unresolved.needsYou.filter(card => card.source.resourceId === "agent");
    expect(coWorkers).toHaveLength(1);
    expect(JSON.stringify(coWorkers)).not.toContain(agent!.id);
    expect(JSON.stringify(coWorkers)).not.toContain(agent!.name);
    const unresolvedIds = unresolved.needsYou.map(card => card.source.resourceId);
    expect(unresolvedIds).toContain("workflow");
    expect(unresolvedIds).toContain("policy");
    expect(JSON.stringify(unresolved.needsYou)).not.toContain(workflow!.id);
    expect(JSON.stringify(unresolved.needsYou)).not.toContain(policy!.id);

    await db.update(companies).set({ defaultResponsibleUserId: managerId }).where(eq(companies.id, companyId));
    const covered = await read();
    expect(covered.needsYou.some(card => ["agent", "workflow", "policy"].includes(card.source.resourceId))).toBe(false);

    await db.update(companies).set({ defaultResponsibleUserId: staleId }).where(eq(companies.id, companyId));
    const staleFallback = await read();
    expect(staleFallback.needsYou.some(card => card.source.resourceId === "agent")).toBe(true);
    expect(JSON.stringify(staleFallback)).not.toContain(staleId);
  });
});
