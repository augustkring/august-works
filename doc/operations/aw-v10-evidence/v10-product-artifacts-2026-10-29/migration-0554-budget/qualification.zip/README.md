# CompanyImport 0554 migration budget test receipt

The pinned embedded-Postgres cohort passed 4/4 tests. It applies the unchanged 0554 migration to 10,000 representative CompanyImport rows, rejects 10,001 rows before DDL or journal mutation, confirms a blocked table lock rolls back, and retries successfully after the blocker is released. The policy test confirms the budget is specific to 0554.

`source-pins.json` contains the exact SHA-256 pins for the runner, test, immutable 0554 and 0556 migrations, and current recovery owner at snapshot time. `test.log`, `syntax.log`, and exit files are the exact runner outputs. The source snapshot parser checked 911 files and passed.

This is repository test evidence only. It does not qualify a production population, lock profile, release operator, or database service. Those external facts remain open in the Safe Change graph. The historical 0554 SQL remains byte-identical.
