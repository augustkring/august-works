from pathlib import Path
p=Path('/workspace/blentera-v10/server/src/services/native-direct-input.ts');s=p.read_text()
names=['assertNativeFrozenTaskSnapshotCurrent','assertNativeTaskSourceInputCurrentInScope','assertNativeTaskSnapshotOwnerCurrentInScope','assertNativeContextInputOwnersCurrent','assertNativeContextReadSourceSetCurrentInScope']
for name in names:
 a=s.index('async function '+name+'(');b=s.index(')'+(' {' if name=='assertNativeContextInputOwnersCurrent' else ': Promise'),a)
 s=s[:b]+', siblingToolSourceProofs: NativeSiblingToolSourceProofs = new Map()'+s[b:]
def edit(name,old,new,count=1):
 global s
 a=s.index('async function '+name+'(');b=s.index('\n}\n',a);chunk=s[a:b];assert chunk.count(old)==count,(name,old,chunk.count(old));chunk=chunk.replace(old,new);s=s[:a]+chunk+s[b:]
edit('assertNativeFrozenTaskSnapshotCurrent','inputs: snapshot.inputs } }, scope);','inputs: snapshot.inputs } }, scope, siblingToolSourceProofs);')
edit('assertNativeTaskSourceInputCurrentInScope','scope, undefined, source);','scope, undefined, source, siblingToolSourceProofs);')
edit('assertNativeTaskSnapshotOwnerCurrentInScope','issueId, snapshot.data, scope);','issueId, snapshot.data, scope, siblingToolSourceProofs);')
edit('assertNativeContextInputOwnersCurrent','match[1]!, snapshot.data, scope);','match[1]!, snapshot.data, scope, siblingToolSourceProofs);')
edit('assertNativeContextInputOwnersCurrent','{ snapshot: owner.payloadSourceSnapshot });','{ snapshot: owner.payloadSourceSnapshot }, undefined, siblingToolSourceProofs);')
edit('assertNativeContextReadSourceSetCurrentInScope','contextInputs, scope);','contextInputs, scope, undefined, undefined, siblingToolSourceProofs);')
edit('assertNativePayloadSourceSetCurrentUncachedInScope','input.actor, source, scope);','input.actor, source, scope, siblingToolSourceProofs);')
edit('assertNativePayloadSourceSetCurrentUncachedInScope','input.actor, issueId, scope);','input.actor, issueId, scope, undefined, undefined, siblingToolSourceProofs);')
edit('assertNativePayloadSourceSetCurrentUncachedInScope','!exactMemoryInputIds.has(memoryId))), completedTaskSourceProofs);','!exactMemoryInputIds.has(memoryId))), completedTaskSourceProofs, siblingToolSourceProofs);')
edit('assertNativePayloadSourceSetCurrentUncachedInScope','manifestIds: manifestIds as NativeContextReadBinding["manifestIds"] }, scope);','manifestIds: manifestIds as NativeContextReadBinding["manifestIds"] }, scope, siblingToolSourceProofs);')
edit('assertNativeDocumentRevisionCurrentSourceAccessInScope','input.actor, source, scope);','input.actor, source, scope, siblingToolSourceProofs);')
edit('assertNativeDocumentRevisionCurrentSourceAccessInScope','input.actor, issueId, scope);','input.actor, issueId, scope, undefined, undefined, siblingToolSourceProofs);')
edit('assertNativeDocumentRevisionCurrentSourceAccessInScope','{ snapshot: item.payloadSourceSnapshot });','{ snapshot: item.payloadSourceSnapshot }, undefined, siblingToolSourceProofs);')
Path('/workspace/v10-preparation/native-ledger-continuity-candidate.ts').write_text(s)
