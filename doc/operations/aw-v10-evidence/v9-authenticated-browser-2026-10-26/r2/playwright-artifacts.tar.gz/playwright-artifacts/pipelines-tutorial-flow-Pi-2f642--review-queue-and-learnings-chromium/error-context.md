# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: pipelines-tutorial-flow.spec.ts >> Pipelines tutorial UI flow >> walks setup, intake, board moves, item detail, review queue, and learnings
- Location: tests/e2e/pipelines-tutorial-flow.spec.ts:438:3

# Error details

```
Error: list pipeline items failed: 500 {"error":"Internal server error"}
```

# Page snapshot

```yaml
- generic [ref=f6e4]:
  - link "Skip to Main Content" [ref=f6e5] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=f6e6]:
    - generic [ref=f6e7]:
      - generic [ref=f6e8]:
        - complementary [ref=f6e10]:
          - button "Open E2E Pipelines 1793059066737 organization switcher" [ref=f6e12]:
            - generic [ref=f6e13]:
              - generic [ref=f6e14]: E
              - generic "E2E Pipelines 1793059066737" [ref=f6e17]
          - navigation [ref=f6e18]:
            - generic [ref=f6e19]:
              - generic [ref=f6e20]:
                - text: Visning
                - combobox "Visning" [ref=f6e21]:
                  - option "Medlem"
                  - option "Leder" [selected]
                  - option "Administrator"
                  - option "Sikkerhedsadministrator"
              - link "Hjem" [ref=f6e22] [cursor=pointer]:
                - /url: /EEPA/dashboard
              - link "Kræver dig" [ref=f6e28] [cursor=pointer]:
                - /url: /EEPA/needs-you
              - link "Arbejde" [ref=f6e34] [cursor=pointer]:
                - /url: /EEPA/work
              - link "Agenter" [ref=f6e40] [cursor=pointer]:
                - /url: /EEPA/agents
              - link "Apps" [ref=f6e48] [cursor=pointer]:
                - /url: /EEPA/apps
              - link "Indsigter" [ref=f6e58] [cursor=pointer]:
                - /url: /EEPA/insights
              - link "Avanceret" [ref=f6e63] [cursor=pointer]:
                - /url: /EEPA/advanced
              - generic [ref=f6e67]:
                - button "Spørg Blentera" [ref=f6e68]
                - link "Hjælp / Support" [ref=f6e69] [cursor=pointer]:
                  - /url: /EEPA/company/help
        - button "Open account menu" [ref=f6e77]:
          - generic [ref=f6e78]: BR
          - generic [ref=f6e80]: Browser product reviewer
      - separator "Resize sidebar" [ref=f6e81]
    - generic [ref=f6e83]:
      - generic [ref=f6e84]:
        - region "Globale funktioner" [ref=f6e85]:
          - button "Spørg Blentera" [ref=f6e86]
          - generic [ref=f6e89]:
            - generic [ref=f6e90]: Sprog
            - combobox "Sprog" [ref=f6e91]:
              - option "English"
              - option "Dansk" [selected]
          - link "Hjælp / Support" [ref=f6e92] [cursor=pointer]:
            - /url: /EEPA/company/help
          - link "Kontakt support" [ref=f6e93] [cursor=pointer]:
            - /url: mailto:support@blentera.com
          - link "Brugerkonto" [ref=f6e94] [cursor=pointer]:
            - /url: /EEPA/company/settings/instance/profile
        - heading "Review queue" [level=1] [ref=f6e101]
      - main [ref=f6e104]:
        - generic [ref=f6e105]:
          - generic [ref=f6e106]:
            - generic [ref=f6e107]:
              - heading "Review queue" [level=1] [ref=f6e108]
              - paragraph [ref=f6e109]: Needs your attention (1)
            - button "Approve 0 items" [disabled]
          - generic [ref=f6e111]:
            - generic [ref=f6e112]:
              - heading "Final calls" [level=2] [ref=f6e113]
              - generic [ref=f6e114]: 1 item
            - link "Pipeline primitives launch Content production Decide whether Pipeline primitives launch is ready to move forward. just now Approve Request changes" [ref=f6e116]:
              - generic [ref=f6e118]:
                - generic [ref=f6e119]:
                  - paragraph [ref=f6e120]: Pipeline primitives launch
                  - generic [ref=f6e121]: Content production
                - paragraph [ref=f6e122]: Decide whether Pipeline primitives launch is ready to move forward.
              - generic [ref=f6e123]:
                - generic [ref=f6e124]: just now
                - button "Approve" [ref=f6e125]
                - button "Request changes" [ref=f6e126]
          - paragraph [ref=f6e127]: "Shortcuts: j/k or arrow keys move, Enter opens item, a approves."
  - generic [ref=f6e128]:
    - heading "Command Palette" [level=2] [ref=f6e129]
    - paragraph [ref=f6e130]: Search for a command to run...
```

# Test source

```ts
  1   | import { randomUUID } from "node:crypto";
  2   | import { expect, request as pwRequest, test, type APIRequestContext, type APIResponse, type Locator, type Page } from "@playwright/test";
  3   | import { createLocalAgentJwt } from "../../server/src/agent-auth-jwt";
  4   | 
  5   | const PORT = Number(process.env.PAPERCLIP_E2E_PORT ?? 3199);
  6   | const BASE_URL = `http://127.0.0.1:${PORT}`;
  7   | 
  8   | type Stage = { id: string; key: string; name: string; kind: string; position: number };
  9   | type PipelineDetail = {
  10  |   id: string;
  11  |   name: string;
  12  |   stages: Stage[];
  13  |   transitions: Array<{ fromStageId: string; toStageId: string }>;
  14  | };
  15  | type CaseSummary = {
  16  |   id: string;
  17  |   caseKey: string;
  18  |   title: string;
  19  |   version: number;
  20  |   stageId: string;
  21  |   parentCaseVersion?: number | null;
  22  |   requestKey?: string | null;
  23  |   childCount?: number;
  24  |   terminalChildCount?: number;
  25  | };
  26  | type CaseRow = { case: CaseSummary; stage?: Stage };
  27  | type CaseDetail = CaseRow & {
  28  |   pipeline: { id: string; key: string; name: string };
  29  |   blockers?: Array<{ caseId: string; blockedByCaseId: string }>;
  30  | };
  31  | 
  32  | async function expectOk(response: APIResponse, label: string) {
  33  |   if (!response.ok()) {
> 34  |     throw new Error(`${label} failed: ${response.status()} ${await response.text()}`);
      |           ^ Error: list pipeline items failed: 500 {"error":"Internal server error"}
  35  |   }
  36  | }
  37  | 
  38  | async function expectError(response: APIResponse, label: string, status: number, code: string, message?: RegExp) {
  39  |   const body = await response.json() as { code?: string; error?: string; message?: string };
  40  |   expect(response.status(), `${label} status: ${JSON.stringify(body)}`).toBe(status);
  41  |   expect(body.code, `${label} code: ${JSON.stringify(body)}`).toBe(code);
  42  |   if (message) expect(body.error ?? body.message ?? "", `${label} message`).toMatch(message);
  43  | }
  44  | 
  45  | async function createCompany(board: APIRequestContext) {
  46  |   const response = await board.post("/api/companies", {
  47  |     data: { name: `E2E Pipelines ${Date.now()}` },
  48  |   });
  49  |   await expectOk(response, "create company");
  50  |   return response.json() as Promise<{ id: string; issuePrefix: string }>;
  51  | }
  52  | 
  53  | async function createCompanyAgent(
  54  |   board: APIRequestContext,
  55  |   companyId: string,
  56  |   input: { name: string; role: string; title?: string; capabilities?: string },
  57  | ) {
  58  |   const response = await board.post(`/api/companies/${companyId}/agents`, {
  59  |     data: {
  60  |       name: input.name,
  61  |       role: input.role,
  62  |       title: input.title,
  63  |       capabilities: input.capabilities,
  64  |       adapterType: "process",
  65  |       adapterConfig: { command: process.execPath, args: ["-e", "process.stdout.write('ok\\n')"] },
  66  |     },
  67  |   });
  68  |   await expectOk(response, `create ${input.name}`);
  69  |   return response.json() as Promise<{ id: string }>;
  70  | }
  71  | 
  72  | async function createPipelineWriterAgentKey(board: APIRequestContext, companyId: string) {
  73  |   await createCompanyAgent(board, companyId, {
  74  |     name: "Pipeline CEO",
  75  |     role: "ceo",
  76  |     title: "CEO",
  77  |     capabilities: "Approves agent join requests during e2e setup.",
  78  |   });
  79  | 
  80  |   const inviteResponse = await board.post(`/api/companies/${companyId}/invites`, {
  81  |     data: {
  82  |       allowedJoinTypes: "agent",
  83  |       defaultsPayload: {
  84  |         agent: {
  85  |           grants: [
  86  |             { permissionKey: "pipelines:write", scope: null },
  87  |           ],
  88  |         },
  89  |       },
  90  |     },
  91  |   });
  92  |   await expectOk(inviteResponse, "create pipeline-writer invite");
  93  |   const invite = await inviteResponse.json() as { token: string };
  94  | 
  95  |   const acceptResponse = await board.post(`/api/invites/${invite.token}/accept`, {
  96  |     data: {
  97  |       requestType: "agent",
  98  |       agentName: "Pipeline Fanout Agent",
  99  |       adapterType: "process",
  100 |       capabilities: "Creates pipeline child work during e2e coverage.",
  101 |     },
  102 |   });
  103 |   await expectOk(acceptResponse, "accept pipeline-writer invite");
  104 |   const accepted = await acceptResponse.json() as { id: string };
  105 | 
  106 |   const approveResponse = await board.post(`/api/companies/${companyId}/join-requests/${accepted.id}/approve`);
  107 |   await expectOk(approveResponse, "approve pipeline-writer join");
  108 |   const approved = await approveResponse.json() as { createdAgentId: string };
  109 | 
  110 |   const runId = randomUUID();
  111 |   const token = createLocalAgentJwt(approved.createdAgentId, companyId, "process", runId);
  112 |   if (!token) throw new Error("PAPERCLIP_AGENT_JWT_SECRET is required for pipeline writer JWT setup");
  113 |   return { agentId: approved.createdAgentId, runId, token };
  114 | }
  115 | 
  116 | async function createPipeline(board: APIRequestContext, companyId: string) {
  117 |   const response = await board.post(`/api/companies/${companyId}/pipelines`, {
  118 |     data: {
  119 |       key: "content-production",
  120 |       name: "Content production",
  121 |       description: "Draft, review, and publish launch content.",
  122 |       enforceTransitions: true,
  123 |       stages: [
  124 |         { key: "drafting", name: "Drafting", kind: "working", position: 0, config: { variables: [] } },
  125 |         { key: "published", name: "Published", kind: "done", position: 2, config: { variables: [] } },
  126 |         { key: "dropped", name: "Dropped", kind: "cancelled", position: 3, config: { variables: [] } },
  127 |       ],
  128 |     },
  129 |   });
  130 |   await expectOk(response, "create pipeline");
  131 |   return response.json() as Promise<{ id: string; name: string }>;
  132 | }
  133 | 
  134 | async function createPrimitivePipeline(board: APIRequestContext, companyId: string) {
```