# Jev lifecycle and inventory qualification evidence

This portable archive preserves the exact source pins, patches, detached source blobs, logs and exits for three cohorts.

- `r2-historical-42/`: historical baseline, 42 tests passed across service (6), setup HTTP (9), announcements (13), inventory/notices (9), and UI (5), against its own r2 source pin.
- `r4-changed-cohort-11/`: later changed-code cohort, 11 tests passed (HTTP 2, service 4, UI 5), with shared/server/UI type checks and UI token gates. The standard server package typecheck passed and includes the vendor Rust release build. Its pin predates the final Saas settings query cap. The standalone direct TSC was stopped after the package typecheck passed and is not claimed as a pass.
- `latest-full-route-15/`: fresh full `announcements-routes.test.ts` run on the latest captured pin, 15/15 passed. This pin includes the Saas settings query bound. `exact-19-source-hashes.json` lists the 18 direct Jev/action-notice source paths and the supplemental route test.

The 42-test result is historical; the latest code was not re-run through all 42 tests. The fresh route run is the complete route file only. Root’s final workspace typecheck remains a separate qualification. No commit or release action is represented here.

`runner-build-proof.json` records that the standard package qualification built the release runner and that its binary SHA-256 matches the separately pinned provider-pack binary. The matching hash is `31964806291c8eac3cad8b18bc26c1d3377191fb46f1f1e65aee2595a5697604`.
