# Responsibility coverage closure (0565 scanner + member continuity preflight)

This bundle records the already published 0565 native responsibility scanner/contact settings (R5) and its reviewed member-removal preflight privacy/session hardening (R6). No DDL or migration is part of this closure. The member preflight remains advisory and does not gate synchronous credential revocation or membership/access removal.

## Exact commit stage list

See `STAGE-LIST.txt`; it contains the complete seven-file closure. `member-continuity-preflight.ts` is a new untracked source file in the working tree and must be included when committing.

## Source receipts

`published-owned.sha256` pins all seven final published paths. The R6 diff was based on the exact R5 bytes pinned in `../qualification/baseline-owned.sha256`. Private R6 patch hash: `2f7f9a48570c224ef1674f21faf128c438e74831a1c6e008c6b6985e8e61c313`.

R5 carried the native per-kind/current-ACL readers, 0565 contact fields and owner-access handling, bounded privacy-safe member preflight, final viewer/target membership authority checks, constant unknown coverage, and synchronous API-key revocation. R6 adds principal/session/authority-epoch query isolation, abort/no-store behavior, after-await and render-time authority/session receipts, expected-user/session request fencing, a board-Human-session route check, and positive visible `MUST_REVOKE` credential coverage.

## Qualification receipts

- R5 focused private qualification: `../qualification` (snapshot 1,184 source files, Oxc, PG 2/2, focused UI 1/1, server and UI typechecks, compiled DB/shared hash guard).
- R6 focused private qualification: `../qualification` (snapshot 1,184 source files, Oxc 7/7, PG 2/2, UI 2/2 including late session response, server/UI typechecks and compiled output guard).
- R6 full UI regression qualification: `../qualification-full-ui` (snapshot 1,184 source files, Oxc 7/7, `CompanyAccess.test.tsx` 36/36).
- Both qualification runs used `/workspace/v10-dep-qualification` under `/workspace/v10-preparation/v10-pg-tests.lock`. Mirror cleanup restored the seven owned paths to match MAIN byte-for-byte; the R6 full-suite output records the snapshot and test receipt.
- The server test exercises visible credential `MUST_REVOKE` without exposing its id/name/hash, hidden support/credential canaries with identical aggregate public output, viewer membership revocation during enumeration, and offboarding commit despite scanner enqueue failure.

## Publication

The R6 patch was applied to MAIN only after the seven-path R5 baseline hash guard passed. `published-owned.sha256` records the exact resulting closure and a post-publication hash check succeeded. No commit or deployment was made.
