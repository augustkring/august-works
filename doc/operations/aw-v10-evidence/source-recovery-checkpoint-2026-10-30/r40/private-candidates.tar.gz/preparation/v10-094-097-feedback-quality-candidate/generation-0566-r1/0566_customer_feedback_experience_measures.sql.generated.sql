DROP TABLE "responsibility_scan_candidates" CASCADE;--> statement-breakpoint
DROP TABLE "responsibility_scan_runs" CASCADE;--> statement-breakpoint
ALTER TABLE "companies" DROP COLUMN "security_contact_user_id";--> statement-breakpoint
ALTER TABLE "companies" DROP COLUMN "support_incident_contact_user_id";