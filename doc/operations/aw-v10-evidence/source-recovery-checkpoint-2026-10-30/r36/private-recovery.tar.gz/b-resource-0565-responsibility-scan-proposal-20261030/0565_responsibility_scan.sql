-- PRIVATE Resource 0565 candidate only. Do not apply or journal before Root review.
CREATE TABLE IF NOT EXISTS responsibility_scan_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  contract_version integer NOT NULL DEFAULT 1,
  status text NOT NULL DEFAULT 'queued',
  cursor_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  requested_at timestamptz NOT NULL DEFAULT now(),
  next_attempt_at timestamptz NOT NULL DEFAULT now(),
  lease_owner text,
  lease_token uuid,
  lease_expires_at timestamptz,
  attempt_count integer NOT NULL DEFAULT 0,
  last_error_code text,
  started_at timestamptz,
  completed_at timestamptz,
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT responsibility_scan_runs_status_check
    CHECK (status IN ('queued','running','complete','failed','abandoned')),
  CONSTRAINT responsibility_scan_runs_lease_pair_check
    CHECK ((lease_owner IS NULL) = (lease_token IS NULL)
      AND (lease_token IS NULL) = (lease_expires_at IS NULL)),
  CONSTRAINT responsibility_scan_runs_attempt_check CHECK (attempt_count >= 0),
  CONSTRAINT responsibility_scan_runs_cursor_check CHECK (jsonb_typeof(cursor_json) = 'object')
);
CREATE UNIQUE INDEX IF NOT EXISTS responsibility_scan_runs_one_active_per_company
  ON responsibility_scan_runs(company_id) WHERE status IN ('queued','running','failed');
CREATE INDEX IF NOT EXISTS responsibility_scan_runs_claim_idx
  ON responsibility_scan_runs(next_attempt_at, requested_at, company_id)
  WHERE status IN ('queued','failed');
CREATE INDEX IF NOT EXISTS responsibility_scan_runs_expiry_idx
  ON responsibility_scan_runs(expires_at);

CREATE TABLE IF NOT EXISTS responsibility_scan_candidates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  scan_run_id uuid NOT NULL REFERENCES responsibility_scan_runs(id) ON DELETE CASCADE,
  resource_kind text NOT NULL,
  resource_id text NOT NULL,
  source_version text NOT NULL,
  observed_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL,
  CONSTRAINT responsibility_scan_candidates_kind_check CHECK (resource_kind IN (
    'agent','deployment','workflow','workflow_run','routine','connector','metric','experiment',
    'decision','approval','ai_use_case','tool_policy','skill_policy','billing','support_case'
  )),
  CONSTRAINT responsibility_scan_candidates_source_version_check
    CHECK (source_version ~ '^[0-9a-f]{64}$'),
  CONSTRAINT responsibility_scan_candidates_resource_id_check CHECK (resource_id <> '')
);
CREATE UNIQUE INDEX IF NOT EXISTS responsibility_scan_candidates_run_resource_uq
  ON responsibility_scan_candidates(scan_run_id, resource_kind, resource_id);
CREATE INDEX IF NOT EXISTS responsibility_scan_candidates_read_idx
  ON responsibility_scan_candidates(company_id, scan_run_id, resource_kind, resource_id, expires_at);
CREATE INDEX IF NOT EXISTS responsibility_scan_candidates_expiry_idx
  ON responsibility_scan_candidates(expires_at);
