import ast,copy,gzip,hashlib,json,pathlib,re,subprocess
root=pathlib.Path('/workspace/blentera-v10');out=pathlib.Path('/workspace/v10-preparation/v10-product-artifacts-b1-recovery-20261103');tmp=pathlib.Path('/tmp/v10-product-artifacts-b1-recovery-20261103');tmp.mkdir(exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();base='81d3445b98b1cd80ff400ede6bd44ea71d88d735';seedpath=pathlib.Path('/workspace/v10-preparation/v10-safe-change-source-inventory-merged-current.json');seed=json.loads(seedpath.read_bytes());r=copy.deepcopy(seed);assert seed['sourceBase']['commitSha']==base
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='b1edccff649dceaaa92aa83e153ebe05c09ae273'
originalbuilder=pathlib.Path('/workspace/v10-preparation/build-v10-safe-change-inventory-draft-current.py').read_text();tree=ast.parse(originalbuilder)
# Reuse only the earlier explicit selection/owner rules, not its executable writer.
ns={'os':__import__('os'),'re':re,'source_ext':{'.ts','.tsx','.js','.mjs','.sql','.yml','.yaml','.json','.sh','.rs','.toml','.py','.css','.html','.svg','.patch'}}
for node in tree.body:
 if isinstance(node,ast.FunctionDef) and node.name in {'relevant','walk_paths'}:exec(compile(ast.Module(body=[node],type_ignores=[]),'<preserved-source-selection>','exec'),ns)
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='rules' for t in node.targets):exec(compile(ast.Module(body=[node],type_ignores=[]),'<preserved-owner-rules>','exec'),ns)
changed=set(subprocess.check_output(['git','diff','--name-only',base,'HEAD'],cwd=root,text=True).splitlines());material={p for p in changed if ns['relevant'](p)}
basepaths=set(subprocess.check_output(['git','ls-tree','-r','--name-only',base],cwd=root,text=True).splitlines());records={x['changeId']:x for x in r['changes']};assignments=[];retired=[]
# Explicit reviewed owner plans precede generic source-family fallback.
for planpath in ['/workspace/v10-preparation/safe-change-graph-final-guard-owner-plan-nov01.json','/workspace/v10-preparation/safe-change-graph-final-host-native-owner-plan-nov01.json']:
 plan=json.loads(pathlib.Path(planpath).read_bytes())
 for addition in plan['additions']:
  p=addition['path'];g=records[addition['existingOwnerGroup']]
  if (root/p).is_file() and p not in g['sourcePaths']:g['sourcePaths'].append(p);assignments.append({'path':p,'group':g['changeId'],'basis':'preserved reviewed owner plan','planPath':planpath,'rationale':addition['rationale']})
# Correct one evidenced historical lexical mismatch: this generated catalog
# belongs to its actual original CI/catalog generator, not repository ownership.
capPath='doc/operations/v10-capability-projection.json'
for g in r['changes']:
 if capPath in g['sourcePaths']:g['sourcePaths'].remove(capPath)
records['SCR-V10-CI-RELEASE-AND-CATALOG-GOVERNANCE']['sourcePaths'].append(capPath)
assignments.append({'path':capPath,'group':'SCR-V10-CI-RELEASE-AND-CATALOG-GOVERNANCE','basis':'explicit correction of inherited substring classifier; actual owning generator is scripts/generate-v10-capability-projection.ts','previousGroup':'SCR-V10-PROJECT-REPOSITORY-SOURCE'})
covered={p for g in r['changes'] for p in g['sourcePaths']+g.get('deletedSourcePaths',[])}
for p in sorted(material-covered):
 label=next(label for label,predicate in ns['rules'] if predicate(p));gid='SCR-V10-'+label.upper().replace('CROSSCUT_','').replace('_','-');g=records[gid];g['sourcePaths'].append(p);assignments.append({'path':p,'group':gid,'basis':'preserved explicit source-family selector; accountable owner/behavior remains unknown'})
allpaths=set()
for g in r['changes']:
 paths=set(g['sourcePaths'])|set(g.get('deletedSourcePaths',[]));absent={p for p in paths if not (root/p).is_file() and p not in basepaths};paths-=absent
 for p in sorted(absent):retired.append({'path':p,'group':g['changeId'],'disposition':'Absent at both current b1 and pinned base; retain as retired intermediate branch reference, not a base deletion or reconstructed current source.'})
 g['sourcePaths']=sorted(p for p in paths if (root/p).is_file());g['deletedSourcePaths']=sorted(p for p in paths if not (root/p).is_file());g['changedSourcePaths']=sorted(paths&material)
 for key in ['dependencyPaths','characterizationTests']:g[key]=sorted(set(g.get(key,[]))-absent)
 if absent:g.setdefault('retiredBranchSourcePaths',[]).extend(x for x in retired if x['group']==g['changeId'])
 allpaths.update(paths)
# Read all actual base source bytes through one Git batch; no fabricated hashes.
present=sorted(allpaths&basepaths);proc=subprocess.Popen(['git','cat-file','--batch'],cwd=root,stdin=subprocess.PIPE,stdout=subprocess.PIPE);payload=''.join(base+':'+p+'\n' for p in present).encode();stream=proc.communicate(payload)[0];assert proc.returncode==0;cursor=0;before={}
for p in present:
 end=stream.index(b'\n',cursor);header=stream[cursor:end].split();size=int(header[2]);content=stream[end+1:end+1+size];before[p]={'path':p,'baseCommitSha':base,'status':'present_at_base','sha256':sha(content)};cursor=end+size+2
for p in allpaths-set(present):before[p]={'path':p,'baseCommitSha':base,'status':'absent_at_base','sha256':None}
for g in r['changes']:
 g['sourceBeforePins']=[before[p] for p in sorted(set(g['sourcePaths'])|set(g['deletedSourcePaths']))]
 # Retain original current writer/state/recovery/compatibility/qualification fields.
 if g.get('hotspotSourcePin'):
  anchor=g['canonicalOwner'];g['hotspotSourcePin']['currentAnchorSha256']=sha((root/anchor).read_bytes())
registry=json.loads((root/'doc/operations/aw-v10-evidence/recovery-2026-10-22/requirement-reconciliation.json').read_bytes());refs={row['id']:set(ns['walk_paths'](row)) for row in registry['items']}
for row in r['requirementsCrosswalk']:
 row['changedReferencedPaths']=sorted(refs[row['workId']]&material);row['safeChangeIds']=sorted(set(row['safeChangeIds'])|{g['changeId'] for g in r['changes'] if refs[row['workId']]&set(g['sourcePaths'])});row['sourceDeltaStatus']='one_or_more_registered_source_paths_changed' if row['changedReferencedPaths'] else 'no_registered_changed_source_path_identified'
for g in r['changes']:
 g['requirements']=sorted(set(g['requirements'])|{row['id'] for row in registry['items'] if refs[row['id']]&set(g['sourcePaths'])})
actualcovered={p for g in r['changes'] for p in g['changedSourcePaths']};assert actualcovered==material
r['sourceInventoryBoundary'].update(sourceDeltaPathCount=len(material),deletedSourcePathCount=len({p for g in r['changes'] for p in g['deletedSourcePaths']}),untrackedSourceCandidateCount=0,ownerGroupCount=len(r['changes']),hotspotRegisterCount=25,requirementCrosswalkCount=169,fullDiffPathCount=len(changed))
r['sourceAfterGeneration']='Current b1 source inventory only; no final source freeze or release qualification. Later accepted source changes require reviewed incremental source mapping and regeneration.'
r['currentSourceRecovery']={'sourceHead':head,'seedPath':'doc/operations/aw-v10-evidence/v10-product-artifacts-b1-recovery-20261103/qualification.tar.gz:historical/schema2-seed-source.json','seedSha256':sha(seedpath.read_bytes()),'preservedBuilderSha256':sha(originalbuilder.encode()),'qualification':'Preserved 50 owner-group assessments, all 169 historical crosswalk statuses and original0554 bounded software evidence. Updated source links/base proofs/current hashes only; new source-family links are not behavior approval or capability readiness.'}
oldrows={x['workId']:x for x in seed['requirementsCrosswalk']}
for row in r['requirementsCrosswalk']:
 for k,v in oldrows[row['workId']].items():
  if k not in {'changedReferencedPaths','safeChangeIds','sourceDeltaStatus'}:assert row[k]==v
oldrecords={x['changeId']:x for x in seed['changes']};linkkeys={'sourcePaths','deletedSourcePaths','changedSourcePaths','sourceBeforePins','dependencyPaths','characterizationTests','requirements','hotspotSourcePin','retiredBranchSourcePaths'}
for g in r['changes']:
 for k,v in oldrecords[g['changeId']].items():
  if k not in linkkeys:assert g[k]==v,(g['changeId'],k)
hot=json.loads((root/'doc/operations/production-hotspot-responsibilities.json').read_bytes())['hotspots'];assert [g['canonicalOwner'] for g in r['changes'] if g.get('recordKind')=='production_hotspot_owner_group']==[x['path'] for x in hot]
rendered=(json.dumps(r,indent=2)+'\n').encode();(tmp/'v10-safe-change-graph.source.json').write_bytes(rendered);(out/'v10-safe-change-graph.source.json.gz').write_bytes(gzip.compress(rendered,mtime=0))
proof={'sourceHead':head,'seedSha256':sha(seedpath.read_bytes()),'candidateSourceSha256':sha(rendered),'records':len(r['changes']),'hotspots':25,'crosswalk':169,'sourceDeltas':len(material),'deletedSourcePaths':r['sourceInventoryBoundary']['deletedSourcePathCount'],'newMappings':assignments,'retiredReferences':retired,'allCurrentPathsExist':True,'allCurrentMaterialDiffPathsCovered':True,'actualBasePinsVerified':True,'historicalCrosswalkAssessmentsUnchanged':True,'all50PriorRecordNonlinkAssessmentsUnchanged':True,'mainFilesWritten':False,'sourceOnlyNotQualification':True};(out/'source-inventory-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:v for k,v in proof.items() if k not in {'newMappings','retiredReferences'}}));print('newMappings',len(assignments),'retired',len(retired))
