# Cleanup r1 independent review

**P1 CL-02 — erasure wire digest disagrees with Host.** `control.ts:2977` hashes a private purpose and omits four null broker fields, whereas `openshell.mjs:2817` hashes those broker fields and omits purpose. Actual Host execution rejects the command before spawn. R38.4 additionally includes `modelBrokerSession:null`. Align the wire digest while retaining purpose checks in server claim authorization. This is inherited but remains an actual-issuer blocker. Sent SourceOwner/root.

R0 parser blocker is fixed. Image write-root exclusions, exact environment, ownership checks and directory-fd traversal address prior trust/traversal concerns.

Conditional remaining race: root selection occurs at `remote-runner-identity.ts:131`, after pathname state validation at :116. A concurrent same-UID writer could replace that root with a sibling before selection. Anchor the root before binding checks and reuse it, or establish exclusive erasure admission. Fresh force_stop removes old writers; the remaining precondition is subsequent concurrent/restarted execution.

Patch SHA: `8028fce730edfa567f2aaa24033f80de633018b947d787b27bb397f8106333e5`. No tests/source edits/network.
