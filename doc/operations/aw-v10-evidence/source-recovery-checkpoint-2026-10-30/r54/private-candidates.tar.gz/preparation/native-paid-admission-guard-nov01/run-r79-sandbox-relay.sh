#!/usr/bin/env bash
set -euo pipefail

REPO=/workspace/blentera-v10
PREP=/workspace/v10-preparation/native-paid-admission-guard-nov01
LOCK=/workspace/v10-preparation/v10-pg-tests.lock
NATIVE_CANDIDATE=${2:-/workspace/v10-preparation/native-fixture-budget-r80-candidate}
EXPECTED_HEAD=${1:?qualified source HEAD required}
NATIVE_SOURCE_PINS=${3:?Native source pin receipt path required}
HOST_CANDIDATE=${4:-}
HOST_SOURCE_PINS=${5:-}
PACK_BUILDER="$REPO/packages/paperclip-runner/scripts/build-provider-pack.mjs"
OPENCODE=/workspace/.cloud-setup/lockfile/node_modules/.pnpm/opencode-linux-x64@1.18.32/node_modules/opencode-linux-x64/bin/opencode
RUN_ID="$(date -u +%Y%m%dT%H%M%SZ)-$$"
RUN_DIR="$PREP/sandbox-relay-debug-$RUN_ID"
PACK_STAGE="/tmp/paperclip-provider-pack-sandbox-relay-$RUN_ID"
DIST_BACKUP="/tmp/paperclip-runner-dist-before-sandbox-relay-$RUN_ID.tar"

mkdir "$RUN_DIR"
[[ -f "$NATIVE_SOURCE_PINS" ]]
if [[ -n "$HOST_CANDIDATE" ]]; then [[ -n "$HOST_SOURCE_PINS" && -f "$HOST_SOURCE_PINS" ]]; fi
[[ ! -e "$PACK_STAGE" ]]
exec 9>"$LOCK"
flock -x 9

[[ "$(git -C "$REPO" rev-parse HEAD)" == "$EXPECTED_HEAD" ]]
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH
[[ -x "$OPENCODE" ]]
[[ -f "$REPO/server/node_modules/@vercel/connect/package.json" ]]
[[ "$(node -p "require('$REPO/server/node_modules/@vercel/connect/package.json').version")" == "0.6.1" ]]

python3 - "$REPO" "$NATIVE_CANDIDATE" "$HOST_CANDIDATE" "$RUN_DIR/native-candidate-files.txt" "$RUN_DIR/host-candidate-files.txt" <<'PY'
import hashlib,json,sys
from pathlib import Path
repo,native=map(Path,sys.argv[1:3])
host_arg=sys.argv[3]
host=Path(host_arg) if host_arg else None
native_out,host_out=map(Path,sys.argv[4:6])
manifest=json.loads((native/'manifest.json').read_text())
with native_out.open('w') as f:
    for rel,pin in manifest.items():
        source=repo/rel
        overlay=native/rel
        current=hashlib.sha256(source.read_bytes()).hexdigest() if source.exists() else None
        if current!=pin['priorSha256']:
            raise SystemExit(f'candidate prior pin mismatch: {rel}: {current}')
        actual=hashlib.sha256(overlay.read_bytes()).hexdigest()
        if actual!=pin['candidateSha256']:
            raise SystemExit(f'candidate overlay pin mismatch: {rel}: {actual}')
        f.write(rel+'\n')
if host is not None:
    host_manifest=json.loads((host/'qualification-source-pins.json').read_text())
    host_paths=[]
    with host_out.open('w') as f:
        for item in host_manifest['sourceFiles']:
            rel=item['path']
            host_paths.append(rel)
            source=repo/rel
            overlay=host/'files'/rel
            current=hashlib.sha256(source.read_bytes()).hexdigest() if source.exists() else None
            if current!=item['parentSha256']:
                raise SystemExit(f'Host candidate prior pin mismatch: {rel}: {current}')
            actual=hashlib.sha256(overlay.read_bytes()).hexdigest()
            if actual!=item['candidateSha256']:
                raise SystemExit(f'Host candidate overlay pin mismatch: {rel}: {actual}')
            f.write(rel+'\n')
    overlap=set(manifest).intersection(host_paths)
    if overlap:
        raise SystemExit(f'Native and Host candidate overlays overlap: {sorted(overlap)}')
else:
    host_out.write_text('')
PY

files=(
  server/src/services/heartbeat.ts
  server/src/services/native-runtime/native-session-executor.ts
  server/src/services/native-runtime/native-session-executor.test.ts
  server/src/services/native-runtime/paid-transport-admission.ts
  server/src/services/native-runtime/paid-transport-admission.test.ts
  server/src/services/native-runtime/native-session-executor-admission.test.ts
  ui/src/lib/system-notice-humanizer.ts
  ui/src/lib/system-notice-humanizer.test.ts
  ui/src/components/task-chat/TaskChatSystemNotice.tsx
  ui/src/i18n/experience/en.json
  ui/src/i18n/experience/da.json
)
while IFS= read -r rel; do files+=("$rel"); done < "$RUN_DIR/native-candidate-files.txt"
while IFS= read -r rel; do [[ -n "$rel" ]] && files+=("$rel"); done < "$RUN_DIR/host-candidate-files.txt"
mapfile -t files < <(printf '%s\n' "${files[@]}" | sort -u)
mkdir -p "$RUN_DIR/restore"
: > "$RUN_DIR/restore-manifest.txt"
for rel in "${files[@]}"; do
  src="$REPO/$rel"
  if [[ -e "$src" ]]; then
    mkdir -p "$RUN_DIR/restore/$(dirname "$rel")"
    cp -p "$src" "$RUN_DIR/restore/$rel"
    printf 'present %s %s\n' "$(sha256sum "$src" | awk '{print $1}')" "$rel" >> "$RUN_DIR/restore-manifest.txt"
  else
    printf 'absent - %s\n' "$rel" >> "$RUN_DIR/restore-manifest.txt"
  fi
done
DIST="$REPO/packages/paperclip-runner/dist"
tar -C "$REPO/packages/paperclip-runner" -cf "$DIST_BACKUP" dist
printf '%s\n' "$DIST_BACKUP" > "$RUN_DIR/dist-backup-path.txt"
printf '%s\n' "$(sha256sum "$REPO/packages/paperclip-runner/dist/cli/opencode-app-server-proxy.cjs" | awk '{print $1}')" > "$RUN_DIR/proxy-dist-before.sha256"
ORIG="$REPO/server/src/services/native-runtime/native-session-executor.ts.orig"
if [[ -e "$ORIG" ]]; then cp -p "$ORIG" "$RUN_DIR/native-session-executor.ts.orig"; printf 'present %s\n' "$(sha256sum "$ORIG" | awk '{print $1}')" > "$RUN_DIR/orig-manifest.txt"
else printf 'absent\n' > "$RUN_DIR/orig-manifest.txt"; fi

restore() {
  local code=$?
  trap - EXIT
  for rel in "${files[@]}"; do
    if [[ -e "$RUN_DIR/restore/$rel" ]]; then cp -p "$RUN_DIR/restore/$rel" "$REPO/$rel"; else rm -f "$REPO/$rel"; fi
  done
  python3 - "$DIST" <<'PY'
import shutil,sys
shutil.rmtree(sys.argv[1])
PY
  tar -C "$REPO/packages/paperclip-runner" -xf "$DIST_BACKUP"
  if [[ -e "$RUN_DIR/native-session-executor.ts.orig" ]]; then cp -p "$RUN_DIR/native-session-executor.ts.orig" "$ORIG"; else rm -f "$ORIG"; fi
  local bad=0
  while read -r state digest rel; do
    if [[ "$state" == present ]]; then
      actual="$(sha256sum "$REPO/$rel" | awk '{print $1}')"
      [[ "$actual" == "$digest" ]] || { echo "restore mismatch: $rel" >&2; bad=1; }
    elif [[ -e "$REPO/$rel" ]]; then echo "restore expected absent: $rel" >&2; bad=1; fi
  done < "$RUN_DIR/restore-manifest.txt"
  [[ "$(sha256sum "$REPO/packages/paperclip-runner/dist/cli/opencode-app-server-proxy.cjs" | awk '{print $1}')" == "$(cat "$RUN_DIR/proxy-dist-before.sha256")" ]] || bad=1
  if (( bad )); then code=71; fi
  printf '%s\n' "$code" > "$RUN_DIR/exit"
  exit "$code"
}
trap restore EXIT

cp "$NATIVE_SOURCE_PINS" "$RUN_DIR/native-source-pins.json"
cp "$NATIVE_CANDIDATE/manifest.json" "$RUN_DIR/native-candidate-manifest.json"
if [[ -n "$HOST_CANDIDATE" ]]; then
  cp "$HOST_SOURCE_PINS" "$RUN_DIR/host-source-pins.json"
  cp "$HOST_CANDIDATE/qualification-source-pins.json" "$RUN_DIR/host-candidate-manifest.json"
fi
sha256sum "$PREP/native-paid-admission-guard.patch" > "$RUN_DIR/guard-patch.sha256"
sha256sum "$REPO/pnpm-lock.yaml" "$REPO/packages/paperclip-runner/package.json" "$PACK_BUILDER" > "$RUN_DIR/pack-source-pins.sha256"
df -B1 /workspace /tmp > "$RUN_DIR/disk-before.txt"
free_bytes="$(df -B1 /tmp | awk 'NR==2 {print $4}')"
(( free_bytes >= 2600000000 )) || { echo "insufficient /tmp headroom for provider pack build" >&2; exit 72; }

while IFS= read -r rel; do
  mkdir -p "$REPO/$(dirname "$rel")"
  cp -p "$NATIVE_CANDIDATE/$rel" "$REPO/$rel"
done < "$RUN_DIR/native-candidate-files.txt"
if [[ -n "$HOST_CANDIDATE" ]]; then
  while IFS= read -r rel; do
    mkdir -p "$REPO/$(dirname "$rel")"
    cp -p "$HOST_CANDIDATE/files/$rel" "$REPO/$rel"
  done < "$RUN_DIR/host-candidate-files.txt"
fi

cd "$REPO"
patch --dry-run -p1 < "$PREP/native-paid-admission-guard.patch" > "$RUN_DIR/guard-patch-dry-run.log"
patch -p1 < "$PREP/native-paid-admission-guard.patch" > "$RUN_DIR/guard-patch-apply.log"
cd "$REPO/packages/paperclip-runner"
node ./node_modules/typescript/bin/tsc -p tsconfig.json > "$RUN_DIR/runner-tsc.log" 2>&1
node ./node_modules/typescript/bin/tsc -p tsconfig.surfaces.json >> "$RUN_DIR/runner-tsc.log" 2>&1
node scripts/build-verified-provider-entrypoints.mjs > "$RUN_DIR/verified-provider-entrypoints.log" 2>&1
[[ -f "$DIST/cli/opencode-app-server-proxy.cjs" ]]
[[ "$(sha256sum "$DIST/cli/opencode-app-server-proxy.cjs" | awk '{print $1}')" != "$(cat "$RUN_DIR/proxy-dist-before.sha256")" ]]

export PATH=/workspace/v10-preparation/pinned-bin:$PATH npm_config_offline=false npm_config_cache=/tmp/provider-pack-registry-cache-v10 npm_config_optional=true npm_config_include=optional npm_config_store_dir=/workspace/.cloud-setup/pnpm-store
node "$PACK_BUILDER" "$PACK_STAGE" > "$RUN_DIR/provider-pack-build.log" 2>&1
[[ -f "$PACK_STAGE/provider-pack.json" ]]
manifest_digest="$(node -p "require('$PACK_STAGE/provider-pack.json').digest")"
[[ "$manifest_digest" =~ ^sha256:[0-9a-f]{64}$ ]]
PACK="/tmp/paperclip-runner-provider-pack-${manifest_digest#sha256:}"
if [[ -e "$PACK" ]]; then
  [[ "$(node -p "require('$PACK/provider-pack.json').digest")" == "$manifest_digest" ]]
  # Keep the duplicate in /tmp instead of moving it onto the nearly-full
  # workspace filesystem. The pre-existing content-addressed pack remains
  # authoritative and the newly built stage is preserved for review.
else
  mv "$PACK_STAGE" "$PACK"
fi
cp "$PACK/provider-pack.json" "$RUN_DIR/provider-pack.json"
printf '%s\n' "$PACK" > "$RUN_DIR/provider-pack-path.txt"
if [[ -e "$PACK_STAGE" ]]; then printf '%s\n' "$PACK_STAGE" > "$RUN_DIR/provider-pack-duplicate-path.txt"; fi
df -B1 /workspace /tmp > "$RUN_DIR/disk-after-pack.txt"

cd "$REPO/server"
PAPERCLIP_RUNNER_REMOTE_PROVIDER_PACK_PATH="$PACK" \
PAPERCLIP_QUALIFIED_OPENCODE_BINARY="$OPENCODE" \
timeout --signal=TERM --kill-after=10s 300s ../node_modules/.bin/vitest run \
  src/services/native-runtime/native-opencode-managed-conversation-frame.integration.test.ts \
  -t "runs the route-created conversation through RuntimeControl" --reporter=verbose \
  > "$RUN_DIR/sandbox-relay-vitest.log" 2>&1
cat "$RUN_DIR/sandbox-relay-vitest.log"
df -B1 /workspace /tmp > "$RUN_DIR/disk-after-test.txt"
