#!/usr/bin/env bash
set -euo pipefail
exec flock -x /workspace/v10-preparation/v10-pg-tests.lock bash -s <<'LOCKED'
set -u
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH
ROOT=/workspace/blentera-v10
MIRROR=/workspace/v10-dep-qualification
OUT=/workspace/v10-preparation/model-migration-monitor-ui-qualified-r22-20261029
mkdir "$OUT"
python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$OUT/source-pins.json" > "$OUT/snapshot.log" 2>&1
rc=$?; printf '%s\n' "$rc" > "$OUT/snapshot.exit"; if ((rc)); then exit "$rc"; fi
node /workspace/v10-preparation/check-snapshot-syntax.cjs "$OUT/source-pins.json" > "$OUT/syntax.log" 2>&1
rc=$?; printf '%s\n' "$rc" > "$OUT/syntax.exit"; if ((rc)); then exit "$rc"; fi
run_step() { local name="$1"; shift; set +e; "$@" > "$OUT/$name.log" 2>&1; local rc=$?; set -e; printf '%s\n' "$rc" > "$OUT/$name.exit"; if ((rc)); then return "$rc"; fi; }
cd "$MIRROR/ui"
run_step ui-monitor timeout 120s ../node_modules/.bin/vitest run src/components/AgentModelMigrationMonitor.test.tsx --maxWorkers=1 --reporter=verbose || exit $?
cd "$MIRROR"
run_step token-gates timeout 90s node scripts/check-token-gates.mjs || exit $?
sha256sum "$OUT"/*.log "$OUT"/*.exit "$OUT/source-pins.json" > "$OUT/SHA256SUMS"
LOCKED
