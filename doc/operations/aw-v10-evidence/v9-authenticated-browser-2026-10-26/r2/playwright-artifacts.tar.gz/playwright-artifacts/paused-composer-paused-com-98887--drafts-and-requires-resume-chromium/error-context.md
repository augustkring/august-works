# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: paused-composer.spec.ts >> paused composer: task chat preserves drafts and requires resume
- Location: tests/e2e/paused-composer.spec.ts:10:3

# Error details

```
Test timeout of 120000ms exceeded.
```

```
Error: apiRequestContext.patch: Target page, context or browser has been closed
```

# Page snapshot

```yaml
- generic [ref=e4]:
  - link "Skip to Main Content" [ref=e5] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e6]:
    - generic [ref=e7]:
      - generic [ref=e8]:
        - complementary [ref=e10]:
          - button "Open Paused composer 1793058916009 organization switcher" [ref=e12]:
            - generic [ref=e13]:
              - generic [ref=e14]: P
              - generic "Paused composer 1793058916009" [ref=e17]
          - navigation [ref=e18]:
            - generic [ref=e19]:
              - generic [ref=e20]:
                - text: Visning
                - combobox "Visning" [ref=e21]:
                  - option "Medlem"
                  - option "Leder" [selected]
                  - option "Administrator"
                  - option "Sikkerhedsadministrator"
              - link "Hjem" [ref=e22] [cursor=pointer]:
                - /url: /PAU/dashboard
              - link "Kræver dig" [ref=e28] [cursor=pointer]:
                - /url: /PAU/needs-you
              - link "Arbejde" [ref=e34] [cursor=pointer]:
                - /url: /PAU/work
              - link "Agenter" [ref=e40] [cursor=pointer]:
                - /url: /PAU/agents
              - link "Apps" [ref=e48] [cursor=pointer]:
                - /url: /PAU/apps
              - link "Indsigter" [ref=e58] [cursor=pointer]:
                - /url: /PAU/insights
              - link "Avanceret" [ref=e63] [cursor=pointer]:
                - /url: /PAU/advanced
              - generic [ref=e67]:
                - button "Spørg Blentera" [ref=e68]
                - link "Hjælp / Support" [ref=e69] [cursor=pointer]:
                  - /url: /PAU/company/help
        - button "Open account menu" [ref=e77]:
          - generic [ref=e78]: BR
          - generic [ref=e80]: Browser product reviewer
      - separator "Resize sidebar" [ref=e81]
    - generic [ref=e83]:
      - region "Globale funktioner" [ref=e85]:
        - button "Spørg Blentera" [ref=e86]
        - generic [ref=e89]:
          - generic [ref=e90]: Sprog
          - combobox "Sprog" [ref=e91]:
            - option "English"
            - option "Dansk" [selected]
        - link "Hjælp / Support" [ref=e92] [cursor=pointer]:
          - /url: /PAU/company/help
        - link "Kontakt support" [ref=e93] [cursor=pointer]:
          - /url: mailto:support@blentera.com
        - link "Brugerkonto" [ref=e94] [cursor=pointer]:
          - /url: /PAU/company/settings/instance/profile
      - generic [ref=e98]:
        - generic [ref=e99]:
          - generic [ref=e100]:
            - navigation "breadcrumb" [ref=e102]:
              - list [ref=e103]:
                - listitem [ref=e104]:
                  - link "Tasks" [ref=e105] [cursor=pointer]:
                    - /url: /PAU/issues
                - listitem [ref=e106]
                - listitem [ref=e109]:
                  - link "Backlog Review the paused composer PAU-1" [disabled] [ref=e110]:
                    - img "Backlog" [ref=e112]
                    - generic [ref=e121]: Review the paused composer
                    - generic [ref=e122]: PAU-1
            - button "Hide properties" [ref=e123]
          - main [ref=e124]:
            - tabpanel [ref=e127]:
              - generic [ref=e129]:
                - generic [ref=e134]:
                  - generic [ref=e136]:
                    - generic [ref=e137]:
                      - 'button "Change status (current: Backlog)" [ref=e139] [cursor=pointer]':
                        - img "Backlog" [ref=e140]
                      - generic [ref=e149]:
                        - heading "Review the paused composer" [level=2] [ref=e150] [cursor=pointer]
                        - generic [ref=e151]: PAU-1
                    - generic [ref=e152]:
                      - generic [ref=e153]: No project
                      - generic "Task people" [ref=e157]:
                        - 'generic "Assignee: Paused composer fixture" [ref=e158]'
                        - 'generic "Originating: Browser product reviewer" [ref=e160]': BR
                      - button "More task actions" [ref=e164]
                  - button "Add a description..." [ref=e166]
                - generic [ref=e173]:
                  - textbox "editable markdown" [ref=e179]:
                    - paragraph [ref=e180]: Keep this draft until I resume.
                  - generic [ref=e181]:
                    - button "Attach file" [ref=e182]
                    - button "Auto mode" [ref=e184]
                    - button "Paused composer fixture" [ref=e187]
                    - button "Send" [ref=e193]
        - complementary [ref=e196]:
          - separator "Resize panel" [ref=e197]
          - region "Side panel" [ref=e200]:
            - generic [ref=e201]:
              - generic [ref=e204]:
                - tablist [ref=e205]:
                  - generic [ref=e208]:
                    - tab "Properties" [selected] [ref=e209]
                    - button "Close Properties" [ref=e211]
                  - status [ref=e215]
                - button "Open a new tab" [ref=e217]
              - generic [ref=e219]:
                - button "Maximize side panel" [ref=e220]
                - button "Close side panel" [ref=e221]
            - tabpanel "Properties" [ref=e224]:
              - generic [ref=e225]:
                - generic [ref=e226]:
                  - generic [ref=e227]: Work
                  - generic [ref=e228]:
                    - generic [ref=e229]:
                      - generic "Status" [ref=e230]
                      - 'button "Change status (current: Backlog)" [ref=e232] [cursor=pointer]':
                        - img "Backlog" [ref=e233]
                        - generic [ref=e242]: Backlog
                    - generic [ref=e243]:
                      - generic "Assignee" [ref=e244]
                      - generic [ref=e245]:
                        - button "Paused composer fixture" [ref=e246] [cursor=pointer]
                        - link [ref=e252] [cursor=pointer]:
                          - /url: /PAU/agents/ab6929f9-1b78-4d96-96c1-307b37e37262
                    - generic [ref=e256]:
                      - generic "Project" [ref=e257]
                      - button "None" [ref=e259] [cursor=pointer]
                    - generic [ref=e263]:
                      - generic "Labels" [ref=e264]
                      - button "None" [ref=e266] [cursor=pointer]
                - generic [ref=e270]:
                  - generic [ref=e271]: Relationships
                  - generic [ref=e272]:
                    - generic [ref=e273]:
                      - generic "Parent" [ref=e274]
                      - button "None" [ref=e276] [cursor=pointer]
                    - generic [ref=e280]:
                      - generic "Blocked by" [ref=e281]
                      - button "None" [ref=e283] [cursor=pointer]
                    - generic [ref=e287]:
                      - generic "Blocking" [ref=e288]
                      - generic [ref=e289]: None
                    - generic [ref=e291]:
                      - generic "Subtasks" [ref=e292]
                      - button "None" [ref=e294] [cursor=pointer]
                - generic [ref=e298]:
                  - generic [ref=e299]: Execution
                  - generic [ref=e300]:
                    - generic [ref=e301]:
                      - generic "Reviewers" [ref=e302]
                      - button "None" [ref=e304] [cursor=pointer]
                    - generic [ref=e308]:
                      - generic "Approvers" [ref=e309]
                      - button "None" [ref=e311] [cursor=pointer]
                    - generic [ref=e315]:
                      - generic "Monitor" [ref=e316]
                      - button "None" [ref=e318] [cursor=pointer]
                    - generic [ref=e324]:
                      - generic "Watchdog" [ref=e325]
                      - button "None" [ref=e327] [cursor=pointer]
                - generic [ref=e331]:
                  - generic [ref=e332]: About
                  - generic [ref=e333]:
                    - generic [ref=e334]:
                      - generic "Originating" [ref=e335]
                      - generic "Browser product reviewer" [ref=e338]: BR
                    - generic [ref=e342]:
                      - generic "Created" [ref=e343]
                      - generic "Oct 26, 2026, 11:55 PM" [ref=e345]
                    - generic [ref=e346]:
                      - generic "Updated" [ref=e347]
                      - generic "just now" [ref=e349]
  - generic [ref=e351]:
    - heading "Command Palette" [level=2] [ref=e352]
    - paragraph [ref=e353]: Search for a command to run...
```

# Test source

```ts
  1  | import { test, expect, type APIResponse } from "@playwright/test";
  2  | 
  3  | async function json(response: APIResponse) {
  4  |   const body = await response.json();
  5  |   expect(response.ok(), JSON.stringify(body)).toBe(true);
  6  |   return body;
  7  | }
  8  | 
  9  | for (const classic of [false, true]) {
  10 |   test(`paused composer: ${classic ? "classic" : "task chat"} preserves drafts and requires resume`, async ({ page, request }) => {
  11 |     test.setTimeout(120_000);
  12 |     const company = await json(await request.post("/api/companies", { data: { name: `Paused composer ${Date.now()}` } }));
  13 |     const settings = await json(await request.get("/api/instance/settings/experimental"));
  14 |     try {
  15 |       await json(await request.patch("/api/instance/settings/experimental", { data: { enableClassicTaskInterface: classic } }));
  16 |       const agent = await json(await request.post(`/api/companies/${company.id}/agents`, { data: {
  17 |         name: "Paused composer fixture", role: "engineer", adapterType: "process",
  18 |         adapterConfig: { command: "/usr/bin/true" },
  19 |         runtimeConfig: { heartbeat: { enabled: false, wakeOnDemand: false } },
  20 |       } }));
  21 |       const task = await json(await request.post(`/api/companies/${company.id}/issues`, { data: {
  22 |         title: "Review the paused composer", status: "backlog", assigneeAgentId: agent.id,
  23 |       } }));
  24 |       await page.goto(`/${company.issuePrefix}/issues/${task.identifier}`);
  25 |       const editor = (classic ? page.getByTestId("issue-chat-composer") : page).getByRole("textbox", { name: "editable markdown" });
  26 |       await editor.fill("Keep this draft until I resume.");
  27 |       await page.getByRole("button", { name: "More task actions", exact: true }).click();
  28 |       await page.getByRole("button", { name: "Pause work", exact: true }).click();
  29 |       const takeover = page.getByTestId("paused-composer-takeover");
  30 |       await expect(takeover).toBeVisible();
  31 |       await expect(takeover).toContainText("Your draft is saved.");
  32 |       await expect(editor).toHaveCount(0);
  33 |       await expect(page.getByRole("button", { name: "Send", exact: true })).toHaveCount(0);
  34 |       await page.keyboard.press("Meta+Enter");
  35 |       const rejected = await request.post(`/api/issues/${task.id}/comments`, { data: { body: "Cannot send yet", reopen: true } });
  36 |       expect(rejected.status()).toBe(409);
  37 |       const rejectedUpdate = await request.patch(`/api/issues/${task.id}`, { data: { comment: "Cannot reassign and send", assigneeAgentId: null } });
  38 |       expect(rejectedUpdate.status()).toBe(409);
  39 |       expect((await json(await request.get(`/api/issues/${task.id}`))).assigneeAgentId).toBe(agent.id);
  40 |       expect(await json(await request.get(`/api/issues/${task.id}/comments`))).toHaveLength(0);
  41 |       await page.reload();
  42 |       await expect(takeover).toBeVisible();
  43 |       await expect(takeover).toContainText("Your draft is saved.");
  44 |       await takeover.getByRole("button", { name: "Resume task" }).click();
  45 |       const dialog = page.getByRole("dialog");
  46 |       await dialog.getByRole("button", { name: "Resume work", exact: true }).click();
  47 |       await expect(takeover).toHaveCount(0);
  48 |       await expect(editor).toHaveText("Keep this draft until I resume.");
  49 |       await page.getByRole("button", { name: "Send", exact: true }).click();
  50 |       await expect.poll(async () => (await json(await request.get(`/api/issues/${task.id}/comments`))).map((comment: { body: string }) => comment.body)).toEqual(["Keep this draft until I resume."]);
  51 | 
  52 |       // Ancestor pause is effective even when this child was created after it.
  53 |       await page.getByRole("button", { name: "More task actions", exact: true }).click();
  54 |       await page.getByRole("button", { name: "Pause work", exact: true }).click();
  55 |       await expect(takeover).toBeVisible();
  56 |       const child = await json(await request.post(`/api/companies/${company.id}/issues`, { data: {
  57 |         title: "Child held by parent", parentId: task.id, status: "backlog", assigneeAgentId: agent.id,
  58 |       } }));
  59 |       await page.goto(`/${company.issuePrefix}/issues/${child.identifier}`);
  60 |       await expect(takeover).toContainText("Subtree is paused.");
  61 |       await expect(editor).toHaveCount(0);
  62 |       expect((await request.post(`/api/issues/${child.id}/comments`, { data: { body: "Still paused" } })).status()).toBe(409);
  63 |       await takeover.getByRole("link", { name: "Resume subtree" }).click();
  64 |       await expect(page).toHaveURL(new RegExp(task.identifier));
  65 |       await takeover.getByRole("button", { name: "Resume subtree" }).click();
  66 |       await page.getByRole("dialog").getByRole("checkbox").uncheck();
  67 |       await page.getByRole("dialog").getByRole("button", { name: "Resume subtree", exact: true }).click();
  68 |       await page.goto(`/${company.issuePrefix}/issues/${child.identifier}`);
  69 |       await expect(takeover).toHaveCount(0);
  70 |       await expect(editor).toBeVisible();
  71 |     } finally {
> 72 |       await request.patch(`/api/companies/${company.id}`, { data: { status: "archived" } });
     |                     ^ Error: apiRequestContext.patch: Target page, context or browser has been closed
  73 |       await request.patch("/api/instance/settings/experimental", { data: { enableClassicTaskInterface: settings.enableClassicTaskInterface } });
  74 |     }
  75 |   });
  76 | }
  77 | 
```