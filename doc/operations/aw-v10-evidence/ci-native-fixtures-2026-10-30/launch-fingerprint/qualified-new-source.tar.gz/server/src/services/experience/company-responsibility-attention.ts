import { and, asc, eq, isNull, sql } from "drizzle-orm";
import {
  agents, aiUseCases, approvals, authUsers, billingAccountCompanies, billingAccounts,
  businessExperiments, businessMetrics, companyAgentPackageInstallations, companyMemberships,
  companySkillPolicies, companies, decisions, issueApprovals, issues, toolApplications,
  toolPolicies, workflows, type Db,
} from "@paperclipai/db";
import type { ExperienceCard } from "@paperclipai/shared";
import type { AuthorizationAction, AuthorizationActor, AuthorizationResource } from "../authorization.js";
import { authorizationService } from "../authorization.js";
import { accessService } from "../access.js";
import { issueService } from "../issues.js";
import { businessMetricService } from "../business-metrics/service.js";
import { businessExperimentService } from "../business-experiments/service.js";
import { aiGovernanceService } from "../ai-governance/governance-service.js";
import { resolveCurrentDefaultResponsibleHuman } from "../company-responsibility.js";
import { nativeSha256 } from "../native-runtime/canonical.js";

const KIND_CAP = 40;
const TOTAL_CAP = 600;
type Candidate = { id: string; ownerUserId: string | null; updatedAt: Date; agentId?: string | null; issueId?: string | null };
type Kind = "agent" | "deployment" | "workflow" | "connector" | "metric" | "experiment" |
  "decision" | "approval" | "ai_use_case" | "policy" | "billing";
type Adapter = {
  kind: Kind; title: string; action: string; view: AuthorizationAction; ownerPermission: string | null;
  readRows: (db: Db, companyId: string, actor: AuthorizationActor) => Promise<Candidate[]>;
};

/** Company responsibility inventory is an authorized, source-backed subset.
 * Each adapter reads its own native production rows and permission vocabulary;
 * the projection never assigns owners, changes lifecycle state, or copies grants. */
const adapters: Adapter[] = [
  { kind: "agent", title: "Co-worker", action: "/agents", view: "agent:read", ownerPermission: "agents:configure",
    readRows: (db, companyId) => db.select({ id: agents.id, ownerUserId: sql<string | null>`null`, updatedAt: agents.updatedAt, agentId: agents.id })
      .from(agents).where(and(eq(agents.companyId, companyId), sql`${agents.status} not in ('terminated','archived','deleted')`)).orderBy(asc(agents.id)).limit(KIND_CAP + 1) },
  { kind: "deployment", title: "Agent Package deployment", action: "/agents", view: "agents:configure", ownerPermission: "agents:configure",
    readRows: (db, companyId) => db.select({ id: companyAgentPackageInstallations.id,
      ownerUserId: aiUseCases.ownerUserId, updatedAt: companyAgentPackageInstallations.updatedAt,
      agentId: companyAgentPackageInstallations.agentId })
      .from(companyAgentPackageInstallations).leftJoin(aiUseCases, and(eq(aiUseCases.companyId, companyId),
        eq(aiUseCases.id, companyAgentPackageInstallations.aiUseCaseId)))
      .where(and(eq(companyAgentPackageInstallations.companyId, companyId),
        sql`${companyAgentPackageInstallations.status} in ('active','readiness_blocked','degraded','needs_update')`))
      .orderBy(asc(companyAgentPackageInstallations.id)).limit(KIND_CAP + 1) },
  { kind: "workflow", title: "Workflow", action: "/workflows", view: "workflows:read", ownerPermission: "workflows:edit",
    readRows: (db, companyId) => db.select({ id: workflows.id, ownerUserId: sql<string | null>`null`, updatedAt: workflows.updatedAt })
      .from(workflows).where(and(eq(workflows.companyId, companyId), isNull(workflows.archivedAt), sql`${workflows.status} <> 'archived'`))
      .orderBy(asc(workflows.id)).limit(KIND_CAP + 1) },
  { kind: "connector", title: "Critical connector", action: "/apps", view: "tools:manage_connections", ownerPermission: "tools:manage_connections",
    readRows: (db, companyId) => db.select({ id: toolApplications.id, ownerUserId: toolApplications.ownerUserId,
      updatedAt: toolApplications.updatedAt }).from(toolApplications)
      .where(and(eq(toolApplications.companyId, companyId), eq(toolApplications.status, "active"), isNull(toolApplications.archivedAt)))
      .orderBy(asc(toolApplications.id)).limit(KIND_CAP + 1) },
  { kind: "metric", title: "Governed metric", action: "/company/analytics", view: "company_scope:read", ownerPermission: "users:manage_permissions",
    readRows: async (db, companyId, actor) => {
      const candidates = await db.select({ id: sql<string>`id`, ownerUserId: sql<string | null>`null`, updatedAt: sql<Date>`updated_at` })
        .from(businessMetrics).where(and(eq(businessMetrics.companyId, companyId), eq(businessMetrics.status, "published"))).orderBy(asc(businessMetrics.id)).limit(KIND_CAP + 1);
      const visible: Candidate[] = [];
      for (const row of candidates) { try { await businessMetricService(db).detail(companyId, actor, row.id); visible.push(row); }
        catch (error) { if (!(error && typeof error === "object" && "status" in error && [403, 404, 409].includes(Number(error.status)))) throw error; } }
      return visible;
    } },
  { kind: "experiment", title: "Experiment", action: "/company/experiments", view: "company_scope:read", ownerPermission: "users:manage_permissions",
    readRows: async (db, companyId, actor) => {
      const candidates = await db.select({ id: sql<string>`id`, ownerUserId: sql<string | null>`null`, updatedAt: sql<Date>`updated_at` })
        .from(businessExperiments).where(and(eq(businessExperiments.companyId, companyId),
          sql`${businessExperiments.state} in ('in_review','ready','running','paused','analyzing')`))
        .orderBy(asc(businessExperiments.id)).limit(KIND_CAP + 1);
      const visible: Candidate[] = [];
      for (const row of candidates) { try { await businessExperimentService(db).detail(companyId, actor, row.id); visible.push(row); }
        catch (error) { if (!(error && typeof error === "object" && "status" in error && [403, 404, 409].includes(Number(error.status)))) throw error; } }
      return visible;
    } },
  { kind: "decision", title: "Material Decision", action: "/decisions", view: "decision_queue:read", ownerPermission: "decision_queue:manage",
    readRows: (db, companyId) => db.select({ id: decisions.id, ownerUserId: issues.assigneeUserId,
      updatedAt: decisions.updatedAt, issueId: issues.id }).from(decisions)
      .innerJoin(issues, and(eq(issues.companyId, decisions.companyId), eq(issues.id, decisions.originIssueId)))
      .where(and(eq(decisions.companyId, companyId), eq(decisions.status, "open"), sql`${decisions.expiresAt} > now()`, isNull(issues.hiddenAt)))
      .orderBy(asc(decisions.id)).limit(KIND_CAP + 1) },
  { kind: "approval", title: "Pending approval", action: "/approvals", view: "company_scope:read", ownerPermission: null,
    readRows: async (db, companyId) => {
      const linked = await db.select({ id: approvals.id, updatedAt: approvals.updatedAt, issueId: issues.id })
        .from(issueApprovals).innerJoin(approvals, and(eq(approvals.companyId, issueApprovals.companyId), eq(approvals.id, issueApprovals.approvalId)))
        .innerJoin(issues, and(eq(issues.companyId, issueApprovals.companyId), eq(issues.id, issueApprovals.issueId)))
        .where(and(eq(issueApprovals.companyId, companyId), sql`${approvals.status} in ('pending','revision_requested')`, isNull(issues.hiddenAt)))
        .orderBy(asc(approvals.id)).limit(KIND_CAP + 1);
      return linked.map(row => ({ ...row, ownerUserId: null }));
    } },
  { kind: "ai_use_case", title: "AI Use Case", action: "/governance/ai-use-cases", view: "company_scope:read", ownerPermission: "users:manage_permissions",
    readRows: async (db, companyId, actor) => {
      const candidates = await db.select({ id: aiUseCases.id, updatedAt: aiUseCases.updatedAt })
        .from(aiUseCases).where(and(eq(aiUseCases.companyId, companyId), sql`${aiUseCases.status} in ('approved','assessing','restricted','suspended')`))
        .orderBy(asc(aiUseCases.id)).limit(KIND_CAP + 1);
      const visible: Candidate[] = [];
      for (const row of candidates) { try { const useCase = await aiGovernanceService(db).get(actor, companyId, row.id);
        visible.push({ id: row.id, ownerUserId: useCase.ownerUserId, updatedAt: row.updatedAt }); }
        catch (error) { if (!(error && typeof error === "object" && "status" in error && [403, 404, 409].includes(Number(error.status)))) throw error; } }
      return visible;
    } },
  { kind: "policy", title: "Policy", action: "/settings/agent-permissions", view: "tools:manage_profiles", ownerPermission: "tools:manage_profiles",
    readRows: async (db, companyId) => {
      const rows = await db.select({ id: toolPolicies.id, updatedAt: toolPolicies.updatedAt }).from(toolPolicies)
        .where(eq(toolPolicies.companyId, companyId)).orderBy(asc(toolPolicies.id)).limit(KIND_CAP + 1);
      const skills = await db.select({ id: companySkillPolicies.companyId, updatedAt: companySkillPolicies.updatedAt })
        .from(companySkillPolicies).where(eq(companySkillPolicies.companyId, companyId)).limit(1);
      return [...rows.map(row => ({ ...row, ownerUserId: null })), ...skills.map(row => ({ ...row, ownerUserId: null }))];
    } },
  { kind: "billing", title: "Billing responsibility", action: "/settings/billing", view: "billing:view", ownerPermission: "billing:manage",
    readRows: (db, companyId) => db.select({ id: billingAccounts.id, ownerUserId: billingAccounts.payerUserId, updatedAt: billingAccounts.updatedAt })
      .from(billingAccountCompanies).innerJoin(billingAccounts, eq(billingAccounts.id, billingAccountCompanies.billingAccountId))
      .where(and(eq(billingAccountCompanies.companyId, companyId), eq(billingAccountCompanies.status, "active"),
        eq(billingAccounts.status, "active"), isNull(billingAccounts.closedAt))).orderBy(asc(billingAccounts.id)).limit(KIND_CAP + 1) },
];

export async function readCompanyResponsibilityAttention(db: Db, actor: AuthorizationActor, companyId: string, signal: AbortSignal): Promise<{
  needsYou: ExperienceCard[]; coverage?: { state: "partial"; reason: "overflow" | "source_stale" };
}> {
  const empty = { needsYou: [] as ExperienceCard[] };
  if (actor.type !== "board" || !actor.userId || actor.source === "local_implicit") return empty;
  return db.transaction(async raw => {
    const tx = raw as unknown as Db;
    await tx.execute(sql`set local statement_timeout='1500ms'`);
    await tx.execute(sql`set local lock_timeout='200ms'`);
    const auth = authorizationService(tx), permissions = accessService(tx);
    const managerActor = { ...actor, isInstanceAdmin: false, ignoreInstanceAdmin: true };
    const allowed = async (action: AuthorizationAction, resource: AuthorizationResource = { type: "company", companyId }) => {
      signal.throwIfAborted();
      return (await auth.decide({ actor: managerActor, action, resource })).allowed;
    };
    const currentMember = async (principal: string) => {
      const [row] = await tx.select({ id: companyMemberships.id }).from(companyMemberships)
        .innerJoin(authUsers, and(eq(authUsers.id, companyMemberships.principalId), eq(authUsers.emailVerified, true)))
        .where(and(eq(companyMemberships.companyId, companyId), eq(companyMemberships.principalType, "user"),
          eq(companyMemberships.principalId, principal), eq(companyMemberships.status, "active"))).limit(1);
      return Boolean(row);
    };
    if (!await currentMember(actor.userId) || !await allowed("company_scope:read") ||
      !await allowed("users:manage_permissions")) return empty;
    const defaultOwner = await resolveCurrentDefaultResponsibleHuman(tx, companyId);
    const cards: ExperienceCard[] = [];
    let total = 0;
    const ownerCheck = new Map<string, Promise<boolean>>();
    for (const adapter of adapters) {
      signal.throwIfAborted();
      if (!await allowed(adapter.view)) continue;
      const rows = await adapter.readRows(tx, companyId, managerActor);
      total += rows.length;
      if (rows.length > KIND_CAP || total > TOTAL_CAP) return { ...empty, coverage: { state: "partial", reason: "overflow" } };
      const readable: Candidate[] = [];
      for (const row of rows) {
        signal.throwIfAborted();
        if (adapter.kind === "agent" && row.agentId && !await allowed("agent:read", { type: "agent", companyId, agentId: row.agentId })) continue;
        if (adapter.kind === "decision" && row.issueId) {
          const issue = await issueService(tx).getById(row.issueId);
          if (!issue || issue.companyId !== companyId || !await allowed("issue:read", {
            type: "issue", companyId, issueId: issue.id, projectId: issue.projectId, parentIssueId: issue.parentId,
            status: issue.status, assigneeAgentId: issue.assigneeAgentId, assigneeUserId: issue.assigneeUserId,
          })) continue;
        }
        if (adapter.kind === "approval" && row.issueId) {
          const issue = await issueService(tx).getById(row.issueId);
          if (!issue || issue.companyId !== companyId || !await allowed("issue:read", {
            type: "issue", companyId, issueId: issue.id, projectId: issue.projectId, parentIssueId: issue.parentId,
            status: issue.status, assigneeAgentId: issue.assigneeAgentId, assigneeUserId: issue.assigneeUserId,
          })) continue;
        }
        readable.push(row);
      }
      const orphans: Candidate[] = [];
      for (const row of readable) {
        const assigned = row.ownerUserId;
        let ownerValid = false;
        if (assigned && adapter.ownerPermission) {
          const key = `${assigned}:${adapter.ownerPermission}`;
          let check = ownerCheck.get(key);
          if (!check) {
            check = currentMember(assigned).then(member => member && permissions.hasPermission(companyId, "user", assigned, adapter.ownerPermission!));
            ownerCheck.set(key, check);
          }
          ownerValid = await check;
        }
        if (!ownerValid && defaultOwner && adapter.ownerPermission) {
          const key = `${defaultOwner}:${adapter.ownerPermission}`;
          let check = ownerCheck.get(key);
          if (!check) {
            check = currentMember(defaultOwner).then(member => member && permissions.hasPermission(companyId, "user", defaultOwner, adapter.ownerPermission!));
            ownerCheck.set(key, check);
          }
          ownerValid = await check;
        }
        if (!ownerValid) orphans.push(row);
      }
      if (!orphans.length) continue;
      const source = { domain: "company_responsibility" as const, companyId, resourceId: adapter.kind,
        version: nativeSha256(orphans.map(row => [row.id, row.updatedAt.toISOString()]).sort()), observedAt: new Date().toISOString() };
      cards.push({ id: `company-responsibility:${companyId}:${adapter.kind}`, kind: "recovery", source, freshness: "fresh",
        title: `Review ${adapter.title.toLowerCase()} responsibility`,
        whyYou: "You manage this company's people and access. This is only the subset you are currently authorized to read.",
        consequence: `${orphans.length} currently readable ${adapter.title.toLowerCase()} ${orphans.length === 1 ? "needs" : "need"} an authorized responsible Human. Review through its native owner flow; repair authority does not assign ownership.`,
        evidence: ["company_responsibility_authorized_subset", adapter.kind],
        actions: [{ id: "review-native-owner", label: `Review ${adapter.title.toLowerCase()}`, labelKey: "review", operation: "open",
          href: adapter.action, criticality: "C3", source, requiresCurrentAuthorization: true }] });
    }
    // Security and tenant support follow-up have no tenant-owned case/contact
    // row. Only the manager-visible company default-contact setting can cause
    // these generic repair links; private support cases never enter this scan.
    const [company] = await tx.select({ defaultResponsibleUserId: companies.defaultResponsibleUserId }).from(companies)
      .where(eq(companies.id, companyId)).limit(1);
    if (!defaultOwner && company && await allowed("users:manage_permissions")) {
      const source = { domain: "company_responsibility" as const, companyId, resourceId: "company_contacts",
        version: nativeSha256([company.defaultResponsibleUserId]), observedAt: new Date().toISOString() };
      cards.push({ id: `company-responsibility:${companyId}:company_contacts`, kind: "recovery", source, freshness: "fresh",
        title: "Review company responsibility contacts", whyYou: "This review is based only on company responsibility settings visible to you.",
        consequence: "Set an authorized company default responsible Human for tenant security and support follow-up. This does not assign Platform Security or private support cases.",
        evidence: ["company_contact_setting_authorized_subset"], actions: [{ id: "review-company-contact", label: "Review company responsibility", labelKey: "review",
          operation: "open", href: "/company/settings/members", criticality: "C3", source, requiresCurrentAuthorization: true }] });
    }
    if (!await currentMember(actor.userId) || !await allowed("users:manage_permissions")) return empty;
    return { needsYou: cards };
  });
}
