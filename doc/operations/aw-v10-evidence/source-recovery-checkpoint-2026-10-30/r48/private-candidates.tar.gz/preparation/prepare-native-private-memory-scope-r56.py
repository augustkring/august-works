from pathlib import Path
import hashlib,json,difflib
r=Path('/workspace/blentera-v10');o=Path('/workspace/v10-preparation/native-private-memory-scope-r56-candidate');rel='server/src/services/native-direct-input.ts';a=(r/rel).read_text();s=a
needle='''async function assertNativeMemoryToolInvocationCurrentInScope(db: Db | Transaction, input: {''';assert needle in s
helper='''function nativeMemoryOwnerReadScopeMatches(db: Db | Transaction, companyId: string,
  reader: AuthorizationActor, scope: NativeSourceReadScope): boolean {
  return is(db, PgTransaction) && scope.context.active && nativeSourceReadScopes.getStore() === scope.context &&
    scope.context.db === (db as object) && !scope.context.ancestry.graphProofsDisabled &&
    scope.context.privacyLockedCompanies.has(companyId) && scope.actorKey === nativeSha256(reader) &&
    scope.context.memoryTemporalIdentity === activeMemoryTemporalReadScopeIdentity(db, reader);
}

'''
s=s.replace(needle,helper+needle,1)
s=s.replace('return assertNativeMemoryToolInvocationCurrentInScope(tx, input);','return assertNativeMemoryToolInvocationCurrentInScope(tx, input, scope);',1)
start=s.index('async function assertNativeMemoryToolInvocationCurrentInScope(');end=s.index('\n/** Validate the consumed',start);part=s[start:end]
part=part.replace('''}): Promise<void> {
  const use''','''}, scope: NativeSourceReadScope): Promise<void> {
  const use''',1)
needle='''  await assertNativeModelOutputCaptureCurrent(db, input.companyId, input.issueId, input.capture,
    "paperclip-self:remember", input.currentReader ?? input.actor,
    input.status === "succeeded" ? "settled" : "live");''';assert needle in part
part=part.replace(needle,'''  const reader = input.currentReader ?? input.actor;
  const conversationState = input.status === "succeeded" ? "settled" : "live";
  if (nativeMemoryOwnerReadScopeMatches(db, input.companyId, reader, scope)) {
    await assertNativeModelOutputCaptureCurrentInScope(db, input.companyId, input.issueId, input.capture,
      "paperclip-self:remember", scope, 0, reader, conversationState);
  } else {
    await assertNativeModelOutputCaptureCurrent(db, input.companyId, input.issueId, input.capture,
      "paperclip-self:remember", reader, conversationState);
  }''',1);s=s[:start]+part+s[end:]
needle='''  await assertNativeMemoryToolInvocationCurrent(db, { companyId: input.companyId, issueId: run.nativeIssueId,
    actor: inputActor, capture, invocationId, status: "succeeded", resultHash: invocation.resultHash, currentReader: input.actor });''';assert needle in s
s=s.replace(needle,'''  const invocationInput: Parameters<typeof assertNativeMemoryToolInvocationCurrent>[1] = {
    companyId: input.companyId, issueId: run.nativeIssueId, actor: inputActor, capture, invocationId,
    status: "succeeded", resultHash: invocation.resultHash, currentReader: input.actor };
  // This is one callback-free owner validation. Its public boundary already
  // owns admission, fresh mutable maps and the final reader/company fences.
  if (nativeMemoryOwnerReadScopeMatches(db, input.companyId, input.actor, scope))
    await assertNativeMemoryToolInvocationCurrentInScope(db, invocationInput, scope);
  else await assertNativeMemoryToolInvocationCurrent(db, invocationInput);''',1)
p=o/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);(o/'candidate.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)));(o/'manifest.json').write_text(json.dumps({rel:{'priorSha256':hashlib.sha256(a.encode()).hexdigest(),'candidateSha256':hashlib.sha256(s.encode()).hexdigest()}},indent=2))
