# R14.1 focused qualification receipt

Runner: `../qualify-r14.1.sh`; dependency mirror `/workspace/v10-dep-qualification`; lock `/workspace/v10-preparation/v10-pg-tests.lock`; current source head `ae983829e2bc2e5db2064769c72e700eeaf0a600`.

Source snapshot, syntax check, per-path parent/candidate hash guard, and the official local prover SHA check passed. Tests: host-agent 51/51; auth/JWT, policy, and backend 75/75 with the pinned prover; selected Task-broker test 1 pass; qualification-fault tests 13/13. Existing sandbox-host integration: 18 pass, 3 fail due the two outdated test scenarios documented in the parent README (post-version-bump replay and missing setup-only credential canary fixture). Shared typecheck passed. Full server TSC returned two unrelated current Native source errors in `native-direct-input.ts:272–273`; no diagnostics referred to candidate files.

The runner's `restore.log` and `build-restore.log` both confirm exact restoration of overlaid sources and dist/tsbuildinfo. This is partial software qualification only; it makes no physical-host or provider claim.
