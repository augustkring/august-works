from pathlib import Path
p=Path('/workspace/blentera-v10/server/src/services/native-direct-input.ts');s=p.read_text()
# Bind each public invocation to fresh admission, with no retained authorization result.
needle='''function withNativeSourceReadScope<T>(db: Db | Transaction, actor: AuthorizationActor,
  read: (scope: NativeSourceReadScope) => Promise<T>, proofMemo?: NativeMemoryPageStructuralProofMemo): Promise<T> {''';assert s.count(needle)==1
s=s.replace(needle,'''function withNativeSourceReadScope<T>(db: Db | Transaction, actor: AuthorizationActor, companyId: string | null,
  read: (scope: NativeSourceReadScope) => Promise<T>, proofMemo?: NativeMemoryPageStructuralProofMemo): Promise<T> {''')
s=s.replace('const readPublicInvocation = (scope: NativeSourceReadScope) => {','const readPublicInvocation = async (scope: NativeSourceReadScope) => {',1)
needle='''    return read(invocationScope);
  };''';assert s.count(needle)==1;s=s.replace(needle,'''    if (companyId && !await nativeSourceReaderHasCompanyAccess(db, companyId, actor))
      throw forbidden("The Native source reader is unavailable");
    const result = await read(invocationScope);
    if (companyId && !await nativeSourceReaderHasCompanyAccess(db, companyId, actor))
      throw forbidden("The Native source reader is unavailable");
    return result;
  };''')
needle='''      await flushNativeSourceReaderChecks(scope.context);
      return result;''';assert s.count(needle)==1;s=s.replace(needle,'''      await flushNativeSourceReaderChecks(scope.context);
      if (companyId && !await nativeSourceReaderHasCompanyAccess(db, companyId, actor))
        throw forbidden("The Native source reader is unavailable");
      return result;''')
# All callers are public entry boundaries; producer-fallback output capture is guarded below after its exact row binding.
assert s.count('withNativeSourceReadScope(tx, input.actor,')==9,s.count('withNativeSourceReadScope(tx, input.actor,')
s=s.replace('withNativeSourceReadScope(tx, input.actor,','withNativeSourceReadScope(tx, input.actor, input.companyId,')
assert s.count('withNativeSourceReadScope(tx, reader,')==1;s=s.replace('withNativeSourceReadScope(tx, reader,','withNativeSourceReadScope(tx, reader, input.companyId,')
assert s.count('withNativeSourceReadScope(tx, actor,')==2
s=s.replace('withNativeSourceReadScope(tx, actor, async scope => {','withNativeSourceReadScope(tx, actor, currentReader ? companyId : null, async scope => {',1)
s=s.replace('withNativeSourceReadScope(tx, actor, async scope => {','withNativeSourceReadScope(tx, actor, companyId, async scope => {',1)
# The private graph traversal already follows a freshly admitted public reader.
a=s.index('async function assertNativePayloadSourceSetCurrentInScope(');b=s.index('\n}\n',a);c=s[a:b];needle='''  if (!await nativeSourceReaderHasCompanyAccess(db, input.companyId, input.actor))
    throw forbidden("The Native source prefix is unavailable");
''';assert c.count(needle)==1;c=c.replace(needle,'');s=s[:a]+c+s[b:]
for name in ['assertNativeManagedConsumedSourceSetCurrentInScope','assertNativeManagedConsumedSourceSetCurrentUncached']:
 a=s.index('async function '+name+'(');b=s.index('\n}\n',a);c=s[a:b];needle=''' ||
    !await nativeSourceReaderHasCompanyAccess(db, input.companyId, input.actor)''';assert c.count(needle)==1;c=c.replace(needle,'');s=s[:a]+c+s[b:]
# The private Context binding reader is reached from admitted source/capture graphs, or its own admitted public wrapper.
a=s.index('async function assertNativeContextReadSourceSetCurrentInScope(');b=s.index('\n}\n',a);c=s[a:b];needle=''' ||
    !await nativeSourceReaderHasCompanyAccess(db, input.companyId, input.actor)''';assert c.count(needle)==1;c=c.replace(needle,'');s=s[:a]+c+s[b:]
# Preserve the no-currentReader server-only producer proof: authenticate its actor before any source walk and after all own row waits.
a=s.index('async function assertNativeModelOutputCaptureCurrentInScope(');b=s.index('\n}\n',a);c=s[a:b];needle='''    agentId: run.agentId, runId: run.id, onBehalfOfUserId: run.responsibleUserId };
''';assert c.count(needle)==1;c=c.replace(needle,needle+'''  if (!currentReader && !await nativeSourceReaderHasCompanyAccess(db, companyId, actor))
    throw forbidden("The Native output reader is unavailable");
''')
needle='''    policy: capture.sourceSet.policy, inputs: capture.sourceSet.inputs });
''';assert c.count(needle)==1;c=c.replace(needle,needle+'''  if (!currentReader && !await nativeSourceReaderHasCompanyAccess(db, companyId, actor))
    throw forbidden("The Native output reader is unavailable");
''');s=s[:a]+c+s[b:]
# This standalone public Memory input reader has no Native scope wrapper.
a=s.index('export async function assertNativeMemorySourceInputCurrent(');b=s.index('\n}\n',a);c=s[a:b];needle='''  await assertNativeMemorySourceCurrent(db, input.companyId, input.actor, input.source, input.transitionEvidence);''';assert c.count(needle)==1;c=c.replace(needle,needle+'''
  if (!await nativeSourceReaderHasCompanyAccess(db, input.companyId, input.actor))
    throw forbidden("A Native Memory source is unavailable");''');s=s[:a]+c+s[b:]
Path('/workspace/v10-preparation/native-private-admission-dedup-candidate.ts').write_text(s)
