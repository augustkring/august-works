#!/usr/bin/env bash
# Prepared canonical full-check runner. Intentionally not executed before the
# source freeze and disk preflight. Usage after freeze:
#   V10_SOURCE_FREEZE=1 run-final-workspace-aggregate-20261101.sh <expected-main-head>
set -Eeuo pipefail

LOCK=/workspace/v10-preparation/v10-pg-tests.lock
if [[ ${1:-} != --locked ]]; then
  exec flock -x "$LOCK" "$0" --locked "$@"
fi
shift

EXPECTED_HEAD=${1:-}
if [[ ${V10_SOURCE_FREEZE:-} != 1 || ! "$EXPECTED_HEAD" =~ ^[0-9a-f]{40}$ ]]; then
  echo 'Refusing aggregate checks: set V10_SOURCE_FREEZE=1 and pass the frozen 40-character MAIN HEAD.' >&2
  exit 64
fi

source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH

MAIN=/workspace/blentera-v10
MIRROR=/workspace/v10-dep-qualification
RUST_CACHE=${V10_AGGREGATE_CARGO_TARGET_DIR:-/tmp/blentera-final-source-rust-target-20261101}
EXPECTED_RUNNERD_SHA256=31964806291c8eac3cad8b18bc26c1d3377191fb46f1f1e65aee2595a5697604
OUT=/workspace/v10-preparation/final-workspace-aggregate-20261101-$(date -u +%H%M%S)
mkdir "$OUT"

exec 9>"$OUT/runner.lock"
flock -n 9 || { echo "Evidence directory already active: $OUT" >&2; exit 73; }

TEST_TMP=/tmp/v10-final-workspace-test-tmp-$(date -u +%Y%m%dT%H%M%SZ)-$$
test_tmp_cleaned=0
finish() {
  rc=$?
  printf '%s\n' "$rc" > "$OUT/exit"
  if [[ $test_tmp_cleaned == 1 && -d "$TEST_TMP" && "$TEST_TMP" == /tmp/v10-final-workspace-test-tmp-* ]]; then
    rm -rf -- "$TEST_TMP"
    printf '%s\n' 'removed exact runner-owned PAPERCLIP_TEST_TMPDIR after passing full test:run' > "$OUT/temp-cleanup.txt"
  elif [[ -d "$TEST_TMP" ]]; then
    printf '%s\n' "preserved test temp for diagnosis: $TEST_TMP" > "$OUT/temp-cleanup.txt"
  fi
  if [[ -f "$OUT/source-pins.json" ]]; then
    (cd "$OUT" && find . -type f ! -name artifact-sha256sums.txt ! -name runner.lock -print0 | sort -z | xargs -0 -r sha256sum > artifact-sha256sums.txt) || true
  fi
  exit "$rc"
}
trap finish EXIT

cd "$MAIN"
ACTUAL_HEAD=$(git rev-parse HEAD)
[[ "$ACTUAL_HEAD" == "$EXPECTED_HEAD" ]] || { echo "MAIN HEAD changed after freeze: expected=$EXPECTED_HEAD actual=$ACTUAL_HEAD" >&2; exit 65; }
printf '%s\n' "$ACTUAL_HEAD" > "$OUT/main-head.txt"
git status --porcelain=v1 > "$OUT/main-status-before.txt"

# A stable dirty tree is not the committed source freeze named by EXPECTED_HEAD.
python3 - "$MAIN" "$OUT/source-freeze.json" <<'PY_FREEZE'
import json,pathlib,subprocess,sys
repo=pathlib.Path(sys.argv[1])
def git(*args): return subprocess.check_output(['git',*args],cwd=repo)
if git('status','--porcelain=v1','--untracked-files=no').strip():
    raise SystemExit('Aggregate requires committed tracked source at the frozen HEAD')
untracked=[p.decode() for p in git('ls-files','--others','--exclude-standard','-z').split(b'\0') if p]
matrix=json.loads((repo/'doc/operations/aw-v10-evidence/v10-169-migration-phases-current-2026-10-30/phase-matrix.json').read_text())
named={pin['path'] for pin in matrix.get('sourcePins',[])}
if any(not p.startswith('doc/operations/aw-v10-evidence/') or p in named for p in untracked):
    raise SystemExit('Aggregate requires committed source and named inputs; only unrelated evidence archives may remain untracked')
pathlib.Path(sys.argv[2]).write_text(json.dumps({'head':git('rev-parse','HEAD').decode().strip(),'sourceDirty':False,'excludedUntrackedEvidenceFiles':len(untracked)},indent=2)+'\n')
PY_FREEZE

# Default free-space floors reflect the incremental outputs, not the occupied
# workspace: package dist directories already exist; the major absent output
# is server/dist, which vendors the existing 58 MiB runner dist plus compiled
# server/assets. Vitest roots are isolated below TEST_TMP and removed on test
# success. The TMP floor also covers the runner package's owned release-test
# artifacts; root Vitest alone does not execute that package. Floors are
# configurable only after measuring the current build and test outputs.
available_kib() { df -Pk "$1" | awk 'NR==2 {print $4}'; }
ROOT_FREE_KIB=$(available_kib /workspace)
TMP_FREE_KIB=$(available_kib /tmp)
MIN_WORKSPACE_KIB=${V10_AGGREGATE_MIN_WORKSPACE_KIB:-131072}
MIN_TMP_KIB=${V10_AGGREGATE_MIN_TMP_KIB:-1048576}
[[ "$MIN_WORKSPACE_KIB" =~ ^[0-9]+$ && "$MIN_TMP_KIB" =~ ^[0-9]+$ ]] || { echo 'Disk floors must be non-negative integer KiB values' >&2; exit 64; }
printf 'workspace_free_kib=%s\ntmp_free_kib=%s\nminimum_workspace_free_kib=%s\nminimum_tmp_free_kib=%s\n' \
  "$ROOT_FREE_KIB" "$TMP_FREE_KIB" "$MIN_WORKSPACE_KIB" "$MIN_TMP_KIB" > "$OUT/disk-before.txt"
if (( ROOT_FREE_KIB < MIN_WORKSPACE_KIB || TMP_FREE_KIB < MIN_TMP_KIB )); then
  echo "Insufficient measured headroom for configured floors; workspace=${ROOT_FREE_KIB}/${MIN_WORKSPACE_KIB} KiB, tmp=${TMP_FREE_KIB}/${MIN_TMP_KIB} KiB. Override V10_AGGREGATE_MIN_WORKSPACE_KIB or V10_AGGREGATE_MIN_TMP_KIB if a lower floor is justified." >&2
  exit 69
fi

[[ -d "$MIRROR" && -f "$MIRROR/pnpm-lock.yaml" && -d "$MIRROR/node_modules" ]] || { echo 'Qualified mirror/dependencies missing' >&2; exit 66; }
cmp -s "$MAIN/pnpm-lock.yaml" "$MIRROR/pnpm-lock.yaml" || { echo 'MAIN/mirror frozen lock differs' >&2; exit 66; }
# The prior /tmp cache was lost when the environment restarted. The retained
# baseline binary is still exact; a missing cache is a build input, not a reason
# to skip the required Rust checks. Cargo will check/build final frozen source.
BASELINE_RUNNERD="$MIRROR/packages/paperclip-runner/dist/bin/paperclip-runnerd"
[[ -x "$BASELINE_RUNNERD" ]] || { echo 'Retained runner baseline missing' >&2; exit 67; }
RUNNERD_SHA=$(sha256sum "$BASELINE_RUNNERD" | awk '{print $1}')
[[ "$RUNNERD_SHA" == "$EXPECTED_RUNNERD_SHA256" ]] || { echo "Retained baseline binary pin mismatch: $RUNNERD_SHA" >&2; exit 67; }
printf '%s  %s\n' "$RUNNERD_SHA" "$BASELINE_RUNNERD" > "$OUT/retained-baseline-runnerd.sha256"
[[ "$RUST_CACHE" == /tmp/blentera-* && ! -L "$RUST_CACHE" ]] || { echo 'Unexpected Cargo target path' >&2; exit 67; }
mkdir -p "$RUST_CACHE"
# Existing integration tests and the package staging script use runner/target.
# Both checkouts already point that path at this legacy cache alias. Repair the
# missing alias once, without overwriting any directory or another cache link.
python3 - "$RUST_CACHE" "$OUT/cargo-target-layout.json" <<'PY_TARGET'
import json,os,pathlib,sys
cache=pathlib.Path(sys.argv[1]); alias=pathlib.Path('/tmp/blentera-preserved-current-rust-target')
if alias.is_symlink():
    assert alias.resolve()==cache.resolve(), 'legacy Cargo alias names a different cache'
elif alias.exists():
    assert alias.resolve()==cache.resolve(), 'refusing to replace an existing Cargo directory'
else:
    alias.symlink_to(cache,target_is_directory=True)
checks=[]
for root in ['/workspace/blentera-v10','/workspace/v10-dep-qualification']:
    target=pathlib.Path(root)/'packages/paperclip-runner/runner/target'
    assert target.resolve()==cache.resolve(), ('Cargo binary lookup differs from build output',str(target))
    checks.append({'path':str(target),'resolved':str(target.resolve())})
pathlib.Path(sys.argv[2]).write_text(json.dumps({'cache':str(cache),'legacyAlias':str(alias),'lookups':checks},indent=2)+'\n')
PY_TARGET

export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_RELEASE_DEBUG=0
export npm_config_workspace_concurrency=1

# Execute the existing real-prover cohorts instead of silently skipping them.
PROVER=/workspace/v10-preparation/tools/openshell-prover-v0.1.2/openshell-prover
PROVER_SHA=$(sha256sum "$PROVER" | awk '{print $1}')
[[ "$PROVER_SHA" == 3e80c0d041a7552d57cc338868bc825a6261e21b5f29a7d7527bcc7926d423f1 ]] || { echo 'Pinned OpenShell prover missing or changed' >&2; exit 67; }
printf '%s  %s\n' "$PROVER_SHA" "$PROVER" > "$OUT/openshell-prover.sha256"
export AW_V7_OPENSHELL_PROVER="$PROVER"
export CARGO_TARGET_DIR="$RUST_CACHE"
export PAPERCLIP_TEST_TMPDIR="$TEST_TMP"
mkdir -p "$PAPERCLIP_TEST_TMPDIR"

# Real Native suites require an explicit qualified executable, not a missing
# PATH command that turns required integration coverage into skipped tests.
export PAPERCLIP_QUALIFIED_OPENCODE_BINARY=/workspace/.cloud-setup/lockfile/node_modules/.pnpm/opencode-linux-x64@1.18.32/node_modules/opencode-linux-x64/bin/opencode
OPENCODE_SHA=$(sha256sum "$PAPERCLIP_QUALIFIED_OPENCODE_BINARY" | awk '{print $1}')
[[ "$OPENCODE_SHA" == 513f500a1a5ea1dc7d865547ac87b32a8936334e8d5abd5b3ff585c45a170080 ]] || { echo 'Qualified OpenCode binary missing or changed' >&2; exit 67; }
printf '%s  %s\n' "$OPENCODE_SHA" "$PAPERCLIP_QUALIFIED_OPENCODE_BINARY" > "$OUT/opencode.sha256"
mkdir "$TEST_TMP/bin"
ln -s "$PAPERCLIP_QUALIFIED_OPENCODE_BINARY" "$TEST_TMP/bin/opencode"
export PATH="$TEST_TMP/bin:$PATH"

# Keep the standard full test suite offline from provider credentials. Record
# only names, never values, of the credentials removed from this process.
stripped=()
while IFS= read -r name; do
  if [[ "$name" =~ (API_KEY|API_TOKEN|ACCESS_KEY_ID|SECRET_ACCESS_KEY|SESSION_TOKEN|CLIENT_SECRET)$ ]]; then
    stripped+=("$name"); unset "$name"
  fi
done < <(compgen -e)
for name in ANTHROPIC_AUTH_TOKEN; do
  if [[ -v $name ]]; then stripped+=("$name"); unset "$name"; fi
done
printf '%s\n' "${stripped[@]}" > "$OUT/provider-credential-vars-stripped.txt"

python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$OUT/source-pins.json" > "$OUT/snapshot.log" 2>&1
node /workspace/v10-preparation/check-snapshot-syntax.cjs "$OUT/source-pins.json" > "$OUT/oxc.log" 2>&1
sha256sum /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py \
  /workspace/v10-preparation/check-snapshot-syntax.cjs \
  /workspace/v10-preparation/record-static-ui-build-inputs.py > "$OUT/helper-sha256sums.txt"

# Check the lock-protected mirror is the exact source image captured above.
python3 - "$MAIN" "$MIRROR" "$OUT/source-pins.json" "$EXPECTED_HEAD" <<'PY'
import hashlib,json,pathlib,sys
main,mirror,pins_path=map(pathlib.Path,sys.argv[1:4]); expected_head=sys.argv[4]
pins=json.loads(pins_path.read_text())
assert pins['sourceHead']==expected_head, ('source HEAD changed before snapshot',pins['sourceHead'],expected_head)
for row in pins['copiedFiles']:
    rel=row['path']; src=main/rel; dst=mirror/rel
    if row.get('deleted'):
        assert not dst.exists(), ('deleted source still exists in mirror',rel)
        continue
    assert src.is_file() and dst.is_file(), ('source missing after snapshot',rel)
    want=hashlib.sha256(src.read_bytes()).hexdigest()
    assert want==row['sha256']==hashlib.sha256(dst.read_bytes()).hexdigest(), ('source pin mismatch',rel)
print(json.dumps({'sourceHead':pins['sourceHead'],'copiedFiles':len(pins['copiedFiles']),'status':'passed'}))
PY

run_step() {
  local label=$1; shift
  printf '%q ' "$@" > "$OUT/$label.command"
  printf '\n' >> "$OUT/$label.command"
  set +e
  (cd "$MIRROR" && "$@") > "$OUT/$label.log" 2>&1
  local rc=$?
  set -e
  printf '%s\n' "$rc" > "$OUT/$label.exit"
  if (( rc != 0 )); then
    tail -80 "$OUT/$label.log" >&2 || true
    return "$rc"
  fi
}

# Refresh changed shared runtime exports before consumers typecheck or test.
run_step bootstrap-shared pnpm --filter @paperclipai/shared build
run_step bootstrap-db pnpm --filter @paperclipai/db build
# Local Host Node contracts are outside Vitest; network.test.mjs owns a separate root/kernel gate.
run_step host-node-contracts node --test deploy/v6/host-agent/openshell.test.mjs deploy/v6/host-agent/broker-profiles.test.mjs deploy/v6/host-agent/sandbox-host-contracts.test.mjs deploy/v6/host-agent/engine.test.mjs deploy/v6/host-agent/backup.test.mjs
run_step ui-token-gates pnpm check:token-gates
run_step typecheck pnpm typecheck
# Node-owned Platform Skill suites are outside the root Vitest projects.
run_step platform-skill-contracts pnpm test:platform-skill-contracts
run_step platform-skill-operating-knowledge pnpm test:platform-skill-operating-knowledge
# Preserve the complete owned test command while separating its last debug
# build from release compilation. Both profiles must exist before Vitest import.
python3 - "$MIRROR" "$OUT/runner-test-composition.json" <<'PY_RUNNER_SCRIPTS'
import json,pathlib,sys
root=pathlib.Path(sys.argv[1]); package=json.loads((root/'packages/paperclip-runner/package.json').read_text())
scripts=package['scripts']
assert package['name']=='@paperclipai/paperclip-runner'
assert scripts['test']=='pnpm run test:typescript && pnpm run test:rust'
assert scripts['test:typescript']=='pnpm run test:typescript:prep && vitest run'
assert scripts['test:rust']=='cargo test --release --manifest-path runner/Cargo.toml --locked --workspace'
for source in [scripts,json.loads((root/'package.json').read_text())['scripts']]:
    assert not any(prefix+name in source for prefix in ['pre','post'] for name in ['test','test:typescript','test:typescript:prep','test:rust'])
pathlib.Path(sys.argv[2]).write_text(json.dumps({k:scripts[k] for k in ['test','test:typescript','test:typescript:prep','test:rust']},indent=2)+'\n')
PY_RUNNER_SCRIPTS
run_step runner-typescript-prep pnpm --filter @paperclipai/paperclip-runner run test:typescript:prep
sha256sum /workspace/v10-preparation/reclaim-final-debug-intermediates-20261101.py > "$OUT/debug-cache-helper.sha256"
run_step reclaim-debug-intermediates python3 /workspace/v10-preparation/reclaim-final-debug-intermediates-20261101.py "$RUST_CACHE" "$OUT/debug-cache-reclamation.json"
run_step bootstrap-rust-release pnpm --filter @paperclipai/paperclip-runner build:binary
for binary in "$RUST_CACHE/debug/paperclip-runnerd" "$RUST_CACHE/debug/fake-codex-app-server" "$RUST_CACHE/debug/fake-harness" "$RUST_CACHE/release/paperclip-runnerd"; do
  [[ -x "$binary" ]] || { echo "Required real-process fixture binary missing: $binary" >&2; exit 67; }
  sha256sum "$binary" >> "$OUT/pre-test-rust-binaries.sha256"
done
# These are exactly the remaining commands from the composition checked above.
run_step runner-typescript-tests pnpm --filter @paperclipai/paperclip-runner exec vitest run
run_step runner-rust-tests pnpm --filter @paperclipai/paperclip-runner run test:rust
run_step opencode-runtime-mechanics env PAPERCLIP_OPENCODE_QUALIFY=1 \
  PAPERCLIP_TEST_OPENCODE_BINARY="$PAPERCLIP_QUALIFIED_OPENCODE_BINARY" \
  node --test packages/paperclip-runner/scripts/qualify-opencode-runtime.test.mjs
run_step test-run pnpm test:run
test_tmp_cleaned=1
if [[ "$TEST_TMP" == /tmp/v10-final-workspace-test-tmp-* && -d "$TEST_TMP" && ! -L "$TEST_TMP" ]]; then
  rm -rf -- "$TEST_TMP"
fi
printf '%s\n' 'removed only the runner-created PAPERCLIP_TEST_TMPDIR after passing full test:run' > "$OUT/temp-cleanup.txt"

python3 /workspace/v10-preparation/record-static-ui-build-inputs.py record "$MIRROR" "$OUT/ui-build-inputs.json"
python3 - "$OUT/ui-build-inputs.json" <<'PY'
import json,pathlib,sys
count=len(json.loads(pathlib.Path(sys.argv[1]).read_text())['buildInputs'])
assert count>=5999,('static UI/package input guard did not cover the qualified minimum',count)
print(json.dumps({'recordedBuildInputs':count,'minimum':5999,'status':'passed'}))
PY
run_step build pnpm build
python3 /workspace/v10-preparation/record-static-ui-build-inputs.py verify "$MIRROR" "$OUT/ui-build-inputs.json" > "$OUT/ui-build-inputs-verify.json"

# Detect MAIN edits made during the run and pin final mirror contents for every
# copied source path. Generated dist outputs are intentionally outside cleanup.
python3 - "$MAIN" "$MIRROR" "$OUT/source-pins.json" "$OUT" <<'PY'
import hashlib,json,pathlib,sys
main,mirror,pins_path,out=map(pathlib.Path,sys.argv[1:])
pins=json.loads(pins_path.read_text()); rows=[]
for item in pins['copiedFiles']:
    rel=item['path']; p=mirror/rel
    if item.get('deleted'):
        assert not p.exists(),('unexpected deleted path reappeared',rel)
        rows.append({'path':rel,'deleted':True}); continue
    assert p.is_file(),('qualified source missing',rel)
    expected=hashlib.sha256((main/rel).read_bytes()).hexdigest()
    actual=hashlib.sha256(p.read_bytes()).hexdigest()
    assert expected==item['sha256']==actual,('source changed during aggregate',rel)
    rows.append({'path':rel,'sha256':actual})
(out/'qualified-tree-source-pins.json').write_text(json.dumps({'sourceHead':pins['sourceHead'],'sourcePinsSha256':hashlib.sha256(pins_path.read_bytes()).hexdigest(),'files':rows},indent=2)+'\n')
print(json.dumps({'verifiedFiles':len(rows),'status':'passed'}))
PY
git status --porcelain=v1 > "$OUT/main-status-after.txt"
[[ $(git rev-parse HEAD) == "$EXPECTED_HEAD" ]] || { echo 'MAIN HEAD changed during aggregate; reject this run' >&2; exit 68; }
cmp -s "$OUT/main-status-before.txt" "$OUT/main-status-after.txt" || { echo 'MAIN working tree changed during aggregate; reject this run' >&2; exit 68; }
sha256sum "$MIRROR/packages/paperclip-runner/dist/bin/paperclip-runnerd" > "$OUT/final-built-runnerd.sha256"
df -h /workspace /tmp > "$OUT/disk-after.txt"
printf '%s\n' 'typecheck, test:run, build, source pin, and static UI input guard passed' > "$OUT/summary.txt"
