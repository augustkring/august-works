import { publicChatTaskUrl } from "../chat-task-url.js";
import { assertPlatformSkillAdmission } from "../platform-skill-admission.js";
import {MANAGEMENT_ANALYTICAL_TOOL_DEFINITIONS,isManagementAnalyticalTool,executeManagementAnalyticalTool} from "./management-analytical-tools.js";
import {assertAnalyticalContextPayloadAccess,assertNativeAnalyticalRunPayloadAccess} from "../analytical-context-authority.js";
import { lockMemoryPrivacy } from "../memory/memory-privacy.js";
import { lockAnalyticalCompany } from "../analytical-privacy.js";
import { withOrchestrationNativeTool, lockNativeToolPlan, assertNativeToolPlanCurrent } from "../orchestration/native-tool-boundary.js";
import { createAssignedMcpTools, getAssignedMcpGateway } from "./assigned-mcp-tools.js";
import { assertAssignableAgent } from "../agent-assignability.js";
import { authorizationService, issueReadSqlCondition, type AuthorizationActor } from "../authorization.js";
import { handoffPlanContext } from "./handoff-plan-context.js";
import { callCreateSkillTool } from "../skill-tools.js";
import { callProjectTool } from "../project-tools.js";
import { createManagedNativeProjectOutput, managedNativeProjectArgumentsSchema, managedNativeProjectApiCallSchema,
  type NativeProjectCreateReceipt } from "../native-project-output.js";
import { isConnectorTool, executeConnectorTool, type ConnectorAssignment } from "../connector-runtime.js";
import { resolveNativeRuntimeMcpSnapshot } from "./runtime-context.js";
import { nativeCallApiResultEnvelope, nativeCommentProjectionHash, nativeSha256 } from "./canonical.js";
import { connectionIntentService } from "../connection-intents.js";
import { RUNTIME_CONNECTION_TOOL_DEFINITIONS } from "../connection-tool-definitions.js";
import { connectionsSearchInputSchema, connectionRequestInputSchema, CONNECTION_INTENT_AGENT_GUIDANCE,
  nativePayloadSourceInputSchema, nativePayloadSourcePolicySchema, nativePayloadSourceSnapshotSchema,
  type NativePayloadSourceInput, type NativePayloadSourcePolicy } from "@paperclipai/shared";
import { createHash } from "node:crypto";
import { isDeepStrictEqual } from "node:util";
import { AsyncLocalStorage } from "node:async_hooks";
import { paperclipChatFilePreparationDelivery } from "@paperclipai/adapter-utils/chat-file-delivery";
import {
  isPaperclipExternalChatContractTurn,
  normalizePaperclipWakePayload,
} from "@paperclipai/adapter-utils/server-utils";
import { runnerApiToolsEnabled } from "./runner-api-rollout.js";
import { openRunnerApiWorkspaceFile } from "./runner-api-files.js";
import { basename } from "node:path";
import { createLocalAgentJwt, verifyLocalAgentJwt, type NativeToolEffectClaim } from "../../agent-auth-jwt.js";
import { getStorageService } from "../../storage/index.js";
import type { StorageService } from "../../storage/types.js";
import { assetService } from "../assets.js";
import { workspaceFileResourceService } from "../workspace-file-resources.js";
import { badRequest, conflict, forbidden } from "../../errors.js";
import { searchRunnerApi } from "./runner-api-catalog.js";
import type { NativeModelOutputCapture, NativePayloadSourceSet } from "./native-execution-input.js";
import { assembleNativeContextRead, type NativeContextReadBinding } from "../native-direct-input.js";
import { executeRunnerApi, validateRunnerApiCall, runnerApiUrl, RUNNER_API_MAX_BYTES, type RunnerApiFile } from "./runner-api-client.js";
import { and, desc, eq, getTableColumns, isNull, notInArray, sql } from "drizzle-orm";
import type { Db } from "@paperclipai/db";
import {
  accountDeletionOperations,
  activityLog,
  agents,
  agentWakeupRequests,
  chatEndpoints,
  chatConversations,
  documents,
  documentRevisions,
  heartbeatRuns,
  companyMemberships,
  issueApprovals,
  issueComments,
  issueDocuments,
  issues,
  issueThreadInteractions,
  nativeRunFinalizations,
  orchestrationPlans,
  toolInvocations,
} from "@paperclipai/db";
import {
  bindManagedNativeMemoryOutputCapture,
  blenteraPlatformContractHashes,
  managedNativeRememberToolDescriptor,
  type ScopedToolGatewayContext,
} from "../tool-gateway.js";
import { CAPABILITY_SEMANTIC_TOOL_CATALOG, paperclipSemanticAction, runnerCodexDynamicToolsFit } from "../../vendor/paperclip-runner/index.js";
import { agentService } from "../agents.js";
import { approvalService } from "../approvals.js";
import { documentService } from "../documents.js";
import type { DocumentRevisionSourceCapture } from "../documents.js";
import { issueService } from "../issues.js";
import { issueThreadInteractionService } from "../issue-thread-interactions.js";
import { getNativeReviewAssignment, readNativeReviewAssignmentContext, type NativeReviewAssignmentContext } from "./native-review-participant.js";
import { childReviewOutcomes } from "./child-review-outcomes.js";
import { materializeNativeInteractionResponses } from "./native-interaction-bridge.js";
import { persistActivity, publishActivity } from "../activity-log.js";
import { captureRunIdentity } from "../run-identity.js";
import { prepareNativeRunnerFileHandoff, type RemoteWorkspaceFileReader } from "./native-runner-file-handoff.js";
import { MAX_ATTACHMENT_BYTES } from "../../attachment-types.js";
import {
  READ_CURRENT_WAKE_COMMENTS_TOOL_DEFINITION,
  READ_CURRENT_WAKE_COMMENTS_TOOL_NAME,
  readCurrentWakeComments,
  type CurrentWakeCommentsBinding,
} from "./current-wake-comments.js";
import {
  authorizeChatAttachmentReuse,
  authorizeChatConversationForBoundRun,
  LIST_CHAT_ATTACHMENTS_TOOL_DEFINITION,
  LIST_CHAT_ATTACHMENTS_TOOL_NAME,
  listAuthorizedChatAttachments,
  prepareReusedChatAttachment,
  REUSE_CHAT_ATTACHMENT_TOOL_DEFINITION,
  REUSE_CHAT_ATTACHMENT_TOOL_NAME,
  type ChatAttachmentReuseSource,
} from "./chat-attachment-reuse.js";
import {
  READ_CHAT_ATTACHMENT_TOOL_DEFINITION,
  READ_CHAT_ATTACHMENT_TOOL_NAME,
  type NativeChatAttachmentReadScope,
} from "./chat-attachment-read.js";

const IMPLEMENTED_OPERATIONS = new Set([
  "search_api", "call_api", "hire_agent",
  "get_task_context", "get_task_history", "search_tasks", "report_progress", "update_task", "propose_completion",
  "request_human_input",
  "create_skill", "create_task", "reassign_task", "set_dependencies", "create_project", "list_project_repositories", "list_projects", "register_deliverable",
  "list_documents", "read_document", "list_document_revisions", "write_document",
  "list_agents", "get_agent", "list_approvals", "get_approval", "get_approval_context",
]);
const MANAGED_NATIVE_REMEMBER_TOOL = "self_remember";
const MANAGED_NATIVE_REMEMBER_GATEWAY_TOOL = "paperclip-self:remember";
const MANAGED_NATIVE_CONTEXT_READ_TOOL = "read_context";

export type NativeManagedProjectCreateCapture = {
  project: Record<string, unknown>;
  receipt: NativeProjectCreateReceipt;
  sourceSet: NativePayloadSourceSet;
  outputCapture: NativeModelOutputCapture;
  /** Exact signed runner API effect for the managed call_api POST result. */
  apiEffect?: Pick<NativeToolEffectClaim, "operationId" | "method" | "pathAndQuery" | "apiReceiptDigest" |
    "bodyHash" | "turnId" | "dispatchId" | "eventSeq" | "attempt">;
};

const NATIVE_REVIEW_READ_TOOLS = new Set([
  "get_task_context", "get_task_history", "list_documents", "read_document", "list_document_revisions",
]);

type Binding = {
  /** Controller-owned turn revocation. Never obtained from tool arguments. */
  authoritySignal?: AbortSignal;
  /** Exact AW output dispatch capture; never read from tool arguments. */
  awOutputCapture?: { readonly value: NativeModelOutputCapture | null };
  /** Exact provider-bound model output capture; never read from tool arguments. */
  nativeModelOutputCapture?: { readonly value: NativeModelOutputCapture | null };
  /** Fixture-only wait probe at the original Project mutation owner. */
  testBeforeManagedProjectCreate?: (capture: NativeModelOutputCapture) => Promise<void>;
  /** Fixture-only post-commit probe for exact idempotent Project replay. */
  testAfterManagedProjectCreate?: (input: { actor: AuthorizationActor; companyId: string; issueId: string; capture: NativeModelOutputCapture; callId: string;
    arguments: Record<string, unknown>; result: Awaited<ReturnType<typeof createManagedNativeProjectOutput>> }) => Promise<void>;
  /** Managed-only ContextEngine read callback with a server-owned witness carrier. */
  managedNativeContextRead?: (query: string, callId?: string) => Promise<{ markdown: string }>;
  managedNativeContextReadCapture?: { value: NativeContextReadBinding | null };
  /** Server-derived scope for one addressed native completion review. */
  nativeReview?: NativeReviewAssignmentContext;
  companyId: string;
  issueId: string;
  runId: string;
  agentId: string;
  /** Server-owned Tool Gateway transport identity; never sourced from tool input. */
  sourceChannel?: "paperclip_runner_protocol" | "tool_gateway_mcp";
  transportCallId?: string;
  requireCurrentResponsibleUser?: boolean;
  normalizedSessionId?: string;
  pinnedMcpDigest?: string;
  /** Server-owned API origin and storage; never obtained from tool input. */
  apiUrl?: string;
  storage?: StorageService;
  /** Server-owned suppression for baseline evals; true never overrides operator opt-in. */
  connectorAssignments?: ConnectorAssignment[];
  assignedMcpTools?: Awaited<ReturnType<typeof createAssignedMcpTools>>;
  apiToolsEnabled?: boolean;
  /** Server-derived native private-conversation opt-in, never tool input. */
  managementToolsEnabled?: boolean;
  workMode?: "standard" | "planning" | "ask";
  workspaceRoot?: string;
  executionTargetKind?: "local" | "remote";
  readRemoteWorkspaceFile?: RemoteWorkspaceFileReader;
  currentWakeComments?: CurrentWakeCommentsBinding;
  chatAttachmentReadScope?: NativeChatAttachmentReadScope;
  stopTaskForReassignment?: (target: { companyId: string; issueId: string; agentId: string; runId: string | null }) => Promise<void>;
  enqueueWakeup?: (agentId: string, options: {
    source: "assignment";
    triggerDetail: "system";
    reason: "issue_assigned";
    payload: Record<string, unknown>;
    idempotencyKey: string;
    requestedByActorType: "agent";
    requestedByActorId: string;
    contextSnapshot: Record<string, unknown>;
    issueStateGuard?: { statuses: string[]; assigneeAgentId: string; statusVersion?: number };
  }) => Promise<unknown>;
};

type ToolReceipt = {
  operationId: string;
  input: unknown;
  result: unknown;
  nativeInputDispatch: NativeInputDispatchReceiptIdentity | null;
  transport?: { channel: "paperclip_runner_protocol" | "tool_gateway_mcp"; callId: string | null };
};

type NativeInputDispatchReceiptIdentity = {
  dispatchId: string;
  eventSeq: number;
  attempt: number;
  turnId: string;
  callId: string;
};

type NativeBackendToolCallIdentity = { tool: string; callId: string; turnId: string };
const nativeBackendToolCallIdentity = new AsyncLocalStorage<NativeBackendToolCallIdentity | null>();

export type NativeDocumentToolResultSource = {
  /** Authenticated backend identity, never document arguments. Null stays unknown. */
  turnId: string | null;
  callId: string;
  tool: "read_document";
  resultDigest: string;
  source: DocumentRevisionSourceCapture | null;
};

/** Exact owner captures for a Native tool result. A null sourceSet means that
 * the returned result contains at least one input whose complete source graph
 * is not known; observedSourceInputs are diagnostic facts, never a substitute
 * for a complete source set. */
export type NativeInputToolResultSource = {
  turnId: string | null;
  callId: string;
  tool: string;
  argumentsHash: string;
  resultDigest: string;
  /** In-memory only; the receipt stores only resultDigest. */
  result: unknown;
  sourceSet: NativePayloadSourceSet | null;
  observedSourceInputs: NativePayloadSourceInput[];
};

type NativeObservedOwnerSource = {
  companyId: string;
  input: NativePayloadSourceInput;
  payloadSourceSnapshot: unknown;
  invalidated?: boolean;
};

function emptyNativeSourcePolicy(): NativePayloadSourcePolicy {
  return { issueIds: [], projectIds: [], runIds: [], memoryIds: [], foundationRevisionIds: [] };
}

function nativeSourceSetFromObservedOwners(owners: readonly NativeObservedOwnerSource[], additionalInputs: readonly NativePayloadSourceInput[] = []): {
  sourceSet: NativePayloadSourceSet | null;
  observedSourceInputs: NativePayloadSourceInput[];
} {
  const policy = emptyNativeSourcePolicy();
  const inputs: NativePayloadSourceInput[] = [];
  const seen = new Set<string>();
  let complete = owners.length > 0;
  const addInput = (source: NativePayloadSourceInput) => {
    const key = JSON.stringify(source);
    if (!seen.has(key)) {
      if (inputs.length >= 256) { complete = false; return; }
      seen.add(key);
      inputs.push(source);
    }
  };
  for (const owner of owners) {
    const source = nativePayloadSourceInputSchema.safeParse(owner.input);
    if (!source.success) { complete = false; continue; }
    addInput(source.data);
    const sourceIssueId = source.data.kind === "task" || source.data.kind === "comment"
      ? source.data.issueId
      : source.data.kind === "document_revision" ? source.data.issueId : null;
    if (sourceIssueId) policy.issueIds.push(sourceIssueId);
    const snapshot = nativePayloadSourceSnapshotSchema.safeParse(owner.payloadSourceSnapshot);
    if (owner.invalidated || !snapshot.success) { complete = false; continue; }
    const expectedOwner = source.data.kind === "task"
      ? { kind: "issue", id: source.data.issueId }
      : source.data.kind === "comment"
        ? { kind: "comment", id: source.data.commentId }
        : source.data.kind === "document_revision"
          ? { kind: "document_revision", id: source.data.revisionId }
        : null;
    if (!expectedOwner || snapshot.data.owner.kind !== expectedOwner.kind ||
      snapshot.data.owner.companyId !== owner.companyId ||
      snapshot.data.owner.id !== expectedOwner.id) {
      complete = false;
      continue;
    }
    for (const key of Object.keys(policy) as (keyof NativePayloadSourcePolicy)[])
      policy[key] = [...new Set([...policy[key], ...snapshot.data.policy[key]])];
    for (const nested of snapshot.data.inputs) addInput(nested);
  }
  for (const raw of additionalInputs) {
    const source = nativePayloadSourceInputSchema.safeParse(raw);
    if (!source.success || (source.data.kind !== "interaction" && source.data.kind !== "comment")) {
      complete = false;
      continue;
    }
    addInput(source.data);
    if (source.data.kind === "interaction" || source.data.kind === "comment")
      policy.issueIds.push(source.data.issueId);
  }
  for (const key of Object.keys(policy) as (keyof NativePayloadSourcePolicy)[])
    policy[key] = [...new Set(policy[key])].sort();
  const parsedPolicy = nativePayloadSourcePolicySchema.safeParse(policy);
  const parsedInputs = nativePayloadSourceInputSchema.array().safeParse(inputs);
  return { sourceSet: complete && parsedPolicy.success && parsedInputs.success
      ? { policy: parsedPolicy.data, inputs: parsedInputs.data } : null,
    observedSourceInputs: inputs };
}

/** Exact public Project projection returned by one native API tool result.
 * This is a partial returned-input fact, not provider-consumption or complete
 * Native input evidence. The body itself is deliberately not retained here. */
export type NativeProjectToolResultSource = {
  turnId: string | null;
  callId: string;
  tool: "call_api";
  operationId: "GET /api/projects/{id}";
  projectId: string | null;
  /** Hash of the validated runner-api request. The request body is never retained. */
  requestHash: string;
  pathAndQuery: string;
  /** Exact provider-visible call_api result envelope digest. */
  resultDigest: string;
  /** Exact raw executeRunnerApi response digest retained by the API receipt. */
  apiResultDigest: string;
  source: Extract<NativePayloadSourceInput, { kind: "project" }> | null;
};

export function captureNativeProjectToolResult(input: {
  companyId: string;
  requestedProjectId: string | null | undefined;
  turnId: string | null;
  callId: string;
  requestHash: string;
  pathAndQuery: string;
  result: unknown;
}): NativeProjectToolResultSource {
  const rawRequestedId = input.requestedProjectId?.toLowerCase();
  const requestedId = rawRequestedId && /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/.test(rawRequestedId)
    ? rawRequestedId : null;
  const response = record(input.result), project = record(response.data);
  const projectId = typeof project.id === "string" ? project.id.toLowerCase() : "";
  const sourceCandidate = response.ok === true && response.status === 200 && requestedId !== null &&
    projectId === requestedId && project.companyId === input.companyId && typeof project.updatedAt === "string" &&
    /^[0-9a-f]{64}$/.test(input.requestHash) && input.pathAndQuery === `/api/projects/${requestedId}`
    ? nativePayloadSourceInputSchema.safeParse({ kind: "project", projectId, sourceVersion: project.updatedAt,
        contentHash: createHash("sha256").update(JSON.stringify(project)).digest("hex") })
    : null;
  const source = sourceCandidate?.success ? sourceCandidate.data : null;
  const { operationId: _operationId, ...toolResponse } = response;
  return {
    turnId: input.turnId,
    callId: input.callId,
    tool: "call_api",
    operationId: "GET /api/projects/{id}",
    projectId: requestedId,
    requestHash: input.requestHash,
    pathAndQuery: input.pathAndQuery,
    // Runnerd binds HTTP results inside the semantic call_api envelope before
    // they enter the provider transcript. Hash that exact public result while
    // retaining the Project DTO's separate owner hash above.
    resultDigest: nativeSha256(nativeCallApiResultEnvelope(input.callId,
      { ...toolResponse, apiOperationId: "GET /api/projects/{id}" })),
    apiResultDigest: nativeSha256(input.result),
    source: source?.kind === "project" ? source : null,
  };
}

function record(value: unknown): Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown>
    : {};
}

export function resolveNativeInputDispatchReceiptIdentity(
  runnerProfile: unknown,
  call: NativeBackendToolCallIdentity | null | undefined,
  operationId: string,
): NativeInputDispatchReceiptIdentity | null {
  if (!call || call.tool !== operationId || !/^[\x21-\x7e]{1,240}$/.test(call.callId) ||
    !/^[\x21-\x7e]{1,240}$/.test(call.turnId)) return null;
  const profile = record(runnerProfile);
  const rawAssociations = profile.nativeToolCallDispatchAssociations;
  const rawIntents = profile.nativeModelInputDispatchIntents;
  if (!Array.isArray(rawAssociations) || rawAssociations.length > 512 ||
    !Array.isArray(rawIntents) || rawIntents.length > 64) return null;
  const associations = rawAssociations.map(value => record(value)).filter(value =>
    value.callId === call.callId && value.turnId === call.turnId);
  if (associations.length !== 1 || associations[0]!.tool !== call.tool) return null;
  const association = associations[0]!;
  const uuidV4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
  if (typeof association.dispatchId !== "string" || !uuidV4.test(association.dispatchId) ||
    !Number.isSafeInteger(association.eventSeq) || (association.eventSeq as number) < 0 ||
    !Number.isSafeInteger(association.attempt) || (association.attempt as number) < 1) return null;
  const intents = rawIntents.map(value => record(value)).filter(value => value.turnId === call.turnId);
  if (intents.length !== 1) return null;
  const intent = intents[0]!;
  if (intent.dispatchId !== association.dispatchId || intent.eventSeq !== association.eventSeq ||
    intent.attempt !== association.attempt || typeof intent.turnInputDigest !== "string" ||
    !/^[0-9a-f]{64}$/.test(intent.turnInputDigest)) return null;
  return {
    dispatchId: association.dispatchId,
    eventSeq: association.eventSeq as number,
    attempt: association.attempt as number,
    turnId: call.turnId,
    callId: call.callId,
  };
}

function canonicalJson(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  if (typeof value === "object" && value !== null) {
    const object = value as Record<string, unknown>;
    return `{${Object.keys(object).sort().map((key) => `${JSON.stringify(key)}:${canonicalJson(object[key])}`).join(",")}}`;
  }
  return JSON.stringify(value) ?? "null";
}

export class PaperclipRunnerToolAuthority {
  constructor(readonly db: Db, readonly binding: Binding) {}

  #sourceChannel(): "paperclip_runner_protocol" | "tool_gateway_mcp" {
    return this.binding.sourceChannel ?? "paperclip_runner_protocol";
  }

  #transportDetails() {
    return {
      source: this.#sourceChannel(),
      ...(this.binding.transportCallId ? { transportCallId: this.binding.transportCallId } : {}),
    };
  }

  definitions(): Array<Record<string, unknown>> {
    if (this.binding.nativeReview) {
      // Scope Paperclip control-plane actions. Provider file and shell access
      // still follow the configured agent/environment policy, including tests.
      return [
        ...CAPABILITY_SEMANTIC_TOOL_CATALOG
          .filter((tool) => NATIVE_REVIEW_READ_TOOLS.has(tool.operationId))
          .map((tool) => ({ name: tool.operationId, description: tool.description, inputSchema: tool.inputSchema })),
        {
          name: "resolve_review",
          description: "Record your decision on the one completion review assigned to this run. Inspect the submitted work first. Accept only if it meets the request; otherwise reject with specific changes. This does not change task ownership. After recording the decision, report your review complete with paperclip_finish. Do not redo the worker's task or wait for your own parent task to become runnable.",
          inputSchema: {
            type: "object", additionalProperties: false,
            properties: {
              decision: { type: "string", enum: ["accept", "reject"] },
              reason: { type: "string", description: "Required when rejecting: the specific changes the worker must make." },
            },
            required: ["decision"],
          },
        },
      ];
    }
    const workMode = this.binding.workMode ?? "standard";
    const definitions: Array<Record<string, unknown>> =
      CAPABILITY_SEMANTIC_TOOL_CATALOG.filter(
        (descriptor) =>
          IMPLEMENTED_OPERATIONS.has(descriptor.operationId) &&
          (runnerApiToolsEnabled(
            this.binding.companyId,
            this.binding.apiToolsEnabled,
          ) ||
            !["search_api", "call_api", "hire_agent"].includes(descriptor.operationId)) &&
          descriptor.allowedModes.includes(workMode) &&
          (descriptor.operationId !== "register_deliverable" ||
            (Boolean(this.binding.workspaceRoot) &&
              ((this.binding.executionTargetKind ?? "local") === "local" || Boolean(this.binding.readRemoteWorkspaceFile)))),
      ).map((descriptor) => ({
        name: descriptor.operationId,
        description:
          descriptor.operationId === "register_deliverable"
            ? "Prepare one verified workspace file for Paperclip's final task or external-chat response. This records the attachment, work product, and explicit same-run selection; it does not confirm provider delivery."
            : descriptor.description,
        inputSchema:
          descriptor.operationId === "request_human_input"
            ? {
                ...descriptor.inputSchema,
                properties: {
                  ...descriptor.inputSchema.properties,
                  resolverPolicy: {
                    type: "string", enum: ["human_only"],
                    description: "Optional tightening: only a current authorized human may resolve this interaction. Omission preserves its Native policy.",
                  },
                },
              }
            : descriptor.operationId === "register_deliverable"
            ? {
                ...descriptor.inputSchema,
                properties: {
                  ...descriptor.inputSchema.properties,
                  filename: {
                    ...(descriptor.inputSchema.properties?.filename ?? {}),
                    description:
                      "Basename for the prepared attachment. Directory components are rejected.",
                  },
                  byteSize: {
                    ...(descriptor.inputSchema.properties?.byteSize ?? {}),
                    minimum: 1,
                    maximum: MAX_ATTACHMENT_BYTES,
                  },
                  contentRef: {
                    ...(descriptor.inputSchema.properties?.contentRef ?? {}),
                    description:
                      "Workspace-relative source path. Absolute paths, URLs, traversal, and symlinks are rejected.",
                  },
                },
              }
            : descriptor.inputSchema,
      }));
    for (const operationId of ["update_task", "propose_completion"] as const) {
      if (!IMPLEMENTED_OPERATIONS.has(operationId)) continue;
      const descriptor = paperclipSemanticAction(operationId);
      if (!descriptor || !descriptor.allowedModes.includes(workMode)) continue;
      definitions.push({ name: operationId, description: descriptor.description, inputSchema: descriptor.inputSchema });
    }
    // Keep the provider session's direct tool catalog stable across ordinary
    // and truncated external-chat turns. Execution still fails closed unless
    // this exact run carries a server-verified current-wake binding.
    definitions.push(READ_CURRENT_WAKE_COMMENTS_TOOL_DEFINITION);
    definitions.push(LIST_CHAT_ATTACHMENTS_TOOL_DEFINITION);
    definitions.push(REUSE_CHAT_ATTACHMENT_TOOL_DEFINITION);
    definitions.push(READ_CHAT_ATTACHMENT_TOOL_DEFINITION);
    if (this.binding.nativeModelOutputCapture) {
      const remember = managedNativeRememberToolDescriptor();
      definitions.push({
        name: MANAGED_NATIVE_REMEMBER_TOOL,
        description: remember.description,
        inputSchema: structuredClone(remember.parametersSchema),
      });
      if (this.binding.managedNativeContextRead) definitions.push({
        name: MANAGED_NATIVE_CONTEXT_READ_TOOL,
        description: "Read the current governed task Context for a focused query. Returns only the rendered Context; source IDs and access are resolved by Paperclip.",
        inputSchema: { type: "object", properties: { query: { type: "string", minLength: 1, maxLength: 4000 } },
          required: ["query"], additionalProperties: false },
      });
    }
    if(this.binding.managementToolsEnabled)definitions.push(...MANAGEMENT_ANALYTICAL_TOOL_DEFINITIONS);
    const connectionTools = [...RUNTIME_CONNECTION_TOOL_DEFINITIONS,
      ...(this.binding.connectorAssignments ?? []).flatMap((assignment) => assignment.tools)];
    const assignedTools = this.binding.assignedMcpTools?.definitions((tools) =>
      runnerCodexDynamicToolsFit([...connectionTools, ...tools, ...definitions])) ?? [];
    return [...connectionTools, ...assignedTools, ...definitions];
  }

  async execute(call: {
    tool: string;
    callId: string;
    arguments: unknown;
  }, options: {
    onDocumentRead?: (source: NativeDocumentToolResultSource) => Promise<void>;
    onProjectToolResult?: (source: NativeProjectToolResultSource) => Promise<void>;
    onNativeInputToolResult?: (source: NativeInputToolResultSource) => Promise<void>;
    onManagedProjectCreateToolResult?: (capture: NativeManagedProjectCreateCapture) => Promise<void>;
    nativeToolCallIdentity?: NativeBackendToolCallIdentity;
  } = {}): Promise<unknown> {
    const nativeCall = options.nativeToolCallIdentity;
    const boundNativeCall = nativeCall && nativeCall.tool === call.tool && nativeCall.callId === call.callId &&
      typeof nativeCall.turnId === "string"
      ? { tool: nativeCall.tool, callId: nativeCall.callId, turnId: nativeCall.turnId }
      : null;
    if (this.binding.nativeModelOutputCapture) {
      const capture = this.binding.nativeModelOutputCapture.value;
      const use = capture?.managedOpenCodeToolUse;
      if (["write_document", "create_task", "create_project", MANAGED_NATIVE_REMEMBER_TOOL].includes(call.tool) && !use)
        throw forbidden("Managed OpenCode output effect has no settled provider tool-use capture");
      const captureToolName = call.tool === MANAGED_NATIVE_REMEMBER_TOOL
        ? MANAGED_NATIVE_REMEMBER_GATEWAY_TOOL : call.tool;
      if (use && (use.callId !== call.callId || use.toolName !== captureToolName ||
        use.argumentsHash !== nativeSha256(call.arguments)))
        throw forbidden("Managed OpenCode output effect does not match its exact provider tool use");
    }
    return nativeBackendToolCallIdentity.run(boundNativeCall, async () => {
      this.binding.authoritySignal?.throwIfAborted();
      const documentSource: { value: DocumentRevisionSourceCapture | null } = { value: null };
      const nativeInputSource: { value: { sourceSet: NativePayloadSourceSet | null;
        observedSourceInputs: NativePayloadSourceInput[] } | null } = { value: null };
      const managedProjectCreateCapture: { value: NativeManagedProjectCreateCapture | null } = { value: null };
      const result = await withOrchestrationNativeTool(this.db, this.binding, call,
        () => this.#executeAdmitted(call, source => { documentSource.value = source; }, options.onProjectToolResult,
          source => { nativeInputSource.value = source; }, capture => { managedProjectCreateCapture.value = capture; }),
        call.tool === MANAGED_NATIVE_REMEMBER_TOOL ||
          (call.tool !== "paperclip_search_assigned_tools" && (this.binding.assignedMcpTools?.has(call.tool) ?? false)));
      if (call.tool === "read_document") {
        const resultDigest = createHash("sha256").update(JSON.stringify(result)).digest("hex");
        const exactCapture = documentSource.value?.returnedResultDigest === resultDigest ? documentSource.value : null;
        documentSource.value = exactCapture;
        if (options.onDocumentRead) {
          await options.onDocumentRead({ turnId: boundNativeCall?.turnId ?? null, callId: call.callId, tool: "read_document",
            resultDigest,
            // The document owner computes this from the same selected revision
            // and normalized DTO before returning. A mismatch means provenance
            // is unknown; never repair it with a later re-read.
            source: exactCapture });
        }
        const captured = documentSource.value;
        const returnedDocument = result && typeof result === "object" && !Array.isArray(result)
          ? (result as Record<string, unknown>).document : null;
        const returnedRevisionId = returnedDocument && typeof returnedDocument === "object" && !Array.isArray(returnedDocument)
          ? (returnedDocument as Record<string, unknown>).latestRevisionId : null;
        const selectedRevisionId = captured?.input.revisionId ?? (typeof returnedRevisionId === "string" ? returnedRevisionId : null);
        if (selectedRevisionId) {
          const input = captured?.input;
          if (input && (input.kind !== "document_revision" || input.issueId !== this.binding.issueId || input.revisionId !== selectedRevisionId))
            throw forbidden("The selected document revision is outside this native Task");
          const [protocol] = await this.db.select({ version: documentRevisions.payloadSourceProtocolVersion }).from(documentRevisions)
            .where(and(eq(documentRevisions.companyId, this.binding.companyId), eq(documentRevisions.id, selectedRevisionId)));
          if (protocol?.version === 1 && !captured)
            throw forbidden("The selected Native document revision source is unavailable");
          if (captured) {
            const source = captured.input;
            if (!source.issueId) throw forbidden("The selected document revision is outside this native Task");
            const [current] = await this.db.select({ latestRevisionId: documents.latestRevisionId,
              revisionId: documentRevisions.id, body: documentRevisions.body,
              payloadSourceSnapshot: documentRevisions.payloadSourceSnapshot,
              payloadSourceSnapshotInvalidated: documentRevisions.payloadSourceSnapshotInvalidated,
            }).from(issueDocuments)
              .innerJoin(documents, and(eq(documents.companyId, issueDocuments.companyId), eq(documents.id, issueDocuments.documentId)))
              .innerJoin(documentRevisions, and(eq(documentRevisions.companyId, documents.companyId),
                eq(documentRevisions.documentId, documents.id), eq(documentRevisions.id, source.revisionId)))
              .where(and(eq(issueDocuments.companyId, this.binding.companyId), eq(issueDocuments.issueId, source.issueId),
                eq(issueDocuments.documentId, source.documentId)));
            if (!current || current.latestRevisionId !== source.revisionId ||
              current.payloadSourceSnapshotInvalidated ||
              createHash("sha256").update(current.body, "utf8").digest("hex") !== source.contentHash ||
              !isDeepStrictEqual(current.payloadSourceSnapshot, captured.payloadSourceSnapshot))
              throw forbidden("The selected document revision changed or was erased before delivery");
          }
          // The callback can wait on durable receipt storage. Re-read every original
          // source owner after that boundary, including for an exact reader with no
          // temporal snapshot (legacy/direct Human source).
          await this.#assertCurrentDocumentRevision(selectedRevisionId);
        }
        // The callback can wait on durable receipt storage. Recheck the original
        // native Task owner after that wait so access loss or source erasure
        // withholds the pending document result.
        await this.#boundContext();
      }
      if (nativeInputSource.value && options.onNativeInputToolResult) {
        await options.onNativeInputToolResult({ turnId: boundNativeCall?.turnId ?? null, callId: call.callId,
          tool: call.tool, argumentsHash: nativeSha256(call.arguments), resultDigest: nativeSha256(result),
          result, sourceSet: nativeInputSource.value.sourceSet,
          observedSourceInputs: nativeInputSource.value.observedSourceInputs });
      }
      if (managedProjectCreateCapture.value && options.onManagedProjectCreateToolResult)
        await options.onManagedProjectCreateToolResult(managedProjectCreateCapture.value);
      return result;
    });
  }

  async #assertCurrentDocumentRevision(revisionId: string, requireLatest = true) {
    const bound = await this.#boundContext();
    const { assertNativeDocumentRevisionCurrentSourceAccess } = await import("../native-direct-input.js");
    await assertNativeDocumentRevisionCurrentSourceAccess(this.db, {
      companyId: this.binding.companyId, issueId: this.binding.issueId, revisionId, requireLatest,
      // This is a server-side recheck for an already validated run binding;
      // it must not claim a JWT credential that this internal callback did not verify.
      actor: { type: "agent", source: "none", companyId: this.binding.companyId,
        agentId: this.binding.agentId, runId: this.binding.runId, onBehalfOfUserId: bound.run.responsibleUserId },
    });
  }

  async #executeAdmitted(call: { tool: string; callId: string; arguments: unknown },
    onDocumentReadSource?: (source: DocumentRevisionSourceCapture | null) => void,
    onProjectToolResult?: (source: NativeProjectToolResultSource) => Promise<void>,
    onNativeInputSource?: (source: { sourceSet: NativePayloadSourceSet | null;
      observedSourceInputs: NativePayloadSourceInput[] }) => void,
    onManagedProjectCreateCapture?: (capture: NativeManagedProjectCreateCapture) => void): Promise<unknown> {
    if (this.binding.nativeReview) {
      if (call.tool === "resolve_review") return this.#resolveReview(call.arguments);
      if (!NATIVE_REVIEW_READ_TOOLS.has(call.tool)) {
        throw forbidden("This review run may only inspect the assigned task and resolve its review.");
      }
    }
    if (this.binding.assignedMcpTools?.has(call.tool)) {
      const current = await this.#boundContext();
      return this.binding.assignedMcpTools.execute(call, current.issue.workMode as "standard" | "planning" | "ask");
    }
    if (isConnectorTool(call.tool)) {
      if (!(this.binding.connectorAssignments ?? []).some((assignment) => assignment.tools.some((tool) => tool.name === call.tool))) throw forbidden("Connector tool is not available to this run");
      const { run } = await this.#boundContext();
      const snapshot = record(run.contextSnapshot);
      if (call.tool.startsWith("agentmail_") && (isPaperclipExternalChatContractTurn(snapshot.paperclipWake) || String(snapshot.source ?? "").startsWith("chat:") || snapshot.paperclipExternalChatQuestionResponse)) throw forbidden("Restricted chat runs cannot use email actions");
      return executeConnectorTool(this.db, this.binding, call.tool, call.arguments);
    }
    if (RUNTIME_CONNECTION_TOOL_DEFINITIONS.some((tool) => tool.name === call.tool)) {
      await this.#boundContext();
      const { run } = await captureRunIdentity(this.db, this.binding);
      if (!run.responsibleUserId) throw forbidden("This task needs a responsible user before requesting a connection");
      const claims = {
        sub: this.binding.agentId, company_id: this.binding.companyId,
        run_id: this.binding.runId, responsible_user_id: run.responsibleUserId,
      };
      const connections = connectionIntentService(this.db);
      if (call.tool === "connections_search") {
        const input = connectionsSearchInputSchema.parse(call.arguments);
        return connections.search(claims, input.query, { retryProviderChoice: input.retryProviderChoice });
      }
      const input = connectionRequestInputSchema.parse(call.arguments);
      const result = await connections.request(claims, input.service, { selectionInteractionId: input.selectionInteractionId, targetService: input.targetService });
      if (result.state === "ready" && this.binding.pinnedMcpDigest && this.binding.enqueueWakeup) {
        const current = await resolveNativeRuntimeMcpSnapshot({ db: this.db, agent: { id: this.binding.agentId, companyId: this.binding.companyId }, runId: this.binding.runId });
        if (current.digest !== this.binding.pinnedMcpDigest) {
          const idempotencyKey = `connection-intent:tools:${this.binding.runId}:${current.digest}`;
          const delivered = () => this.db.select({ id: agentWakeupRequests.id }).from(agentWakeupRequests).where(and(
            eq(agentWakeupRequests.companyId, this.binding.companyId), eq(agentWakeupRequests.idempotencyKey, idempotencyKey),
            notInArray(agentWakeupRequests.status, ["skipped", "failed", "cancelled"]),
          )).limit(1);
          if (!(await delivered()).length) try { await this.binding.enqueueWakeup(this.binding.agentId, {
            source: "assignment", triggerDetail: "system", reason: "issue_assigned",
            payload: { issueId: this.binding.issueId, mutation: "connection_tools_refreshed" },
            idempotencyKey,
            issueStateGuard: { statuses: ["in_progress", "in_review"], assigneeAgentId: this.binding.agentId },
            requestedByActorType: "agent", requestedByActorId: this.binding.agentId,
            contextSnapshot: { issueId: this.binding.issueId, taskId: this.binding.issueId, forceFreshSession: true, wakeReason: "issue_assigned", source: "connection_tools.refreshed" },
          }); } catch (error) { if (!(await delivered()).length) throw error; }
          return { ...result, instruction: "Access is already authorized. A fresh continuation with updated tools is queued. Finish independent work, then yield. Do not request authorization again." };
        }
      }
      return result;
    }
    if (
      !IMPLEMENTED_OPERATIONS.has(call.tool) &&
      !(call.tool === MANAGED_NATIVE_REMEMBER_TOOL && this.binding.nativeModelOutputCapture) &&
      !(call.tool === MANAGED_NATIVE_CONTEXT_READ_TOOL && this.binding.nativeModelOutputCapture && this.binding.managedNativeContextRead) &&
      call.tool !== READ_CURRENT_WAKE_COMMENTS_TOOL_NAME &&
      call.tool !== LIST_CHAT_ATTACHMENTS_TOOL_NAME &&
      call.tool !== REUSE_CHAT_ATTACHMENT_TOOL_NAME &&
      call.tool !== READ_CHAT_ATTACHMENT_TOOL_NAME &&
      !(this.binding.managementToolsEnabled&&isManagementAnalyticalTool(call.tool))
    ) {
      throw new Error("paperclip_runner_tool_not_advertised");
    }
    if (
      !runnerApiToolsEnabled(
        this.binding.companyId,
        this.binding.apiToolsEnabled,
      ) &&
      ["search_api", "call_api", "hire_agent"].includes(call.tool)
    ) {
      throw new Error("paperclip_runner_tool_not_advertised");
    }
    const context = await this.#boundContext();
    const reader: AuthorizationActor = { type: "agent", source: "agent_jwt", companyId: this.binding.companyId,
      agentId: this.binding.agentId, runId: this.binding.runId, onBehalfOfUserId: context.run.responsibleUserId };
    if(isManagementAnalyticalTool(call.tool))return executeManagementAnalyticalTool(this.db,this.binding.companyId,{type:"agent",source:"agent_jwt",companyId:this.binding.companyId,agentId:this.binding.agentId,runId:this.binding.runId,onBehalfOfUserId:context.run.responsibleUserId},call.tool,call.arguments,
      sourceSet=>onNativeInputSource?.({sourceSet,observedSourceInputs:sourceSet.inputs}));
    const input = record(call.arguments);
    if (call.tool === MANAGED_NATIVE_CONTEXT_READ_TOOL) {
      if (!this.binding.nativeModelOutputCapture || !this.binding.managedNativeContextRead ||
        !this.binding.managedNativeContextReadCapture ||
        Object.keys(input).length !== 1 || typeof input.query !== "string" || !input.query.trim() || input.query.length > 4_000)
        throw forbidden("Managed Context read arguments are invalid");
      return this.binding.managedNativeContextRead(input.query, call.callId);
    }
    if (call.tool === MANAGED_NATIVE_REMEMBER_TOOL) {
      if (!this.binding.nativeModelOutputCapture)
        throw forbidden("Managed Memory output capture is unavailable");
      // This managed-only descriptor is supplied by Tool Gateway and is
      // intentionally not part of the general semantic-operation catalog.
      // Its original Gateway policy, approval and current-source checks remain
      // authoritative inside #rememberManagedNativeMemory.
      return this.#rememberManagedNativeMemory(call);
    }
    if (call.tool === READ_CHAT_ATTACHMENT_TOOL_NAME) {
      const scope = this.binding.chatAttachmentReadScope;
      const identityKeys = ["companyId", "issueId", "runId", "agentId"] as const;
      if (!scope || identityKeys.some((key) => scope.options.binding[key] !== this.binding[key])) {
        throw new Error("paperclip_runner_chat_attachment_read_scope_unavailable");
      }
      if (Object.keys(input).some((key) => key !== "sourceCommentId" && key !== "attachmentId")) {
        throw new Error("paperclip_runner_chat_attachment_read_arguments_invalid");
      }
      const result = await scope.read({
        sourceCommentId: requiredUuid(input.sourceCommentId),
        attachmentId: requiredUuid(input.attachmentId),
      });
      const sourceCapture = scope.nativeReadResultCapture(result);
      // Scope captures the exact delivered Attachment and retained owner roots;
      // its null sourceSet remains explicit unknown history.
      onNativeInputSource?.(sourceCapture ?? { sourceSet: null, observedSourceInputs: [] });
      return result;
    }
    if (call.tool === READ_CURRENT_WAKE_COMMENTS_TOOL_NAME) {
      if (!this.binding.currentWakeComments) {
        throw new Error("paperclip_runner_tool_not_advertised");
      }
      return readCurrentWakeComments(
        this.db,
        this.binding.currentWakeComments,
        input,
      );
    }
    if (call.tool === LIST_CHAT_ATTACHMENTS_TOOL_NAME) {
      return listAuthorizedChatAttachments({
        db: this.db,
        binding: this.binding,
        sourceCommentId:
          input.sourceCommentId === null || input.sourceCommentId === undefined
            ? null
            : requiredUuid(input.sourceCommentId),
        limit: boundedLimit(input.limit, 20, 50),
        cursor:
          input.cursor === null || input.cursor === undefined
            ? null
            : requiredString(input.cursor),
      });
    }
    if (call.tool === REUSE_CHAT_ATTACHMENT_TOOL_NAME) {
      return this.#reuseChatAttachment(input);
    }
    const descriptor = CAPABILITY_SEMANTIC_TOOL_CATALOG.find(
      (candidate) => candidate.operationId === call.tool,
    ) ?? paperclipSemanticAction(call.tool);
    if (
      !descriptor ||
      !descriptor.allowedModes.includes(
        context.issue.workMode as "standard" | "planning" | "ask",
      )
    ) {
      throw new Error("paperclip_runner_tool_mode_denied");
    }
    switch (call.tool) {
      case "create_skill": {
        const apiUrl = this.binding.apiUrl ?? process.env.PAPERCLIP_API_URL;
        const token = createLocalAgentJwt(this.binding.agentId, this.binding.companyId, context.actor.adapterType, this.binding.runId, context.run.responsibleUserId);
        if (!apiUrl || !token) throw new Error("Skill tool authentication is unavailable");
        return callCreateSkillTool({ arguments: input, apiUrl, token, companyId: this.binding.companyId });
      }
      case "create_project":
      case "list_project_repositories":
      case "list_projects": {
        // Managed OpenCode advertises this operation only when the exact
        // provider response capture is installed. Never silently fall back to
        // the ordinary API route if that per-call capture was lost.
        if (call.tool === "create_project" && this.binding.nativeModelOutputCapture &&
          !this.binding.nativeModelOutputCapture.value?.managedOpenCodeToolUse)
          throw forbidden("Managed Project creation has no exact provider tool-use capture");
        if (call.tool === "create_project" && this.binding.nativeModelOutputCapture?.value?.managedOpenCodeToolUse) {
          const managedCapture = this.binding.nativeModelOutputCapture.value;
          if (!managedNativeProjectArgumentsSchema.safeParse(input).success)
            throw forbidden("Managed Project creation arguments are invalid");
          // Pass the untouched provider JSON into the owner so its idempotency
          // hash remains bound to the exact arguments captured at dispatch.
          const managedArguments = input;
          await this.binding.testBeforeManagedProjectCreate?.(managedCapture);
          const created = await createManagedNativeProjectOutput({ db: this.db, actor: reader,
            companyId: this.binding.companyId, issueId: this.binding.issueId, callId: call.callId,
            arguments: managedArguments, capture: managedCapture });
          await this.binding.testAfterManagedProjectCreate?.({ actor: reader, companyId: this.binding.companyId,
            issueId: this.binding.issueId, capture: managedCapture, callId: call.callId,
            arguments: managedArguments,
            result: created });
          onManagedProjectCreateCapture?.({ project: created.project, receipt: created.receipt,
            sourceSet: created.sourceSet, outputCapture: managedCapture });
          return created.project;
        }
        const apiUrl = this.binding.apiUrl ?? process.env.PAPERCLIP_API_URL;
        const token = createLocalAgentJwt(this.binding.agentId, this.binding.companyId, context.actor.adapterType, this.binding.runId, context.run.responsibleUserId);
        if (!apiUrl || !token) throw new Error("Project tool authentication is unavailable");
        return callProjectTool({ name: call.tool, arguments: input, apiUrl, token,
          companyId: this.binding.companyId, issueId: this.binding.issueId, agentId: this.binding.agentId,
          conversation: Boolean(context.issue.conversationAgentId) });
      }
      case "search_api": return searchRunnerApi(call.arguments);
      case "hire_agent": {
        const body: Record<string, unknown> = {
          name: requiredString(input.name),
          adapterType: "paperclip_runner",
          inheritRuntimeFrom: "caller",
          reportsTo: this.binding.agentId,
          sourceIssueId: this.binding.issueId,
        };
        if (input.role !== undefined) body.role = input.role;
        if (input.title !== undefined) body.title = input.title;
        if (input.capabilities !== undefined) body.capabilities = input.capabilities;
        if (typeof input.instructions === "string" && input.instructions.trim()) {
          body.instructionsBundle = {
            entryFile: "AGENTS.md",
            files: { "AGENTS.md": input.instructions },
          };
        }
        const { operationId, ...response } = record(await this.#callApi(call.callId, {
          operationId: "POST /api/companies/{companyId}/agent-hires",
          pathParams: { companyId: this.binding.companyId },
          body,
        }));
        return { ...response, apiOperationId: operationId };
      }
      case "call_api": {
        // PRP reserves operationId/callId for semantic result identity. The
        // HTTP operation is metadata, including in previously saved receipts;
        // exposing it as operationId makes the runner reject a valid response.
        const { operationId, ...response } = record(await this.#callApi(call.callId, call.arguments,
          onProjectToolResult, onManagedProjectCreateCapture
            ? async capture => { onManagedProjectCreateCapture(capture); }
            : undefined));
        return { ...response, apiOperationId: operationId };
      }
      case "get_task_context": {
        const childTasks = await this.db.select({ ...getTableColumns(issues),
          sourceVersion: sql<string>`extract(epoch from ${issues.updatedAt})::text`,
          ownerBodyHash: sql<string>`public.aw_native_payload_body_hash('issue',to_jsonb(${issues}))` })
          .from(issues)
          .where(and(
            eq(issues.companyId, this.binding.companyId),
            eq(issues.parentId, this.binding.issueId),
            isNull(issues.hiddenAt),
            await issueReadSqlCondition(this.db, reader),
          ))
          .orderBy(desc(issues.createdAt), desc(issues.id))
          .limit(101);
        const [activeSourceRow] = await this.db.select({
          id: issues.id, companyId: issues.companyId, identifier: issues.identifier, title: issues.title,
          description: issues.description, workMode: issues.workMode, updatedAt: issues.updatedAt,
          payloadSourceSnapshot: issues.payloadSourceSnapshot,
          payloadSourceSnapshotInvalidated: issues.payloadSourceSnapshotInvalidated,
          sourceVersion: sql<string>`extract(epoch from ${issues.updatedAt})::text`,
          ownerBodyHash: sql<string>`public.aw_native_payload_body_hash('issue',to_jsonb(${issues}))`,
        }).from(issues).where(and(eq(issues.companyId, this.binding.companyId), eq(issues.id, this.binding.issueId)));
        const taskRows = [activeSourceRow, ...childTasks.slice(0, 100)].filter((row): row is NonNullable<typeof activeSourceRow> => Boolean(row));
        const taskOwners: NativeObservedOwnerSource[] = taskRows.map(row => ({ companyId: row.companyId,
          input: { kind: "task", issueId: row.id, sourceVersion: row.sourceVersion,
            contentHash: row.ownerBodyHash },
          payloadSourceSnapshot: row.payloadSourceSnapshot,
          invalidated: row.payloadSourceSnapshotInvalidated }));
        const acceptedPlan = await this.#acceptedPlan(context.run.contextSnapshot);
        const sourcePlanApproval = await handoffPlanContext(this.db, context.issue);
        const reviewOutcomes = await childReviewOutcomes(this.db, this.binding.companyId, this.binding.issueId, reader);
        const assignedReview = this.binding.nativeReview ? (await getNativeReviewAssignment(this.db, {
          ...this.binding, contextSnapshot: this.binding.nativeReview,
          allowResolvedByRunId: this.binding.runId,
        }))?.interaction : undefined;
        const contextOwners = [...taskOwners];
        const contextInteractions: NativePayloadSourceInput[] = [];
        let compositesComplete = true;
        const capturePlanSource = async (issueId: string, revisionId: string, interactionId: string | null) => {
          const [revision] = await this.db.select({ documentId: documentRevisions.documentId,
            revisionId: documentRevisions.id, body: documentRevisions.body,
            payloadSourceSnapshot: documentRevisions.payloadSourceSnapshot,
            payloadSourceSnapshotInvalidated: documentRevisions.payloadSourceSnapshotInvalidated,
          }).from(documentRevisions).innerJoin(issueDocuments, and(
            eq(issueDocuments.companyId, documentRevisions.companyId),
            eq(issueDocuments.documentId, documentRevisions.documentId),
            eq(issueDocuments.issueId, issueId), eq(issueDocuments.key, "plan"),
          )).where(and(eq(documentRevisions.companyId, this.binding.companyId),
            eq(documentRevisions.id, revisionId))).limit(1);
          if (!revision) { compositesComplete = false; return; }
          contextOwners.push({ companyId: this.binding.companyId,
            input: { kind: "document_revision", documentId: revision.documentId, revisionId: revision.revisionId,
              issueId, contentHash: createHash("sha256").update(revision.body, "utf8").digest("hex") },
            payloadSourceSnapshot: revision.payloadSourceSnapshot,
            invalidated: revision.payloadSourceSnapshotInvalidated });
          if (!interactionId) { compositesComplete = false; return; }
          const interaction = await this.#captureNativeInteractionSource(issueId, interactionId);
          if (!interaction) { compositesComplete = false; return; }
          contextInteractions.push(interaction);
        };
        if (acceptedPlan) {
          const interactionId = await this.#acceptedPlanInteractionId(context.issue.id, acceptedPlan.revisionId);
          await capturePlanSource(context.issue.id, acceptedPlan.revisionId, interactionId);
        }
        if (sourcePlanApproval) {
          await capturePlanSource(sourcePlanApproval.sourceIssueId, sourcePlanApproval.revisionId,
            sourcePlanApproval.interactionId);
        }
        for (const outcome of reviewOutcomes) {
          const sourceIssueId = record(outcome.result).childTaskId;
          if (typeof sourceIssueId !== "string") { compositesComplete = false; continue; }
          const interaction = await this.#captureNativeInteractionSource(sourceIssueId, outcome.id);
          if (!interaction) { compositesComplete = false; continue; }
          contextInteractions.push(interaction);
        }
        // Assigned native completion review has a separate original owner and
        // remains explicitly unknown until that owner exposes a source capture.
        if (assignedReview) compositesComplete = false;
        const taskSourceClosure = nativeSourceSetFromObservedOwners(contextOwners, contextInteractions);
        const result = {
          company: { id: this.binding.companyId },
          actor: redactedActor(context.actor),
          activeTask: redactedTask(context.issue),
          childTasks: childTasks.slice(0, 100).map(redactedTask),
          childTasksTruncated: childTasks.length > 100,
          delegationGuidance: "Reuse existing child tasks for delegated work. Inspect a completed child's comments and documents before creating another task for the same deliverable. Use search_tasks if the child task list is truncated.",
          run: {
            id: this.binding.runId,
            status: context.run.status,
            invocationSource: context.run.invocationSource,
          },
          connectionGuidance: CONNECTION_INTENT_AGENT_GUIDANCE,
          acceptedPlan,
          sourcePlanApproval,
          childReviewOutcomes: reviewOutcomes,
          ...(this.binding.nativeReview ? { assignedReview } : {}),
        };
        // Task rows are exact source inputs when the context contains only the
        // active/child task projection. Plan approvals and review outcomes are
        // separate owners; until each returned row has its own source capture,
        // preserve the result but leave its source closure unknown.
        const activeTaskMatches = activeSourceRow?.id === context.issue.id &&
          activeSourceRow.title === context.issue.title && activeSourceRow.description === context.issue.description &&
          activeSourceRow.workMode === context.issue.workMode && activeSourceRow.identifier === context.issue.identifier;
        onNativeInputSource?.({ sourceSet: compositesComplete && activeTaskMatches && taskSourceClosure.sourceSet
            ? taskSourceClosure.sourceSet : null,
          observedSourceInputs: activeTaskMatches ? taskSourceClosure.observedSourceInputs : [],
        });
        return result;
      }
      case "get_task_history": {
        const limit = boundedLimit(input.limit);
        const comments = await this.db.select({
          id: issueComments.id,
          body: issueComments.body,
          authorAgentId: issueComments.authorAgentId,
          authorUserId: issueComments.authorUserId,
          createdAt: issueComments.createdAt,
          sourceVersion: sql<string>`extract(epoch from ${issueComments.updatedAt})::text`,
          payloadSourceSnapshot: issueComments.payloadSourceSnapshot,
          payloadSourceSnapshotInvalidated: issueComments.payloadSourceSnapshotInvalidated,
        }).from(issueComments)
          .where(and(
            eq(issueComments.companyId, this.binding.companyId),
            eq(issueComments.issueId, this.binding.issueId),
            isNull(issueComments.deletedAt),
          ))
          .orderBy(desc(issueComments.createdAt))
          .limit(limit);
        const orderedComments = comments.reverse();
        const owners: NativeObservedOwnerSource[] = [];
        let exactProjection = true;
        for (const row of orderedComments) {
          const projection = await issueService(this.db).getComment(row.id);
          const [currentVersion] = await this.db.select({
            sourceVersion: sql<string>`extract(epoch from ${issueComments.updatedAt})::text`,
          }).from(issueComments).where(and(eq(issueComments.companyId, this.binding.companyId),
            eq(issueComments.issueId, this.binding.issueId), eq(issueComments.id, row.id), isNull(issueComments.deletedAt)));
          if (!projection || projection.id !== row.id || projection.issueId !== this.binding.issueId ||
            projection.body !== row.body || currentVersion?.sourceVersion !== row.sourceVersion) {
            exactProjection = false;
          }
          if (projection) owners.push({ companyId: this.binding.companyId,
            input: { kind: "comment", issueId: this.binding.issueId, commentId: row.id,
              sourceVersion: row.sourceVersion,
              contentHash: nativeCommentProjectionHash({ body: projection.body, presentation: projection.presentation,
                metadata: projection.metadata }) },
            payloadSourceSnapshot: row.payloadSourceSnapshot,
            invalidated: row.payloadSourceSnapshotInvalidated });
          else exactProjection = false;
        }
        const sourceClosure = nativeSourceSetFromObservedOwners(owners);
        const result = { comments: orderedComments.map(({ sourceVersion: _sourceVersion,
          payloadSourceSnapshot: _payloadSourceSnapshot,
          payloadSourceSnapshotInvalidated: _payloadSourceSnapshotInvalidated, ...comment }) => comment) };
        const emptyHistorySourceSet: NativePayloadSourceSet = {
          policy: { ...emptyNativeSourcePolicy(), issueIds: [this.binding.issueId] }, inputs: [],
        };
        onNativeInputSource?.({ sourceSet: exactProjection
            ? (orderedComments.length === 0 ? emptyHistorySourceSet : sourceClosure.sourceSet) : null,
          observedSourceInputs: sourceClosure.observedSourceInputs });
        return result;
      }
      case "search_tasks": {
        const tasks = await issueService(this.db).list(this.binding.companyId, {
          readCondition: await issueReadSqlCondition(this.db, reader),
        });
        const query = typeof input.query === "string" ? input.query.toLowerCase() : "";
        const statuses = Array.isArray(input.statuses) ? new Set(input.statuses.filter((value): value is string => typeof value === "string")) : null;
        return { tasks: tasks.filter((task) =>
          (!query || `${task.identifier} ${task.title} ${task.description ?? ""}`.toLowerCase().includes(query))
          && (!statuses || statuses.size === 0 || statuses.has(task.status))
        ).slice(0, boundedLimit(input.limit)).map(redactedTask) };
      }
      case "list_documents": {
        const documents = await documentService(this.db).listIssueDocuments(this.binding.issueId);
        for (const document of documents) if (document.latestRevisionId)
          await this.#assertCurrentDocumentRevision(document.latestRevisionId);
        return { documents };
      }
      case "read_document": {
        const document = await documentService(this.db).getIssueDocumentByKey(this.binding.issueId, requiredString(input.key), {
          onSourceCapture: source => { onDocumentReadSource?.(source); },
        });
        if (!document) throw new Error("paperclip_runner_document_not_found");
        return { document };
      }
      case "list_document_revisions": {
        const revisions = await documentService(this.db).listIssueDocumentRevisions(this.binding.issueId, requiredString(input.key));
        for (const revision of revisions) await this.#assertCurrentDocumentRevision(revision.id, false);
        return { revisions };
      }
      case "write_document": return this.#writeDocument(input);
      case MANAGED_NATIVE_REMEMBER_TOOL: return this.#rememberManagedNativeMemory(call);
      case "list_agents":
        return { actors: (await agentService(this.db).list(this.binding.companyId)).map(redactedActor) };
      case "get_agent": {
        const actor = await agentService(this.db).getById(requiredString(input.actorId));
        if (!actor || actor.companyId !== this.binding.companyId) throw new Error("paperclip_runner_agent_not_found");
        return { actor: redactedActor(actor) };
      }
      case "list_approvals":
        return { approvals: await approvalService(this.db).list(this.binding.companyId) };
      case "get_approval": {
        const approval = await this.#approval(requiredString(input.approvalId));
        return { approval };
      }
      case "get_approval_context": {
        const approval = await this.#approval(requiredString(input.approvalId));
        const tasks = await this.db.select({ issue: issues }).from(issueApprovals)
          .innerJoin(issues, eq(issues.id, issueApprovals.issueId))
          .where(and(
            eq(issueApprovals.approvalId, approval.id),
            eq(issueApprovals.companyId, this.binding.companyId),
            eq(issues.companyId, this.binding.companyId),
          ));
        return { approval, tasks: tasks.map((row) => row.issue) };
      }
      case "report_progress": return this.#reportProgress(input);
      case "update_task": return this.#updateTask(input);
      case "propose_completion": return this.#proposeCompletion(input,
        (await captureRunIdentity(this.db, this.binding)).context?.id ?? null);
      case "request_human_input": return this.#requestHumanInput(input,
        (await captureRunIdentity(this.db, this.binding)).context?.id ?? null);
      case "create_task": return this.#createTask(input,
        (await captureRunIdentity(this.db, this.binding)).context?.id ?? null);
      case "reassign_task": return this.#reassignTask(input);
      case "set_dependencies": return this.#setDependencies(input);
      case "register_deliverable": return this.#registerDeliverable(input);
      default: throw new Error("paperclip_runner_tool_not_bound");
    }
  }

  async #callApi(callId: string, value: unknown,
    onProjectToolResult?: (source: NativeProjectToolResultSource) => Promise<void>,
    onManagedProjectCreateToolResult?: (capture: NativeManagedProjectCreateCapture) => Promise<void>): Promise<unknown> {
    const bound = await this.#boundContext();
    const context = { ...this.binding, issueIdentifier: bound.issue.identifier, workMode: bound.issue.workMode };
    const { input, operation } = validateRunnerApiCall(value, context);
    const apiUrl = this.binding.apiUrl ?? process.env.PAPERCLIP_API_URL;
    if (!apiUrl) throw new Error("Paperclip API origin is unavailable");
    let nativeToolEffect: NativeToolEffectClaim | undefined;
    const callIdentity = nativeBackendToolCallIdentity.getStore();
    const nativeInputDispatch = resolveNativeInputDispatchReceiptIdentity(bound.run.runnerProfileJson, callIdentity, "call_api");
    const mutation = !["GET", "HEAD", "OPTIONS"].includes(operation.method);
    const managedProjectApiCall = managedNativeProjectApiCallSchema.safeParse(value);
    const managedProjectOutputCapture = this.binding.nativeModelOutputCapture?.value ?? null;
    const managedProjectApiCapture = managedProjectApiCall.success && managedProjectApiCall.data.pathParams.companyId === this.binding.companyId &&
      managedProjectOutputCapture?.runId === this.binding.runId &&
      managedProjectOutputCapture.managedOpenCodeToolUse?.toolName === "call_api" &&
      managedProjectOutputCapture.managedOpenCodeToolUse.callId === callId &&
      managedProjectOutputCapture.managedOpenCodeToolUse.argumentsHash === nativeSha256(value)
      ? managedProjectOutputCapture : null;
    const contentType = input.contentType ?? (input.files?.length ? "multipart/form-data" : "application/json");
    if (mutation && nativeInputDispatch && callIdentity && !input.files?.length &&
      (!input.body || (typeof input.body === "object" && !Array.isArray(input.body))) &&
      /^application\/json(?:\s*;|$)/i.test(contentType)) {
      const [lease] = await this.db.select({ leaseOwner: nativeRunFinalizations.leaseOwner,
        leaseExpiresAt: nativeRunFinalizations.leaseExpiresAt, controllerBootId: nativeRunFinalizations.controllerBootId,
        controllerPid: nativeRunFinalizations.controllerPid, controllerProcessStartedAt: nativeRunFinalizations.controllerProcessStartedAt,
      }).from(nativeRunFinalizations).where(and(
        eq(nativeRunFinalizations.companyId, this.binding.companyId), eq(nativeRunFinalizations.runId, this.binding.runId),
        eq(nativeRunFinalizations.issueId, this.binding.issueId), eq(nativeRunFinalizations.attempt, nativeInputDispatch.attempt),
        sql`${nativeRunFinalizations.leaseExpiresAt} > clock_timestamp()`,
      ));
      if (lease?.leaseOwner && lease.leaseExpiresAt && lease.controllerBootId && lease.controllerPid && lease.controllerProcessStartedAt) {
        const url = runnerApiUrl(operation, input, context, apiUrl);
        nativeToolEffect = {
          ...nativeInputDispatch,
          tool: "call_api",
          operationId: operation.operationId,
          method: operation.method.toUpperCase(),
          pathAndQuery: `${url.pathname}${url.search}`,
          bodyPresent: input.body !== undefined,
          bodyHash: createHash("sha256").update(input.body === undefined ? "null" : canonicalJson(input.body)).digest("hex"),
          apiReceiptDigest: createHash("sha256").update(canonicalJson(input)).digest("hex"),
          leaseOwner: lease.leaseOwner,
          leaseExpiresAt: lease.leaseExpiresAt.toISOString(),
          controllerBootId: lease.controllerBootId,
          controllerPid: lease.controllerPid,
          controllerProcessStartedAt: lease.controllerProcessStartedAt.toISOString(),
        };
      }
    }
    if (managedProjectApiCapture && (!nativeToolEffect || !managedProjectApiCall.success ||
      nativeToolEffect.operationId !== managedProjectApiCall.data.operationId || nativeToolEffect.method !== "POST" ||
      nativeToolEffect.pathAndQuery !== `/api/companies/${this.binding.companyId}/projects`))
      throw forbidden("Managed Project API creation requires the exact signed POST effect claim");
    const token = createLocalAgentJwt(this.binding.agentId, this.binding.companyId, bound.actor.adapterType,
      this.binding.runId, bound.run.responsibleUserId, { kind: "standard" }, nativeToolEffect);
    if (!token) throw new Error("Paperclip run authentication is unavailable");
    const execute = async () => {
      const current = await this.#boundContext();
      if (!runnerApiToolsEnabled(this.binding.companyId, this.binding.apiToolsEnabled)) throw new Error("paperclip_runner_tool_not_advertised");
      return executeRunnerApi(input, { ...context, workMode: current.issue.workMode }, {
        apiUrl, token,
        beforeDispatch: async () => {
          const fresh = await this.#boundContext();
          if (!runnerApiToolsEnabled(this.binding.companyId, this.binding.apiToolsEnabled)) throw new Error("paperclip_runner_tool_not_advertised");
          validateRunnerApiCall(input, { ...context, workMode: fresh.issue.workMode });
        },
        readFile: (file) => this.#readApiFile(file),
        saveResponse: async (bytes, contentType) => {
          const storage = this.binding.storage ?? getStorageService();
          const saved = await storage.putFile({ companyId: this.binding.companyId, namespace: "runner-api", originalFilename: contentType.includes("json") ? "response.json" : "response.bin", contentType, body: bytes });
          const asset = await assetService(this.db).create(this.binding.companyId, { ...saved, createdByAgentId: this.binding.agentId });
          const activity = await persistActivity(this.db, { companyId: this.binding.companyId, actorType: "agent", actorId: this.binding.agentId, agentId: this.binding.agentId, runId: this.binding.runId, issueId: this.binding.issueId, action: "asset.created", entityType: "asset", entityId: asset.id, details: { source: "runner.call_api", byteSize: saved.byteSize } });
          publishActivity(activity.publication);
          return { artifactId: asset.id, url: `/api/assets/${asset.id}/content`, contentType, byteSize: saved.byteSize, sha256: saved.sha256 };
        },
      });
    };
    if (["GET", "HEAD", "OPTIONS"].includes(operation.method)) {
      const result = await execute();
      if (operation.operationId === "GET /api/projects/{id}" && onProjectToolResult) {
        const capture = captureNativeProjectToolResult({ companyId: this.binding.companyId,
          requestedProjectId: input.pathParams?.id, turnId: nativeBackendToolCallIdentity.getStore()?.turnId ?? null,
          callId, requestHash: createHash("sha256").update(canonicalJson(input)).digest("hex"),
          pathAndQuery: (() => { const url = runnerApiUrl(operation, input, context, apiUrl); return `${url.pathname}${url.search}`; })(),
          result });
        await onProjectToolResult(capture);
        // Native Project reads use the existing run-owned API receipt map. The
        // exact response body stays in the provider result path; only its
        // digest and bounded request/dispatch identity are retained here.
        const identity = nativeBackendToolCallIdentity.getStore();
        if (capture.source && identity?.tool === "call_api" && identity.callId === callId &&
          identity.turnId === capture.turnId && nativeInputDispatch) {
          const receiptKey = createHash("sha256").update(callId).digest("hex");
          await this.db.transaction(async tx => {
            const [run] = await tx.select().from(heartbeatRuns).where(and(
              eq(heartbeatRuns.companyId, this.binding.companyId), eq(heartbeatRuns.id, this.binding.runId),
              eq(heartbeatRuns.agentId, this.binding.agentId), eq(heartbeatRuns.nativeIssueId, this.binding.issueId),
              eq(heartbeatRuns.status, "running"),
            )).for("update");
            const profile = record(run?.runnerProfileJson);
            const associations = Array.isArray(profile.nativeToolCallDispatchAssociations)
              ? profile.nativeToolCallDispatchAssociations.map(record).filter(value => value.callId === callId &&
                value.turnId === capture.turnId && value.tool === "call_api") : [];
            if (!run || associations.length !== 1 || associations[0]!.dispatchId !== nativeInputDispatch.dispatchId ||
              associations[0]!.eventSeq !== nativeInputDispatch.eventSeq || associations[0]!.attempt !== nativeInputDispatch.attempt ||
              typeof associations[0]!.argumentsHash !== "string" || !/^[0-9a-f]{64}$/.test(associations[0]!.argumentsHash))
              throw new Error("native_project_api_receipt_binding_invalid");
            const resultJson = record(run.resultJson), receipts = record(resultJson.apiToolReceipts);
            const receipt = { callId, turnId: capture.turnId, eventSeq: nativeInputDispatch.eventSeq,
              attempt: nativeInputDispatch.attempt, operationId: capture.operationId, method: "GET",
              pathAndQuery: capture.pathAndQuery, requestHash: capture.requestHash,
              argumentsHash: associations[0]!.argumentsHash as string, state: "completed", status: 200,
              resultDigest: capture.apiResultDigest, providerResultDigest: capture.resultDigest };
            if (receipts[receiptKey] && JSON.stringify(receipts[receiptKey]) !== JSON.stringify(receipt))
              throw new Error("native_project_api_receipt_conflict");
            receipts[receiptKey] = receipt;
            await tx.update(heartbeatRuns).set({ resultJson: { ...resultJson, apiToolReceipts: receipts } })
              .where(eq(heartbeatRuns.id, run.id));
          });
        }
      }
      return result;
    }
    if (!callId || callId.length > 500) throw badRequest("A bounded runner call id is required");
    // Reserve durably before HTTP dispatch, without holding a DB lock over an
    // HTTP route that itself needs DB locks. A crash leaves an explicit unknown
    // outcome rather than replaying a possibly committed external mutation.
    const key = createHash("sha256").update(callId).digest("hex");
    const digest = createHash("sha256").update(canonicalJson(input)).digest("hex");
    const prior = await this.db.transaction(async (tx) => {
      const locked = await this.#lockAuthorizedMutationContext(tx as unknown as Db);
      const resultJson = record(locked.run.resultJson);
      const receipts = record(resultJson.apiToolReceipts);
      const existing = record(receipts[key]);
      if (receipts[key]) {
        if (existing.digest !== digest) throw badRequest("API call id was reused with different arguments");
        return { result: existing.result ?? { ok: false, status: null, error: "api_outcome_unknown", outcome: "unknown", guidance: "Inspect state before issuing another mutation." } };
      }
      if (Object.keys(receipts).length >= 512) throw badRequest("Run API mutation limit reached");
      const receipt = { digest, operationId: operation.operationId, state: "pending" as const,
        ...(managedProjectApiCapture ? { argumentsHash: managedProjectOutputCapture!.managedOpenCodeToolUse!.argumentsHash } : {}),
        ...(nativeToolEffect ? { callId, turnId: nativeToolEffect.turnId, dispatchId: nativeToolEffect.dispatchId,
          eventSeq: nativeToolEffect.eventSeq, attempt: nativeToolEffect.attempt,
          method: nativeToolEffect.method, pathAndQuery: nativeToolEffect.pathAndQuery,
          bodyHash: nativeToolEffect.bodyHash } : {}) };
      receipts[key] = receipt;
      const captures = record(resultJson.nativeManagedProjectApiCaptures);
      if (managedProjectApiCapture && nativeToolEffect && managedProjectApiCall.success &&
        nativeToolEffect.operationId === managedProjectApiCall.data.operationId &&
        nativeToolEffect.method === "POST" && nativeToolEffect.pathAndQuery === `/api/companies/${this.binding.companyId}/projects` &&
        nativeToolEffect.apiReceiptDigest === digest) {
        captures[key] = { operationId: nativeToolEffect.operationId, apiReceiptDigest: digest,
          capture: managedProjectApiCapture };
      }
      await tx.update(heartbeatRuns).set({ resultJson: { ...resultJson, apiToolReceipts: receipts,
        nativeManagedProjectApiCaptures: captures } }).where(eq(heartbeatRuns.id, this.binding.runId));
      return null;
    });
    if (prior) return prior.result;
    const result = await execute();
    // Some older routes attribute the agent but omit runId. Retain their domain
    // event and add the run-bound HTTP receipt, without logging request bodies.
    const apiActivity = await persistActivity(this.db, {
      companyId: this.binding.companyId, actorType: "agent", actorId: this.binding.agentId,
      agentId: this.binding.agentId, runId: this.binding.runId, issueId: this.binding.issueId,
      action: "runner.api_called", entityType: "issue", entityId: this.binding.issueId,
      details: { operationId: operation.operationId, requestFingerprint: digest, pathParams: input.pathParams ?? {}, status: result.status, outcome: record(result).outcome ?? (result.ok ? "succeeded" : "failed") },
    });
    publishActivity(apiActivity.publication);
    await this.db.transaction(async (tx) => {
      const [run] = await tx.select().from(heartbeatRuns).where(eq(heartbeatRuns.id, this.binding.runId)).for("update");
      const resultJson = record(run?.resultJson);
      const receipts = record(resultJson.apiToolReceipts);
      const { operationId: _httpOperationId, ...publicResult } = record(result);
      const providerResultDigest = nativeSha256(nativeCallApiResultEnvelope(callId,
        { ...publicResult, apiOperationId: operation.operationId }));
      receipts[key] = { digest, operationId: operation.operationId, state: "completed", providerResultDigest, result,
        ...(managedProjectApiCapture ? { argumentsHash: managedProjectOutputCapture!.managedOpenCodeToolUse!.argumentsHash } : {}),
        ...(nativeToolEffect ? { callId, turnId: nativeToolEffect.turnId, dispatchId: nativeToolEffect.dispatchId,
          eventSeq: nativeToolEffect.eventSeq, attempt: nativeToolEffect.attempt,
          method: nativeToolEffect.method, pathAndQuery: nativeToolEffect.pathAndQuery,
          bodyHash: nativeToolEffect.bodyHash } : {}) };
      const captures = record(resultJson.nativeManagedProjectApiCaptures);
      delete captures[key];
      await tx.update(heartbeatRuns).set({ resultJson: { ...resultJson, apiToolReceipts: receipts,
        nativeManagedProjectApiCaptures: captures } }).where(eq(heartbeatRuns.id, this.binding.runId));
    });
    const resultData = "data" in result ? result.data : undefined;
    if (managedProjectApiCapture && managedProjectApiCall.success && result.ok === true && result.status === 201 &&
      resultData && typeof resultData === "object" && !Array.isArray(resultData)) {
      const [run] = await this.db.select({ resultJson: heartbeatRuns.resultJson }).from(heartbeatRuns).where(and(
        eq(heartbeatRuns.companyId, this.binding.companyId), eq(heartbeatRuns.id, this.binding.runId),
        eq(heartbeatRuns.agentId, this.binding.agentId), eq(heartbeatRuns.nativeIssueId, this.binding.issueId)));
      const receipts = record(record(run?.resultJson).nativeProjectCreateReceipts);
      const createReceipt = record(receipts[key]) as unknown as NativeProjectCreateReceipt;
      if (createReceipt.callId !== callId || createReceipt.tool !== "call_api" ||
        createReceipt.argumentsHash !== managedProjectOutputCapture?.managedOpenCodeToolUse?.argumentsHash ||
        createReceipt.projectId !== (resultData as Record<string, unknown>).id ||
        createReceipt.resultDigest !== nativeSha256(resultData))
        throw forbidden("Managed Project API result receipt is unavailable");
      if (!nativeToolEffect || nativeToolEffect.operationId !== managedProjectApiCall.data.operationId ||
        nativeToolEffect.method !== "POST" || nativeToolEffect.pathAndQuery !== `/api/companies/${this.binding.companyId}/projects`)
        throw forbidden("Managed Project API effect receipt is unavailable");
      await onManagedProjectCreateToolResult?.({ project: resultData as Record<string, unknown>,
        receipt: createReceipt, sourceSet: managedProjectOutputCapture.sourceSet, outputCapture: managedProjectOutputCapture,
        apiEffect: { operationId: nativeToolEffect.operationId, method: nativeToolEffect.method,
          pathAndQuery: nativeToolEffect.pathAndQuery, apiReceiptDigest: nativeToolEffect.apiReceiptDigest,
          bodyHash: nativeToolEffect.bodyHash, turnId: nativeToolEffect.turnId,
          dispatchId: nativeToolEffect.dispatchId, eventSeq: nativeToolEffect.eventSeq, attempt: nativeToolEffect.attempt } });
    }
    return result;
  }

  async #rememberManagedNativeMemory(call: { tool: string; callId: string; arguments: unknown }) {
    const capture = this.binding.nativeModelOutputCapture?.value;
    const use = capture?.managedOpenCodeToolUse;
    if (!capture || !use || use.callId !== call.callId ||
      use.toolName !== MANAGED_NATIVE_REMEMBER_GATEWAY_TOOL ||
      use.argumentsHash !== nativeSha256(call.arguments)) {
      throw forbidden("Managed Memory write has no exact provider tool-use capture");
    }
    const current = await this.#boundContext();
    const token = createLocalAgentJwt(this.binding.agentId, this.binding.companyId,
      current.actor.adapterType, this.binding.runId, current.run.responsibleUserId);
    const claims = token ? verifyLocalAgentJwt(token) : null;
    if (!claims || claims.sub !== this.binding.agentId || claims.company_id !== this.binding.companyId ||
      claims.run_id !== this.binding.runId ||
      (claims.responsible_user_id ?? null) !== (current.run.responsibleUserId ?? null)) {
      throw forbidden("Managed Memory requires the current verified Agent credential");
    }
    const memberships = current.run.responsibleUserId
      ? await this.db.select({ companyId: companyMemberships.companyId,
          membershipRole: companyMemberships.membershipRole, status: companyMemberships.status })
          .from(companyMemberships).where(and(eq(companyMemberships.companyId, this.binding.companyId),
            eq(companyMemberships.principalType, "user"),
            eq(companyMemberships.principalId, current.run.responsibleUserId)))
      : [];
    const actor: AuthorizationActor = {
      type: "agent", source: "agent_jwt", companyId: claims.company_id,
      agentId: claims.sub, runId: claims.run_id,
      onBehalfOfUserId: claims.responsible_user_id ?? null,
      authenticatedCredentialExpiresAt: claims.exp * 1000,
      keyScope: claims.key_scope ?? { kind: "standard" },
      onBehalfOfMemberships: memberships,
    };
    const gateway = getAssignedMcpGateway(this.db);
    const session = await gateway.createSession({
      companyId: this.binding.companyId,
      agentId: this.binding.agentId,
      runId: this.binding.runId,
      issueId: this.binding.issueId,
      authorizationActor: actor,
      actorType: "agent",
      actorId: this.binding.agentId,
    });
    const scopedContext: ScopedToolGatewayContext = {
      session,
      assertCurrent: async descriptor => {
        const stillCurrent = await this.#boundContext();
        if (session.companyId !== this.binding.companyId || session.agentId !== this.binding.agentId ||
          session.runId !== this.binding.runId || session.issueId !== this.binding.issueId ||
          (session.responsibleUserId ?? null) !== (stillCurrent.run.responsibleUserId ?? null) ||
          (descriptor && descriptor.name !== MANAGED_NATIVE_REMEMBER_GATEWAY_TOOL)) {
          throw forbidden("Managed Memory Tool Gateway session changed");
        }
      },
    };
    bindManagedNativeMemoryOutputCapture(scopedContext, capture);
    const gatewayResult = await gateway.executeTool({
      sessionToken: session.token,
      tool: MANAGED_NATIVE_REMEMBER_GATEWAY_TOOL,
      parameters: record(call.arguments),
      timeoutMs: 60_000,
      idempotencyKey: `aw-native-tool:${this.binding.runId}:${use.callId}`,
    }, undefined, scopedContext);
    const completed = record(gatewayResult);
    if ((completed.status !== "completed" && completed.status !== "replayed") ||
      completed.tool !== MANAGED_NATIVE_REMEMBER_GATEWAY_TOOL ||
      typeof completed.invocationId !== "string" || !Object.hasOwn(completed, "result")) {
      throw forbidden("Managed Memory result has no completed canonical Tool Gateway invocation");
    }
    const resultHash = nativeSha256(completed.result);
    const [invocation] = await this.db.select({ id: toolInvocations.id,
      argumentsHash: toolInvocations.argumentsHash, resultHash: toolInvocations.resultHash,
      workflowResultJson: toolInvocations.workflowResultJson,
    }).from(toolInvocations).where(and(
      eq(toolInvocations.companyId, this.binding.companyId),
      eq(toolInvocations.id, completed.invocationId),
      eq(toolInvocations.runId, this.binding.runId),
      eq(toolInvocations.agentId, this.binding.agentId),
      eq(toolInvocations.issueId, this.binding.issueId),
      eq(toolInvocations.idempotencyKey, `aw-native-tool:${this.binding.runId}:${use.callId}`),
      eq(toolInvocations.toolName, MANAGED_NATIVE_REMEMBER_GATEWAY_TOOL),
      eq(toolInvocations.status, "succeeded"),
    ));
    if (!invocation || invocation.argumentsHash !== nativeSha256(call.arguments) ||
      invocation.resultHash !== resultHash || nativeSha256(invocation.workflowResultJson) !== resultHash) {
      throw forbidden("Managed Memory result does not match its canonical invocation");
    }
    // Native tool results are the validated result payload itself. The Gateway
    // wrapper's invocation ID is server authority, while the provider transcript
    // must hash exactly the same bounded result stored in the canonical row.
    return completed.result;
  }

  async #readApiFile(file: RunnerApiFile): Promise<{ bytes: Buffer; filename: string; contentType: string }> {
    if (file.artifactId) {
      const asset = await assetService(this.db).getById(file.artifactId);
      if (!asset || asset.companyId !== this.binding.companyId) throw forbidden("Artifact is not available in this company");
      if (asset.byteSize > RUNNER_API_MAX_BYTES) throw badRequest("Artifact exceeds API transfer limit");
      const object = await (this.binding.storage ?? getStorageService()).getObject(this.binding.companyId, asset.objectKey);
      const chunks: Buffer[] = [];
      let length = 0;
      try {
        for await (const chunk of object.stream) {
          const bytes = Buffer.from(chunk);
          length += bytes.length;
          if (length > RUNNER_API_MAX_BYTES) throw badRequest("Artifact exceeds API transfer limit");
          chunks.push(bytes);
        }
      } finally { object.stream.destroy(); }
      return { bytes: Buffer.concat(chunks), filename: asset.originalFilename ?? "file", contentType: asset.contentType };
    }
    const resolved = await workspaceFileResourceService(this.db).prepareDownload(this.binding.issueId, { path: file.path!, workspace: "auto" });
    const handle = await openRunnerApiWorkspaceFile(resolved.realPath);
    try {
      const stat = await handle.stat();
      if (!stat.isFile() || stat.size > RUNNER_API_MAX_BYTES) throw badRequest("Workspace file exceeds API transfer limit");
      const bytes = Buffer.alloc(RUNNER_API_MAX_BYTES + 1);
      let length = 0;
      while (length < bytes.length) {
        const { bytesRead } = await handle.read(bytes, length, bytes.length - length, length);
        if (!bytesRead) break;
        length += bytesRead;
      }
      if (length > RUNNER_API_MAX_BYTES) throw badRequest("Workspace file exceeds API transfer limit");
      return { bytes: bytes.subarray(0, length), filename: basename(resolved.realPath), contentType: "application/octet-stream" };
    } finally { await handle.close(); }
  }

  async #approval(id: string) {
    const approval = await approvalService(this.db).getById(id);
    if (!approval || approval.companyId !== this.binding.companyId) throw new Error("paperclip_runner_approval_not_found");
    return approval;
  }

  async #boundContext() {
    this.binding.authoritySignal?.throwIfAborted();
    const [row] = await this.db.select({ issue: issues, actor: agents, run: heartbeatRuns })
      .from(heartbeatRuns)
      .innerJoin(issues, eq(issues.id, this.binding.issueId))
      .innerJoin(agents, eq(agents.id, this.binding.agentId))
      .where(and(
        eq(heartbeatRuns.id, this.binding.runId),
        eq(heartbeatRuns.companyId, this.binding.companyId),
        eq(heartbeatRuns.agentId, this.binding.agentId),
        eq(heartbeatRuns.nativeIssueId, this.binding.issueId),
        eq(issues.companyId, this.binding.companyId),
        ...(this.binding.nativeReview ? [] : [
          eq(issues.assigneeAgentId, this.binding.agentId),
          eq(issues.executionRunId, this.binding.runId),
        ]),
        eq(agents.companyId, this.binding.companyId),
      ))
      .limit(1);
    if (
      !row
      || row.run.runtimeMode !== "native"
      || row.run.status !== "running"
      || ["paused", "terminated", "pending_approval", "error"].includes(row.actor.status)
    ) {
      throw new Error("paperclip_runner_tool_binding_not_authorized");
    }
    if (this.binding.nativeReview) {
      const admitted = readNativeReviewAssignmentContext(row.run.contextSnapshot);
      if (!admitted || admitted.nativeReviewInteractionId !== this.binding.nativeReview.nativeReviewInteractionId
        || admitted.nativeReviewDecisionId !== this.binding.nativeReview.nativeReviewDecisionId) {
        throw forbidden("The run was not admitted for this review.");
      }
      const review = await getNativeReviewAssignment(this.db, {
        ...this.binding, contextSnapshot: this.binding.nativeReview,
        allowResolvedByRunId: this.binding.runId,
      });
      if (!review || (review.interaction.status === "pending" && row.issue.executionRunId !== this.binding.runId)) {
        throw forbidden("The assigned review is no longer available to this run.");
      }
    }
    this.binding.authoritySignal?.throwIfAborted();
    this.#assertConversationGeneration(row);
    const actor: AuthorizationActor = { type:"agent",source:"agent_jwt",companyId:this.binding.companyId,
      agentId:this.binding.agentId,runId:this.binding.runId,onBehalfOfUserId:row.run.responsibleUserId };
    // The analytical reviewer below includes the same current Task reader ACL
    // after pinning source rows under the privacy locks. Avoid a duplicate
    // standalone ACL query before that authoritative recheck.
    await assertAnalyticalContextPayloadAccess(this.db,this.binding.companyId,actor,{issueId:this.binding.issueId},undefined,{privacyLockMode:"read"});
    return row;
  }

  async #resolveReview(value: unknown) {
    const input = record(value);
    if (Object.keys(input).some((key) => !["decision", "reason"].includes(key))
      || !["accept", "reject"].includes(String(input.decision))) {
      throw badRequest("Choose accept or reject for this run's assigned review.");
    }
    const reason = typeof input.reason === "string" ? input.reason.trim() : "";
    if (input.decision === "reject" && !reason) throw badRequest("Explain the changes required before rejecting the review.");
    const context = await this.#boundContext();
    const review = await getNativeReviewAssignment(this.db, {
      ...this.binding, contextSnapshot: this.binding.nativeReview,
      allowResolvedByRunId: this.binding.runId,
    });
    if (!review) throw forbidden("Review is no longer assigned to this run.");
    const expectedStatus = input.decision === "accept" ? "accepted" : "rejected";
    if (review.interaction.status !== "pending") {
      if (review.interaction.status !== expectedStatus) throw badRequest("This review already has a different decision.");
      return { interactionId: review.interaction.id, status: expectedStatus, deduplicated: true };
    }
    const apiUrl = this.binding.apiUrl ?? process.env.PAPERCLIP_API_URL;
    const token = createLocalAgentJwt(this.binding.agentId, this.binding.companyId,
      context.actor.adapterType, this.binding.runId, context.run.responsibleUserId);
    if (!apiUrl || !token) throw new Error("Review tool authentication is unavailable");
    // Use the existing resolution route so authorization, activity, dependency
    // wakes and request-changes continuation have one implementation.
    const response = await fetch(`${apiUrl.replace(/\/$/, "")}/api/issues/${this.binding.issueId}/interactions/${review.interaction.id}/${input.decision}`, {
      method: "POST", redirect: "error", signal: AbortSignal.timeout(30_000),
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", "X-Paperclip-Run-Id": this.binding.runId },
      body: JSON.stringify(input.decision === "reject" ? { reason } : {}),
    });
    if (!response.ok) throw new Error(`Review decision was not accepted (${response.status}): ${(await response.text()).slice(0, 2_000)}`);
    return { interactionId: review.interaction.id, status: expectedStatus };
  }

  async #reportProgress(input: Record<string, unknown>): Promise<unknown> {
    const body = typeof input.body === "string" ? input.body.trim() : "";
    const idempotencyKey = typeof input.idempotencyKey === "string" ? input.idempotencyKey.trim() : "";
    if (!body || !idempotencyKey) throw new Error("paperclip_runner_tool_input_invalid");
    let publication: Awaited<ReturnType<typeof persistActivity>>["publication"] | null = null;
    const result = await this.#withMutationReceipt(
      "report_progress",
      idempotencyKey,
      input,
      async (tx, context) => {
        const comment = await issueService(tx).addComment(
          this.binding.issueId,
          body,
          { agentId: this.binding.agentId, runId: this.binding.runId },
          { authorizationReason: this.#sourceChannel() },
          tx,
        );
        const result = { commentId: comment.id, issueId: this.binding.issueId, disposition: "applied" };
        const activity = await persistActivity(tx, {
          companyId: this.binding.companyId,
          actorType: "agent",
          actorId: this.binding.agentId,
          agentId: this.binding.agentId,
          runId: this.binding.runId,
          issueId: this.binding.issueId,
          action: "issue.comment_added",
          entityType: "issue",
          entityId: this.binding.issueId,
          details: {
            commentId: comment.id,
            bodySnippet: comment.body.slice(0, 120),
            identifier: context.issue.identifier,
            issueTitle: context.issue.title,
            authorizationReason: this.#sourceChannel(),
            ...this.#transportDetails(),
          },
        });
        publication = activity.publication;
        return result;
      },
    );
    if (publication) publishActivity(publication);
    return result;
  }

  async #updateTask(input: Record<string, unknown>): Promise<unknown> {
    const idempotencyKey = requiredString(input.idempotencyKey);
    const expectedUpdatedAt = requiredString(input.expectedUpdatedAt);
    if (!Number.isFinite(Date.parse(expectedUpdatedAt)) || new Date(expectedUpdatedAt).toISOString() !== expectedUpdatedAt)
      throw new Error("paperclip_runner_tool_input_invalid");
    const editableFields = ["title", "description", "priority"] as const;
    if (idempotencyKey.length > 240 || !editableFields.some((key) => Object.hasOwn(input, key)) ||
      Object.keys(input).some((key) => !["idempotencyKey", "expectedUpdatedAt", ...editableFields].includes(key))) {
      throw new Error("paperclip_runner_tool_input_invalid");
    }
    if (input.title !== undefined && (typeof input.title !== "string" || !input.title.trim() || input.title.length > 500))
      throw new Error("paperclip_runner_tool_input_invalid");
    if (input.description !== undefined && input.description !== null &&
      (typeof input.description !== "string" || input.description.length > 50_000))
      throw new Error("paperclip_runner_tool_input_invalid");
    if (input.priority !== undefined && !["critical", "high", "medium", "low"].includes(String(input.priority)))
      throw new Error("paperclip_runner_tool_input_invalid");

    let publication: Awaited<ReturnType<typeof persistActivity>>["publication"] | null = null;
    const result = await this.#withMutationReceipt("update_task", idempotencyKey, input, async (tx, context) => {
      if (context.issue.updatedAt.toISOString() !== expectedUpdatedAt)
        throw conflict("Task changed since it was read; refresh the Task before updating", { code: "task_version_conflict" });
      const actor: AuthorizationActor = { type: "agent", source: "agent_jwt", companyId: this.binding.companyId,
        agentId: this.binding.agentId, runId: this.binding.runId, onBehalfOfUserId: context.run.responsibleUserId };
      const decision = await authorizationService(tx).decide({ actor, action: "issue:mutate", resource: {
        type: "issue", companyId: this.binding.companyId, issueId: this.binding.issueId,
        projectId: context.issue.projectId, parentIssueId: context.issue.parentId,
        assigneeAgentId: context.issue.assigneeAgentId, assigneeUserId: context.issue.assigneeUserId,
        status: context.issue.status,
      } });
      if (!decision.allowed) throw forbidden(decision.explanation);
      const updated = await issueService(tx).update(this.binding.issueId, {
        companyGuard: this.binding.companyId,
        ...(input.title !== undefined ? { title: (input.title as string).trim() } : {}),
        ...(input.description !== undefined ? { description: input.description as string | null } : {}),
        ...(input.priority !== undefined ? { priority: input.priority as typeof issues.$inferSelect.priority } : {}),
        actorAgentId: this.binding.agentId,
        actorRunId: this.binding.runId,
      }, tx);
      if (!updated) throw new Error("paperclip_runner_task_not_found");
      const activity = await persistActivity(tx, {
        companyId: this.binding.companyId, actorType: "agent", actorId: this.binding.agentId,
        agentId: this.binding.agentId, runId: this.binding.runId, issueId: this.binding.issueId,
        action: "issue.updated", entityType: "issue", entityId: this.binding.issueId,
        details: { identifier: updated.identifier, changedFields: editableFields.filter(key => input[key] !== undefined),
          status: updated.status, statusVersion: updated.statusVersion, ...this.#transportDetails() },
      });
      publication = activity.publication;
      return { commandId: `update-task:${updated.id}:${updated.statusVersion}`, disposition: "applied",
        stateRevision: updated.statusVersion, entityRefs: [updated.id], scheduledWakeIds: [],
        task: { id: updated.id, title: updated.title, description: updated.description, priority: updated.priority,
          status: updated.status, statusVersion: updated.statusVersion } };
    });
    if (publication) publishActivity(publication);
    return result;
  }

  async #proposeCompletion(input: Record<string, unknown>, identityContextId: string | null): Promise<unknown> {
    const idempotencyKey = requiredString(input.idempotencyKey);
    const expectedUpdatedAt = requiredString(input.expectedUpdatedAt);
    const summary = requiredString(input.summary);
    if (!Number.isFinite(Date.parse(expectedUpdatedAt)) || new Date(expectedUpdatedAt).toISOString() !== expectedUpdatedAt ||
      idempotencyKey.length > 240 || summary.length > 900 ||
      Object.keys(input).some((key) => !["idempotencyKey", "expectedUpdatedAt", "summary"].includes(key))) {
      throw new Error("paperclip_runner_tool_input_invalid");
    }

    let publication: Awaited<ReturnType<typeof persistActivity>>["publication"] | null = null;
    const result = await this.#withMutationReceipt("propose_completion", idempotencyKey, input, async (tx, context) => {
      if (context.issue.updatedAt.toISOString() !== expectedUpdatedAt || context.issue.status !== "in_progress")
        throw conflict("Task changed or is no longer active; refresh it before requesting completion review", { code: "task_version_conflict" });
      const actor: AuthorizationActor = { type: "agent", source: "agent_jwt", companyId: this.binding.companyId,
        agentId: this.binding.agentId, runId: this.binding.runId, onBehalfOfUserId: context.run.responsibleUserId };
      const decision = await authorizationService(tx).decide({ actor, action: "issue:mutate", resource: {
        type: "issue", companyId: this.binding.companyId, issueId: this.binding.issueId,
        projectId: context.issue.projectId, parentIssueId: context.issue.parentId,
        assigneeAgentId: context.issue.assigneeAgentId, assigneeUserId: context.issue.assigneeUserId,
        status: context.issue.status,
      } });
      if (!decision.allowed) throw forbidden(decision.explanation);
      const interaction = await issueThreadInteractionService(tx).create(context.issue, {
        kind: "request_confirmation",
        idempotencyKey,
        sourceRunId: this.binding.runId,
        resolverPolicy: "human_only",
        title: "Review task completion proposal",
        summary,
        continuationPolicy: "wake_assignee",
        payload: {
          version: 1,
          prompt: `The Co-worker says this Task may be ready for completion review: ${summary}`,
          detailsMarkdown: "Accepting this request records a Human review response. It does not mark the Task complete. The Native finalizer must still assess the current completion contract, durable work evidence, and policy.",
          acceptLabel: "Review complete",
          rejectLabel: "Request changes",
          rejectRequiresReason: true,
          supersedeOnUserComment: true,
        },
      } as never, { agentId: this.binding.agentId, userId: null, identityContextId });
      const activity = await persistActivity(tx, {
        companyId: this.binding.companyId, actorType: "agent", actorId: this.binding.agentId,
        agentId: this.binding.agentId, runId: this.binding.runId, issueId: this.binding.issueId,
        action: "issue.completion_proposed", entityType: "issue", entityId: this.binding.issueId,
        details: { interactionId: interaction.id, interactionStatus: interaction.status,
          currentTaskStatus: context.issue.status, statusCommitted: false,
          summarySha256: nativeSha256(summary), ...this.#transportDetails() },
      });
      publication = activity.publication;
      return {
        commandId: `completion-proposal:${interaction.id}`,
        disposition: "applied",
        stateRevision: Number(context.issue.statusVersion),
        entityRefs: [context.issue.id, interaction.id],
        scheduledWakeIds: [],
        proposalStatus: "pending_human_review",
        currentTaskStatus: context.issue.status,
        taskStatusCommitted: false,
        evidenceRequirement: "The current Native finalizer must independently assess current completion evidence and policy before changing Task disposition.",
      };
    });
    if (publication) publishActivity(publication);
    return result;
  }

  async #writeDocument(input: Record<string, unknown>): Promise<unknown> {
    const idempotencyKey = requiredString(input.idempotencyKey);
    let publication: Awaited<ReturnType<typeof persistActivity>>["publication"] | null = null;
    const result = await this.#withMutationReceipt("write_document", idempotencyKey, input, async (tx) => {
      const write = await documentService(tx).upsertIssueDocument({
        issueId: this.binding.issueId,
        key: requiredString(input.key),
        title: requiredString(input.title),
        format: "markdown",
        body: requiredString(input.body),
        baseRevisionId: nullableProviderId(input.baseRevisionId),
        changeSummary: input.changeSummary === null || input.changeSummary === undefined
          ? null
          : requiredString(input.changeSummary),
        createdByAgentId: this.binding.agentId,
        createdByRunId: this.binding.runId,
        nativeModelOutputCapture: this.binding.nativeModelOutputCapture?.value ?? this.binding.awOutputCapture?.value ?? undefined,
      });
      const activity = await persistActivity(tx, {
        companyId: this.binding.companyId,
        actorType: "agent",
        actorId: this.binding.agentId,
        agentId: this.binding.agentId,
        runId: this.binding.runId,
        issueId: this.binding.issueId,
        action: write.created ? "issue.document_created" : "issue.document_updated",
        entityType: "issue",
        entityId: this.binding.issueId,
        details: {
          key: write.document.key,
          documentId: write.document.id,
          title: write.document.title,
          format: write.document.format,
          revisionNumber: write.document.latestRevisionNumber,
          ...this.#transportDetails(),
        },
      });
      publication = activity.publication;
      return {
        disposition: "applied",
        created: write.created,
        document: write.document,
      };
    });
    if (publication) publishActivity(publication);
    return result;
  }

  async #createTask(input: Record<string, unknown>, identityContextId: string | null): Promise<unknown> {
    const idempotencyKey = requiredString(input.idempotencyKey);
    if (input.status !== undefined && input.status !== "backlog" && input.status !== "todo") {
      throw new Error("paperclip_runner_tool_input_invalid");
    }
    const assigneeAgentId = input.assigneeActorId === null || input.assigneeActorId === undefined
      ? this.binding.agentId
      : requiredString(input.assigneeActorId);
    const assignee = await agentService(this.db).getById(assigneeAgentId);
    if (!assignee || assignee.companyId !== this.binding.companyId) {
      throw new Error("paperclip_runner_agent_not_found");
    }
    const priority = input.priority === "critical" || input.priority === "high"
      || input.priority === "medium" || input.priority === "low"
      ? input.priority
      : "medium";
    const blockedByIssueIds = Array.isArray(input.blockedByTaskIds)
      ? input.blockedByTaskIds.map(requiredString)
      : [];
    const durableIdempotencyKey =
      `paperclip-runner:create-task:${this.binding.issueId}:${idempotencyKey}`;
    const inputFingerprint = createHash("sha256")
      .update(canonicalJson(input))
      .digest("hex");
    let publication: Awaited<ReturnType<typeof persistActivity>>["publication"] | null = null;
    const result = await this.#withMutationReceipt("create_task", idempotencyKey, input, async (tx, context) => {
      const conversation = Boolean(context.issue.conversationAgentId);
      const existingChild = await tx.select().from(issues).where(and(
        eq(issues.companyId, this.binding.companyId),
        eq(issues.originId, durableIdempotencyKey),
      )).limit(1).then((rows) => rows[0] ?? null);
      if (existingChild) {
        if (existingChild.originFingerprint !== inputFingerprint) {
          throw new Error("paperclip_runner_tool_idempotency_conflict");
        }
        return {
          commandId: `create-task:${existingChild.id}`,
          disposition: "duplicate",
          stateRevision: existingChild.statusVersion,
          entityRefs: [existingChild.id],
          scheduledWakeIds: [],
          task: {
            id: existingChild.id,
            identifier: existingChild.identifier,
            parentId: existingChild.parentId,
            status: existingChild.status,
            assigneeActorId: existingChild.assigneeAgentId,
          },
        };
      }
      let deduplicated = false;
      const createInput = {
        projectId: nullableProviderId(input.projectId),
        initialPlan: nullableProviderId(input.initialPlan),
        title: requiredString(input.title),
        description: input.description === null || input.description === undefined
          ? null
          : requiredString(input.description),
        status: input.status === "backlog" ? "backlog" as const
          : blockedByIssueIds.length > 0 ? "blocked" as const : "todo" as const,
        workMode: "standard" as const,
        priority,
        assigneeAgentId,
        blockedByIssueIds,
        blockParentUntilDone: false,
        createdByAgentId: this.binding.agentId,
        originKind: "manual" as const,
        originId: durableIdempotencyKey,
        originRunId: this.binding.runId,
        originIdentityContextId: identityContextId,
        continuationIdentityContextId: identityContextId,
        originFingerprint: inputFingerprint,
        // Responsibility comes from the locked, current run. The model never
        // chooses the Human whose authority scopes this private work.
        responsibleUserId: context.run.responsibleUserId,
        actorResponsibleUserId: context.run.responsibleUserId,
        actorAgentId: this.binding.agentId,
        actorRunId: this.binding.runId,
        idempotencyKey: durableIdempotencyKey,
        onDeduplicated: () => { deduplicated = true; },
      };
      const nativeModelOutputCapture = this.binding.nativeModelOutputCapture?.value ?? undefined;
      const privacyActor: AuthorizationActor = {
        type: "agent", source: "agent_jwt", companyId: this.binding.companyId,
        agentId: this.binding.agentId, runId: this.binding.runId,
        onBehalfOfUserId: context.run.responsibleUserId,
      };
      let child: typeof issues.$inferSelect;
      if (context.plan) {
        const allowedDraftKeys = new Set(["idempotencyKey", "title", "description", "status"]);
        if (context.plan.issueId !== this.binding.issueId || context.plan.status !== "running" ||
            context.plan.actionClass !== "internal_draft" || context.plan.riskClass !== "C0" ||
            input.status !== "backlog" || Object.keys(input).some(key => !allowedDraftKeys.has(key)) ||
            !nativeModelOutputCapture)
          throw forbidden("Native plan Task creation requires an exact source-bound C0 backlog draft");
        // Active plans cannot create ordinary child work. The C0 lane creates
        // one standalone backlog draft, still bound to this exact native
        // output capture; issueService derives privacy and seals its source
        // prefix before commit. The database parent/active-plan guard remains
        // in force for every child-task path.
        const { actorAgentId: _actorAgentId, blockParentUntilDone: _blockParentUntilDone,
          ...standaloneDraft } = createInput;
        child = await issueService(tx).create(this.binding.companyId, standaloneDraft, tx, undefined,
          { privacyActor, nativeModelOutputCapture, nativeModelOutputToolName: "create_task" });
      } else {
        child = conversation
          ? await issueService(tx).create(this.binding.companyId, createInput, tx, undefined,
              { privacyActor, nativeModelOutputCapture, nativeModelOutputToolName: "create_task" })
          : (await issueService(tx).createChild(this.binding.issueId, createInput,
              { privacyActor, nativeModelOutputCapture, nativeModelOutputToolName: "create_task" })).issue;
      }
      if (deduplicated && child.originFingerprint !== inputFingerprint) {
        throw new Error("paperclip_runner_tool_idempotency_conflict");
      }
      let childStatus = child.status;
      let childStatusVersion = child.statusVersion;
      if (child.status === "blocked" && blockedByIssueIds.length > 0) {
        const readiness = await issueService(tx).getDependencyReadiness(child.id, tx);
        if (readiness.isDependencyReady) {
          const readyChild = await issueService(tx).update(child.id, {
            status: "todo",
            actorAgentId: this.binding.agentId,
            actorRunId: this.binding.runId,
          }, tx);
          if (readyChild) {
            childStatus = readyChild.status;
            childStatusVersion = readyChild.statusVersion;
          }
        }
      }
      if (!deduplicated) {
        const activity = await persistActivity(tx, {
          companyId: this.binding.companyId, actorType: "agent", actorId: this.binding.agentId,
          agentId: this.binding.agentId, runId: this.binding.runId, issueId: child.id,
          action: "issue.created", entityType: "issue", entityId: child.id,
          details: { identifier: child.identifier, title: child.title, parentId: child.parentId,
            assigneeAgentId: child.assigneeAgentId, status: childStatus, ...this.#transportDetails() },
        });
        publication = activity.publication;
      }
      const wakeId = `created-child:${child.id}`;
      const shouldWake = !deduplicated && childStatus === "todo" && Boolean(child.assigneeAgentId);
      return {
        commandId: `create-task:${child.id}`,
        disposition: deduplicated ? "duplicate" : "applied",
        stateRevision: childStatusVersion,
        entityRefs: [child.id],
        scheduledWakeIds: shouldWake ? [wakeId] : [],
        task: {
          id: child.id,
          identifier: child.identifier,
          parentId: child.parentId,
          projectId: child.projectId,
          status: childStatus,
          assigneeActorId: child.assigneeAgentId,
        },
      };
    }) as Record<string, unknown>;

    if (publication) publishActivity(publication);
    const task = record(result.task);
    const childId = requiredString(task.id);
    const scheduledWakeIds = Array.isArray(result.scheduledWakeIds)
      ? result.scheduledWakeIds.filter((value): value is string => typeof value === "string")
      : [];
    const assignedAgentId = typeof task.assigneeActorId === "string"
      ? task.assigneeActorId
      : null;
    if (this.binding.enqueueWakeup && assignedAgentId && scheduledWakeIds.length > 0) {
      await this.binding.enqueueWakeup(assignedAgentId, {
        source: "assignment",
        triggerDetail: "system",
        reason: "issue_assigned",
        payload: {
          issueId: childId,
          mutation: "create_child",
          parentIssueId: task.parentId ?? null,
        },
        idempotencyKey: scheduledWakeIds[0]!,
        requestedByActorType: "agent",
        requestedByActorId: this.binding.agentId,
        contextSnapshot: {
          issueId: childId,
          source: "paperclip_runner.create_task",
          parentIssueId: task.parentId ?? null,
        },
      });
    }
    return result;
  }


  async #reassignTask(input: Record<string, unknown>): Promise<unknown> {
    const key = requiredString(input.idempotencyKey);
    const taskId = requiredUuid(input.taskId);
    const assigneeAgentId = requiredUuid(input.assigneeActorId);
    const expectedOwner = input.expectedAssigneeActorId === null ? null : requiredUuid(input.expectedAssigneeActorId);
    const expectedVersion = input.expectedStatusVersion;
    const reason = requiredString(input.reason);
    if (!Number.isSafeInteger(expectedVersion) || Number(expectedVersion) < 0 || key.length > 240 || reason.length > 20_000) {
      throw new Error("paperclip_runner_tool_input_invalid");
    }
    if (taskId === this.binding.issueId) {
      throw new Error("paperclip_runner_reassignment_current_task: delegate with create_task; this tool cannot interrupt its own caller");
    }
    const durableKey = `reassign:${this.binding.issueId}:${key}`;
    const fingerprint = createHash("sha256").update(canonicalJson(input)).digest("hex");
    const priorReceipt = async (tx: Db): Promise<Record<string, unknown> | null> => {
      const [prior] = await tx.select({ details: activityLog.details }).from(activityLog).where(and(
        eq(activityLog.companyId, this.binding.companyId), eq(activityLog.action, "issue.reassigned"),
        sql`${activityLog.details}->>'reassignmentKey' = ${durableKey}`,
      )).limit(1);
      if (!prior) return null;
      if (prior.details?.inputFingerprint !== fingerprint) throw new Error("paperclip_runner_tool_idempotency_conflict");
      return record(prior.details?.receipt);
    };
    const authorize = async (tx: Db, run: typeof heartbeatRuns.$inferSelect) => {
      const [target] = await tx.select().from(issues).where(and(eq(issues.id, taskId), eq(issues.companyId, this.binding.companyId))).for("update");
      if (!target) throw new Error("paperclip_runner_task_not_found");
      const actor = { type: "agent" as const, source: "agent_jwt" as const, companyId: this.binding.companyId,
        agentId: this.binding.agentId, runId: this.binding.runId, onBehalfOfUserId: run.responsibleUserId };
      for (const action of ["issue:read", "tasks:assign"] as const) {
        const decision = await authorizationService(tx).decide({ actor, action, resource: {
          type: "issue", companyId: this.binding.companyId, issueId: taskId, projectId: target.projectId,
          parentIssueId: target.parentId, assigneeAgentId: action === "tasks:assign" ? assigneeAgentId : target.assigneeAgentId,
          assigneeUserId: action === "tasks:assign" ? null : target.assigneeUserId, status: target.status,
        } });
        if (!decision.allowed) throw forbidden(decision.explanation);
      }
      await assertAssignableAgent(tx, this.binding.companyId, assigneeAgentId, { kind: "work" });
      const [externalChat] = await tx.select({ id: chatConversations.id }).from(chatConversations).where(and(
        eq(chatConversations.companyId, this.binding.companyId), eq(chatConversations.issueId, taskId),
      )).limit(1);
      if (externalChat) throw new Error("paperclip_runner_reassignment_conversation_locked");
      return target;
    };
    const validate = (target: typeof issues.$inferSelect) => {
      if (target.conversationAgentId) throw new Error("paperclip_runner_reassignment_conversation_locked");
      if (["done", "cancelled", "in_review"].includes(target.status) || record(target.executionState).status === "pending") {
        throw new Error("paperclip_runner_reassignment_state_denied");
      }
      if (target.assigneeUserId || target.assigneeAgentId !== expectedOwner || target.statusVersion !== expectedVersion) {
        throw new Error("paperclip_runner_reassignment_conflict: refresh search_tasks before deciding again");
      }
    };
    // Stop outside row locks: the runtime needs those locks to acknowledge cancellation.
    // A second locked check below prevents any intervening ownership/version change.
    const prepared = await this.db.transaction(async (tx) => {
      const context = await this.#lockAuthorizedMutationContext(tx as unknown as Db);
      if (context.issue.workMode !== "standard") throw new Error("paperclip_runner_tool_mode_denied");
      const target = await authorize(tx as unknown as Db, context.run);
      if (await priorReceipt(tx as unknown as Db)) return null;
      validate(target);
      return target;
    });
    // Cancellation and ownership commit cannot share locks. If the second
    // phase loses its preconditions, restore runnable work to the still-current
    // prior owner. The durable wake key deduplicates retries; the state guard
    // closes races with later reassignment, completion, and manual holds.
    const restoreInterruptedWork = async (error: unknown) => {
      if (!prepared?.executionRunId || !prepared.assigneeAgentId || !this.binding.enqueueWakeup) return;
      const [stopped] = await this.db.select().from(heartbeatRuns).where(and(
        eq(heartbeatRuns.id, prepared.executionRunId), eq(heartbeatRuns.companyId, this.binding.companyId),
        eq(heartbeatRuns.agentId, prepared.assigneeAgentId), eq(heartbeatRuns.status, "cancelled"),
        eq(heartbeatRuns.errorCode, "issue_reassigned"),
      ));
      if (!stopped) return;
      const [current] = await this.db.select().from(issues).where(and(
        eq(issues.id, taskId), eq(issues.companyId, this.binding.companyId),
      ));
      if (!current || current.assigneeAgentId !== prepared.assigneeAgentId || current.assigneeUserId ||
          current.conversationAgentId || !["todo", "in_progress"].includes(current.status) ||
          record(current.executionState).status === "pending") return;
      if (current.executionRunId && current.executionRunId !== prepared.executionRunId) return;
      try {
        await this.binding.enqueueWakeup(current.assigneeAgentId, {
          source: "assignment", triggerDetail: "system", reason: "issue_assigned",
          payload: { issueId: taskId, mutation: "reassign_task_rollback", interruptedRunId: prepared.executionRunId },
          idempotencyKey: `${durableKey}:restore:${prepared.executionRunId}:${current.statusVersion}`,
          requestedByActorType: "agent", requestedByActorId: this.binding.agentId,
          contextSnapshot: { issueId: taskId, source: "paperclip_runner.reassign_task_rollback", forceFreshSession: true },
          issueStateGuard: { statuses: ["todo", "in_progress"], assigneeAgentId: current.assigneeAgentId, statusVersion: current.statusVersion },
        });
      } catch (restoreError) {
        throw new AggregateError([error, restoreError], "paperclip_runner_reassignment_restore_failed");
      }
    };
    if (prepared && prepared.assigneeAgentId && prepared.assigneeAgentId !== assigneeAgentId) {
      if (prepared.executionRunId && (!this.binding.stopTaskForReassignment || !this.binding.enqueueWakeup)) {
        throw new Error("paperclip_runner_reassignment_stop_unavailable");
      }
      try {
        await this.binding.stopTaskForReassignment?.({ companyId: this.binding.companyId, issueId: taskId,
          agentId: prepared.assigneeAgentId, runId: prepared.executionRunId });
      } catch (error) {
        await restoreInterruptedWork(error);
        throw error;
      }
    }
    let publication: Awaited<ReturnType<typeof persistActivity>>["publication"] | null = null;
    const result = await this.#withMutationReceipt("reassign_task", key, input, async (tx, context) => {
      if (context.issue.workMode !== "standard") throw new Error("paperclip_runner_tool_mode_denied");
      const target = await authorize(tx, context.run);
      const prior = await priorReceipt(tx);
      if (prior) return prior;
      validate(target);
      if (target.executionRunId && target.executionRunId !== prepared?.executionRunId) {
        throw new Error("paperclip_runner_reassignment_conflict: a new execution started; refresh before retrying");
      }
      if (target.executionRunId && target.assigneeAgentId !== assigneeAgentId) {
        const [run] = await tx.select({ status: heartbeatRuns.status }).from(heartbeatRuns).where(eq(heartbeatRuns.id, target.executionRunId));
        if (run && ["running", "queued", "scheduled_retry"].includes(run.status)) throw new Error("paperclip_runner_reassignment_stop_unconfirmed");
      }
      const changed = target.assigneeAgentId !== assigneeAgentId;
      const updated = changed ? await issueService(tx).update(taskId, {
        companyGuard: this.binding.companyId, assigneeAgentId, assigneeUserId: null,
        status: target.status === "in_progress" ? "todo" : target.status,
        statusVersion: target.statusVersion + 1, actorAgentId: this.binding.agentId, actorRunId: this.binding.runId,
      }, tx) : target;
      if (!updated) throw new Error("paperclip_runner_task_not_found");
      const receipt = {
        commandId: `reassign-task:${taskId}:${updated.statusVersion}`, disposition: changed ? "applied" : "duplicate",
        stateRevision: updated.statusVersion, entityRefs: [taskId],
        scheduledWakeIds: changed && updated.status === "todo" ? [`${durableKey}:${updated.statusVersion}`] : [],
      };
      if (changed) await issueService(tx).addComment(taskId, reason, { agentId: this.binding.agentId, runId: this.binding.runId });
      const activity = await persistActivity(tx, {
        companyId: this.binding.companyId, actorType: "agent", actorId: this.binding.agentId,
        agentId: this.binding.agentId, runId: this.binding.runId, issueId: taskId,
        action: "issue.reassigned", entityType: "issue", entityId: taskId,
        details: { ...this.#transportDetails(), reassignmentKey: durableKey, inputFingerprint: fingerprint,
          previousAssigneeAgentId: target.assigneeAgentId, assigneeAgentId, reason, changed, receipt },
      });
      publication = activity.publication;
      return receipt;
    }, { beforeReceiptReplay: async (tx, context) => { await authorize(tx, context.run); } }).catch(async (error: unknown) => {
      await restoreInterruptedWork(error);
      throw error;
    }) as {
      stateRevision: number; scheduledWakeIds: string[];
    };
    if (publication) publishActivity(publication);
    // Replay repairs a failed dispatch. The durable wake key and state/version guard
    // prevent duplicate successors and prevent waking a later, unrelated assignment.
    if (result.scheduledWakeIds.length && this.binding.enqueueWakeup) {
      await this.binding.enqueueWakeup(assigneeAgentId, {
        source: "assignment", triggerDetail: "system", reason: "issue_assigned",
        payload: { issueId: taskId, mutation: "reassign_task", reason },
        idempotencyKey: result.scheduledWakeIds[0]!, requestedByActorType: "agent", requestedByActorId: this.binding.agentId,
        contextSnapshot: { issueId: taskId, source: "paperclip_runner.reassign_task", reassignmentReason: reason },
        issueStateGuard: { statuses: ["todo"], assigneeAgentId, statusVersion: result.stateRevision },
      });
    }
    return result;
  }

  async #setDependencies(input: Record<string, unknown>): Promise<unknown> {
    const idempotencyKey = requiredString(input.idempotencyKey);
    if (!Array.isArray(input.blockedByTaskIds)) {
      throw new Error("paperclip_runner_tool_input_invalid");
    }
    const blockedByIssueIds = input.blockedByTaskIds.map(requiredString);
    return this.#withMutationReceipt("set_dependencies", idempotencyKey, input, async (tx) => {
      const updated = await issueService(tx).update(this.binding.issueId, {
        blockedByIssueIds,
        actorAgentId: this.binding.agentId,
        actorRunId: this.binding.runId,
      }, tx);
      if (!updated) throw new Error("paperclip_runner_task_not_found");
      return {
        commandId: `set-dependencies:${updated.id}:${updated.statusVersion}`,
        disposition: "applied",
        stateRevision: updated.statusVersion,
        entityRefs: [updated.id, ...blockedByIssueIds],
        scheduledWakeIds: [],
      };
    });
  }

  async #registerDeliverable(input: Record<string, unknown>): Promise<unknown> {
    const idempotencyKey = requiredString(input.idempotencyKey);
    const workspaceRoot = this.binding.workspaceRoot?.trim();
    if (!workspaceRoot) {
      throw new Error("paperclip_runner_file_handoff_workspace_unavailable");
    }
    let publication:
      Awaited<ReturnType<typeof persistActivity>>["publication"] | null = null;
    let rollbackDefinitePreCommitFailure: (() => Promise<void>) | null = null;
    const result = await this.#withMutationReceipt(
      "register_deliverable",
      idempotencyKey,
      input,
      async (tx, context) => {
        const prepared = await prepareNativeRunnerFileHandoff({
          db: tx,
          binding: {
            companyId: this.binding.companyId,
            issueId: this.binding.issueId,
            runId: this.binding.runId,
            agentId: this.binding.agentId,
            workspaceRoot,
            executionTargetKind: this.binding.executionTargetKind ?? "local",
            readRemoteWorkspaceFile: this.binding.readRemoteWorkspaceFile,
          },
          deliverable: {
            filename: typeof input.filename === "string" ? input.filename : "",
            contentType:
              typeof input.contentType === "string" ? input.contentType : "",
            byteSize:
              typeof input.byteSize === "number" ? input.byteSize : Number.NaN,
            sha256: typeof input.sha256 === "string" ? input.sha256 : "",
            contentRef:
              typeof input.contentRef === "string" ? input.contentRef : "",
            title: typeof input.title === "string" ? input.title : "",
          },
          storage: this.binding.storage,
        });
        rollbackDefinitePreCommitFailure =
          prepared.rollbackDefinitePreCommitFailure;
        if (prepared.result.disposition === "applied") {
          const activity = await persistActivity(tx, {
            companyId: this.binding.companyId,
            actorType: "agent",
            actorId: this.binding.agentId,
            agentId: this.binding.agentId,
            runId: this.binding.runId,
            issueId: this.binding.issueId,
            action: "issue.attachment_added",
            entityType: "issue",
            entityId: this.binding.issueId,
            details: {
              attachmentId: prepared.result.entityRefs[0],
              workProductId: prepared.result.entityRefs[1],
              commentId: prepared.result.entityRefs[2],
              identifier: context.issue.identifier,
              issueTitle: context.issue.title,
              ...this.#transportDetails(),
            },
          });
          publication = activity.publication;
        }
        return prepared.result;
      },
      {
        onDefinitePreCommitFailure: async () => {
          const rollback = rollbackDefinitePreCommitFailure;
          rollbackDefinitePreCommitFailure = null;
          await rollback?.();
        },
      },
    );
    if (publication) publishActivity(publication);
    return result;
  }

  async #reuseChatAttachment(input: Record<string, unknown>): Promise<unknown> {
    const idempotencyKey = requiredString(input.idempotencyKey);
    if (idempotencyKey.length > 200) {
      throw new Error("paperclip_runner_tool_input_invalid");
    }
    const sourceCommentId = requiredUuid(input.sourceCommentId);
    const attachmentId = requiredUuid(input.attachmentId);
    const title = requiredString(input.title);
    if (title.length > 500) throw new Error("paperclip_runner_tool_input_invalid");
    let source: ChatAttachmentReuseSource | null = null;
    let publication:
      Awaited<ReturnType<typeof persistActivity>>["publication"] | null = null;
    let rollbackDefinitePreCommitFailure: (() => Promise<void>) | null = null;
    const authorize = async (tx: Db, contextSnapshot: unknown) => {
      source = await authorizeChatAttachmentReuse({
        db: tx,
        binding: this.binding,
        contextSnapshot,
        sourceCommentId,
        attachmentId,
      });
    };
    const result = await this.#withMutationReceipt(
      REUSE_CHAT_ATTACHMENT_TOOL_NAME,
      idempotencyKey,
      input,
      async (tx, context) => {
        if (context.issue.workMode === "ask") {
          throw new Error("paperclip_runner_tool_mode_denied");
        }
        await authorize(tx, context.run.contextSnapshot);
        const resultJson = record(context.run.resultJson);
        for (const receipt of Object.values(record(resultJson.semanticToolReceipts))) {
          const candidate = receipt as ToolReceipt | undefined;
          if (candidate?.operationId !== REUSE_CHAT_ATTACHMENT_TOOL_NAME) continue;
          const priorInput = record(candidate.input);
          if (
            priorInput.sourceCommentId === sourceCommentId &&
            priorInput.attachmentId === attachmentId
          ) {
            return { ...record(candidate.result), disposition: "duplicate" };
          }
        }
        const prepared = await prepareReusedChatAttachment({
          db: tx,
          binding: this.binding,
          source: source!,
          title,
          storage: this.binding.storage,
        });
        rollbackDefinitePreCommitFailure =
          prepared.rollbackDefinitePreCommitFailure;
        const activity = await persistActivity(tx, {
          companyId: this.binding.companyId,
          actorType: "agent",
          actorId: this.binding.agentId,
          agentId: this.binding.agentId,
          runId: this.binding.runId,
          issueId: this.binding.issueId,
          action: "issue.attachment_added",
          entityType: "issue",
          entityId: this.binding.issueId,
          details: {
            attachmentId: prepared.result.prepared.attachmentId,
            workProductId: prepared.result.prepared.workProductId,
            commentId: prepared.result.prepared.commentId,
            identifier: context.issue.identifier,
            issueTitle: context.issue.title,
            source: "paperclip_runner_chat_attachment_reuse",
            sourceCommentId,
            sourceAttachmentId: attachmentId,
            sourceSha256: source!.sha256,
          },
        });
        publication = activity.publication;
        return prepared.result;
      },
      {
        beforeReceiptReplay: async (tx, context) => {
          if (context.issue.workMode === "ask") {
            throw new Error("paperclip_runner_tool_mode_denied");
          }
          await authorize(tx, context.run.contextSnapshot);
        },
        onDefinitePreCommitFailure: async () => {
          const rollback = rollbackDefinitePreCommitFailure;
          rollbackDefinitePreCommitFailure = null;
          await rollback?.();
        },
      },
    );
    if (publication) publishActivity(publication);
    return result;
  }

  async #acceptedPlan(contextSnapshot: unknown): Promise<{
    documentId: string;
    revisionId: string;
    revisionNumber: number;
    markdown: string;
  } | null> {
    const acceptedTarget = record(
      record(record(contextSnapshot).planReviewInteraction).acceptedTargetRevision,
    );
    let revisionId = typeof acceptedTarget.revisionId === "string"
      ? acceptedTarget.revisionId
      : null;
    if (!revisionId) revisionId = await this.#latestAcceptedPlanRevisionId();
    if (!revisionId) return null;

    const [revision] = await this.db.select({
      documentId: documentRevisions.documentId,
      revisionId: documentRevisions.id,
      revisionNumber: documentRevisions.revisionNumber,
      markdown: documentRevisions.body,
    })
      .from(documentRevisions)
      .innerJoin(issueDocuments, and(
        eq(issueDocuments.documentId, documentRevisions.documentId),
        eq(issueDocuments.companyId, this.binding.companyId),
        eq(issueDocuments.issueId, this.binding.issueId),
        eq(issueDocuments.key, "plan"),
      ))
      .where(and(
        eq(documentRevisions.id, revisionId),
        eq(documentRevisions.companyId, this.binding.companyId),
      ))
      .limit(1);
    return revision ?? null;
  }

  async #acceptedPlanInteractionId(issueId: string, revisionId: string): Promise<string | null> {
    const rows = await this.db.select({ id: issueThreadInteractions.id, payload: issueThreadInteractions.payload })
      .from(issueThreadInteractions).where(and(eq(issueThreadInteractions.companyId, this.binding.companyId),
        eq(issueThreadInteractions.issueId, issueId), eq(issueThreadInteractions.kind, "request_confirmation"),
        eq(issueThreadInteractions.status, "accepted")))
      .orderBy(desc(issueThreadInteractions.resolvedAt), desc(issueThreadInteractions.createdAt));
    for (const row of rows) {
      const target = record(record(row.payload).target);
      if (target.type === "issue_document" && target.key === "plan" && target.revisionId === revisionId &&
        (target.issueId === undefined || target.issueId === issueId)) return row.id;
    }
    return null;
  }

  async #captureNativeInteractionSource(issueId: string, interactionId: string): Promise<NativePayloadSourceInput | null> {
    const sources: NativePayloadSourceInput[] = [];
    try {
      const responses = await materializeNativeInteractionResponses({ db: this.db, companyId: this.binding.companyId,
        issueId, runId: this.binding.runId, agentId: this.binding.agentId, interactionIds: [interactionId],
        onSourceCapture: source => { sources.push(source); } });
      if (responses.length !== 1 || responses[0]?.interactionId !== interactionId || sources.length !== 1) return null;
      return sources[0] ?? null;
    } catch {
      // Preserve the original read result; unsupported interaction shapes are
      // represented as unknown source history and block later qualification.
      return null;
    }
  }

  async #latestAcceptedPlanRevisionId(): Promise<string | null> {
    const rows = await this.db.select({ payload: issueThreadInteractions.payload })
      .from(issueThreadInteractions)
      .where(and(
        eq(issueThreadInteractions.companyId, this.binding.companyId),
        eq(issueThreadInteractions.issueId, this.binding.issueId),
        eq(issueThreadInteractions.kind, "request_confirmation"),
        eq(issueThreadInteractions.status, "accepted"),
      ))
      .orderBy(desc(issueThreadInteractions.resolvedAt), desc(issueThreadInteractions.createdAt));
    for (const row of rows) {
      const target = record(record(row.payload).target);
      if (
        target.type === "issue_document"
        && (target.issueId === undefined || target.issueId === this.binding.issueId)
        && target.key === "plan"
        && typeof target.revisionId === "string"
        && target.revisionId.length > 0
      ) return target.revisionId;
    }
    return null;
  }

  async #withMutationReceipt(
    operationId: string,
    idempotencyKey: string,
    input: Record<string, unknown>,
    effect: (
      tx: Db,
      context: {
        run: typeof heartbeatRuns.$inferSelect;
        issue: typeof issues.$inferSelect;
        actor: typeof agents.$inferSelect;
        plan: typeof orchestrationPlans.$inferSelect | null;
      },
    ) => Promise<unknown>,
    options: {
      onDefinitePreCommitFailure?: () => Promise<void>;
      beforeReceiptReplay?: (
        tx: Db,
        context: {
          run: typeof heartbeatRuns.$inferSelect;
          issue: typeof issues.$inferSelect;
          actor: typeof agents.$inferSelect;
          plan: typeof orchestrationPlans.$inferSelect | null;
        },
      ) => Promise<void>;
    } = {},
  ): Promise<unknown> {
    return this.db.transaction(async (tx) => {
      try {
        const context = await this.#lockAuthorizedMutationContext(
          tx as unknown as Db,
        );
        const isFilePreparation =
          operationId === "register_deliverable" ||
          operationId === REUSE_CHAT_ATTACHMENT_TOOL_NAME;
        const snapshot = record(context.run.contextSnapshot);
        const wake = snapshot.paperclipWake;
        const normalized = normalizePaperclipWakePayload(wake);
        let provider =
          normalized?.issue?.id === this.binding.issueId &&
          isPaperclipExternalChatContractTurn(wake)
            ? normalized.externalChatProvider
            : null;
        if (
          isFilePreparation &&
          snapshot.source === "issue.interaction.respond" &&
          snapshot.paperclipExternalChatQuestionResponse
        ) {
          // Answer text is invocation-only, so the persisted wake cannot use
          // the prompt-shape question predicate. Resolve the durable answer
          // chain and current reach/principal before effects or receipt replay;
          // a marker alone never supplies the provider or new authority.
          const authorized = await authorizeChatConversationForBoundRun(
            tx as unknown as Db,
            this.binding,
            context.run.contextSnapshot,
            "nonblocking",
          );
          const [endpoint] = await tx
            .select({ provider: chatEndpoints.provider })
            .from(chatEndpoints)
            .where(
              and(
                eq(chatEndpoints.id, authorized.endpointId),
                eq(chatEndpoints.companyId, this.binding.companyId),
                eq(chatEndpoints.assignedAgentId, this.binding.agentId),
              ),
            );
          if (!endpoint || endpoint.provider === "agentmail") {
            throw new Error("paperclip_runner_chat_attachment_binding_denied");
          }
          provider = endpoint.provider;
        }
        // Describe file preparation from the locked, server-built wake, never
        // from file/tool arguments. Replays of older receipts gain the same
        // honest delivery guidance without repeating their committed effect.
        const describeResult = (result: unknown): unknown => {
          if (!isFilePreparation) return result;
          return {
            ...record(result),
            fileDelivery: paperclipChatFilePreparationDelivery(provider),
          };
        };
        const resultJson = record(context.run.resultJson);
        const receipts = record(resultJson.semanticToolReceipts);
        const prior = receipts[idempotencyKey] as ToolReceipt | undefined;
        if (prior !== undefined) {
          if (
            prior.operationId !== operationId ||
            canonicalJson(prior.input) !== canonicalJson(input)
          ) {
            throw new Error("paperclip_runner_tool_idempotency_conflict");
          }
          await options.beforeReceiptReplay?.(tx as unknown as Db, context);
          await this.#assertMutationSourceCurrent(tx as unknown as Db, context);
          return describeResult(prior.result);
        }
        const result = JSON.parse(
          JSON.stringify(
            describeResult(await effect(tx as unknown as Db, context)),
          ),
        ) as unknown;
        this.binding.authoritySignal?.throwIfAborted();
        const [currentIssue] = await tx.select().from(issues).where(and(
          eq(issues.companyId, this.binding.companyId), eq(issues.id, this.binding.issueId),
        ));
        if (!currentIssue) throw new Error("paperclip_runner_tool_binding_not_authorized");
        this.#assertConversationGeneration({ issue: currentIssue, run: context.run });
        await this.#assertMutationSourceCurrent(tx as unknown as Db, context);
        const nativeInputDispatch = resolveNativeInputDispatchReceiptIdentity(context.run.runnerProfileJson, nativeBackendToolCallIdentity.getStore(), operationId);
        receipts[idempotencyKey] = {
          operationId,
          input,
          result,
          nativeInputDispatch,
          ...(this.binding.transportCallId ? { transport: {
            channel: this.#sourceChannel(), callId: this.binding.transportCallId,
          } } : {}),
        } satisfies ToolReceipt;
        await tx
          .update(heartbeatRuns)
          .set({
            resultJson: { ...resultJson, semanticToolReceipts: receipts },
            updatedAt: new Date(),
          })
          .where(eq(heartbeatRuns.id, this.binding.runId));
        return result;
      } catch (error) {
        if (process.env.PAPERCLIP_NATIVE_ISSUE_PRIVACY_DIAGNOSTICS === "1") {
          const errorRecord = error && typeof error === "object" ? error as Record<string, unknown> : {};
          const causeRecord = errorRecord.cause && typeof errorRecord.cause === "object"
            ? errorRecord.cause as Record<string, unknown> : {};
          const message = error instanceof Error ? error.message : "";
          const code = typeof errorRecord.code === "string" && /^[a-z][a-z0-9_]{1,95}$/.test(errorRecord.code)
            ? errorRecord.code
            : /^[a-z][a-z0-9_]{1,95}$/.test(message) ? message : "unclassified_native_tool_error";
          const status = typeof errorRecord.status === "number" && Number.isInteger(errorRecord.status)
            ? errorRecord.status : typeof errorRecord.statusCode === "number" && Number.isInteger(errorRecord.statusCode)
              ? errorRecord.statusCode : null;
          const sqlState = typeof causeRecord.code === "string" && /^[0-9A-Z]{5}$/.test(causeRecord.code)
            ? causeRecord.code : null;
          const sourceFrames = error instanceof Error && typeof error.stack === "string"
            ? error.stack.split("\n").slice(1).flatMap(frame => {
              const match = /(?:^|\/)([^/]+\.ts):(\d+):(\d+)\)?$/.exec(frame.trim());
              return match ? [{ file: match[1], line: Number(match[2]), column: Number(match[3]) }] : [];
            }).slice(0, 4)
            : [];
          console.info("native-managed-mutation-failure", JSON.stringify({
            operationId,
            errorClass: error instanceof Error ? error.constructor.name : "NonError",
            code,
            status,
            sqlState,
            sourceFrames,
          }));
        }
        await options.onDefinitePreCommitFailure?.().catch(() => undefined);
        throw error;
      }
    });
  }

  #assertConversationGeneration(context: { issue: typeof issues.$inferSelect; run: typeof heartbeatRuns.$inferSelect }) {
    if (!context.issue.conversationAgentId && !context.issue.conversationRetiredAt) return;
    const generation = context.run.contextSnapshot?.conversationSessionGeneration ?? 0;
    if (context.issue.conversationRetiredAt || !Number.isSafeInteger(generation) ||
      generation !== context.issue.conversationSessionGeneration) {
      throw new Error("paperclip_runner_conversation_generation_changed");
    }
  }

  async #assertMutationSourceCurrent(tx: Db, context: { run: typeof heartbeatRuns.$inferSelect }) {
    if(context.run.id!==this.binding.runId||context.run.nativeIssueId!==this.binding.issueId)
      throw new Error("paperclip_runner_tool_binding_not_authorized");
    // Recheck the exact run and native Task as one worklist at each mutation
    // boundary. The pre-effect and post-effect calls remain separate proofs;
    // the latter gates receipt storage and the transaction commit.
    await assertNativeAnalyticalRunPayloadAccess(tx, this.binding.companyId, context.run.id);
    const actor = { type: "agent" as const, source: "agent_jwt" as const, companyId: this.binding.companyId,
      agentId: this.binding.agentId, runId: this.binding.runId, onBehalfOfUserId: context.run.responsibleUserId };
    await assertPlatformSkillAdmission(tx, actor, blenteraPlatformContractHashes());
  }

  async #lockAuthorizedMutationContext(tx: Db): Promise<{
    run: typeof heartbeatRuns.$inferSelect;
    issue: typeof issues.$inferSelect;
    actor: typeof agents.$inferSelect;
      plan: typeof orchestrationPlans.$inferSelect | null;
  }> {
    this.binding.authoritySignal?.throwIfAborted();
    // Current analytical source review must acquire its company boundary
    // before Memory; then preserve the Native plan -> Task -> run order.
    await lockAnalyticalCompany(tx, this.binding.companyId);
    await lockMemoryPrivacy(tx, this.binding.companyId);
    // Bounded plans use the same order as reservation, supervision and Stop.
    // Ordinary native runs retain their existing Task/run mutation behavior.
    const bounded = await lockNativeToolPlan(tx, this.binding);
    // Match identity activation and queue mutations before locking the run.
    await tx.select({ id: issues.id }).from(issues).where(and(
      eq(issues.id, this.binding.issueId), eq(issues.companyId, this.binding.companyId),
    )).for("update");
    // Authorization for writes is intentionally re-read only after the
    // transaction starts. Locking the run and issue in the same statement
    // closes the gap between the discovery-time check and the mutation: a
    // reassignment, replacement run, or terminal transition must commit either
    // before this check (and be rejected) or after this transaction completes.
    const [context] = await tx
      .select({ run: heartbeatRuns, issue: issues, actor: agents })
      .from(heartbeatRuns)
      .innerJoin(issues, eq(issues.id, this.binding.issueId))
      .innerJoin(agents, eq(agents.id, this.binding.agentId))
      .where(and(
        eq(heartbeatRuns.id, this.binding.runId),
        eq(heartbeatRuns.companyId, this.binding.companyId),
        eq(heartbeatRuns.agentId, this.binding.agentId),
        eq(heartbeatRuns.nativeIssueId, this.binding.issueId),
        eq(issues.companyId, this.binding.companyId),
        eq(issues.assigneeAgentId, this.binding.agentId),
        eq(issues.executionRunId, this.binding.runId),
        eq(agents.companyId, this.binding.companyId),
      ))
      .for("update")
      .limit(1);
    if (
      !context
      || context.run.runtimeMode !== "native"
      || context.run.status !== "running"
      || context.run.companyId !== this.binding.companyId
      || context.run.agentId !== this.binding.agentId
      || context.run.nativeIssueId !== this.binding.issueId
      || context.issue.companyId !== this.binding.companyId
      || context.issue.assigneeAgentId !== this.binding.agentId
      || context.issue.executionRunId !== this.binding.runId
      || context.actor.companyId !== this.binding.companyId
      || ["paused", "terminated", "pending_approval", "error"].includes(context.actor.status)
    ) {
      throw new Error("paperclip_runner_tool_binding_not_authorized");
    }
    if (this.binding.requireCurrentResponsibleUser) {
      const responsibleUserId = context.run.responsibleUserId;
      if (!responsibleUserId) throw forbidden("This operation requires the current represented Human");
      const [membership] = await tx.select({ principalId: companyMemberships.principalId })
        .from(companyMemberships).where(and(
          eq(companyMemberships.companyId, this.binding.companyId),
          eq(companyMemberships.principalType, "user"),
          eq(companyMemberships.principalId, responsibleUserId),
          eq(companyMemberships.status, "active"),
        )).limit(1).for("share", { noWait: true });
      const [erasing] = await tx.select({ id: accountDeletionOperations.id })
        .from(accountDeletionOperations).where(eq(accountDeletionOperations.userId, responsibleUserId)).limit(1);
      if (!membership || erasing) throw forbidden("The current represented Human is no longer authorized");
    }
    if (bounded) await assertNativeToolPlanCurrent(tx, this.binding, true);
    this.binding.authoritySignal?.throwIfAborted();
    this.#assertConversationGeneration(context);
    await this.#assertMutationSourceCurrent(tx, context);
    return { ...context, plan: bounded?.plan ?? null };
  }

  async #requestHumanInput(input: Record<string, unknown>, identityContextId: string | null): Promise<unknown> {
    if (input.resolverPolicy !== undefined && input.resolverPolicy !== "human_only")
      throw new Error("paperclip_runner_interaction_resolver_policy_invalid");
    const interactionKind = requiredString(input.interactionKind);
    const interactionKinds = {
      confirmation: "request_confirmation",
      checkbox: "request_checkbox_confirmation",
      questions: "ask_user_questions",
      suggest_tasks: "suggest_tasks",
      item_verdicts: "request_item_verdicts",
    } as const;
    const kind = interactionKinds[
      interactionKind as keyof typeof interactionKinds
    ];
    if (!kind) throw new Error("paperclip_runner_interaction_kind_invalid");
    const prompt = requiredString(input.prompt);
    const idempotencyKey = requiredString(input.idempotencyKey);
    let publication: Awaited<ReturnType<typeof persistActivity>>["publication"] | null = null;
    const result = await this.#withMutationReceipt(
      "request_human_input",
      idempotencyKey,
      input,
      async (tx, context) => {
        const suppliedPayload = record(input.payload);
        const targetRevisionId = nullableProviderId(input.targetRevisionId);
        const suppliedTarget = record(suppliedPayload.target);
        const inferredPlanningTarget = targetRevisionId !== null
          && suppliedPayload.target === undefined
          && kind === "request_confirmation"
          && context.issue.workMode === "planning"
          ? {
              type: "issue_document",
              issueId: context.issue.id,
              key: "plan",
              revisionId: targetRevisionId,
            }
          : null;
        if (targetRevisionId !== null && suppliedPayload.target === undefined && inferredPlanningTarget === null) {
          throw new Error('paperclip_runner_interaction_target_incomplete: targetRevisionId also requires payload.target = { type: "issue_document", key: "plan", revisionId: targetRevisionId }. Use the actual document key. If the source plan already authorized this scope, do not request approval again merely because the execution task has a new plan document.');
        }
        const normalizedPayload = inferredPlanningTarget !== null
          ? { ...suppliedPayload, target: inferredPlanningTarget }
          : suppliedTarget.type === "issue_document"
          ? {
              ...suppliedPayload,
              target: {
                ...suppliedTarget,
                issueId: suppliedTarget.issueId ?? context.issue.id,
                revisionId: suppliedTarget.revisionId ?? targetRevisionId,
              },
            }
          : suppliedPayload;
        const interaction = await issueThreadInteractionService(tx).create(context.issue, {
          kind,
          idempotencyKey,
          sourceRunId: this.binding.runId,
          ...(input.resolverPolicy === "human_only" ? { resolverPolicy: "human_only" } : {}),
          title: requiredString(input.title),
          summary: prompt,
          continuationPolicy: requiredString(input.continuationPolicy),
          payload: {
            ...normalizedPayload,
            version: 1,
            prompt,
            ...(kind === "request_confirmation" ? {
              detailsMarkdown: normalizedPayload.detailsMarkdown ?? "",
              acceptLabel: normalizedPayload.acceptLabel ?? "Confirm",
              rejectLabel: normalizedPayload.rejectLabel ?? "Request changes",
              rejectRequiresReason: normalizedPayload.rejectRequiresReason ?? false,
              supersedeOnUserComment: normalizedPayload.supersedeOnUserComment ?? true,
            } : {}),
          },
        } as never, { agentId: this.binding.agentId, userId: null, identityContextId });
        const activity = await persistActivity(tx, {
          companyId: this.binding.companyId,
          actorType: "agent",
          actorId: this.binding.agentId,
          agentId: this.binding.agentId,
          runId: this.binding.runId,
          issueId: this.binding.issueId,
          action: "issue.thread_interaction_created",
          entityType: "issue",
          entityId: this.binding.issueId,
          details: {
            interactionId: interaction.id,
            interactionKind: interaction.kind,
            interactionStatus: interaction.status,
            continuationPolicy: interaction.continuationPolicy,
            ...this.#transportDetails(),
          },
        });
        publication = activity.publication;
        return { interaction, disposition: "applied" };
      },
    );
    if (publication) publishActivity(publication);
    return result;
  }
}

function requiredString(value: unknown): string {
  if (typeof value !== "string" || value.trim() === "") throw new Error("paperclip_runner_tool_input_invalid");
  return value.trim();
}

/**
 * Some native tool transports cannot faithfully express a nullable string in
 * their provider-facing schema and send the JSON null sentinel as a string.
 * Normalize only the well-known empty/null sentinels at the control-plane
 * boundary; real revision ids remain untouched and optimistic concurrency is
 * still enforced by the document service.
 */
function nullableProviderId(value: unknown): string | null {
  if (value === null || value === undefined) return null;
  const normalized = requiredString(value);
  return normalized === "null" || normalized === "undefined" ? null : normalized;
}

function requiredUuid(value: unknown): string {
  const normalized = requiredString(value);
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/iu.test(normalized)) {
    throw new Error("paperclip_runner_tool_input_invalid");
  }
  return normalized;
}

function boundedLimit(value: unknown, fallback = 50, maximum = 100): number {
  return typeof value === "number" && Number.isInteger(value)
    ? Math.max(1, Math.min(value, maximum))
    : fallback;
}

function redactedActor(actor: {
  id: string;
  companyId: string;
  name: string;
  role: string;
  title?: string | null;
  status: string;
  reportsTo?: string | null;
  capabilities?: string | null;
}) {
  return {
    id: actor.id,
    companyId: actor.companyId,
    name: actor.name,
    role: actor.role,
    title: actor.title ?? null,
    status: actor.status,
    reportsTo: actor.reportsTo ?? null,
    capabilities: actor.capabilities ?? null,
  };
}

function redactedTask(task: typeof issues.$inferSelect) {
  return {
    id: task.id,
    url: publicChatTaskUrl(task.id),
    companyId: task.companyId,
    identifier: task.identifier,
    title: task.title,
    description: task.description,
    status: task.status,
    statusVersion: task.statusVersion,
    priority: task.priority,
    workMode: task.workMode,
    assigneeAgentId: task.assigneeAgentId,
    executionRunId: task.executionRunId,
    parentId: task.parentId,
    projectId: task.projectId,
    goalId: task.goalId,
  };
}
