#!/usr/bin/env bash
set -euo pipefail
exec flock -x /workspace/v10-preparation/v10-pg-tests.lock bash -s <<'LOCKED'
set -euo pipefail
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH GOMEMLIMIT=1536MiB GOGC=50
out=/workspace/v10-preparation/resource-governance-followup-r1-20261030/attempt-9
main=/workspace/blentera-v10
mirror=/workspace/v10-dep-qualification
mkdir -p "$out"
trap 'rc=$?; printf "%s\n" "$rc" > "$out/qualification.exit"; exit "$rc"' EXIT
python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$out/source-pins.json" > "$out/snapshot.log" 2>&1
python3 - "$main" "$mirror" "$out" <<'PY'
import pathlib,sys,json,hashlib
main,mirror,out=map(pathlib.Path,sys.argv[1:])
prior=json.loads(pathlib.Path('/workspace/v10-preparation/resource-governance-current-typecheck-r6-20261030/resource-syntax-pins.json').read_text())
volatile={
 'packages/db/src/schema/heartbeat_run_events.ts',
 'packages/db/src/schema/native_run_finalizations.ts',
 'server/src/services/authorization.ts',
 'server/src/services/heartbeat.ts',
 'server/src/services/memory/memory-privacy.ts',
 'server/src/services/workflows/workflow-native-nodes.ts',
}
paths={x['path'] for x in prior['copiedFiles']} - volatile
paths.update({'server/src/services/workflows/workflow-executor.ts','server/src/__tests__/resource-governance.integration.test.ts'})
rows=[]
for rel in sorted(paths):
 p=main/rel; q=mirror/rel
 if not p.is_file(): continue
 expected=hashlib.sha256(p.read_bytes()).hexdigest()
 assert q.is_file() and hashlib.sha256(q.read_bytes()).hexdigest()==expected,('current mirror differs from source pin',rel)
 rows.append({'path':rel,'sha256':expected})
(out/'resource-source-before.json').write_text(json.dumps(rows,indent=2)+'\n')
pins=json.loads((out/'source-pins.json').read_text())
pins['copiedFiles']=[{'path':x['path']} for x in rows]
(out/'resource-syntax-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
PY
node /workspace/v10-preparation/check-snapshot-syntax.cjs "$out/resource-syntax-pins.json" > "$out/syntax.log" 2>&1
cd "$mirror"
pnpm exec vitest run server/src/__tests__/resource-governance.integration.test.ts --reporter=verbose > "$out/resource-pg-test.log" 2>&1
python3 - "$main" "$mirror" "$out" <<'PY'
import pathlib,sys,json,hashlib
main,mirror,out=map(pathlib.Path,sys.argv[1:])
for row in json.loads((out/'resource-source-before.json').read_text()):
 rel=row['path']; expected=row['sha256']
 for root in (main,mirror):
  p=root/rel
  assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==expected,('source changed during test',str(root),rel)
PY
trap - EXIT
printf '0\n' > "$out/qualification.exit"
LOCKED
