#!/usr/bin/env bash
set -euo pipefail

bundle_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
target="${1:?usage: apply-patch.sh PATH_TO_CLEAN_OPENSHELL_CHECKOUT}"
expected_commit="6648bd0c290efbc41ba131ee9831ee45cd431f94"
expected_patch_sha="a273518c9db62db6593c9674207617b6a6654af84013b6827e8306a150f16d4b"
patch_file="$bundle_dir/openshell-rt01-expected-id.patch"

actual_commit="$(git -C "$target" rev-parse HEAD)"
if [[ "$actual_commit" != "$expected_commit" ]]; then
  echo "refusing patch: expected OpenShell $expected_commit, got $actual_commit" >&2
  exit 65
fi
if [[ -n "$(git -C "$target" status --porcelain)" ]]; then
  echo "refusing patch: target checkout must be clean" >&2
  exit 65
fi
actual_patch_sha="$(sha256sum "$patch_file" | awk '{print $1}')"
if [[ "$actual_patch_sha" != "$expected_patch_sha" ]]; then
  echo "refusing patch: patch SHA256 mismatch" >&2
  exit 65
fi
git -C "$target" apply --check "$patch_file"
git -C "$target" apply "$patch_file"
printf 'Applied private RT-01 patch to %s at %s\n' "$target" "$expected_commit"
