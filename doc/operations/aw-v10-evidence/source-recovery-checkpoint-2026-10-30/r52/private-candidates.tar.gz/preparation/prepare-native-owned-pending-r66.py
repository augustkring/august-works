from pathlib import Path
import hashlib,json,difflib
r=Path('/workspace/blentera-v10');p=Path('/workspace/v10-preparation/native-pending-task-r66-candidate');rel='server/src/services/native-direct-input.ts';old=(r/rel).read_text();s=old
s=s.replace('  pending?: NativePendingTaskRead;\n}', '  pending?: NativePendingTaskRead;\n  descendants?: Set<string>;\n}',1)
needle='''        if (scope.active.has(visitKey)) throw forbidden("The Native scoped Task source graph contains a cycle");
        addNativeSourceActiveVisit(scope, visitKey);
'''
addition='''        if (scope.active.has(visitKey)) throw forbidden("The Native scoped Task source graph contains a cycle");
        const owned = scope.context.scopedTaskReads.get(visitKey);
        if (owned?.pending && owned.descendants && owned.mutableSources.compatible &&
          owned.pending.owner === scope.context.ancestry.pendingTaskOwner &&
          current === scope.context && current.active && current.db === (db as object) &&
          current.privacyLockedCompanies.has(companyId) && !current.flushingReaders &&
          !current.ancestry.graphProofsDisabled && !nativeSourceEffectBarrierActive(current) &&
          !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, owned.descendants) &&
          await nativeFrozenMutableSourcesCurrent(db as Db, companyId, owned.mutableSources, scope) &&
          await nativeSourceReaderHasCompanyAccess(db, companyId, actor)) {
          // The SAME parent still owns this unchecked Task continuation. Its
          // pending reader checks remain queued; this skips only a duplicate
          // structural walk after the fresh exact Task owner checks above.
          nativeSourceReadWork(scope, "ownedPendingTask:1");
          recordNativeProofReaderSetUse(scope, undefined);
          propagateNativeMutableSources(scope, owned.mutableSources);
          for (const frame of scope.context.ancestry.frozenTaskProofStacks.get(scope.actorKey) ?? [])
            addNativeFrozenTaskDescendantClosure(frame.descendants, visitKey, owned.descendants);
          deferNativeScopedTaskRead(scope, owned);
          const ownPin = { contentHash: snapshot.data.owner.contentHash, snapshotDigest: snapshot.data.digest };
          const previous = scope.taskTemporalScopes.get(issueId);
          if (previous && !isDeepStrictEqual(previous, ownPin)) throw forbidden("The Native Task owner scope changed");
          scope.taskTemporalScopes.set(issueId, ownPin);
          deferNativeSourceOwnerReaderChecks(scope, { companyId, actor, issueIds: [issueId] });
          return snapshot.data.digest;
        }
        const descendants = new Set<string>();
        descriptor.descendants = descendants;
        addNativeSourceActiveVisit(scope, visitKey);
'''
assert s.count(needle)==1;s=s.replace(needle,addition,1)
needle='            const frame: NativeSourceProofFrame = { visitKey, descendants: new Set(), mutableSources };'
assert s.count(needle)==1;s=s.replace(needle,'            const frame: NativeSourceProofFrame = { visitKey, descendants, mutableSources };',1)
f=p/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s);(p/'owned-pending-task.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)));m=json.loads((p/'manifest.json').read_text());m[rel]={'priorSha256':hashlib.sha256(old.encode()).hexdigest(),'candidateSha256':hashlib.sha256(s.encode()).hexdigest()};(p/'manifest.json').write_text(json.dumps(m,indent=2));print((p/'owned-pending-task.diff').read_text())
