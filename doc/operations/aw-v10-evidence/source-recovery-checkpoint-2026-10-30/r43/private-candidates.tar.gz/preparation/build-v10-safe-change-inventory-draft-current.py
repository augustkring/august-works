import json, subprocess, hashlib, os, re, collections
ROOT='/workspace/blentera-v10'
BASE='81d3445b98b1cd80ff400ede6bd44ea71d88d735'
REG_PATH='doc/operations/aw-v10-evidence/recovery-2026-10-22/requirement-reconciliation.json'
HOT_PATH='doc/operations/production-hotspot-responsibilities.json'
BRIEF_PATH='doc/reference/blentera-v10/Blentera_Master_Build_Brief_V10_FINAL_v4.0_2026-10-18.md'
reg=json.load(open(os.path.join(ROOT,REG_PATH)))
hotdoc=json.load(open(os.path.join(ROOT,HOT_PATH)))
items=reg['items']; hot=hotdoc['hotspots']
tracked_changed=set(subprocess.check_output(['git','diff','--name-only',BASE],cwd=ROOT,text=True).splitlines())
untracked=set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines())
source_ext={'.ts','.tsx','.js','.mjs','.sql','.yml','.yaml','.json','.sh','.rs','.toml','.py','.css','.html','.svg'}
def relevant(p):
 ext=os.path.splitext(p)[1]
 if p=='Dockerfile': return True
 if '/' not in p: return ext in source_ext
 if p.startswith('patches/'): return ext=='.patch'
 if p.startswith(('skills/','skills-releases/','evals/')): return ext in source_ext or ext=='.md'
 if ext=='.md':
  return p.startswith(('server/src/onboarding-assets/','server/src/built-ins/agents/','packages/teams-catalog/')) or (p.startswith('packages/adapters/') and '/skills/' in p)
 return p.startswith(('server/src/','ui/src/','ui/public/','packages/','cli/src/','tests/e2e/','scripts/','.github/workflows/')) and ext in source_ext or p=='ui/index.html'
# Requirement references are treated as owner/source links only. Their existence
# does not upgrade the requirement's reconciliation or acceptance state.
def walk_paths(x, context=None):
 if isinstance(x,dict):
  for k,v in x.items():
   if k=='sourcePath' and isinstance(v,str):
    path=v.split('#',1)[0]
    if path and not path.startswith('/') and '://' not in path and not any(ch.isspace() for ch in path):
     yield path
   elif k=='sourceOwners' and isinstance(v,list):
    for path in v:
     if isinstance(path,str) and path and not path.startswith('/') and '://' not in path and not any(ch.isspace() for ch in path):
      yield path.split('#',1)[0]
   if k=='scopedEvidence':
    if isinstance(v,list):
     for evidence in v:
      if isinstance(evidence,dict):
       paths=evidence.get('paths')
       if isinstance(paths,list):
        for path in paths:
         if isinstance(path,str) and path and not path.startswith('/') and '://' not in path and not any(ch.isspace() for ch in path):
          yield path.split('#',1)[0]
      yield from walk_paths(evidence)
   else:
    yield from walk_paths(v)
 elif isinstance(x,list):
  for v in x: yield from walk_paths(v)
all_refs={row['id']:set(walk_paths(row)) for row in items}
all_changed=tracked_changed | {p for p in untracked if relevant(p)}
material={p for p in all_changed if relevant(p)}
deleted_paths={p for p in tracked_changed if relevant(p) and not os.path.isfile(os.path.join(ROOT,p))}
# Explicit current V10 candidate files added after the register snapshot by active
# V10 source owners; no source-before hash is made up when absent at base.
monitor_candidates={
 'packages/db/src/migrations/0563_wise_yellow_claw.sql',
 'packages/db/src/migrations/meta/0563_snapshot.json',
 'packages/db/src/schema/agent_model_migration_monitor_receipts.ts',
 'packages/shared/src/agent-model-migration-monitoring.ts',
 'packages/shared/src/agent-model-migration-monitoring.test.ts',
 'server/src/services/agents/authoring-model-migration-monitor.ts',
}
candidates=material | {p for p in untracked if relevant(p)} | {p for p in monitor_candidates if os.path.isfile(os.path.join(ROOT,p))}
def git_before_pin(p):
 proc=subprocess.run(['git','show',f'{BASE}:{p}'],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
 if proc.returncode==0:
  return {'path':p,'baseCommitSha':BASE,'status':'present_at_base','sha256':hashlib.sha256(proc.stdout).hexdigest()}
 return {'path':p,'baseCommitSha':BASE,'status':'absent_at_base','sha256':None}
def refs_for(paths): return [row for row in items if all_refs[row['id']] & paths]
def requirement_ids(paths): return sorted({row['id'] for row in refs_for(paths)})
def summarize_requirement(row):
 return {'workId':row['id'],'bindingClause':row.get('currentAssessment',{}).get('bindingClause',row.get('work')),'reconciliationStatus':row.get('reconciliation'),'implementationStatus':row.get('currentAssessment',{}).get('implementationStatus'),'implementationFinding':row.get('currentAssessment',{}).get('implementationFinding'),'remainingWork':row.get('currentAssessment',{}).get('remainingWork')}

def common_record(change_id,label,owner,paths,ids,kind,source_before_pins,dependency_paths=None, tests=None, owner_source_pin=None):
 paths=sorted(paths)
 return {
  'changeId':change_id,
  'recordKind':kind,
  'domainGroup':label,
  'canonicalOwner':owner,
  'ownerDisposition':'domain source boundary identified; accountable maintainer is not inferred',
  'accountableHuman':None,
  'accountableHumanDisposition':'unknown; production hotspot inventory declares no maintainer assignment',
  'requirements':ids,
  'requirementInterpretation':'Source path linkage only. Reconciliation statuses and original acceptance conditions remain as recorded; a linked path is not requirement closure.',
  'state':'source_delta_present_review_open' if any(p in tracked_changed or p in untracked for p in paths) else 'no_delta_at_pinned_base; owner_anchor_only',
  'sourceBeforePins':source_before_pins,
  'sourcePaths':[p for p in paths if os.path.isfile(os.path.join(ROOT,p))],
  'deletedSourcePaths':[p for p in paths if p in deleted_paths],
  'changedSourcePaths':[p for p in paths if p in tracked_changed or p in untracked],
  'dependencyPaths':sorted(set(dependency_paths or [])),
  'characterizationTests':sorted(set(tests or [])),
  'currentWriter':'unknown; this inventory identifies code owner paths but does not establish every runtime writer or external writer',
  'durableState':'unknown unless explicitly stated in a linked source/test/evidence record; not inferred from directory names',
  'recovery':'unknown until linked owner recovery path and exact current source/test receipt are reviewed',
  'compatibility':'unknown; no old/new deployment compatibility claim is inferred',
  'rollback':'unknown; no reversible rollback or destructive reversal is claimed',
  'irreversibleBoundaries':{'status':'unknown_pending_owner_review','items':[]},
  'dependencies':'Only direct callers and migration journal ordering listed in dependencyPaths are sourced from existing registers; other runtime/provider dependencies remain unreviewed.',
  'humanApproval':'unknown; repository source presence is not Human approval',
  'externalQualification':'unknown or unavailable unless a linked current exact-source receipt states otherwise',
  'sourceReviewBoundary':'Candidate source inventory derived from branch diff and V10 register paths. It is not a behavior audit, test receipt, phase approval, or release claim.',
  **({'hotspotSourcePin':owner_source_pin} if owner_source_pin else {})
 }

records=[]; claimed=set()
for n,h in enumerate(hot,1):
 anchor=h['path']
 # Existing 25-hotspot boundaries; only actual branch deltas and linked requirement paths are included.
 exact_ids={rid for rid,paths in ((r['id'],set(r.get('currentAssessment',{}).get('sourceOwners',[]))) for r in items) if anchor in paths}
 paths=({anchor}|set(h.get('directImportCallers',[]))|set(h.get('directImportTests',[]))) & candidates
 for rid in exact_ids: paths |= (all_refs[rid] & candidates)
 if os.path.isfile(os.path.join(ROOT,anchor)): paths.add(anchor)
 path_ids=requirement_ids(paths)
 relevant_tests={p for p in paths if re.search(r'(?:\.test\.|\.spec\.)',p)}
 relevant_calls={p for p in set(h.get('directImportCallers',[])) & paths}
 records.append(common_record(
  f'SCR-V10-HOTSPOT-{n:02d}', h['domainResponsibility'], anchor, paths,
  path_ids,'production_hotspot_owner_group',
  [git_before_pin(p) for p in sorted(paths)],relevant_calls,relevant_tests,
  {'registerPath':HOT_PATH,'registeredSha256':h.get('sourceSha256'),'currentAnchorSha256':hashlib.sha256(open(os.path.join(ROOT,anchor),'rb').read()).hexdigest() if os.path.isfile(os.path.join(ROOT,anchor)) else None}
 ))
 claimed |= paths

left=candidates-claimed
rules=[
 ('crosscut_auth_identity',lambda p:any(x in p.lower() for x in ('auth','sso','mfa','passkey','password','invite','account-deletion','offboarding','invitations')) or p.startswith('cli/src/client/board-auth')),
 ('crosscut_private_data_erasure',lambda p:any(x in p.lower() for x in ('memory','context/','privacy','erasure','purge','quarantine','redact','source-binding','private-payload'))),
 ('crosscut_project_repository_source',lambda p:any(x in p.lower() for x in ('project','repository','git-workspace','workspace-restoration','native-project'))),
 ('crosscut_model_provider_and_migration_monitor',lambda p:any(x in p.lower() for x in ('model','provider-profile','agent_model_migration','0563_wise_yellow_claw'))),
 ('crosscut_database_schema_and_migrations',lambda p:(p.startswith('packages/db/') or p.startswith('packages/shared/src/customer-operations')) and '0554_company_import_fenced_effects.sql' not in p),
 ('crosscut_api_contracts',lambda p:any(x in p.lower() for x in ('openapi','api-path','/api/','docs/api/','route-contract'))),
 ('crosscut_support_status_trust_notices',lambda p:any(x in p.lower() for x in ('support','service-health','trust','notice','announcement','product-notice','notifications'))),
 ('crosscut_connector_provider_lifecycle',lambda p:any(x in p.lower() for x in ('connector','adapter','tool-connection','openclaw','hermes','mcp-server'))),
 ('crosscut_native_runtime_and_authority',lambda p:any(x in p.lower() for x in ('native-runtime','runtime','execution','runner','tool-authority','agent-runtime'))),
 ('crosscut_workflows_durable_operations',lambda p:any(x in p.lower() for x in ('workflow','scheduled-work','customer-operation','operation-recovery','heartbeat','routine'))),
 ('crosscut_skills_and_publication',lambda p:any(x in p.lower() for x in ('skill','authoring','publication','agent-package'))),
 ('crosscut_cost_resource_accounting',lambda p:any(x in p.lower() for x in ('cost','budget','resource','billing','reservation'))),
 ('crosscut_analytics_learning',lambda p:any(x in p.lower() for x in ('learning','analytical','decision','forecast','experiment','metric'))),
 ('crosscut_telemetry_audit_security',lambda p:any(x in p.lower() for x in ('telemetry','audit','redaction','security','agent-auth'))),
 ('crosscut_onboarding_first_value',lambda p:any(x in p.lower() for x in ('onboarding','activation','first-value','welcome','invite'))),
 ('crosscut_product_identity_help_language',lambda p:any(x in p.lower() for x in ('product-identity','help','search','i18n','locale','brand','language','docs/cli'))),
 ('crosscut_ci_release_and_catalog_governance',lambda p:p.startswith(('.github/','scripts/')) or '/' not in p),
 ('crosscut_cli_compatibility_and_commands',lambda p:p.startswith('cli/')),
 ('crosscut_durable_company_operations',lambda p:any(x in p.lower() for x in ('company-import','customer-operation'))),
 ('crosscut_customer_feedback_and_sharing',lambda p:any(x in p.lower() for x in ('feedback','sharing'))),
 ('crosscut_core_server_contracts',lambda p:p in ('server/src/config.ts','server/src/errors.ts','server/src/realtime/live-events-ws.ts')),
 ('crosscut_shared_contracts',lambda p:p.startswith(('packages/shared/','packages/adapter-utils/'))),
 ('crosscut_customer_experience',lambda p:p.startswith(('ui/','tests/e2e/'))),
 ('crosscut_unclassified_registered_owner',lambda p:True),
]
# 0554 has a reviewed, source-tested phase record; preserve it rather than hiding it in the unresolved-owner bucket.
legacy_manifest=json.load(open(os.path.join(ROOT,'doc/operations/v10-safe-change-graph.source.json')))
company_import_record=next(record for record in legacy_manifest['changes'] if record.get('changeId') == 'SCR-V10-0554-company-import-lease-budget')
company_import_record.update({
 'recordKind':'migration_phase_safe_change_record',
 'domainGroup':'company import 0554 migration and current recovery owner',
 'sourceBeforePins':[git_before_pin(p) for p in company_import_record['sourcePaths']],
 'deletedSourcePaths':[],
 'changedSourcePaths':[p for p in company_import_record['sourcePaths'] if p in tracked_changed or p in untracked],
 'sourceReviewBoundary':'Scoped source change and embedded-Postgres test receipt only; production population, lock profile, release owner and mixed-version window remain open.'
})
records.append(company_import_record)
claimed |= set(company_import_record['sourcePaths'])
left.discard('packages/db/src/migrations/0554_company_import_fenced_effects.sql')
extras=collections.defaultdict(set)
for p in sorted(left):
 for label,match in rules:
  if match(p): extras[label].add(p);break
for label,paths in extras.items():
 ids=requirement_ids(paths)
 group_files=sorted(paths)
 # The 0563 monitor candidate relates to V10-074/078 source only where the register has an exact link; do not guess additional requirement IDs.
 records.append(common_record(
  'SCR-V10-'+label.upper().replace('CROSSCUT_','').replace('_','-'),
  label,label,paths,ids,'cross_cutting_owner_group',
  [git_before_pin(p) for p in group_files],[],[p for p in group_files if re.search(r'(?:\.test\.|\.spec\.)',p)]
 ))
 claimed |= paths

# All 169 requirement rows are cross-referenced without upgrading their current status.
requirement_crosswalk=[]
for row in items:
 refs=all_refs[row['id']]
 linked=sorted({record['changeId'] for record in records if refs & set(record['sourcePaths'])})
 changed_refs=sorted(refs & candidates)
 requirement_crosswalk.append({
  **summarize_requirement(row),
  'changedReferencedPaths':changed_refs,
  'safeChangeIds':linked,
  'sourceDeltaStatus':'one_or_more_registered_source_paths_changed' if changed_refs else 'no_registered_changed_source_path_identified',
  'acceptanceStatus':'unchanged_from_requirement_reconciliation_register'
 })
# Inputs are pinned later by the repo generator to current source hashes.
source_inputs=[
 {'path':BRIEF_PATH,'role':'binding V10 brief and 169-item catalogue'},
 {'path':REG_PATH,'role':'current per-item reconciliation and owner/source links'},
 {'path':HOT_PATH,'role':'canonical 25 production hotspot ownership boundaries and direct caller/test inventory'},
]
# Delta inventory completeness: current tracked plus untracked source candidates referenced by the register.
manifest={
 'schemaVersion':2,
 'requirement':'V10-004',
 'scope':'Candidate inventory of material source paths changed from full master base 81d3445b98b1cd80ff400ede6bd44ea71d88d735 and explicitly present new V10 source candidates. Grouped by the existing 25 production hotspot owners plus cross-cutting source owner families. This is not evidence that every V10 requirement is implemented, tested, compatible, reversible, Human-approved, or release-qualified.',
 'sourceBase':{'commitSha':BASE,'identity':'full master base supplied by current build task'},
 'sourceInputs':source_inputs,
 'sourceInventoryBoundary':{'sourceDeltaPathCount':len(material),'deletedSourcePathCount':len(deleted_paths),'untrackedSourceCandidateCount':len({p for p in untracked if relevant(p)}),'ownerGroupCount':len(records),'hotspotRegisterCount':len(hot),'requirementCrosswalkCount':len(requirement_crosswalk),'fullDiffPathCount':len(tracked_changed),'note':'This graph inventories every changed source/test/config/SQL file in the current branch diff plus untracked current source candidates; it excludes non-source documentation/evidence/archive files. Requirement links are exact path matches against the 169-item register and may be empty. It does not claim every changed file is a V10 feature or that every branch diff line has been behavior-reviewed.'},
 'requirementsCrosswalk':requirement_crosswalk,
 'changes':records,
 'sourceAfterGeneration':'deferred_until_candidate_source_freeze'
}
out='/workspace/v10-preparation/v10-safe-change-source-inventory-draft-current.json'
json.dump(manifest,open(out,'w'),indent=2); open(out,'a').write('\n')
print(json.dumps({'output':out,'hotspots':len(hot),'groups':len(records),'sourceDeltaPaths':len(material),'deletedSourcePaths':len(deleted_paths),'candidatePaths':len(candidates),'crosswalk':len(requirement_crosswalk),'assignedPaths':len(claimed),'unassigned':len(candidates-claimed),'groupCounts':{r['changeId']:len(r['sourcePaths']) for r in records}},indent=2))
