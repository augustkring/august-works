# Private Resource 0565 proposal: responsibility continuity scan metadata

**Status: proposal only; no migration or main-tree schema change.** Sequence after Resource 0564. Root review is required before implementing durable storage. This note exists because the current read-only Experience poll cannot scan all §17 native domains with bounded queries and complete current source visibility.

## Existing-owner review

- `human_workflow_coverages` is semantically limited to temporary Human-to-Human `workflows:run` coverage for one exact workflow revision and optional Task. It is not generic ownership, does not cover other action classes, and cannot be reused as the inventory or scanner cursor.
- `memory_jobs` owns Memory operations and queue execution/result state. `plugin_jobs` owns plugin operations. `process_analysis_runs`/`process_findings` own process-analysis findings. None are generic responsibility scans; using them would blur their lifecycle/security contracts.
- Experience is currently deterministic, read-only and uncached. There is no existing periodic cross-domain responsibility scan state.

## Proposed architecture

Keep all native resource rows and owner fields as the sources of truth. Add only an ephemeral scan cursor and non-authoritative finding pointers. Domain services supply bounded pages in stable key order and the current source version. No resource is assigned, paused, transferred, or granted authority by the scanner.

An internal scan runs a bounded page per source kind, then persists its cursor and pointer findings. An Experience read resolves current candidates through their owning native service using the caller’s real actor. The service must apply the exact current read policy before returning a visible candidate. It then rechecks source version/status, membership and source-specific owner authority. A missing, stale, revoked or unreadable candidate contributes no card, count, kind, ID, owner, `hasMore`, overflow signal or existence indicator to that caller. The fallback remains the read-time result of `resolveCurrentDefaultResponsibleHuman`, independently checked against the same native permission/source authority. No actor/session is forged for candidate owners.

A scanner page that hits its row/page budget resumes from its durable cursor in a later invocation. The raw cursor, raw row count, `hasMore`, overflow and scan completeness never appear in Experience. The public projection always labels results as the caller’s authorized subset; it resolves current candidates through native `get`/access owners and omits stale, missing or unreadable pointers completely. It does not emit raw-overflow or cache-progress coverage.

## Private schema sketch (not executable migration)

Proposed scan metadata row:

```text
responsibility_scan_runs
  id uuid primary key
  company_id uuid not null
  contract_version integer not null
  status enum queued | running | complete | failed | abandoned
  cursor_json jsonb not null default {}        -- per-kind stable source cursor only
  requested_at / next_attempt_at timestamptz
  lease_owner text nullable
  lease_token uuid nullable
  lease_expires_at timestamptz nullable
  attempt_count integer not null default 0
  last_error_code text nullable               -- sanitized code only
  started_at / completed_at timestamptz nullable
  expires_at timestamptz not null             -- renewable cursor TTL
  created_at / updated_at timestamptz
```

Proposed candidate-pointer row:

```text
responsibility_scan_candidates
  id uuid primary key
  company_id uuid not null
  scan_run_id uuid not null references responsibility_scan_runs on delete cascade
  resource_kind text not null                 -- allowlisted §17 class
  resource_id text not null                   -- native key only
  source_version text not null                -- native version/hash only
  observed_at timestamptz not null
  expires_at timestamptz not null
  unique(scan_run_id, resource_kind, resource_id)
```

No classification field is stored. Recompute MUST_REASSIGN / CAN_FALL_BACK_TO_AUTHORIZED_GROUP / CAN_BE_UNOWNED_TEMPORARILY only after the caller’s current native `get`, source authorization, owner membership and domain permission checks.

There is deliberately no `owner_user_id`, default owner, member list, credential subject/pointer, title/body, payload, classification, copied permission, transfer target, or authority bit in either table. `MUST_REVOKE` is not stored as a scan candidate: credentials and personal grants stay in the immediate native revocation/offboarding path. Candidate pointers expire after 30 minutes and are discarded or suppressed when a fresh native source version no longer matches. Access to these internal rows is restricted to the scan worker and Experience service; callers never receive these rows directly. Storage is not a replacement owner registry and cannot be queried as authoritative inventory without fresh native source checks.

The scan worker uses bounded `FOR UPDATE SKIP LOCKED` claims over scan-run rows and persists progress after each successful page. Each native adapter owns the metadata query, stable cursor, status filter, source revision, and page size. A failed adapter leaves its cursor unchanged, records a sanitized error code, and never deletes or edits the source resource. Transient failures receive bounded backoff/retry; permanent failures become `abandoned` and wait for the next periodic scan rather than retry forever. Every lease renewal, progress write and completion uses an exact `(id, lease_owner, lease_token, lease_expires_at > now())` compare-and-set. The whole scan is safe to repeat. A unique partial index on active company runs prevents concurrent claims.

Operational defaults approved by Root for this proposal are local engineering budgets, not external SLAs: start one scan per company every 5 minutes; request at most 40 metadata candidates per kind/page; allow one leased job per company with a 30-second lease; expire candidate pointers after 30 minutes; expire idle cursors after 24 hours and renew their TTL only after durable page progress. Use the existing background-maintenance scheduler and fair-company claim path. An expired cursor starts a fresh deterministic scan. A scan can span many periodic invocations; pointers from an older completed scan remain usable only while their source-version recheck succeeds and their TTL remains fresh.

## Per-domain implementation seams still required

| Kind | Native page API needed | Source check at projection read | Classification / notes |
|---|---|---|---|
| Agent | Agent service bounded active-company page; board `agent:read` visibility is company membership based. | Current agent read + configure source authority. | `CAN_BE_UNOWNED_TEMPORARILY` only where existing agent lifecycle allows it; no Human owner inferred from `reportsTo`.
| Package deployment | Package installation service page joined to active target Agent and linked AI Use Case. | Target Agent read + installation and AI governance checks. | Linked AI Use Case owner, never installer.
| Workflow | Workflow service cursor page that applies complete `assertWorkflowAuthoringSources` checks before limit. | Current workflow read/edit and full authoring-source checks. | Default is only effective owner candidate; creator is provenance.
| Workflow run | Workflow execution service page with active status and complete `assertWorkflowRunAuthoringSources`. | Current run and linked workflow source reads. | `workflowRuns.responsibleUserId` is per-run owner.
| Routine | Routine service cursor page that applies full `assertRoutineSourceAccess` before limit. | Current routine read and source checks. | `routines.responsibleUserId`; private drafts require full source validation before any derived signal.
| Connector | Connection service page applying `assertToolConnectionAccess` and application visibility before limit. | Current application and connection authority; check app Human/Agent owner separately from credential subjects. | `MUST_REVOKE` for personal grants remains a separate immediate native operation.
| Metric | Metric service cursor page that applies `inspectPublishedDefinition` and population/project checks before limit. | Current metric detail + definition source. | Creator is provenance only.
| Experiment | Experiment service authorized cursor page whose cursor advances across raw rows without returning raw overflow. | Current experiment version/source and route authorization. | Creator is provenance only.
| Decision | Decision queue page joined to canonical `visibleIssueCondition()` before limit. | `decision_queue:read` and current linked `issue:read`. | Linked `issues.responsibleUserId`, not assignee/decider.
| Approval | Approval service page applying issue visibility and current admitted-responder policy before limit. | Current approval and linked issue read. | Existing admitted responders only; no autoapprover.
| AI Use Case | Governance service current source page with stable cursor (not current `LIMIT 100`). | Current `aiGovernanceService.get`/owner permission. | `aiUseCases.ownerUserId`; deployment owner follows linked Use Case.
| Policy | Tool/skill policy service page under exact `tools:manage_profiles` / `skill_config:update` boundaries. | Same native policy action. | Company-scope policy does not become an individual owner.
| Billing | Billing service page joined through active `billingAccountCompanies`. | Current billing view/manage and payer membership. | `payerUserId` joined through company.
| Security contact | No tenant security case table/reader identified. | Optional canonical `companies.security_contact_user_id` contact setting. | Contact label requires active verified same-company Human membership and gives no permissions; platform incidents remain platform-owned.
| Support/incident contact | No canonical tenant contact field identified. | Optional `companies.support_incident_contact_user_id`; separately inventory current support cases through the tenant customer getter. | Tenant contact is not an assigned responder. Platform Support continuity uses only its configured operator group, with fresh assurance/effect permission at use.
| Support/incident | Support operator-owned page distinct from private customer case storage. | Existing support responder/operator authority; private case read per case. | Opener is requester, never responder. Tenant follow-up stays separate.

## §17.4–17.7 continuity behavior

- The offboarding/access owner continues to revoke membership, sessions, keys, personal connection grants and support access first. It records a scan request only after the native revocation transaction; failure or backlog cannot roll revocation back.
- Classification follows existing domain safe-state rules: `MUST_REASSIGN` for material accountable work, `CAN_FALL_BACK_TO_AUTHORIZED_GROUP` only where an explicit native responder/group policy exists, `CAN_BE_UNOWNED_TEMPORARILY` only where the domain already permits it, and `MUST_REVOKE` for personal credentials/grants through their existing synchronous native owners; these do not enter the scanner. The projection performs none of these actions.
- No generic temporary delegation table. Existing `human_workflow_coverages` remains scoped to `workflows:run`; other temporary action coverage requires a domain-owned bounded policy and cannot copy broad grants.
- Approval escalation follows an existing due window and currently admitted responder group, then the policy-authorized admin/operator audience. Do not invent a due period or repeat notification schedule when no native deadline/policy exists. Until such a policy exists, surface one generic current-authorized action and allow the native approval owner to decide.
- The 5-minute period and 30-minute/24-hour expiries above are local queue/cache budgets approved for implementation. They do not establish a customer promise or notification SLA. No automatic pause, reassignment, or notification is added.

## Review gate

Root approved the short-lived pointer-cache architecture and the local scan/lease/TTL defaults above. Still required before main publication: complete native metadata adapters and real current-owner `get`/authorization readers for every applicable §17 class; migration generated from an isolated 0565 overlay after Resource 0564 is serialized; scheduler registration with existing fair-company claims; lifecycle cleanup; and the required pagination, lease/race, expiry, private-zero, revocation and classification PostgreSQL tests. This directory remains private; no main migration journal or main schema has been changed.

## Isolated implementation candidate

The private implementation remains outside the main source tree until a complete overlay and migration are qualified. It contains a one-page lease orchestrator, PostgreSQL cursor/pointer store using raw SQL, metadata-only keyset pages for 17 native kinds, native domain readers, and the authorized-subset Experience resolver. Readers call existing native getters/source policies on the actual viewer and recheck effective owner coverage; pointer rows contain only company, kind, native ID, version hash, and timestamps. Security and tenant support/incident contacts are optional canonical company fields; a support case opener is not treated as a Platform responder. Platform Support's operator group is read from native deployment configuration and does not establish current authentication, assurance, or case-effect authority. `native-reader-ports.ts` rejects a missing or duplicate kind at binding time.

The integration seam emits one generic card per kind only after current native visibility/source version and the native owner/default/group decision pass. It neither receives owner IDs nor infers ownership from creator/requester/installer/decider provenance. An unreadable pointer returns no card/count/kind/fingerprint/overflow. The internal pointer query is capped at 40 IDs per kind and is never returned to the caller. Generic support-case handling remains the operator owner’s port; tenant-manager access cannot make a private case visible.

Private PG qualification is driven by `run-responsibility-0565-overlay-pg-r2.sh`. It snapshots the current source through the existing source-sync helper, copies the isolated overlay into the qualification mirror under the shared test lock, records the overlay/SQL SHA-256 manifest, Oxc-checks the entire mirror tree plus overlay, and runs the test in the mirror. No overlay file is published into main. Initial PG attempt exposed that raw Drizzle SQL needs ISO timestamp binds; the isolated store was corrected and the rerun is pending the shared lock.

The private scheduler candidate is `maintenance-runner.ts`. It is designed to be registered as a 2-second `company-responsibility-scan` job in the existing `server/src/services/saas/platform.ts` job array, which already owns interval leases, duplicate-run exclusion, error handling, and stop behavior. Each tick expires a bounded metadata batch, admits at most one next company by oldest completed scan with a locked company row and `SKIP LOCKED`, then claims one 40-row native page with an exact run/worker/token/lease CAS. It does not add another timer. `complete` queues that company’s next scan 5 minutes later; in-progress pages are fairly interleaved by `requested_at` and company ID. This registration is not wired in the main scheduler.

Native metadata pages are now per-kind queries in `native-metadata-sources.ts`, selecting only `{id, updatedAt}` for Agent, Deployment, Workflow, Workflow Run, Routine, Connector, Metric, Experiment, Decision, Approval, AI Use Case, Tool Policy, Skill Policy, Billing, and Support case. Each query keysets by native ID, applies its source’s operational status, and runs under 1s statement / 200ms lock budgets. This is trusted-server ID/version collection only. All public current owner/read/visibility checks remain dependent on per-domain ports; the port set is complete at the type level but concrete implementations are not yet complete.
