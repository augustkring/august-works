use std::path::PathBuf;

use serde_json::Value;

use crate::acpx_provider_backend::{AcpxCommandExecutor, ACPX_PROVIDER_STATE_FILE};
use crate::durable::{
    Command, CommandExecution, CommandExecutor, DurableRunnerConfig, DurableRunnerError,
    PolledEvent, TerminalDeliveryReconciliation,
};
use crate::managed_provider_backend::{
    ManagedProviderCommandExecutor, MANAGED_PROVIDER_STATE_FILE,
};
use crate::provider_backend::{CodexCommandExecutor, CODEX_PROVIDER_STATE_FILE};

enum SelectedExecutor {
    LocalFacade(CodexCommandExecutor),
    Acpx(AcpxCommandExecutor),
    Managed(ManagedProviderCommandExecutor),
}

impl CommandExecutor for SelectedExecutor {
    fn retained_events(&mut self) -> Result<Vec<PolledEvent>, DurableRunnerError> {
        match self {
            Self::LocalFacade(executor) => executor.retained_events(),
            Self::Acpx(executor) => executor.retained_events(),
            Self::Managed(executor) => executor.retained_events(),
        }
    }
    fn execute(&mut self, command: &Command) -> Result<CommandExecution, DurableRunnerError> {
        match self {
            Self::LocalFacade(executor) => executor.execute(command),
            Self::Acpx(executor) => executor.execute(command),
            Self::Managed(executor) => executor.execute(command),
        }
    }

    fn poll_events(&mut self) -> Result<Vec<PolledEvent>, DurableRunnerError> {
        match self {
            Self::LocalFacade(executor) => executor.poll_events(),
            Self::Acpx(executor) => executor.poll_events(),
            Self::Managed(executor) => executor.poll_events(),
        }
    }

    fn poll_events_with_native_capture(
        &mut self,
        on_capture: &mut dyn FnMut(Value) -> Result<Value, DurableRunnerError>,
    ) -> Result<Vec<PolledEvent>, DurableRunnerError> {
        match self {
            Self::LocalFacade(executor) => executor.poll_events_with_native_capture(on_capture),
            Self::Acpx(executor) => executor.poll_events_with_native_capture(on_capture),
            Self::Managed(executor) => executor.poll_events_with_native_capture(on_capture),
        }
    }

    fn rotate_authority(&mut self, config: &DurableRunnerConfig) {
        match self {
            Self::LocalFacade(executor) => executor.rotate_authority(config),
            Self::Acpx(executor) => executor.rotate_authority(config),
            Self::Managed(executor) => executor.rotate_authority(config),
        }
    }

    fn maintain_backpressured_provider(&mut self) -> Result<(), DurableRunnerError> {
        match self {
            Self::LocalFacade(executor) => executor.maintain_backpressured_provider(),
            Self::Acpx(executor) => executor.maintain_backpressured_provider(),
            Self::Managed(executor) => executor.maintain_backpressured_provider(),
        }
    }

    fn acknowledge_events(&mut self, count: usize) -> Result<(), DurableRunnerError> {
        match self {
            Self::LocalFacade(executor) => executor.acknowledge_events(count),
            Self::Acpx(executor) => executor.acknowledge_events(count),
            Self::Managed(executor) => executor.acknowledge_events(count),
        }
    }

    fn reconcile_terminal_delivery(
        &mut self,
    ) -> Result<TerminalDeliveryReconciliation, DurableRunnerError> {
        match self {
            Self::LocalFacade(executor) => executor.reconcile_terminal_delivery(),
            Self::Acpx(executor) => executor.reconcile_terminal_delivery(),
            Self::Managed(executor) => executor.reconcile_terminal_delivery(),
        }
    }

    fn shutdown(&mut self) -> Result<(), DurableRunnerError> {
        match self {
            Self::LocalFacade(executor) => executor.shutdown(),
            Self::Acpx(executor) => executor.shutdown(),
            Self::Managed(executor) => executor.shutdown(),
        }
    }
}

/// Selects one durable provider implementation for the lifetime of a runner.
/// Recovery selection comes only from mutually exclusive private state files;
/// fresh selection comes only from the controller's run.prepare descriptor.
pub struct NativeProviderCommandExecutor {
    state_dir: PathBuf,
    config: DurableRunnerConfig,
    selected: Option<SelectedExecutor>,
    recovery_checked: bool,
}

impl NativeProviderCommandExecutor {
    pub fn with_runner_config(state_dir: impl Into<PathBuf>, config: &DurableRunnerConfig) -> Self {
        Self {
            state_dir: state_dir.into(),
            config: config.clone(),
            selected: None,
            recovery_checked: false,
        }
    }

    fn select_recovery(&mut self) -> Result<(), DurableRunnerError> {
        if self.recovery_checked {
            return Ok(());
        }
        self.recovery_checked = true;
        let codex = self.state_dir.join(CODEX_PROVIDER_STATE_FILE).exists();
        let acpx = self.state_dir.join(ACPX_PROVIDER_STATE_FILE).exists();
        let managed = self.state_dir.join(MANAGED_PROVIDER_STATE_FILE).exists();
        if [codex, acpx, managed]
            .into_iter()
            .filter(|present| *present)
            .count()
            > 1
        {
            return Err(DurableRunnerError::invalid(
                "runner state contains conflicting provider authorities",
            ));
        }
        self.selected = if managed {
            Some(SelectedExecutor::Managed(
                ManagedProviderCommandExecutor::with_runner_config(&self.state_dir, &self.config),
            ))
        } else if acpx {
            Some(SelectedExecutor::Acpx(
                AcpxCommandExecutor::with_runner_config(&self.state_dir, &self.config),
            ))
        } else if codex {
            Some(SelectedExecutor::LocalFacade(
                CodexCommandExecutor::with_runner_config(&self.state_dir, &self.config),
            ))
        } else {
            None
        };
        Ok(())
    }

    fn select_from_payload(&mut self, payload: &Value) -> Result<(), DurableRunnerError> {
        let kind = payload
            .pointer("/provider/kind")
            .and_then(Value::as_str)
            .ok_or_else(|| {
                DurableRunnerError::invalid(
                    "run.prepare requires a supported provider kind before runner execution",
                )
            })?;
        self.selected = Some(match kind {
            "codex" | "opencode" => SelectedExecutor::LocalFacade(
                CodexCommandExecutor::with_runner_config(&self.state_dir, &self.config),
            ),
            "acpx" => SelectedExecutor::Acpx(AcpxCommandExecutor::with_runner_config(
                &self.state_dir,
                &self.config,
            )),
            "claude_managed" | "aws_agentcore" => SelectedExecutor::Managed(
                ManagedProviderCommandExecutor::with_runner_config(&self.state_dir, &self.config),
            ),
            _ => {
                return Err(DurableRunnerError::invalid(format!(
                    "provider kind {kind} is not executable through the local runnerd boundary"
                )))
            }
        });
        Ok(())
    }
}

impl CommandExecutor for NativeProviderCommandExecutor {
    fn retained_events(&mut self) -> Result<Vec<PolledEvent>, DurableRunnerError> {
        self.selected
            .as_mut()
            .map_or_else(|| Ok(Vec::new()), CommandExecutor::retained_events)
    }
    fn execute(&mut self, command: &Command) -> Result<CommandExecution, DurableRunnerError> {
        self.select_recovery()?;
        if self.selected.is_none()
            && matches!(command.command_type.as_str(), "run.prepare" | "run.attach")
        {
            self.select_from_payload(&command.payload)?;
        }
        self.selected
            .as_mut()
            .ok_or_else(|| {
                DurableRunnerError::invalid(
                    "run.prepare must select a provider before provider commands execute",
                )
            })?
            .execute(command)
    }

    fn poll_events(&mut self) -> Result<Vec<PolledEvent>, DurableRunnerError> {
        self.select_recovery()?;
        self.selected
            .as_mut()
            .map_or_else(|| Ok(Vec::new()), CommandExecutor::poll_events)
    }

    fn poll_events_with_native_capture(
        &mut self,
        on_capture: &mut dyn FnMut(Value) -> Result<Value, DurableRunnerError>,
    ) -> Result<Vec<PolledEvent>, DurableRunnerError> {
        self.select_recovery()?;
        if let Some(executor) = self.selected.as_mut() {
            executor.poll_events_with_native_capture(on_capture)
        } else {
            Ok(Vec::new())
        }
    }

    fn maintain_backpressured_provider(&mut self) -> Result<(), DurableRunnerError> {
        // A provider that has not yet been selected/restored cannot have
        // in-process cleanup to advance. Never launch one merely for ACK debt.
        self.selected
            .as_mut()
            .map_or_else(|| Ok(()), CommandExecutor::maintain_backpressured_provider)
    }

    fn rotate_authority(&mut self, config: &DurableRunnerConfig) {
        self.config = config.clone();
        if let Some(executor) = self.selected.as_mut() {
            executor.rotate_authority(config);
        }
    }

    fn acknowledge_events(&mut self, count: usize) -> Result<(), DurableRunnerError> {
        self.select_recovery()?;
        if let Some(executor) = self.selected.as_mut() {
            executor.acknowledge_events(count)
        } else if count == 0 {
            Ok(())
        } else {
            Err(DurableRunnerError::invalid(
                "cannot acknowledge provider events before provider selection",
            ))
        }
    }

    fn reconcile_terminal_delivery(
        &mut self,
    ) -> Result<TerminalDeliveryReconciliation, DurableRunnerError> {
        // Selection only loads the provider authority. The selected executor
        // decides whether terminal delivery can settle without a cold launch.
        self.select_recovery()?;
        self.selected.as_mut().map_or_else(
            || Ok(TerminalDeliveryReconciliation::CleanupCompleted),
            CommandExecutor::reconcile_terminal_delivery,
        )
    }

    fn shutdown(&mut self) -> Result<(), DurableRunnerError> {
        // Terminal delivery can be reconciled by a replacement runner whose
        // executor has not processed a provider command. Select the durable
        // provider authority before cleanup so an absent in-memory selection
        // can never turn the cleanup fence into a successful no-op.
        self.select_recovery()?;
        if let Some(executor) = self.selected.as_mut() {
            executor.shutdown()
        } else {
            Ok(())
        }
    }
}
