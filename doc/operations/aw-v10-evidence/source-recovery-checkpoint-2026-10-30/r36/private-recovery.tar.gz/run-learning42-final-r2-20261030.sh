#!/usr/bin/env bash
set -euo pipefail
exec flock -x /workspace/v10-preparation/v10-pg-tests.lock bash -lc '
set -euo pipefail
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH
OUT=/workspace/v10-preparation/learning42-final-r2-20261030
ROOT=/workspace/v10-dep-qualification
BINARY=/workspace/.cloud-setup/lockfile/node_modules/.pnpm/opencode-linux-x64@1.18.32/node_modules/opencode-linux-x64/bin/opencode
EXPECTED=513f500a1a5ea1dc7d865547ac87b32a8936334e8d5abd5b3ff585c45a170080
mkdir -p "$OUT"
for name in binary.path binary.sha256 runner.txt source-pins.json snapshot.log snapshot.exit syntax.log syntax.exit full42.log full42.exit exit; do
  if [[ -e "$OUT/$name" || -e "$OUT/$name.tmp" ]]; then
    echo "final Learning r2 artifact already exists: $OUT/$name" >&2
    exit 73
  fi
done
actual="$(sha256sum "$BINARY" | cut -d" " -f1)"
test "$actual" = "$EXPECTED"
printf "%s\n" "$BINARY" > "$OUT/binary.path.tmp"
printf "%s\n" "$actual" > "$OUT/binary.sha256.tmp"
python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$OUT/source-pins.json" > "$OUT/snapshot.log.tmp" 2>&1
printf "0\n" > "$OUT/snapshot.exit.tmp"
node /workspace/v10-preparation/check-snapshot-syntax.cjs "$OUT/source-pins.json" > "$OUT/syntax.log.tmp" 2>&1
printf "0\n" > "$OUT/syntax.exit.tmp"
mv "$OUT/snapshot.log.tmp" "$OUT/snapshot.log"
mv "$OUT/snapshot.exit.tmp" "$OUT/snapshot.exit"
mv "$OUT/syntax.log.tmp" "$OUT/syntax.log"
mv "$OUT/syntax.exit.tmp" "$OUT/syntax.exit"
mv "$OUT/binary.path.tmp" "$OUT/binary.path"
mv "$OUT/binary.sha256.tmp" "$OUT/binary.sha256"
printf "node_heap_mb=3072\ntimeout_seconds=2400\ntest_file=src/__tests__/v7-learning.integration.test.ts\ntest_pattern=unfiltered (all 42 cases)\nqualification_workspace=%s\nsource_pins_sha256=%s\n" "$ROOT" "$(sha256sum "$OUT/source-pins.json" | cut -d" " -f1)" > "$OUT/runner.txt.tmp"
mv "$OUT/runner.txt.tmp" "$OUT/runner.txt"
cd "$ROOT/server"
set +e
timeout --signal=TERM --kill-after=10s 2400s python3 /workspace/v10-preparation/run-with-owned-child-cleanup.py ../node_modules/.bin/vitest run src/__tests__/v7-learning.integration.test.ts --reporter=verbose > "$OUT/full42.log.tmp" 2>&1
rc=$?
printf "%s\n" "$rc" > "$OUT/full42.exit.tmp"
mv "$OUT/full42.log.tmp" "$OUT/full42.log"
mv "$OUT/full42.exit.tmp" "$OUT/full42.exit"
printf "%s\n" "$rc" > "$OUT/exit.tmp"
mv "$OUT/exit.tmp" "$OUT/exit"
exit "$rc"
'
