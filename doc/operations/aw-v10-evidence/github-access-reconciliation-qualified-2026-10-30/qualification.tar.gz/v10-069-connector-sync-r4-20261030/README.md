# V10-069 GitHub repository-access reconciliation — R4

This portable bundle contains the unchanged R3 feature qualification, the R4 fairness follow-up, the exact eight-file source candidate and current MAIN hashes, and raw qualification/hygiene receipts. The R4 candidate is now applied to MAIN; no files were staged or committed by this qualification step.

## Final R4 change

When the bounded sweep defers due work because its five-grant pass is full or a grant is leased, the existing local scheduler gate now retries after 60 seconds. Per-grant hourly freshness, the five-grant pass cap, and lease behavior remain in place. The PostgreSQL regression uses unforced sweeps: the first five grants are not refreshed early, the sixth progresses at +60 seconds, a live lease is not polled early, and work progresses after lease expiry.

R4 changed only `server/src/services/tool-access.ts` and `server/src/__tests__/tool-access-service.test.ts` relative to R3. The eight-file closure is listed in `stage-paths.txt`; its exact applied bytes are pinned by `current-main-stage-pins.sha256`. `r4-candidate/` retains full baseline/candidate copies, anchored patch, hashes, and the Root Project witness boundary record.

## Qualification results

R3 receipts are retained byte-for-byte in the embedded R3 archive and establish PostgreSQL access 10/10, lifecycle 16/16, events 3/3, recovery 13/13, and full server TSC success.

R4 PostgreSQL access/cadence corpus passed 11 tests (348 skipped by targeted selection); DB and shared builds passed; full server TSC passed. The final UI closure run passed Oxc, DB/shared builds, and `pnpm --dir /workspace/v10-dep-qualification/ui typecheck` (TypeScript build mode). Mirror source restoration verified all eight baseline paths; the DB/shared/UI distribution manifest matched. The final run log and restoration evidence are under `qualification/r4-ui-attempt3/`.

The first R4 access/TSC wrapper recorded a cleanup-guard bug after its successful tests. Its original `cleanup.exit=1` is preserved unchanged; a separate guarded restoration receipt verified the mirror files, R5 module pin, and compiled output. UI wrapper attempts 1 and 2 are also retained as preflight/harness failures; attempt 3 is the successful clean run. No failed or superseded receipt was overwritten.

## Applicability and limits

The applicable owner is GitHub `repository_access`, using complete paginated installation/repository snapshots. GitHub does not expose an ordered installation event-feed cursor for this owner, so cursor, watermark, and feed-level gap detection remain `not_reported`. Known issue and pull-request objects use conditional canonical GETs with provider object versions; this does not attest feed completeness or undiscovered objects. Other providers remain `not_reported`. No credentials, raw provider headers, webhook delivery IDs, or provider bodies are included in the DTO.

The exact R4 prior-MAIN guard was `r4-candidate/baseline-source-pins.sha256`; the exact post-publication source guard is `current-main-stage-pins.sha256`. Root’s Project repository witness lines were verified present in both the pinned baseline and published candidate before publication.
