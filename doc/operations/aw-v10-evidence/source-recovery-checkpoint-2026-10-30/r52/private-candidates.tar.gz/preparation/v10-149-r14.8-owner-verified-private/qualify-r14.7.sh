#!/usr/bin/env bash
set -euo pipefail
REPO=/workspace/blentera-v10
MIRROR=/workspace/v10-dep-qualification
CAND=/workspace/v10-preparation/v10-149-r14.7-probe-fixture-private
OUT=$CAND/qualification-r14.7
mkdir -m 700 "$OUT" || exit 73
exec 9>/workspace/v10-preparation/v10-pg-tests.lock
flock -x 9
root_kb=$(df -Pk / | awk 'NR==2 {print $4}')
tmp_kb=$(df -Pk /tmp | awk 'NR==2 {print $4}')
if [[ ! "$root_kb" =~ ^[0-9]+$ || ! "$tmp_kb" =~ ^[0-9]+$ ]] || ((root_kb < 120000 || tmp_kb < 120000)); then
 echo "headroom guard failed before source snapshot: root=${root_kb:-unknown}KB tmp=${tmp_kb:-unknown}KB" > "$OUT/preflight.log"; exit 78
fi
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH
cd "$REPO"
restore_all() {
 python3 - "$CAND/source-pins.json" "$MIRROR" "$OUT/restore-files" "$OUT/build-backup" "$OUT/restore.log" <<'PY'
from pathlib import Path
import hashlib,json,shutil,sys
pins=json.loads(Path(sys.argv[1]).read_text())['sourceFiles']; root=Path(sys.argv[2]); backup=Path(sys.argv[3]); build=Path(sys.argv[4]); log=Path(sys.argv[5]); errors=[]
for row in pins:
 p=row['path']; dst=root/p; actual=hashlib.sha256(dst.read_bytes()).hexdigest() if dst.is_file() else None
 if actual==row['candidateSha256']:
  src=backup/p
  if row['parentSha256'] is None:
   if dst.exists(): dst.unlink()
  elif not src.is_file() or hashlib.sha256(src.read_bytes()).hexdigest()!=row['parentSha256']:
   errors.append(f'BASELINE_BACKUP_BAD {p}')
  else:
   dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
 elif actual!=row['parentSha256']:
  errors.append(f'SOURCE_RESTORE_GUARD {p} actual={actual}')
# Restore exact compiled outputs and tsbuildinfo captured before test execution.
meta=json.loads((build/'state.json').read_text())
for rel in meta['distDirs']:
 dst=root/rel; saved=build/'dirs'/rel
 if dst.exists(): shutil.rmtree(dst)
 if saved.exists(): shutil.copytree(saved,dst,symlinks=True)
for rel in meta['tsbuildinfo']:
 dst=root/rel; saved=build/'files'/rel
 if dst.exists() or dst.is_symlink(): dst.unlink()
 dst.parent.mkdir(parents=True,exist_ok=True)
 if saved.exists(): shutil.copy2(saved,dst)
keep=set(meta['tsbuildinfo'])
for extra in root.rglob('*.tsbuildinfo'):
 rel=extra.relative_to(root).as_posix()
 if rel not in keep: extra.unlink()
for row in pins:
 p=row['path']; dst=root/p; actual=hashlib.sha256(dst.read_bytes()).hexdigest() if dst.is_file() else None
 if actual!=row['parentSha256']: errors.append(f'SOURCE_POST_RESTORE {p} actual={actual}')
log.write_text(('\n'.join(errors)+'\n') if errors else 'tracked sources and compiled outputs restored byte-for-byte\n')
if errors: raise SystemExit(1)
PY
}
restore_ready=0
cleanup() { if ((restore_ready)); then restore_all || echo 'restore_failed=1' >> "$OUT/restore.log"; fi; }
trap cleanup EXIT INT TERM
python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$OUT/snapshot-source-pins.json" > "$OUT/snapshot.log" 2>&1
python3 - "$CAND/source-pins.json" "$CAND/files" "$REPO" "$MIRROR" "$OUT/restore-files" "$OUT/build-backup" "$OUT/overlay-pins.json" <<'PY'
from pathlib import Path
import hashlib,json,shutil,sys
pins=Path(sys.argv[1]); candidate=Path(sys.argv[2]); repo=Path(sys.argv[3]); mirror=Path(sys.argv[4]); backup=Path(sys.argv[5]); build=Path(sys.argv[6]); out=Path(sys.argv[7]); rows=json.loads(pins.read_text())['sourceFiles']; records=[]
# Verify all pins before creating any overlay or backup.
for row in rows:
 p=row['path']; main=repo/p; target=mirror/p; cand=candidate/p
 for label,file,want in [('MAIN',main,row['parentSha256']),('mirror',target,row['parentSha256']),('candidate',cand,row['candidateSha256'])]:
  actual=hashlib.sha256(file.read_bytes()).hexdigest() if file.is_file() else None
  if actual!=want: raise SystemExit(f'{label} pin mismatch {p}: {actual} != {want}')
 if row['parentSha256'] is not None:
  saved=backup/p; saved.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(target,saved)
 records.append({'path':p,'parentSha256':row['parentSha256'],'candidateSha256':row['candidateSha256']})
# Preserve all existing compiler outputs before any test/typecheck can mutate them.
dist_dirs=['packages/shared/dist','packages/db/dist','server/dist']; present=[]; hashes={}
for rel in dist_dirs:
 src=mirror/rel
 if src.exists():
  present.append(rel); dst=build/'dirs'/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copytree(src,dst,symlinks=True)
  for f in src.rglob('*'):
   if f.is_file(): hashes[f.relative_to(mirror).as_posix()]=hashlib.sha256(f.read_bytes()).hexdigest()
tsbuild=[p.relative_to(mirror).as_posix() for p in mirror.rglob('*.tsbuildinfo') if p.is_file()]
for rel in tsbuild:
 src=mirror/rel; dst=build/'files'/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
(build/'state.json').write_text(json.dumps({'distDirs':present,'tsbuildinfo':tsbuild,'hashes':hashes},indent=2)+'\n')
out.write_text(json.dumps({'files':records},indent=2)+'\n')
PY
restore_ready=1
python3 - "$CAND/source-pins.json" "$CAND/files" "$MIRROR" <<'PY'
from pathlib import Path
import hashlib,json,sys
pins=json.loads(Path(sys.argv[1]).read_text())['sourceFiles']; candidate=Path(sys.argv[2]); mirror=Path(sys.argv[3])
for row in pins:
 p=row['path']; src=candidate/p; dst=mirror/p
 dst.parent.mkdir(parents=True,exist_ok=True)
 import shutil
 shutil.copy2(src,dst)
 if hashlib.sha256(dst.read_bytes()).hexdigest()!=row['candidateSha256']: raise SystemExit(f'overlay copy mismatch {p}')
PY
run_step() { local name="$1"; shift; set +e; "$@" > "$OUT/$name.log" 2>&1; local rc=$?; set -e; printf '%s\n' "$rc" > "$OUT/$name.exit"; return 0; }
cd "$MIRROR"
run_step shared-build pnpm --filter @paperclipai/shared build
if [[ $(cat "$OUT/shared-build.exit") != 0 ]]; then exit 1; fi
run_step db-build pnpm --filter @paperclipai/db build
if [[ $(cat "$OUT/db-build.exit") != 0 ]]; then exit 1; fi
cd "$MIRROR/server"
run_step policy-vitest pnpm exec vitest run src/__tests__/openshell-qualification-policy.test.ts src/__tests__/v7-sandbox-policy.test.ts src/__tests__/agent-auth-jwt.test.ts --maxWorkers=1 --reporter=verbose
run_step bridge-pg-vitest pnpm exec vitest run src/__tests__/v7-sandbox-host-bridge.integration.test.ts src/__tests__/v7-sandbox-qualification-faults.test.ts --maxWorkers=1 --reporter=verbose
run_step shared-tsc pnpm --filter @paperclipai/shared exec tsc --noEmit --singleThreaded
run_step server-tsc pnpm --filter @paperclipai/server exec tsc --noEmit --singleThreaded
python3 - "$OUT" <<'PY'
from pathlib import Path
import hashlib,json,sys
out=Path(sys.argv[1]); names=['shared-build','db-build','policy-vitest','bridge-pg-vitest','shared-tsc','server-tsc']; result={n:int((out/f'{n}.exit').read_text()) for n in names}
root=Path('/workspace/v10-dep-qualification'); before=json.loads((out/'build-backup/state.json').read_text()); current={}
for rel in ('packages/shared/dist','packages/db/dist','server/dist'):
 p=root/rel
 if p.exists():
  for f in p.rglob('*'):
   if f.is_file(): current[f.relative_to(root).as_posix()]=hashlib.sha256(f.read_bytes()).hexdigest()
for rel in before['tsbuildinfo']:
 f=root/rel
 if f.is_file(): current[rel]=hashlib.sha256(f.read_bytes()).hexdigest()
result['compiled-state-mutated-before-restore']=0 if current==before['hashes'] else 1
(out/'result-before-restore.json').write_text(json.dumps(result,indent=2)+'\n')
print(result)
if any(result[name] for name in names): raise SystemExit(1)
PY
