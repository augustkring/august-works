#!/usr/bin/env bash
set -euo pipefail
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH
CAND=/workspace/v10-preparation/v10-094-097-feedback-quality-candidate
MIRROR=/workspace/v10-dep-qualification
OUT=$CAND/generation-0566-r2
TSC=$MIRROR/node_modules/.pnpm/typescript@7.0.2/node_modules/typescript/bin/tsc
DRIZZLE=$MIRROR/node_modules/.pnpm/drizzle-kit@0.31.10/node_modules/drizzle-kit/bin.cjs
mkdir -p "$OUT/mirror-backup" "$OUT/pruned-snapshots"
exec 9>/workspace/v10-preparation/v10-pg-tests.lock
flock -x 9
STATE=$OUT/mirror-path-states.tsv
: > "$STATE"
backup_path() {
  local rel="$1" src="$MIRROR/$1" dst="$OUT/mirror-backup/$1"
  if [ -e "$src" ]; then
    mkdir -p "$(dirname "$dst")"
    cp -a "$src" "$dst"
    printf 'present\t%s\n' "$rel" >> "$STATE"
  else
    printf 'absent\t%s\n' "$rel" >> "$STATE"
  fi
}
while IFS= read -r rel; do backup_path "${rel#files/}"; done < "$CAND/exact-files.txt"
backup_path packages/db/src/migrations/meta/_journal.json
backup_path packages/db/src/migrations/meta/0561_snapshot.json
backup_path packages/db/src/migrations/meta/0562_snapshot.json
backup_path packages/db/src/migrations/meta/0563_snapshot.json
backup_path packages/db/src/migrations/meta/0564_snapshot.json
backup_path packages/db/src/migrations/meta/0565_snapshot.json
backup_path packages/db/src/migrations/meta/0566_snapshot.json
backup_path packages/db/dist
for p in "$MIRROR"/packages/db/src/migrations/0566_*.sql; do
  [ -e "$p" ] || continue
  rel=${p#"$MIRROR"/}
  backup_path "$rel"
done
restore_mirror() {
  while IFS=$'\t' read -r state rel; do
    dst="$MIRROR/$rel"; src="$OUT/mirror-backup/$rel"
    if [ "$state" = present ]; then mkdir -p "$(dirname "$dst")"; rm -rf "$dst"; cp -a "$src" "$dst"; else rm -rf "$dst"; fi
  done < "$STATE"
}
trap restore_mirror EXIT HUP INT TERM
while IFS= read -r rel; do
  rel=${rel#files/}
  mkdir -p "$(dirname "$MIRROR/$rel")"
  cp -p "$CAND/files/$rel" "$MIRROR/$rel"
done < "$CAND/exact-files.txt"
cd "$MIRROR/packages/db"
pnpm run build > "$OUT/db-build.log" 2>&1
node "$DRIZZLE" generate --name customer_feedback_experience_measures > "$OUT/drizzle-generate.log" 2>&1
pnpm run prune:snapshots > "$OUT/prune-snapshots.log" 2>&1
mapfile -t migrations < <(find src/migrations -maxdepth 1 -type f -name '0566_*.sql' -printf '%f\n' | sort)
[ "${#migrations[@]}" -eq 1 ]
MIG=${migrations[0]}
cp "src/migrations/$MIG" "$OUT/$MIG.generated.sql"
cp src/migrations/meta/0566_snapshot.json "$OUT/0566_snapshot.json.generated"
cp src/migrations/meta/_journal.json "$OUT/_journal.json.generated"
for old in 0561 0562 0563 0564 0565; do
  if [ -e "$OUT/mirror-backup/packages/db/src/migrations/meta/${old}_snapshot.json" ] && [ ! -e "src/migrations/meta/${old}_snapshot.json" ]; then
    cp "$OUT/mirror-backup/packages/db/src/migrations/meta/${old}_snapshot.json" "$OUT/pruned-snapshots/${old}_snapshot.json"
  fi
done
cat >> "src/migrations/$MIG" <<'SQL'
--> statement-breakpoint
CREATE FUNCTION aw_v10_customer_feedback_experience_measure_guard() RETURNS trigger LANGUAGE plpgsql SET search_path=pg_catalog,public,pg_temp AS $$
BEGIN
  IF TG_OP='UPDATE' THEN
    RAISE EXCEPTION 'Optional feedback experience ratings are immutable' USING ERRCODE='23514';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM customer_feedback f
    WHERE f.company_id=NEW.company_id AND f.id=NEW.feedback_id
      AND f.context->'experienceMeasure'->>'offered'='true'
      AND f.context->'experienceMeasure'->>'consent'='granted'
  ) THEN
    RAISE EXCEPTION 'Optional feedback ratings require the original consent marker' USING ERRCODE='23514';
  END IF;
  IF EXISTS (
    SELECT 1 FROM customer_feedback_events e
    WHERE e.company_id=NEW.company_id AND e.feedback_id=NEW.feedback_id
      AND e.link_type='aw_feedback_measure_withdrawal_v1'
  ) THEN
    RAISE EXCEPTION 'Withdrawn feedback ratings cannot be restored' USING ERRCODE='23514';
  END IF;
  RETURN NEW;
END $$;
--> statement-breakpoint
CREATE TRIGGER aw_v10_customer_feedback_experience_measure_guard
BEFORE INSERT OR UPDATE ON customer_feedback_experience_measures
FOR EACH ROW EXECUTE FUNCTION aw_v10_customer_feedback_experience_measure_guard();
--> statement-breakpoint
CREATE FUNCTION aw_v10_customer_feedback_experience_withdrawal_event_guard() RETURNS trigger LANGUAGE plpgsql SET search_path=pg_catalog,public,pg_temp AS $$
BEGIN
  IF NEW.link_type='aw_feedback_measure_withdrawal_v1' AND NOT EXISTS (
    SELECT 1 FROM customer_feedback f
    WHERE f.company_id=NEW.company_id AND f.id=NEW.feedback_id
      AND f.context->'experienceMeasure'->>'offered'='true'
      AND f.context->'experienceMeasure'->>'consent'='granted'
  ) THEN
    RAISE EXCEPTION 'Feedback withdrawal marker requires original consent' USING ERRCODE='23514';
  END IF;
  RETURN NEW;
END $$;
--> statement-breakpoint
CREATE TRIGGER aw_v10_customer_feedback_experience_withdrawal_event_guard
BEFORE INSERT ON customer_feedback_events
FOR EACH ROW EXECUTE FUNCTION aw_v10_customer_feedback_experience_withdrawal_event_guard();
--> statement-breakpoint
CREATE FUNCTION aw_v10_customer_feedback_experience_withdrawal_immutable() RETURNS trigger LANGUAGE plpgsql SET search_path=pg_catalog,public,pg_temp AS $$
BEGIN
  IF OLD.link_type='aw_feedback_measure_withdrawal_v1' AND pg_trigger_depth() <= 1 THEN
    RAISE EXCEPTION 'Feedback withdrawal markers are append-only' USING ERRCODE='23514';
  END IF;
  RETURN OLD;
END $$;
--> statement-breakpoint
CREATE TRIGGER aw_v10_customer_feedback_experience_withdrawal_immutable
BEFORE DELETE ON customer_feedback_events
FOR EACH ROW EXECUTE FUNCTION aw_v10_customer_feedback_experience_withdrawal_immutable();
SQL
node "$TSC" --noEmit --pretty false -p tsconfig.json > "$OUT/db-typecheck-with-triggers.log" 2>&1
pnpm run check:migrations > "$OUT/check-migrations.log" 2>&1
cp "src/migrations/$MIG" "$OUT/$MIG"
cp src/migrations/meta/0566_snapshot.json "$OUT/0566_snapshot.json"
cp src/migrations/meta/_journal.json "$OUT/_journal.json"
printf '%s\n' "$MIG" > "$OUT/migration-name.txt"
sha256sum "$OUT/$MIG" "$OUT/0566_snapshot.json" "$OUT/_journal.json" > "$OUT/SHA256SUMS"
