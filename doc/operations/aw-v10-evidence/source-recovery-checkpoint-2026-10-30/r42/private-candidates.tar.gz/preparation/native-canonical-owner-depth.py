from pathlib import Path
p=Path('/workspace/blentera-v10/server/src/services/native-direct-input.ts');s=p.read_text()
s=s.replace('  policy: NativePayloadSourcePolicy; inputs: NativePayloadSourceInput[] }>;','  policy: NativePayloadSourcePolicy; inputs: NativePayloadSourceInput[]; requiredSets?: NativePayloadSourceSet[];\n  validatedDepth?: number }>;',1)
a=s.index('    if (source.kind === "tool_result") {',s.index('async function assertNativePayloadSourceSetCurrentUncachedInScope('));b=s.index('    if (source.kind === "authored_definition")',a);chunk=s[a:b]
c=chunk.index('      const producerRun =');d=chunk.index('      const projectCreateCapture',c);decls=chunk[c:d];chunk=chunk[:c]+chunk[d:]
insert='''      // Canonical producer identity is independent of the later consumer.
'''+decls+'''      const producerEntry = receipt?.success ? receipt.data.additionalInputs.find(entry =>
        entry.inputs.some(value => value.kind === "tool_result" && isDeepStrictEqual(value, source))) : undefined;
      const producerClosures: NativePayloadSourceSet[] = producerEntry ? [producerEntry] : [];
      let producerClosureAvailable = Boolean(producerEntry && sourceBindingCurrent && captures.length === 1);
      const addProducerClosure = (value: unknown) => {
        const record = nativeSourceRecord(value);
        const parsedPolicy = nativePayloadSourcePolicySchema.safeParse(record.policy);
        const parsedInputs = nativePayloadSourceInputSchema.array().safeParse(record.inputs);
        if (parsedPolicy.success && parsedInputs.success)
          producerClosures.push({ policy: parsedPolicy.data, inputs: parsedInputs.data });
        else producerClosureAvailable = false;
      };
      if (capture.sourceSet !== undefined) addProducerClosure(capture.sourceSet);
      const contextClosure = nativeSourceRecord(capture.contextRead).sourceSet;
      if (contextClosure !== undefined) addProducerClosure(contextClosure);
      const producedDocument = nativeSourceRecord(capture.documentRevision);
      if (typeof producedDocument.revisionId === "string") {
        const [owner] = await db.select({ snapshot: documentRevisions.payloadSourceSnapshot }).from(documentRevisions)
          .where(and(eq(documentRevisions.companyId, input.companyId), eq(documentRevisions.id, producedDocument.revisionId))).for("share");
        const snapshot = nativePayloadSourceSnapshotSchema.safeParse(owner?.snapshot);
        if (snapshot.success) producerClosures.push({ policy: snapshot.data.policy, inputs: snapshot.data.inputs });
        else producerClosureAvailable = false;
      }
      const producedTask = nativeSourceRecord(capture.taskRef);
      if (typeof producedTask.issueId === "string") {
        const [owner] = await db.select({ snapshot: issues.payloadSourceSnapshot }).from(issues)
          .where(and(eq(issues.companyId, input.companyId), eq(issues.id, producedTask.issueId))).for("share");
        const snapshot = nativePayloadSourceSnapshotSchema.safeParse(owner?.snapshot);
        if (snapshot.success) producerClosures.push({ policy: snapshot.data.policy, inputs: snapshot.data.inputs });
        else producerClosureAvailable = false;
      }
'''
chunk=chunk.replace('    if (source.kind === "tool_result") {\n','    if (source.kind === "tool_result") {\n'+insert,1)
chunk=chunk.replace('''        issueId: input.issueId, runId: input.runId, actor: input.actor, actorScope: scope.actorKey,
        memoryTemporalIdentity: scope.context.memoryTemporalIdentity, source })}`;''','''        issueId: producerRun.nativeIssueId, runId: source.runId, actor: input.actor, actorScope: scope.actorKey,
        memoryTemporalIdentity: scope.context.memoryTemporalIdentity, source,
        captureHash: nativeSha256(capture), producerClosures })}`;''',1)
chunk=chunk.replace('''        nativeGraphProofInputsEligible(policy.data, inputs.data) ? toolSourceVisitKey : null;''','''        producerClosureAvailable && nativeGraphProofInputsEligible(policy.data, inputs.data) &&
        producerClosures.every(set => nativeGraphProofInputsEligible(set.policy, set.inputs)) ? toolSourceVisitKey : null;''',1)
c=chunk.index('      const prefixCoversProof =');d=chunk.index('      if (siblingProof && prefixCoversProof',c)
chunk=chunk[:c]+'''      const prefixCoversProof = siblingProof && (siblingProof.requiredSets ?? [siblingProof]).every(set =>
        set.inputs.every(required => inputs.data.some(candidate => isDeepStrictEqual(candidate, required))) &&
        (Object.keys(policy.data) as (keyof NativePayloadSourcePolicy)[]).every(key =>
          set.policy[key].every(id => policy.data[key].includes(id))));
'''+chunk[d:]
chunk=chunk.replace('''            policy: policy.data, inputs: inputs.data });''','''            policy: producerEntry!.policy, inputs: producerEntry!.inputs, requiredSets: producerClosures });''',1)
s=s[:a]+chunk+s[b:]
# One exact document key, with successful deeper proof safely covering shallower reads.
a=s.index('  const documentProofKey =');b=s.index('  const documentProofEligible',a);chunk=s[a:b].replace('    depth, snapshot })}`;','    snapshot })}`;');s=s[:a]+chunk+s[b:]
s=s.replace('''  if (documentProof && !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, documentProof.descendants)) {''','''  if (documentProof && depth <= (documentProof.validatedDepth ?? -1) &&
    !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, documentProof.descendants)) {''',1)
s=s.replace('''        policy: snapshot.policy, inputs: snapshot.inputs });
  }
  } finally''','''        policy: snapshot.policy, inputs: snapshot.inputs, validatedDepth: depth });
  }
  } finally''',1)
p.with_suffix('.canonicalowner.tmp.ts').write_text(s)
