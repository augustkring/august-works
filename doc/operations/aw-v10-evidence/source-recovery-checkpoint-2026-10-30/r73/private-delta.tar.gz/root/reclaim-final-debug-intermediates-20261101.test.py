from pathlib import Path
import hashlib
import json
import subprocess
import tempfile

helper = Path(__file__).with_name('reclaim-final-debug-intermediates-20261101.py')
with tempfile.TemporaryDirectory(prefix='blentera-final-source-rust-target-check-', dir='/tmp') as tmp:
    root = Path(tmp)
    debug = root / 'debug'
    (debug / 'deps').mkdir(parents=True)
    victim = debug / 'deps/cache.rlib'
    victim.write_text('rebuildable')
    command = ['python3', str(helper), tmp, str(root / 'receipt.json')]
    assert subprocess.run(command, capture_output=True).returncode != 0
    assert victim.read_text() == 'rebuildable'
    for name in ['paperclip-runnerd', 'fake-codex-app-server', 'fake-harness']:
        f = debug / name
        f.write_text(name)
        f.chmod(0o700)
    link = debug / 'deps/link'
    link.symlink_to(victim)
    assert subprocess.run(command, capture_output=True).returncode != 0
    assert victim.read_text() == 'rebuildable'
    link.unlink()
    library = debug / 'deps/libmacro.so'
    library.write_text('executable library')
    library.chmod(0o700)
    (debug / '.fingerprint/x').mkdir(parents=True)
    (debug / '.fingerprint/x/cache.json').write_text('{}')
    kept = {f: hashlib.sha256(f.read_bytes()).hexdigest() for f in [*debug.glob('fake*'), debug / 'paperclip-runnerd', library]}
    subprocess.run(command, check=True)
    assert len(json.loads((root / 'receipt.json').read_text())['removed']) == 2
    assert not victim.exists() and not (debug / '.fingerprint/x').exists()
    assert all(hashlib.sha256(f.read_bytes()).hexdigest() == h for f, h in kept.items())
print('PASS: prepared binaries retained; missing binaries and symlinks refuse deletion')
