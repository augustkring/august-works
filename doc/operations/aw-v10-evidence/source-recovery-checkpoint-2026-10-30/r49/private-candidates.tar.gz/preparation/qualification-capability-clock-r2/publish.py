from pathlib import Path
import hashlib,subprocess,json,shutil,tarfile
main=Path('/workspace/blentera-v10');candidate=Path(__file__).resolve().parent;qualification=candidate/'qualification'
assert (qualification/'exit').read_text().strip()=='0'
assert (qualification/'focused-tests.exit').read_text().strip()=='0'
assert (qualification/'server-typecheck.exit').read_text().strip()=='0'
assert json.loads((qualification/'restore.json').read_text())['restored'] is True
parents=json.loads((candidate/'parents.json').read_text());overlay=json.loads((qualification/'overlay-pins.json').read_text());temporary=candidate/'publication';temporary.mkdir(exist_ok=False)
for rel,parent in parents.items():
 assert hashlib.sha256((main/rel).read_bytes()).hexdigest()==parent,('MAIN parent changed',rel)
 assert hashlib.sha256((candidate/rel).read_bytes()).hexdigest()==overlay[rel],('qualified candidate changed',rel)
for rel,parent in parents.items():
 p=temporary/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(candidate/rel,p)
 subprocess.run(['node','/workspace/v10-preparation/publish-parsed-source.cjs',str(p),str(main/rel),parent],check=True)
out=main/'doc/operations/aw-v10-evidence/sandbox-qualification-report-timestamps-2026-10-30';out.mkdir(exist_ok=False)
with tarfile.open(out/'qualification.tar.gz','w:gz') as t:
 for p in sorted(candidate.rglob('*')):
  if p.is_file() and 'publication' not in p.relative_to(candidate).parts:t.add(p,arcname=str(p.relative_to(candidate)),recursive=False)
b=(out/'qualification.tar.gz').read_bytes();manifest={'purpose':'scoped software qualification; no physical host or whole-V10 acceptance','baselineHead':json.loads((qualification/'source-pins.json').read_text())['sourceHead'],'parents':parents,'qualifiedOverlay':overlay,'targetedTestsPassed':51,'fullServerTypecheckExit':0,'restoreVerified':True,'archiveSha256':hashlib.sha256(b).hexdigest(),'archiveBytes':len(b)};(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(out/'README.md').write_text('''# Sandbox qualification report timestamps

Independently generated host reports can refresh observation times while retaining exactly the same target evidence. Compare every validated field except testedAt/expiresAt; require both the original and current expiry to remain valid through completion. Keep the earlier expiry in the result. Image, kernel, credential epoch, policy/control, and provenance changes still fail closed.

The private two-file overlay passed 51 selected policy/fault tests and the full server typecheck. Four added cases cover fresh timestamps, attempted renewal of an expired original, shortened current expiry, and expiry between the current read and the completion fence. Exact baseline plus overlay source pins, runnable check, logs, and verified restoration are in the archive. These fixture tests do not qualify a physical sandbox host.
''')
subprocess.run(['git','diff','--check','--',*parents.keys()],cwd=main,check=True)
subprocess.run(['git','add','--',*parents.keys(),str(out.relative_to(main))],cwd=main,check=True)
subprocess.run(['git','commit','-m','fix: compare stable sandbox evidence without renewing qualification expiry [skip ci]'],cwd=main,check=True)
