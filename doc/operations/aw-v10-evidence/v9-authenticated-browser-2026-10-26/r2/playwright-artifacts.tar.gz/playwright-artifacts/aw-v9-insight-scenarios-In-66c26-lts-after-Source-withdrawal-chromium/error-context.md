# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: aw-v9-insight-scenarios.spec.ts >> Insights reads conditional scenario comparisons and loses private results after Source withdrawal
- Location: tests/e2e/aw-v9-insight-scenarios.spec.ts:18:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('main').getByRole('heading', { name: 'Conditional native capacity model', exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByRole('main').getByRole('heading', { name: 'Conditional native capacity model', exact: true })

```

```yaml
- link "Skip to Main Content":
  - /url: "#main-content"
- complementary:
  - button "Open Disposable scenario comparisons organization switcher": D Disposable scenario comparisons
  - navigation:
    - text: View
    - combobox "View":
      - option "Member"
      - option "Manager" [selected]
      - option "Admin"
    - link "Home":
      - /url: /DISAAAAAA/dashboard
    - link "Needs You":
      - /url: /DISAAAAAA/needs-you
    - link "Work":
      - /url: /DISAAAAAA/work
    - link "Agents":
      - /url: /DISAAAAAA/agents
    - link "Apps":
      - /url: /DISAAAAAA/apps
    - link "Insights":
      - /url: /DISAAAAAA/insights
    - button "Ask Blentera"
    - link "Help / Support":
      - /url: /DISAAAAAA/company/help
- button "Open account menu": BR Browser product reviewer
- separator "Resize sidebar"
- region "Global utilities":
  - button "Ask Blentera"
  - text: Language
  - combobox "Language":
    - option "English" [selected]
    - option "Dansk"
  - link "Help / Support":
    - /url: /DISAAAAAA/company/help
  - link "Contact support":
    - /url: mailto:support@blentera.com
  - link "User account":
    - /url: /DISAAAAAA/company/settings/instance/profile
- main:
  - heading "Insights" [level=1]
  - paragraph: Explore measurements, estimates and questions that need closer review.
  - region "Recorded measurements":
    - heading "Recorded measurements" [level=2]
    - paragraph: A selection of saved measurements. Review the definitions and dates before comparing results.
    - alert:
      - paragraph: Current authorized measurements could not be read. Refresh before using a retained result.
      - button "Try again"
    - link "Inspect definitions and observations":
      - /url: /DISAAAAAA/business-metrics
  - list:
    - listitem:
      - heading "Business performance" [level=2]:
        - link "Business performance":
          - /url: /DISAAAAAA/business-metrics
      - paragraph: See measurements and their approved definitions.
    - listitem:
      - heading "Scenarios" [level=2]:
        - link "Scenarios":
          - /url: /DISAAAAAA/business-scenarios
      - paragraph: Compare conditional calculations and their assumptions.
- heading "Command Palette" [level=2]
- paragraph: Search for a command to run...
```

# Test source

```ts
  1  | import { createRequire } from "node:module";
  2  | import { readFile } from "node:fs/promises";
  3  | import { tmpdir } from "node:os";
  4  | import path from "node:path";
  5  | import { expect, test, type APIResponse } from "@playwright/test";
  6  | import { createDb, closeRegisteredClients, issues, businessScenarioRuns } from "../../packages/db/src/index.ts";
  7  | import { eq } from "../../packages/db/node_modules/drizzle-orm/index.js";
  8  | import { businessMetricService } from "../../server/src/services/business-metrics/service.ts";
  9  | import { businessScenarioService } from "../../server/src/services/business-scenarios/service.ts";
  10 | import { aiGovernanceService } from "../../server/src/services/ai-governance/governance-service.ts";
  11 | import { analyticalPurpose, metricDefinition } from "../../server/src/__tests__/helpers/business-metric-fixture.ts";
  12 | import { scenarioDefinition } from "../../server/src/__tests__/helpers/business-scenario-fixture.ts";
  13 | const axePath = createRequire(import.meta.url).resolve("axe-core/axe.min.js");
  14 | async function json(response: APIResponse) { expect(response.ok(), `${response.status()}: ${await response.text()}`).toBe(true); return response.json(); }
  15 | 
  16 | // Actual Native metric/scenario/publication/result owners and Source refusal;
  17 | // explicit synthetic approved governance and manager presentation fixture.
  18 | test("Insights reads conditional scenario comparisons and loses private results after Source withdrawal", async ({ page, request }, info) => {
  19 |   const flags = await json(await request.get("/api/instance/settings/experimental"));
  20 |   const company = await json(await request.post("/api/companies", { data: { name: "Disposable scenario comparisons" } }));
  21 |   const configPath = process.env.PAPERCLIP_E2E_SERVER_CONFIG!;
  22 |   expect(configPath.startsWith(path.join(tmpdir(), "paperclip-e2e-home-"))).toBe(true);
  23 |   const config = JSON.parse(await readFile(configPath, "utf8"));
  24 |   expect(path.resolve(config.database.embeddedPostgresDataDir)).toBe(path.join(path.dirname(configPath), "db"));
  25 |   const pid = await readFile(path.join(config.database.embeddedPostgresDataDir, "postmaster.pid"), "utf8");
  26 |   const databaseUrl = `postgres://paperclip:paperclip@127.0.0.1:${pid.split("\n")[3]}/paperclip`, db = createDb(databaseUrl);
  27 |   const actor = { type: "board" as const, source: "local_implicit" as const };
  28 |   let writes = 0;
  29 |   page.on("request", req => { if (req.method() !== "GET" && /\/business-(metrics|scenarios)/.test(req.url())) writes++; });
  30 |   try {
  31 |     await json(await request.patch("/api/instance/settings/experimental", { data: { experience_projection_v9: true, progressive_shell_v9: true,
  32 |       analytical_lineage_v8: true, business_metrics_v8: true, scenario_planning_v8: true, ai_use_cases_v7: true, governance_evidence_v7: true } }));
  33 |     const purpose = analyticalPurpose(); purpose.analyticalPurpose!.capabilities = ["metrics", "scenario"];
  34 |     const policy = await aiGovernanceService(db).obligation(actor, company.id, purpose);
  35 |     const [issue] = await db.insert(issues).values({ companyId: company.id, status: "done", title: "PRIVATE scenario Source prose", createdAt: new Date("2026-01-01T12:00:00Z") }).returning();
  36 |     const metrics = businessMetricService(db);
  37 |     const measured = await metrics.create(company.id, actor, { key: "completed_objects", definition: { ...metricDefinition(policy.id), valueType: "count", unit: "objects", calculation: { kind: "native_count", population: { entity: "issue", statuses: ["done"], projectId: null } } } });
  38 |     await metrics.publish(company.id, actor, measured.metric.id, { expectedRevision: 1, versionId: measured.version.id });
  39 |     const observation = await metrics.query(company.id, actor, { metricId: measured.metric.id, versionId: measured.version.id, from: "2026-01-01T00:00:00Z", until: "2026-01-02T00:00:00Z", dimensions: [], maxRows: 5000 });
  40 |     const owner = businessScenarioService(db);
  41 |     const created = await owner.create(company.id, actor, { key: "conditional_capacity", definition: scenarioDefinition(policy.id, {
  42 |       kind: "metric_observation", key: "objects", metricId: measured.metric.id, metricVersionId: measured.version.id, observationId: observation.id, unit: { issue: 1 },
  43 |     }) });
  44 |     const published = await owner.publish(company.id, actor, created.scenario.id, { expectedRevision: 1, versionId: created.version.id, rationale: "Synthetic human review of this conditional model and source pins" });
  45 |     const run = await owner.run(company.id, actor, published.id, { expectedRevision: published.revision, versionId: created.version.id, seed: null });
  46 |     expect(run.result.cases.map(value => value.outputs[0].nominal)).toEqual([2, 3]);
  47 |     const initial = await db.select().from(businessScenarioRuns).where(eq(businessScenarioRuns.companyId, company.id));
  48 |     await page.route(`**/api/companies/${company.id}/experience?*`, route => route.fulfill({ headers: { "Cache-Control": "private, no-store" }, json: {
  49 |       companyId: company.id, profile: "manager", availableProfiles: ["member", "manager", "admin"], advancedLinks: [], generatedAt: new Date().toISOString(), dependencies: [], needsYou: [], inProgress: [], done: [], watch: [],
  50 |     } }));
  51 |     await page.goto(`/${company.issuePrefix}/insights`);
  52 |     const main = page.getByRole("main");
> 53 |     await expect(main.getByRole("heading", { name: "Conditional native capacity model", exact: true })).toBeVisible();
     |                                                                                                         ^ Error: expect(locator).toBeVisible() failed
  54 |     await expect(main).toContainText("Value: 2 tasks"); await expect(main).toContainText("Value: 3 tasks"); await expect(main).toContainText("Change from base: 1 task");
  55 |     await expect(main).toContainText("does not prove its assumptions"); await expect(main).not.toContainText("PRIVATE scenario Source");
  56 |     await main.getByText("Review assumptions and unmodeled effects", { exact: true }).click();
  57 |     await expect(main).toContainText("Human-declared assumption"); await expect(main).toContainText("Declared range: 1 to 3");
  58 |     await page.setViewportSize({ width: 390, height: 844 });
  59 |     await page.getByRole("combobox", { name: "Language", exact: true }).selectOption("da");
  60 |     await expect(main.getByRole("heading", { name: "Gemte scenariesammenligninger", exact: true })).toBeVisible(); await expect(main).toContainText("Værdi: 3 opgaver");
  61 |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  62 |     await page.addScriptTag({ path: axePath });
  63 |     expect((await page.evaluate(async () => (window as any).axe.run(document.querySelector("main"), { runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21aa"] } }))).violations).toEqual([]);
  64 |     await page.screenshot({ path: info.outputPath("insight-native-scenarios-mobile-da.png"), fullPage: true });
  65 |     expect(writes).toBe(0); expect(await db.select().from(businessScenarioRuns).where(eq(businessScenarioRuns.companyId, company.id))).toEqual(initial);
  66 |     await db.update(issues).set({ hiddenAt: new Date() }).where(eq(issues.id, issue.id));
  67 |     expect((await request.get(`/api/companies/${company.id}/business-scenarios/${published.id}/runs/${run.id}`)).status()).toBe(403);
  68 |     await page.reload(); await expect(main).not.toContainText("Value: 3 tasks"); await expect(main).not.toContainText("Værdi: 3 opgaver");
  69 |   } finally {
  70 |     await page.goto("about:blank"); await request.patch("/api/instance/settings/experimental", { data: flags }); await closeRegisteredClients(databaseUrl);
  71 |   }
  72 | });
  73 | 
```