import{t as a}from"./createLucideIcon-BqxdEa8D.js";var e=[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]],o=a("loader-circle",e);export{o as t};
