# Private OpenShell RT-01 R6.1 integration candidate

This candidate packages a source-pinned NVIDIA/OpenShell v0.1.2 downstream patch and an isolated GitHub Actions qualification workflow. It remains **candidate-not-qualified** and profile admission remains closed. No main checkout or provider/runtime was changed.

The upstream base is commit `6648bd0c290efbc41ba131ee9831ee45cd431f94`. The cumulative R6 patch and exact changed-path set are pinned in `third_party/openshell/rt01/source-pins.json`. R6.1 layers the qualified R5.1 identity-bound API, CLI no-fallback regression and test-only seccomp safety annotations with the frozen Quality R2 PID/memory-swap provisioning changes and Resource R12 Rust resource/runtime helpers. The Resource R13 follow-up contains host-only source and is not part of this upstream vendor patch. The upstream Apache-2.0 license and attribution are retained.

## Reproduce the source tree

From the repository root:

```sh
workdir="$(mktemp -d "${TMPDIR:-/tmp}/openshell-rt01.XXXXXX")"
scripts/openshell-rt01/fetch-and-apply.sh "$workdir/source"
```

The helper fetches the exact upstream commit, refuses an existing destination, verifies the cumulative patch digest, applies it, and verifies all changed paths and pinned input/source files.

## Remote qualification

The dedicated workflow installs Rust 1.95.0 minimal, disables debug symbols and incremental compilation, and caps Cargo build jobs and test threads at two. A pinned Rust dependency cache is keyed by the upstream/toolchain and Cargo lockfile; it does not replace source, format, compile, or test checks. The workflow checks formatting, compiles the server, CLI, Docker driver and sandbox packages (including generated protobuf), then resolves and runs 18 named tests with `--exact`. It requires each test to appear exactly once in Cargo's list and produce one passing, non-ignored result. Logs are retained as a workflow artifact.

The selected tests cover nine identity-bound RPC/CLI checks and the CLI `UNIMPLEMENTED` no-fallback transport case; create-time PID and memory-swap policy; canonical protobuf `Struct` PID parsing that rejects f64-backed numeric values; disk-limit and external-mount constraints; seccomp allow/deny behavior; and a past absolute idle deadline that returns without host stress. The workflow has read-only repository permissions and uses no provider credentials, model calls, deployed gateway, or live host access.

The no-fallback case uses a test TLS transport and does not qualify a deployed older gateway. Unit tests do not establish physical Docker quota, host seccomp, or target-runtime behavior. Those runtime and host qualifications remain open. R6.0 source verification and formatting passed, but its four-package compile failed because the pinned Bollard model is `HostConfigLogConfig` with field `typ`, not `LogConfig`/`type_`; focused tests were skipped. R6.1 fixes that type mismatch. Its exact 18 tests and package compilation are pending a dedicated remote run; R5.1 previously passed all four package checks and 15 selected tests.
