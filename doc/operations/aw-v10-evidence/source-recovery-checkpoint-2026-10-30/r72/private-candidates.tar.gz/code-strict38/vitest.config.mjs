import { defineConfig } from "/workspace/v10-dep-qualification/node_modules/vitest/dist/config.js";
import {createRequire} from "node:module"; const require=createRequire("/workspace/blentera-v10/server/package.json");
import fs from "node:fs";import path from "node:path";
const out="/workspace/v10-preparation/committed-native-agent-strict38-pg-nov01", workspace=out+"/test-workspace", main="/workspace/blentera-v10", base="/workspace/v10-preparation/v10-149-r14.38.4.61-selected-opencode-worker-provider-private/files";
export default defineConfig({root:workspace+"/server",plugins:[{name:"private-owner-overrides",enforce:"pre",resolveId(id,importer){
 if(id === "@paperclipai/adapter-utils/paid-model-probe")return base+"/packages/adapter-utils/src/paid-model-probe.ts";
 if(id === "@paperclipai/shared")return out+"/shared-entry.ts";
 if(id.startsWith("@paperclipai/")){
  const parts=id.split("/");const rel="packages/"+(parts[1] === "plugin-sdk" ? "plugins/sdk" : parts[1])+"/src/"+(parts.slice(2).join("/")||"index")+".ts";
  for(const root of [out+"/files","/workspace/v10-preparation/committed-native-agent-pg-assertions-followup-nov01/files","/workspace/v10-preparation/committed-native-agent-pg-seed-followup-nov01/files","/workspace/v10-preparation/committed-native-agent-contract-followup-nov01/files","/workspace/v10-preparation/committed-native-agent-reconcile-nov01/files",base,main])if(fs.existsSync(root+"/"+rel))return root+"/"+rel;
  try{return require.resolve(id);}catch{return;}
 }
 if(!importer || !id.startsWith("."))return;
 const file=path.resolve(path.dirname(importer.split("?")[0]),id).replace(/\.js$/, ".ts");
 let relative=null;for(const root of [out+"/files","/workspace/v10-preparation/committed-native-agent-pg-assertions-followup-nov01/files","/workspace/v10-preparation/committed-native-agent-pg-seed-followup-nov01/files","/workspace/v10-preparation/committed-native-agent-contract-followup-nov01/files","/workspace/v10-preparation/committed-native-agent-reconcile-nov01/files",workspace,base,main])if(file.startsWith(root+"/")){relative=path.relative(root,file);break;}
 if(relative)for(const root of [out+"/files","/workspace/v10-preparation/committed-native-agent-pg-assertions-followup-nov01/files","/workspace/v10-preparation/committed-native-agent-pg-seed-followup-nov01/files","/workspace/v10-preparation/committed-native-agent-contract-followup-nov01/files","/workspace/v10-preparation/committed-native-agent-reconcile-nov01/files",base,main]){const candidate=path.join(root,relative);if(fs.existsSync(candidate))return candidate;}
}}],test:{include:["src/__tests__/committed-native-agent-reconcile.integration.test.ts"],pool:"forks",maxWorkers:1,testTimeout:30000,hookTimeout:45000}});
