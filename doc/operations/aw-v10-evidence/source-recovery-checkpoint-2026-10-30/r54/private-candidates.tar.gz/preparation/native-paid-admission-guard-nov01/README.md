# Native paid transport admission guard (private patch)

Base: `254e5c998c9f41725708a2c8c404078397a3fcac` (`codex/blentera-v10`). The main repository worktree remains untouched; reconcile this patch with concurrent changes before any application.

Heartbeat now blocks unsupported Paperclip Runner provider profiles before provider-bound AI Connection credentials are resolved. Direct Native CLI credentials are rejected on this path. OpenCode may proceed to the final gate, while only the internal `aw_text_only` draft uses its existing controller-owned backend.

The final gate is at `executePaperclipNativeSession` before startup registration, session restoration, or backend execution. It does not trust model-broker-looking environment strings. For paid OpenCode, it requires Paperclip Runner + the `opencode_server` driver + Runnerd + the server-selected remote Sandbox execution target. That is the only Native launch path that calls RuntimeControl's existing managed model issuance path; RuntimeControl verifies the current source, run and execution manifest, provider-profile hash, typed model credential and authority before startup dispatch. The model gateway reserves before provider wire calls. RuntimeControl continues to reject forged reserved environment values and missing/stale manifest or profile authority.

Stop stays independent of model availability. Focused tests include actual executor-entry call spies for an unqualified provider and a forged environment tuple on an SSH route, plus policy coverage for the server-selected managed Sandbox route and unsupported routes. No prices, token bounds, ledger/table, or bypass flag are introduced.

The repository's managed conversation integration has a `sandboxRelay: true` case that exercises the positive server-selected Sandbox → RuntimeControl path, including a current manifest and broker reservation. Its local test-only env-injection variant is intentionally outside the production admission contract.
