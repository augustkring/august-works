from pathlib import Path
p=Path('/workspace/blentera-v10/server/src/services/native-direct-input.ts');s=p.read_text()
s=s.replace('const nativeSourceMemoDiagnostics = { frozenTaskMemoByKind:', 'const nativeSourceMemoDiagnostics = { siblingToolSourceProofHits: 0, frozenTaskMemoByKind:',1)
s=s.replace('  nativeSourceMemoDiagnostics.frozenTaskMemoByKind = {};','  nativeSourceMemoDiagnostics.frozenTaskMemoByKind = {};\n  nativeSourceMemoDiagnostics.siblingToolSourceProofHits = 0;',1)
s=s.replace('''      const siblingProofKey = siblingToolSourceProofs && source.toolName !== "create_project" && source.toolName !== "call_api"
        ? nativeSha256({ companyId: input.companyId, issueId: input.issueId, runId: input.runId,
            actor: input.actor, actorScope: scope.actorKey, memoryTemporalIdentity: scope.context.memoryTemporalIdentity, source }) : null;''','''      const toolSourceVisitKey = `native-tool-source:${nativeSha256({ companyId: input.companyId,
        issueId: input.issueId, runId: input.runId, actor: input.actor, actorScope: scope.actorKey,
        memoryTemporalIdentity: scope.context.memoryTemporalIdentity, source })}`;
      if (scope.active.has(toolSourceVisitKey)) throw forbidden("The Native tool source graph contains a cycle");
      const siblingProofKey = siblingToolSourceProofs && source.toolName !== "create_project" && source.toolName !== "call_api"
        ? toolSourceVisitKey : null;''')
s=s.replace('''        // The source loop charged this hit above.''','''        if (nativeSourceMemoDiagnosticsEnabled()) nativeSourceMemoDiagnostics.siblingToolSourceProofHits =
          Math.min(1_000_000, nativeSourceMemoDiagnostics.siblingToolSourceProofHits + 1);
        // The source loop charged this hit above.''',1)
s=s.replace('''      const siblingFrame = { visitKey: siblingProofKey ?? "", descendants: new Set<string>() };''','''      addNativeSourceActiveVisit(scope, toolSourceVisitKey);
      const siblingFrame = { visitKey: toolSourceVisitKey, descendants: new Set([toolSourceVisitKey]) };''',1)
s=s.replace('''      } finally {
        if (siblingProofKey && siblingProofStack.at(-1)''','''      } finally {
        scope.active.delete(toolSourceVisitKey);
        if (siblingProofKey && siblingProofStack.at(-1)''',1)
s=s.replace('''        if (reusable && scope.context.memoryTemporalIdentity) {
        }
''','')
p.with_suffix('.ownvisit.tmp.ts').write_text(s)
p=Path('/workspace/blentera-v10/server/src/__tests__/native-payload-temporal-sources.integration.test.ts');s=p.read_text()
s=s.replace('''    database = await startEmbeddedPostgresTestDatabase''','''    vi.stubEnv("PAPERCLIP_NATIVE_SOURCE_MEMO_DIAGNOSTICS", "1");
    resetNativeSourceMemoDiagnosticsForTest();
    database = await startEmbeddedPostgresTestDatabase''',1)
s=s.replace('''    const { first, second, memoryAId, memoryBId } = temporal;''','''    expect(nativeSourceMemoDiagnosticsForTest().siblingToolSourceProofHits).toBeGreaterThan(0);
    const { first, second, memoryAId, memoryBId } = temporal;''',1)
p.with_suffix('.ownvisit.tmp.ts').write_text(s)
