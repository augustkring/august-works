#!/usr/bin/env bash
set -euo pipefail

# Final two-case authenticated Native Project browser cohort. The helper takes
# the canonical PostgreSQL lock, pins current source, verifies all UI build
# inputs, rebuilds both UI bundles, then runs the unfiltered integration file.
export PAPERCLIP_PINNED_NATIVE_BUILD_STATIC_UI=1
export PAPERCLIP_PINNED_NATIVE_TEST_TIMEOUT_SECONDS=600
exec /workspace/v10-preparation/run-pinned-managed-browser-test.sh \
  managed-project-full2-final-r2-20261030 \
  src/services/native-runtime/native-opencode-managed-browser.integration.test.ts \
  .
