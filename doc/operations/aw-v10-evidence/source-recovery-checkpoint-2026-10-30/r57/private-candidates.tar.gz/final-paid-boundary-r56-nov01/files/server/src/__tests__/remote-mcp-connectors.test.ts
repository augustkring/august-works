import { randomUUID } from "node:crypto";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";
import { agents, heartbeatRuns, issues, toolCatalogEntries, toolConnectionInstalls, toolInvocations, companies, companyMemberships, instanceSettings, createDb, toolConnections, toolPolicies, toolProfileEntries } from "@paperclipai/db";
import { eq } from "drizzle-orm";
import { startEmbeddedPostgresTestDatabase } from "./helpers/embedded-postgres.js";
import { toolAccessService } from "../services/tool-access.js";
import { createToolGatewayService } from "../services/tool-gateway.js";
import { instanceSettingsService, normalizeExperimentalSettings } from "../services/instance-settings.js";
import express from "express";
import request from "supertest";
import { toolAccessRoutes } from "../routes/tool-access.js";
const actor = { actorType: "user" as const, actorId: "mcp-test-user", actorSource: "local_implicit" as const };
const tool = (name: string) => ({ name, description: name, inputSchema: { type: "object", properties: {} }, annotations: { readOnlyHint: true } });
describe("remote connector lifecycle", () => {
  let fixture: Awaited<ReturnType<typeof startEmbeddedPostgresTestDatabase>>;
  let db: ReturnType<typeof createDb>;
  let keyDir: string;
  beforeAll(async () => {
    keyDir = await mkdtemp(join(tmpdir(), "mcp-connector-secrets-"));
    vi.stubEnv("PAPERCLIP_SECRETS_MASTER_KEY_FILE", join(keyDir, "key"));
    fixture = await startEmbeddedPostgresTestDatabase("mcp-connectors-test-");
    db = createDb(fixture.connectionString);
  });
  afterAll(async () => { await fixture?.cleanup(); vi.unstubAllEnvs(); if (keyDir) await rm(keyDir, { recursive: true, force: true }); });
  async function company() {
    const [row] = await db.insert(companies).values({ name: `MCP ${randomUUID()}`, issuePrefix: `M${randomUUID().slice(0, 5)}` }).returning();
    await db.insert(companyMemberships).values({ companyId: row.id, principalType: "user", principalId: actor.actorId, status: "active", membershipRole: "admin" });
    return row;
  }
  function remoteFixture() {
    const requests: { url: string; headers: Headers }[] = [];
    let added = false;
    let removed = false;
    const service = toolAccessService(db, { deploymentMode: "local_trusted", deploymentExposure: "private",
      remoteHttpEndpointLookup: async () => [{ address: "8.8.8.8", family: 4 }],
      remoteHttpRequest: async (url, init) => {
        const body = JSON.parse(String(init.body)); const headers = new Headers(init.headers);
        requests.push({ url, headers });
        if (body.method === "initialize") return Response.json({ id: body.id, jsonrpc: "2.0", result: { protocolVersion: "2025-06-18", capabilities: {} } }, { headers: { "Mcp-Session-Id": "session" } });
        expect(headers.get("mcp-session-id")).toBe("session");
        if (body.method === "notifications/initialized") return new Response(null, { status: 202 });
        expect(body.method).toBe("tools/list");
        return Response.json({ id: body.id, jsonrpc: "2.0", result: body.params?.cursor
          ? { tools: [tool("ask"), ...(added ? [tool("new_tool")] : [])] }
          : { tools: [tool("read"), ...(!removed ? [tool("off")] : [])], nextCursor: "page-two" } });
      },
    });
    return { service, requests, add: () => { added = true; }, remove: () => { removed = true; }, restore: () => { removed = false; } };
  }
  it.each([undefined, false])("allows all aggregator setup with stored setting %s", async (legacyValue) => {
    await db.delete(instanceSettings);
    if (legacyValue !== undefined) await db.insert(instanceSettings).values({ experimental: { enableMcpAggregators: legacyValue } });
    expect(normalizeExperimentalSettings({ enableMcpAggregators: legacyValue }).enableMcpAggregators).toBe(true);
    expect((await instanceSettingsService(db).getExperimental()).enableMcpAggregators).toBe(true);
    const org = await company(); const remote = remoteFixture();
    const app = express();
    app.use((req, _res, next) => { req.actor = { type: "board", userId: actor.actorId, source: "local_implicit", isInstanceAdmin: true }; next(); });
    app.use("/api", toolAccessRoutes(db, { paperclipCloudConnector: null }));
    const gallery = await request(app).get(`/api/companies/${org.id}/tools/gallery`);
    expect(gallery.status).toBe(200);
    expect(gallery.body.apps.map((entry: { slug: string }) => entry.slug)).toEqual(expect.arrayContaining(["zapier", "arcade", "composio", "executor", "notion"]));
    expect(gallery.body.apps.some((entry: { slug: string }) => entry.slug === "mem0")).toBe(false);
    for (const [galleryKey, connectionMethodKey, link] of [
      ["zapier", "generated-url", "https://mcp.zapier.com/api/v1/connect?token=fixture-secret"],
      ["arcade", "mcp", "https://api.arcade.dev/mcp/fixture"],
      ["composio", "mcp", "https://connect.composio.dev/mcp"],
      ["executor", "mcp", "https://example.com/mcp"],
    ]) {
      const connected = await remote.service.connectGalleryApp(org.id, { galleryKey, connectionMethodKey, link, authMode: "none" }, actor);
      expect(connected.catalog).toHaveLength(3);
      expect(connected.connectionId).toBeTruthy();
    }
  });
  it.each([
    ["zapier", "generated-url", "https://mcp.zapier.com/api/v1/connect?token=fixture-secret"],
    ["composio", "mcp", "https://mcp.composio.dev/session/fixture?token=fixture-secret"],
  ])("%s vaults session URLs, paginates discovery, preserves Off/Ask during refresh and reconnect, and isolates companies", async (galleryKey, connectionMethodKey, link) => {
    const org = await company(); const other = await company(); const remote = remoteFixture();
    const input = { galleryKey, connectionMethodKey, link, authMode: "none" as const };
    const connected = await remote.service.connectGalleryApp(org.id, input, actor);
    expect(connected.catalog).toHaveLength(3);
    expect(JSON.stringify(connected)).not.toContain("fixture-secret");
    expect(remote.requests.every((r) => r.url.includes("token=fixture-secret"))).toBe(true);
    const ids = Object.fromEntries(connected.catalog.map((entry) => [entry.toolName, entry.id]));
    const finished = await remote.service.finishGalleryAppConnection(org.id, connected.connectionId, { enabledCatalogEntryIds: [ids.read, ids.ask], askFirstCatalogEntryIds: [ids.ask], access: "all_agents" }, actor);
    remote.add();
    const refreshed = await remote.service.refreshCatalog(connected.connectionId, actor, { enableAllByDefault: true });
    const newId = refreshed.catalog.find((entry) => entry.toolName === "new_tool")!.id;
    const entries = await db.select().from(toolProfileEntries).where(eq(toolProfileEntries.profileId, finished.profile.id));
    expect(entries.map((entry) => entry.catalogEntryId)).toEqual(expect.arrayContaining([ids.read, ids.ask, newId]));
    expect(entries.map((entry) => entry.catalogEntryId)).not.toContain(ids.off);
    await expect(remote.service.connectGalleryApp(other.id, { ...input, reconnectConnectionId: connected.connectionId }, actor)).rejects.toThrow("not found");
    const reconnected = await remote.service.connectGalleryApp(org.id, { ...input, reconnectConnectionId: connected.connectionId }, actor);
    const restored = await remote.service.finishGalleryAppConnection(org.id, connected.connectionId, { enabledCatalogEntryIds: reconnected.catalog.map((entry) => entry.id), askFirstCatalogEntryIds: [], access: "all_agents" }, actor);
    expect(restored.connection.status).toBe("active");
    expect(restored.profileEntries.map((entry) => entry.catalogEntryId)).not.toContain(ids.off);
    const policies = await db.select().from(toolPolicies).where(eq(toolPolicies.companyId, org.id));
    expect(policies.some((policy) => policy.enabled && policy.config.catalogEntryId === ids.ask)).toBe(true);
    remote.remove();
    const afterRemoval = await remote.service.refreshCatalog(connected.connectionId, actor);
    expect(afterRemoval.catalog.find((entry) => entry.toolName === "off")?.status).not.toBe("active");
    const [retired] = await db.select().from(toolCatalogEntries).where(eq(toolCatalogEntries.id, ids.off));
    expect(retired.status).toBe("disabled"); // Check persisted discovery, not just this refresh response.
    remote.restore();
    const afterReturn = await remote.service.refreshCatalog(connected.connectionId, actor);
    expect(afterReturn.catalog.find((entry) => entry.toolName === "off")?.status).toBe("active");
    const retainedEntries = await db.select().from(toolProfileEntries).where(eq(toolProfileEntries.profileId, finished.profile.id));
    expect(retainedEntries.map((entry) => entry.catalogEntryId)).not.toContain(ids.off);
    await remote.service.archiveConnection(connected.connectionId, org.id, actor);
    const [removed] = await db.select().from(toolConnections).where(eq(toolConnections.id, connected.connectionId));
    expect(removed.enabled).toBe(false);
    expect(removed.status).toBe("archived");
  });
  it("renews expired discovery sessions while refusing opaque invocation before session initialization", async () => {
    const org = await company();
    const [agent] = await db.insert(agents).values({ companyId: org.id, name: "Session tester", role: "engineer", adapterType: "process", adapterConfig: {}, runtimeConfig: {} }).returning();
    let initialized = 0;
    const expired = new Set<string>();
    const calls: string[] = [];
    const send = async (_url: string, init: RequestInit) => {
      const body = JSON.parse(String(init.body));
      if (body.method === "initialize") return Response.json({ id: body.id, result: { protocolVersion: "2025-06-18" } }, { headers: { "Mcp-Session-Id": `session-${++initialized}` } });
      if (body.method === "notifications/initialized") return new Response(null, { status: 202 });
      const session = new Headers(init.headers).get("mcp-session-id")!;
      if (body.method === "tools/call") calls.push(session);
      if (expired.has(session)) return new Response(null, { status: 404 });
      return Response.json({ id: body.id, result: body.method === "tools/list" ? { tools: [tool("read")] } : { content: [{ type: "text", text: "ok" }] } });
    };
    const service = toolAccessService(db, { deploymentMode: "local_trusted", deploymentExposure: "private", remoteHttpEndpointLookup: async () => [{ address: "8.8.8.8", family: 4 }], remoteHttpRequest: send });
    const connected = await service.connectGalleryApp(org.id, { galleryKey: "arcade", connectionMethodKey: "mcp", link: "https://api.arcade.dev/mcp/expiration", authMode: "none" }, actor);
    const beforeRefresh = initialized;
    expired.add(`session-${initialized}`);
    expect((await service.refreshCatalog(connected.connectionId, actor)).catalog).toHaveLength(1);
    expect(initialized).toBe(beforeRefresh + 1);
    await service.finishGalleryAppConnection(org.id, connected.connectionId, { enabledCatalogEntryIds: connected.catalog.map((entry) => entry.id), askFirstCatalogEntryIds: [], access: "all_agents" }, actor);
    const gateway = createToolGatewayService(db, { deploymentMode: "local_trusted", deploymentExposure: "private", remoteHttpRequest: send });
    const call = () => gateway.executeTestCall({ companyId: org.id, connectionId: connected.connectionId, agentId: agent.id, userId: actor.actorId, toolName: "read", parameters: {} });
    const beforeExecution = initialized;
    await expect(call()).rejects.toMatchObject({reasonCode:"tool_model_effect_unqualified"});
    expired.add(`session-${initialized}`);
    await expect(call()).rejects.toMatchObject({reasonCode:"tool_model_effect_unqualified"});
    expect(calls).toEqual([]);
    expect(initialized).toBe(beforeExecution);
  });
  it("saves a vaulted draft without contacting the provider and resumes with custom headers", async () => {
    const org = await company(); const remote = remoteFixture();
    const input = { galleryKey: "arcade", connectionMethodKey: "mcp", link: "https://api.arcade.dev/mcp/fixture", authMode: "bearer" as const };
    const draft = await remote.service.connectGalleryApp(org.id, { ...input, saveDraft: true, credentialValues: { "credentials.authorization": "fixture-key", "headers.Arcade-User-ID": "test-user" } }, actor);
    expect(remote.requests).toHaveLength(0);
    expect(JSON.stringify(draft)).not.toContain("fixture-key");
    const connected = await remote.service.connectGalleryApp(org.id, { ...input, resumeConnectionId: draft.connectionId }, actor);
    expect(connected.catalog).toHaveLength(3);
    expect(remote.requests.every((request) => request.headers.get("authorization") === "Bearer fixture-key" && request.headers.get("arcade-user-id") === "test-user")).toBe(true);
  });
  it("does not widen an empty agent selection after an OAuth callback or reconnect", async () => {
    const org = await company();
    const endpoint = "https://api.arcade.dev/mcp/fixture-oauth";
    const send = async (url: string, init: RequestInit) => {
      if (url.includes(".well-known/oauth-protected-resource")) return Response.json({ resource: endpoint, authorization_servers: ["https://auth.arcade.dev"] });
      if (url.includes(".well-known/")) return Response.json({ issuer: "https://auth.arcade.dev", authorization_endpoint: "https://auth.arcade.dev/authorize", token_endpoint: "https://auth.arcade.dev/token", response_types_supported: ["code"], code_challenge_methods_supported: ["S256"], token_endpoint_auth_methods_supported: ["none"] });
      if (url === "https://auth.arcade.dev/token") return Response.json({ access_token: "fixture-access", token_type: "Bearer", expires_in: 3600 });
      if (url !== endpoint) throw new Error(`Unexpected fixture URL: ${url}`);
      if (!new Headers(init.headers).has("authorization")) return new Response(null, { status: 401, headers: { "WWW-Authenticate": 'Bearer resource_metadata="https://api.arcade.dev/.well-known/oauth-protected-resource"' } });
      const body = JSON.parse(String(init.body));
      if (body.method === "notifications/initialized") return new Response(null, { status: 202 });
      return Response.json({ id: body.id, result: body.method === "initialize" ? { protocolVersion: "2025-06-18" } : { tools: [tool("read")] } });
    };
    const service = toolAccessService(db, { deploymentMode: "local_trusted", deploymentExposure: "private", remoteHttpEndpointLookup: async () => [{ address: "8.8.8.8", family: 4 }], remoteHttpRequest: send });
    const input = { galleryKey: "arcade", connectionMethodKey: "mcp", link: endpoint, authMode: "auto" as const, oauthClient: { clientId: "fixture-client" } };
    const connected = await service.connectGalleryApp(org.id, input, actor);
    const callback = async () => {
      const redirectUri = "http://127.0.0.1:3116/api/tools/oauth/callback";
      const started = await service.startOAuth(org.id, connected.connectionId, { redirectUri, actor });
      return service.completeOAuthCallback({ state: new URL(started.authorizationUrl).searchParams.get("state")!, code: "fixture-code", redirectUri, actor });
    };
    await service.putConnectionInstalls(connected.connectionId, { installs: [] }, actor);
    const first = await callback();
    expect(first.connection.status).toBe("active");
    expect((await service.listConnectionInstalls(connected.connectionId))).toHaveLength(0);
    await service.connectGalleryApp(org.id, { ...input, reconnectConnectionId: connected.connectionId }, actor);
    await callback();
    expect((await service.listConnectionInstalls(connected.connectionId))).toHaveLength(0);
  });
  it("retains connection access configuration but refuses opaque execute/resume before provider work", async () => {
    const org = await company();
    const [allowed, denied] = await db.insert(agents).values(["Allowed", "Denied"].map((name) => ({ companyId: org.id, name, role: "engineer", adapterType: "process", adapterConfig: {}, runtimeConfig: {} }))).returning();
    const calls: { name: string; arguments: unknown; session: string | null }[] = [];
    const send = async (_url: string, init: RequestInit) => {
      const body = JSON.parse(String(init.body));
      if (body.method === "initialize") return Response.json({ id: body.id, result: { protocolVersion: "2025-06-18" } }, { headers: { "Mcp-Session-Id": "execution-session" } });
      if (body.method === "notifications/initialized") return new Response(null, { status: 202 });
      if (body.method === "tools/list") return Response.json({ id: body.id, result: { tools: [tool("execute"), tool("resume"), tool("off")] } });
      calls.push({ ...body.params, session: new Headers(init.headers).get("mcp-session-id") });
      return Response.json({ id: body.id, result: { structuredContent: body.params.name === "execute"
        ? { status: "waiting_for_interaction", executionId: "fixture-execution", interaction: { kind: "form", message: "Approve read?", requestedSchema: { type: "object", properties: {} } } }
        : { ok: true, resumed: body.params.arguments.executionId }, content: [] } });
    };
    const service = toolAccessService(db, { deploymentMode: "local_trusted", deploymentExposure: "private", remoteHttpEndpointLookup: async () => [{ address: "8.8.8.8", family: 4 }], remoteHttpRequest: send });
    const connection = await service.connectGalleryApp(org.id, { galleryKey: "executor", connectionMethodKey: "mcp", link: "https://executor.sh/test/mcp", authMode: "none" }, actor);
    const ids = Object.fromEntries(connection.catalog.map((entry) => [entry.toolName, entry.id]));
    await service.finishGalleryAppConnection(org.id, connection.connectionId, { enabledCatalogEntryIds: [ids.execute, ids.resume], askFirstCatalogEntryIds: [ids.execute], access: { agentIds: [allowed.id] } }, actor);
    const gateway = createToolGatewayService(db, { deploymentMode: "local_trusted", deploymentExposure: "private", remoteHttpRequest: send, toolActionSigningSecret: "fixture-signing-key" });
    const call = (agentId: string, toolName: string, parameters: Record<string, unknown> = {}) => gateway.executeTestCall({ companyId: org.id, connectionId: connection.connectionId, agentId, userId: actor.actorId, toolName, parameters });
    for (const [agentId, toolName] of [[denied.id,"execute"],[allowed.id,"off"],[allowed.id,"execute"],[allowed.id,"resume"]])
      await expect(call(agentId!,toolName!)).rejects.toMatchObject({reasonCode:"tool_model_effect_unqualified"});
    expect(calls).toHaveLength(0);
    expect(await db.select().from(toolInvocations).where(eq(toolInvocations.companyId,org.id))).toHaveLength(0);
    const [issue] = await db.insert(issues).values({companyId:org.id,title:"Opaque provider unavailable",status:"in_progress",assigneeAgentId:allowed.id}).returning();
    const [run] = await db.insert(heartbeatRuns).values({companyId:org.id,agentId:allowed.id,invocationSource:"assignment",status:"running",contextSnapshot:{issueId:issue.id}}).returning();
    const session=await gateway.createSession({companyId:org.id,agentId:allowed.id,runId:run.id});
    const execute=(await gateway.listToolsForSession(session.token)).find(entry=>entry.upstreamToolName==="execute")!;
    expect(execute).toBeDefined();
    await expect(gateway.executeTool({sessionToken:session.token,tool:execute.name,parameters:{}})).rejects.toMatchObject({reasonCode:"tool_model_effect_unqualified"});
    await service.finishGalleryAppConnection(org.id,connection.connectionId,{enabledCatalogEntryIds:[ids.execute,ids.resume],askFirstCatalogEntryIds:[ids.execute],access:{agentIds:[]}},actor);
    expect(await db.select().from(toolConnectionInstalls).where(eq(toolConnectionInstalls.connectionId,connection.connectionId))).toHaveLength(0);
    expect((await gateway.listToolsForSession(session.token)).filter(entry=>entry.connectionId===connection.connectionId)).toHaveLength(0);
    await service.archiveConnection(connection.connectionId,org.id,actor);
    await expect(call(allowed.id,"resume")).rejects.toThrow("not found");
    expect(calls).toHaveLength(0);
  });

});
