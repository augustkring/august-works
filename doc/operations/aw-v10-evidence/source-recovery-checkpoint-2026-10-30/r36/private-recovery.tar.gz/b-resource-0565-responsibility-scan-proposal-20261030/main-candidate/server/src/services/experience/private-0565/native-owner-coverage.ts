/** PRIVATE 0565 candidate. Resolves coverage through a domain's native
 * read/owner policy; it never changes the canonical source or assigns a Human. */
export async function hasNativeResponsibilityCoverage(input: {
  canonicalOwnerUserId: string | null;
  companyDefaultUserId: string | null;
  /** Must call the owning domain's current source and action policy for this
   * Human; company membership/repair permission alone is not enough. */
  canReadAndOwnUnderNativePolicy(userId: string): Promise<boolean>;
  /** Present only for a pre-existing, explicitly configured native responder
   * group. Generic manager/admin capability cannot satisfy this fallback. */
  explicitNativeFallbackGroupIsAuthorized?: () => Promise<boolean>;
}): Promise<boolean> {
  const candidates = [...new Set([input.canonicalOwnerUserId, input.companyDefaultUserId].filter(
    (userId): userId is string => Boolean(userId),
  ))];
  for (const userId of candidates) {
    if (await input.canReadAndOwnUnderNativePolicy(userId)) return true;
  }
  return Boolean(await input.explicitNativeFallbackGroupIsAuthorized?.());
}
