# Ordered ACP Human-comment Run2 notice contract

Read-only trace on003404c031dad874db43aa1ad8c07e80568bdd17; all eight route/recovery/policy/UI owner files below are byte-identical to actual failing62ce903. This proves expected owner behavior for these fixture inputs, not an observed pair of DOM comment IDs. No browser/DB/SDK action ran.

## 1. Exact fixture preconditions

`acp-stop-continuation.spec.ts:19–40`: fresh company, one assigned Task, no blocker list/other Tasks/pause/monitor; status todo triggers Run1. First helper sees its retained unavailable notice and expands it before Send. Recovery writes Task blocked BEFORE adding that system comment (`recovery/service.ts:3963–3969,4083–4103`). Thus the ordinary Human Send operates on blocked/no-first-class-blocker Task. It is a board browser comment with no Agent run header, not an Agent's self-comment. Composer Stop's second call has the same Human-comment path. Legacy continuation's single helper call follows a distinct process_lost source Run, not an earlier same-cause unavailable action.

## 2. Ordinary Human comment implicitly reopens blocked assigned Task

`routes/issues.ts:2336–2383`, `shouldImplicitlyMoveCommentedIssueToTodo`:

    if (input.actorType !== "user") return false;
    if (!isClosedIssueStatus(input.issueStatus) && input.issueStatus !== "blocked") return false;
    if (typeof input.assigneeAgentId !== "string" || input.assigneeAgentId.length === 0) return false;
    return true;

The preceding guard excludes Agent self-run comments. This fixture's normal Human comment matches. POST-comments at18249–18267 invokes that exact function in `effectiveMoveToTodoRequested`; no blockers were created by this fixture or configuration-incomplete escalation (only a board-owned recovery action).

## 3. Commit todo, then CANCEL old action before enqueueing Run2

`routes/issues.ts:18337–18362`:

    if (effectiveMoveToTodoRequested && (isClosed || (isBlocked && !hasUnresolvedFirstClassBlockers) || shouldResumeInProgressScheduledRetry)) {
      const reopenedIssue = await svc.update(id, { status: "todo" });
      ...
      reopened = isClosed || (isBlocked && !hasUnresolvedFirstClassBlockers);
      reopenFromStatus = reopened ? issue.status : null;
      currentIssue = reopenedIssue;

`routes/issues.ts:18801–18817` awaits revalidation BEFORE starting its async wake block:

    await revalidateActiveSourceRecoveryAfterCommittedWrite({
      issue: currentIssue, trigger: "comment", actor,
      statusChanged: reopened || scheduledRetrySupersededByComment,
      resumeRequested: resumeRequested === true, reopened,
      blockedToTodoRecovery: reopened && reopenFromStatus === "blocked" && currentIssue.status === "todo",
    });
    void (async () => { ... wakeups ... })();

`classifySourceRecoveryRevalidation` at4442 returns immediately for this exact true flag:

    if (input.blockedToTodoRecovery === true)
      return "Recovery action became stale because the source issue was manually moved from blocked to todo.";

`revalidateActiveSourceRecovery` at4564–4570 then AWAITS:

    recoveryActionsSvc.resolveActiveForIssue({ companyId, sourceIssueId, actionId,
      status: "cancelled", outcome: "cancelled", resolutionNote });

`issue-recovery-actions.ts:467–502` updates only the exact active action, setting status cancelled. If it is already inactive there is no active old action to dedupe against. Only the AFTER-commit wrapper catches actual failures, logging exact warning `failed to revalidate recovery action after committed issue write`; that warning is ABSENT in the authentic complete old62 job log. A storage/revalidation failure would be a real owner failure, not intended dedupe semantics.

## 4. Run2 wake does not opt out of immediate recovery

After the awaited cancellation, `routes/issues.ts:18930–18957` enqueues reason `issue_reopened_via_comment` with the SAME Task/comment IDs and reopenedFrom; no goalControlRequestId/resumeSessionGoalHeartbeat is added. Heartbeat setup failure calls `releaseIssueExecutionAndPromote` at26868 with suppressImmediateRecovery based ONLY on those absent goal fields. That owner calls wakeQueue.releaseIssueExecution (27137), then applies its effects.

## 5. Configuration failure is blocked via the existing recovery port

`modules/wake-queue/domain/policy.ts:414–427` makes isConfigurationIncompleteFailedRun a shouldBlockImmediately case and returns `{kind:"blocked", notice:"configuration_incomplete"}` (unless an existing live path/explicit blocker/pause/monitor supersedes it; this fresh fixture has none). `application/use-cases.ts:971–977` calls recovery.escalateStrandedAssignedIssue with the exact finishing run and notice kind. Heartbeat's port adapter9869–9882 rereads that Run and passes its actual payload to buildConfigurationIncompleteRecoveryNoticeSeed.

## 6. New action, hence a NEW comment carrying Run2 metadata

`recovery/service.ts:2512` upsertSourceScoped targets same company/Task. `issue-recovery-actions.ts:293` looks up ACTIVE actions only (156–174). The old action was cancelled BEFORE the Run2 enqueue. With no active prior action,450–455 inserts a new action with a new UUID. The same-cause dedupe branch is not applicable here.

`recovery/service.ts:4049–4103` allows configuration-incomplete escalation comments and dedupes by that NEW recoveryAction.id (`noticeMetadataReferencesRecoveryAction` or body marker). The old Run1 comment refers to the old action and cannot satisfy this dedupe. It adds the system comment with `escalationNotice.metadata`. `stranded-notice.ts:238–248` constructs it from the exact latestRun:

    metadata: { version: 1, sourceRunId: input.sourceRun?.id ?? null, sections }

Its raw presentation title is Configuration incomplete. Therefore requiring the current Run2's retained notice is correct for this Human-reopen fixture. Repeated internal same-cause failures WITHOUT this Human blocked→todo cancellation may legitimately retain an old notice; that is a different path and must not be assumed here. The legacy helper caller instead starts with process_lost; configuration-incomplete's supersedeOnIdentityChange also prevents reuse of a different-cause action.

## 7. Stable rendered identity, unchanged missing-link failure

The existing adapter uses comment.id/renderKey; TaskChatThreadView:359–363/379–383 emits `id=comment-<item.id>`. The candidate chooses the exact current Task/company/system/configuration record by metadata.sourceRunId and then this existing DOM wrapper. No old-notice fallback, new product field or fabricated comment. If any normal-path contract above fails to produce the current notice, the test fails rather than silently validating the old attempt.

The original helper's dynamic `.last()` and one-time expanded check allow the old expanded notice to satisfy initial lookup while a later collapsed same-title notice becomes `.last()`. Actual old62 Run2 detailGET15.063 precedes commentsGET15.122; failure at20.411 is consistent with this race, but exact DOM interleaving remains unobserved without the artifact.
