#!/usr/bin/env bash
set -u
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH
NAME=github-known-object-etag-followup-r1-20261030
OUT=/workspace/v10-preparation
ROOT=/workspace/v10-dep-qualification
for suffix in source-pins.json snapshot.log snapshot.exit syntax.log syntax.exit test.log test.exit exit runner.txt; do
  if [[ -e "$OUT/$NAME-$suffix" || -e "$OUT/$NAME.$suffix" ]]; then
    echo "attempt artifact already exists: $NAME" >&2
    exit 73
  fi
done
printf 'timeout_seconds=300\ntest_file=src/__tests__/external-objects-service.test.ts\n' > "$OUT/$NAME-runner.txt"
python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$OUT/$NAME-source-pins.json" > "$OUT/$NAME-snapshot.log" 2>&1
snap=$?
printf '%s\n' "$snap" > "$OUT/$NAME-snapshot.exit"
if [[ "$snap" -ne 0 ]]; then printf '%s\n' "$snap" > "$OUT/$NAME.exit"; exit "$snap"; fi
node /workspace/v10-preparation/check-snapshot-syntax.cjs "$OUT/$NAME-source-pins.json" > "$OUT/$NAME-syntax.log" 2>&1
syntax_rc=$?
printf '%s\n' "$syntax_rc" > "$OUT/$NAME-syntax.exit"
if [[ "$syntax_rc" -ne 0 ]]; then printf '%s\n' "$syntax_rc" > "$OUT/$NAME.exit"; exit "$syntax_rc"; fi
cd "$ROOT/server"
timeout 300s ../node_modules/.bin/vitest run src/__tests__/external-objects-service.test.ts --maxWorkers=1 --reporter=verbose > "$OUT/$NAME-test.log" 2>&1
run_rc=$?
printf '%s\n' "$run_rc" > "$OUT/$NAME-test.exit"
if [[ "$run_rc" -eq 0 ]]; then final_rc=0; else final_rc="$run_rc"; fi
printf '%s\n' "$final_rc" > "$OUT/$NAME.exit"
exit "$final_rc"
