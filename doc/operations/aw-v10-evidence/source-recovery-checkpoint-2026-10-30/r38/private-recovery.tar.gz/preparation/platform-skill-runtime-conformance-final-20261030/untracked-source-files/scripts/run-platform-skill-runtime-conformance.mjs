#!/usr/bin/env node
import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const CONTRACT_PATH = "evals/platform-skill/runtime-conformance.json";
const RELEASE_PATH = "skills-releases/blentera-platform/releases.json";
const sha256 = (value) => createHash("sha256").update(value).digest("hex");

function parseArgs(args) {
  const options = { profiles: [], dryRun: false, evidenceDir: null };
  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index];
    if (arg === "--profile") options.profiles.push(args[++index]);
    else if (arg === "--dry-run") options.dryRun = true;
    else if (arg === "--evidence-dir") options.evidenceDir = args[++index];
    else if (arg === "--help") options.help = true;
    else throw new Error(`Unknown argument: ${arg}`);
  }
  if (options.profiles.some((profile) => !profile)) throw new Error("--profile requires a profile id");
  if (options.evidenceDir && (options.evidenceDir.startsWith("/") || path.resolve(ROOT, options.evidenceDir) === ROOT ||
      !path.resolve(ROOT, options.evidenceDir).startsWith(`${ROOT}${path.sep}`)))
    throw new Error("Evidence directory must be repo-relative and remain inside the repository");
  return options;
}

async function file(pathname) {
  return readFile(path.resolve(ROOT, pathname));
}

async function loadContract() {
  return JSON.parse((await file(CONTRACT_PATH)).toString("utf8"));
}

export function validateContract(contract) {
  if (contract.contract !== "v10-platform-skill-cross-runtime-conformance") throw new Error("Unexpected runtime conformance contract id");
  const scenarioIds = new Set(contract.scenarios.map(({ id }) => id));
  if (scenarioIds.size !== contract.scenarios.length || !scenarioIds.size) throw new Error("Scenario IDs must be nonempty and unique");
  const profiles = new Set();
  for (const profile of contract.profiles) {
    if (profiles.has(profile.id)) throw new Error(`Duplicate profile ${profile.id}`);
    profiles.add(profile.id);
    if (!Array.isArray(profile.implementationSources) || profile.implementationSources.length === 0)
      throw new Error(`${profile.id} must pin the implementation source it claims`);
    if (profile.exactInstalledVersion !== null && profile.qualification !== "externally-qualified")
      throw new Error(`${profile.id} has a version claim without external qualification`);
    const covered = new Set();
    for (const suite of profile.suites) {
      for (const id of suite.scenarios) {
        if (!scenarioIds.has(id)) throw new Error(`${profile.id} references unknown scenario ${id}`);
        covered.add(id);
      }
      if (!suite.path || !suite.selection || !suite.config) throw new Error(`${profile.id} has an incomplete test suite record`);
    }
    profile.sourceCoverage = [...scenarioIds].map((id) => ({ id, coveredBySourceTests: covered.has(id) }));
    profile.commonSuiteComplete = profile.sourceCoverage.every(({ coveredBySourceTests }) => coveredBySourceTests);
    if (profile.implementation === "no-common-skill-delivery-driver" && profile.suites.length)
      throw new Error(`${profile.id} cannot claim suites without a delivery driver`);
    if (profile.qualification !== "externally-qualified" && !/unqualified|not-GA|not_GA/i.test(profile.qualification))
      throw new Error(`${profile.id} must remain unqualified until external evidence is reviewed`);
  }
  return contract;
}

export async function validateSuites(contract) {
  const pins = new Map();
  for (const profile of contract.profiles) {
    for (const sourcePath of profile.implementationSources) {
      const source = await file(sourcePath);
      pins.set(sourcePath, sha256(source));
    }
    for (const suite of profile.suites) {
      const source = await file(suite.path);
      const sourceText = source.toString("utf8");
      const missingAlternatives = suite.selection.split("|").filter((selection) => !sourceText.includes(selection));
      if (missingAlternatives.length) throw new Error(`${suite.path} is missing test title(s): ${missingAlternatives.join(", ")}`);
      const config = await file(suite.config);
      pins.set(suite.path, sha256(source));
      pins.set(suite.config, sha256(config));
    }
  }
  return Object.fromEntries([...pins].sort(([left], [right]) => left.localeCompare(right)));
}

export function parseTestSummary(output) {
  const line = output.match(/^\s*Tests\s+(.+?)\s+\((\d+)\)\s*$/m);
  if (!line) return { passed: 0, failed: 0, skipped: 0, todo: 0, total: 0, parsed: false };
  const counts = Object.fromEntries([...line[1].matchAll(/(\d+)\s+(passed|failed|skipped|todo|pending)/g)]
    .map(([, count, name]) => [name === "pending" ? "todo" : name, Number(count)]));
  const summary = { passed: counts.passed ?? 0, failed: counts.failed ?? 0, skipped: counts.skipped ?? 0,
    todo: counts.todo ?? 0, total: Number(line[2]), parsed: true };
  if (summary.passed + summary.failed + summary.skipped + summary.todo !== summary.total)
    return { ...summary, parsed: false };
  return summary;
}

function commandFor(suite) {
  return ["pnpm", ["exec", "vitest", "run", "--config", suite.config, suite.path, "--testNamePattern", suite.selection.replaceAll("|", "|")]];
}

async function runProfile(profile, sourcePins, options) {
  const results = [];
  for (const suite of profile.suites) {
    const [command, args] = commandFor(suite);
    const result = options.dryRun
      ? { status: 0, stdout: "", stderr: "" }
      : spawnSync(command, args, { cwd: ROOT, encoding: "utf8", env: { ...process.env, VITEST_MAX_THREADS: "1" } });
    const testSummary = parseTestSummary(result.stdout ?? "");
    results.push({
      suite: suite.path,
      config: suite.config,
      selection: suite.selection,
      command: [command, ...args],
      sourceSha256: sourcePins[suite.path],
      configSha256: sourcePins[suite.config],
      exitCode: result.status ?? 1,
      testSummary,
      stdout: result.stdout ?? "",
      stderr: result.stderr ?? result.error?.message ?? "",
    });
  }
  return {
    profile: profile.id,
    runtime: profile.runtime,
    implementation: profile.implementation,
    qualification: profile.qualification,
    exactInstalledVersion: profile.exactInstalledVersion,
    commonSuiteComplete: profile.commonSuiteComplete,
    sourceCoverage: profile.sourceCoverage,
    suites: results,
    localSourceSuitesPassed: !options.dryRun && results.length > 0 && results.every(({ exitCode, testSummary }) => exitCode === 0 && testSummary.parsed && testSummary.passed > 0 && testSummary.failed === 0),
    sourceSuitesExecuted: !options.dryRun,
    externalQualification: "not-run; exact installed runtime/profile evidence and Human owner review are required",
  };
}

async function main() {
  const options = parseArgs(process.argv.slice(2));
  if (options.help) {
    console.log("Usage: node scripts/run-platform-skill-runtime-conformance.mjs [--profile ID] [--dry-run] [--evidence-dir repo/relative/path]");
    return 0;
  }
  const contract = validateContract(await loadContract());
  const sourcePins = await validateSuites(contract);
  const selected = options.profiles.length
    ? contract.profiles.filter(({ id }) => options.profiles.includes(id))
    : contract.profiles.filter(({ suites }) => suites.length > 0);
  if (!selected.length || selected.length !== new Set(options.profiles).size && options.profiles.length)
    throw new Error(`Unknown or unavailable profile id: ${options.profiles.join(", ")}`);
  const releaseBytes = await file(RELEASE_PATH);
  const releases = JSON.parse(releaseBytes.toString("utf8"));
  const currentRelease = releases.at(-1);
  if (!currentRelease) throw new Error("No immutable Platform Skill release is registered");

  const profiles = [];
  for (const profile of selected) profiles.push(await runProfile(profile, sourcePins, options));
  const report = {
    schemaVersion: 1,
    contract: contract.contract,
    generatedAt: new Date().toISOString(),
    mode: options.dryRun ? "dry-run-not-executed" : "local-source-tests-only",
    repoRevision: spawnSync("git", ["rev-parse", "HEAD"], { cwd: ROOT, encoding: "utf8" }).stdout.trim(),
    dependencies: { node: process.version, pnpm: spawnSync("pnpm", ["--version"], { cwd: ROOT, encoding: "utf8" }).stdout.trim() },
    sourcePins: { contract: sha256(await file(CONTRACT_PATH)), releaseRegistry: sha256(releaseBytes), sourceTestConfigAndImplementationFiles: sourcePins },
    release: {
      skillKey: currentRelease.skillKey,
      version: currentRelease.id,
      digest: currentRelease.contentDigest,
      sourceSha: currentRelease.sourceSha,
      operationManifestHash: currentRelease.operationManifestHash,
      toolCatalogContractHash: currentRelease.toolCatalogContractHash,
      compatibilityDeclarationIsExternalQualification: false,
      supersedes: currentRelease.supersedes ?? null,
    },
    releaseComparison: {
      championVersion: currentRelease.supersedes ?? null,
      candidateVersion: currentRelease.id,
      status: "champion-challenger evaluation is not run by this source-conformance harness",
      requiredBeforePromotion: ["paired evaluation results", "adversarial and recovery results", "complete applicable runtime conformance", "Human platform-owner review", "staged rollout and rollback evidence"],
    },
    profiles,
    qualificationResult: options.dryRun
      ? "source-contract-valid; runtime-tests-not-run; runtime-remains-unqualified"
      : profiles.every(({ commonSuiteComplete, localSourceSuitesPassed }) => commonSuiteComplete && localSourceSuitesPassed)
        ? "source-suites-green-only; runtime-remains-unqualified"
        : "incomplete-or-failing-source-conformance; runtime-remains-unqualified",
  };
  if (!options.dryRun || options.evidenceDir) {
    const evidenceDir = options.evidenceDir ?? `doc/operations/aw-v10-evidence/platform-skill-runtime-conformance-${new Date().toISOString().slice(0, 10)}`;
    await mkdir(path.resolve(ROOT, evidenceDir), { recursive: true });
    await writeFile(path.resolve(ROOT, evidenceDir, `${profiles.map(({ profile }) => profile).join("+")}-report.json`), `${JSON.stringify(report, null, 2)}\n`);
  }
  console.log(JSON.stringify({ qualificationResult: report.qualificationResult, profiles: profiles.map(({ profile, commonSuiteComplete, localSourceSuitesPassed }) => ({ profile, commonSuiteComplete, localSourceSuitesPassed })), evidenceDir: options.evidenceDir ?? (!options.dryRun ? `doc/operations/aw-v10-evidence/platform-skill-runtime-conformance-${new Date().toISOString().slice(0, 10)}` : null) }, null, 2));
  return options.dryRun || report.qualificationResult === "source-suites-green-only; runtime-remains-unqualified" ? 0 : 2;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().then((code) => { process.exitCode = code; }).catch((error) => {
    console.error(error instanceof Error ? error.stack : String(error));
    process.exitCode = 1;
  });
}
