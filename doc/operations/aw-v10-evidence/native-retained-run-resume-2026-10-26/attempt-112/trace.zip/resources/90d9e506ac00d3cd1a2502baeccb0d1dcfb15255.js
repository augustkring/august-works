import{t as r}from"./createLucideIcon-BqxdEa8D.js";var t=[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]],o=r("chevron-right",t);export{o as t};
