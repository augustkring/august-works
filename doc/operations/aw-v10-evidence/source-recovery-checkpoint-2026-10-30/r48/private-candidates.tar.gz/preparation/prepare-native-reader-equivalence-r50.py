from pathlib import Path
import hashlib,json,difflib
r=Path('/workspace/blentera-v10');o=Path('/workspace/v10-preparation/native-reader-equivalence-r50-candidate');rel='server/src/services/native-direct-input.ts';a=(r/rel).read_text();s=a
needle='function deferNativeSourceReaderCheck(scope: NativeSourceReadScope, input: {';assert needle in s
helper='''// These are exactly the current-reader and workspace checks consumed by the
// final grouped pass. Receipt membership, source bodies and temporal bindings
// remain validated against the original full source sets before deferral.
function nativeFinalSourceReaderIdentity(set: { runId: string; policy: NativePayloadSourcePolicy;
  inputs: NativePayloadSourceInput[] }): string {
  const unique = (ids: string[]) => [...new Set(ids)].sort();
  const sources = set.inputs;
  return nativeSha256({
    projectIds: unique([...set.policy.projectIds, ...sources.flatMap(source =>
      source.kind === "project" || source.kind === "project_workspace" ? [source.projectId] : [])]),
    issueIds: unique([...set.policy.issueIds, ...sources.flatMap(source => source.kind === "task" ? [source.issueId] : [])]),
    memoryIds: unique([...set.policy.memoryIds, ...sources.flatMap(source => source.kind === "memory" ? [source.memoryId] : [])]),
    foundationRevisionIds: unique([...set.policy.foundationRevisionIds, ...sources.flatMap(source =>
      source.kind === "foundation_revision" ? [source.revisionId] : [])]),
    runIds: unique([...set.policy.runIds, ...sources.flatMap(source =>
      source.kind === "workspace_metadata" || source.kind === "worker_model_dispatch" ||
      source.kind === "conversation_model_dispatch" || source.kind === "native_task_wake" ||
      source.kind === "tool_result" || source.kind === "retained_run" ? [source.runId] : [])]),
    contextIds: unique(sources.flatMap(source => source.kind === "context" ? [source.manifestId] : [])),
    runtimeInstructions: unique(sources.flatMap(source => source.kind === "runtime_instructions"
      ? [nativeSha256({ runId: set.runId, source })] : [])),
    workspaceSources: unique(sources.flatMap(source => source.kind === "workspace_metadata" ? [nativeSha256(source)] : [])),
  });
}
'''
s=s.replace(needle,helper+needle,1)
s=s.replace('''  const setKey = nativeSha256(set);
  // Record actual use even when the owning context already deduplicated it.
  recordNativeProofReaderSet(scope, `${key}:${setKey}`, { companyId: input.companyId, actor: input.actor, ...set });''','''  const setKey = nativeFinalSourceReaderIdentity(set);
  // Proof provenance retains the complete original identity even when the
  // final reader queue already has an equivalent set of current checks.
  recordNativeProofReaderSet(scope, `${key}:${nativeSha256(set)}`, { companyId: input.companyId, actor: input.actor, ...set });''',1)
p=o/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);(o/'candidate.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)));(o/'manifest.json').write_text(json.dumps({rel:{'priorSha256':hashlib.sha256(a.encode()).hexdigest(),'candidateSha256':hashlib.sha256(s.encode()).hexdigest()}},indent=2))
