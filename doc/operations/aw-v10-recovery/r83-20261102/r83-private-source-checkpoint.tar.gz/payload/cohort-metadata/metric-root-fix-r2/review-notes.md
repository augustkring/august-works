# Source review notes

At Main `62ce903dd6d870675491503d7407d33537f8490d`, the metric case provides a `configureHeartbeat` callback whose body performs only instance-setting, governance, metric, and issue setup and ends with `return {}`. In `server/src/__tests__/helpers/managed-native-conversation-frame.ts`, `sandboxRelay` defaults to true (line 158); `prepareNativeRuntimeContext` runs at lines 214–214 before provider profile discovery/sealing (lines 215 onward); `configureHeartbeat` is then invoked at lines 498–500 to supply the custom sandbox runtime. The callback's empty return replaces the authenticated Sandbox host that the helper would otherwise configure.

The candidate moves the unchanged setup body to `prepareNativeRuntimeContext` and removes only the empty return. It leaves the model/tool/result/source-receipt assertions, timeouts, and paid transport guards unchanged. This is a source-backed proposed fix only; no tests, typecheck, or SDK execution was run.
