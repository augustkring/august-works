/** Admission policy for paid Native provider transports. */
export const NATIVE_PAID_ADMISSION_OWNER = "Managed model gateway owner";
export const NATIVE_PAID_ADMISSION_REASON = "paid_transport_unqualified";

export class NativePaidTransportAdmissionError extends Error {
  readonly code = "configuration_incomplete";
  readonly owner = NATIVE_PAID_ADMISSION_OWNER;
  readonly resultJson: Record<string, unknown>;
  readonly provider: string;

  constructor(provider: string, binding?: { companyId: string; agentId: string }) {
    super(
      "This runtime is not available for managed model calls. Choose an available runtime in Runtime settings.",
    );
    this.name = "NativePaidTransportAdmissionError";
    this.provider = provider;
    this.resultJson = {
      configurationIncomplete: {
        reason: NATIVE_PAID_ADMISSION_REASON,
        owner: NATIVE_PAID_ADMISSION_OWNER,
        provider,
        companyId: binding?.companyId ?? null,
        agentId: binding?.agentId ?? null,
        actionUrl: binding?.agentId ? `/agents/${binding.agentId}/runtime` : null,
      },
    };
  }
}

/** Run before resolving a provider-bound AI Connection into Native env. A
 * direct connection binding is a CLI credential path, not a server reservation
 * route. OpenCode remains a candidate because its route is checked again
 * against the execution target and current manifest by RuntimeControl. */
export function assertNativePaidTransportCandidate(input: {
  provider: string;
  serverOwnedDraft?: boolean;
  aiConnectionBound?: boolean;
}): void {
  if (input.aiConnectionBound) {
    throw new NativePaidTransportAdmissionError(`${input.provider} direct AI Connection`);
  }
  if (input.provider === "aw_text_only" && input.serverOwnedDraft) return;
  if (input.provider === "opencode") return;
  throw new NativePaidTransportAdmissionError(input.provider);
}

/** Final launch guard. A server-selected Sandbox target is the only Native
 * OpenCode launch route that enters RuntimeControl's existing current-source,
 * manifest, model-profile and typed-credential checks. Caller environment
 * values are deliberately not treated as admission evidence. */
export function assertNativePaidTransportAdmitted(input: {
  provider: string;
  adapterType?: string;
  serverOwnedDraft?: boolean;
  companyId: string;
  agentId: string;
  useRunnerd?: boolean;
  backendDriverKind?: string;
  executionTarget?: { kind?: string; transport?: string } | null;
}): void {
  if (input.provider === "aw_text_only" && input.adapterType === "paperclip_runner" && input.serverOwnedDraft) return;
  if (input.adapterType === "paperclip_runner" && input.provider === "opencode" &&
      input.backendDriverKind === "opencode_server" && input.useRunnerd === true &&
      input.executionTarget?.kind === "remote" && input.executionTarget.transport === "sandbox") return;
  throw new NativePaidTransportAdmissionError(input.provider, input);
}
