# Private Resource 0565 candidate

This directory is intentionally not imported by the Experience service. It is an isolated implementation candidate for the approved responsibility cursor/pointer architecture. The matching PostgreSQL integration test is `server/src/__tests__/private-0565-responsibility-scan.integration.test.ts`.

Do not add migration journal entries, expose candidate pointers to callers, or wire a scheduler before the native metadata adapters and current per-domain authorization readers for all §17 classes are ready and Resource 0564 has been serialized. Candidate IDs and source versions are trusted-server metadata only; no public result may include them without a fresh domain-owner read and current source-version check.

## Classification and safe states

Classification is recomputed with the current native read and membership proof. Uncovered active material objects are `MUST_REASSIGN`; paused Agents, Routines, and Experiments may be `CAN_BE_UNOWNED_TEMPORARILY` because those native states already stop their work. A configured Platform Support responder group is `CAN_FALL_BACK_TO_AUTHORIZED_GROUP`, but tenant case rows never become cards when that group is missing; case visibility still requires the case owner's customer getter. `MUST_REVOKE` credentials and personal grants stay in the synchronous native offboarding path and never enter this pointer cache.

## Tenant contacts

Security and support/incident contacts are separate optional company settings. The private owner-only, no-store contact reader returns only active verified same-company Human choices. A contact label grants no permissions. Generic Company list/get/update responses exclude both contact IDs, and native offboarding clears them in the same revocation transaction before best-effort queueing.
