from pathlib import Path
import hashlib,json,difflib
r=Path('/workspace/blentera-v10');o=Path('/workspace/v10-preparation/native-reader-coverage-r54-candidate');rel='server/src/services/native-direct-input.ts';a=(r/rel).read_text();s=a
start=s.index('      const coversRequiredSets =');end=s.index('      if (siblingProof && prefixCoversProof',start)
s=s[:start]+'''      const prefixCoversProof = siblingProof && (siblingProof.requiredSets ?? [siblingProof]).every(set =>
        set.inputs.every(required => cover.inputs.some(candidate => isDeepStrictEqual(candidate, required))) &&
        (Object.keys(cover.policy) as (keyof NativePayloadSourcePolicy)[]).every(key =>
          set.policy[key].every(id => cover.policy[key].includes(id))));
'''+s[end:]
needle='''      // Producer receipt/capture selection precedes the frame; retain that
      // exact current row too so a later public invocation must reload it.
      recordNativeMutableSourceRow(scope, "run", input.companyId, producerRun);
''';assert needle in s;s=s.replace(needle,'',1)
start=s.index('        if (siblingCompleted && siblingProofKey) {');end=s.index('\n      }\n      continue;',start)
s=s[:start]+'''        if (siblingCompleted && siblingProofKey && siblingToolSourceProofs.size < 512)
          siblingToolSourceProofs.set(siblingProofKey, { descendants: siblingFrame.descendants, mutableSources: siblingFrame.mutableSources,
            policy: producerEntry!.policy, inputs: producerEntry!.inputs, requiredSets: producerClosures,
            ...(siblingFrame.readerSelection?.complete ? { readerSets: new Map(siblingFrame.readerSelection.sets) } : {}) });'''+s[end:]
s=s.replace('''      // Keep each original full prefix for receipt/evidence checks. Completed
      // descendant proofs may also live in this sealed invocation's ancestry;
      // never replace their saved prefixes with a sliced union.''','''      // This sibling ledger stays local to the component traversal. Keep
      // every original full prefix for receipt/evidence checks; never replace
      // those prefixes with a sliced union.''',1)
start=s.index('function nativeFinalSourceReaderIdentity(');end=s.index('function deferNativeSourceReaderCheck(',start);f=s[start:end]
f=f.replace('function nativeFinalSourceReaderIdentity(','function nativeFinalSourceReaderChecks(',1).replace('inputs: NativePayloadSourceInput[] }): string {','inputs: NativePayloadSourceInput[] }) {',1).replace('  return nativeSha256({','  return {',1)
assert f.endswith('  });\n}\n');f=f[:-len('  });\n}\n')]+'  };\n}\n';s=s[:start]+f+s[end:]
s=s.replace('  const setKey = nativeFinalSourceReaderIdentity(set);','  const checks = nativeFinalSourceReaderChecks(set);\n  const setKey = nativeSha256(checks);',1)
needle='''  if (!pending.sets.has(setKey)) {
    nativeSourceReadWork(scope, "deferNativeSourceReaderCheck:388");''';assert needle in s
s=s.replace(needle,'''  const alreadyQueued = pending.sets.has(setKey) || pending.sets.size > 0 && (() => {
    const queued = [...pending.sets.values()].map(nativeFinalSourceReaderChecks);
    return (Object.keys(checks) as (keyof typeof checks)[]).every(kind =>
      checks[kind].every(value => queued.some(existing => existing[kind].includes(value))));
  })();
  if (!alreadyQueued) {
    nativeSourceReadWork(scope, "deferNativeSourceReaderCheck:388");''',1)
s=s.replace('''    // If the set is requested after a prior final pass, schedule a new pass;
    // an active grouped pass already covers every known set for this actor.''','''    // Coverage records pending obligations, never an authorization result.
    // After a prior flush, even a covered subset schedules a fresh pass; an
    // active grouped pass already covers every known obligation for this actor.''',1)
assert 'toolLedger' not in s and 'ownToolReaders' not in s
p=o/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);(o/'candidate.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)));(o/'manifest.json').write_text(json.dumps({rel:{'priorSha256':hashlib.sha256(a.encode()).hexdigest(),'candidateSha256':hashlib.sha256(s.encode()).hexdigest()}},indent=2))
