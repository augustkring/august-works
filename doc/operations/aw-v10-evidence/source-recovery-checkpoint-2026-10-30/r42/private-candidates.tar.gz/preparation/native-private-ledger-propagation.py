from pathlib import Path
p=Path('/workspace/blentera-v10/server/src/services/native-direct-input.ts');s=p.read_text()
# Keep private closure proofs invocation-local, shared through explicit recursion only.
s=s.replace('currentReader?: AuthorizationActor, conversationState: "live" | "settled" = "live"): Promise<void> {','currentReader?: AuthorizationActor, conversationState: "live" | "settled" = "live",\n  siblingToolSourceProofs: NativeSiblingToolSourceProofs = new Map()): Promise<void> {',1)
# Private consumed entry and uncached signatures.
for name in ['assertNativeManagedConsumedSourceSetCurrentInScope','assertNativeManagedConsumedSourceSetCurrentUncached']:
 a=s.index('async function '+name+'(');b=s.index('): Promise<void> {',a)
 old=s[a:b];assert old.endswith('scope: NativeSourceReadScope')
 s=s[:a]+old.replace('scope: NativeSourceReadScope','scope: NativeSourceReadScope, siblingToolSourceProofs: NativeSiblingToolSourceProofs = new Map()')+s[b:]
s=s.replace('await assertNativeManagedConsumedSourceSetCurrentUncached(db, input, scope);','await assertNativeManagedConsumedSourceSetCurrentUncached(db, input, scope, siblingToolSourceProofs);')
s=s.replace('  const siblingToolSourceProofs: NativeSiblingToolSourceProofs = new Map();\n','')
# Payload entry can be called directly; its private uncached root owns a fresh ledger when absent.
s=s.replace('''  completedTaskSourceProofs?: Map<string, string>, validatedDispatchSources?: ReadonlySet<string>, siblingToolSourceProofs?: NativeSiblingToolSourceProofs): Promise<void> {''','''  completedTaskSourceProofs?: Map<string, string>, validatedDispatchSources?: ReadonlySet<string>,
  siblingToolSourceProofs: NativeSiblingToolSourceProofs = new Map()): Promise<void> {''',1)
# Private document recursive function only.
a=s.index('async function assertNativeDocumentRevisionCurrentSourceAccessInScope(');b=s.index('): Promise<void> {',a)
s=s[:a]+s[a:b].replace('scope: NativeSourceReadScope, depth: number','scope: NativeSourceReadScope, depth: number,\n  siblingToolSourceProofs: NativeSiblingToolSourceProofs = new Map()')+s[b:]
# Propagate the map in the three callers that already receive it.
for start,end in [('async function assertNativeModelOutputCaptureCurrentInScope(', '/** Revalidate a driver continuation'),('async function assertNativePayloadSourceSetCurrentUncachedInScope(', '\nfunction profileRunExecution('),('async function assertNativeDocumentRevisionCurrentSourceAccessInScope(', '\nexport interface NativeContextSourceClosure')]:
 a=s.index(start)
 try:b=s.index(end,a)
 except ValueError:b=len(s)
 chunk=s[a:b]
 # Exact call endings specific to these functions.
 chunk=chunk.replace('consumedSourceComponents, sourceSet: capture.sourceSet }, scope);','consumedSourceComponents, sourceSet: capture.sourceSet }, scope, siblingToolSourceProofs);')
 chunk=chunk.replace('capture.tool, scope, 0, input.actor, "settled");','capture.tool, scope, 0, input.actor, "settled", siblingToolSourceProofs);')
 chunk=chunk.replace('managedCapture, "write_document", scope, depth + 1, input.actor, "settled");','managedCapture, "write_document", scope, depth + 1, input.actor, "settled", siblingToolSourceProofs);')
 chunk=chunk.replace('}, scope, depth + 1);','}, scope, depth + 1, siblingToolSourceProofs);')
 chunk=chunk.replace('}, scope, 0);','}, scope, 0, siblingToolSourceProofs);')
 s=s[:a]+chunk+s[b:]
# Document proof: exact current owner guards above remain fresh; retain complete snapshot, no projected union.
a=s.index('  const snapshot = parsed.data;',s.index('async function assertNativeDocumentRevisionCurrentSourceAccessInScope('))
s=s[:a]+s[a:].replace('''  const snapshot = parsed.data;
  const policy = snapshot.policy;''','''  const snapshot = parsed.data;
  const documentProofKey = `document-node:${nativeSha256({ companyId: input.companyId, issueId: input.issueId,
    revisionId: input.revisionId, actor: input.actor, actorScope: scope.actorKey,
    memoryTemporalIdentity: scope.context.memoryTemporalIdentity, requireLatest: input.requireLatest !== false,
    depth, snapshot })}`;
  const documentProof = siblingToolSourceProofs.get(documentProofKey);
  if (documentProof && !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, documentProof.descendants)) {
    deferNativeSourceReaderCheck(scope, { companyId: input.companyId,
      runId: snapshot.inputs.find(source => source.kind === "worker_model_dispatch" || source.kind === "conversation_model_dispatch")?.runId ?? input.revisionId,
      actor: input.actor, policy: snapshot.policy, inputs: snapshot.inputs });
    for (const parent of scope.context.ancestry.frozenTaskProofStacks.get(scope.actorKey) ?? [])
      for (const descendant of documentProof.descendants) parent.descendants.add(descendant);
    scope.active.delete(activeKey);
    return;
  }
  let documentProofStack = scope.context.ancestry.frozenTaskProofStacks.get(scope.actorKey);
  if (!documentProofStack) {
    documentProofStack = [];
    scope.context.ancestry.frozenTaskProofStacks.set(scope.actorKey, documentProofStack);
  }
  const documentFrame = { visitKey: activeKey, descendants: new Set<string>() };
  documentProofStack.push(documentFrame);
  let documentCompleted = false;
  try {
  const policy = snapshot.policy;''',1)
# Finish exact document function (locate its closing from following function).
a=s.index('  const documentFrame =');b=s.index('\n}\n',a)
chunk=s[a:b]
needle='''  scope.active.delete(activeKey);
  scope.complete.add(completeKey);'''
assert chunk.count(needle)==1
chunk=chunk.replace(needle,'''  documentCompleted = true;
  scope.active.delete(activeKey);
  scope.complete.add(completeKey);
  } finally {
    if (documentProofStack.at(-1) === documentFrame) documentProofStack.pop();
    if (documentCompleted && siblingToolSourceProofs.size < 512)
      siblingToolSourceProofs.set(documentProofKey, { descendants: documentFrame.descendants,
        policy: snapshot.policy, inputs: snapshot.inputs });
  }''')
s=s[:a]+chunk+s[b:]
p.with_suffix('.propagate.tmp.ts').write_text(s)
