import { afterEach, describe, expect, it } from "vitest";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
const entries = [
  ["claude_local", "claude", () => import("../files/packages/adapters/claude-local/src/server/test.js")],
  ["codex_local", "codex", () => import("../files/packages/adapters/codex-local/src/server/test.js")],
  ["opencode_local", "opencode", () => import("../files/packages/adapters/opencode-local/src/server/test.js")],
  ["kimi_local", "kimi", () => import("../files/packages/adapters/kimi-local/src/server/test.js")],
  ["gemini_local", "gemini", () => import("../files/packages/adapters/gemini-local/src/server/test.js")],
  ["grok_local", "grok", () => import("../files/packages/adapters/grok-local/src/server/test.js")],
  ["pi_local", "pi", () => import("../files/packages/adapters/pi-local/src/server/test.js")],
  ["cursor_local", "agent", () => import("../files/packages/adapters/cursor-local/src/server/test.js")],
] as const;
const roots: string[] = [];
let restore: Record<string, string | undefined> = {};
afterEach(async () => {
  for (const [name, value] of Object.entries(restore)) value === undefined ? delete process.env[name] : process.env[name] = value;
  restore = {};
  await Promise.all(roots.splice(0).map(root => fs.rm(root, { recursive: true, force: true })));
});
describe("actual CLI environment test entries refuse inference and retain non-paid checks", () => {
  it("refuses the separate Claude ACP subscription hello login probe before child credential preparation", async () => {
    const { probeClaudeAcpSandboxLogin } = await import("../files/packages/adapters/claude-local/src/server/acp.js");
    const checks = await probeClaudeAcpSandboxLogin({ config: {}, target: null });
    expect(checks).toEqual([expect.objectContaining({ code: "paid_transport_unqualified", level: "error" })]);
  });

  it.each(entries)("%s never launches a hello prompt", async (adapterType, command, load) => {
    const root = await fs.mkdtemp(path.join(os.tmpdir(), "paid-setup-entry-")); roots.push(root);
    const bin = path.join(root, "bin"); await fs.mkdir(bin);
    const log = path.join(root, "calls.jsonl");
    const source = `#!/usr/bin/env node
const fs = require("node:fs");
const args=process.argv.slice(2);fs.appendFileSync(${JSON.stringify(log)},JSON.stringify(args)+"\\n");
if(args.includes("--version")||args.includes("-v"))console.log("99.0.0");
else if(args.includes("models")||args.includes("--list-models"))console.log("Logged in\\nModels:\\n  openai/test-model\\n  grok-test\\n");
else if(args.includes("--help"))console.log("--effort --output-format --mode --model");
else console.log("Logged in using API key");
`;
    await fs.writeFile(path.join(bin, command), source, { mode: 0o755 });
    const values = { PATH: `${bin}:${process.env.PATH}`, HOME: root, XDG_CONFIG_HOME: root,
      ANTHROPIC_API_KEY: "software-fixture-not-live", OPENAI_API_KEY: "software-fixture-not-live",
      GEMINI_API_KEY: "software-fixture-not-live", XAI_API_KEY: "software-fixture-not-live",
      CURSOR_API_KEY: "software-fixture-not-live", KIMI_MODEL_API_KEY: "software-fixture-not-live",
      KIMI_MODEL_NAME: "test-model" };
    for (const [name, value] of Object.entries(values)) { restore[name] = process.env[name]; process.env[name] = value; }
    const { testEnvironment } = await load();
    const result = await testEnvironment({ companyId: "company", adapterType,
      config: { engine: "cli", command: path.join(bin, command), cwd: root,
        model: adapterType === "claude_local" ? "claude-sonnet-4-6" : adapterType === "codex_local" ? "gpt-5" : "openai/test-model", env: values } });
    expect(result.checks.map(check => check.code)).toContain("paid_transport_unqualified");
    expect(result.status).toBe("fail");
    const calls = (await fs.readFile(log, "utf8").catch(() => "")).trim().split("\n").filter(Boolean).map(line => JSON.parse(line) as string[]);
    expect(calls.some(args => args.some(value => /hello|Respond with/i.test(value)))).toBe(false);
    expect(result.checks.some(check => /command_resolvable|cwd_valid|auth_detected|models_discovered/.test(check.code))).toBe(true);
  }, 30_000);
});
