import json, pathlib, hashlib, tarfile, shutil
from collections import defaultdict
OUT=pathlib.Path('/workspace/v10-preparation/v10-final-claim-reconciliation-candidate-r2-20261030')
PREP=pathlib.Path('/workspace/v10-preparation')
REPORT=OUT/'reconciliation.json'
SOURCE_BUNDLE=OUT/'source-bundle'
if SOURCE_BUNDLE.exists(): shutil.rmtree(SOURCE_BUNDLE)
SOURCE_BUNDLE.mkdir()
# Explicitly package every substantive preparation-workspace artifact referenced by the draft.
refs={
 '/workspace/v10-preparation/current-inherited-crosswalk-20261028':'source-bundle/cross-version/current-inherited-crosswalk-20261028.json',
 '/workspace/v10-preparation/v10-final-claim-reconciliation-candidate-r2-20261030/generator/build-v10-final-claim-reconciliation-r2.py':'source-bundle/generator/build-v10-final-claim-reconciliation-r2.py',
 '/workspace/v10-preparation/v10-final-claim-reconciliation-candidate-r2-20261030/generator/portable-refresh-v10-final-claim-reconciliation-r2.py':'source-bundle/generator/portable-refresh-v10-final-claim-reconciliation-r2.py',

 '/workspace/v10-preparation/v10-final-claim-reconciliation-candidate-r2-20261030/predecessor-claim-crosswalk.json':'source-bundle/traceability/predecessor-claim-crosswalk.json',
 '/workspace/v10-preparation/v10-final-claim-reconciliation-candidate-r2-20261030/launch-claim-matrix.json':'source-bundle/traceability/launch-claim-matrix.json',
 '/workspace/blentera-v10/doc/operations/aw-v6-evidence.md':'source-bundle/predecessors/v6-evidence.md',
 '/workspace/blentera-v10/doc/reference/blentera-v10/Blentera_Master_Build_Brief_V10_FINAL_v4.0_2026-10-18.md':'source-bundle/predecessors/v10-master-build-brief.md',
 '/workspace/blentera-v10/evals/aw-v7/pilot-readiness.json':'source-bundle/predecessors/v7-pilot-readiness.json',
 '/workspace/blentera-v10/evals/aw-v8/readiness.json':'source-bundle/predecessors/v8-readiness.json',
 '/workspace/blentera-v10/doc/operations/aw-v8-source-acceptance.md':'source-bundle/predecessors/v8-source-acceptance.md',
 '/workspace/blentera-v10/evals/aw-v9/readiness.json':'source-bundle/predecessors/v9-readiness.json',
 '/workspace/blentera-v10/doc/experience/v9/coverage.json':'source-bundle/predecessors/v9-experience-coverage.json',
 '/workspace/v10-preparation/v10-001-060-current-gap-audit-20261030.json':'source-bundle/audits/v10-001-060-current-gap-audit-20261030.json',
 '/workspace/v10-preparation/v10-169-061-120-current-gap-audit-luna-20261030.json':'source-bundle/audits/v10-061-120-current-gap-audit-luna-20261030.json',
 '/workspace/v10-preparation/v10-169-full-current-gap-audit-20261030.json':'source-bundle/audits/v10-121-169-current-gap-audit-20261030.json',
 '/workspace/v10-preparation/v10-169-full-current-gap-audit-20261030.md':'source-bundle/audits/v10-121-169-current-gap-audit-20261030.md',
 '/workspace/v10-preparation/v10-169-current-gap-audit-20261030.md':'source-bundle/audits/v10-169-current-gap-audit-20261030.md',
 '/workspace/v10-preparation/v10-169-full-current-evidence-map-20261030.json':'source-bundle/maps/v10-169-full-current-evidence-map-20261030.json',
 '/workspace/v10-preparation/v10-169-current-assessment-overlay-20261030.json':'source-bundle/maps/v10-169-current-assessment-overlay-20261030.json',
 '/workspace/v10-preparation/v10-requirement-implementation-reconciliation-candidate-current-r2-20261029.json':'source-bundle/maps/v10-requirement-implementation-reconciliation-candidate-current-r2-20261029.json',
 '/workspace/v10-preparation/v10-121-operation-coverage-refresh-20261030/README.md':'source-bundle/receipts/v10-121-operation-coverage-refresh-20261030-README.md',
 '/workspace/v10-preparation/public-openapi-contract-r1-20261028-test.exit':'source-bundle/receipts/public-openapi-contract-r1-20261028-test.exit',
 '/workspace/v10-preparation/public-openapi-contract-r1-20261028-test.log':'source-bundle/receipts/public-openapi-contract-r1-20261028-test.log',
 '/workspace/v10-preparation/root-operation-inventory-r2-20261030.exit':'source-bundle/receipts/root-operation-inventory-r2-20261030.exit',
 '/workspace/v10-preparation/root-operation-inventory-r2-20261030.log':'source-bundle/receipts/root-operation-inventory-r2-20261030.log',
 '/workspace/v10-preparation/temporal9-reader-origin-r47-20261030-test.exit':'source-bundle/receipts/temporal9-reader-origin-r47-20261030-test.exit',
 '/workspace/v10-preparation/temporal9-reader-origin-r47-20261030-test.log':'source-bundle/receipts/temporal9-reader-origin-r47-20261030-test.log',
}
replacement_paths=[
 'doc/operations/aw-v10-evidence/github-known-object-reconciliation-2026-10-30/README.md',
 'doc/operations/aw-v10-evidence/github-known-object-reconciliation-2026-10-30/qualification.tar.gz',
 'doc/operations/aw-v10-evidence/github-access-reconciliation-qualified-2026-10-30/README.md',
 'doc/operations/aw-v10-evidence/github-access-reconciliation-qualified-2026-10-30/qualification.tar.gz',
 'doc/operations/aw-v10-evidence/github-repository-access-reconciliation-2026-10-30/README.md',
 'doc/operations/aw-v10-evidence/github-repository-access-reconciliation-2026-10-30/manifest.json',
 'doc/operations/aw-v10-evidence/github-repository-access-reconciliation-2026-10-30/qualification.tar.gz',
 'doc/operations/aw-v10-evidence/github-known-object-etag-followup-2026-10-30/README.md',
 'doc/operations/aw-v10-evidence/github-known-object-etag-followup-2026-10-30/qualification.tar.gz',
]
repo_root=pathlib.Path('/workspace/blentera-v10')
replacement_receipts=[{'path':rel,'sha256':hashlib.sha256((repo_root/rel).read_bytes()).hexdigest()} for rel in replacement_paths]
historical_path='/workspace/v10-preparation/v10-069-connector-sync-r4-20261030.tar.gz'
historical_hash=hashlib.sha256(pathlib.Path(historical_path).read_bytes()).hexdigest()
historical_item={'originalPrivatePath':historical_path,'portablePath':None,'availability':'historical_navigation_only_not_bundled','originalSha256':historical_hash,'replacementReceiptLinks':replacement_receipts,'replacementScope':'Current committed GitHub reconciliation receipts cover the bounded known-object, ETag and repository-access scopes identified in V10-069. They are not byte-identical to the private archive and do not imply that every historical archive item is qualified.'}
source_map=[]
for original,bundle in refs.items():
 src=pathlib.Path(original)
 if src.is_file():
  dst=OUT/bundle; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src,dst)
  digest=hashlib.sha256(src.read_bytes()).hexdigest()
  source_map.append({'originalPrivatePath':original,'portablePath':bundle,'availability':'bundled','originalSha256':digest,'portableSha256':hashlib.sha256(dst.read_bytes()).hexdigest()})
 else:
  source_map.append({'originalPrivatePath':original,'portablePath':None,'availability':'unavailable_navigation_only','originalSha256':None})
# Rewrite private absolute refs to relative bundle references, and mark all unresolved prep refs explicitly.
report=json.load(open(REPORT))
portable_lookup={a:b for a,b in refs.items()}
unavailable=[]
def rewrite(x):
 if isinstance(x,dict):
  return {k:rewrite(v) for k,v in x.items()}
 if isinstance(x,list): return [rewrite(v) for v in x]
 if isinstance(x,str) and x.startswith('/workspace/v10-preparation/'):
  if x==historical_path:
   return 'historical navigation only: private v10-069 connector-sync r4 archive'
  if x in portable_lookup:
   return portable_lookup[x]
  if x not in {item['originalPrivatePath'] for item in unavailable}:
   unavailable.append({'originalPrivatePath':x,'portablePath':None,'availability':'unavailable_navigation_only','sha256':None})
  return f"unavailable navigation only: {pathlib.Path(x).name}"
 return x
report=rewrite(report)
for entry in report.get('sourceHashInventory',[]):
 if isinstance(entry.get('path'),str) and entry['path'].startswith('source-bundle/'):
  entry['location']='candidate_bundle'
 if entry.get('path')=='historical navigation only: private v10-069 connector-sync r4 archive':
  entry['location']='portable_source_map'; entry['state']='historical_navigation_only_not_bundled'; entry['originalPrivatePath']=historical_path; entry['sha256']=historical_hash; entry['replacementReceiptLinks']=replacement_receipts
for row in report.get('rows',[]):
 for entry in row.get('currentSourcePins',[]):
  if isinstance(entry.get('path'),str) and entry['path'].startswith('source-bundle/'):
   entry['location']='candidate_bundle'
  if entry.get('path')=='historical navigation only: private v10-069 connector-sync r4 archive':
   entry['location']='portable_source_map'; entry['state']='historical_navigation_only_not_bundled'; entry['originalPrivatePath']=historical_path; entry['sha256']=historical_hash; entry['replacementReceiptLinks']=replacement_receipts
report['portableEvidence']={
 'bundlePath':'source-bundle.tar.gz',
 'sourceMapPath':'portable-source-map.json',
 'description':'Substantive preparation-workspace maps, audits, crosswalk and referenced receipts are bundled at relative paths. Repository source and receipts remain repository-relative references. This archive does not duplicate repository source files.',
 'unavailableNavigationOnly':unavailable,
 'historicalNavigationOnly':[historical_item],
}
source_map_doc={
 'kind':'portable-source-map-for-v10-final-claim-reconciliation-candidate',
 'mapping':source_map,
 'unavailableNavigationOnly':unavailable,
 'historicalNavigationOnly':[historical_item],
 'policy':'Original private input SHA-256 values are retained for bundled files. The excluded R4 archive retains its original hash as historical navigation only; committed replacement receipts are linked for their exact scopes without claiming byte identity or full archive-content qualification. Other private paths not bundled are explicitly marked unavailable navigation only.'
}
(OUT/'portable-source-map.json').write_text(json.dumps(source_map_doc,indent=2)+'\n')
REPORT.write_text(json.dumps(report,indent=2)+'\n')
# Rebuild the minimal evidence archive from only sidecar maps/audits/crosswalk/receipts.
with tarfile.open(OUT/'source-bundle.tar.gz','w:gz') as tf:
 for p in sorted(SOURCE_BUNDLE.rglob('*')):
  if p.is_file(): tf.add(p,arcname=p.relative_to(OUT).as_posix())
# Replace report hashes and create a portable integrity manifest.
files=['README.md','reconciliation.json','predecessor-claim-crosswalk.json','launch-claim-matrix.json','portable-source-map.json','source-bundle.tar.gz','generator/build-v10-final-claim-reconciliation-r2.py','generator/portable-refresh-v10-final-claim-reconciliation-r2.py']
(OUT/'SHA256SUMS').write_text(''.join(f"{hashlib.sha256((OUT/f).read_bytes()).hexdigest()}  {f}\n" for f in files))
print('bundled',sum(1 for x in source_map if x['availability']=='bundled'),'private inputs; unavailable navigation',len(unavailable),'archive bytes',(OUT/'source-bundle.tar.gz').stat().st_size)
