"""Reclaim generated debug intermediates after the final debug preparation."""
from pathlib import Path
import hashlib
import json
import stat
import sys

root = Path(sys.argv[1]).resolve(strict=True)
assert root.parent == Path('/tmp') and root.name.startswith('blentera-final-source-rust-target-'), root
debug = root / 'debug'
assert debug.is_dir() and not debug.is_symlink()
for name in ['paperclip-runnerd', 'fake-codex-app-server', 'fake-harness']:
    f = debug / name
    assert f.is_file() and not f.is_symlink() and f.stat().st_mode & 0o111, f
def digest(f):
    return hashlib.sha256(f.read_bytes()).hexdigest()
kept = {}
for folder in [debug, debug / 'deps']:
    assert folder.is_dir() and not folder.is_symlink(), folder
    for f in folder.iterdir():
        if f.is_file() and not f.is_symlink() and f.stat().st_mode & 0o111:
            kept[str(f.relative_to(root))] = digest(f)
removed = []
for folder in [debug / 'deps', debug / '.fingerprint']:
    if not folder.exists():
        continue
    assert folder.is_dir() and not folder.is_symlink(), folder
    paths = sorted(folder.rglob('*'))
    assert not any(f.is_symlink() for f in paths), 'Refusing symlinked generated intermediates'
    for f in paths:
        s = f.lstat()
        if stat.S_ISREG(s.st_mode) and not s.st_mode & 0o111:
            removed.append({'path': str(f.relative_to(root)), 'bytes': s.st_size, 'sha256': digest(f)})
            f.unlink()
    for d in sorted([f for f in paths if f.is_dir()], key=lambda f: len(f.parts), reverse=True):
        if not any(d.iterdir()):
            d.rmdir()
for name, expected in kept.items():
    assert digest(root / name) == expected, name
Path(sys.argv[2]).write_text(json.dumps({'scope': 'rebuildable Cargo debug intermediates only; all executable artifacts retained', 'target': str(root), 'retainedExecutables': kept, 'removed': removed}, indent=2) + '\n')
print(json.dumps({'removedFiles': len(removed), 'removedBytes': sum(f['bytes'] for f in removed), 'retainedExecutables': len(kept)}))
