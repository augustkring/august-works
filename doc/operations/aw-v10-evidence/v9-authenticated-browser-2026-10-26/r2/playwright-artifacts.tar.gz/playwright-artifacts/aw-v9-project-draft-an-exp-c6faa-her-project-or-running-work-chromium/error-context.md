# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: aw-v9-project-draft.spec.ts >> an explicit project draft recovers a lost Native acknowledgement after reload through reads without creating another project or running work
- Location: tests/e2e/aw-v9-project-draft.spec.ts:14:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'Home', exact: true, level: 1 })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByRole('heading', { name: 'Home', exact: true, level: 1 })

```

```yaml
- link "Skip to Main Content":
  - /url: "#main-content"
- complementary:
  - button "Open Disposable Native project-draft qualification organization switcher": D Disposable Native project-draft qualification
  - navigation:
    - text: Visning
    - combobox "Visning":
      - option "Medlem"
      - option "Leder" [selected]
      - option "Administrator"
      - option "Sikkerhedsadministrator"
    - link "Hjem":
      - /url: /DISAAAAAAAAA/dashboard
    - link "Kræver dig":
      - /url: /DISAAAAAAAAA/needs-you
    - link "Arbejde":
      - /url: /DISAAAAAAAAA/work
    - link "Agenter":
      - /url: /DISAAAAAAAAA/agents
    - link "Apps":
      - /url: /DISAAAAAAAAA/apps
    - link "Indsigter":
      - /url: /DISAAAAAAAAA/insights
    - link "Avanceret":
      - /url: /DISAAAAAAAAA/advanced
    - button "Spørg Blentera"
    - link "Hjælp / Support":
      - /url: /DISAAAAAAAAA/company/help
- button "Open account menu": BR Browser product reviewer
- separator "Resize sidebar"
- region "Globale funktioner":
  - button "Spørg Blentera"
  - text: Sprog
  - combobox "Sprog":
    - option "English"
    - option "Dansk" [selected]
  - link "Hjælp / Support":
    - /url: /DISAAAAAAAAA/company/help
  - link "Kontakt support":
    - /url: mailto:support@blentera.com
  - link "Brugerkonto":
    - /url: /DISAAAAAAAAA/company/settings/instance/profile
- main:
  - heading "Hjem" [level=1]
  - button "Spørg Blentera"
  - paragraph: Der er ikke noget, der kræver din opmærksomhed lige nu.
```

# Test source

```ts
  1   | import { createRequire } from "node:module";
  2   | import { expect, test, type APIResponse } from "@playwright/test";
  3   | const axePath = createRequire(import.meta.url).resolve("axe-core/axe.min.js");
  4   | async function json(response: APIResponse) {
  5   |   expect(response.ok(), `${response.status()}: ${await response.text()}`).toBe(
  6   |     true,
  7   |   );
  8   |   return response.json();
  9   | }
  10  | 
  11  | // Original authenticated-project APIs and current creator-bound receipt. Only
  12  | // the transport of the single committed POST and first receipt GET is aborted.
  13  | // This is software evidence, not hosted identity or live business acceptance.
  14  | test("an explicit project draft recovers a lost Native acknowledgement after reload through reads without creating another project or running work", async ({
  15  |   page,
  16  |   request,
  17  | }, info) => {
  18  |   test.setTimeout(120000);
  19  |   const flags = await json(
  20  |     await request.get("/api/instance/settings/experimental"),
  21  |   );
  22  |   const session = await json(await request.get("/api/auth/get-session"));
  23  |   await json(
  24  |     await request.patch("/api/instance/settings/experimental", {
  25  |       data: {
  26  |         experience_projection_v9: true,
  27  |         progressive_shell_v9: true,
  28  |         home_v9: true,
  29  |         ambient_commands_v9: true,
  30  |       },
  31  |     }),
  32  |   );
  33  |   const company = await json(
  34  |     await request.post("/api/companies", {
  35  |       data: { name: "Disposable Native project-draft qualification" },
  36  |     }),
  37  |   );
  38  |   const base = `/api/companies/${company.id}`;
  39  |   const attempts: Array<Record<string, unknown>> = [];
  40  |   let savedId: string | undefined, key: string | undefined, reads = 0;
  41  |   await page.route(`**${base}/projects?**`, async (route) => {
  42  |     if (route.request().method() !== "POST") return route.continue();
  43  |     expect(
  44  |       new URL(route.request().url()).searchParams.get("expectedActorId"),
  45  |     ).toBe(session.user.id);
  46  |     attempts.push(route.request().postDataJSON());
  47  |     expect(attempts).toHaveLength(1);
  48  |     key = attempts[0]!.idempotencyKey as string;
  49  |     const response = await route.fetch();
  50  |     const result = await json(response);
  51  |     expect(result.companyId).toBe(company.id);
  52  |     expect(result.status).toBe("planned");
  53  |     savedId ??= result.id;
  54  |     expect(result.id).toBe(savedId);
  55  |     await route.abort("failed");
  56  |   });
  57  |   await page.route(`**${base}/projects/create-receipts/**`, async (route) => {
  58  |     expect(route.request().method()).toBe("GET");
  59  |     expect(new URL(route.request().url()).searchParams.get("expectedActorId")).toBe(session.user.id);
  60  |     reads++;
  61  |     if (reads === 1) return route.abort("failed");
  62  |     await route.continue();
  63  |   });
  64  |   try {
  65  |     await page.goto(`/${company.issuePrefix}/dashboard`);
  66  |     await expect(
  67  |       page.getByRole("heading", { level: 1, name: "Home", exact: true }),
> 68  |     ).toBeVisible();
      |       ^ Error: expect(locator).toBeVisible() failed
  69  |     await page.keyboard.press("Control+k");
  70  |     await page.getByRole("combobox").fill("opret et projekt Customer Research");
  71  |     await page
  72  |       .getByRole("option", { name: "Prepare a Project", exact: true })
  73  |       .click();
  74  |     await expect(
  75  |       page.getByRole("textbox", { name: "Project name", exact: true }),
  76  |     ).toHaveValue("Customer Research");
  77  |     expect(attempts).toHaveLength(0);
  78  |     await page
  79  |       .getByRole("textbox", {
  80  |         name: "Goal or description (optional)",
  81  |         exact: true,
  82  |       })
  83  |       .fill("Private browser draft: review our customer research plan.");
  84  |     await page
  85  |       .getByRole("button", { name: "Create project", exact: true })
  86  |       .click();
  87  |     await expect(page.getByRole("alert")).toContainText(
  88  |       "We have not confirmed this project",
  89  |     );
  90  |     expect(attempts).toHaveLength(1);
  91  |     await expect(page.getByRole("textbox", { name: "Project name", exact: true })).toHaveCount(0);
  92  |     const once = await json(await request.get(`${base}/projects`));
  93  |     expect(once).toHaveLength(1);
  94  |     expect(once[0].id).toBe(savedId);
  95  |     await json(await request.patch(`/api/projects/${savedId}`, { data: { name: "Current Native research project" } }));
  96  |     const pending = await page.evaluate(() => sessionStorage.getItem("aw.v9.pending-project-receipts"));
  97  |     expect(pending).toContain(key!);
  98  |     expect(pending).not.toContain("Private browser draft");
  99  |     expect(pending).not.toContain("Customer Research");
  100 |     await page.reload();
  101 |     await expect(page.getByRole("heading", { level: 1, name: "Home", exact: true })).toBeVisible();
  102 |     await page.keyboard.press("Control+k");
  103 |     await page.getByRole("combobox").fill("create project A separate new draft");
  104 |     await page.getByRole("option", { name: "Prepare a Project", exact: true }).click();
  105 |     await expect(page.getByRole("heading", { name: "Find your project", exact: true })).toBeVisible();
  106 |     await expect(
  107 |       page.getByRole("heading", { name: "Project saved", exact: true }),
  108 |     ).toBeVisible();
  109 |     await expect(
  110 |       page.getByRole("heading", { name: "Project saved", exact: true }),
  111 |     ).toBeFocused();
  112 |     expect(attempts).toHaveLength(1);
  113 |     expect(reads).toBe(2);
  114 |     await expect(page.getByRole("dialog")).toContainText("Current Native research project");
  115 |     expect(await page.evaluate(() => sessionStorage.getItem("aw.v9.pending-project-receipts"))).toBeNull();
  116 |     const retained = await json(await request.get(`${base}/projects`));
  117 |     expect(retained).toHaveLength(1);
  118 |     expect(retained[0].id).toBe(savedId);
  119 |     expect(await json(await request.get(`${base}/issues`))).toEqual([]);
  120 |     expect(await json(await request.get(`${base}/agents`))).toEqual([]);
  121 |     const runs = await json(await request.get(`${base}/heartbeat-runs`));
  122 |     expect(Array.isArray(runs) ? runs : runs.items).toEqual([]);
  123 |     await page.setViewportSize({ width: 390, height: 844 });
  124 |     await page.addScriptTag({ path: axePath });
  125 |     expect(
  126 |       await page.evaluate(
  127 |         async () =>
  128 |           (
  129 |             await (
  130 |               window as unknown as {
  131 |                 axe: { run(scope: string): Promise<{ violations: unknown[] }> };
  132 |               }
  133 |             ).axe.run('[role="dialog"]')
  134 |           ).violations,
  135 |       ),
  136 |     ).toEqual([]);
  137 |     expect(
  138 |       await page.evaluate(
  139 |         () => document.documentElement.scrollWidth <= innerWidth,
  140 |       ),
  141 |     ).toBe(true);
  142 |     await page.screenshot({
  143 |       path: info.outputPath("v9-native-project-receipt-mobile.png"),
  144 |       fullPage: true,
  145 |     });
  146 |     await expect(
  147 |       page.getByRole("link", { name: "Open project", exact: true }),
  148 |     ).toHaveAttribute("href", new RegExp(`/projects/${savedId}$`));
  149 |   } finally {
  150 |     await json(
  151 |       await request.patch("/api/instance/settings/experimental", {
  152 |         data: {
  153 |           experience_projection_v9: flags.experience_projection_v9,
  154 |           progressive_shell_v9: flags.progressive_shell_v9,
  155 |           home_v9: flags.home_v9,
  156 |           ambient_commands_v9: flags.ambient_commands_v9,
  157 |         },
  158 |       }),
  159 |     );
  160 |   }
  161 | });
  162 | 
```