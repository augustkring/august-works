# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: pipelines-tutorial-flow.spec.ts >> Pipelines tutorial UI flow >> walks setup, intake, board moves, item detail, review queue, and learnings
- Location: tests/e2e/pipelines-tutorial-flow.spec.ts:439:3

# Error details

```
Error: list pipeline items failed: 500 {"error":"Internal server error"}
```

# Page snapshot

```yaml
- generic [ref=f6e4]:
  - link "Skip to Main Content" [ref=f6e5] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=f6e6]:
    - generic [ref=f6e7]:
      - generic [ref=f6e8]:
        - complementary [ref=f6e10]:
          - button "Open E2E Pipelines 1793061501397 organization switcher" [ref=f6e12]:
            - generic [ref=f6e13]:
              - generic [ref=f6e14]: E
              - generic "E2E Pipelines 1793061501397" [ref=f6e17]
          - navigation [ref=f6e18]:
            - generic [ref=f6e19]:
              - generic [ref=f6e20]:
                - text: View
                - combobox "View" [ref=f6e21]:
                  - option "Member"
                  - option "Manager" [selected]
                  - option "Admin"
                  - option "Security admin"
              - link "Home" [ref=f6e22] [cursor=pointer]:
                - /url: /EEPA/dashboard
              - link "Needs You" [ref=f6e28] [cursor=pointer]:
                - /url: /EEPA/needs-you
              - link "Work" [ref=f6e34] [cursor=pointer]:
                - /url: /EEPA/work
              - link "Agents" [ref=f6e40] [cursor=pointer]:
                - /url: /EEPA/agents
              - link "Apps" [ref=f6e48] [cursor=pointer]:
                - /url: /EEPA/apps
              - link "Insights" [ref=f6e58] [cursor=pointer]:
                - /url: /EEPA/insights
              - link "Advanced" [ref=f6e63] [cursor=pointer]:
                - /url: /EEPA/advanced
              - generic [ref=f6e67]:
                - button "Ask Blentera" [ref=f6e68]
                - link "Help / Support" [ref=f6e69] [cursor=pointer]:
                  - /url: /EEPA/company/help
        - button "Open account menu" [ref=f6e77]:
          - generic [ref=f6e78]: BR
          - generic [ref=f6e80]: Browser product reviewer
      - separator "Resize sidebar" [ref=f6e81]
    - generic [ref=f6e83]:
      - generic [ref=f6e84]:
        - region "Global utilities" [ref=f6e85]:
          - button "Ask Blentera" [ref=f6e86]
          - generic [ref=f6e89]:
            - generic [ref=f6e90]: Language
            - combobox "Language" [ref=f6e91]:
              - option "English" [selected]
              - option "Dansk"
          - link "Help / Support" [ref=f6e92] [cursor=pointer]:
            - /url: /EEPA/company/help
          - link "Contact support" [ref=f6e93] [cursor=pointer]:
            - /url: mailto:support@blentera.com
          - link "User account" [ref=f6e94] [cursor=pointer]:
            - /url: /EEPA/company/settings/instance/profile
        - heading "Review queue" [level=1] [ref=f6e101]
      - main [ref=f6e104]:
        - generic [ref=f6e105]:
          - generic [ref=f6e106]:
            - generic [ref=f6e107]:
              - heading "Review queue" [level=1] [ref=f6e108]
              - paragraph [ref=f6e109]: Needs your attention (1)
            - button "Approve 0 items" [disabled]
          - generic [ref=f6e111]:
            - generic [ref=f6e112]:
              - heading "Final calls" [level=2] [ref=f6e113]
              - generic [ref=f6e114]: 1 item
            - link "Pipeline primitives launch Content production Decide whether Pipeline primitives launch is ready to move forward. just now Approve Request changes" [ref=f6e116]:
              - generic [ref=f6e118]:
                - generic [ref=f6e119]:
                  - paragraph [ref=f6e120]: Pipeline primitives launch
                  - generic [ref=f6e121]: Content production
                - paragraph [ref=f6e122]: Decide whether Pipeline primitives launch is ready to move forward.
              - generic [ref=f6e123]:
                - generic [ref=f6e124]: just now
                - button "Approve" [ref=f6e125]
                - button "Request changes" [ref=f6e126]
          - paragraph [ref=f6e127]: "Shortcuts: j/k or arrow keys move, Enter opens item, a approves."
  - generic [ref=f6e128]:
    - heading "Command Palette" [level=2] [ref=f6e129]
    - paragraph [ref=f6e130]: Search for a command to run...
```

# Test source

```ts
  1   | import { randomUUID } from "node:crypto";
  2   | import { expect, request as pwRequest, test, type APIRequestContext, type APIResponse, type Locator, type Page } from "@playwright/test";
  3   | import { registerEnglishAccountLocaleIsolation } from "./account-locale-isolation";
  4   | import { createLocalAgentJwt } from "../../server/src/agent-auth-jwt";
  5   | 
  6   | registerEnglishAccountLocaleIsolation(test);
  7   | 
  8   | const PORT = Number(process.env.PAPERCLIP_E2E_PORT ?? 3199);
  9   | const BASE_URL = `http://127.0.0.1:${PORT}`;
  10  | 
  11  | type Stage = { id: string; key: string; name: string; kind: string; position: number };
  12  | type PipelineDetail = {
  13  |   id: string;
  14  |   name: string;
  15  |   stages: Stage[];
  16  |   transitions: Array<{ fromStageId: string; toStageId: string }>;
  17  | };
  18  | type CaseSummary = {
  19  |   id: string;
  20  |   caseKey: string;
  21  |   title: string;
  22  |   version: number;
  23  |   stageId: string;
  24  |   parentCaseVersion?: number | null;
  25  |   requestKey?: string | null;
  26  |   childCount?: number;
  27  |   terminalChildCount?: number;
  28  | };
  29  | type CaseRow = { case: CaseSummary; stage?: Stage };
  30  | type CaseDetail = CaseRow & {
  31  |   pipeline: { id: string; key: string; name: string };
  32  |   blockers?: Array<{ caseId: string; blockedByCaseId: string }>;
  33  | };
  34  | 
  35  | async function expectOk(response: APIResponse, label: string) {
  36  |   if (!response.ok()) {
> 37  |     throw new Error(`${label} failed: ${response.status()} ${await response.text()}`);
      |           ^ Error: list pipeline items failed: 500 {"error":"Internal server error"}
  38  |   }
  39  | }
  40  | 
  41  | async function expectError(response: APIResponse, label: string, status: number, code: string, message?: RegExp) {
  42  |   const body = await response.json() as { code?: string; error?: string; message?: string };
  43  |   expect(response.status(), `${label} status: ${JSON.stringify(body)}`).toBe(status);
  44  |   expect(body.code, `${label} code: ${JSON.stringify(body)}`).toBe(code);
  45  |   if (message) expect(body.error ?? body.message ?? "", `${label} message`).toMatch(message);
  46  | }
  47  | 
  48  | async function createCompany(board: APIRequestContext) {
  49  |   const response = await board.post("/api/companies", {
  50  |     data: { name: `E2E Pipelines ${Date.now()}` },
  51  |   });
  52  |   await expectOk(response, "create company");
  53  |   return response.json() as Promise<{ id: string; issuePrefix: string }>;
  54  | }
  55  | 
  56  | async function createCompanyAgent(
  57  |   board: APIRequestContext,
  58  |   companyId: string,
  59  |   input: { name: string; role: string; title?: string; capabilities?: string },
  60  | ) {
  61  |   const response = await board.post(`/api/companies/${companyId}/agents`, {
  62  |     data: {
  63  |       name: input.name,
  64  |       role: input.role,
  65  |       title: input.title,
  66  |       capabilities: input.capabilities,
  67  |       adapterType: "process",
  68  |       adapterConfig: { command: process.execPath, args: ["-e", "process.stdout.write('ok\\n')"] },
  69  |     },
  70  |   });
  71  |   await expectOk(response, `create ${input.name}`);
  72  |   return response.json() as Promise<{ id: string }>;
  73  | }
  74  | 
  75  | async function createPipelineWriterAgentKey(board: APIRequestContext, companyId: string) {
  76  |   await createCompanyAgent(board, companyId, {
  77  |     name: "Pipeline CEO",
  78  |     role: "ceo",
  79  |     title: "CEO",
  80  |     capabilities: "Approves agent join requests during e2e setup.",
  81  |   });
  82  | 
  83  |   const inviteResponse = await board.post(`/api/companies/${companyId}/invites`, {
  84  |     data: {
  85  |       allowedJoinTypes: "agent",
  86  |       defaultsPayload: {
  87  |         agent: {
  88  |           grants: [
  89  |             { permissionKey: "pipelines:write", scope: null },
  90  |           ],
  91  |         },
  92  |       },
  93  |     },
  94  |   });
  95  |   await expectOk(inviteResponse, "create pipeline-writer invite");
  96  |   const invite = await inviteResponse.json() as { token: string };
  97  | 
  98  |   const acceptResponse = await board.post(`/api/invites/${invite.token}/accept`, {
  99  |     data: {
  100 |       requestType: "agent",
  101 |       agentName: "Pipeline Fanout Agent",
  102 |       adapterType: "process",
  103 |       capabilities: "Creates pipeline child work during e2e coverage.",
  104 |     },
  105 |   });
  106 |   await expectOk(acceptResponse, "accept pipeline-writer invite");
  107 |   const accepted = await acceptResponse.json() as { id: string };
  108 | 
  109 |   const approveResponse = await board.post(`/api/companies/${companyId}/join-requests/${accepted.id}/approve`);
  110 |   await expectOk(approveResponse, "approve pipeline-writer join");
  111 |   const approved = await approveResponse.json() as { createdAgentId: string };
  112 | 
  113 |   const runId = randomUUID();
  114 |   const token = createLocalAgentJwt(approved.createdAgentId, companyId, "process", runId);
  115 |   if (!token) throw new Error("PAPERCLIP_AGENT_JWT_SECRET is required for pipeline writer JWT setup");
  116 |   return { agentId: approved.createdAgentId, runId, token };
  117 | }
  118 | 
  119 | async function createPipeline(board: APIRequestContext, companyId: string) {
  120 |   const response = await board.post(`/api/companies/${companyId}/pipelines`, {
  121 |     data: {
  122 |       key: "content-production",
  123 |       name: "Content production",
  124 |       description: "Draft, review, and publish launch content.",
  125 |       enforceTransitions: true,
  126 |       stages: [
  127 |         { key: "drafting", name: "Drafting", kind: "working", position: 0, config: { variables: [] } },
  128 |         { key: "published", name: "Published", kind: "done", position: 2, config: { variables: [] } },
  129 |         { key: "dropped", name: "Dropped", kind: "cancelled", position: 3, config: { variables: [] } },
  130 |       ],
  131 |     },
  132 |   });
  133 |   await expectOk(response, "create pipeline");
  134 |   return response.json() as Promise<{ id: string; name: string }>;
  135 | }
  136 | 
  137 | async function createPrimitivePipeline(board: APIRequestContext, companyId: string) {
```