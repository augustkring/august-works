import { z } from "zod";

const digest = z.string().regex(/^[a-f0-9]{64}$/);
const requestId = z.uuid().refine(value => value === value.toLowerCase(), "Use the canonical request ID");

export const agentModelMigrationMonitorReviewSchema = z.strictObject({
  companyId: z.uuid(), draftId: z.uuid(), agentId: z.uuid(), migrationRevisionId: z.uuid(),
  publishedVersion: z.number().int().positive(), publishedAt: z.iso.datetime(),
  targetProfileHash: digest, targetConfigurationHash: digest, targetLifecycleHash: digest,
  canRecord: z.boolean(), blockers: z.array(z.string().min(1).max(100)).max(20),
  tests: z.array(z.strictObject({ testId: z.uuid(), runId: z.uuid(), scenarioIndex: z.number().int().min(0).max(9),
    testCreatedAt: z.iso.datetime(), runStartedAt: z.iso.datetime(), verificationId: z.uuid(),
    verificationCreatedAt: z.iso.datetime(), outputHash: digest, resultHash: digest })).max(10),
  reviewHash: digest,
}).superRefine((review, context) => {
  if (review.canRecord !== (review.blockers.length === 0 && review.tests.length > 0))
    context.addIssue({ code: "custom", path: ["canRecord"], message: "A monitoring receipt needs current post-publication verified tests for every scenario" });
});

export const agentModelMigrationMonitorCommandSchema = z.strictObject({
  requestId, expectedReviewHash: digest, confirmMonitoring: z.literal(true),
});

export const agentModelMigrationMonitorReceiptSchema = agentModelMigrationMonitorReviewSchema.extend({
  requestId, reviewedByUserId: z.string().min(1).max(200), recordedAt: z.iso.datetime(),
  decision: z.literal("healthy"),
});

export type AgentModelMigrationMonitorReview = z.infer<typeof agentModelMigrationMonitorReviewSchema>;
export type AgentModelMigrationMonitorCommand = z.infer<typeof agentModelMigrationMonitorCommandSchema>;
export type AgentModelMigrationMonitorReceipt = z.infer<typeof agentModelMigrationMonitorReceiptSchema>;
