import assert from "node:assert/strict";
import {readFileSync, writeFileSync} from "node:fs";
import {createRequire} from "node:module";
import vm from "node:vm";
import {randomUUID, createHash} from "node:crypto";
import {orchestrationCompletionSchema} from "/workspace/v10-dep-qualification/packages/shared/dist/orchestration.js";
const req=createRequire("/workspace/v10-dep-qualification/package.json");
const {transformSync}=req("esbuild");
const root="/workspace/v10-preparation/native-worker-workspace-leaf-r106";
const helper=readFileSync("/workspace/v10-preparation/v10-149-r14.38.4.30-preflight-origin-private/files/server/src/__tests__/helpers/managed-native-opencode-e2e-fixture.ts","utf8");
const tests=readFileSync(root+"/files/server/src/services/native-runtime/native-opencode-managed-source.integration.test.ts","utf8");
// Execute the actual existing fixture output collector, rather than a second implementation.
const begin=helper.indexOf("requiredOutputs: (() => {");
assert(begin>=0);
const end=helper.indexOf("})(),",begin);
const expression=helper.slice(begin+"requiredOutputs: ".length,end+4);
const collector=transformSync("globalThis.collect = (modelSteps) => "+expression+";",{loader:"ts"}).code;
const ctx=vm.createContext({randomUUID,callId:"schema-probe"});
vm.runInContext(collector,ctx);
const receipt=[];
for(const name of ["binds a managed Project GET result", "refuses the next managed request after the captured Project workspace changes"]){
 const start=tests.indexOf('it("'+name);assert(start>=0,name);
 const stepsStart=tests.indexOf("steps: [",start)+"steps: ".length;
 const stepsEnd=tests.indexOf("      ]",stepsStart)+7;
 const steps=vm.runInContext("("+tests.slice(stepsStart,stepsEnd)+")",ctx);
 assert.deepEqual(Array.from(steps,x=>x.tool),["call_api","write_document","paperclip_finish"]);
 const output=ctx.collect(steps);
 const parsed=orchestrationCompletionSchema.parse({objective:"Complete the managed source-bound task",requiredOutputs:output,businessInvariants:["Use only this task's supplied workspace"]});
 assert.equal(parsed.requiredOutputs.length,1);
 const old=orchestrationCompletionSchema.safeParse({objective:parsed.objective,requiredOutputs:ctx.collect(steps.filter(x=>x.tool!=="write_document")),businessInvariants:parsed.businessInvariants});
 assert.equal(old.success,false,"former GET+finish program must fail production min1 schema");
 receipt.push({name,tools:Array.from(steps,x=>x.tool),requiredOutput:parsed.requiredOutputs[0],formerProgramDenied:true});
}
const base=readFileSync("/workspace/v10-preparation/v10-149-r14.38.4.30-preflight-origin-private/files/server/src/services/native-direct-input.ts","utf8");
const final=readFileSync(root+"/files/server/src/services/native-direct-input.ts","utf8");
assert.equal(final,base.replace("async function assertNativeWorkspaceMetadataSourcesCurrent(","export async function assertNativeWorkspaceMetadataSourcesCurrent("));
writeFileSync(root+"/local-fixture-validation.json",JSON.stringify({status:"PASS",schemaModule:"@paperclipai/shared/dist/orchestration.js",checks:receipt,workspaceOwnerBodyUnchanged:true,limitations:"No SDK/Host/model launch or full Native9 qualification claimed."},null,2)+"\n");
console.log("PASS: 2 actual Project programs accepted; 2 former empty-output programs denied; existing workspace owner body unchanged.");
