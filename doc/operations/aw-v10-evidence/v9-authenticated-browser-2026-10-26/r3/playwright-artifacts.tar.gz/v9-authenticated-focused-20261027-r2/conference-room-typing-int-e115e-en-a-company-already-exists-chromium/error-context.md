# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: conference-room-typing-intro.spec.ts >> First-task launch after onboarding wizard >> lands on the first task even when a company already exists
- Location: tests/e2e/conference-room-typing-intro.spec.ts:156:3

# Error details

```
TimeoutError: locator.waitFor: Timeout 20000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: /Get started/ }) to be visible

```

# Page snapshot

```yaml
- generic [ref=e5]:
  - generic [ref=e6]:
    - button "Name your organization" [ref=e7] [cursor=pointer]
    - button "Create your first agent" [ref=e8] [cursor=pointer]
    - button "Connect a model" [disabled] [ref=e9]
    - button "Review" [disabled] [ref=e10]
    - generic [ref=e11]: Step 3 of 4
  - generic [ref=e12]:
    - generic [ref=e13]: Ada
    - heading "Connect a model" [level=1] [ref=e25]
    - paragraph [ref=e28]:
      - generic [ref=e29]: Paperclip works with your subscription or API keys.
  - generic [ref=e31]:
    - radiogroup "Model source" [ref=e32]:
      - radio "Claude Subscription" [checked] [ref=e34] [cursor=pointer]:
        - generic [ref=e36]: Claude
        - generic [ref=e37]: Subscription
    - button "Use API key instead" [ref=e40] [cursor=pointer]
  - paragraph [ref=e43]: Unauthorized
  - generic [ref=e44]:
    - button "Back" [ref=e45]
    - button "Connect" [ref=e47]
```

# Test source

```ts
  13  |  *
  14  |  * Completing the onboarding wizard now creates the first assigned task and
  15  |  * drops the user straight onto that task's detail page (not the dashboard),
  16  |  * so they land in the conversation the agent will start in. The chat intro
  17  |  * still has unit coverage in BoardChat tests.
  18  |  *
  19  |  * PAP-404: onboarding used to intermittently bounce to the company dashboard.
  20  |  * The bounce only reproduces when the instance already has ≥1 company (the
  21  |  * board's test ports), so the second test seeds a company first to exercise
  22  |  * exactly that failing condition.
  23  |  */
  24  | 
  25  | const FIRST_TASK_TITLE = "Paperclip onboarding";
  26  | 
  27  | /**
  28  |  * Intercept authentication, environment checks, and hiring so no real CLI check
  29  |  * runs and no real agent process spawns (the hire still happens server-side
  30  |  * with an inert http adapter).
  31  |  */
  32  | async function installLaunchIntercepts(page: Page, baseURL?: string) {
  33  |   await mockOnboardingLocalAiConnection(page);
  34  |   await page.route("**/test-environment", (route) =>
  35  |     route.fulfill({
  36  |       contentType: "application/json",
  37  |       body: JSON.stringify({ status: "pass", checks: [] }),
  38  |     }),
  39  |   );
  40  | 
  41  |   await page.route("**/agent-hires", async (route) => {
  42  |     const req = route.request();
  43  |     const body = JSON.parse(req.postData() || "{}");
  44  |     const auth = req.headers().authorization;
  45  |     const real = await fetch(new URL(req.url(), baseURL).toString(), {
  46  |       method: "POST",
  47  |       headers: {
  48  |         "Content-Type": "application/json",
  49  |         ...(auth ? { Authorization: auth } : {}),
  50  |       },
  51  |       body: JSON.stringify({
  52  |         name: body.name,
  53  |         role: body.role,
  54  |         adapterType: "http",
  55  |         adapterConfig: { url: "http://127.0.0.1:1/dead" },
  56  |         runtimeConfig: { heartbeat: { enabled: false } },
  57  |       }),
  58  |     });
  59  |     await route.fulfill({
  60  |       status: real.status,
  61  |       contentType: "application/json",
  62  |       body: await real.text(),
  63  |     });
  64  |   });
  65  | }
  66  | 
  67  | /** Drive the wizard from the /onboarding route through to "Get started". */
  68  | async function runOnboardingWizard(page: Page, companyName: string) {
  69  |   await page.goto("/onboarding");
  70  | 
  71  |   // Launcher card path (existing companies) — enter the wizard if the
  72  |   // route shows a launcher instead of opening the wizard directly.
  73  |   const startBtn = page.getByRole("button", { name: /Start Onboarding/i });
  74  |   if (await startBtn.count()) await startBtn.first().click();
  75  | 
  76  |   // Step 0: front door (skipped when the wizard opens on the create path).
  77  |   const frontDoor = page.getByText("Build a new organization");
  78  |   if (await frontDoor.count()) await frontDoor.first().click();
  79  | 
  80  |   // Step 1: company name.
  81  |   await page.getByPlaceholder("e.g. Northwind Labs").fill(companyName);
  82  |   await page.getByRole("button", { name: /^Continue/ }).click();
  83  | 
  84  |   // Step 1's "Next" creates the company; the mission step no longer runs.
  85  | 
  86  |   // Step 3: name the agent. The role picker is gone — the arc asks for a
  87  |   // name and hires under the neutral `general` role.
  88  |   await page.waitForSelector("#onboarding-agent-name", { timeout: 30_000 });
  89  |   await page.locator("#onboarding-agent-name").fill("Ada");
  90  |   await page.getByRole("button", { name: /^Next$/ }).click();
  91  | 
  92  |   // Step 4: pick a model source, then advance. Nothing is selected on arrival
  93  |   // — the row is a question, not a confirmation — so the CTA is disabled until
  94  |   // a tile is pressed. By role rather than by label: which adapters the tiles
  95  |   // offer depends on the registry this environment reports.
  96  |   const source = page.getByRole("radio").first();
  97  |   await source.waitFor({ timeout: 30_000 });
  98  |   await source.click();
  99  | 
  100 |   // "Connect", not "Next": this step's button starts the sign-in where there
  101 |   // is one to start, so it is named for what it does. This test simulates
  102 |   // successful local account connection before the environment check and hire.
  103 |   //
  104 |   // Waited on for enabled rather than for visible: it is already on screen,
  105 |   // disabled, and clicking a disabled button raises nothing and does nothing.
  106 |   const connectNext = page.getByRole("button", { name: /^Connect$/ });
  107 |   await expect(connectNext).toBeEnabled({ timeout: 30_000 });
  108 |   await connectNext.click();
  109 | 
  110 |   // Step 5: review → Get started creates the first task and opens its
  111 |   // detail page.
  112 |   const getStarted = page.getByRole("button", { name: /Get started/ });
> 113 |   await getStarted.waitFor({ timeout: 20_000 });
      |                    ^ TimeoutError: locator.waitFor: Timeout 20000ms exceeded.
  114 |   await getStarted.click();
  115 | }
  116 | 
  117 | async function assertFirstTaskExists(page: Page, companyName: string) {
  118 |   const companiesRes = await page.request.get("/api/companies");
  119 |   expect(companiesRes.ok()).toBe(true);
  120 |   const companies = await companiesRes.json();
  121 |   const company = companies.find(
  122 |     (candidate: { name: string }) => candidate.name === companyName,
  123 |   );
  124 |   expect(company).toBeTruthy();
  125 | 
  126 |   const issuesRes = await page.request.get(`/api/companies/${company.id}/issues`);
  127 |   expect(issuesRes.ok()).toBe(true);
  128 |   const issues = await issuesRes.json();
  129 |   const firstTask = issues.find(
  130 |     (candidate: { title: string }) => candidate.title === FIRST_TASK_TITLE,
  131 |   );
  132 |   expect(firstTask).toBeTruthy();
  133 |   // The progressive sidebar can retain a hidden task label. Assert the actual
  134 |   // task detail heading instead of whichever text node appears first.
  135 |   await expect(page.getByRole("main").getByRole("heading", { name: FIRST_TASK_TITLE, exact: true })).toBeVisible({
  136 |     timeout: 15_000,
  137 |   });
  138 | }
  139 | 
  140 | test.describe("First-task launch after onboarding wizard", () => {
  141 |   test("creates the first task and opens its detail page", async ({ page, baseURL }) => {
  142 |     await instrumentNavLog(page);
  143 |     await installLaunchIntercepts(page, baseURL);
  144 | 
  145 |     const companyName = `E2E-TypingIntro-${Date.now()}`;
  146 |     await runOnboardingWizard(page, companyName);
  147 | 
  148 |     await expectLandsOnFirstTaskWithoutDashboardBounce(page);
  149 |     await assertFirstTaskExists(page, companyName);
  150 |   });
  151 | 
  152 |   // PAP-404 regression: the dashboard bounce only fires when the instance
  153 |   // already has a company for the route-sync effect to reset selection to.
  154 |   // Seed one first, then onboard a brand-new company and assert we still land
  155 |   // on the first task without a dashboard bounce.
  156 |   test("lands on the first task even when a company already exists", async ({
  157 |     page,
  158 |     baseURL,
  159 |   }) => {
  160 |     await instrumentNavLog(page);
  161 |     await installLaunchIntercepts(page, baseURL);
  162 | 
  163 |     // Seed a pre-existing company so the companies list is non-empty when the
  164 |     // wizard launches — the exact condition that reproduced the bounce.
  165 |     const seedRes = await page.request.post("/api/companies", {
  166 |       data: { name: `E2E-Seed-${Date.now()}` },
  167 |     });
  168 |     expect(seedRes.ok()).toBe(true);
  169 | 
  170 |     const companyName = `E2E-TypingIntro-Existing-${Date.now()}`;
  171 |     await runOnboardingWizard(page, companyName);
  172 | 
  173 |     await expectLandsOnFirstTaskWithoutDashboardBounce(page);
  174 |     await assertFirstTaskExists(page, companyName);
  175 |   });
  176 | });
  177 | 
```