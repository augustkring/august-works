# General-server shard duration refresh candidate

Private duration-only candidate for Main `249ea9e7d0bad179e76f73c1a9372ad934a01e94`. It preserves every existing duration value and adds exactly three measured file durations from PR run 41440401218 (merge checkout `3cdc4b70abcce2af630beab1f11e1de7ccd5355c`, PR source head `13a96e3fefbcf6de25ff5a66f6ef3024be278da1`):

- Conversation frame: 723,529 ms; five tests, two failed.
- Managed source: 42,646 ms; five tests, four failed.
- Private Project create: 23,840 ms; two tests, one failed.

These failed/partial-run numbers are scheduling observations only, not acceptance evidence. Project-create-wait and managed-browser have no reliable per-file timing in captured logs, so they retain the existing 1,621 ms median fallback as unknowns. No guessed timings were added.

The forecast uses the exact PR environment (`GITHUB_WORKFLOW=PR`) and the current 1,052-file PR selection, then adds eight new test paths from the requested 18-path union: the reviewed 16-path R6/Railway source set, one frozen managed-positive comment test, and the duration-manifest candidate. The nine pinned test paths include one already in Main; all nine are selected exactly once, and all eight new paths are selected exactly once. The frame file is alone on its shard; ordinary managed scheduler work remains on a different shard. With existing weights, the current PR selection maps frame to index 10 (11/12), matching the captured CI job. The non-PR mode includes the Rust-cached native-runner suite and is a different input.

The totals in `coherent-selection-forecast.json` are duration-weight sums, not wall-clock forecasts; they omit startup/import overhead and runtime variance. Existing workflow setup still derives browser installation from the selected file list for the exact checkout. No Main, Mirror, test, workflow, or source file changed; no tests or compilers ran. Candidate patch: `general-server-shard-durations.patch`.
