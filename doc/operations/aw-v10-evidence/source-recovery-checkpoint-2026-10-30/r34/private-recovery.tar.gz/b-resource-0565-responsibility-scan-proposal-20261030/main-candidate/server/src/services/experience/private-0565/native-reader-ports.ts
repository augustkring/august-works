/** PRIVATE Resource 0565 native-reader integration seam. Domain implementations
 * must live with their owning services; this registry only composes them. */
import type { AuthorizationActor } from "../../authorization.js";
import type { CurrentNativeResponsibility, NativeResponsibilityReader } from "./authorized-subset-reader.js";
import type { ResponsibilityScanKind } from "./responsibility-scan.js";

export type ResponsibilityReadPort = (actor: AuthorizationActor, companyId: string, resourceId: string) => Promise<CurrentNativeResponsibility>;
export type NativeResponsibilityReadPorts = Record<ResponsibilityScanKind, ResponsibilityReadPort>;

const destinations: Record<ResponsibilityScanKind, { title: string; href: string }> = {
  agent: { title: "Co-worker", href: "/agents" },
  deployment: { title: "Agent Package deployment", href: "/agents" },
  workflow: { title: "Workflow", href: "/workflows" },
  workflow_run: { title: "Workflow run", href: "/workflows" },
  routine: { title: "Routine", href: "/company/settings/members" },
  connector: { title: "Critical connector", href: "/apps" },
  metric: { title: "Governed metric", href: "/business-metrics" },
  experiment: { title: "Experiment", href: "/business-experiments" },
  decision: { title: "Material decision", href: "/decisions" },
  approval: { title: "Pending approval", href: "/approvals" },
  ai_use_case: { title: "AI Use Case", href: "/governance/ai-use-cases" },
  tool_policy: { title: "Tool policy", href: "/settings/agent-permissions" },
  skill_policy: { title: "Company skill policy", href: "/company/settings/skills" },
  billing: { title: "Billing responsibility", href: "/settings/billing" },
  support_case: { title: "Support response", href: "/support" },
};

/** Exact supported kind set is checked at construction/read time. Each port is
 * required so a missing owner integration cannot silently appear as zero work. */
export function bindNativeResponsibilityReaders(ports: NativeResponsibilityReadPorts): NativeResponsibilityReader[] {
  return (Object.keys(destinations) as ResponsibilityScanKind[]).map(kind => ({
    kind, ...destinations[kind],
    inspectCurrent: (actor, companyId, resourceId) => ports[kind](actor, companyId, resourceId),
  }));
}
