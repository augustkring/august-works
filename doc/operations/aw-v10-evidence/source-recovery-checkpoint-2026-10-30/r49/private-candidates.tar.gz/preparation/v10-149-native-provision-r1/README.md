# V10-149 native provisioning R1 private candidate

This candidate adds a source-owned CreateSandbox path through the existing OpenShell v0.1.2 CLI and Docker driver. It does not edit MAIN, publish the vendor patch, or claim a deployable/qualified host.

`prepare.provisioning` is a strict, controller-generated envelope. The server pins scope, host credential epoch, and image from its current DB state, then hashes exactly `{scope, hostEpoch, imageDigest, purpose, operationKey, expiresAt, idleUntilUnixSeconds, policyHash, document, resourceLimits}`. The deterministic request UUID is derived from that hash. Existing host command replay reuses the persisted original expiry and request UUID; changed or expired replay fails before a new effect.

Qualification now provisions its isolated read-only/no-network bootstrap target before the fixed probe suite. Admission separately provisions the compiled policy and all four exact resource limits. A protected capability snapshot and each probe carry the exact sandbox/container, policy, host epoch, image, kernel, mechanism and probe-target hash. Admission compares the fresh target evidence against the signed prepare receipt, exact scope, compiled policy hash, and four limits. It does not transfer qualification-target identity to the admission target. Resource-owned host code must still implement the matching create journal, absolute-expiry helper, `--no-auto-providers` create call, exact-ID stop, quota observation and probes.

The vendored patch adds a hidden `--request-id` create option while preserving the existing public `sandbox_create` helper signature. The Docker driver accepts a per-sandbox `pids_limit` that cannot exceed the daemon ceiling and sets `memory_swap` equal to the memory limit at create. Resource host code must pass exact decimal memory bytes, CPU millicores, disk bytes, and per-profile PID limit, with auto-provider discovery disabled.

## Validation performed

- V7 patch applies cleanly from the exact current-MAIN files plus the pinned R10 parent files; applying it reconstructs every candidate byte-for-byte.
- Vendor patch applies cleanly from exact R5 CLI and R11 Docker driver source parents; applying it reconstructs every changed Rust file byte-for-byte.
- Rustfmt 1.97.1 parser/format check passed under the canonical flock. No Cargo compile or test ran.
- The required shared/server tests, full TypeScript typecheck, OpenShell host tests, CreateSandbox replay test, quota exhaustion/restart probe, and physical-host qualification remain pending in the integrated R12 candidate.

See `source-pins.json` and `exact-stage-paths.txt` for source parents, candidate hashes, patches, and the precise source path list.
