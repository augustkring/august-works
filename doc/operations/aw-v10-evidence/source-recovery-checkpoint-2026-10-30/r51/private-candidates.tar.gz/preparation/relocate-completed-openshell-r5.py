from pathlib import Path
import hashlib,json,subprocess,shutil,datetime
source=Path('/workspace/v10-preparation/openshell-rt01-expected-id-candidate-r5');dest=Path('/tmp/blentera-preserved-openshell-r5-20261030');pinsPath=Path('/workspace/v10-preparation/openshell-rt01-repo-integration-candidate-r5.1/third_party/openshell/rt01/source-pins.json');pins=json.loads(pinsPath.read_text())
assert source.is_dir() and not source.is_symlink() and not dest.exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()=='6648bd0c290efbc41ba131ee9831ee45cd431f94'
assert not subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=source).strip()
def verify(root):
 for rel,expected in pins['files'].items():assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==expected,rel
verify(source)
# Move the COMPLETE tree; preserve all files and keep the original path usable.
shutil.move(str(source),str(dest));source.symlink_to(dest,target_is_directory=True);verify(source);verify(dest)
receipt={'purpose':'reversible relocation of fully pinned completed upstream build copy; no files discarded','sourcePath':str(source),'preservedPath':str(dest),'originalPathIsSymlink':source.is_symlink(),'verifiedSourceFileCount':len(pins['files']),'upstreamCommit':'6648bd0c290efbc41ba131ee9831ee45cd431f94','qualifiedPatchSha256':pins['patch']['sha256'],'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat()}
Path('/workspace/v10-preparation/openshell-r5-preserved-relocation-20261030.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
