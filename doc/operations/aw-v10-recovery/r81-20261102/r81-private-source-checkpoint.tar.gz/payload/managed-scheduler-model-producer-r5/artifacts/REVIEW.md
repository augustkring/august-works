# R4: actual tunnel association controls

Prepared against clean tracked Main `13a96e3fefbcf6de25ff5a66f6ef3024be278da1`. No published source was changed. R3 remains frozen; its whole three files/seven pure controls passed with exact copied-candidate provenance.

Only three candidate paths change from R3: heartbeat helper delegates its existing ephemeral upstream TCP tuple map and TLS WeakMap to the model transport helper; that helper now owns the extracted map; a new three-case test exercises that exact owner. Existing Host signed-start, image, kernel socket observation, incoming JWT, currentness and data-retirement checks are unchanged. This is an extraction inside the test fixture, not a new production admission owner.

The TLS object is classified exactly once, including an unbound object. Retirement closes its channel and both tunnel ends. A late close deletes a tuple entry only when it is still the same entry. Thus replacing a retired TCP tuple cannot retag an old TLS object or erase its successor. Authorization retains the exact route/origin and conflicting-header checks and rechecks retirement after awaiting the existing channel authorization.

Three new controls are concrete:

1. Deterministic same-key table reuse: A succeeds, A retires, B occupies the same key, old A and previously unbound TLS objects cannot become B; late A close does not delete B. Synthetic Socket metadata tests only table behavior and makes no kernel provenance claim.
2. An authorization promise is paused, A retires, B takes the key, then A resolves: no header is returned and B is never consulted.
3. Actual loopback HTTP CONNECT tunnels and TLS handshakes: a direct/unregistered TLS socket receives no injected header; A is injected only on its registered tunnel; stopped A closes; an incoming conflicting A header on B closes without injection; a fresh B channel receives only B. Controlled strings are not JWTs and the stub ModelChannel is not a Host admission or profile proof. The real kernel/image/ancestry controls remain in the earlier whole test file.

Prepared runner reuses the reviewed R3 source-copy/provenance and owned-process-group launcher. It runs WHOLE four files/ten cases with exact eight candidate paths, existing Root 120000 KiB and TMP 1048576 KiB floors. Only dependency directories are symlinks. Module provenance is required before each file's first test; post-run provenance covers all modules and all tests. It performs no DB, SDK, compiler, build or Main/Mirror overlay. Source review/Root GO is required before execution.

Still unqualified: actual Host producer-denial journeys with genuine quotes/signed START and zero provider effects; default real SDK parity and two real serial SDK Runs; physical isolation. These mechanics controls do not replace those gates. Project and observational Source4 siblings are excluded from this packet.

## R5 successor

Only the secureConnection callback changes: before association initialization it destroys the socket and returns. It cannot be classified later. R4 remains frozen. Root authorized whole four files/ten controls after this exact fail-closed guard.
