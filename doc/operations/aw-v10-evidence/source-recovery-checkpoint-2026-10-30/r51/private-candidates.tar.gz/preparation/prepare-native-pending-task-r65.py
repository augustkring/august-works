from pathlib import Path
import hashlib,json,difflib
root=Path('/workspace/blentera-v10');base=Path('/workspace/v10-preparation/native-before-predicate-r63-recovered');out=Path('/workspace/v10-preparation/native-pending-task-r65-candidate');rows={}
def save(rel,old,new,baseline=None):
 p=out/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(new);rows[rel]={'priorSha256':hashlib.sha256(old.encode()).hexdigest(),'candidateSha256':hashlib.sha256(new.encode()).hexdigest()};(out/(Path(rel).name+'.diff')).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
 if baseline is not None:(out/'pending-only.diff').write_text(''.join(difflib.unified_diff(baseline.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
rel='server/src/services/native-direct-input.ts';old=(root/rel).read_text();a=(base/rel).read_text();s=a
def rep(x,y):
 global s
 assert s.count(x)==1,(x[:95],s.count(x));s=s.replace(x,y,1)
rep('''interface NativeSourceReadAncestry { work: number;''','''interface NativeSourceReadAncestry { work: number; pendingTaskOwner: object; preparingTaskEffect: boolean;''')
rep('''  childHandle: NativeSourceGraphObligationHandle; mutableSources: NativeMutableSourceDependencies;
}''','''  childHandle: NativeSourceGraphObligationHandle; mutableSources: NativeMutableSourceDependencies;
  pending?: NativePendingTaskRead;
}
interface NativePendingTaskRead {
  owner: object;
  obligations: Omit<NativeSourceGraphObligations, "taskPins"> & {
    taskPins: ReadonlyArray<readonly [string, { contentHash: string; snapshotDigest: string }]>;
  };
  groups: Array<{ key: string; companyId: string; actor: AuthorizationActor; version: number;
    sets: Array<[string, { runId: string; policy: NativePayloadSourcePolicy; inputs: NativePayloadSourceInput[] }]>;
    issueIds: string[]; memoryIds: string[] }>;
}''')
rep('''function completeNativeSourceGraphObligations(context: NativeSourceReadContext, actorKey: string): NativeSourceGraphObligations | undefined {''','''function captureNativeSourceGraphObligations(context: NativeSourceReadContext, actorKey: string): NativeSourceGraphObligations | undefined {''')
needle='async function replayNativeSourceGraphObligations(scope: NativeSourceReadScope, obligations: NativeSourceGraphObligations,'
helpers='''function completeNativeSourceGraphObligations(context: NativeSourceReadContext, actorKey: string): NativeSourceGraphObligations | undefined {
  const snapshot = captureNativeSourceGraphObligations(context, actorKey);
  return snapshot && snapshot.scopedTasks.every(check => !check.pending && check.childHandle.completed) ? snapshot : undefined;
}
function nativePendingTaskQueuesArePure(snapshot: Omit<NativeSourceGraphObligations, "taskPins">,
  companyId: string, actorKey: string): boolean {
  const pureKinds = new Set<NativePayloadSourceInput["kind"]>(["task", "runtime_instructions", "workspace_metadata",
    "worker_model_dispatch", "conversation_model_dispatch", "tool_result", "completion_contract", "document_revision"]);
  return snapshot.actorKey === actorKey && [...snapshot.readerSets, ...snapshot.ownerReads].every(check =>
    check.companyId === companyId && nativeSha256(check.actor) === actorKey) && snapshot.analyticalReads.length === 0 && snapshot.readResults.length === 0 && snapshot.runtimeSkills.length === 0 &&
    snapshot.scopedTasks.length === 0 && snapshot.ownerReads.every(group => group.memoryIds.length === 0) &&
    snapshot.readerSets.every(set => set.policy.memoryIds.length === 0 && set.policy.projectIds.length === 0 &&
      set.policy.foundationRevisionIds.length === 0 && set.inputs.every(source => pureKinds.has(source.kind)));
}
function nativeSourceEffectBarrierActive(context: NativeSourceReadContext): boolean {
  for (let current: NativeSourceReadContext | undefined = context; current; current = current.parentContext)
    if (current.ancestry.preparingTaskEffect) return true;
  return false;
}
function nativePendingTaskCanAdopt(scope: NativeSourceReadScope, pending: NativePendingTaskRead, companyId: string): boolean {
  const context = scope.context;
  return pending.owner === context.ancestry.pendingTaskOwner && !context.ancestry.graphProofsDisabled &&
    nativePendingTaskQueuesArePure(pending.obligations, companyId, scope.actorKey) && context.deferredReaderChecks.size === 0 &&
    context.deferredReadResultChecks.size === 0 && context.deferredAnalyticalTasks.size === 0 &&
    context.scopedTaskReads.size === 0 && !context.runtimeSkillReads?.size && scope.taskTemporalScopes.size === 0;
}
function freezeNativePendingTaskData(value: unknown, seen = new WeakSet<object>()): void {
  if (!value || typeof value !== "object" || seen.has(value)) return;
  seen.add(value);
  if (value instanceof Map) for (const [key, item] of value) {
    freezeNativePendingTaskData(key, seen); freezeNativePendingTaskData(item, seen);
  }
  else for (const item of Object.values(value)) freezeNativePendingTaskData(item, seen);
  Object.freeze(value);
}
function adoptNativePendingTaskQueues(scope: NativeSourceReadScope, pending: NativePendingTaskRead): void {
  // This continues the SAME privately owned validation. Its source nodes were
  // already charged when queued. Transfer only unchecked obligations/pins;
  // current rows, checked sets and reader outcomes stay fresh in this scope.
  const data = structuredClone({ obligations: pending.obligations, groups: pending.groups });
  for (const group of data.groups) {
    scope.context.deferredReaderChecks.set(group.key, { companyId: group.companyId, actor: group.actor,
      version: group.version, sets: new Map(group.sets), issueIds: new Set(group.issueIds), memoryIds: new Set(group.memoryIds) });
    scope.context.pendingReaderChecks.add(group.key);
  }
  for (const [id, pin] of data.obligations.taskPins) scope.taskTemporalScopes.set(id, pin);
}
'''
rep(needle,helpers+needle)
rep('''interface NativeSourceReadContext { db: object; memoryTemporalIdentity: string | null;''','''interface NativeSourceReadContext { db: object; memoryTemporalIdentity: string | null;
  parentContext?: NativeSourceReadContext; flushingReaders: boolean;''')
rep('''  return { work: 0, graphProofs: new Map(), graphProofsDisabled: false,''','''  return { work: 0, pendingTaskOwner: {}, preparingTaskEffect: false, graphProofs: new Map(), graphProofsDisabled: false,''')
# Find the context construction's first exact field rather than changing scope objects.
rep('''  const context: NativeSourceReadContext = { db: db as object, memoryTemporalIdentity,''','''  const context: NativeSourceReadContext = { db: db as object, memoryTemporalIdentity, flushingReaders: false,''')
# Atomic ownership of a pending continuation; ordinary completed replays keep their existing charged path.
rep('''  const key = nativeScopedTaskReadKey(input);
  if (scope.active.has(key)) throw forbidden("The Native scoped Task reader graph contains a cycle");''','''  const key = nativeScopedTaskReadKey(input);
  const pending = input.pending;
  input.pending = undefined;
  if (scope.active.has(key)) throw forbidden("The Native scoped Task reader graph contains a cycle");''')
rep('''        await withNativeSourceReadScope(scope.context.db as Db, input.actor, input.companyId, async childScope => {
          const completed = input.childHandle.completed;''','''        await withNativeSourceReadScope(scope.context.db as Db, input.actor, input.companyId, async childScope => {
          childScope.context.readerObligations ??= input.childHandle;
          if (pending && nativePendingTaskCanAdopt(childScope, pending, input.companyId) && input.mutableSources.compatible &&
            await nativeFrozenMutableSourcesCurrent(childScope.context.db as Db, input.companyId, input.mutableSources, childScope)) {
            adoptNativePendingTaskQueues(childScope, pending);
            return;
          }
          const completed = input.childHandle.completed;''')
# Factor the already qualified drain so an effect barrier never runs the parent's final ACL pass.
a0=s.index('    while (context.pendingScopedTaskReads.size) {',s.index('async function flushNativeSourceReaderChecks'))
b0=s.index('    if (context.pendingReaderChecks.size) {',a0)
drain=s[a0:b0]
body='\n'.join(line[2:] if line.startswith('  ') else line for line in drain.splitlines())
body=body.replace('    const keys = [...context.pendingScopedTaskReads];\n    context.pendingScopedTaskReads.clear();', '    const keys = [...context.pendingScopedTaskReads].filter(key => !pendingOnly || context.scopedTaskReads.get(key)?.pending);\n    if (!keys.length) break;\n    for (const key of keys) context.pendingScopedTaskReads.delete(key);',1)
s=s[:a0]+'    await drainNativeScopedTaskReads(context);\n'+s[b0:]
helper='''async function drainNativeScopedTaskReads(context: NativeSourceReadContext, pendingOnly = false): Promise<void> {
'''+body+'''\n}
async function prepareNativeSourceEffectBoundary(scope: NativeSourceReadScope): Promise<void> {
  const contexts: NativeSourceReadContext[] = [];
  const seen = new Set<NativeSourceReadContext>();
  for (let context: NativeSourceReadContext | undefined = scope.context; context; context = context.parentContext) {
    if (!context.active || seen.has(context) || contexts.length >= 512)
      throw forbidden("The Native pending Task owner is unavailable");
    if (context.ancestry.preparingTaskEffect) throw forbidden("The Native pending Task check cannot enter an effect");
    seen.add(context);
    contexts.push(context);
  }
  const ancestries = new Set(contexts.map(context => context.ancestry));
  for (const ancestry of ancestries) ancestry.preparingTaskEffect = true;
  try {
    for (const context of contexts.reverse()) {
      // A foreign transaction/savepoint keeps this barrier link only. Its
      // ancestor's pending check still runs on that owner's own DB and actor.
      await drainNativeScopedTaskReads(context, true);
    }
  } finally { for (const ancestry of ancestries) ancestry.preparingTaskEffect = false; }
  disableNativeSourceGraphCheckpoints(scope);
  for (const ancestry of ancestries) {
    ancestry.graphProofsDisabled = true;
    ancestry.graphProofs.clear();
  }
}
'''
rep('async function flushNativeSourceReaderChecks(context: NativeSourceReadContext) {',helper+'''async function flushNativeSourceReaderChecks(context: NativeSourceReadContext) {
  const wasFlushing = context.flushingReaders;
  context.flushingReaders = true;
  try {''')
rep('''    if (!pendingResults && !pendingAnalytical && !context.pendingReaderChecks.size && !context.pendingScopedTaskReads.size) break;
  }
}
function withNativeSourceReadScope''','''    if (!pendingResults && !pendingAnalytical && !context.pendingReaderChecks.size && !context.pendingScopedTaskReads.size) break;
  }
  } finally { context.flushingReaders = wasFlushing; }
}
function withNativeSourceReadScope''')
rep('''  read: (scope: NativeSourceReadScope) => Promise<T>, proofMemo?: NativeMemoryPageStructuralProofMemo): Promise<T> {''','''  read: (scope: NativeSourceReadScope) => Promise<T>, proofMemo?: NativeMemoryPageStructuralProofMemo,
  privateTaskParent?: { scope: NativeSourceReadScope; check: NativeScopedTaskRead }): Promise<T> {''')
rep('''    inheritedContext?.pinnedRowsActorKey === actorKey ? inheritedContext.pinnedRows : undefined);
  return nativeSourceReadScopes.run(scope.context, async () => {''','''    inheritedContext?.pinnedRowsActorKey === actorKey ? inheritedContext.pinnedRows : undefined);
  // This link is an effect barrier only. Memo ancestry, rows and work budgets
  // still inherit solely through the exact same transaction object above.
  scope.context.parentContext = current?.active ? current : undefined;
  for (let parent = scope.context.parentContext; parent; parent = parent.parentContext)
    if (parent.ancestry.graphProofsDisabled) scope.context.ancestry.graphProofsDisabled = true;
  return nativeSourceReadScopes.run(scope.context, async () => {''')
rep('''      const result = await readPublicInvocation(scope);
      await flushNativeSourceReaderChecks(scope.context);''','''      const result = await readPublicInvocation(scope);
      const parent = privateTaskParent?.scope;
      if (privateTaskParent && parent && inheritedContext === parent.context && parent.context.active &&
        parent.context.db === scope.context.db && nativeSha256(privateTaskParent.check.actor) === actorKey &&
        parent.context.privacyLockedCompanies.has(privateTaskParent.check.companyId) && !parent.context.flushingReaders &&
        !scope.context.ancestry.graphProofsDisabled && !nativeSourceEffectBarrierActive(scope.context) &&
        privateTaskParent.check.mutableSources.compatible) {
        const snapshot = captureNativeSourceGraphObligations(scope.context, actorKey);
        const ownPin = snapshot?.taskPins.get(privateTaskParent.check.issueId);
        if (snapshot && nativePendingTaskQueuesArePure(snapshot, privateTaskParent.check.companyId, actorKey) && ownPin &&
          ownPin.contentHash === privateTaskParent.check.contentHash && ownPin.snapshotDigest === privateTaskParent.check.snapshotDigest) {
          const data = structuredClone({ obligations: { ...snapshot, taskPins: [...snapshot.taskPins] },
            groups: [...scope.context.deferredReaderChecks].map(([key, group]) => ({ key,
              companyId: group.companyId, actor: group.actor, version: group.version,
              sets: [...group.sets], issueIds: [...group.issueIds], memoryIds: [...group.memoryIds] })) });
          freezeNativePendingTaskData(data);
          privateTaskParent.check.pending = Object.freeze({ owner: scope.context.ancestry.pendingTaskOwner, ...data });
          return result;
        }
      }
      await flushNativeSourceReaderChecks(scope.context);''')
# All three existing fences are awaited; no authority or effect is removed.
assert s.count('      disableNativeSourceGraphCheckpoints(scope);')==3
s=s.replace('      disableNativeSourceGraphCheckpoints(scope);','      await prepareNativeSourceEffectBoundary(scope);')
rep('''        const descriptor = { companyId, actor, issueId, contentHash: snapshot.data.owner.contentHash,''','''        const descriptor: NativeScopedTaskRead = { companyId, actor, issueId, contentHash: snapshot.data.owner.contentHash,''')
rep('''            finally { if (stack.at(-1) === frame) stack.pop(); }
          });
        } finally''','''            finally { if (stack.at(-1) === frame) stack.pop(); }
          }, undefined, { scope, check: descriptor });
        } finally''')
rep('''          if (!retainedHandle?.completed || !mutableSources.compatible)
            markNativeSourceProofsIncompatible(scope);''','''          if (!retainedHandle?.completed && !descriptor.pending || !mutableSources.compatible)
            markNativeSourceProofsIncompatible(scope);''')
rep('''  siblingToolSourceProofHits: 0, documentNodeHits:''','''  pendingTaskCaptures: 0, pendingTaskAdoptions: 0,
  siblingToolSourceProofHits: 0, documentNodeHits:''')
rep('''  nativeSourceMemoDiagnostics.siblingToolSourceProofHits = 0;''','''  nativeSourceMemoDiagnostics.pendingTaskCaptures = 0;
  nativeSourceMemoDiagnostics.pendingTaskAdoptions = 0;
  nativeSourceMemoDiagnostics.siblingToolSourceProofHits = 0;''')
rep('''  const data = structuredClone({ obligations: pending.obligations, groups: pending.groups });''','''  const data = structuredClone({ obligations: pending.obligations, groups: pending.groups });
  if (nativeSourceMemoDiagnosticsEnabled()) nativeSourceMemoDiagnostics.pendingTaskAdoptions += 1;''')
rep('''          privateTaskParent.check.pending = Object.freeze({ owner: scope.context.ancestry.pendingTaskOwner, ...data });''','''          privateTaskParent.check.pending = Object.freeze({ owner: scope.context.ancestry.pendingTaskOwner, ...data });
          if (nativeSourceMemoDiagnosticsEnabled()) nativeSourceMemoDiagnostics.pendingTaskCaptures += 1;''')
rep('''        workByFamily: diagnostic.workByFamily,
        graph:''','''        workByFamily: diagnostic.workByFamily,
        pendingTaskCaptures: nativeSourceMemoDiagnostics.pendingTaskCaptures,
        pendingTaskAdoptions: nativeSourceMemoDiagnostics.pendingTaskAdoptions,
        graph:''')
save(rel,old,s,a)
for rel in ['server/src/services/authorization.ts','server/src/__tests__/native-payload-temporal-sources.integration.test.ts']:save(rel,(root/rel).read_text(),(base/rel).read_text())
(out/'manifest.json').write_text(json.dumps(rows,indent=2))
