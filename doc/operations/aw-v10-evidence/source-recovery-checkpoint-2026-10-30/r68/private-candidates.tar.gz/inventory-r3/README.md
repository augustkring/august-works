# Final metadata inventory preparation

Private preparation only. No Main/Mirror/source-manifest/generated graph writes, no test runs and no current/source-after hash refresh were performed. Frozen metadata manifests are referenced as inputs; Host/Native final combined source remains a gate.

`updated-owner-plan.json` consolidates the two earlier plans and adds 12 missing source paths, for 53 additions to the current inventory, all assigned to existing groups. It preserves the 50 groups, 25 hotspots, source base `81d3445b98b1cd80ff400ede6bd44ea71d88d735`, all 169 historical statuses and the exact requirement crosswalk.

The new paths are three Host installation/profile files (Dockerfile and broker module/tests), four adapter admission/probe test files, three connected-tool protocol/telemetry test files, the server broker-capability component test, and the Native actual SDK qualifier script. The Native OpenCode driver and driver test already have inventory owners; their final source/receipt hashes need the normal post-freeze generation, not another group. The server capability seven-file component plus two constructor followup files has seven unique paths: the latter replaces control.ts and its component test.

The final55 guard manifest has 56 union entries but only55 final files. `qualification-fixed-platform-echo.integration.test.ts` has null parent and null final hashes: remove its proposed addition from the old plan, never create a base-deletion/deletedSourcePaths record. The existing original v7 bridge suite remains the qualification test owner. Prepared-unapplied942 assertions remain excluded. Operational Host documentation is recorded as a separate documentation/Help input, outside the existing source-only inventory boundary.

## Commands after owner freeze

These are ordered preparation instructions, not commands executed by this audit.

1. Obtain exact final Host and Native source manifests/receipts; compose the source checkpoint with all final55 and capability/constructor followups, preserve Project changes, and commit the reviewed source freeze. Record a full frozen HEAD. Do not reuse Host26/NativeR104 hashes if a successor changes bytes.
2. The original read-only audit command below is historical R1 reproduction only; do not rerun it over frozen R1 outputs. R2 is the current pinned owner-plan successor. Any later path-set change needs another explicit successor plan:

   `python3 /workspace/v10-preparation/final-metadata-inventory-audit-nov01/prepare-owner-plan.py`

3. On a private copy of the frozen source manifest, apply `consolidatedAdditions` to each exact `existingOwnerGroup`: add current membership to sourcePaths; add sourceBeforePin from the declared base; classify changedSourcePaths from the exact frozen base/head comparison. Do not add groups or change requirements/statuses. Remove the six absent-at-base noncurrent paths listed in the earlier input map from current/changed/pin lists, retaining retirement provenance separately. Never add those paths to deletedSourcePaths. Recompute sourceInventoryBoundary from the exact frozen source diff plus explicitly retained current untracked-source policy, rather than incrementing old counts mechanically.
4. Assert source base,50 group IDs,25 hotspot IDs,169 historical status map and complete requirementsCrosswalk equality before/after the private manifest edit. Required digests are recorded below and in updated-owner-plan.json. Review/publish only this explicit metadata delta through the parent owner.
5. Once that reviewed manifest and exact frozen source are in place, run the existing commands in the frozen repository under the normal shared-lock discipline:

   `node scripts/generate-v10-safe-change-graph.mjs`

   `node scripts/generate-v10-safe-change-graph.mjs --check`

   `node scripts/check-v10-safe-change-graph.mjs`

6. Continue the existing `/workspace/v10-preparation/final-metadata-refresh-plan-nov01/input-map.json` sequence: reviewed Help pairs/search, mounted UI coverage, V10-122 aliases (preserve active compatibility mappings), migration67-row phase candidate, then R4/append-only Nov1 claims amendment. Use committed frozen base/head for Help. No component source/test receipt closes physical/runtime/provider/pricing/Human/release gates.

Historical status-map SHA256: `e6630ae7f08def7034bdc1fc25fed68a8ea8ce216a9fe9938256a25eae06e19f`.

Full requirements-crosswalk SHA256: `e5a38122df824b06c9dbc2c2ccf687cd4be004ac390df7081e66460d3664b8bd`.

## Executable private manifest edit helper

`edit-frozen-source-inventory.py` now implements step3, including membership/pin repair and the exact eight-key sourceInventoryBoundary. It refuses tracked worktree/index changes, untracked files outside the unrelated evidence allowance, unexpected HEAD, changed manifest/plan pin, altered historical statuses/crosswalk, unknown groups, missing planned files, unexpected retirement, source symlinks and any new source delta without an explicit reviewed owner. It reads immutable Git blobs for base pins and base/HEAD membership. It writes a new manifest plus a compact adjacent receipt only under `/workspace/v10-preparation`, outside the frozen root/Main/Mirror. It neither applies the manifest nor invokes graph generation. Existing private output files cannot be overwritten.

Execution is **pending final clean source freeze**. Only Python syntax was parsed during preparation; this helper has not been run against current unstable application source.

After the parent records the final clean commit and exact input manifest pin, invoke (replace every angle-bracket value with the reviewed frozen input):

```sh
python3 /workspace/v10-preparation/final-metadata-inventory-audit-nov01/edit-frozen-source-inventory-r2.py \
  --frozen-root '<clean-frozen-worktree-root>' \
  --expected-head '<exact-40-character-frozen-HEAD>' \
  --source-manifest '<exact-input-manifest-path>' \
  --expected-manifest-sha256 '<reviewed-input-manifest-SHA256>' \
  --owner-plan /workspace/v10-preparation/final-metadata-inventory-audit-nov01/updated-owner-plan-r3.json \
  --expected-owner-plan-sha256 f75c5904dd7242bc682ee96808d47c02cef04396bd54bd6e94825e4e16d3d039 \
  --output /workspace/v10-preparation/final-metadata-inventory-audit-nov01/final-frozen-source-manifest.json
```

The output basename must be unused, its private parent directory must exist, and the frozen Git index/tracked files must be clean. Untracked files are allowed only under `doc/operations/aw-v10-evidence/`, and never when named by current sourcePaths, planned additions, sourceInputs, the historical register, or a repository-local manifest/owner-plan input. Every named current source/input must be tracked at the frozen HEAD. Unrelated evidence is neither read nor staged/deleted. If final successor source adds a path outside the reviewed inventory, the helper stops with its exact path list; assign those paths explicitly through an updated reviewed owner plan rather than changing the coverage check. The output boundary's changed/deleted counts derive from unique repaired membership intersected with actual no-rename base/HEAD diff, fullDiffPathCount from that full diff, and untrackedSourceCandidateCount is zero because only unrelated non-source evidence may remain untracked; the receipt records its count/prefix without treating it as source. No historical acceptance field or complete crosswalk content is rewritten.

The bounded evidence-allowance guard was updated on request; only syntax was parsed. Final execution still awaits the source freeze. All historical status/crosswalk constants and50/25 group assertions remain unchanged.

## R2 successor: coherent Host50 selector test

R1 plan/helper remain byte-identical. `updated-owner-plan-r2.json` adds exactly `server/src/__tests__/sandbox-endpoint-network-selectors.test.ts` to the existing Native authority group, with an actual absent-at-base pin from81d3445 and source-only26/31 component receipt references. It has54 total owner additions and preserves50 groups,25 hotspots,169 statuses and the full crosswalk digest. The frozen Host50 inventory audit finds no uncovered code paths; operational Host documentation remains deliberately separate. `updated-owner-plan-r2-pins.json` and `updated-owner-plan-r2-audit.json` record exact pins and scope.

The original helper hardcoded53, so a minimal R2 successor helper reads the reviewed count from the pinned plan instead. It retains every freeze/evidence/status/path guard; R1 helper is untouched. The executable invocation above now uses ONLY the R2 plan pin and successor helper. R2 helper was syntax-parsed, never executed. No graph generation, tests, Main or Mirror mutations occurred.

## R3 successor: Host60 exact task-boundary claim fixture

Current invocation now selects `updated-owner-plan-r3.json` SHA256 `f75c5904dd7242bc682ee96808d47c02cef04396bd54bd6e94825e4e16d3d039`. It adds exactly the absent-at-base `server/src/__tests__/native-fixture-agent-claim.integration.test.ts` to the existing Native authority group, for55 total additions. R1/R2 are unchanged. The R2 helper is already parameterized and reused byte-identically; no new helper code or execution is required. Host60's105-entry membership audit has no uncovered code paths; the operational Host document remains separate. The audit claims no PG11/Host60/journey pass from source presence.50 groups,25 hotspots,169 statuses and the full crosswalk digest remain unchanged.
