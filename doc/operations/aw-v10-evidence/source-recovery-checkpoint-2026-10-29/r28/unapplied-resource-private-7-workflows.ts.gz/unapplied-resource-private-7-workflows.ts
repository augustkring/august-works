import { sql } from "drizzle-orm";
import {
  type AnyPgColumn,
  bigint,
  check,
  index,
  integer,
  jsonb,
  foreignKey,
  pgTable,
  text,
  timestamp,
  unique,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";
import type {
  ExecutionPrincipal,
  WorkflowGraphV1,
  WorkflowJsonSchema,
  WorkflowWaitKind,
  WorkflowWaitStatus,
} from "@paperclipai/shared";
import { agents } from "./agents.js";
import { authUsers } from "./auth.js";
import { companies } from "./companies.js";
import { folders } from "./folders.js";
import { heartbeatRuns } from "./heartbeat_runs.js";
import { issues } from "./issues.js";
import { projects } from "./projects.js";

export const workflows = pgTable(
  "workflows",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    companyId: uuid("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    projectId: uuid("project_id").references(() => projects.id, { onDelete: "set null" }),
    folderId: uuid("folder_id").references(() => folders.id, { onDelete: "set null" }),
    name: text("name").notNull(),
    description: text("description"),
    status: text("status").notNull().default("active"),
    publishedRevisionId: uuid("published_revision_id"),
    draftRevisionId: uuid("draft_revision_id"),
    createdByUserId: text("created_by_user_id"),
    createdByAgentId: uuid("created_by_agent_id").references(() => agents.id, { onDelete: "set null" }),
    // Native authoring provenance survives later Human revisions and source-run
    // removal. These IDs confer no read, execution or permission authority.
    authoringSourceRunIds: jsonb("authoring_source_run_ids").$type<string[]>().notNull().default([]),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
    archivedAt: timestamp("archived_at", { withTimezone: true }),
  },
  (table) => ({
    companyIdIdUq: uniqueIndex("workflows_company_id_id_uq").on(
      table.companyId,
      table.id,
    ),
    companyStatusIdx: index("workflows_company_status_idx").on(table.companyId, table.status),
    companyUpdatedIdx: index("workflows_company_updated_idx").on(table.companyId, table.updatedAt),
    companyProjectIdx: index("workflows_company_project_idx").on(table.companyId, table.projectId),
    companyFolderIdx: index("workflows_company_folder_idx").on(table.companyId, table.folderId),
    statusCheck: check(
      "workflows_status_check",
      sql`${table.status} in ('active', 'paused', 'archived')`,
    ),
    authoringSourcesCheck: check("workflows_authoring_sources_check",
      sql`jsonb_typeof(${table.authoringSourceRunIds}) = 'array'`),
    archiveCheck: check(
      "workflows_archive_check",
      sql`(${table.status} = 'archived') = (${table.archivedAt} is not null)`,
    ),
    distinctRevisionPointersCheck: check(
      "workflows_distinct_revision_pointers_check",
      sql`${table.publishedRevisionId} is null or ${table.draftRevisionId} is null or ${table.publishedRevisionId} <> ${table.draftRevisionId}`,
    ),
  }),
);

export const workflowRuns = pgTable(
  "workflow_runs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    companyId: uuid("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    workflowId: uuid("workflow_id")
      .notNull()
      .references(() => workflows.id, { onDelete: "cascade" }),
    workflowRevisionId: uuid("workflow_revision_id")
      .notNull()
      .references(() => workflowRevisions.id, { onDelete: "cascade" }),
    triggerId: uuid("trigger_id"),
    status: text("status").notNull().default("queued"),
    source: text("source").notNull().default("manual"),
    triggerPayload: jsonb("trigger_payload").$type<Record<string, unknown>>().notNull().default({}),
    responsibleUserId: text("responsible_user_id"),
    executionPrincipal: jsonb("execution_principal").$type<ExecutionPrincipal>(),
    humanCoverageId: uuid("human_coverage_id"),
    // Actual private workflow copy owners retained across child-run removal.
    // Native capture propagates these IDs to the existing parent run chain.
    authoringSourceWorkflowIds: jsonb("authoring_source_workflow_ids").$type<string[]>().notNull().default([]),
    memoryRecordIds: jsonb("memory_record_ids").$type<string[]>().notNull().default([]),
    parentWorkflowRunId: uuid("parent_workflow_run_id").references((): AnyPgColumn => workflowRuns.id, { onDelete: "set null" }),
    parentNodeId: text("parent_node_id"),
    executionAgentRunId: uuid("execution_agent_run_id").references(() => heartbeatRuns.id, { onDelete: "set null" }),
    idempotencyKey: text("idempotency_key"),
    correlationId: text("correlation_id"),
    retryOfRunId: uuid("retry_of_run_id").references(
      (): AnyPgColumn => workflowRuns.id,
      { onDelete: "set null" },
    ),
    idempotencyRootRunId: uuid("idempotency_root_run_id").references(
      (): AnyPgColumn => workflowRuns.id,
      { onDelete: "set null" },
    ),
    executionOwnerId: text("execution_owner_id"),
    leaseExpiresAt: timestamp("lease_expires_at", { withTimezone: true }),
    ownerHeartbeatAt: timestamp("owner_heartbeat_at", { withTimezone: true }),
    startedAt: timestamp("started_at", { withTimezone: true }),
    finishedAt: timestamp("finished_at", { withTimezone: true }),
    failureCode: text("failure_code"),
    failureMessage: text("failure_message"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    resourceActiveIdx: index("workflow_runs_resource_active_idx").on(table.companyId, table.id)
      .where(sql`${table.status} in ('running','recovering','cancelling')`),
    resourceQueuedIdx: index("workflow_runs_resource_queued_idx").on(table.companyId, table.updatedAt, table.id)
      .where(sql`${table.status}='queued'`),
    resourceProgressIdx: index("workflow_runs_resource_progress_idx").on(table.companyId, table.updatedAt.desc(), table.id.desc())
      .where(sql`${table.startedAt} is not null`),
    companyIdUq: unique("workflow_runs_company_id_uq").on(table.companyId, table.id),
    authoringSourcesIdx: index("workflow_runs_authoring_sources_idx").using("gin", table.authoringSourceWorkflowIds),
    authoringSourcesCheck: check("workflow_runs_authoring_sources_check",
      sql`jsonb_typeof(${table.authoringSourceWorkflowIds}) = 'array'`),
    companyWorkflowCreatedIdx: index("workflow_runs_company_workflow_created_idx").on(
      table.companyId,
      table.workflowId,
      table.createdAt,
    ),
    companyStatusCreatedIdx: index("workflow_runs_company_status_created_idx").on(
      table.companyId,
      table.status,
      table.createdAt,
    ),
    companyRetryOfIdx: index("workflow_runs_company_retry_of_idx").on(
      table.companyId,
      table.retryOfRunId,
      table.createdAt,
    ),
    companyIdempotencyRootIdx: index("workflow_runs_company_idempotency_root_idx").on(
      table.companyId,
      table.idempotencyRootRunId,
      table.createdAt,
    ),
    companyIdempotencyUq: uniqueIndex("workflow_runs_company_idempotency_uq")
      .on(table.companyId, table.idempotencyKey)
      .where(sql`${table.idempotencyKey} is not null`),
    statusCheck: check(
      "workflow_runs_status_check",
      sql`${table.status} in ('queued', 'running', 'waiting', 'recovering', 'cancelling', 'succeeded', 'failed', 'cancelled')`,
    ),
    sourceCheck: check(
      "workflow_runs_source_check",
      sql`${table.source} in ('manual', 'schedule', 'webhook', 'api', 'connector_event', 'routine', 'pipeline', 'task', 'test')`,
    ),
    leasePairCheck: check(
      "workflow_runs_lease_pair_check",
      sql`(${table.executionOwnerId} is null) = (${table.leaseExpiresAt} is null)`,
    ),
    retryLineagePairCheck: check(
      "workflow_runs_retry_lineage_pair_check",
      sql`${table.retryOfRunId} is null or ${table.idempotencyRootRunId} is not null`,
    ),
    terminalLeaseCheck: check(
      "workflow_runs_terminal_lease_check",
      sql`${table.status} not in ('succeeded', 'failed', 'cancelled') or (${table.executionOwnerId} is null and ${table.leaseExpiresAt} is null)`,
    ),
    terminalFinishedCheck: check(
      "workflow_runs_terminal_finished_check",
      sql`${table.status} not in ('succeeded', 'failed', 'cancelled') or ${table.finishedAt} is not null`,
    ),
  }),
);

export const workflowStepRuns = pgTable(
  "workflow_step_runs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    companyId: uuid("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    workflowRunId: uuid("workflow_run_id")
      .notNull()
      .references(() => workflowRuns.id, { onDelete: "cascade" }),
    nodeId: text("node_id").notNull(),
    attempt: integer("attempt").notNull().default(1),
    status: text("status").notNull().default("pending"),
    inputJson: jsonb("input_json").$type<unknown>(),
    outputJson: jsonb("output_json").$type<unknown>(),
    failureResolution: jsonb("failure_resolution").$type<{ policy: "follow_failure_branch" | "continue_with_null" | "wait_for_human"; resolved: boolean }>(),
    memoryRecordIds: jsonb("memory_record_ids").$type<string[]>().notNull().default([]),
    taskResultJson: jsonb("task_result_json").$type<unknown>(),
    taskResultAcceptedAt: timestamp("task_result_accepted_at", { withTimezone: true }),
    taskResultRunId: uuid("task_result_run_id").references(() => heartbeatRuns.id, { onDelete: "set null" }),
    childWorkflowRunId: uuid("child_workflow_run_id").references(() => workflowRuns.id, { onDelete: "set null" }),
    startedAt: timestamp("started_at", { withTimezone: true }),
    finishedAt: timestamp("finished_at", { withTimezone: true }),
    durationMs: bigint("duration_ms", { mode: "number" }),
    agentId: uuid("agent_id").references(() => agents.id, { onDelete: "set null" }),
    heartbeatRunId: uuid("heartbeat_run_id").references(() => heartbeatRuns.id, { onDelete: "set null" }),
    toolInvocationId: uuid("tool_invocation_id"),
    automationArtifactVersionId: uuid("automation_artifact_version_id"),
    errorCode: text("error_code"),
    errorMessage: text("error_message"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    runNodeAttemptUq: uniqueIndex("workflow_step_runs_run_node_attempt_uq").on(
      table.workflowRunId,
      table.nodeId,
      table.attempt,
    ),
    companyRunStatusIdx: index("workflow_step_runs_company_run_status_idx").on(
      table.companyId,
      table.workflowRunId,
      table.status,
    ),
    heartbeatRunIdx: index("workflow_step_runs_company_heartbeat_idx").on(table.companyId, table.heartbeatRunId),
    statusCheck: check(
      "workflow_step_runs_status_check",
      sql`${table.status} in ('pending', 'running', 'waiting', 'retry_scheduled', 'retried', 'succeeded', 'failed', 'skipped', 'cancelling', 'cancelled')`,
    ),
    attemptCheck: check(
      "workflow_step_runs_attempt_check",
      sql`${table.attempt} >= 1`,
    ),
    durationCheck: check(
      "workflow_step_runs_duration_check",
      sql`${table.durationMs} is null or ${table.durationMs} >= 0`,
    ),
    terminalFinishedCheck: check(
      "workflow_step_runs_terminal_finished_check",
      sql`${table.status} not in ('retried', 'succeeded', 'failed', 'skipped', 'cancelled') or ${table.finishedAt} is not null`,
    ),
  }),
);

export const workflowWaits = pgTable(
  "workflow_waits",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    companyId: uuid("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    workflowRunId: uuid("workflow_run_id")
      .notNull()
      .references(() => workflowRuns.id, { onDelete: "cascade" }),
    nodeId: text("node_id").notNull(),
    waitKey: text("wait_key").notNull(),
    kind: text("kind").$type<WorkflowWaitKind>().notNull(),
    status: text("status").$type<WorkflowWaitStatus>().notNull().default("active"),
    wakeAt: timestamp("wake_at", { withTimezone: true }),
    timeoutAt: timestamp("timeout_at", { withTimezone: true }),
    referenceType: text("reference_type"),
    referenceId: text("reference_id"),
    signalTokenHash: text("signal_token_hash"),
    resolutionJson: jsonb("resolution_json").$type<unknown>(),
    resolvedByType: text("resolved_by_type"),
    resolvedById: text("resolved_by_id"),
    resolvedAt: timestamp("resolved_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    companyRunStatusIdx: index("workflow_waits_company_run_status_idx").on(
      table.companyId,
      table.workflowRunId,
      table.status,
    ),
    statusWakeIdx: index("workflow_waits_status_wake_idx").on(
      table.status,
      table.wakeAt,
    ),
    runNodeActiveUq: uniqueIndex("workflow_waits_run_node_active_uq")
      .on(table.workflowRunId, table.nodeId, table.waitKey)
      .where(sql`${table.status} = 'active'`),
    signalTokenHashUq: uniqueIndex("workflow_waits_signal_token_hash_uq")
      .on(table.signalTokenHash)
      .where(sql`${table.signalTokenHash} is not null`),
    kindCheck: check(
      "workflow_waits_kind_check",
      sql`${table.kind} in ('delay', 'human_interaction', 'external_callback', 'task_completion', 'external_agent_run', 'direct_agent_run', 'tool_action', 'subworkflow')`,
    ),
    statusCheck: check(
      "workflow_waits_status_check",
      sql`${table.status} in ('active', 'resolved', 'timed_out', 'cancelled')`,
    ),
    terminalResolutionCheck: check(
      "workflow_waits_terminal_resolution_check",
      sql`(${table.status} = 'active' and ${table.resolvedAt} is null) or (${table.status} <> 'active' and ${table.resolvedAt} is not null)`,
    ),
    delayWakeCheck: check(
      "workflow_waits_delay_wake_check",
      sql`${table.kind} <> 'delay' or ${table.wakeAt} is not null`,
    ),
    callbackSignalCheck: check(
      "workflow_waits_callback_signal_check",
      sql`${table.kind} <> 'external_callback' or ${table.signalTokenHash} is not null`,
    ),
  }),
);

export const workflowRevisions = pgTable(
  "workflow_revisions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    companyId: uuid("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    workflowId: uuid("workflow_id")
      .notNull()
      .references(() => workflows.id, { onDelete: "cascade" }),
    revisionNumber: integer("revision_number").notNull(),
    state: text("state").notNull().default("draft"),
    graph: jsonb("graph_json").$type<WorkflowGraphV1>().notNull(),
    inputSchema: jsonb("input_schema").$type<WorkflowJsonSchema | null>(),
    outputSchema: jsonb("output_schema").$type<WorkflowJsonSchema | null>(),
    changeSummary: text("change_summary"),
    createdByUserId: text("created_by_user_id"),
    createdByAgentId: uuid("created_by_agent_id").references(() => agents.id, { onDelete: "set null" }),
    createdByRunId: uuid("created_by_run_id").references(() => heartbeatRuns.id, { onDelete: "set null" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    companyWorkflowIdUq: unique("workflow_revisions_company_workflow_id_uq").on(table.companyId, table.workflowId, table.id),
    workflowRevisionUq: uniqueIndex("workflow_revisions_workflow_revision_uq").on(
      table.workflowId,
      table.revisionNumber,
    ),
    companyWorkflowStateIdx: index("workflow_revisions_company_workflow_state_idx").on(
      table.companyId,
      table.workflowId,
      table.state,
    ),
    companyAuthoringRunIdx: index("workflow_revisions_company_authoring_run_idx").on(
      table.companyId,
      table.createdByRunId,
      table.createdAt,
    ),
    oneDraftUq: uniqueIndex("workflow_revisions_one_draft_uq")
      .on(table.workflowId)
      .where(sql`${table.state} = 'draft'`),
    onePublishedUq: uniqueIndex("workflow_revisions_one_published_uq")
      .on(table.workflowId)
      .where(sql`${table.state} = 'published'`),
    stateCheck: check(
      "workflow_revisions_state_check",
      sql`${table.state} in ('draft', 'published', 'superseded', 'discarded')`,
    ),
  }),
);

/**
 * Temporary Human-to-Human routing scope for one exact published workflow
 * revision. This is not a permission grant: both Users retain their own
 * current company and resource authorization at admission and dispatch.
 */
export const humanWorkflowCoverages = pgTable("human_workflow_coverages", {
  id: uuid("id").primaryKey().defaultRandom(),
  requestId: uuid("request_id").notNull(),
  companyId: uuid("company_id").notNull().references(() => companies.id, { onDelete: "cascade" }),
  principalUserId: text("principal_user_id").notNull().references(() => authUsers.id, { onDelete: "cascade" }),
  delegateeUserId: text("delegatee_user_id").notNull().references(() => authUsers.id, { onDelete: "cascade" }),
  actionKey: text("action_key").notNull().default("workflows:run"),
  workflowId: uuid("workflow_id").notNull(),
  workflowRevisionId: uuid("workflow_revision_id").notNull(),
  scopeType: text("scope_type").notNull(),
  taskId: uuid("task_id"),
  startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  reason: text("reason").notNull(),
  revokedAt: timestamp("revoked_at", { withTimezone: true }),
  revokedByUserId: text("revoked_by_user_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => ({
  companyIdUq: unique("human_workflow_coverages_company_id_uq").on(table.companyId, table.id),
  requestUq: unique("human_workflow_coverages_company_request_uq").on(table.companyId, table.requestId),
  workflowRevisionFk: foreignKey({
    name: "human_workflow_coverages_revision_fk",
    columns: [table.companyId, table.workflowId, table.workflowRevisionId],
    foreignColumns: [workflowRevisions.companyId, workflowRevisions.workflowId, workflowRevisions.id],
  }).onDelete("cascade"),
  workflowFk: foreignKey({
    name: "human_workflow_coverages_workflow_fk",
    columns: [table.companyId, table.workflowId],
    foreignColumns: [workflows.companyId, workflows.id],
  }).onDelete("cascade"),
  taskFk: foreignKey({
    name: "human_workflow_coverages_task_fk",
    columns: [table.companyId, table.taskId],
    foreignColumns: [issues.companyId, issues.id],
  }).onDelete("cascade"),
  actionCheck: check("human_workflow_coverages_action_check", sql`${table.actionKey} = 'workflows:run'`),
  scopeCheck: check("human_workflow_coverages_scope_check",
    sql`(${table.scopeType} = 'manual' and ${table.taskId} is null) or (${table.scopeType} = 'task' and ${table.taskId} is not null)`),
  intervalCheck: check("human_workflow_coverages_interval_check",
    sql`${table.expiresAt} > ${table.startsAt} and ${table.reason} <> ''`),
  revocationPairCheck: check("human_workflow_coverages_revocation_pair_check",
    sql`${table.revokedAt} is not null or ${table.revokedByUserId} is null`),
  principalIdx: index("human_workflow_coverages_principal_idx").on(table.companyId, table.principalUserId, table.expiresAt),
  delegateeIdx: index("human_workflow_coverages_delegatee_idx").on(table.companyId, table.delegateeUserId, table.expiresAt),
}));
