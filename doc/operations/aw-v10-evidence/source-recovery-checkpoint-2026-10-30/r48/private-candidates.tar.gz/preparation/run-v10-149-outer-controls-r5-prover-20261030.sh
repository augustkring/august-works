#!/usr/bin/env bash
set -uo pipefail
REPO=/workspace/blentera-v10
MIRROR=/workspace/v10-dep-qualification
CAND=/workspace/v10-preparation/v10-149-openshell-outer-controls-r5
PROVER=/workspace/v10-preparation/tools/openshell-prover-v0.1.2/openshell-prover
EXPECTED=3e80c0d041a7552d57cc338868bc825a6261e21b5f29a7d7527bcc7926d423f1
OUT=/workspace/v10-preparation/v10-149-openshell-outer-controls-r5-prover-qualification-r1
mkdir -m 700 "$OUT" || exit 73
exec 9>/workspace/v10-preparation/v10-pg-tests.lock
flock -x 9
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH
actual=$(sha256sum "$PROVER" | awk '{print $1}')
printf '%s\n' "$actual" > "$OUT/prover-binary.sha256"
if [[ "$actual" != "$EXPECTED" ]]; then echo "unexpected prover binary hash: $actual" > "$OUT/prover-check.log"; exit 78; fi
cd "$REPO" || exit 70
restore_overlay() {
 python3 - "$CAND/source-pins-r5.json" "$MIRROR" "$OUT/restore-files" "$OUT/restore.log" <<'PY'
from pathlib import Path
import hashlib,json,shutil,sys
pins=json.loads(Path(sys.argv[1]).read_text())['files']; mirror=Path(sys.argv[2]); backup=Path(sys.argv[3]); log=Path(sys.argv[4]); failures=[]
for row in pins:
 p=row['path']; target=mirror/p; actual=hashlib.sha256(target.read_bytes()).hexdigest() if target.is_file() else None
 if actual==row['candidate_sha256']:
  saved=backup/p
  if not saved.is_file() or hashlib.sha256(saved.read_bytes()).hexdigest()!=row['baseline_sha256']: failures.append(f'BASELINE_BACKUP_BAD {p}'); continue
  shutil.copy2(saved,target)
 elif actual!=row['baseline_sha256']: failures.append(f'RESTORE_GUARD_MISMATCH {p} actual={actual}')
for row in pins:
 p=row['path']; target=mirror/p; actual=hashlib.sha256(target.read_bytes()).hexdigest() if target.is_file() else None
 if actual!=row['baseline_sha256']: failures.append(f'POST_RESTORE_MISMATCH {p} actual={actual}')
log.write_text('\n'.join(failures)+('\n' if failures else 'source overlay restored byte-for-byte\n'))
if failures: raise SystemExit(1)
PY
}
restore_build_state() {
 python3 - "$OUT/build-state" "$MIRROR" "$OUT/build-restore.log" <<'PY'
from pathlib import Path
import hashlib,shutil,sys
backup=Path(sys.argv[1]); mirror=Path(sys.argv[2]); log=Path(sys.argv[3]); failures=[]
def treehash(root): return [(p.relative_to(root).as_posix(),hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(root.rglob('*')) if p.is_file()]
for name in ('packages/shared/dist','packages/db/dist','server/dist'):
 src=backup/name; dst=mirror/name
 if src.exists() and treehash(src)!=treehash(dst):
  if dst.exists(): shutil.rmtree(dst)
  shutil.copytree(src,dst)
  if treehash(src)!=treehash(dst): failures.append(f'DIST_RESTORE_MISMATCH {name}')
prior={p.relative_to(backup/'tsbuildinfo').as_posix():p for p in (backup/'tsbuildinfo').rglob('*') if p.is_file()} if (backup/'tsbuildinfo').exists() else {}
current={p.relative_to(mirror).as_posix():p for p in mirror.rglob('*.tsbuildinfo') if p.is_file()}
for rel,p in current.items():
 if rel not in prior: p.unlink(); continue
 if hashlib.sha256(p.read_bytes()).digest()!=hashlib.sha256(prior[rel].read_bytes()).digest(): shutil.copy2(prior[rel],p)
for rel,saved in prior.items():
 target=mirror/rel
 if not target.exists(): target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(saved,target)
 if hashlib.sha256(target.read_bytes()).digest()!=hashlib.sha256(saved.read_bytes()).digest(): failures.append(f'TSBUILDINFO_RESTORE_MISMATCH {rel}')
log.write_text('\n'.join(failures)+('\n' if failures else 'compiled output and tsbuildinfo restored byte-for-byte\n'))
if failures: raise SystemExit(1)
PY
}
cleanup() {
 if [[ -f "$OUT/overlay-ready" ]] && [[ $(cat "$OUT/overlay-ready") == 1 ]]; then restore_overlay || echo restore_overlay_failed=1 >> "$OUT/restore.log"; fi
 if [[ ${BUILD_BACKUP_READY:-0} == 1 ]]; then restore_build_state || echo restore_build_state_failed=1 >> "$OUT/build-restore.log"; fi
}
trap cleanup EXIT INT TERM
python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$OUT/snapshot-source-pins.json" > "$OUT/snapshot.log" 2>&1
rc=$?; printf '%s\n' "$rc" > "$OUT/snapshot.exit"; if ((rc)); then exit "$rc"; fi
node /workspace/v10-preparation/check-snapshot-syntax.cjs "$OUT/snapshot-source-pins.json" > "$OUT/snapshot-syntax.log" 2>&1
rc=$?; printf '%s\n' "$rc" > "$OUT/snapshot-syntax.exit"; if ((rc)); then exit "$rc"; fi
python3 - "$CAND/source-pins-r5.json" "$CAND/files" "$REPO" "$MIRROR" "$OUT/restore-files" <<'PY'
from pathlib import Path
import hashlib,json,shutil,sys
pins=json.loads(Path(sys.argv[1]).read_text())['files']; candidate=Path(sys.argv[2]); repo=Path(sys.argv[3]); mirror=Path(sys.argv[4]); backup=Path(sys.argv[5]); out=backup.parent; records=[]
for row in pins:
 p=row['path']
 for label,file,expected in [('MAIN baseline',repo/p,row['baseline_sha256']),('mirror snapshot',mirror/p,row['baseline_sha256']),('candidate',candidate/p,row['candidate_sha256'])]:
  actual=hashlib.sha256(file.read_bytes()).hexdigest() if file.is_file() else None
  if actual!=expected: raise SystemExit(f'{label} hash mismatch {p}: {actual} != {expected}')
 saved=backup/p; saved.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(mirror/p,saved); records.append({'path':p,'baseline_sha256':row['baseline_sha256'],'candidate_sha256':row['candidate_sha256']})
(out/'overlay-pins.json').write_text(json.dumps({'files':records},indent=2)+'\n'); (out/'overlay-ready').write_text('1\n')
for row in pins: shutil.copy2(candidate/row['path'],mirror/row['path'])
for row in pins:
 actual=hashlib.sha256((mirror/row['path']).read_bytes()).hexdigest()
 if actual!=row['candidate_sha256']: raise SystemExit(f'overlay hash mismatch {row["path"]}: {actual}')
PY
rc=$?; if ((rc)); then exit "$rc"; fi
mkdir -p "$OUT/build-state"
for d in packages/shared/dist packages/db/dist server/dist; do if [[ -d "$MIRROR/$d" ]]; then mkdir -p "$OUT/build-state/$(dirname "$d")"; cp -a "$MIRROR/$d" "$OUT/build-state/$d"; fi; done
mkdir -p "$OUT/build-state/tsbuildinfo"
find "$MIRROR" -name '*.tsbuildinfo' -type f -print0 | while IFS= read -r -d '' f; do rel=${f#"$MIRROR/"}; mkdir -p "$OUT/build-state/tsbuildinfo/$(dirname "$rel")"; cp -a "$f" "$OUT/build-state/tsbuildinfo/$rel"; done
BUILD_BACKUP_READY=1
cd "$MIRROR/server" || exit 70
AW_V7_OPENSHELL_PROVER="$PROVER" pnpm exec vitest run src/__tests__/v7-openshell-backend.test.ts --maxWorkers=1 --reporter=verbose > "$OUT/openshell-backend.test.log" 2>&1
rc=$?; printf '%s\n' "$rc" > "$OUT/openshell-backend.test.exit"
exit "$rc"
