# Private managed Project/worktree preparation

Immutable R3 successor to R2. Source only on Main `ead2a89b1eedcc45364870a897eff4508a175ac4`. No tests, compiler, SDK, Main/Mirror write or qualification claim.

The existing `withManagedNativeHeartbeatFixture` invokes `prepareNativeRuntimeContext` before reading/fixing Adapter configuration, discovering capabilities and qualifying its Worker profile. Its `configureHeartbeat` runs before `driveScheduler` can quote/start a Plan. The new helper composes these exact two hooks; it adds no preparation callback or lifecycle registry.

The preparation hook seeds real Git bytes, uses the current existing authenticated session and actual Project HTTP route to capture a same-company Project plus non-null `file://` Git repository workspace. It then sets Git-worktree strategy on the Agent before qualification and enables the existing isolated-workspace feature flags. It never inserts a Run, Plan, WorkerAttempt or ExecutionWorkspace, changes a live deadline, or passes a caller-selected cwd into Host admission. The actual scheduler and workspace runtime must select/realize/persist the worktree.

The Host delta adds only explicit `ordinaryWorkerProject: {projectId,projectWorkspaceId}`. Without it, the exact original Agent Home cwd/null-Git tuple remains required. With it, preparation checks the current Human Project ACL and original captured Project owner, real Task association, active persisted execution workspace and active original Run lease, exact Native tuple/lease root, and actual Git top-level/branch/common directory. The existing bootstrap task digest/workspace source-currentness checks still run before binding/policy/Host effects. The policy continues using the exact derived taskRoot rather than the directory containing sibling worktrees.

Use the returned hooks with `withManagedNativeHeartbeatFixture`; inside its real `driveScheduler`, obtain `projectFixture.project().projectId`, and create the Task/Plan/wakeup via existing domain services. Do not edit Adapter strategy after quote/manifest/profile creation. This helper currently selects fresh runtime-owned local Git worktrees only.

The managed Project-create suite uses a first-party tool to create its output Project; it does not need an existing Project input just because its name contains Project. Its managed capture/source-set/privacy/replay assertions remain distinct. Project-create-wait retains real Task row blocking and stale source denial. The legacy three finalize-branch adapter callbacks directly mutate Git/Task rows, so their existing owner evidence must not be presented as managed model actions.

Merge boundary: Host parent is exact Main `a30fbd3d...`. Sourceowner independently changes the same helper for serial socket injection; merge these small optional-Project hunks via a pinned three-way merge only after both source reviews, never by copying an entire stale helper. No changes to heartbeat helper, conversation frame or legacy OpenCode helper. Focused actual negative controls and qualification limits are in `negative-case-plan.json`.

Validation so far: `git apply --check` only. This is patch applicability, not TypeScript or runtime evidence.

R2 checks an explicit Task ProjectWorkspace pointer and original lease future-expiry/root twice. The final Task/lease recheck and existing workspace source-currentness run in the same transaction; the unchanged outer late expiry check remains. No parent repository or common-Git directory is added to Sandbox filesystem policy.

Review correction: Root retracted the R1 policy-root blocker after observing the existing immediately following assignments. The effective policy already used `taskRoot` plus unchanged runtime binary read paths, with exact `taskRoot` write scope. R3 removes the redundant old initial assignments and R2 conditional variable entirely; it preserves those original final effective assignments exactly. No policy expansion or default change.

Source type inspection: `authorizationService` already accepts `Db | DbTransaction` (authorization.ts2108), using the identical transaction type alias as this helper and native-direct-input.ts. No cast, bypass or service signature change is needed. This is source-level compatibility evidence, not a compiler pass; scoped semantic checking awaits review/Sourceowner scheduling.
