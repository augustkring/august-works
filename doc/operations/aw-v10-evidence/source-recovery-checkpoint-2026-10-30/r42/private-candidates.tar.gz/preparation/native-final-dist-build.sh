# Sourced by the canonical locked qualification runner after source capture.
if [[ "$ROOT" != /workspace/v10-dep-qualification ]]; then exit 64; fi
native_dist_scratch="$(mktemp -d /tmp/native-final-dist-backup.XXXXXX)" || exit 1
for native_dist_package in db shared; do
  if [[ ! -d "$ROOT/packages/$native_dist_package/dist" || -L "$ROOT/packages/$native_dist_package/dist" ]]; then exit 64; fi
  cp -a "$ROOT/packages/$native_dist_package/dist" "$native_dist_scratch/$native_dist_package" || exit 1
done
restore_native_qualification_dist() {
  local native_restore_rc=0
  for native_dist_package in db shared; do
    rm -rf "$ROOT/packages/$native_dist_package/dist"
    cp -a "$native_dist_scratch/$native_dist_package" "$ROOT/packages/$native_dist_package/dist" || native_restore_rc=$?
  done
  if [[ "$native_restore_rc" -eq 0 ]]; then rm -rf "$native_dist_scratch"; fi
  printf "%s\n" "$native_restore_rc" > "$OUT/$NAME-dist-restore.exit"
  if [[ "$native_restore_rc" -ne 0 ]]; then exit "$native_restore_rc"; fi
}
trap restore_native_qualification_dist EXIT
for native_dist_package in shared db; do
  (cd "$ROOT/packages/$native_dist_package" && pnpm run build) > "$OUT/$NAME-$native_dist_package-build.log" 2>&1
  native_dist_build_rc=$?
  printf "%s\n" "$native_dist_build_rc" > "$OUT/$NAME-$native_dist_package-build.exit"
  if [[ "$native_dist_build_rc" -ne 0 ]]; then printf "%s\n" "$native_dist_build_rc" > "$OUT/$NAME.exit"; exit "$native_dist_build_rc"; fi
done
