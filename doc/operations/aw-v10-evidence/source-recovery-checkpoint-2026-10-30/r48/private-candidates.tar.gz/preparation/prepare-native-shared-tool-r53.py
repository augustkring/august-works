from pathlib import Path
import hashlib,json,difflib
r=Path('/workspace/blentera-v10');o=Path('/workspace/v10-preparation/native-shared-tool-r53-candidate');rel='server/src/services/native-direct-input.ts';a=(r/rel).read_text();s=a
needle='''      const siblingProof = siblingProofKey ? siblingToolSourceProofs?.get(siblingProofKey) : undefined;''';assert needle in s
s=s.replace(needle,'''      let siblingProof = siblingProofKey ? siblingToolSourceProofs?.get(siblingProofKey) : undefined;''',1)
needle='''      const prefixCoversProof = siblingProof && (siblingProof.requiredSets ?? [siblingProof]).every(set =>
        set.inputs.every(required => cover.inputs.some(candidate => isDeepStrictEqual(candidate, required))) &&
        (Object.keys(cover.policy) as (keyof NativePayloadSourcePolicy)[]).every(key =>
          set.policy[key].every(id => cover.policy[key].includes(id))));''';assert needle in s
s=s.replace(needle,'''      const coversRequiredSets = (sets: NativePayloadSourceSet[]) => sets.every(set =>
        set.inputs.every(required => cover.inputs.some(candidate => isDeepStrictEqual(candidate, required))) &&
        (Object.keys(cover.policy) as (keyof NativePayloadSourcePolicy)[]).every(key =>
          set.policy[key].every(id => cover.policy[key].includes(id))));
      const toolLedger = !scope.context.ancestry.graphProofsDisabled && is(scope.context.db, PgTransaction)
        ? scope.context.ancestry.graphProofs : undefined;
      const toolLedgerKey = JSON.stringify([toolSourceVisitKey, historicalDocumentDepthHint]);
      const ownToolReaders = toolLedger ? (scope.context.readerObligations ??= {}) : undefined;
      if (!siblingProof && siblingProofKey) {
        const retained = toolLedger?.get(toolLedgerKey);
        const sameContext = retained?.readerObligations !== undefined && retained.readerObligations === ownToolReaders;
        const obligations = retained?.readerObligations?.completed;
        if (retained && coversRequiredSets(retained.requiredSets ?? [retained]) && (sameContext || obligations) &&
          !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, retained.descendants) &&
          await nativeFrozenMutableSourcesCurrent(db, input.companyId, retained.mutableSources, scope) &&
          (sameContext || obligations && await replayNativeSourceGraphObligations(scope, obligations, retained.readerSets)))
          siblingProof = retained;
      }
      const prefixCoversProof = siblingProof && coversRequiredSets(siblingProof.requiredSets ?? [siblingProof]);''',1)
needle='''      if (siblingProofKey) siblingProofStack.push(siblingFrame);
      let siblingCompleted = false;''';assert needle in s
s=s.replace(needle,'''      if (siblingProofKey) siblingProofStack.push(siblingFrame);
      let siblingCompleted = false;''',1)
needle='''        if (siblingCompleted && siblingProofKey && siblingToolSourceProofs && siblingToolSourceProofs.size < 512)
          siblingToolSourceProofs.set(siblingProofKey, { descendants: siblingFrame.descendants, mutableSources: siblingFrame.mutableSources,
            policy: producerEntry!.policy, inputs: producerEntry!.inputs, requiredSets: producerClosures,
            ...(siblingFrame.readerSelection?.complete ? { readerSets: new Map(siblingFrame.readerSelection.sets) } : {}) });''';assert needle in s
s=s.replace(needle,'''        if (siblingCompleted && siblingProofKey) {
          const completedProof = { descendants: siblingFrame.descendants, mutableSources: siblingFrame.mutableSources,
            policy: producerEntry!.policy, inputs: producerEntry!.inputs, requiredSets: producerClosures,
            ...(ownToolReaders ? { readerObligations: ownToolReaders } : {}),
            ...(siblingFrame.readerSelection?.complete ? { readerSets: new Map(siblingFrame.readerSelection.sets) } : {}) };
          if (siblingToolSourceProofs.size < 512) siblingToolSourceProofs.set(siblingProofKey, completedProof);
          if (toolLedger && !scope.context.ancestry.graphProofsDisabled && toolLedger.size < 512)
            toolLedger.set(toolLedgerKey, completedProof);
        }''',1)
s=s.replace('''      let siblingCompleted = false;
      try {
      const projectCreateCapture''','''      let siblingCompleted = false;
      try {
      // Producer receipt/capture selection precedes the frame; retain that
      // exact current row too so a later public invocation must reload it.
      recordNativeMutableSourceRow(scope, "run", input.companyId, producerRun);
      const projectCreateCapture''',1)
s=s.replace('''      // This ledger exists only across sibling components of this uncached
      // invocation. Keep each original full prefix for receipt/evidence checks;
      // never replace prefixes with a sliced union or share proofs with a new read.''','''      // Keep each original full prefix for receipt/evidence checks. Completed
      // descendant proofs may also live in this sealed invocation's ancestry;
      // never replace their saved prefixes with a sliced union.''',1)
needle='  let proof = eligible ? proofs.get(key) : undefined;'
assert needle in s
s=s.replace(needle,'  let proof = eligible && !scope.context.ancestry.graphProofsDisabled ? proofs.get(key) : undefined;\n  if (proof && !proof.mutableSources.compatible) proof = undefined;',1)
needle='      let siblingProof = siblingProofKey ? siblingToolSourceProofs?.get(siblingProofKey) : undefined;'
assert needle in s
s=s.replace(needle,'      let siblingProof = siblingProofKey && !scope.context.ancestry.graphProofsDisabled ? siblingToolSourceProofs.get(siblingProofKey) : undefined;\n      if (siblingProof && !siblingProof.mutableSources.compatible) siblingProof = undefined;',1)
needle='  let documentProof = documentProofEligible ? siblingToolSourceProofs.get(documentProofKey) : undefined;'
assert needle in s
s=s.replace(needle,'  let documentProof = documentProofEligible && !scope.context.ancestry.graphProofsDisabled ? siblingToolSourceProofs.get(documentProofKey) : undefined;\n  if (documentProof && !documentProof.mutableSources.compatible) documentProof = undefined;',1)
needle='        if (taskProof && !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, taskProof.descendants)) {'
assert needle in s
s=s.replace(needle,'        if (taskProof && taskProof.mutableSources.compatible && !scope.context.ancestry.graphProofsDisabled &&\n          !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, taskProof.descendants)) {',1)
needle='          const taskProofAlreadyCurrent = Boolean(taskProof && taskProof.key ==='
assert needle in s
s=s.replace(needle,'          const taskProofAlreadyCurrent = Boolean(taskProof && taskProof.mutableSources.compatible &&\n            !scope.context.ancestry.graphProofsDisabled && taskProof.key ===',1)
needle='function recordNativeProofReaderSet(scope: NativeSourceReadScope, key: string,\n  set: NativeSourceGraphObligations["readerSets"][number]): void {\n'
assert needle in s
s=s.replace(needle,'function excludeUnpinnedNativeSourceProofs(scope: NativeSourceReadScope,\n  policy: NativePayloadSourcePolicy, inputs: NativePayloadSourceInput[]): void {\n  if (nativeGraphProofInputsEligible(policy, inputs)) return;\n  // These owners are not all pinned or represented by dependency/reader\n  // replay. No enclosing local or shared proof may skip their current checks.\n  for (const stack of scope.context.ancestry.frozenTaskProofStacks.values())\n    for (const frame of stack) frame.mutableSources.compatible = false;\n}\nfunction recordNativeProofReaderSet(scope: NativeSourceReadScope, key: string,\n  set: NativeSourceGraphObligations["readerSets"][number]): void {\n  excludeUnpinnedNativeSourceProofs(scope, set.policy, set.inputs);\n',1)
needle='  return policy.projectIds.length === 0 && !inputs.some(source =>\n    source.kind === "project" || source.kind === "project_workspace" ||\n'
assert needle in s
s=s.replace(needle,'  return policy.projectIds.length === 0 && policy.foundationRevisionIds.length === 0 && !inputs.some(source =>\n    source.kind === "authored_definition" || source.kind === "skill_version" ||\n    source.kind === "playbook_revision" || source.kind === "role_pack_version" ||\n    source.kind === "foundation_revision" || source.kind === "attachment" ||\n    source.kind === "project" || source.kind === "project_workspace" ||\n',1)
needle='  const run = await nativeSourceReadRun(db, input.companyId, input.runId, scope);\n  if (run?.nativeIssueId !== input.issueId || run.runtimeMode !== "native")\n    throw forbidden("The Native source prefix owner is unavailable");'
assert needle in s
s=s.replace(needle,'  excludeUnpinnedNativeSourceProofs(scope, policy.data, inputs.data);\n  const run = await nativeSourceReadRun(db, input.companyId, input.runId, scope);\n  if (run?.nativeIssueId !== input.issueId || run.runtimeMode !== "native")\n    throw forbidden("The Native source prefix owner is unavailable");',1)
needle='  const snapshot = parsed.data;\n  const documentProofKey'
assert needle in s
s=s.replace(needle,'  const snapshot = parsed.data;\n  excludeUnpinnedNativeSourceProofs(scope, snapshot.policy, snapshot.inputs);\n  const documentProofKey',1)
p=o/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);(o/'candidate.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)));(o/'manifest.json').write_text(json.dumps({rel:{'priorSha256':hashlib.sha256(a.encode()).hexdigest(),'candidateSha256':hashlib.sha256(s.encode()).hexdigest()}},indent=2))
