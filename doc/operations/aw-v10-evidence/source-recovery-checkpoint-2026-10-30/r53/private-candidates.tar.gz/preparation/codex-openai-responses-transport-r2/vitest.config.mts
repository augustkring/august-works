import { fileURLToPath } from "node:url";
import { defineConfig } from "vitest/config";
const root = new URL("./files/", import.meta.url);
export default defineConfig({
  resolve: { alias: [
    { find: /^@paperclipai\/shared$/, replacement: fileURLToPath(new URL("packages/shared/src/index.ts", root)) },
  ] },
  test: { environment: "node", include: ["files/server/src/services/orchestration/openai-responses-model-transport.test.ts"],
    setupFiles: [], maxWorkers: 1, minWorkers: 1, pool: "forks" },
});
