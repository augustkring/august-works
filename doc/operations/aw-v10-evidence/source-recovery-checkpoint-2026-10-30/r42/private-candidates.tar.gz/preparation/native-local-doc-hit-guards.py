from pathlib import Path
p=Path('/workspace/blentera-v10/server/src/services/native-direct-input.ts');s=p.read_text()
a=s.index('  const documentProofCover = requireReceiptMembership ?');b=s.index('  const captures =',a);s=s[:a]+s[b:]
s=s.replace(', ...documentProofCover','')
s=s.replace('''            issueId: documentRevision.issueId, revisionId: documentRevision.revisionId, actor, requireLatest: false,
            proofCaptureHash: nativeSha256(capture), proofCaptureInputs: capture.sourceSet.inputs,
            proofCapturePolicy: capture.sourceSet.policy, proofCaptureDispatch: capture.dispatch''','''            issueId: documentRevision.issueId, revisionId: documentRevision.revisionId, actor, requireLatest: false''')
s=s.replace('''  proofCaptureHash?: string; proofCaptureInputs?: NativePayloadSourceInput[];
  proofCapturePolicy?: NativePayloadSourcePolicy;
  proofCaptureDispatch?: Extract<NativePayloadSourceInput, { kind: "worker_model_dispatch" | "conversation_model_dispatch" }>;
''','')
s=s.replace('''        issueId: source.issueId, revisionId: source.revisionId, actor: input.actor, requireLatest: false,
        ...(input.proofCaptureHash ? { proofCaptureHash: input.proofCaptureHash } : {}),
        ...(input.proofCaptureInputs ? { proofCaptureInputs: input.proofCaptureInputs } : {}),
        ...(input.proofCapturePolicy ? { proofCapturePolicy: input.proofCapturePolicy } : {}),
        ...(input.proofCaptureDispatch ? { proofCaptureDispatch: input.proofCaptureDispatch } : {})''','''        issueId: source.issueId, revisionId: source.revisionId, actor: input.actor, requireLatest: false''')
needle='''  if (documentProof && !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, documentProof.descendants)) {
    deferNativeSourceReaderCheck'''
replace='''  if (documentProof && !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, documentProof.descendants)) {
    const sourceDispatch = snapshot.inputs.find((source): source is Extract<NativePayloadSourceInput,
      { kind: "worker_model_dispatch" | "conversation_model_dispatch" }> =>
      source.kind === "worker_model_dispatch" || source.kind === "conversation_model_dispatch");
    for (const source of snapshot.inputs) {
      if (source.kind === "runtime_instructions") {
        if (!sourceDispatch) throw forbidden("A Native document runtime instruction owner is unavailable");
        await assertNativeRuntimeInstructionsCurrent(db, input.companyId, sourceDispatch.runId, source, scope);
      }
      if (source.kind === "runtime_skill") {
        if (!sourceDispatch) throw forbidden("A Native document runtime Skill owner is unavailable");
        await assertNativeDocumentRuntimeSkillCurrent(db, input.companyId, input.actor, source, sourceDispatch.runId);
      }
      if (source.kind === "native_task_wake") {
        if (!sourceDispatch || source.runId !== sourceDispatch.runId)
          throw forbidden("A Native document task wake source is unavailable");
        const wakeRun = await nativeSourceReadRun(db, input.companyId, source.runId, scope);
        const wakeReceipt = nativeRunInputSourceReceiptSchema.safeParse(nativeSourceRecord(wakeRun?.runnerProfileJson).nativeInputSourceReceipt);
        if (!wakeReceipt.success) throw forbidden("A Native document task wake source is unavailable");
        await assertNativeTaskWakeSourceCurrentInScope(db, scope, { companyId: input.companyId, issueId: input.issueId,
          runId: source.runId, source, inputs: snapshot.inputs, bootstrapInputs: wakeReceipt.data.bootstrap.inputs });
      }
    }
    deferNativeSourceReaderCheck'''
assert s.count(needle)==1;s=s.replace(needle,replace)
p.with_suffix('.localguards.tmp.ts').write_text(s)
