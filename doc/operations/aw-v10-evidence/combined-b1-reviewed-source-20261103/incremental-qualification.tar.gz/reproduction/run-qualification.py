import pathlib,subprocess
p=pathlib.Path('/workspace/v10-preparation/combined-b1-incremental-final-20261103')
with (p/'orchestration.log').open('wb') as f:r=subprocess.run(['python3',str(p/'qualify.py')],stdout=f,stderr=subprocess.STDOUT)
(p/'orchestration.exit').write_text(str(r.returncode)+'\n')
print('Actual orchestration exit',r.returncode)
raise SystemExit(r.returncode)
