#!/bin/bash
set -euo pipefail
source /workspace/v10-preparation/env.sh
OUT=/workspace/v10-preparation/committed-native-agent-strict38-pg-nov01
set +e
/workspace/v10-dep-qualification/node_modules/.bin/vitest run --config "$OUT/vitest.config.mjs" --reporter=verbose > "$OUT/component.log" 2>&1
status=$?
printf '%s\n' "$status" > "$OUT/component.exit"
tail -65 "$OUT/component.log"
exit "$status"
