import ast,copy,gzip,hashlib,json,os,pathlib,shutil,subprocess
P=pathlib.Path('/workspace/v10-preparation');O=P/'combined-b1-incremental-final-20261103';B=P/'combined-b1-final-metadata-20261103';OLD=pathlib.Path('/tmp/combined-b1-final-metadata-20261103/worktree');T=pathlib.Path('/tmp/combined-b1-incremental-final-20261103');W=T/'worktree';R=pathlib.Path('/workspace/blentera-v10');sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(p.read_bytes())
assert os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize//1024>=120000;assert os.statvfs('/tmp').f_bavail*os.statvfs('/tmp').f_frsize//1024>=1048576
base=load(B/'final-manifest.json');five=load(P/'serial-model-process-uid-20261103/final-five-source-manifest.json');human=load(P/'managed-comment-human-evidence-private-20261103/V3-HANDOFF.json')
assert not W.exists();shutil.copytree(OLD,W,symlinks=True)
patches=[P/'serial-model-process-uid-20261103/r2/source.patch',P/'managed-comment-human-evidence-private-20261103/human-api-fixture-v3.patch',P/'managed-comment-human-evidence-private-20261103/managed-comment-human-evidence-v3.patch',P/'readonly-serial-auth-diagnostics-20261103/r2/source.patch']
proof=[]
for p in patches:
 r=subprocess.run(['patch','-p1','--batch','--fuzz=0','-i',str(p)],cwd=W,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);assert r.returncode==0,r.stdout.decode();proof.append({'path':str(p),'sha256':sha(p.read_bytes()),'actualExit':r.returncode,'output':r.stdout.decode()})
paths=sorted({r['path'] for r in five['paths']}|set(human['finalComposedSources']));assert len(paths)==6
for row in five['paths']:
 if row['path'].endswith('managed-native-heartbeat-fixture.ts'):continue
 assert sha((W/row['path']).read_bytes())==row['candidateSha256'],row['path']
comment='server/src/__tests__/heartbeat-comment-wake-batching-managed-positive.integration.test.ts';assert sha((W/comment).read_bytes())==human['finalComposedSources'][comment]
# Exact independent proof that diagnostics and Human deltas commute on the frozen source28 helper.
C=T/'commute';C.mkdir(parents=True);diag=patches[-1]
for rel in paths:
 p=C/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((OLD/rel).read_bytes())
for p in [patches[0],diag,patches[1],patches[2]]:subprocess.run(['patch','-p1','--batch','--fuzz=0','-i',str(p)],cwd=C,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
assert all((C/p).read_bytes()==(W/p).read_bytes() for p in paths)
# Exact inverse to final49 incoming bytes (before metadata generation).
I=T/'inverse';I.mkdir()
for rel in paths:
 p=I/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((W/rel).read_bytes())
for p in reversed(patches):subprocess.run(['patch','-R','-p1','--batch','--fuzz=0','-i',str(p)],cwd=I,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
assert all((I/p).read_bytes()==(OLD/p).read_bytes() for p in paths)
rows=[{'path':p,'final49DonorSha256':sha((OLD/p).read_bytes()),'candidateSha256':sha((W/p).read_bytes())} for p in paths];sm={'baseHead':base['baseHead'],'frozen49ManifestSha256':sha((B/'final-manifest.json').read_bytes()),'incomingPaths':rows,'patches':proof,'strictInverseExact':True,'humanDiagnosticsCommutativityExact':True,'runtimeBoundary':'UID actualunit6PASS; Human/diagnostic pure checks only. No SDK/HTTP/PG acceptance inferred.'};(O/'increment-source-manifest.json').write_text(json.dumps(sm,indent=2)+'\n');digest=sha((O/'increment-source-manifest.json').read_bytes())
phase='doc/operations/aw-v10-evidence/v10-169-migration-phases-current-2026-10-30';gp=W/'doc/operations/v10-safe-change-graph.source.json';g=load(gp);oldg=copy.deepcopy(g);groups=[]
for p in paths:
 matches=[x['changeId'] for x in g['changes'] if p in x['changedSourcePaths']];assert len(matches)==1,(p,matches);groups.append({'path':p,'existingOwnerGroup':matches[0]})
g['currentSourceRecovery']['approvedIncrementalSourceManifestSha256']=digest
batch='doc/operations/aw-v10-evidence/combined-b1-reviewed-source-20261103';newEvidence=batch+'/incremental-qualification.tar.gz';allpaths=sorted({x['path'] for x in base['files']}|set(paths)|{newEvidence});assert len(allpaths)==54
(W/newEvidence).write_bytes(gzip.compress(b'',mtime=0));(W/batch/'stage-list.txt').write_text('\n'.join(allpaths)+'\n')
(W/batch/'README.md').write_text((W/batch/'README.md').read_text()+'\n## Approved incremental source layer\n\nThe separate `incremental-qualification.tar.gz` records the exact UID R2, Human comment V3 and diagnostic R2 additions to the frozen 49-file candidate. Existing phase, Help and alias pinned paths do not intersect these six source files; their semantic pins are unchanged. Existing Safe Change owner links are retained and only current-source hashes are regenerated. The UID unit receipt proves six native primitive cases; Human and diagnostic checks retain their pure-only limits and do not establish SDK/HTTP acceptance.\n')
for file in ['phase-matrix.json','source-revision-ledger.json']:
 p=W/phase/file;d=load(p);d['approvedIncrementalSource']={'sourceManifestSha256':digest,'sourceFiles':6,'scope':'Individually reviewed UID R2, Human comment V3 and diagnostic R2 layer; no existing semantic phase source pins affected and no historical result promotion.'};p.write_text(json.dumps(d,indent=2)+'\n')
for file,field in [(W/phase/'phase-matrix.json','sourcePins'),(W/'doc/operations/agent-native-tool-alias-compatibility.json','sourcePins'),(W/'docs/help/change-review.json','reviews')]:
 records=load(file)[field];hits=[x for x in records if x.get('path',x.get('source')) in paths];assert not hits
# Genuine isolated alternate index; no Main objects/index/ref writes.
oldenv=load(B/'preparation-proof.json')['alternateGitEnvironment'];env={**os.environ,**oldenv,'GIT_WORK_TREE':str(W),'GIT_INDEX_FILE':str(T/'candidate.index'),'GIT_OBJECT_DIRECTORY':str(T/'objects')};(T/'objects').mkdir();subprocess.run(['git','read-tree',base['baseHead']],cwd=W,env=env,check=True)
def stage():
 for p in allpaths:
  blob=subprocess.check_output(['git','hash-object','-w','--stdin'],cwd=W,env=env,input=(W/p).read_bytes()).decode().strip();subprocess.run(['git','update-index','--add','--cacheinfo','100644',blob,p],cwd=W,env=env,check=True)
stage();full=subprocess.check_output(['git','diff','--cached','--name-only','81d3445b98b1cd80ff400ede6bd44ea71d88d735'],cwd=W,env=env,text=True).splitlines();g['sourceInventoryBoundary']['fullDiffPathCount']=len(full);assert len(full)==13843;gp.write_text(json.dumps(g,indent=2)+'\n');stage()
for file in ['phase-matrix.json']:
 a=load(OLD/phase/file);b=load(W/phase/file);b.pop('approvedIncrementalSource');assert a==b
assert g['changes']==oldg['changes'] and g['requirementsCrosswalk']==oldg['requirementsCrosswalk']
proof={'baseHead':base['baseHead'],'finalPaths':allpaths,'uniqueFiles':54,'affectedSourceFiles':6,'newUniqueSourcePaths':sorted(set(paths)-{r['path'] for r in base['files']}),'unchangedPhaseHelpAliasPins':True,'existingSafeGraphGroups':groups,'materialSourceCount':1939,'fullDiffPathCount':13843,'alternateGitEnvironment':{k:v for k,v in env.items() if k.startswith('GIT_')},'incrementSourceManifestSha256':digest,'all169HistoryAnd50AssessmentsUnchanged':True};(O/'composition-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:v for k,v in proof.items() if k not in ['finalPaths','alternateGitEnvironment']},indent=2))
