from pathlib import Path
p=Path('/workspace/blentera-v10/server/src/services/authorization.ts');s=p.read_text();needle='export interface MemoryPageStructuralProofMemoStore {';assert s.count(needle)==1
s=s.replace(needle,'''export type NativeMutableSourceRowFamily = "run" | "reservation" | "invocation" | "contract";
export interface NativeMutableSourceRowDependency { family: NativeMutableSourceRowFamily; companyId: string; id: string; digest: string }
export interface NativeMutableSourceDependencies { rows: Map<string, NativeMutableSourceRowDependency>; compatible: boolean }
export interface MemoryPageStructuralProofMemoStore {''',1)
s=s.replace('''  readonly proofsByOwnerPrefix: Map<string, Map<string, Set<string>>>;
}''','''  readonly proofsByOwnerPrefix: Map<string, Map<string, Set<string>>>;
  mutableSourceProofsByOwnerPrefix?: Map<string, Map<string, NativeMutableSourceDependencies>>;
}''',1);p.with_suffix('.mutableproofs.tmp.ts').write_text(s)
p=Path('/workspace/blentera-v10/server/src/services/native-direct-input.ts');s=p.read_text()
s=s.replace('type AuthorizationActor, type MemoryNativeSourceRowsScope, type MemoryPageStructuralProofMemoStore','type AuthorizationActor, type MemoryNativeSourceRowsScope, type MemoryPageStructuralProofMemoStore,\n  type NativeMutableSourceDependencies, type NativeMutableSourceRowDependency, type NativeMutableSourceRowFamily',1)
s=s.replace('Array<{ visitKey: string; descendants: Set<string> }>', 'Array<{ visitKey: string; descendants: Set<string>; mutableSources: NativeMutableSourceDependencies }>')
s=s.replace('type NativeCompletedTaskSourceProofs = Map<string, { key: string; descendants: Set<string> }>;','type NativeCompletedTaskSourceProofs = Map<string, { key: string; descendants: Set<string>; mutableSources: NativeMutableSourceDependencies }>;')
s=s.replace('type NativeSiblingToolSourceProofs = Map<string, { descendants: Set<string>;','type NativeSiblingToolSourceProofs = Map<string, { descendants: Set<string>; mutableSources: NativeMutableSourceDependencies;')
s=s.replace('  frozenTaskSnapshots: Map<string, Set<string>>;\n','  frozenTaskSnapshots: Map<string, Set<string>>;\n  frozenTaskMutableSources: Map<string, NativeMutableSourceDependencies>;\n  currentMutableSourceRows: Map<string, string>;\n',1)
# Typed obligations are separate from ancestry/cycle keys.
a=s.index('async function withNativeSourceGraphProof(')
s=s[:a]+'''function newNativeMutableSources(): NativeMutableSourceDependencies { return { rows: new Map(), compatible: true }; }
function mergeNativeMutableSources(target: NativeMutableSourceDependencies, source: NativeMutableSourceDependencies) {
  if (!source.compatible) target.compatible = false;
  for (const [key, row] of source.rows) {
    const old = target.rows.get(key);
    if (old && old.digest !== row.digest) target.compatible = false;
    if (target.rows.size >= 512 && !target.rows.has(key)) { target.compatible = false; continue; }
    target.rows.set(key, row);
  }
}
function propagateNativeMutableSources(scope: NativeSourceReadScope, source: NativeMutableSourceDependencies) {
  for (const frame of scope.context.ancestry.frozenTaskProofStacks.get(scope.actorKey) ?? [])
    mergeNativeMutableSources(frame.mutableSources, source);
}
function nativeMutableSourceRowDigest(family: NativeMutableSourceRowFamily, row: object): string {
  if (family !== "invocation") return nativeSha256(row);
  const value = row as typeof toolInvocations.$inferSelect;
  return nativeSha256({ id: value.id, companyId: value.companyId, agentId: value.agentId,
    runId: value.runId, issueId: value.issueId, toolName: value.toolName,
    idempotencyKey: value.idempotencyKey, status: value.status, resultHash: value.resultHash,
    argumentsHash: value.argumentsHash, workflowResultJson: value.workflowResultJson });
}
function recordNativeMutableSourceRow(scope: NativeSourceReadScope, family: NativeMutableSourceRowFamily,
  companyId: string, row: object & { id: string }) {
  const key = `${family}:${companyId}:${row.id}`;
  const dependency: NativeMutableSourceRowDependency = { family, companyId, id: row.id,
    digest: nativeMutableSourceRowDigest(family, row) };
  scope.currentMutableSourceRows.set(key, dependency.digest);
  propagateNativeMutableSources(scope, { rows: new Map([[key, dependency]]), compatible: true });
}
function nativeFrozenMutableProofMap(store: MemoryPageStructuralProofMemoStore, actorKey: string,
  memoryIdentity: string | null): Map<string, NativeMutableSourceDependencies> {
  if (!memoryIdentity) return new Map();
  const owners = store.mutableSourceProofsByOwnerPrefix ??= new Map();
  const key = nativeMemoryStructuralOwnerPrefixKey(actorKey, memoryIdentity);
  const existing = owners.get(key);
  if (existing) return existing;
  const created = new Map<string, NativeMutableSourceDependencies>();
  if (owners.size < 128) owners.set(key, created);
  return created;
}
async function nativeFrozenMutableSourcesCurrent(db: Db | Transaction, companyId: string,
  dependencies: NativeMutableSourceDependencies | undefined, scope: NativeSourceReadScope): Promise<boolean> {
  if (!dependencies?.compatible || !dependencies.rows.size || dependencies.rows.size > 512) return false;
  const pending: Record<NativeMutableSourceRowFamily, string[]> = { run: [], reservation: [], invocation: [], contract: [] };
  for (const [key, row] of dependencies.rows) {
    if (row.companyId !== companyId) return false;
    if (!scope.currentMutableSourceRows.has(key)) pending[row.family].push(row.id);
  }
  for (const family of ["run", "reservation", "invocation", "contract"] as const) {
    const ids = [...new Set(pending[family])];
    if (!ids.length) continue;
    const rows = family === "run" ? await db.select().from(heartbeatRuns).where(and(
      eq(heartbeatRuns.companyId, companyId), inArray(heartbeatRuns.id, ids))).for("share") :
      family === "reservation" ? await db.select().from(orchestrationModelReservations).where(and(
        eq(orchestrationModelReservations.companyId, companyId), inArray(orchestrationModelReservations.id, ids))).for("share") :
      family === "invocation" ? await db.select().from(toolInvocations).where(and(
        eq(toolInvocations.companyId, companyId), inArray(toolInvocations.id, ids))).for("share") :
      await db.select().from(completionContracts).where(and(eq(completionContracts.companyId, companyId),
        inArray(completionContracts.id, ids))).for("share");
    for (const row of rows) recordNativeMutableSourceRow(scope, family, companyId, row);
    if (rows.length !== ids.length) return false;
  }
  for (const [key, row] of dependencies.rows)
    if (scope.currentMutableSourceRows.get(key) !== row.digest) return false;
  return true;
}
'''+s[a:]
# Every frame and completed node retains the same typed dependency closure.
s=s.replace('descendants: new Set<string>() };','descendants: new Set<string>(), mutableSources: newNativeMutableSources() };')
s=s.replace('descendants: new Set([toolSourceVisitKey]) };','descendants: new Set([toolSourceVisitKey]), mutableSources: newNativeMutableSources() };')
s=s.replace('descendants: frame.descendants, policy:', 'descendants: frame.descendants, mutableSources: frame.mutableSources, policy:')
s=s.replace('scope.context.memoryTemporalIdentity), descendants: taskFrame.descendants });','scope.context.memoryTemporalIdentity), descendants: taskFrame.descendants, mutableSources: taskFrame.mutableSources });')
s=s.replace('descendants: siblingFrame.descendants,\n','descendants: siblingFrame.descendants, mutableSources: siblingFrame.mutableSources,\n')
s=s.replace('descendants: documentFrame.descendants,\n','descendants: documentFrame.descendants, mutableSources: documentFrame.mutableSources,\n')
# Propagate mutable obligations whenever a private structural hit skips its walk.
s=s.replace('''    deferNativeSourceReaderCheck(scope, input);
    for (const parent''','''    deferNativeSourceReaderCheck(scope, input);
    propagateNativeMutableSources(scope, proof.mutableSources);
    for (const parent''',1)
s=s.replace('''        if (taskProof && !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, taskProof.descendants)) {
          nativeSourceReadWork(scope);''','''        if (taskProof && !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, taskProof.descendants)) {
          nativeSourceReadWork(scope);
          propagateNativeMutableSources(scope, taskProof.mutableSources);''',1)
s=s.replace('''          if (taskProofAlreadyCurrent && taskProof) {
            for (const parent''','''          if (taskProofAlreadyCurrent && taskProof) {
            propagateNativeMutableSources(scope, taskProof.mutableSources);
            for (const parent''',1)
s=s.replace('''      if (siblingProof && prefixCoversProof &&
        !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, siblingProof.descendants)) {''','''      if (siblingProof && prefixCoversProof &&
        !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, siblingProof.descendants)) {
        propagateNativeMutableSources(scope, siblingProof.mutableSources);''',1)
s=s.replace('''  if (documentProof && depth <= (documentProof.validatedDepth ?? -1) &&
    !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, documentProof.descendants)) {''','''  if (documentProof && depth <= (documentProof.validatedDepth ?? -1) &&
    !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, documentProof.descendants)) {
    propagateNativeMutableSources(scope, documentProof.mutableSources);''',1)
# Paired metadata uses the same exact Memory owner-prefix store as existing frozen Task proofs.
s=s.replace('  const structuralStore = memoryStructuralProofMemoStore?.transaction', '  const structuralStore: MemoryPageStructuralProofMemoStore = memoryStructuralProofMemoStore?.transaction',1)
s=s.replace('''const scope: NativeSourceReadScope = { context, actorKey, pinnedRows, active, completedImmutableSourceLeafProofs: new Set(),''','''const scope: NativeSourceReadScope = { context, actorKey, pinnedRows, active, completedImmutableSourceLeafProofs: new Set(),
    frozenTaskMutableSources: nativeFrozenMutableProofMap(structuralStore, actorKey, memoryTemporalIdentity), currentMutableSourceRows: new Map(),''',1)
s=s.replace('''      frozenTaskSnapshots: memoMatches && proofMemo ? proofMemo.frozenTaskSnapshots : new Map(),
      completedImmutableSourceLeafProofs: new Set(),''','''      frozenTaskSnapshots: scope.frozenTaskSnapshots,
      completedImmutableSourceLeafProofs: new Set(), currentMutableSourceRows: new Map(),''',1)
s=s.replace('''        active, completedImmutableSourceLeafProofs: new Set(), frozenTaskSnapshots:''','''        active, completedImmutableSourceLeafProofs: new Set(), currentMutableSourceRows: new Map(),
        frozenTaskMutableSources: nativeFrozenMutableProofMap(current.memoryStructuralProofMemoStore, actorKey, memoryTemporalIdentity),
        frozenTaskSnapshots:''',1)
# Mutable producer rows reached by any cold proof are recorded even on row-cache hits.
s=s.replace('''    return scope.pinnedRows.runs.get(key) ?? null;''','''    const cached = scope.pinnedRows.runs.get(key) ?? null;
    if (cached) recordNativeMutableSourceRow(scope, "run", companyId, cached);
    return cached;''',1)
s=s.replace('''  if (run) scope.pinnedRows.runs.set(key, run);''','''  if (run) { scope.pinnedRows.runs.set(key, run); recordNativeMutableSourceRow(scope, "run", companyId, run); }''',1)
s=s.replace('''    return scope.pinnedRows.reservations.get(key) ?? null;''','''    const cached = scope.pinnedRows.reservations.get(key) ?? null;
    if (cached) recordNativeMutableSourceRow(scope, "reservation", companyId, cached);
    return cached;''',1)
s=s.replace('''  if (reservation) scope.pinnedRows.reservations.set(key, reservation);''','''  if (reservation) { scope.pinnedRows.reservations.set(key, reservation); recordNativeMutableSourceRow(scope, "reservation", companyId, reservation); }''',1)
# Completion contracts must also refresh current mutable owner state on a local leaf hit.
s=s.replace('''  if (scope.completedImmutableSourceLeafProofs.has(proofKey)) { nativeSourceReadWork(scope); return; }
''','',1)
needle='''  // This is structural row currentness only. The owning source set'''
s=s.replace(needle,'''  recordNativeMutableSourceRow(scope, "contract", companyId, contract);
  if (scope.completedImmutableSourceLeafProofs.has(proofKey)) { nativeSourceReadWork(scope); return; }
  // This is structural row currentness only. The owning source set''',1)
# Source output loop uses one stable invocation projection across all producer readers.
s=s.replace('''          const [invocation] = await db.select({ id: toolInvocations.id, status: toolInvocations.status,''','''          const [invocation] = await db.select({ id: toolInvocations.id, companyId: toolInvocations.companyId,
            agentId: toolInvocations.agentId, idempotencyKey: toolInvocations.idempotencyKey,
            argumentsHash: toolInvocations.argumentsHash, workflowResultJson: toolInvocations.workflowResultJson,
            status: toolInvocations.status,''',1)
needle='''        } else if (source.toolName === "create_task"'''
s=s.replace(needle,'''          recordNativeMutableSourceRow(scope, "invocation", companyId, invocation);
        } else if (source.toolName === "create_task"''',1)
needle='''      const matchingReceiptInputs = receipt?.success ? nativeToolResultReceiptCopies(receipt.data, source) : null;'''
s=s.replace(needle,'''      if (invocation) recordNativeMutableSourceRow(scope, "invocation", input.companyId, invocation);
      const matchingReceiptInputs = receipt?.success ? nativeToolResultReceiptCopies(receipt.data, source) : null;''',1)
needle='''  const callId = invocation.idempotencyKey.slice(`aw-native-tool:${dispatch.runId}:`.length);'''
s=s.replace(needle,'''  recordNativeMutableSourceRow(scope, "invocation", input.companyId, invocation);
  const callId = invocation.idempotencyKey.slice(`aw-native-tool:${dispatch.runId}:`.length);''',1)
# Record direct model producer queries too.
a=s.index('async function assertNativeModelOutputCaptureCurrentInScope(');b=s.index('\n/** Revalidate a driver',a);chunk=s[a:b]
needle='''  const bootstrap = receipt?.success ? receipt.data.bootstrap : null;''';assert chunk.count(needle)==1;chunk=chunk.replace(needle,'''  if (run) recordNativeMutableSourceRow(scope, "run", companyId, run);
  if (reservation) recordNativeMutableSourceRow(scope, "reservation", companyId, reservation);
  const bootstrap = receipt?.success ? receipt.data.bootstrap : null;''',1);s=s[:a]+chunk+s[b:]
# Document contract readers are also dependencies of enclosing frozen Task proofs.
needle='''        throw forbidden("The Native document completion contract changed");
      continue;'''
s=s.replace(needle,'''        throw forbidden("The Native document completion contract changed");
      recordNativeMutableSourceRow(scope, "contract", input.companyId, contract);
      continue;''',1)
# Frozen reuse now checks dependency rows before skipping the structural closure.
needle='''    if (reusable && cachedDescendants && !cachedCycle) {'''
replacement='''    const cachedMutableSources = scope.frozenTaskMutableSources.get(completeKey);
    const mutableSourcesCurrent = reusable && cachedDescendants && !cachedCycle &&
      await nativeFrozenMutableSourcesCurrent(db, companyId, cachedMutableSources, scope);
    if (reusable && cachedDescendants && !cachedCycle && mutableSourcesCurrent) {
      propagateNativeMutableSources(scope, cachedMutableSources!);''';assert s.count(needle)==1;s=s.replace(needle,replacement)
needle='''        if (reusable && scope.frozenTaskSnapshots.size < 512)
          scope.frozenTaskSnapshots.set(completeKey, new Set(proofFrame.descendants));'''
replacement='''        if (reusable && scope.frozenTaskSnapshots.size < 512) {
          scope.frozenTaskSnapshots.set(completeKey, new Set(proofFrame.descendants));
          scope.frozenTaskMutableSources.set(completeKey, proofFrame.mutableSources);
        }''';assert s.count(needle)==1;s=s.replace(needle,replacement)
p.with_suffix('.mutableproofs.tmp.ts').write_text(s)
