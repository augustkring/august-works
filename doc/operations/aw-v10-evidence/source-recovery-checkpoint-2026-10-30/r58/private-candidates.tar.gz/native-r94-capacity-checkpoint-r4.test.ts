import { randomUUID } from "node:crypto";
import { readFile } from "node:fs/promises";
import { afterAll, expect, it, vi } from "vitest";
import { and, eq, sql } from "drizzle-orm";
import { createDb, closeRegisteredClients, authUsers, authPasskeys, authSessions, issues, heartbeatRuns, issuePrivacySources } from "@paperclipai/db";
import { nativePayloadSourceSnapshotSchema, nativeRunInputSourceReceiptSchema, type NativePayloadSourceInput } from "@paperclipai/shared";
import { assertNativeManagedConsumedSourceSetCurrent } from "../services/native-direct-input.js";
import { nativeSha256 } from "../services/native-runtime/canonical.js";
const connection = process.env.NATIVE_CONTEXT_REPLAY_DATABASE_URL!;
const root = "/tmp/native-payload-temporal-X0vcAM";
const checkpoint = JSON.parse(await readFile(`${root}/native-source-failure-checkpoint.json`, "utf8"));
vi.stubEnv("PAPERCLIP_HOME", root); vi.stubEnv("PAPERCLIP_INSTANCE_ID", checkpoint.instanceId);
const db = createDb(connection);
afterAll(async () => { await closeRegisteredClients(connection); vi.unstubAllEnvs(); });
it("accepts a real retained Task copy then denies only the otherwise-valid total work overflow", async () => {
  const identity = checkpoint.aliceActor;
  const [user] = await db.select().from(authUsers).where(eq(authUsers.id, checkpoint.aliceUserId));
  expect((await db.select().from(authPasskeys).where(eq(authPasskeys.userId, checkpoint.aliceUserId))).length).toBeGreaterThan(0);
  const now = new Date(), sessionId = randomUUID();
  await db.insert(authSessions).values({ id: sessionId, userId: checkpoint.aliceUserId, token: randomUUID(), createdAt: now, updatedAt: now,
    expiresAt: new Date(now.getTime()+3_600_000), authenticationMethod: "passkey", authenticatedAt: now, authenticatorVersion: user!.authenticatorVersion });
  const [run] = await db.select().from(heartbeatRuns).where(eq(heartbeatRuns.id, checkpoint.runs.find((r: any) => r.status === "succeeded").id));
  const first = { companyId: checkpoint.companyId, aliceUserId: checkpoint.aliceUserId, issueId: run!.nativeIssueId!, runId: run!.id };
  const second = { aliceActor: { ...identity, sessionId } };
  const profile = run!.runnerProfileJson as Record<string, unknown>;
  const [taskB] = await db.select().from(issues).where(eq(issues.id, checkpoint.taskBId));
    const rollback = new Error("rollback Native capacity fixture");
    await expect(db.transaction(async rawTx => {
      const tx = rawTx as unknown as typeof db;
      const sourceSnapshot = nativePayloadSourceSnapshotSchema.parse(taskB!.payloadSourceSnapshot);
      const copies = await tx.insert(issues).values(Array.from({ length: 64 }, () => ({
        ...taskB!, id: randomUUID(), identifier: null, issueNumber: null,
        checkoutRunId: null, executionRunId: null,
        payloadSourceSnapshot: null,
      }))).returning({ id: issues.id });
      const originalEdges = await tx.select().from(issuePrivacySources).where(and(
        eq(issuePrivacySources.companyId, first.companyId), eq(issuePrivacySources.issueId, taskB!.id)));
      expect(originalEdges.length).toBeGreaterThan(0);
      for (const copy of copies) await tx.insert(issuePrivacySources).values(originalEdges.map(edge => ({
        ...edge, id: randomUUID(), issueId: copy.id,
      }))).onConflictDoNothing();
      const sources: Extract<NativePayloadSourceInput, { kind: "task" }>[] = [];
      for (const copy of copies) {
        const { digest: _digest, ...body } = sourceSnapshot;
        const snapshot = { ...body, owner: { ...body.owner, id: copy.id } };
        const [sealed] = await tx.update(issues).set({ payloadSourceSnapshot: sql`(select value || jsonb_build_object(
          'digest',encode(sha256(convert_to(value::text,'UTF8')),'hex'))
          from (select ${JSON.stringify(snapshot)}::jsonb as value) supplied)` }).where(eq(issues.id, copy.id))
          .returning({ sourceVersion: issues.updatedAt });
        expect(sealed).toBeDefined();
        sources.push({ kind: "task", issueId: copy.id, sourceVersion: sealed!.sourceVersion.toISOString(),
          contentHash: sourceSnapshot.owner.contentHash });
      }
      const components = sources.map(source => ({ kind: "additional_input" as const,
        responsibleUserId: first.aliceUserId,
        policy: { issueIds: [source.issueId], projectIds: [], runIds: [], memoryIds: [], foundationRevisionIds: [] },
        inputs: [source],
      }));
      const receipt = nativeRunInputSourceReceiptSchema.parse(profile.nativeInputSourceReceipt);
      const { digest: _digest, ...receiptBody } = { ...receipt,
        additionalInputs: [...receipt.additionalInputs, ...components.map(({ kind: _kind, ...set }) => set)] };
      expect(receiptBody.additionalInputs.length).toBeLessThanOrEqual(256);
      const [sealedReceipt] = await tx.execute<{ receipt: unknown }>(sql`select value || jsonb_build_object(
        'digest',encode(sha256(convert_to(value::text,'UTF8')),'hex')) as receipt
        from (select ${JSON.stringify(receiptBody)}::jsonb as value) supplied`);
      const augmentedReceipt = nativeRunInputSourceReceiptSchema.parse(sealedReceipt!.receipt);
      await tx.update(heartbeatRuns).set({ runnerProfileJson: { ...profile,
        nativeInputSourceReceipt: augmentedReceipt } })
        .where(and(eq(heartbeatRuns.companyId, first.companyId), eq(heartbeatRuns.id, first.runId))).catch(error => {
          const cause = (error as { cause?: { code?: string; message?: string } }).cause;
          console.error("native_capacity_fixture_pg_failure", JSON.stringify({ code: cause?.code,
            staticReason: typeof cause?.message === "string" && /^Native [A-Za-z ]+$/.test(cause.message) ? cause.message : null }));
          throw error;
        });
      const validate = (selected: typeof components) => assertNativeManagedConsumedSourceSetCurrent(tx, {
        companyId: first.companyId, issueId: first.issueId, runId: first.runId, actor: second.aliceActor,
        components: selected,
        sourceSet: { policy: { issueIds: selected.map(value => value.inputs[0]!.issueId).sort(),
          projectIds: [], runIds: [], memoryIds: [], foundationRevisionIds: [] },
          inputs: selected.flatMap(value => value.inputs) },
      });
      await expect(validate(components.slice(0, 1))).resolves.toBeUndefined();
      expect(components).toHaveLength(64);
      expect(components.flatMap(value => value.inputs)).toHaveLength(64);
      await expect(validate(components)).rejects.toMatchObject({ status: 403,
        message: "The Native source graph exceeds its total-work bound" });
      throw rollback;
    })).rejects.toBe(rollback);

  console.info("native_capacity_envelope_checkpoint", JSON.stringify({ oneCopyAccepted: true, inputCount: 64, exactTotalWork403: true, limit: 2048 }));
}, 120_000);
