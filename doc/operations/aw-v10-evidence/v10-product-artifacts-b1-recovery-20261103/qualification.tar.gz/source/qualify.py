import fcntl,gzip,hashlib,json,os,pathlib,signal,subprocess,time
root=pathlib.Path('/workspace/blentera-v10');out=pathlib.Path('/workspace/v10-preparation/v10-product-artifacts-b1-recovery-20261103');tmp=pathlib.Path('/tmp/v10-product-artifacts-b1-recovery-20261103');q=out/'qualification';sha=lambda b:hashlib.sha256(b).hexdigest();node='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
manifest=json.loads((tmp/'v10-safe-change-graph.source.json').read_bytes());paths={p for g in manifest['changes'] for p in g['sourcePaths']}|{p['path'] for p in manifest['sourceInputs']}
paths.update(['scripts/generate-v10-safe-change-graph.mjs','scripts/generate-v10-capability-projection.ts','scripts/check-v10-safe-change-graph.mjs','scripts/check-v10-capability-projection.mjs','scripts/v10-product-artifacts.test.mjs','scripts/check-v10-security-fast-path.test.mjs','scripts/check-v10-security-regression-execution.test.mjs','scripts/check-v10-security-fast-path.mjs','scripts/check-v10-security-regression-execution.mjs','packages/shared/src/feature-catalog.ts','packages/teams-catalog/generated/catalog.json','packages/skills-catalog/generated/catalog.json','doc/experience/v9/coverage.json','doc/operations/agent-native-ui-operation-coverage.json','doc/operations/v10-capability-projection.json','doc/operations/v10-safe-change-graph.json','doc/operations/v10-safe-change-graph.source.json','packages/db/src/migrations/meta/_journal.json'])
paths.update('packages/db/src/migrations/'+e['tag']+'.sql' for e in json.loads((root/'packages/db/src/migrations/meta/_journal.json').read_bytes())['entries'])
before={p:sha((root/p).read_bytes()) for p in sorted(paths)};before[str(tmp/'v10-safe-change-graph.source.json')]=sha((tmp/'v10-safe-change-graph.source.json').read_bytes());before[str(tmp/'v10-capability-projection.json')]=sha((tmp/'v10-capability-projection.json').read_bytes());(q/'input-source-pins.json.gz').write_bytes(gzip.compress((json.dumps(before,indent=2)+'\n').encode(),mtime=0))
def events():return dict(x.split() for x in pathlib.Path('/sys/fs/cgroup/memory.events').read_text().splitlines())
def free(p):s=os.statvfs(p);return s.f_bavail*s.f_frsize//1024
def headroom():return int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text())-int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text())
lock=open('/workspace/v10-preparation/v10-pg-tests.lock','a');wait=time.monotonic()
while True:
 try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);break
 except BlockingIOError:
  if time.monotonic()-wait>60:raise RuntimeError('canonical flock wait exceeded60s')
  time.sleep(.1)
assert free('/workspace')>=120000 and free('/tmp')>=1048576 and headroom()>=512*1024*1024
initial=events();results=[];env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=128'}
commands=[('baseline-capability-check',['scripts/check-v10-capability-projection.mjs'],1),('baseline-safe-change-check',['scripts/check-v10-safe-change-graph.mjs'],1),('generate-capability',['cli/node_modules/tsx/dist/cli.mjs','scripts/generate-v10-capability-projection.ts','--out',str(tmp/'v10-capability-projection.json')],0),('generate-safe-change',[str(out/'private-safe-change-generator.mjs')],0),('candidate-capability-check',[str(out/'private-capability-check.mjs')],0),('candidate-safe-change-check',[str(out/'private-safe-change-check.mjs')],0),('existing-negative-controls',['--test','--test-concurrency=1',str(root/'scripts/check-v10-security-fast-path.test.mjs'),str(root/'scripts/check-v10-security-regression-execution.test.mjs'),str(out/'private-product-artifacts.test.mjs')],0)]
commands=[item for item in commands if item[0] not in {'baseline-capability-check','baseline-safe-change-check','generate-capability'}]
for label,args,expected in commands:
 assert free('/workspace')>=120000 and free('/tmp')>=1048576 and headroom()>=512*1024*1024
 start=time.monotonic();peak=0;reason=None;command=[node,'--max-old-space-size=128',*args]
 with (q/(label+'.log')).open('wb') as log:
  p=subprocess.Popen(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=env)
  while p.poll() is None:
   rss=0
   for entry in pathlib.Path('/proc').iterdir():
    if not entry.name.isdigit():continue
    try:
     fields=(entry/'stat').read_text().rsplit(')',1)[1].split()
     if int(fields[2])==p.pid:rss+=int(fields[21])*os.sysconf('SC_PAGE_SIZE')//1024
    except (OSError,ValueError,IndexError):pass
   peak=max(peak,rss)
   if rss>256*1024:reason='process-group RSS cap'
   elif time.monotonic()-start>60:reason='deadline'
   elif events()!=initial:reason='memory event changed'
   if reason:os.killpg(p.pid,signal.SIGKILL);break
   time.sleep(.025)
  code=p.wait()
 (q/(label+'.exit')).write_text(str(code)+'\n');item={'label':label,'command':command,'actualExitCode':code,'expectedExit':expected,'seconds':time.monotonic()-start,'peakProcessGroupRssKiB':peak,'stopped':reason};results.append(item)
 (q/'progress-receipt.json').write_text(json.dumps({'results':results,'memoryBefore':initial,'memoryCurrent':events()},indent=2)+'\n')
 # Persist each uniquely generated result immediately; uncompressed output is reproducible /tmp.
 if label.startswith('generate-') and code==0:
  filename='v10-capability-projection.json' if label=='generate-capability' else 'v10-safe-change-graph.json';(out/(filename+'.gz')).write_bytes(gzip.compress((tmp/filename).read_bytes(),mtime=0))
 if code!=expected:print(json.dumps(item));raise SystemExit(1)
assert all(sha((pathlib.Path(p) if p.startswith('/') else root/p).read_bytes())==digest for p,digest in before.items());assert events()==initial
receipt={'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'scope':'Private original-generator artifact consistency and existing unchanged negative controls only; no PG, migration apply, runtime behavior or readiness qualification.','lockPath':'/workspace/v10-preparation/v10-pg-tests.lock','heapMiB':128,'groupRssCapMiB':256,'deadlineSeconds':60,'allInputPinsUnchanged':True,'inputPinCount':len(before),'memoryBefore':initial,'memoryAfter':events(),'rootFreeKiB':free('/workspace'),'results':results};(q/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
