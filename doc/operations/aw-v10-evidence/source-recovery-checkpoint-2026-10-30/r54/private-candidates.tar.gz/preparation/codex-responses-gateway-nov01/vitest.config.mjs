import { defineConfig } from "/workspace/v10-dep-qualification/node_modules/vitest/dist/config.js";
import { createRequire } from "node:module";
const require = createRequire("/workspace/blentera-v10/server/package.json");
import fs from "node:fs";
import path from "node:path";
const overlay = "/workspace/v10-preparation/codex-responses-gateway-nov01";
const source = "/workspace/blentera-v10";
export default defineConfig({ plugins: [{ name: "source-overlay", enforce: "pre", resolveId(id, importer) {
 if (id === "vitest" || id.startsWith("@vitest/")) return;
 if (id === "@paperclipai/shared") return source + "/packages/shared/src/index.ts";
 if (!id.startsWith(".") && !id.startsWith("/") && !id.startsWith("node:")) {
   try { return require.resolve(id); } catch { return; }
 }
 if (!importer || !id.startsWith(".")) return;
 const absolute = path.resolve(path.dirname(importer.split("?")[0]), id).replace(/\.js$/, ".ts");
 if (absolute.startsWith(source + "/")) {
   const changed = overlay + absolute.slice(source.length);
   if (fs.existsSync(changed)) return changed;
 }
 if (!absolute.startsWith(overlay + "/")) return;
 if (fs.existsSync(absolute)) return absolute;
 const original = source + absolute.slice(overlay.length);
 if (fs.existsSync(original)) return original;
} }], test: { environment: "node", include: ["server/src/**/*.test.ts"], maxWorkers: 1, pool: "forks" } });
