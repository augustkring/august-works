from pathlib import Path
p=Path('/workspace/blentera-v10/server/src/services/native-direct-input.ts');s=p.read_text();s=s.replace('siblingToolSourceProofHits: 0, documentNodeHits: 0,','siblingToolSourceProofHits: 0, documentNodeHits: 0, documentOwnerReads: 0, documentOwnerMs: 0,',1)
a=s.index('async function assertNativeDocumentRevisionCurrentSourceAccessInScope(');b=s.index('\n}\n',a);c=s[a:b];needle='''  // Re-read the exact revision, document link, and latest pointer on every''';assert c.count(needle)==1;c=c.replace(needle,'''  const documentOwnerReadStartedAt = process.env.PAPERCLIP_NATIVE_CONTEXT_PHASE_DIAGNOSTICS === "1" ? performance.now() : null;
'''+needle)
needle='''  if (revision.payloadSourceSnapshotInvalidated || !parsed.success''';assert c.count(needle)==1;c=c.replace(needle,'''  if (documentOwnerReadStartedAt !== null) {
    nativeSourceMemoDiagnostics.documentOwnerReads += 1;
    nativeSourceMemoDiagnostics.documentOwnerMs += performance.now() - documentOwnerReadStartedAt;
  }
'''+needle);s=s[:a]+c+s[b:];Path('/workspace/v10-preparation/native-document-query-timing-candidate.ts').write_text(s)
p=Path('/workspace/blentera-v10/server/src/services/context/context-manifest.ts');s=p.read_text();needle='''      const phaseStartedAt = Date.now();''';assert s.count(needle)==1;s=s.replace(needle,'''      const phaseNativeReadStats = phaseDiagnosticsEnabled
        ? (await import("../native-direct-input.js")).nativeSourceMemoDiagnosticsForTest : undefined;
      const phaseNativeReads: Record<string, { calls: number; elapsedMs: number }> = {};
      const captureNativeReadStats = (phase: string) => {
        const stats = phaseNativeReadStats?.();
        if (stats) phaseNativeReads[phase] = { calls: stats.documentOwnerReads, elapsedMs: stats.documentOwnerMs };
      };
      captureNativeReadStats("entry");
'''+needle)
needle='''        const now = Date.now(); phaseElapsed[phaseName] = now - phaseAt; phaseName = name; phaseAt = now;''';assert s.count(needle)==1;s=s.replace(needle,needle+'\n        captureNativeReadStats(name);')
needle='''          const now = Date.now(); phaseElapsed[phaseName] = now - phaseAt;''';assert s.count(needle)==1;s=s.replace(needle,needle+'\n          captureNativeReadStats("exit");')
s=s.replace('initialRemainingMs: phaseInitialRemainingMs, elapsedMs: now - phaseStartedAt, phases: phaseElapsed }));','initialRemainingMs: phaseInitialRemainingMs, elapsedMs: now - phaseStartedAt, phases: phaseElapsed, nativeDocumentReads: phaseNativeReads }));')
Path('/workspace/v10-preparation/native-context-document-query-timing-candidate.ts').write_text(s)
