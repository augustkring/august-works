"""Restore the owned cold Cargo cache after typecheck, before real Rust builds.

The aggregate holds the canonical flock. This restores bytes and metadata; it
never qualifies a binary or replaces the required debug/release build commands.
"""
from pathlib import Path, PurePosixPath
from decimal import Decimal
import fcntl
import hashlib
import json
import os
import stat
import subprocess
import sys
import tarfile
import tempfile

CACHE = Path('/tmp/blentera-final-source-rust-target-20261101')
LOCK = Path('/workspace/v10-preparation/v10-pg-tests.lock')
BASE = Path('/dev/shm/blentera-final-rust-target-preservation-20261102')
ARCHIVE_SHA = 'efc26d0e696f7acab6993b05fa17204a3a22b8d090d9c3c0ddab9d0f6b8ce912'
MANIFEST_SHA = '32be1a9181676ec766be6855fc02622cd05ee8cf040e13c0e787a26075c9f4a7'
RECEIPT = Path('/workspace/v10-preparation/final-rust-cold-cache-restoration-20261102.json')


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def restore(cache, archive, manifest, archive_sha, manifest_sha, receipt):
    assert digest(manifest) == manifest_sha, 'cold-cache manifest changed'
    metadata = json.loads(manifest.read_text())
    assert metadata['sourcePath'] == str(cache)
    assert digest(archive) == archive_sha, 'cold-cache archive changed'
    assert cache.is_dir() and not cache.is_symlink()
    marker = cache / 'ARCHIVED.json'
    if not marker.exists():
        previous = json.loads(receipt.read_text())
        assert previous['archiveSha256'] == archive_sha and previous['manifestSha256'] == manifest_sha
        return {'status': 'already_restored', 'cache': str(cache), 'binaryQualification': False}
    assert {p.name for p in cache.iterdir()} == {'ARCHIVED.json'}, 'cache gained unowned files'
    marker_bytes = marker.read_bytes()
    pointer = json.loads(marker_bytes)
    assert pointer['sourcePath'] == str(cache) and pointer['archiveSha256'] == archive_sha
    assert pointer['manifestSha256'] == manifest_sha
    rows = metadata['entries']
    expected = {r['path']: r for r in rows}
    assert len(expected) == len(rows) and '.' in expected
    for path, row in expected.items():
        assert path == '.' or (not PurePosixPath(path).is_absolute() and
            '..' not in PurePosixPath(path).parts and str(PurePosixPath(path)) == path)
        assert row['type'] in {'file', 'dir', 'hardlink'}
        if row['type'] == 'hardlink':
            master = expected[row['hardlinkTo']]
            assert master['type'] == 'file'
            assert all(row[k] == master[k] for k in ('sha256', 'size', 'mode', 'uid', 'gid', 'mtimeNs'))
    seen = set()
    with tarfile.open(archive, 'r|gz') as stream:
        for member in stream:
            assert member.name in expected and member.name not in seen
            row = expected[member.name]
            kind = 'dir' if member.isdir() else 'file' if member.isfile() else 'hardlink' if member.islnk() else None
            assert kind == row['type']
            assert (member.mode, member.uid, member.gid) == (row['mode'], row['uid'], row['gid'])
            assert int(Decimal(member.pax_headers.get('mtime', str(member.mtime))) * 1_000_000_000) == row['mtimeNs']
            if kind == 'file':
                assert member.size == row['size']
                assert hashlib.file_digest(stream.extractfile(member), 'sha256').hexdigest() == row['sha256']
            elif kind == 'hardlink':
                assert member.size == 0 and member.linkname == row['hardlinkTo'] and member.linkname in seen
            seen.add(member.name)
    assert seen == set(expected)
    staging = Path(tempfile.mkdtemp(prefix=cache.name + '.restore-', dir=cache.parent))
    child_env = os.environ.copy()
    child_env['TAR_OPTIONS'] = ''
    subprocess.run(['/usr/bin/tar', '--extract', '--use-compress-program=/usr/bin/gzip',
        '--same-owner', '--same-permissions', '--delay-directory-restore',
        '--file', str(archive), '--directory', str(staging)], env=child_env, check=True)
    actual = {'.'}
    for parent, dirs, files in os.walk(staging, followlinks=False):
        for name in dirs + files:
            actual.add(str((Path(parent) / name).relative_to(staging)))
    assert actual == set(expected), 'restored cache path set differs'
    inode_groups = {}
    for path, row in expected.items():
        restored = staging if path == '.' else staging / path
        info = restored.lstat()
        assert (stat.S_IMODE(info.st_mode), info.st_uid, info.st_gid, info.st_mtime_ns) == (
            row['mode'], row['uid'], row['gid'], row['mtimeNs']), path
        assert (stat.S_ISDIR(info.st_mode) if row['type'] == 'dir' else stat.S_ISREG(info.st_mode))
        if row['type'] != 'dir':
            assert info.st_size == row['size']
            inode_groups.setdefault((info.st_dev, info.st_ino), []).append((path, info.st_nlink))
            if row['type'] == 'file':
                assert digest(restored) == row['sha256'], path
            else:
                master = (staging / row['hardlinkTo']).stat()
                assert (info.st_dev, info.st_ino) == (master.st_dev, master.st_ino), path
    assert all(all(count == len(group) for _, count in group) for group in inode_groups.values())
    assert marker.read_bytes() == marker_bytes and {p.name for p in cache.iterdir()} == {'ARCHIVED.json'}
    retired = cache.with_name(cache.name + '.cold-marker-before-restore')
    assert not retired.exists()
    os.rename(cache, retired)
    os.rename(staging, cache)
    result = {'status': 'restored', 'cache': str(cache), 'archiveSha256': archive_sha,
        'manifestSha256': manifest_sha, 'paths': len(rows), 'hardlinkAliases': sum(r['type'] == 'hardlink' for r in rows),
        'verified': 'exact paths/content/mode/uid/gid/ns-mtime/internal hardlink topology; archive retained',
        'retiredMarker': str(retired), 'binaryQualification': False}
    receipt.write_text(json.dumps(result, indent=2) + '\n')
    return result


def require_inherited_lock():
    owned = LOCK.stat()
    for path in Path('/proc/self/fd').iterdir():
        try:
            fd = int(path.name)
            info = os.fstat(fd)
            if (info.st_dev, info.st_ino) == (owned.st_dev, owned.st_ino):
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                return
        except (OSError, ValueError):
            continue
    raise RuntimeError('cold-cache restore requires inherited canonical aggregate flock')


if __name__ == '__main__':
    assert len(sys.argv) == 2 and Path(sys.argv[1]) == CACHE
    require_inherited_lock()
    assert Path('/tmp/blentera-preserved-current-rust-target').resolve() == CACHE.resolve()
    print(json.dumps(restore(CACHE, BASE/'rust-target.tar.gz', BASE/'rust-target.manifest.json',
        ARCHIVE_SHA, MANIFEST_SHA, RECEIPT)))
