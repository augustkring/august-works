# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: aw-v9-workflow-test.spec.ts >> an unpublished internal test recovers its original receipt after reload and preserves native test purpose
- Location: tests/e2e/aw-v9-workflow-test.spec.ts:12:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Data supplied when this workflow starts.', { exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByText('Data supplied when this workflow starts.', { exact: true })

```

```yaml
- link "Skip to Main Content":
  - /url: "#main-content"
- complementary:
  - button "Open Unpublished internal test browser fixture organization switcher": U Unpublished internal test browser fixture
  - navigation:
    - text: Visning
    - combobox "Visning":
      - option "Medlem"
      - option "Leder" [selected]
      - option "Administrator"
      - option "Sikkerhedsadministrator"
    - link "Hjem":
      - /url: /UNP/dashboard
    - link "Kræver dig":
      - /url: /UNP/needs-you
    - link "Arbejde":
      - /url: /UNP/work
    - link "Agenter":
      - /url: /UNP/agents
    - link "Apps":
      - /url: /UNP/apps
    - link "Indsigter":
      - /url: /UNP/insights
    - link "Avanceret":
      - /url: /UNP/advanced
    - button "Spørg Blentera"
    - link "Hjælp / Support":
      - /url: /UNP/company/help
- button "Open account menu": BR Browser product reviewer
- region "Globale funktioner":
  - button "Åbn navigation"
  - button "Spørg Blentera"
  - text: Sprog
  - combobox "Sprog":
    - option "English"
    - option "Dansk" [selected]
  - link "Hjælp / Support":
    - /url: /UNP/company/help
  - link "Kontakt support":
    - /url: mailto:support@blentera.com
  - link "Brugerkonto":
    - /url: /UNP/company/settings/instance/profile
- main:
  - link "Alle workflows":
    - /url: /UNP/workflows
  - heading "Test internal routing" [level=1]
  - paragraph: Kladde — ingen aktiv udgivet version
  - region "Driftsoversigt":
    - heading "Driftsoversigt" [level=2]
    - heading "Næste trigger" [level=3]
    - paragraph: Udgiv en testet version, før du starter arbejdet.
    - heading "Afventer handling eller genopretning" [level=3]
    - paragraph: Ingen kørsel venter eller er under genopretning nu. Gennemgå fejlede kørsler separat i historikken.
    - heading "Seneste kørsler" [level=3]
    - paragraph: Dette er registrerede eksekveringsstatusser. En afsluttet kørsel dokumenterer ikke et uafhængigt verificeret forretningsresultat.
    - paragraph: Der er endnu ingen registrerede kørsler.
    - button "Opdater kørsel"
  - region "Kladdeversion 2":
    - heading "Kladdeversion 2" [level=2]
    - paragraph: Denne kladde er adskilt fra den aktive version. At læse eller redigere kladden ændrer ikke det aktive workflow.
    - link "Opbyg dette kladdeflow":
      - /url: /UNP/workflows/538aaed7-dcc9-4992-8509-c96dbc4a81da/draft
    - paragraph: Trinnumrene identificerer de angivne trin. Forbindelserne bestemmer rækkefølge og forgreninger; dette er ikke et kørselsforløb.
    - list:
      - listitem:
        - 'heading "Trin 1: Start internal test" [level=3]'
        - term: Handling
        - definition: Manual Trigger
        - term: Udføres af
        - definition: Workflowmotoren
        - term: Inputkilde
        - definition: Data, der angives, når workflowet starter.
        - term: Nødvendig adgang
        - definition: Der er ikke angivet en yderligere tilladelse for trinnet. Tilladelser til workflow og kørsel gælder stadig.
        - term: Godkendelsesregel
        - definition: Trinnet har intet godkendelsespunkt. Reglerne for at starte workflowet gælder stadig.
        - term: Mulig effekt angivet af handlingen
        - definition: Beregning uden angivet ekstern effekt
        - term: Godkendelse
        - definition: De gældende godkendelsesregler er ikke verificeret i denne visning.
        - term: Genforsøg
        - definition: Intet genforsøg angivet
        - definition:
          - paragraph: Højst 1 forsøg.
          - paragraph: Handlingen angiver, at en nøgle mod dobbelte virkninger ikke er nødvendig.
        - term: Angivet testtilstand
        - definition: Sikker tilstand angivet
        - term: Forbundne næste trin
        - definition:
          - list:
            - listitem: Trin 2
        - link "Rediger dette kladdetrin":
          - /url: /UNP/workflows/538aaed7-dcc9-4992-8509-c96dbc4a81da/draft/steps/start
      - listitem:
        - 'heading "Trin 2: Choose internal route" [level=3]'
        - term: Handling
        - definition: Condition
        - term: Udføres af
        - definition: Workflowmotoren
        - term: Inputkilde
        - definition: Startdata, variabler eller tidligere resultater, som betingelsen bruger.
        - term: Nødvendig adgang
        - definition: Der er ikke angivet en yderligere tilladelse for trinnet. Tilladelser til workflow og kørsel gælder stadig.
        - term: Godkendelsesregel
        - definition: Trinnet har intet godkendelsespunkt. Reglerne for at starte workflowet gælder stadig.
        - term: Når denne betingelse er opfyldt
        - definition:
          - paragraph: Data ved workflowets start
          - list "Feltnavne, fra yderste til inderste niveau":
            - listitem:
              - code: "\"amount\""
          - paragraph: Er større end eller lig med
          - paragraph:
            - text: "Tal:"
            - code: "10000"
        - term: Mulig effekt angivet af handlingen
        - definition: Beregning uden angivet ekstern effekt
        - term: Godkendelse
        - definition: De gældende godkendelsesregler er ikke verificeret i denne visning.
        - term: Genforsøg
        - definition: Intet genforsøg angivet
        - definition:
          - paragraph: Højst 1 forsøg.
          - paragraph: Handlingen angiver, at en nøgle mod dobbelte virkninger ikke er nødvendig.
        - term: Angivet testtilstand
        - definition: Sikker tilstand angivet
        - term: Forbundne næste trin
        - definition:
          - list:
            - listitem: "Trin 3 — Angivet udgang: true"
            - listitem: "Trin 4 — Angivet udgang: false"
        - link "Rediger dette kladdetrin":
          - /url: /UNP/workflows/538aaed7-dcc9-4992-8509-c96dbc4a81da/draft/steps/route
      - listitem:
        - 'heading "Trin 3: Finish internal test" [level=3]'
        - term: Handling
        - definition: Merge activated branches
        - term: Udføres af
        - definition: Workflowmotoren
        - term: Inputkilde
        - definition: Tilknyttede startdata, variabler eller resultater fra tidligere trin.
        - term: Nødvendig adgang
        - definition: Der er ikke angivet en yderligere tilladelse for trinnet. Tilladelser til workflow og kørsel gælder stadig.
        - term: Godkendelsesregel
        - definition: Trinnet har intet godkendelsespunkt. Reglerne for at starte workflowet gælder stadig.
        - term: Mulig effekt angivet af handlingen
        - definition: Beregning uden angivet ekstern effekt
        - term: Godkendelse
        - definition: De gældende godkendelsesregler er ikke verificeret i denne visning.
        - term: Genforsøg
        - definition: Intet genforsøg angivet
        - definition:
          - paragraph: Højst 1 forsøg.
          - paragraph: Handlingen angiver, at en nøgle mod dobbelte virkninger ikke er nødvendig.
        - term: Angivet testtilstand
        - definition: Sikker tilstand angivet
        - term: Forbundne næste trin
        - definition: Ingen udgående forbindelse angivet.
        - link "Rediger dette kladdetrin":
          - /url: /UNP/workflows/538aaed7-dcc9-4992-8509-c96dbc4a81da/draft/steps/finish
      - listitem:
        - 'heading "Trin 4: Unselected internal path" [level=3]'
        - term: Handling
        - definition: Merge activated branches
        - term: Udføres af
        - definition: Workflowmotoren
        - term: Inputkilde
        - definition: Tilknyttede startdata, variabler eller resultater fra tidligere trin.
        - term: Nødvendig adgang
        - definition: Der er ikke angivet en yderligere tilladelse for trinnet. Tilladelser til workflow og kørsel gælder stadig.
        - term: Godkendelsesregel
        - definition: Trinnet har intet godkendelsespunkt. Reglerne for at starte workflowet gælder stadig.
        - term: Mulig effekt angivet af handlingen
        - definition: Beregning uden angivet ekstern effekt
        - term: Godkendelse
        - definition: De gældende godkendelsesregler er ikke verificeret i denne visning.
        - term: Genforsøg
        - definition: Intet genforsøg angivet
        - definition:
          - paragraph: Højst 1 forsøg.
          - paragraph: Handlingen angiver, at en nøgle mod dobbelte virkninger ikke er nødvendig.
        - term: Angivet testtilstand
        - definition: Sikker tilstand angivet
        - term: Forbundne næste trin
        - definition: Ingen udgående forbindelse angivet.
        - link "Rediger dette kladdetrin":
          - /url: /UNP/workflows/538aaed7-dcc9-4992-8509-c96dbc4a81da/draft/steps/alternate
  - region "Før du foretager ændringer":
    - heading "Før du foretager ændringer" [level=2]
    - paragraph: Input, ansvarlige aktører, modtagere, aktuel adgang og gældende godkendelsesregler kræver en fuld gennemgang af den native kladde. Handlingsnavne fastslår ikke tilladelse eller sikkerhed.
    - paragraph: Intet repræsentativt testresultat er verificeret her. En angivet testtilstand er ikke en bestået test; denne visning kan ikke teste, udgive, køre, pause eller udfase et workflow.
  - navigation "Workflowhandlinger":
    - link "Rediger kladde i Avanceret":
      - /url: /UNP/workflows/538aaed7-dcc9-4992-8509-c96dbc4a81da/advanced
  - region "Publicér intern version":
    - heading "Publicér intern version" [level=2]
    - paragraph: Denne publicering er begrænset til det gennemgåede interne kontrolflow med tomt syntetisk input. Den interne test kvalificerer ikke væsentlige handlinger og verificerer ikke et forretningsresultat uafhængigt.
    - paragraph: Gennemfør en intern test af den aktuelle draft før publicering.
  - region "Test kladden":
    - heading "Test kladden" [level=2]
    - button "Gennemgå intern test"
  - region "Start arbejde":
    - heading "Start arbejde" [level=2]
    - paragraph: En aktuel aktiv udgivet version er nødvendig for en ny kørsel.
  - region "Workflowkontrol":
    - heading "Workflowkontrol" [level=2]
    - paragraph: Pause stopper nye starter. Eksisterende arbejde fortsætter med sine gældende regler for godkendelse, genforsøg og genoprettelse.
    - button "Pause"
- navigation "Mobilnavigation":
  - link "Hjem":
    - /url: /UNP/dashboard
  - link "Kræver dig":
    - /url: /UNP/needs-you
  - link "Arbejde":
    - /url: /UNP/work
  - link "Agenter":
    - /url: /UNP/agents
  - link "Apps":
    - /url: /UNP/apps
- heading "Command Palette" [level=2]
- paragraph: Search for a command to run...
```

# Test source

```ts
  19  |   );
  20  |   const session = await json(await request.get("/api/auth/get-session"));
  21  |   const expectedUserId = encodeURIComponent(session.user.id);
  22  |   const enabled = {
  23  |     enableWorkflowsV1: true,
  24  |     enableWorkflowBuilderV1: true,
  25  |     experience_projection_v9: true,
  26  |     progressive_shell_v9: true,
  27  |   };
  28  |   const errors: string[] = [];
  29  |   page.on("pageerror", (error) => errors.push(error.message));
  30  |   try {
  31  |     await json(
  32  |       await request.patch("/api/instance/settings/experimental", {
  33  |         data: enabled,
  34  |       }),
  35  |     );
  36  |     const company = await json(
  37  |       await request.post("/api/companies", {
  38  |         data: { name: "Unpublished internal test browser fixture" },
  39  |       }),
  40  |     );
  41  |     const base = `/api/companies/${company.id}`,
  42  |       workflows = `${base}/workflows`;
  43  |     const draft = await json(
  44  |       await request.post(workflows, {
  45  |         data: { name: "Test internal routing" },
  46  |       }),
  47  |     );
  48  |     const prepared = await json(
  49  |       await request.patch(`${workflows}/${draft.id}/draft`, {
  50  |         data: {
  51  |           expectedRevisionId: draft.draftRevisionId,
  52  |           graph: {
  53  |             version: 1,
  54  |             variables: [],
  55  |             settings: { totalDeadlineSeconds: 60 },
  56  |             nodes: [
  57  |               {
  58  |                 id: "start",
  59  |                 type: "core.manual_trigger",
  60  |                 name: "Start internal test",
  61  |                 config: {},
  62  |                 position: { x: 0, y: 0 },
  63  |               },
  64  |               {
  65  |                 id: "route",
  66  |                 type: "core.condition",
  67  |                 name: "Choose internal route",
  68  |                 config: { expression: '{{trigger.amount}} >= 10000' },
  69  |                 position: { x: 0, y: 1 },
  70  |               },
  71  |               {
  72  |                 id: "finish",
  73  |                 type: "core.merge",
  74  |                 name: "Finish internal test",
  75  |                 config: { mode: "all" },
  76  |                 position: { x: 0, y: 2 },
  77  |               },
  78  |               {
  79  |                 id: "alternate",
  80  |                 type: "core.merge",
  81  |                 name: "Unselected internal path",
  82  |                 config: { mode: "all" },
  83  |                 position: { x: 1, y: 2 },
  84  |               },
  85  |             ],
  86  |             edges: [
  87  |               { id: "start-route", source: "start", target: "route" },
  88  |               {
  89  |                 id: "route-finish",
  90  |                 source: "route",
  91  |                 target: "finish",
  92  |                 sourceHandle: "true",
  93  |               },
  94  |               {
  95  |                 id: "route-alternate",
  96  |                 source: "route",
  97  |                 target: "alternate",
  98  |                 sourceHandle: "false",
  99  |               },
  100 |             ],
  101 |           },
  102 |         },
  103 |       }),
  104 |     );
  105 |     expect(prepared.publishedRevisionId).toBeNull();
  106 |     const endpoint = `${workflows}/${draft.id}/experience/test?expectedUserId=${expectedUserId}`;
  107 |     const commands: Record<string, unknown>[] = [];
  108 |     let accepted: Record<string, unknown> | undefined;
  109 |     await page.route(`**${endpoint}`, async (route) => {
  110 |       commands.push(route.request().postDataJSON());
  111 |       if (commands.length === 1) {
  112 |         accepted = await json(await route.fetch());
  113 |         await route.abort("failed");
  114 |       } else await route.continue();
  115 |     });
  116 |     const path = `/${company.issuePrefix}/workflows/${draft.id}`;
  117 |     await page.setViewportSize({ width: 390, height: 844 });
  118 |     await page.goto(path);
> 119 |     await expect(page.getByText("Data supplied when this workflow starts.", { exact: true })).toBeVisible();
      |                                                                                               ^ Error: expect(locator).toBeVisible() failed
  120 |     await expect(page.getByText("Start data, variables or earlier outputs used by the condition.", { exact: true })).toBeVisible();
  121 |     await expect(page.getByText("This step has no approval checkpoint. Workflow admission rules still apply.", { exact: true }).first()).toBeVisible();
  122 |     await expect(page.getByText("At most 1 attempt.", { exact: true }).first()).toBeVisible();
  123 |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  124 |     await page
  125 |       .getByRole("button", { name: "Review internal test", exact: true })
  126 |       .click();
  127 |     const dialog = page.getByRole("dialog"),
  128 |       confirm = dialog.getByRole("button", {
  129 |         name: "Start internal test",
  130 |         exact: true,
  131 |       });
  132 |     await expect(dialog).toContainText("An empty list starts with no data");
  133 |     await expect(dialog).toContainText(
  134 |       "Succeeded, within the configured 60 seconds",
  135 |     );
  136 |     await expect(confirm).toBeDisabled();
  137 |     expect(commands).toHaveLength(0);
  138 |     await dialog.getByRole("button", { name: "Add a test value", exact: true }).click();
  139 |     const inputPath = dialog.getByRole("textbox", { name: "Field names, from outermost to innermost", exact: true });
  140 |     await expect(inputPath).toBeFocused(); await inputPath.fill("amount");
  141 |     await dialog.getByRole("combobox", { name: "Value type", exact: true }).selectOption("number");
  142 |     await dialog.getByRole("spinbutton", { name: "Test value", exact: true }).fill("10000");
  143 |     await page.addScriptTag({ path: axePath });
  144 |     const violations = await page.evaluate(
  145 |       async () =>
  146 |         (
  147 |           await (
  148 |             window as unknown as {
  149 |               axe: {
  150 |                 run: (scope: string) => Promise<{ violations: unknown[] }>;
  151 |               };
  152 |             }
  153 |           ).axe.run('[role="dialog"]')
  154 |         ).violations,
  155 |     );
  156 |     expect(violations).toEqual([]);
  157 |     await page.screenshot({
  158 |       path: info.outputPath("unpublished-test-confirmation-mobile.png"),
  159 |       fullPage: true,
  160 |     });
  161 |     await dialog.getByRole("checkbox").check();
  162 |     await confirm.click();
  163 |     await expect.poll(() => commands.length).toBe(1);
  164 |     expect(commands[0].syntheticInput).toEqual([{ path: ["amount"], value: 10000 }]);
  165 |     await expect.poll(() => accepted?.requestId).toBe(commands[0].requestId);
  166 |     await page.reload();
  167 |     await expect(
  168 |       page.getByText(
  169 |         "The original internal test was admitted. Open the test to check its actual status and steps.",
  170 |         { exact: true },
  171 |       ),
  172 |     ).toBeVisible();
  173 |     expect(commands).toHaveLength(1);
  174 |     const current = await json(await request.get(`${workflows}/${draft.id}`));
  175 |     expect(current.publishedRevisionId).toBeNull();
  176 |     expect(current.draftRevisionId).toBe(prepared.draftRevisionId);
  177 |     const recovered = await json(
  178 |       await request.get(
  179 |         `${workflows}/${draft.id}/experience?expectedUserId=${expectedUserId}`,
  180 |       ),
  181 |     );
  182 |     expect(recovered.testReceipt).toEqual(accepted);
  183 |     expect(
  184 |       await json(await request.post(endpoint, { data: commands[0] })),
  185 |     ).toEqual(accepted);
  186 |     const history = await json(
  187 |       await request.get(`${workflows}/${draft.id}/runs`),
  188 |     );
  189 |     expect(history).toHaveLength(1);
  190 |     expect(history[0]).toMatchObject({
  191 |       id: accepted!.runId,
  192 |       source: "test",
  193 |       status: "succeeded",
  194 |       workflowRevisionId: prepared.draftRevisionId,
  195 |     });
  196 |     const activity = await json(await request.get(`${base}/activity`));
  197 |     expect(
  198 |       activity.filter(
  199 |         (event: { action: string; entityId: string }) =>
  200 |           event.action === "workflow.customer_test_admitted" &&
  201 |           event.entityId === draft.id,
  202 |       ),
  203 |     ).toHaveLength(1);
  204 |     await page
  205 |       .getByRole("link", { name: "Inspect internal test", exact: true })
  206 |       .click();
  207 |     await expect(
  208 |       page.getByRole("heading", {
  209 |         name: "Internal workflow test",
  210 |         exact: true,
  211 |       }),
  212 |     ).toBeVisible();
  213 |     await expect(
  214 |       page.getByText(
  215 |         "Recorded branch selects next step: Finish internal test. This does not confirm that the next step ran.",
  216 |         { exact: true },
  217 |       ),
  218 |     ).toBeVisible();
  219 |     await page.screenshot({
```