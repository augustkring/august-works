# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: conference-room-typing-intro.spec.ts >> First-task launch after onboarding wizard >> lands on the first task even when a company already exists
- Location: tests/e2e/conference-room-typing-intro.spec.ts:153:3

# Error details

```
TimeoutError: locator.waitFor: Timeout 20000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: /Get started/ }) to be visible

```

# Page snapshot

```yaml
- generic [ref=e5]:
  - generic [ref=e6]:
    - button "Name your organization" [ref=e7] [cursor=pointer]
    - button "Create your first agent" [ref=e8] [cursor=pointer]
    - button "Connect a model" [disabled] [ref=e9]
    - button "Review" [disabled] [ref=e10]
    - generic [ref=e11]: Step 3 of 4
  - generic [ref=e12]:
    - generic [ref=e13]: Ada
    - heading "Connect a model" [level=1] [ref=e25]
    - paragraph [ref=e28]:
      - generic [ref=e29]: Paperclip works with your subscription or API keys.
  - generic [ref=e31]:
    - radiogroup "Model source" [ref=e32]:
      - radio "Claude Subscription" [checked] [ref=e34] [cursor=pointer]:
        - generic [ref=e36]: Claude
        - generic [ref=e37]: Subscription
    - button "Use API key instead" [ref=e40] [cursor=pointer]
  - paragraph [ref=e43]: Unauthorized
  - generic [ref=e44]:
    - button "Back" [ref=e45]
    - button "Connect" [ref=e47]
```

# Test source

```ts
  10  |  *
  11  |  * Completing the onboarding wizard now creates the first assigned task and
  12  |  * drops the user straight onto that task's detail page (not the dashboard),
  13  |  * so they land in the conversation the agent will start in. The chat intro
  14  |  * still has unit coverage in BoardChat tests.
  15  |  *
  16  |  * PAP-404: onboarding used to intermittently bounce to the company dashboard.
  17  |  * The bounce only reproduces when the instance already has ≥1 company (the
  18  |  * board's test ports), so the second test seeds a company first to exercise
  19  |  * exactly that failing condition.
  20  |  */
  21  | 
  22  | const FIRST_TASK_TITLE = "Paperclip onboarding";
  23  | 
  24  | /**
  25  |  * Intercept authentication, environment checks, and hiring so no real CLI check
  26  |  * runs and no real agent process spawns (the hire still happens server-side
  27  |  * with an inert http adapter).
  28  |  */
  29  | async function installLaunchIntercepts(page: Page, baseURL?: string) {
  30  |   await mockOnboardingLocalAiConnection(page);
  31  |   await page.route("**/test-environment", (route) =>
  32  |     route.fulfill({
  33  |       contentType: "application/json",
  34  |       body: JSON.stringify({ status: "pass", checks: [] }),
  35  |     }),
  36  |   );
  37  | 
  38  |   await page.route("**/agent-hires", async (route) => {
  39  |     const req = route.request();
  40  |     const body = JSON.parse(req.postData() || "{}");
  41  |     const auth = req.headers().authorization;
  42  |     const real = await fetch(new URL(req.url(), baseURL).toString(), {
  43  |       method: "POST",
  44  |       headers: {
  45  |         "Content-Type": "application/json",
  46  |         ...(auth ? { Authorization: auth } : {}),
  47  |       },
  48  |       body: JSON.stringify({
  49  |         name: body.name,
  50  |         role: body.role,
  51  |         adapterType: "http",
  52  |         adapterConfig: { url: "http://127.0.0.1:1/dead" },
  53  |         runtimeConfig: { heartbeat: { enabled: false } },
  54  |       }),
  55  |     });
  56  |     await route.fulfill({
  57  |       status: real.status,
  58  |       contentType: "application/json",
  59  |       body: await real.text(),
  60  |     });
  61  |   });
  62  | }
  63  | 
  64  | /** Drive the wizard from the /onboarding route through to "Get started". */
  65  | async function runOnboardingWizard(page: Page, companyName: string) {
  66  |   await page.goto("/onboarding");
  67  | 
  68  |   // Launcher card path (existing companies) — enter the wizard if the
  69  |   // route shows a launcher instead of opening the wizard directly.
  70  |   const startBtn = page.getByRole("button", { name: /Start Onboarding/i });
  71  |   if (await startBtn.count()) await startBtn.first().click();
  72  | 
  73  |   // Step 0: front door (skipped when the wizard opens on the create path).
  74  |   const frontDoor = page.getByText("Build a new organization");
  75  |   if (await frontDoor.count()) await frontDoor.first().click();
  76  | 
  77  |   // Step 1: company name.
  78  |   await page.getByPlaceholder("e.g. Northwind Labs").fill(companyName);
  79  |   await page.getByRole("button", { name: /^Continue/ }).click();
  80  | 
  81  |   // Step 1's "Next" creates the company; the mission step no longer runs.
  82  | 
  83  |   // Step 3: name the agent. The role picker is gone — the arc asks for a
  84  |   // name and hires under the neutral `general` role.
  85  |   await page.waitForSelector("#onboarding-agent-name", { timeout: 30_000 });
  86  |   await page.locator("#onboarding-agent-name").fill("Ada");
  87  |   await page.getByRole("button", { name: /^Next$/ }).click();
  88  | 
  89  |   // Step 4: pick a model source, then advance. Nothing is selected on arrival
  90  |   // — the row is a question, not a confirmation — so the CTA is disabled until
  91  |   // a tile is pressed. By role rather than by label: which adapters the tiles
  92  |   // offer depends on the registry this environment reports.
  93  |   const source = page.getByRole("radio").first();
  94  |   await source.waitFor({ timeout: 30_000 });
  95  |   await source.click();
  96  | 
  97  |   // "Connect", not "Next": this step's button starts the sign-in where there
  98  |   // is one to start, so it is named for what it does. This test simulates
  99  |   // successful local account connection before the environment check and hire.
  100 |   //
  101 |   // Waited on for enabled rather than for visible: it is already on screen,
  102 |   // disabled, and clicking a disabled button raises nothing and does nothing.
  103 |   const connectNext = page.getByRole("button", { name: /^Connect$/ });
  104 |   await expect(connectNext).toBeEnabled({ timeout: 30_000 });
  105 |   await connectNext.click();
  106 | 
  107 |   // Step 5: review → Get started creates the first task and opens its
  108 |   // detail page.
  109 |   const getStarted = page.getByRole("button", { name: /Get started/ });
> 110 |   await getStarted.waitFor({ timeout: 20_000 });
      |                    ^ TimeoutError: locator.waitFor: Timeout 20000ms exceeded.
  111 |   await getStarted.click();
  112 | }
  113 | 
  114 | async function assertFirstTaskExists(page: Page, companyName: string) {
  115 |   const companiesRes = await page.request.get("/api/companies");
  116 |   expect(companiesRes.ok()).toBe(true);
  117 |   const companies = await companiesRes.json();
  118 |   const company = companies.find(
  119 |     (candidate: { name: string }) => candidate.name === companyName,
  120 |   );
  121 |   expect(company).toBeTruthy();
  122 | 
  123 |   const issuesRes = await page.request.get(`/api/companies/${company.id}/issues`);
  124 |   expect(issuesRes.ok()).toBe(true);
  125 |   const issues = await issuesRes.json();
  126 |   const firstTask = issues.find(
  127 |     (candidate: { title: string }) => candidate.title === FIRST_TASK_TITLE,
  128 |   );
  129 |   expect(firstTask).toBeTruthy();
  130 |   // The progressive sidebar can retain a hidden task label. Assert the actual
  131 |   // task detail heading instead of whichever text node appears first.
  132 |   await expect(page.getByRole("main").getByRole("heading", { name: FIRST_TASK_TITLE, exact: true })).toBeVisible({
  133 |     timeout: 15_000,
  134 |   });
  135 | }
  136 | 
  137 | test.describe("First-task launch after onboarding wizard", () => {
  138 |   test("creates the first task and opens its detail page", async ({ page, baseURL }) => {
  139 |     await instrumentNavLog(page);
  140 |     await installLaunchIntercepts(page, baseURL);
  141 | 
  142 |     const companyName = `E2E-TypingIntro-${Date.now()}`;
  143 |     await runOnboardingWizard(page, companyName);
  144 | 
  145 |     await expectLandsOnFirstTaskWithoutDashboardBounce(page);
  146 |     await assertFirstTaskExists(page, companyName);
  147 |   });
  148 | 
  149 |   // PAP-404 regression: the dashboard bounce only fires when the instance
  150 |   // already has a company for the route-sync effect to reset selection to.
  151 |   // Seed one first, then onboard a brand-new company and assert we still land
  152 |   // on the first task without a dashboard bounce.
  153 |   test("lands on the first task even when a company already exists", async ({
  154 |     page,
  155 |     baseURL,
  156 |   }) => {
  157 |     await instrumentNavLog(page);
  158 |     await installLaunchIntercepts(page, baseURL);
  159 | 
  160 |     // Seed a pre-existing company so the companies list is non-empty when the
  161 |     // wizard launches — the exact condition that reproduced the bounce.
  162 |     const seedRes = await page.request.post("/api/companies", {
  163 |       data: { name: `E2E-Seed-${Date.now()}` },
  164 |     });
  165 |     expect(seedRes.ok()).toBe(true);
  166 | 
  167 |     const companyName = `E2E-TypingIntro-Existing-${Date.now()}`;
  168 |     await runOnboardingWizard(page, companyName);
  169 | 
  170 |     await expectLandsOnFirstTaskWithoutDashboardBounce(page);
  171 |     await assertFirstTaskExists(page, companyName);
  172 |   });
  173 | });
  174 | 
```