# V10-149 private R14 host credential claim alignment

This is a two-file host delta on the frozen private R13 source, kept separate while Quality's server-side R2 remains mutable. It matches the current issuer claim contract: nested claim version and sourceBindingHash are required; scope uses `generation`; containerId is the raw 64-hex Docker ID; `execute(id)` must equal the signed claim commandId; and the capability is bound to the host-computed targetQualificationHash. The candidate pins cover the same 12-path composed source set as R13; only the host engine and host test change here.

The host-agent suite passed 51/51 under the canonical flock with mocked Docker and CLI. Node syntax checks passed. No mirror overlay, issuer integration, Cargo test, or physical qualification ran. This is not yet the complete R14 composition; wait for frozen Quality R2 before combining and qualifying.
