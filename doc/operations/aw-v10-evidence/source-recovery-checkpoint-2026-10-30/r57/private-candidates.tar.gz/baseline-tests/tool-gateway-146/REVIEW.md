This is a test-only migration of the two frozen ToolGateway suites. Production admission, registries, paid profiles, plugin and Cognee expectations are unchanged.

The original137 test cases remain active. Three service workflow/review/remembered-permission journeys and six gateway policy/replay/rate-limit journeys now use the existing fixed Railway GraphQL endpoint and strict schema, with real database grants and vault references. Their approval, crash recovery, catalogue drift, stored-argument replay, denial, quota and tenant assertions remain active.

Opaque HTTP/stdio cases now assert the supported behavior: refusal before provider dispatch, vault access, approval creation or runtime spawn. Test-tab and named-gateway paths remain covered; discovery/auth/revocation/profile and protocol-rate-limit assertions remain active. Unsupported opaque tool execution and physical child cancellation are not claimed as successful.

Nine additional cases exercise the actual exported mcp-http owner directly: elicitation envelope, stateful initialization/session headers, SSE provider error, invalid JSON, wrong request ID, response size/cancellation, abort, timeout, and deterministic SDK KV HTTP flow. These transport tests do not carry or bypass application admission.

The new zero-effect assertions found a real preselection defect: GitHub credential-aware descriptor selection refreshed OAuth/read a vault secret before the opaque guard. The separate production owner fix is qualification-boundary-followup-nov01 patch17975fe5 (ToolGateway3f51b71b...). All three affected cases now assert unchanged OAuth-refresh counts plus zero vault/provider effects after explicit discovery.

Qualification: whole two suites146/146 PASS, no selector or skipped cases, whole-r6.log; effective production hashes in whole-r6-effective-source-pins.json. Full production TS7 --noEmit --singleThreaded PASS0/empty log. The server config excludes __tests__, so no separate static test-typecheck claim is made. The exact two source files are frozen by manifest.json and tool-gateway-baseline-migration.patch. Main, active Host snapshots and frozen C7 source were not edited.
