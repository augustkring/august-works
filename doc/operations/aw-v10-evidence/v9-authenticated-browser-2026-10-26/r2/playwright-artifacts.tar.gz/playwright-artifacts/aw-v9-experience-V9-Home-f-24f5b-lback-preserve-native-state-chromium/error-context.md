# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: aw-v9-experience.spec.ts >> V9 Home, feedback recovery and rollback preserve native state
- Location: tests/e2e/aw-v9-experience.spec.ts:14:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'Home', exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByRole('heading', { name: 'Home', exact: true })

```

```yaml
- link "Skip to Main Content":
  - /url: "#main-content"
- complementary:
  - button "Open V9 disposable browser company organization switcher": V V9 disposable browser company
  - navigation:
    - text: Visning
    - combobox "Visning":
      - option "Medlem"
      - option "Leder" [selected]
      - option "Administrator"
      - option "Sikkerhedsadministrator"
    - link "Hjem":
      - /url: /VDIA/dashboard
    - link "Kræver dig":
      - /url: /VDIA/needs-you
    - link "Arbejde":
      - /url: /VDIA/work
    - link "Agenter":
      - /url: /VDIA/agents
    - link "Apps":
      - /url: /VDIA/apps
    - link "Indsigter":
      - /url: /VDIA/insights
    - link "Avanceret":
      - /url: /VDIA/advanced
    - button "Spørg Blentera"
    - link "Hjælp / Support":
      - /url: /VDIA/company/help
- button "Open account menu": BR Browser product reviewer
- button "Feedback"
- separator "Resize sidebar"
- region "Globale funktioner":
  - button "Spørg Blentera"
  - text: Sprog
  - combobox "Sprog":
    - option "English"
    - option "Dansk" [selected]
  - button "Feedback"
  - link "Hjælp / Support":
    - /url: /VDIA/company/help
  - link "Kontakt support":
    - /url: mailto:support@blentera.com
  - link "Brugerkonto":
    - /url: /VDIA/company/settings/instance/profile
- main:
  - heading "Hjem" [level=1]
  - button "Spørg Blentera"
  - paragraph: Der er ikke noget, der kræver din opmærksomhed lige nu.
```

# Test source

```ts
  1   | import { expect, test, type APIResponse } from "@playwright/test";
  2   | 
  3   | test.use({ trace: "retain-on-failure" });
  4   | 
  5   | async function json(response: APIResponse) {
  6   |   expect(response.ok(), `${response.status()}: ${await response.text()}`).toBe(
  7   |     true,
  8   |   );
  9   |   return response.json();
  10  | }
  11  | 
  12  | // This exercises the built UI and authenticated Native APIs on the disposable
  13  | // instance. It does not qualify hosted authentication or live business acceptance.
  14  | test("V9 Home, feedback recovery and rollback preserve native state", async ({
  15  |   page,
  16  |   request,
  17  | }) => {
  18  |   test.setTimeout(120_000);
  19  |   const original = await json(
  20  |     await request.get("/api/instance/settings/experimental"),
  21  |   );
  22  |   const session = await json(await request.get("/api/auth/get-session"));
  23  |   const expectedUserId = encodeURIComponent(session.user.id);
  24  |   const enabled = {
  25  |     experience_projection_v9: true,
  26  |     progressive_shell_v9: true,
  27  |     home_v9: true,
  28  |     customer_feedback_v9: true,
  29  |     ambient_commands_v9: true,
  30  |   };
  31  |   const errors: string[] = [];
  32  |   const requestedPageChunks: string[] = [];
  33  |   page.on("request", (request) => {
  34  |     const path = new URL(request.url()).pathname;
  35  |     if (
  36  |       /\/(?:CustomAgent|NewAgent|HireAgent|MyFeedback|FeedbackTriage|CustomerSupport|Activation|AgentMonitor|MaintenanceHistory)-[^/]+\.js$/.test(
  37  |         path,
  38  |       )
  39  |     )
  40  |       requestedPageChunks.push(path);
  41  |   });
  42  |   page.on("pageerror", (error) => errors.push(error.message));
  43  |   await json(
  44  |     await request.patch("/api/instance/settings/experimental", {
  45  |       data: enabled,
  46  |     }),
  47  |   );
  48  |   const company = await json(
  49  |     await request.post("/api/companies", {
  50  |       data: { name: "V9 disposable browser company" },
  51  |     }),
  52  |   );
  53  |   const base = `/api/companies/${company.id}`;
  54  |   const body =
  55  |     "Browser feedback: preserve my entered explanation after a network interruption.";
  56  |   try {
  57  |     await page.goto(`/${company.issuePrefix}/dashboard`);
  58  |     await expect(
  59  |       page.getByRole("heading", { name: "Home", exact: true }),
> 60  |     ).toBeVisible();
      |       ^ Error: expect(locator).toBeVisible() failed
  61  |     await expect(
  62  |       page.getByRole("heading", { name: "Home", exact: true }),
  63  |     ).toBeFocused();
  64  |     // The built Home entry must not fetch setup, triage or private history pages.
  65  |     // This checks real browser imports, not a mocked lazy component.
  66  |     expect(requestedPageChunks).toEqual([]);
  67  |     await expect(
  68  |       page.getByText("Nothing needs your attention right now.", {
  69  |         exact: true,
  70  |       }),
  71  |     ).toBeVisible();
  72  |     const projection = await json(
  73  |       await request.get(`${base}/experience?expectedUserId=${expectedUserId}`),
  74  |     );
  75  |     expect(projection.companyId).toBe(company.id);
  76  |     expect(projection.needsYou).toEqual([]);
  77  |     await page.goto(`/${company.issuePrefix}/needs-you`);
  78  |     await expect(
  79  |       page.getByRole("heading", { name: "Needs You", exact: true }),
  80  |     ).toBeVisible();
  81  |     await expect(
  82  |       page.getByRole("heading", { name: "Needs You", exact: true }),
  83  |     ).toBeFocused();
  84  |     await expect(
  85  |       page.getByText("Nothing needs your action in the current queue.", {
  86  |         exact: true,
  87  |       }),
  88  |     ).toBeVisible();
  89  |     await page
  90  |       .getByRole("link", { name: "Open full queue", exact: true })
  91  |       .click();
  92  |     await expect(page).toHaveURL(
  93  |       new RegExp(`/${company.issuePrefix}/decisions$`),
  94  |     );
  95  |     await page.goto(`/${company.issuePrefix}/work`);
  96  |     await expect(
  97  |       page.getByRole("heading", { name: "Work", exact: true }),
  98  |     ).toBeVisible();
  99  |     await expect(
  100 |       page.getByRole("heading", { name: "Work", exact: true }),
  101 |     ).toBeFocused();
  102 |     const workOwners = page.getByRole("navigation", {
  103 |       name: "Company work",
  104 |       exact: true,
  105 |     });
  106 |     for (const [label, path] of [
  107 |       ["Projects", "projects"],
  108 |       ["Tasks", "issues"],
  109 |       ["Routines", "routines"],
  110 |     ]) {
  111 |       await expect(
  112 |         workOwners.getByRole("link", { name: label, exact: true }),
  113 |       ).toHaveAttribute("href", `/${company.issuePrefix}/${path}`);
  114 |     }
  115 |     await expect(
  116 |       page.getByText(
  117 |         "No current tasks appear in this view. Open Tasks or Projects to review other work.",
  118 |         { exact: true },
  119 |       ),
  120 |     ).toBeVisible();
  121 |     await page.goto(`/${company.issuePrefix}/dashboard`);
  122 |     await expect(
  123 |       page.getByRole("heading", { name: "Home", exact: true }),
  124 |     ).toBeVisible();
  125 |     const homeEndpoint = `**/api/companies/${company.id}/experience?*`;
  126 |     await page.route(homeEndpoint, (route) =>
  127 |       route.fulfill({ status: 503, json: { error: "Temporary test outage" } }),
  128 |     );
  129 |     await page.reload();
  130 |     await expect(
  131 |       page.getByRole("alert").filter({ hasText: "Home could not be loaded" }),
  132 |     ).toBeVisible();
  133 |     await expect(
  134 |       page.getByRole("alert").filter({ hasText: "Home could not be loaded" }),
  135 |     ).toBeFocused();
  136 |     await expect(
  137 |       page.getByText("Nothing needs your attention right now.", {
  138 |         exact: true,
  139 |       }),
  140 |     ).toHaveCount(0);
  141 |     await page.unroute(homeEndpoint);
  142 |     await page.getByRole("button", { name: "Try again", exact: true }).click();
  143 |     await expect(
  144 |       page.getByRole("heading", { name: "Home", exact: true }),
  145 |     ).toBeVisible();
  146 |     await expect(
  147 |       page.getByRole("heading", { name: "Home", exact: true }),
  148 |     ).toBeFocused();
  149 |     const trigger = page
  150 |       .locator('[aria-label="Global utilities"]')
  151 |       .getByRole("button", { name: "Feedback", exact: true });
  152 |     const ask = page
  153 |       .locator('[aria-label="Global utilities"]')
  154 |       .getByRole("button", { name: "Ask August", exact: true });
  155 |     await ask.click();
  156 |     let commands = page.getByRole("dialog");
  157 |     await expect(
  158 |       commands.getByRole("combobox", { name: "Search or enter a command" }),
  159 |     ).toBeFocused();
  160 |     await commands
```