# Selection-cancellation legacy retirement map

Private, read-only comparison of only these two legacy cases:

- `heartbeat-process-recovery.test.ts`: “fences native selection when cancellation wins during preparation” (around line 2749).
- `heartbeat-process-recovery.test.ts`: “does not dispatch when cancellation wins after native selection” (around line 2835).

The candidate `retire-selection-cancellation-cases.patch` removes exactly those two `it` bodies. It leaves the legacy issue-before-run row-lock test between them untouched, along with every other recovery case. Root reported the installed-controller replacement’s before-selection, after-selection, and row-lock cases passed 3/3 in 36 seconds; that qualification is Root’s evidence, not a test run performed here.

## Fixture/lifecycle comparison

The legacy cases seed a queued run, set a mock Codex adapter, resume the queue, and use `nativeSessionBackendFactory` plus `mockAdapterExecute` spies. The pre-selection case cancels from `beforeNativeRuntimeSelection`. The post-selection case sets automation invocation, waits at `beforeChatControlRecoveryCheck(stage="dispatch")` until cancellation state is requested, then drains.

The replacement is the existing parameterized case `cancels a real installed-controller Run at %s without dispatching its model` in `heartbeat-dependency-draft-controller.integration.test.ts` (around line 1395). Its `before_selection` and `after_selection` parameters represent the two retirement candidates. It admits a real Task/Plan through `withInstalledDraftTransport`, observes the real Run lifecycle at the selection or dispatch hooks, and uses the actual controlled HTTP transport fetch counter. The separate `before_selection_row_lock` parameter and old standalone row-lock test are outside this retirement patch.

## Assertion mapping

| Legacy assertion/invariant | Replacement case coverage |
|---|---|
| Selection/cancellation hook reached | `selectionReached` and selected Run ID match the real wake ID in both phases. |
| Before-selection Run is still legacy, unresolved, and has no Native session | `beforeSelection` observes `runtimeMode:"legacy"`, `runtimeModeResolvedAt:null`, `nativeSessionId:null`; final state reasserts those fields. |
| Before-selection cancellation records `startupCancellation.beforeNativeSelection` and preparation settled | Final before-selection Run asserts that exact cancellation marker and `startupPreparationSettledAt`. |
| Before-selection run is cancelled; no native finalization coordinator exists | Final run status is cancelled and the coordinator query is empty for `before_selection`. |
| After-selection dispatch gate observes a Native Run | `beforeDispatch` requires Native mode and `nativeIssueId` for the selected Task; dispatch is expected only for `after_selection`. |
| Cancellation is requested while dispatch is held before provider work | Replacement starts `cancelRun`, observes the durable `startupCancellation.requestedAt`, asserts controlled HTTP call count remains zero, then releases/drains and requires clean cancellation. This uses the current startup-cancellation fence field rather than the legacy execution-cancellation state field. |
| After-selection run remains Native and settles cancelled with preparation marker | Final after-selection Run asserts cancelled/Native plus `startupPreparationSettledAt`. |
| After-selection Native resolution and session were persisted | The replacement requires `runtimeModeResolvedAt` to be a Date and `nativeSessionId` to be a string. |
| After-selection coordinator is present but has attempt 0 and no lease | Replacement asserts coordinator `runId`, Task `issueId`, `attempt:0`, and `leaseOwner:null`. |
| Task execution ownership is released and Task is not falsely completed | Replacement checks `executionRunId`, `executionAgentNameKey`, and `executionLockedAt` are null and status is not done. |
| Provider backend factory was never called | The existing installed-controller helper asserts its `nativeSessionBackendFactory` substitution was never called. The new cancellation case also requires controlled model HTTP fetch count `0`. |
| Legacy mock adapter execution was never called | The legacy-only `mockAdapterExecute` spy is not carried over. The replacement runs the installed Native software controller with a guarded fetch counter, requires zero model HTTP calls, and preserves the final runtime-mode selection assertions. This is an instrumentation/fixture change; it makes no claim about local adapter execution in other recovery cases. |
| Native profile/source receipt assertions | Neither retiring legacy case asserts `runnerProfileJson` source receipts. The replacement uses the installed, qualified controller/Plan fixture but these cancellation branches do not claim profile-source equality. That evidence belongs to the adjacent first-bootstrap source cases, not this retirement mapping. |
| No provider result or paid model output was produced | Replacement asserts no model reservations, no `nativeRunResults`, no result document, and zero fetch calls. |
| Wake request reaches cancelled terminal state | Replacement reads the actual `agentWakeupRequests` row and requires `status:"cancelled"` bound to the wake Run. |

No new PID, authority, or pricing claim is inferred from the retired cases. The replacement’s real Plan admission is part of the already-qualified installed-controller fixture; the patch does not alter admission, caps, or the row-lock case.

## Validation and application gate

- `git apply --check retire-selection-cancellation-cases.patch` passes against the unchanged legacy module at current HEAD.
- The patch hash is `ea9cf855f51cc2762a036901bbe1ff6ee97b92301874f934efe4e70830703b5f`.
- It deletes exactly two named legacy `it` cases and leaves the intervening row-lock test intact.
- This is a private candidate only. It has not been applied. No tests, PostgreSQL, or compiler checks were run for this comparison.
