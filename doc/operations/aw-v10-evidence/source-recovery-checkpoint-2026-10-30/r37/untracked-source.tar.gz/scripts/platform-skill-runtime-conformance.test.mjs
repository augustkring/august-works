import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { test } from "node:test";
import path from "node:path";
import { validateContract } from "./run-platform-skill-runtime-conformance.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

test("runtime conformance contract keeps profiles unqualified and exposes scenario coverage gaps", async () => {
  const contract = JSON.parse(await readFile(path.join(root, "evals/platform-skill/runtime-conformance.json"), "utf8"));
  validateContract(contract);
  const ids = contract.scenarios.map(({ id }) => id);
  assert.deepEqual(ids, ["pinned-positive-delivery", "missing-or-stale-pin", "reserved-name-collision", "isolated-profile-boundary", "safe-recovery-boundary"]);
  for (const profile of contract.profiles) {
    assert.match(profile.qualification, /unqualified|not-GA/i);
    assert.equal(profile.exactInstalledVersion, null);
  }
  const runnable = contract.profiles.filter(({ suites }) => suites.length > 0);
  assert.equal(runnable.length, 3);
  assert.ok(runnable.every(({ commonSuiteComplete }) => !commonSuiteComplete), "partial source suites must not be mislabeled as common-suite completion");
});

test("A2A/custom profile cannot advertise a source test driver that does not exist", async () => {
  const contract = JSON.parse(await readFile(path.join(root, "evals/platform-skill/runtime-conformance.json"), "utf8"));
  const profile = contract.profiles.find(({ id }) => id === "a2a-or-custom");
  profile.suites = [{ path: "missing.test.ts", config: "vitest.config.ts", selection: "case", scenarios: [] }];
  assert.throws(() => validateContract(contract), /cannot claim suites without a delivery driver/);
});
