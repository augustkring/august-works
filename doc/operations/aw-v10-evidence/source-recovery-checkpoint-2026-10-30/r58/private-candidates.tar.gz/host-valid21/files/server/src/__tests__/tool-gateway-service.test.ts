import { randomUUID } from "node:crypto";
import { readFileSync } from "node:fs";
import { nativeSha256 } from "../services/native-runtime/canonical.js";
import { workflowService } from "../services/workflows/workflow-service.js";
import { workflowExecutorService } from "../services/workflows/workflow-executor.js";
import { and, eq, sql } from "drizzle-orm";
import { afterAll, afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import { PRODUCT_IDENTITY } from "@paperclipai/shared";
import {
  activityLog,
  authUsers,
  agentWakeupRequests,
  toolActionDeliveries,
  agents,
  approvals,
  companies,
  companySkills,
  companySecretBindings,
  companySecrets,
  companyMemberships,
  toolConnectionInstalls,
  issueComments,
  connectionGrants,
  createDb,
  heartbeatRuns,
  issueApprovals,
  issues,
  projects,
  principalPermissionGrants,
  issueThreadInteractions,
  instanceSettings,
  toolApplications,
  toolCatalogEntries,
  toolConnections,
  toolAccessAuditEvents,
  toolActionRequests,
  toolCallEvents,
  toolGatewaySessions,
  toolInvocations,
  toolPolicies,
  toolRateLimitCounters,
  workflows,
  workflowRuns,
  workflowStepRuns,
  workflowWaits,
  supportCases,
  supportCaseEvents,
} from "@paperclipai/db";
import type { PluginToolDispatcher } from "../services/plugin-tool-dispatcher.js";
import type { VercelConnectClient } from "../services/vercel-connect.js";
import { initializeRunIdentity, reserveSteeredIdentity, reconcileSteeredIdentity } from "../services/run-identity.js";
import { issueService } from "../services/issues.js";
import { projectService } from "../services/projects.js";
import type { AuthorizationActor } from "../services/authorization.js";
import { createCanonicalHumanProject, seedCurrentHumanSourceActor } from "./helpers/current-human-source-fixture.js";
import { commitToolActionReview } from "../services/tool-action-review.js";
import { materializeNativeInteractionResponses } from "../services/native-runtime/native-interaction-bridge.js";
import { toolActionDeliveryService } from "../services/tool-action-delivery.js";
import { secretService } from "../services/secrets.js";
import { instanceSettingsService } from "../services/instance-settings.js";
import { preparePlatformSkillAdmission } from "../services/platform-skill-admission.js";
import { toolAccessService } from "../services/tool-access.js";
import {
  createToolGatewayService,
  blenteraPlatformContractHashes,
  ToolGatewayHttpError,
  type ScopedToolGatewayContext,
} from "../services/tool-gateway.js";
import { AGENT_NATIVE_EXISTING_API_OPERATION_MANIFEST, AGENT_NATIVE_OPERATION_MANIFEST, agentNativeOperationForToolName, blenteraToolCatalogContractHash } from "../services/agent-native-operation-manifest.js";
import { canonicalToolArguments, signToolArguments } from "../services/tool-content-guards.js";
import {
  getEmbeddedPostgresTestSupport,
  startEmbeddedPostgresTestDatabase,
} from "./helpers/embedded-postgres.js";

const embeddedPostgresSupport = await getEmbeddedPostgresTestSupport();
const describeEmbeddedPostgres = embeddedPostgresSupport.supported ? describe : describe.skip;
const testToolActionSigningSecret = "test-tool-action-signing-secret";
type ToolGatewayServiceOptions = NonNullable<Parameters<typeof createToolGatewayService>[1]>;

describe("Blentera platform contract hashes", () => {
  it("records existing Agent APIs without registering tools or MCP exposure", () => {
    expect(AGENT_NATIVE_EXISTING_API_OPERATION_MANIFEST.length).toBeGreaterThan(0);
    for (const operation of AGENT_NATIVE_EXISTING_API_OPERATION_MANIFEST) {
      expect(operation).toMatchObject({ toolId: null, legacyAliases: [], mcpExposed: false, apiOnly: true });
      expect(operation.apiOperation).toMatch(/^(GET|POST|PUT|PATCH|DELETE)\s+\S/);
      expect(operation.principalTypes).toContain("agent");
      expect(operation.authorityEvidence.length).toBeGreaterThan(0);
      expect(operation.materialityEvidence.length).toBeGreaterThan(0);
      expect(agentNativeOperationForToolName(operation.operationId)).toBeUndefined();
    }
  });

  it("exports stable operation and first-party tool catalog hashes", () => {
    const first = blenteraPlatformContractHashes();
    const second = blenteraPlatformContractHashes();
    expect(first).toEqual(second);
    expect(first.operationManifestHash).toMatch(/^[a-f0-9]{64}$/);
    expect(first.toolCatalogContractHash).toMatch(/^[a-f0-9]{64}$/);
    const releaseRegistry = JSON.parse(readFileSync(new URL("../../../skills-releases/blentera-platform/releases.json", import.meta.url), "utf8")) as Array<Record<string, unknown>>;
    expect(releaseRegistry.at(-1)).toMatchObject(first);
    const contract = {
      toolId: "blentera.task.list_assigned",
      operationId: "blentera.task.list_assigned",
      legacyAliases: ["paperclip-self:list_my_issues"],
      displayName: "List assigned Tasks",
      description: "List the current Co-worker's assigned Tasks.",
      inputSchema: { type: "object", additionalProperties: false },
      risk: "read",
    };
    expect(blenteraToolCatalogContractHash([contract])).not.toBe(
      blenteraToolCatalogContractHash([{ ...contract, displayName: "Changed display contract" }]),
    );
  });

  it("pins V1, V2, and V3 procedure-contract releases without repinning old Runs", () => {
    const releaseRegistry = JSON.parse(readFileSync(new URL("../../../skills-releases/blentera-platform/releases.json", import.meta.url), "utf8")) as Array<Record<string, unknown>>;
    expect(releaseRegistry.map(release => release.id)).toEqual(["v1", "v2", "v3"]);
    expect(releaseRegistry[0]).toMatchObject({
      operationManifestHash: "22c7ebc0014d5df6b5716751b41838d8a5c786515b35e86f019bae7023df3a69",
      toolCatalogContractHash: "5c9b1372bf12ad8b962b3249d2ce6e3679f33ba681f5cbc407d1459bee335825",
    });
    expect(releaseRegistry[1]).toMatchObject({
      operationManifestHash: "24b568c81d493c84218a55e8efdea6c9cce5b77b5107b5a1c62e7322fce198b8",
      toolCatalogContractHash: "5c9b1372bf12ad8b962b3249d2ce6e3679f33ba681f5cbc407d1459bee335825",
    });
    expect(releaseRegistry[2]).toMatchObject({
      id: "v3",
      supersedes: "v2",
      operationManifestHash: "52fe608c583066221d3cee9562cd2216e17abdb9d0860ba74d9b9adf33e50e20",
      toolCatalogContractHash: "5c9b1372bf12ad8b962b3249d2ce6e3679f33ba681f5cbc407d1459bee335825",
      sourceSha: releaseRegistry[1].sourceSha,
      contentDigest: releaseRegistry[1].contentDigest,
      files: releaseRegistry[1].files,
    });
    expect(blenteraPlatformContractHashes()).toMatchObject({
      operationManifestHash: releaseRegistry[2].operationManifestHash,
      toolCatalogContractHash: releaseRegistry[2].toolCatalogContractHash,
    });
  });

  it("keeps Task progress replay routed by its canonical manifest alias and owner", () => {
    expect(AGENT_NATIVE_OPERATION_MANIFEST.find(operation => operation.operationId === "blentera.task.comment.add"))
      .toMatchObject({ domain: "Work", canonicalService: "PaperclipRunnerToolAuthority.report_progress",
        legacyAliases: ["paperclip-self:report_progress"], mcpExposed: true });
  });

  it("classifies the required least-authority domain projections without claiming unqualified channels", () => {
    const domains = new Set(AGENT_NATIVE_OPERATION_MANIFEST.map(operation => operation.domain));
    for (const domain of ["Tasks", "Projects", "Work", "Agents", "Apps", "Insights", "Decisions", "Support"])
      expect([...domains]).toContain(domain);
    expect(AGENT_NATIVE_OPERATION_MANIFEST.find(operation => operation.operationId === "blentera.apps.list_authorized_tools"))
      .toMatchObject({ apiOperation: "MCP tools/list", openclawQualified: false, mcpExposed: true });
    expect(AGENT_NATIVE_OPERATION_MANIFEST.find(operation => operation.operationId === "blentera.support.case.request"))
      .toMatchObject({ mode: "PROPOSAL_ONLY", openclawQualified: false });
    expect(AGENT_NATIVE_OPERATION_MANIFEST.find(operation => operation.operationId === "blentera.support.case.manage"))
      .toMatchObject({ mode: "HUMAN_ONLY", mcpExposed: false });
    expect(AGENT_NATIVE_OPERATION_MANIFEST.find(operation => operation.operationId === "blentera.support.intake.status"))
      .toMatchObject({ toolId: "blentera.support.intake.status", canonicalService: "customerSupportCaseService.intakePolicyFromNative" });
    expect(AGENT_NATIVE_OPERATION_MANIFEST.find(operation => operation.operationId === "blentera.support.service.status"))
      .toMatchObject({ toolId: "blentera.support.service.status", canonicalService: "managedServiceHealth.read", mcpExposed: true });
  });
});

function createTestToolGatewayService(db: ReturnType<typeof createDb>, options: ToolGatewayServiceOptions = {}) {
  return createToolGatewayService(db, {
    ...options,
    toolActionSigningSecret: options.toolActionSigningSecret ?? testToolActionSigningSecret,
    remoteHttpRequest: options.remoteHttpRequest ?? (async (url, init) => fetch(url, init)),
  });
}

async function createRunFixture(db: ReturnType<typeof createDb>) {
  const company = await db.insert(companies).values({
    name: `Gateway ${randomUUID()}`,
    issuePrefix: `TG${randomUUID().slice(0, 6).toUpperCase()}`,
  }).returning().then((rows) => rows[0]!);
  const agent = await db.insert(agents).values({
    companyId: company.id,
    name: `Gateway Agent ${randomUUID()}`,
    role: "engineer",
    adapterType: "process",
    adapterConfig: {},
    runtimeConfig: {},
    permissions: {},
  }).returning().then((rows) => rows[0]!);
  const issue = await db.insert(issues).values({
    companyId: company.id,
    title: "Gateway approval work",
    status: "in_progress",
    assigneeAgentId: agent.id,
  }).returning().then((rows) => rows[0]!);
  const run = await db.insert(heartbeatRuns).values({
    companyId: company.id,
    agentId: agent.id,
    invocationSource: "assignment",
    status: "running",
    contextSnapshot: { issueId: issue.id },
  }).returning().then((rows) => rows[0]!);
  return { company, agent, issue, run };
}

async function createRemoteMcpToolFixture(db: ReturnType<typeof createDb>, companyId: string) {
  const application = await db.insert(toolApplications).values({
    companyId,
    applicationKey: `remote-${randomUUID().slice(0, 8)}`,
    name: "Remote MCP",
    type: "mcp_http",
    status: "active",
  }).returning().then((rows) => rows[0]!);
  const connection = await db.insert(toolConnections).values({
    companyId,
    applicationId: application.id,
    name: "Remote connection",
    uid: `test/${randomUUID()}`,
    transport: "mcp_remote",
    status: "active",
    enabled: true,
    healthStatus: "ok",
    // Use a public IP literal so protocol tests remain independent of DNS while
    // still exercising the production egress guard and their global fetch stub.
    credentialPolicy: "shared",
    config: { url: "https://8.8.8.8/mcp" },
  }).returning().then((rows) => rows[0]!);
  await db.insert(connectionGrants).values({
    companyId,
    connectionId: connection.id,
    kind: "organization",
    credentialSecretRefs: [],
    status: "active",
    isDefault: true,
  });
  const catalogEntry = await db.insert(toolCatalogEntries).values({
    companyId,
    applicationId: application.id,
    connectionId: connection.id,
    entryKind: "tool",
    name: "needs_input",
    toolName: "needs_input",
    title: "Needs input",
    riskLevel: "read",
    isReadOnly: true,
    status: "active",
    versionHash: randomUUID(),
    schemaHash: randomUUID(),
  }).returning().then((rows) => rows[0]!);
  return { application, connection, catalogEntry };
}

function fakePluginDispatcher(): PluginToolDispatcher {
  return {
    initialize: async () => {},
    teardown: () => {},
    listToolsForAgent: () => [
      {
        name: "fixture:delete_everything",
        displayName: "Delete everything",
        description: "Destructive fixture tool.",
        parametersSchema: { type: "object" },
        pluginId: "fixture-plugin",
      },
    ],
    getTool: () => null,
    executeTool: async (_name, parameters) => ({
      pluginId: "fixture-plugin",
      toolName: "delete_everything",
      result: { content: "deleted", data: parameters },
    }),
    registerPluginTools: () => {},
    unregisterPluginTools: () => {},
    toolCount: () => 1,
    getRegistry: () => {
      throw new Error("not implemented");
    },
  };
}

describeEmbeddedPostgres("tool gateway service", () => {
  let db!: ReturnType<typeof createDb>;
  let tempDb: Awaited<ReturnType<typeof startEmbeddedPostgresTestDatabase>> | null = null;

  beforeAll(async () => {
    tempDb = await startEmbeddedPostgresTestDatabase("paperclip-tool-gateway-");
    db = createDb(tempDb.connectionString);
  }, 20_000);

  afterEach(async () => {
    vi.unstubAllEnvs();
    await db.delete(activityLog);
    await db.delete(agentWakeupRequests);
    await db.delete(toolGatewaySessions);
    await db.delete(toolCallEvents);
    await db.delete(toolAccessAuditEvents);
    await db.delete(toolActionRequests);
    await db.delete(toolInvocations);
    await db.delete(issueApprovals);
    await db.delete(approvals);
    await db.delete(issueThreadInteractions);
    await db.delete(toolCatalogEntries);
    await db.delete(toolConnections);
    await db.delete(toolApplications);
    await db.delete(companySecrets);
    await db.delete(toolPolicies);
    await db.delete(principalPermissionGrants);
    await db.delete(instanceSettings);
    // Workflows own immutable revision history, including createdByRunId
    // provenance. Cascade revisions before deleting their source runs.
    await db.delete(workflows);
    await db.delete(heartbeatRuns);
    await db.delete(issues);
    await db.delete(projects);
    await db.delete(companyMemberships);
    await db.delete(companySkills);
    await db.delete(agents);
    await db.delete(supportCaseEvents);
    await db.delete(supportCases);
    await db.delete(companies);
  });

  afterAll(async () => {
    await tempDb?.cleanup();
  });

  it("executes a pinned connector through a workflow and denies catalogue drift before another provider call", async () => {
    const { company, agent, run, issue } = await createRunFixture(db);
    const userId = randomUUID();
    await db.insert(authUsers).values({ id: userId, name: "Workflow connector owner", email: `${userId}@example.test`,
      emailVerified: true, createdAt: new Date(), updatedAt: new Date() });
    await db.insert(companyMemberships).values([
      { companyId: company.id, principalType: "user", principalId: userId, membershipRole: "member", status: "active" },
      { companyId: company.id, principalType: "agent", principalId: agent.id, membershipRole: "member", status: "active" },
    ]);
    await db.update(heartbeatRuns).set({ responsibleUserId: userId }).where(eq(heartbeatRuns.id, run.id));
    await initializeRunIdentity(db, { companyId: company.id, runId: run.id, issueId: issue.id,
      responsibleUserId: userId, cause: "instruction" });
    const { connection, catalogEntry } = await createRemoteMcpToolFixture(db, company.id);
    await db.insert(toolPolicies).values({ companyId: company.id, name: "Allow workflow connector",
      policyType: "allow", selectors: { connectionId: connection.id } });
    let calls = 0;
    const provider = async (_url: string, init: RequestInit) => {
      const body = JSON.parse(String(init.body));
      if (body.method === "tools/call") calls++;
      return new Response(JSON.stringify({ jsonrpc: "2.0", id: body.id,
        result: { content: [{ type: "text", text: "reviewed connector output" }] } }),
        { headers: { "content-type": "application/json" } });
    };
    const gateway = createTestToolGatewayService(db, { remoteHttpRequest: provider });
    const actor = { principal: { type: "agent" as const, agentId: agent.id, responsibleUserId: userId },
      runId: run.id, responsibleUserId: userId };
    const svc = workflowService(db);
    const workflow = await svc.create(company.id, { name: "Pinned connector" }, actor);
    const draft = await svc.updateDraft(company.id, workflow.id, {
      expectedRevisionId: workflow.draftRevisionId!, graph: { version: 1, variables: [], settings: {},
        nodes: [{ id: "start", type: "core.manual_trigger", name: "Start", position: { x: 0, y: 0 }, config: {} },
          { id: "connector", type: "connector.action", name: "Read", position: { x: 100, y: 0 }, config: {
            toolCatalogEntryId: catalogEntry.id, connectionId: connection.id,
            catalogVersionHash: catalogEntry.versionHash, catalogSchemaHash: catalogEntry.schemaHash, projectedInputSchemaHash: nativeSha256(catalogEntry.inputSchema), input: {},
          } }], edges: [{ id: "e1", source: "start", target: "connector" }] },
    }, actor);
    await svc.publish(company.id, workflow.id, { expectedDraftRevisionId: draft.draftRevisionId!,
      expectedPublishedRevisionId: null, approvalId: null }, actor);
    const executor = workflowExecutorService(db, { toolGateway: gateway });
    const completed = await executor.startManualRun(company.id, workflow.id, { input: {} }, actor, "workflow-connector");
    expect(completed.run.status).toBe("succeeded");
    const step = completed.steps.find((item) => item.nodeId === "connector")!;
    expect(step).toMatchObject({ status: "succeeded", toolInvocationId: expect.any(String) });
    expect(calls).toBe(1);
    const [receipt] = await db.select().from(toolInvocations).where(eq(toolInvocations.id, step.toolInvocationId!));
    expect(receipt.workflowResultJson).toEqual(step.outputJson);
    // A changed effective input definition must be refused even when a catalog
    // producer accidentally retains its old version/schema metadata.
    await db.update(toolCatalogEntries).set({ inputSchema: { type: "object", properties: { changed: { type: "string" } } } }).where(eq(toolCatalogEntries.id, catalogEntry.id));
    const inputDrift = await executor.startManualRun(company.id, workflow.id, { input: {} }, actor, "workflow-connector-input-drift");
    expect(inputDrift.run).toMatchObject({ status: "failed", failureCode: "workflow_connector_drift" });
    expect(calls).toBe(1);
    await db.update(toolCatalogEntries).set({ inputSchema: catalogEntry.inputSchema }).where(eq(toolCatalogEntries.id, catalogEntry.id));
    await db.update(toolCatalogEntries).set({ versionHash: randomUUID() }).where(eq(toolCatalogEntries.id, catalogEntry.id));
    const denied = await executor.startManualRun(company.id, workflow.id, { input: {} }, actor, "workflow-connector-drift");
    expect(denied.run).toMatchObject({ status: "failed", failureCode: "workflow_connector_drift" });
    expect(calls).toBe(1);
  });

  it("parks a user workflow for signed tool review, recovers its receipt, and blocks late approval after cancellation", async () => {
    const { company } = await createRunFixture(db);
    const { connection, catalogEntry } = await createRemoteMcpToolFixture(db, company.id);
    await db.insert(authUsers).values(["workflow-owner", "reviewer"].map(id => ({ id, name: id,
      email: `${id}@example.test`, emailVerified: true, createdAt: new Date(), updatedAt: new Date() }))).onConflictDoNothing();
    await db.insert(companyMemberships).values([
      { companyId: company.id, principalType: "user", principalId: "workflow-owner", membershipRole: "owner", status: "active" },
      { companyId: company.id, principalType: "user", principalId: "reviewer", membershipRole: "admin", status: "active" },
    ]);
    await db.insert(toolPolicies).values({ companyId: company.id, name: "Review workflow connector",
      policyType: "require_approval", selectors: { connectionId: connection.id } });
    let calls = 0;
    const gateway = createTestToolGatewayService(db, { remoteHttpRequest: async (_url, init) => {
      const body = JSON.parse(String(init.body));
      if (body.method === "tools/call") calls++;
      return new Response(JSON.stringify({ jsonrpc: "2.0", id: body.id,
        result: { content: [{ type: "text", text: "approved user result" }] } }),
        { headers: { "content-type": "application/json" } });
    } });
    const actor = { principal: { type: "user" as const, userId: "workflow-owner" } };
    const svc = workflowService(db);
    const workflow = await svc.create(company.id, { name: "Reviewed connector" }, actor);
    const draft = await svc.updateDraft(company.id, workflow.id, {
      expectedRevisionId: workflow.draftRevisionId!, graph: { version: 1, variables: [], settings: {},
        nodes: [{ id: "start", type: "core.manual_trigger", name: "Start", position: { x: 0, y: 0 }, config: {} },
          { id: "connector", type: "connector.action", name: "Read", position: { x: 100, y: 0 }, config: {
            toolCatalogEntryId: catalogEntry.id, connectionId: connection.id,
            catalogVersionHash: catalogEntry.versionHash, catalogSchemaHash: catalogEntry.schemaHash, input: {},
          } }], edges: [{ id: "e1", source: "start", target: "connector" }] },
    }, actor);
    await svc.publish(company.id, workflow.id, { expectedDraftRevisionId: draft.draftRevisionId!,
      expectedPublishedRevisionId: null, approvalId: null }, actor);
    const executor = workflowExecutorService(db, { toolGateway: gateway });
    const waiting = await executor.startManualRun(company.id, workflow.id, { input: {} }, actor, "reviewed-workflow");
    expect(waiting.run.status).toBe("waiting");
    expect(waiting.waits).toMatchObject([{ kind: "tool_action", status: "active" }]);
    expect(calls).toBe(0);
    const [request] = await db.select().from(toolActionRequests);
    expect(request).toMatchObject({ issueId: null, interactionId: null, status: "pending", requestedByUserId: "workflow-owner" });
    // Recreate a worker crash after the signed request commits but before the
    // workflow wait commits. Recovery must bind that same pending request.
    await db.transaction(async (tx) => {
      await tx.delete(workflowWaits).where(eq(workflowWaits.workflowRunId, waiting.run.id));
      await tx.update(workflowStepRuns).set({ status: "running", toolInvocationId: null })
        .where(and(eq(workflowStepRuns.workflowRunId, waiting.run.id), eq(workflowStepRuns.nodeId, "connector")));
      await tx.update(workflowRuns).set({ status: "running", executionOwnerId: "crashed-worker",
        leaseExpiresAt: new Date(0), ownerHeartbeatAt: new Date(0) }).where(eq(workflowRuns.id, waiting.run.id));
    });
    const afterCrash = workflowExecutorService(db, { toolGateway: gateway });
    expect(await afterCrash.recoverExpiredRuns()).toMatchObject({ recovered: 1, failedRunIds: [] });
    expect((await afterCrash.getRun(company.id, waiting.run.id))?.waits)
      .toMatchObject([{ kind: "tool_action", status: "active", referenceId: request.invocationId }]);
    expect(await db.select().from(toolActionRequests)).toHaveLength(1);
    expect(calls).toBe(0);
    await gateway.approveActionRequest({ companyId: company.id, actionRequestId: request.id, actor: { userId: "reviewer" } });
    expect(calls).toBe(1);
    // A restarted executor consumes the stored receipt without invoking the provider.
    const restarted = workflowExecutorService(db, { toolGateway: gateway });
    expect(await restarted.recoverExpiredRuns()).toMatchObject({ recovered: 1, failedRunIds: [] });
    const completed = await restarted.getRun(company.id, waiting.run.id);
    expect(completed?.run.status).toBe("succeeded");
    const step = completed!.steps.find((item) => item.nodeId === "connector" && item.status === "succeeded")!;
    const [receipt] = await db.select().from(toolInvocations).where(eq(toolInvocations.id, request.invocationId));
    expect(receipt).toMatchObject({ actorType: "user", actorId: "workflow-owner", workflowRunId: waiting.run.id });
    expect(step.outputJson).toEqual(receipt.workflowResultJson);
    expect(receipt.workflowResultJson).not.toBeNull();
    await restarted.recoverExpiredRuns();
    expect(calls).toBe(1);
    const cancelled = await executor.startManualRun(company.id, workflow.id, { input: {} }, actor, "cancelled-review-workflow");
    expect(cancelled.run.status).toBe("waiting");
    const requests = await db.select().from(toolActionRequests);
    const pending = requests.find((item) => item.status === "pending")!;
    await executor.cancelRun(company.id, cancelled.run.id, { reason: "Operator cancelled" }, actor);
    await expect(gateway.approveActionRequest({ companyId: company.id, actionRequestId: pending.id,
      actor: { userId: "reviewer" } })).rejects.toMatchObject({ reasonCode: "action_not_pending" });
    expect(calls).toBe(1);
    const rejected = await executor.startManualRun(company.id, workflow.id, { input: {} }, actor, "rejected-review-workflow");
    const rejectedRequest = (await db.select().from(toolActionRequests)).find((item) => item.status === "pending")!;
    await gateway.declineActionRequest({ companyId: company.id, actionRequestId: rejectedRequest.id, actor: { userId: "reviewer" } });
    await restarted.recoverExpiredRuns();
    expect((await restarted.getRun(company.id, rejected.run.id))?.run).toMatchObject({ status: "failed", failureCode: "workflow_tool_review_declined" });
    const expired = await executor.startManualRun(company.id, workflow.id, { input: {} }, actor, "expired-review-workflow");
    await restarted.recoverExpiredRuns(20, new Date(Date.now() + 61 * 60_000));
    expect((await restarted.getRun(company.id, expired.run.id))?.run).toMatchObject({ status: "failed", failureCode: "workflow_tool_review_expired" });
    const revoked = await executor.startManualRun(company.id, workflow.id, { input: {} }, actor, "revoked-review-workflow");
    const revokedRequest = (await db.select().from(toolActionRequests)).find((item) => item.status === "pending")!;
    await db.update(companyMemberships).set({ status: "inactive" }).where(and(eq(companyMemberships.companyId, company.id), eq(companyMemberships.principalId, "workflow-owner")));
    await expect(gateway.approveActionRequest({ companyId: company.id, actionRequestId: revokedRequest.id,
      actor: { userId: "reviewer" } })).rejects.toMatchObject({ details: { code: "workflow_execution_principal_revoked" } });
    expect((await restarted.getRun(company.id, revoked.run.id))?.run.status).toBe("waiting");
    expect(calls).toBe(1);
  });

  it("exposes Memory self-tools only when the Memory feature gates are enabled", async () => {
    const { company, agent, run } = await createRunFixture(db);
    for (const toolName of [
      "paperclip-self:recall",
      "paperclip-self:remember",
      "paperclip-self:correct_memory",
      "paperclip-self:share_memory",
    ]) {
      await db.insert(toolPolicies).values({
        companyId: company.id,
        name: `Allow ${toolName}`,
        policyType: "allow",
        selectors: { toolName },
      });
    }

    const gateway = createTestToolGatewayService(db);
    const session = await gateway.createSession({
      companyId: company.id,
      agentId: agent.id,
      runId: run.id,
    });

    const disabledNames = (await gateway.listToolsForSession(session.token))
      .map((tool) => tool.name);
    expect(disabledNames).not.toContain("blentera.memory.recall");
    expect(disabledNames).not.toContain("blentera.memory.remember");
    expect(disabledNames).not.toContain("blentera.memory.correct");
    expect(disabledNames).not.toContain("blentera.memory.share");
    expect(disabledNames).not.toContain("paperclip-self:recall");

    const enabledMemoryExperimental = {
      enableCollectiveMemoryV1: true,
      enablePrivateAgentMemoryV1: true,
    };
    await db
      .insert(instanceSettings)
      .values({
        singletonKey: "default",
        general: {},
        experimental: enabledMemoryExperimental,
      })
      .onConflictDoUpdate({
        target: [instanceSettings.singletonKey],
        set: { experimental: enabledMemoryExperimental },
      });

    const enabledNames = (await gateway.listToolsForSession(session.token))
      .map((tool) => tool.name);
    expect(enabledNames).toEqual(
      expect.arrayContaining([
        "blentera.memory.recall",
        "blentera.memory.remember",
        "blentera.memory.correct",
        "blentera.memory.share",
      ]),
    );
    const remember = (await gateway.listToolsForSession(session.token))
      .find((tool) => tool.name === "blentera.memory.remember");
    expect(remember).toMatchObject({
      displayName: "Submit a Memory candidate from the current work",
      description: "Submit a Memory candidate from the current work.",
      providerType: "paperclip_self",
      risk: "write",
    });
    expect(remember?.parametersSchema).toMatchObject({ type: "object" });
    expect(remember?.description).not.toMatch(/Paperclip/i);
  });

  it("exposes AI workflow authoring tools only behind the full authoring feature gate", async () => {
    const { company, agent, run } = await createRunFixture(db);
    const authoringToolNames = [
      "paperclip-self:create_workflow",
      "paperclip-self:add_trigger",
      "paperclip-self:add_step",
      "paperclip-self:update_step",
      "paperclip-self:connect_steps",
      "paperclip-self:remove_step",
      "paperclip-self:test_step",
      "paperclip-self:publish_workflow",
    ];
    for (const toolName of authoringToolNames) {
      await db.insert(toolPolicies).values({
        companyId: company.id,
        name: `Allow ${toolName}`,
        policyType: "allow",
        selectors: { toolName },
      });
    }

    const gateway = createTestToolGatewayService(db);
    const session = await gateway.createSession({
      companyId: company.id,
      agentId: agent.id,
      runId: run.id,
    });

    const disabledNames = (await gateway.listToolsForSession(session.token))
      .map((tool) => tool.name);
    for (const toolName of authoringToolNames) {
      expect(disabledNames).not.toContain(toolName);
    }

    await instanceSettingsService(db).updateExperimental({
      enableWorkflowsV1: true,
      enableWorkflowBuilderV1: true,
      enableAiWorkflowAuthoring: true,
    });

    const enabledNames = (await gateway.listToolsForSession(session.token))
      .map((tool) => tool.name);
    expect(enabledNames).toEqual(expect.arrayContaining([
      "blentera.workflow.draft.create",
      "blentera.workflow.trigger.add",
      "blentera.workflow.step.add",
      "blentera.workflow.step.update",
      "blentera.workflow.steps.connect",
      "blentera.workflow.step.remove",
      "blentera.workflow.step.test",
      "blentera.workflow.publish.prepare",
    ]));
  });

  it("does not let a plugin shadow a reserved first-party name while its feature gate is closed", async () => {
    const { company, agent, run } = await createRunFixture(db);
    let pluginCalls = 0;
    const pluginDispatcher = fakePluginDispatcher();
    pluginDispatcher.listToolsForAgent = () => [{
      name: "blentera.workflow.draft.create",
      displayName: "Plugin replacement",
      description: "Conflicting plugin fixture.",
      parametersSchema: { type: "object", properties: {}, additionalProperties: false },
      pluginId: "fixture-plugin",
    }];
    pluginDispatcher.executeTool = async () => {
      pluginCalls += 1;
      return { pluginId: "fixture-plugin", toolName: "workflow.draft.create", result: { created: true } };
    };
    const gateway = createTestToolGatewayService(db, { pluginToolDispatcher: pluginDispatcher });
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id });

    await expect(gateway.executeTool({
      sessionToken: session.token,
      tool: "blentera.workflow.draft.create",
      parameters: { name: "Plugin shadow attempt", idempotencyKey: "shadow" },
    })).rejects.toMatchObject({ status: 404, reasonCode: "tool_not_found" });
    expect(pluginCalls).toBe(0);
  });

  it("routes an MCP Task comment through the current Native owner and binds its honest transport identity", async () => {
    const { company, agent, issue, run } = await createRunFixture(db);
    const userId = `gateway-task-human-${randomUUID()}`;
    await seedCurrentHumanSourceActor(db, [company.id], userId);
    await db.insert(companyMemberships).values({ companyId: company.id, principalType: "agent", principalId: agent.id,
      status: "active", membershipRole: "member" });
    await db.update(heartbeatRuns).set({ responsibleUserId: userId, runtimeMode: "native", nativeIssueId: issue.id })
      .where(eq(heartbeatRuns.id, run.id));
    await db.update(issues).set({ executionRunId: run.id }).where(eq(issues.id, issue.id));
    await preparePlatformSkillAdmission(db, { companyId: company.id, agentId: agent.id, runId: run.id,
      responsibleUserId: userId, requireExisting: false }, blenteraPlatformContractHashes());
    const humanMembership = await db.select().from(companyMemberships).where(and(
      eq(companyMemberships.companyId, company.id), eq(companyMemberships.principalType, "user"),
      eq(companyMemberships.principalId, userId), eq(companyMemberships.status, "active"),
    )).then(rows => rows[0]!);
    const actor: AuthorizationActor = { type: "agent", source: "agent_jwt", companyId: company.id, agentId: agent.id,
      runId: run.id, onBehalfOfUserId: userId, authenticatedCredentialExpiresAt: Date.now() + 60_000,
      keyScope: { kind: "standard" }, companyIds: [company.id],
      memberships: [{ companyId: company.id, membershipRole: "member", status: "active" }],
      onBehalfOfMemberships: [{ companyId: humanMembership.companyId, membershipRole: humanMembership.membershipRole,
        status: humanMembership.status }] };
    await db.insert(toolPolicies).values({ companyId: company.id, name: "Allow internal Task comment",
      policyType: "allow", selectors: { toolName: "paperclip-self:report_progress" } });
    const gateway = createTestToolGatewayService(db);
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id,
      issueId: issue.id, authorizationActor: actor });
    expect((await gateway.listToolsForSession(session.token)).map(tool => tool.name))
      .toContain("blentera.task.comment.add");

    const parameters = { idempotencyKey: randomUUID(), body: "Internal progress update." };
    const result = await gateway.executeTool({ sessionToken: session.token, tool: "blentera.task.comment.add", parameters });
    expect(result.status).toBe("completed");
    const replay = await gateway.executeTool({ sessionToken: session.token, tool: "blentera.task.comment.add", parameters });
    expect(replay.status).toBe("replayed");
    const [comment] = await db.select().from(issueComments).where(eq(issueComments.issueId, issue.id));
    expect(await db.select().from(issueComments).where(eq(issueComments.issueId, issue.id))).toHaveLength(1);
    expect(comment).toMatchObject({ authorAgentId: agent.id, createdByRunId: run.id,
      metadata: expect.objectContaining({ authorizationReason: "tool_gateway_mcp" }) });
    await db.insert(toolPolicies).values({ companyId: company.id, name: "Block this Task comment on replay",
      policyType: "block", priority: 1, selectors: { toolName: "paperclip-self:report_progress" },
      conditions: { arguments: { fieldEquals: { body: parameters.body } } } });
    await expect(gateway.executeTool({ sessionToken: session.token, tool: "blentera.task.comment.add", parameters }))
      .rejects.toMatchObject({ status: 403 });
    expect(await db.select().from(issueComments).where(eq(issueComments.issueId, issue.id))).toHaveLength(1);
    const [currentRun] = await db.select().from(heartbeatRuns).where(eq(heartbeatRuns.id, run.id));
    const receipts = currentRun.resultJson?.semanticToolReceipts as Record<string, { transport?: { channel: string; callId: string } }>;
    expect(Object.values(receipts)).toEqual(expect.arrayContaining([
      expect.objectContaining({ transport: { channel: "tool_gateway_mcp", callId: result.invocationId } }),
    ]));

    await db.insert(toolPolicies).values({ companyId: company.id, name: "Allow exact-version Task field updates",
      policyType: "allow", selectors: { toolName: "paperclip-self:update_task" } });
    expect((await gateway.listToolsForSession(session.token)).map(tool => tool.name))
      .toContain("blentera.task.update");
    const [taskBeforeUpdate] = await db.select().from(issues).where(eq(issues.id, issue.id));
    const updateParameters = { idempotencyKey: randomUUID(), expectedUpdatedAt: taskBeforeUpdate.updatedAt.toISOString(),
      title: "Updated through current Task owner" };
    const updated = await gateway.executeTool({ sessionToken: session.token, tool: "blentera.task.update",
      parameters: updateParameters });
    expect(updated.status).toBe("completed");
    const updateReplay = await gateway.executeTool({ sessionToken: session.token, tool: "blentera.task.update",
      parameters: updateParameters });
    expect(updateReplay.status).toBe("replayed");
    const [taskAfterUpdate] = await db.select().from(issues).where(eq(issues.id, issue.id));
    expect(taskAfterUpdate).toMatchObject({ title: updateParameters.title, status: taskBeforeUpdate.status,
      assigneeAgentId: taskBeforeUpdate.assigneeAgentId, assigneeUserId: taskBeforeUpdate.assigneeUserId });
    await expect(gateway.executeTool({ sessionToken: session.token, tool: "blentera.task.update", parameters: {
      ...updateParameters, idempotencyKey: randomUUID(), title: "Stale update must not apply",
    } })).rejects.toMatchObject({ status: 409 });

    await db.insert(toolPolicies).values({ companyId: company.id, name: "Allow Task completion proposals",
      policyType: "allow", selectors: { toolName: "paperclip-self:propose_completion" } });
    expect((await gateway.listToolsForSession(session.token)).map(tool => tool.name))
      .toContain("blentera.task.completion.propose");
    const proposalParameters = { idempotencyKey: randomUUID(), expectedUpdatedAt: taskAfterUpdate.updatedAt.toISOString(),
      summary: "The requested work and current Task evidence are ready for Human review." };
    const proposal = await gateway.executeTool({ sessionToken: session.token,
      tool: "blentera.task.completion.propose", parameters: proposalParameters });
    expect(proposal.status).toBe("completed");
    expect(proposal.result).toMatchObject({ data: { proposalStatus: "pending_human_review", currentTaskStatus: "in_progress",
      taskStatusCommitted: false, evidenceRequirement: expect.stringContaining("finalizer") } });
    const proposalReplay = await gateway.executeTool({ sessionToken: session.token,
      tool: "blentera.task.completion.propose", parameters: proposalParameters });
    expect(proposalReplay.status).toBe("replayed");
    const [reviewRequest] = await db.select().from(issueThreadInteractions).where(eq(issueThreadInteractions.issueId, issue.id));
    expect(reviewRequest).toMatchObject({ status: "pending", requestedResolverPolicy: "human_only",
      effectiveResolverPolicy: "human_only", resolverPolicyProvenance: "explicit", sourceRunId: run.id,
      kind: "request_confirmation" });
    expect(await db.select().from(issueThreadInteractions).where(eq(issueThreadInteractions.issueId, issue.id))).toHaveLength(1);
    const [taskAfterProposal] = await db.select().from(issues).where(eq(issues.id, issue.id));
    expect(taskAfterProposal).toMatchObject({ status: taskAfterUpdate.status,
      statusVersion: taskAfterUpdate.statusVersion, assigneeAgentId: taskAfterUpdate.assigneeAgentId });
    await expect(gateway.executeTool({ sessionToken: session.token, tool: "blentera.task.completion.propose", parameters: {
      ...proposalParameters, idempotencyKey: randomUUID(), expectedUpdatedAt: taskBeforeUpdate.updatedAt.toISOString(),
    } })).rejects.toMatchObject({ status: 409 });

    await db.update(heartbeatRuns).set({ runnerProfileJson: sql`${heartbeatRuns.runnerProfileJson} - 'platformSkillAdmission'` })
      .where(eq(heartbeatRuns.id, run.id));
    await expect(gateway.executeTool({ sessionToken: session.token, tool: "blentera.task.update", parameters: {
      idempotencyKey: randomUUID(), expectedUpdatedAt: taskAfterUpdate.updatedAt.toISOString(), title: "Unpinned write must not apply",
    } })).rejects.toMatchObject({ status: 409, details: { code: "platform_skill_readmission_required" } });

    await preparePlatformSkillAdmission(db, { companyId: company.id, agentId: agent.id, runId: run.id,
      responsibleUserId: userId, requireExisting: false }, blenteraPlatformContractHashes());
    await db.update(companyMemberships).set({ status: "inactive" }).where(and(
      eq(companyMemberships.companyId, company.id), eq(companyMemberships.principalType, "user"),
      eq(companyMemberships.principalId, userId),
    ));
    await expect(gateway.executeTool({ sessionToken: session.token, tool: "blentera.task.comment.add", parameters }))
      .rejects.toMatchObject({ status: 403 });
  });

  it("projects only current readable Projects through the canonical service and Human intersection", async () => {
    const { company, agent, run } = await createRunFixture(db);
    const userId = `gateway-project-human-${randomUUID()}`;
    const humanActor = await seedCurrentHumanSourceActor(db, [company.id], userId);
    await db.update(heartbeatRuns).set({ responsibleUserId: userId }).where(eq(heartbeatRuns.id, run.id));
    await db.insert(companyMemberships).values({
      companyId: company.id,
      principalType: "agent",
      principalId: agent.id,
      status: "active",
      membershipRole: "member",
    });
    const humanMembership = await db.select().from(companyMemberships).where(and(
      eq(companyMemberships.companyId, company.id), eq(companyMemberships.principalType, "user"),
      eq(companyMemberships.principalId, userId), eq(companyMemberships.status, "active"),
    )).then(rows => rows[0]!);
    const verifiedAgentActor: AuthorizationActor = {
      type: "agent", source: "agent_jwt", companyId: company.id, agentId: agent.id, runId: run.id,
      onBehalfOfUserId: userId, authenticatedCredentialExpiresAt: Date.now() + 60_000,
      keyScope: { kind: "standard" }, companyIds: [company.id],
      memberships: [{ companyId: company.id, membershipRole: "member", status: "active" }],
      onBehalfOfMemberships: [{ companyId: humanMembership.companyId,
        membershipRole: humanMembership.membershipRole, status: humanMembership.status }],
    };
    const visible = await createCanonicalHumanProject(db, company.id, humanActor, "Gateway-visible project", {
      description: "Current company project summary.",
    });
    await createRemoteMcpToolFixture(db, company.id);
    const otherCompany = await db.insert(companies).values({
      name: `Gateway other ${randomUUID()}`,
      issuePrefix: `GO${randomUUID().slice(0, 6).toUpperCase()}`,
    }).returning().then(rows => rows[0]!);
    const otherOwner = await seedCurrentHumanSourceActor(db, [otherCompany.id], `gateway-project-other-${randomUUID()}`);
    const outsideTenant = await createCanonicalHumanProject(db, otherCompany.id, otherOwner, "Other company project");
    await db.insert(toolPolicies).values([
      { companyId: company.id, name: "Allow Project list for fixture", policyType: "allow",
        selectors: { toolName: "paperclip-self:list_projects" } },
      { companyId: company.id, name: "Allow Project context for fixture", policyType: "allow",
        selectors: { toolName: "paperclip-self:get_project_context" } },
      { companyId: company.id, name: "Allow Agent context for fixture", policyType: "allow",
        selectors: { toolName: "paperclip-self:get_my_agent_context" } },
      { companyId: company.id, name: "Allow current Work for fixture", policyType: "allow",
        selectors: { toolName: "paperclip-self:get_my_current_work" } },
      { companyId: company.id, name: "Allow available App tools for fixture", policyType: "allow",
        selectors: { riskLevel: "read" } },
    ]);
    const gateway = createTestToolGatewayService(db);
    const session = await gateway.createSession({
      companyId: company.id,
      agentId: agent.id,
      runId: run.id,
      authorizationActor: verifiedAgentActor,
    });

    const listed = await gateway.executeTool({
      sessionToken: session.token,
      tool: "blentera.project.list",
      parameters: { limit: 10 },
    });
    expect(listed.status).toBe("completed");
    expect(listed.result).toMatchObject({ data: { projects: [expect.objectContaining({ id: visible.id, name: "Gateway-visible project" })] } });
    expect(JSON.stringify(listed.result)).not.toContain(outsideTenant.id);

    const detail = await gateway.executeTool({
      sessionToken: session.token,
      tool: "blentera.project.get_context",
      parameters: { projectId: visible.id },
    });
    expect(detail.result).toMatchObject({ data: { id: visible.id, name: "Gateway-visible project" } });
    await expect(gateway.executeTool({
      sessionToken: session.token,
      tool: "blentera.project.get_context",
      parameters: { projectId: outsideTenant.id },
    })).rejects.toMatchObject({ status: 404, reasonCode: "project_not_found" });

    const self = await gateway.executeTool({
      sessionToken: session.token,
      tool: "blentera.agent.get_self_context",
      parameters: {},
    });
    expect(self.result).toMatchObject({ data: { agent: { id: agent.id }, run: { id: run.id, status: "running" } } });
    expect(JSON.stringify(self.result)).not.toContain("adapterConfig");
    const work = await gateway.executeTool({
      sessionToken: session.token,
      tool: "blentera.work.get_current_task",
      parameters: {},
    });
    expect(work.result).toMatchObject({ data: { issue: { id: session.issueId }, run: { id: run.id, status: "running" } } });
    const apps = await gateway.executeTool({ sessionToken: session.token, tool: "blentera.apps.list_authorized_tools", parameters: {} });
    expect(apps.result).toMatchObject({ data: { applications: [expect.objectContaining({
      application: "Remote MCP", connection: "Remote connection", status: "active", enabled: true,
      availableOperations: [expect.any(String)],
    })] } });
    expect(JSON.stringify(apps.result)).not.toMatch(/credentialSecretRefs|transportConfig|authToken|password/i);
  });

  it("creates an idempotent local Support request under the current Native Human and approved safe context", async () => {
    const { company, agent, issue, run } = await createRunFixture(db);
    const userId = `gateway-support-human-${randomUUID()}`;
    await seedCurrentHumanSourceActor(db, [company.id], userId);
    await db.insert(companyMemberships).values({ companyId: company.id, principalType: "agent", principalId: agent.id,
      status: "active", membershipRole: "member" });
    await db.update(heartbeatRuns).set({ responsibleUserId: userId, runtimeMode: "native", nativeIssueId: issue.id })
      .where(eq(heartbeatRuns.id, run.id));
    await preparePlatformSkillAdmission(db, { companyId: company.id, agentId: agent.id, runId: run.id,
      responsibleUserId: userId, requireExisting: false }, blenteraPlatformContractHashes());
    const humanMembership = await db.select().from(companyMemberships).where(and(
      eq(companyMemberships.companyId, company.id), eq(companyMemberships.principalType, "user"),
      eq(companyMemberships.principalId, userId), eq(companyMemberships.status, "active"),
    )).then(rows => rows[0]!);
    const actor: AuthorizationActor = { type: "agent", source: "agent_jwt", companyId: company.id, agentId: agent.id,
      runId: run.id, onBehalfOfUserId: userId, authenticatedCredentialExpiresAt: Date.now() + 60_000,
      companyIds: [company.id],
      memberships: [{ companyId: company.id, membershipRole: "member", status: "active" }],
      onBehalfOfMemberships: [{ companyId: humanMembership.companyId, membershipRole: humanMembership.membershipRole, status: humanMembership.status }] };
    const supportCaseDataPolicy = { schemaVersion: 1 as const, policyVersion: "gateway.support.v1", recipientName: "Blentera Support",
      privacyNoticeUrl: "https://support.example.test/privacy", processingRegion: "test", retentionTrigger: "after_last_customer_or_support_message" as const,
      retentionDays: 30, backupMaxDays: 7, restoreLagDays: 2, deletionMarkerDays: 10, legalHoldPolicyId: "gateway.support.hold.v1" };
    await db.insert(toolPolicies).values({ companyId: company.id, name: "Allow Support request fixture", policyType: "allow",
      selectors: { toolName: "paperclip-self:create_support_request" } });
    await db.insert(toolPolicies).values({ companyId: company.id, name: "Allow Support intake status fixture", policyType: "allow",
      selectors: { toolName: "paperclip-self:get_support_intake_status" } });
    const gateway = createTestToolGatewayService(db, { supportCaseDataPolicy });
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id, authorizationActor: actor });
    expect((await gateway.listToolsForSession(session.token)).map(tool => tool.name)).toEqual(expect.arrayContaining([
      "blentera.support.intake.status", "blentera.support.case.request",
    ]));
    const intake = await gateway.executeTool({ sessionToken: session.token, tool: "blentera.support.intake.status", parameters: {} });
    expect(intake.result).toMatchObject({ data: { available: true, recipientName: "Blentera Support", retentionDays: 30 } });
    const requestKey = randomUUID();
    const parameters = { idempotencyKey: requestKey, expectedPolicyRevision: (intake.result as { data: { revision: string } }).data.revision,
      description: "I could not open the current Task.", category: "access", safeContext: { surface: "work", errorCode: "ACCESS_CHANGED" } };
    const first = await gateway.executeTool({ sessionToken: session.token, tool: "blentera.support.case.request", parameters });
    expect(first.status).toBe("completed");
    expect(first.result).toMatchObject({ data: { openedByUserId: userId, status: "RECEIVED", delivery: "pending" } });
    const replay = await gateway.executeTool({ sessionToken: session.token, tool: "blentera.support.case.request", parameters });
    expect(replay.status).toBe("replayed");
    await expect(gateway.executeTool({ sessionToken: session.token, tool: "blentera.support.case.request",
      parameters: { ...parameters, description: "Different text under the same request key." } })).rejects.toMatchObject({ status: 409 });
    expect(await db.select().from(supportCases)).toHaveLength(1);
    expect(await db.select().from(supportCaseEvents)).toHaveLength(1);
    const [activity] = await db.select().from(activityLog).where(eq(activityLog.action, "support.case_requested"));
    expect(activity).toMatchObject({ actorType: "agent", actorId: agent.id, agentId: agent.id, runId: run.id });
  });

  it("reads public service status separately from Support intake under current run, Human, policy, and Skill pins", async () => {
    const { company, agent, issue, run } = await createRunFixture(db);
    const userId = `gateway-service-status-human-${randomUUID()}`;
    await seedCurrentHumanSourceActor(db, [company.id], userId);
    await db.insert(companyMemberships).values({ companyId: company.id, principalType: "agent", principalId: agent.id,
      status: "active", membershipRole: "member" });
    await db.update(heartbeatRuns).set({ responsibleUserId: userId, runtimeMode: "native", nativeIssueId: issue.id })
      .where(eq(heartbeatRuns.id, run.id));
    const humanMembership = await db.select().from(companyMemberships).where(and(
      eq(companyMemberships.companyId, company.id), eq(companyMemberships.principalType, "user"),
      eq(companyMemberships.principalId, userId), eq(companyMemberships.status, "active"),
    )).then(rows => rows[0]!);
    const actor: AuthorizationActor = { type: "agent", source: "agent_jwt", companyId: company.id, agentId: agent.id,
      runId: run.id, onBehalfOfUserId: userId, authenticatedCredentialExpiresAt: Date.now() + 60_000,
      keyScope: { kind: "standard" }, companyIds: [company.id],
      memberships: [{ companyId: company.id, membershipRole: "member", status: "active" }],
      onBehalfOfMemberships: [{ companyId: humanMembership.companyId, membershipRole: humanMembership.membershipRole,
        status: humanMembership.status }] };
    await preparePlatformSkillAdmission(db, { companyId: company.id, agentId: agent.id, runId: run.id,
      responsibleUserId: userId, requireExisting: false }, blenteraPlatformContractHashes());
    await db.insert(toolPolicies).values({ companyId: company.id, name: "Allow public service status",
      policyType: "allow", selectors: { toolName: "paperclip-self:get_service_status" } });
    const projection = { state: "current" as const, statusUrl: PRODUCT_IDENTITY.statusOrigin, source: "statuspage_public_v2" as const,
      customerImpact: "unknown" as const,
      observedAt: new Date().toISOString(), providerUpdatedAt: new Date().toISOString(), indicator: "minor" as const,
      components: [{ id: "app", name: "Blentera app" as const, status: "degraded_performance" as const }],
      incidents: [], scheduledMaintenance: [] };
    const read = vi.fn(async () => projection);
    const gateway = createTestToolGatewayService(db, { serviceHealthReader: { read } });
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id,
      issueId: issue.id, authorizationActor: actor });
    expect((await gateway.listToolsForSession(session.token)).map(tool => tool.name))
      .toContain("blentera.support.service.status");
    const result = await gateway.executeTool({ sessionToken: session.token, tool: "blentera.support.service.status", parameters: {} });
    expect(result.result).toMatchObject({ data: projection });
    expect(JSON.stringify(result.result)).not.toMatch(/credential|password|supportCase|caseId/i);
    expect(read).toHaveBeenCalledOnce();

    await db.update(heartbeatRuns).set({ runnerProfileJson: sql`${heartbeatRuns.runnerProfileJson} - 'platformSkillAdmission'` })
      .where(eq(heartbeatRuns.id, run.id));
    await expect(gateway.executeTool({ sessionToken: session.token, tool: "blentera.support.service.status", parameters: {} }))
      .rejects.toMatchObject({ status: 409, details: { code: "platform_skill_readmission_required" } });
    expect(read).toHaveBeenCalledOnce();
    await db.update(companyMemberships).set({ status: "suspended" }).where(and(
      eq(companyMemberships.companyId, company.id), eq(companyMemberships.principalType, "user"),
      eq(companyMemberships.principalId, userId),
    ));
    await expect(gateway.executeTool({ sessionToken: session.token, tool: "blentera.support.service.status", parameters: {} }))
      .rejects.toMatchObject({ status: 403 });
    expect(read).toHaveBeenCalledOnce();
  });

  it("executes create_workflow through the governed gateway without publishing", async () => {
    const { company, agent, run } = await createRunFixture(db);
    const issue = await db.select().from(issues).where(eq(issues.companyId, company.id)).then(rows => rows[0]!);
    const userId = `gateway-workflow-human-${randomUUID()}`;
    await seedCurrentHumanSourceActor(db, [company.id], userId);
    await db.update(heartbeatRuns).set({ responsibleUserId: userId, runtimeMode: "native", nativeIssueId: issue.id })
      .where(eq(heartbeatRuns.id, run.id));
    await db.update(issues).set({ executionRunId: run.id }).where(eq(issues.id, issue.id));
    await db.insert(companyMemberships).values({
      companyId: company.id,
      principalType: "agent",
      principalId: agent.id,
      status: "active",
      membershipRole: "member",
    });
    await db.insert(principalPermissionGrants).values({
      companyId: company.id,
      principalType: "agent",
      principalId: agent.id,
      permissionKey: "workflows:edit",
      scope: null,
    });
    const humanMembership = await db.select().from(companyMemberships).where(and(
      eq(companyMemberships.companyId, company.id), eq(companyMemberships.principalType, "user"),
      eq(companyMemberships.principalId, userId), eq(companyMemberships.status, "active"),
    )).then(rows => rows[0]!);
    const actor: AuthorizationActor = {
      type: "agent", source: "agent_jwt", companyId: company.id, agentId: agent.id, runId: run.id,
      onBehalfOfUserId: userId, authenticatedCredentialExpiresAt: Date.now() + 60_000,
      companyIds: [company.id], memberships: [{ companyId: company.id, membershipRole: "member", status: "active" }],
      onBehalfOfMemberships: [{ companyId: humanMembership.companyId,
        membershipRole: humanMembership.membershipRole, status: humanMembership.status }],
    };
    await preparePlatformSkillAdmission(db, { companyId: company.id, agentId: agent.id, runId: run.id,
      responsibleUserId: userId, requireExisting: false }, blenteraPlatformContractHashes());
    await db.insert(toolPolicies).values({
      companyId: company.id,
      name: "Allow workflow draft creation",
      policyType: "allow",
      selectors: { toolName: "paperclip-self:create_workflow" },
    });
    await instanceSettingsService(db).updateExperimental({
      enableWorkflowsV1: true,
      enableWorkflowBuilderV1: true,
      enableAiWorkflowAuthoring: true,
    });

    const gateway = createTestToolGatewayService(db);
    const session = await gateway.createSession({
      companyId: company.id,
      agentId: agent.id,
      runId: run.id,
      issueId: issue.id,
      authorizationActor: actor,
    });
    const parameters = {
      name: "Gateway-authored workflow",
      description: "Created through the governed self-tool",
      idempotencyKey: "gateway-create-v1",
    };
    const result = await gateway.executeTool({
      sessionToken: session.token,
      tool: "blentera.workflow.draft.create",
      parameters,
    });

    expect(result.status).toBe("completed");
    expect(result.result).toMatchObject({
      data: {
        status: "created",
        workflow: {
          name: "Gateway-authored workflow",
          publishedRevisionId: null,
          draftRevision: { state: "draft" },
        },
      },
    });

    const replay = await gateway.executeTool({
      sessionToken: session.token,
      tool: "paperclip-self:create_workflow",
      parameters,
    });
    expect(replay.status).toBe("replayed");
    const workflowId = (value: unknown) => {
      expect(value).toMatchObject({ data: { workflow: { id: expect.any(String) } } });
      return (value as { data: { workflow: { id: string } } }).data.workflow.id;
    };
    expect(workflowId(replay.result)).toBe(workflowId(result.result));
    expect(await db.select().from(workflows).where(eq(workflows.companyId, company.id))).toHaveLength(1);

    await expect(gateway.executeTool({ sessionToken: session.token, tool: "paperclip-self:create_workflow", parameters: {
      ...parameters, description: "Changed content under the original request key",
    } })).rejects.toMatchObject({ status: 409, details: { code: "workflow_authoring_idempotency_conflict" } });
    expect(await db.select().from(workflows).where(eq(workflows.companyId, company.id))).toHaveLength(1);

    const [blockReplay] = await db.insert(toolPolicies).values({ companyId: company.id,
      name: "Block current workflow draft replay", policyType: "block", priority: 1,
      selectors: { toolName: "paperclip-self:create_workflow" },
    }).returning();
    await expect(gateway.executeTool({ sessionToken: session.token, tool: "paperclip-self:create_workflow", parameters }))
      .rejects.toMatchObject({ status: 403 });
    await db.delete(toolPolicies).where(eq(toolPolicies.id, blockReplay!.id));
    expect(await db.select().from(workflows).where(eq(workflows.companyId, company.id))).toHaveLength(1);

    await db.update(heartbeatRuns).set({ runnerProfileJson: sql`${heartbeatRuns.runnerProfileJson} - 'platformSkillAdmission'` })
      .where(eq(heartbeatRuns.id, run.id));
    await expect(gateway.executeTool({ sessionToken: session.token, tool: "paperclip-self:create_workflow", parameters }))
      .rejects.toMatchObject({ status: 409, details: { code: "platform_skill_readmission_required" } });
    expect(await db.select().from(workflows).where(eq(workflows.companyId, company.id))).toHaveLength(1);

    await preparePlatformSkillAdmission(db, { companyId: company.id, agentId: agent.id, runId: run.id,
      responsibleUserId: userId, requireExisting: false }, blenteraPlatformContractHashes());
    await db.update(companyMemberships).set({ status: "suspended" }).where(and(
      eq(companyMemberships.companyId, company.id), eq(companyMemberships.principalType, "user"),
      eq(companyMemberships.principalId, userId),
    ));
    await expect(gateway.executeTool({ sessionToken: session.token, tool: "paperclip-self:create_workflow", parameters }))
      .rejects.toMatchObject({ status: 403 });
    expect(await db.select().from(workflows).where(eq(workflows.companyId, company.id))).toHaveLength(1);

    await db.update(companyMemberships).set({ status: "active" }).where(and(
      eq(companyMemberships.companyId, company.id), eq(companyMemberships.principalType, "user"),
      eq(companyMemberships.principalId, userId),
    ));
    await db.update(heartbeatRuns).set({ status: "failed" }).where(eq(heartbeatRuns.id, run.id));
    await expect(gateway.executeTool({ sessionToken: session.token, tool: "paperclip-self:create_workflow", parameters }))
      .rejects.toMatchObject({ status: 401 });
    expect(await db.select().from(workflows).where(eq(workflows.companyId, company.id))).toHaveLength(1);
  });

  it("gates write tools with an action request and executes only stored reviewed arguments once", async () => {
    const { company, agent, run } = await createRunFixture(db);
    await db.insert(toolPolicies).values({
      companyId: company.id,
      name: "Review note writes",
      policyType: "require_approval",
      selectors: { toolName: "mcp-remote-fixture:update_note" },
    });
    const gateway = createTestToolGatewayService(db);
    const session = await gateway.createSession({
      companyId: company.id,
      agentId: agent.id,
      runId: run.id,
    });

    await expect(gateway.executeTool({
      sessionToken: session.token,
      tool: "mcp-remote-fixture:update_note",
      parameters: { noteId: "n1", body: "short" },
    })).rejects.toMatchObject({
      reasonCode: "approval_required",
      details: { instructions: expect.stringContaining("A human approval card was posted on task") },
    });

    await expect(gateway.executeTool({
      sessionToken: session.token,
      tool: "mcp-remote-fixture:update_note",
      parameters: { noteId: "n1", body: "short" },
    })).rejects.toMatchObject({ reasonCode: "approval_required" });
    expect(await db.select().from(toolActionRequests)).toHaveLength(1);

    const [actionRequest] = await db.select().from(toolActionRequests);
    expect(actionRequest).toMatchObject({
      status: "pending",
      issueId: session.issueId,
      approvalId: null,
    });
    expect(actionRequest.signedArguments).toEqual(expect.any(String));

    // PAP-10896: the prosumer card preview must be plain language — no tool/risk vocab,
    // no "Arguments reviewed for execution:" header, and no raw JSON code block.
    const preview = actionRequest.previewMarkdown ?? "";
    expect(preview).not.toMatch(/Tool:/);
    expect(preview).not.toMatch(/Risk:/);
    expect(preview).not.toMatch(/Arguments reviewed for execution:/);
    expect(preview).not.toMatch(/```/);
    expect(preview).toContain("Remote fixture update note");
    expect(preview).not.toContain("checking with you first");
    expect(preview).not.toContain("\n\n");
    // The humanized field label is surfaced (body → "Body"), the raw key is not.
    expect(preview).toContain("**Body:** short");

    const [interaction] = await db.select().from(issueThreadInteractions);
    expect(interaction).toMatchObject({
      kind: "request_confirmation",
      status: "pending",
      issueId: session.issueId,
    });
    // The board-only formal-approval interaction may keep the technical block.
    const interactionDetails =
      (interaction.payload as { detailsMarkdown?: string } | null)?.detailsMarkdown ?? "";
    expect(interactionDetails).toMatch(/Tool: `mcp-remote-fixture:update_note`/);
    expect(interactionDetails).toMatch(/Risk: `write`/);
    const [invocation] = await db.select().from(toolInvocations);
    expect(invocation).toMatchObject({
      status: "awaiting_approval",
      approvalState: "pending",
      toolName: "mcp-remote-fixture:update_note",
      resultSummary: null,
    });

    await db.update(issueThreadInteractions).set({
      status: "accepted",
      resolvedByUserId: "board-user",
      resolvedAt: new Date(),
      updatedAt: new Date(),
    }).where(eq(issueThreadInteractions.id, interaction.id));

    const result = await gateway.executeTool({
      sessionToken: session.token,
      tool: "mcp-remote-fixture:update_note",
      approvedActionRequestId: actionRequest.id,
      parameters: { noteId: "n1", body: "this tampered body must not execute" },
    });
    expect(result.status).toBe("completed");
    expect((result.result as { data?: { bodyLength?: number } }).data?.bodyLength).toBe("short".length);

    await expect(gateway.executeTool({
      sessionToken: session.token,
      tool: "mcp-remote-fixture:update_note",
      approvedActionRequestId: actionRequest.id,
      parameters: { noteId: "n1", body: "short" },
    })).rejects.toMatchObject({ reasonCode: "action_not_approved" });
  });

  it("approves a pending action request directly from the review queue and preserves signed arguments", async () => {
    const { company, agent, issue, run } = await createRunFixture(db);
    // Real runner calls carry immutable identity in their signed approval.
    await initializeRunIdentity(db, {
      companyId: company.id, runId: run.id, issueId: issue.id,
      responsibleUserId: null, cause: "company_default",
    });
    await db.insert(toolPolicies).values({
      companyId: company.id,
      name: "Review note writes",
      policyType: "require_approval",
      selectors: { toolName: "mcp-remote-fixture:update_note" },
    });
    const gateway = createTestToolGatewayService(db);
    const session = await gateway.createSession({
      companyId: company.id,
      agentId: agent.id,
      runId: run.id,
    });

    await expect(gateway.executeTool({
      sessionToken: session.token,
      tool: "mcp-remote-fixture:update_note",
      parameters: { noteId: "n1", body: "reviewed body" },
    })).rejects.toMatchObject({ reasonCode: "approval_required" });

    const [actionRequest] = await db.select().from(toolActionRequests);
    const approved = await gateway.approveActionRequest({
      companyId: company.id,
      actionRequestId: actionRequest.id,
      actor: { userId: "board-user" },
    });
    expect(approved).toMatchObject({
      status: "executed",
      resolvedByUserId: "board-user",
      resultSummary: expect.stringContaining("bodyLength"),
    });

    // The server carries out the approved call itself with no interactive
    // caller left to raise timeoutMs, so it must get the full 60s headroom
    // rather than the 10s interactive default.
    const [executedEvent] = await db.select().from(toolCallEvents).where(and(
      eq(toolCallEvents.actionRequestId, actionRequest.id),
      eq(toolCallEvents.reasonCode, "approved_action_executed"),
    ));
    expect(executedEvent?.metadata).toMatchObject({ timeoutMs: 60_000 });

    const result = await gateway.executeTool({
      sessionToken: session.token,
      tool: "mcp-remote-fixture:update_note",
      parameters: { noteId: "n1", body: "reviewed body" },
    });
    expect(result.status).toBe("replayed");
    expect((result.result as { data?: { bodyLength?: number } }).data?.bodyLength).toBe("reviewed body".length);

    const [invocation] = await db.select().from(toolInvocations);
    expect(invocation).toMatchObject({
      status: "succeeded",
      approvalState: "approved",
    });
    const [consumed] = await db.select().from(toolActionRequests);
    expect(consumed.status).toBe("executed");
  });

  it("commits one human decision and delivers once after the original run yields, including after service restart", async () => {
    const { company, agent, issue, run } = await createRunFixture(db);
    await db.insert(toolPolicies).values({ companyId: company.id, name: "Ask first", policyType: "require_approval", selectors: { toolName: "mcp-remote-fixture:update_note" } });
    const wakeup = vi.fn(async (agentId: string, input: any) => {
      const [wake] = await db.insert(agentWakeupRequests).values({ companyId: company.id, agentId, source: input.source, idempotencyKey: input.idempotencyKey, payload: input.payload }).returning();
      return wake as any;
    });
    const deliveries = toolActionDeliveryService(db, { wakeup });
    const gateway = createTestToolGatewayService(db, { onToolActionSettled: deliveries.deliver });
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id });
    await expect(gateway.executeTool({ sessionToken: session.token, tool: "mcp-remote-fixture:update_note", parameters: { noteId: "n1", body: "receipt" } })).rejects.toMatchObject({ reasonCode: "approval_required" });
    const [request] = await db.select().from(toolActionRequests);
    await gateway.approveActionRequest({ companyId: company.id, actionRequestId: request.id, actor: { userId: "reviewer" } });
    const [interaction] = await db.select().from(issueThreadInteractions).where(eq(issueThreadInteractions.id, request.interactionId!));
    expect(interaction).toMatchObject({ issueId: issue.id, status: "accepted", resolvedByUserId: "reviewer", result: { outcome: "accepted", toolAction: { status: "executed", rememberedAction: false } } });
    const nativeResponses = await materializeNativeInteractionResponses({ db, companyId: company.id, issueId: issue.id, runId: randomUUID(), agentId: agent.id, interactionIds: [interaction.id] });
    expect(nativeResponses).toMatchObject([{ interactionId: interaction.id, response: { status: "accepted", result: { toolAction: { status: "executed", resultSummary: expect.stringContaining("bodyLength") } } } }]);
    expect(wakeup).not.toHaveBeenCalled();
    expect((await db.select().from(toolActionDeliveries))[0].deliveredAt).toBeNull();
    await deliveries.deliverForRun({ companyId: company.id, runId: run.id });
    expect(wakeup).not.toHaveBeenCalled();
    await db.update(heartbeatRuns).set({ status: "succeeded" }).where(eq(heartbeatRuns.id, run.id));
    const restarted = toolActionDeliveryService(db, { wakeup });
    await deliveries.deliverForRun({ companyId: randomUUID(), runId: run.id });
    await deliveries.deliverForRun({ companyId: company.id, runId: randomUUID() });
    expect(wakeup).not.toHaveBeenCalled();
    // The original executor's terminal cleanup must deliver a review that was
    // approved while it was running, without waiting for the scheduler sweep.
    await deliveries.deliverForRun({ companyId: company.id, runId: run.id });
    expect(wakeup).toHaveBeenCalledTimes(1);
    await Promise.all([restarted.sweepPending(), deliveries.sweepPending()]);
    await gateway.approveActionRequest({ companyId: company.id, actionRequestId: request.id, actor: { userId: "second-reviewer" } });
    await restarted.sweepPending();
    expect(wakeup).toHaveBeenCalledTimes(1);
    expect(wakeup.mock.calls[0][1].payload.toolAction).toMatchObject({ executionStatus: "executed", resultSummary: expect.stringContaining("bodyLength"), instructions: expect.stringContaining("Do not call it again") });
    expect((await db.select().from(toolActionDeliveries))[0].deliveredAt).not.toBeNull();
    expect((await db.select().from(toolActionRequests))[0].decidedByUserId).toBe("reviewer");
    const message = wakeup.mock.calls[0][1].payload.paperclipAgentMessage;
    expect(message.text).toContain("Do not call it again");
    expect(message.text).not.toContain("bodyLength");
    expect(message.untrustedToolResults).toMatchObject([{ actionRequestId: request.id, resultSummary: expect.stringContaining("bodyLength") }]);
  });

  it("waits for all reviews, then delivers both outcomes in one durable continuation", async () => {
    const { company, agent, issue, run } = await createRunFixture(db);
    await db.insert(toolPolicies).values({ companyId: company.id, name: "Ask first", policyType: "require_approval", selectors: { toolName: "mcp-remote-fixture:update_note" } });
    const wakeup = vi.fn(async (agentId: string, input: any) => (await db.insert(agentWakeupRequests).values({ companyId: company.id, agentId, source: input.source, idempotencyKey: input.idempotencyKey, payload: input.payload }).returning())[0] as any);
    const delivery = toolActionDeliveryService(db, { wakeup });
    const gateway = createTestToolGatewayService(db, { onToolActionSettled: delivery.deliver });
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id });
    for (const noteId of ["one", "two"]) await expect(gateway.executeTool({ sessionToken: session.token, tool: "mcp-remote-fixture:update_note", parameters: { noteId, body: "reviewed body" } })).rejects.toMatchObject({ reasonCode: "approval_required" });
    const requests = await db.select().from(toolActionRequests);
    expect(requests).toHaveLength(2);
    await expect(issueService(db).update(issue.id, { status: "done", actorAgentId: agent.id })).rejects.toThrow("waiting for a connection review");
    await db.update(heartbeatRuns).set({ status: "succeeded" }).where(eq(heartbeatRuns.id, run.id));
    await gateway.approveActionRequest({ companyId: company.id, actionRequestId: requests[0].id, actor: { userId: "reviewer" } });
    expect(wakeup).not.toHaveBeenCalled();
    expect((await db.select().from(issueThreadInteractions)).filter(row => row.status === "pending")).toHaveLength(1);
    await expect(gateway.declineActionRequest({ companyId: company.id, issueId: issue.id, interactionId: requests[0].interactionId!, actionRequestId: requests[1].id, actor: { userId: "reviewer" } })).rejects.toThrow("does not belong to this interaction");
    await gateway.declineActionRequest({ companyId: company.id, issueId: issue.id, interactionId: requests[1].interactionId!, actionRequestId: requests[1].id, reason: "Not needed", actor: { userId: "reviewer" } });
    await delivery.sweepPending();
    expect(wakeup).toHaveBeenCalledTimes(1);
    const payload = wakeup.mock.calls[0][1].payload;
    expect(payload.interactionIds).toHaveLength(2);
    expect(new Set(payload.toolActions.map((action: any) => action.executionStatus))).toEqual(new Set(["executed", "rejected"]));
    expect((await db.select().from(toolActionDeliveries)).every(row => row.deliveredAt)).toBe(true);
    const native = await materializeNativeInteractionResponses({ db, companyId: company.id, issueId: issue.id, runId: randomUUID(), agentId: agent.id, interactionIds: payload.interactionIds });
    expect(native).toHaveLength(2);
  });

  it("keeps reviewed results from different source runs in separate non-coalescing wakes", async () => {
    const { company, agent, issue, run } = await createRunFixture(db);
    const [secondRun] = await db.insert(heartbeatRuns).values({ companyId: company.id,
      agentId: agent.id, status: "running", contextSnapshot: { issueId: issue.id } }).returning();
    await db.insert(toolPolicies).values({ companyId: company.id, name: "Ask first", policyType: "require_approval", selectors: { toolName: "mcp-remote-fixture:update_note" } });
    const gateway = createTestToolGatewayService(db);
    for (const sourceRun of [run, secondRun]) {
      const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: sourceRun.id });
      await expect(gateway.executeTool({ sessionToken: session.token, tool: "mcp-remote-fixture:update_note", parameters: { noteId: sourceRun.id, body: "separate origin" } })).rejects.toMatchObject({ reasonCode: "approval_required" });
    }
    const requests = await db.select().from(toolActionRequests);
    for (const action of requests) await gateway.declineActionRequest({ companyId: company.id, issueId: issue.id,
      interactionId: action.interactionId!, actionRequestId: action.id, actor: { userId: "reviewer" } });
    await db.update(heartbeatRuns).set({ status: "succeeded" }).where(eq(heartbeatRuns.companyId, company.id));
    const wakeup = vi.fn(async (agentId: string, input: any) => (await db.insert(agentWakeupRequests).values({ companyId: company.id,
      agentId, source: input.source, idempotencyKey: input.idempotencyKey, payload: input.payload }).returning())[0] as any);
    await toolActionDeliveryService(db, { wakeup }).sweepPending();
    expect(wakeup).toHaveBeenCalledTimes(2);
    expect(new Set(wakeup.mock.calls.map(([, input]) => input.payload.sourceRunId))).toEqual(new Set([run.id, secondRun.id]));
    for (const [, input] of wakeup.mock.calls) {
      expect(input.allowRunCoalescing).toBe(false);
      expect(input.payload.toolActionRequestIds).toHaveLength(1);
    }
    expect((await db.select().from(toolActionDeliveries)).every(row => row.deliveredAt)).toBe(true);
  });

  it("bounds many outcomes and recovers their full-result reference after wake commit", async () => {
    const { company, agent, run } = await createRunFixture(db);
    await db.insert(toolPolicies).values({ companyId: company.id, name: "Ask first", policyType: "require_approval", selectors: { toolName: "mcp-remote-fixture:update_note" } });
    const gateway = createTestToolGatewayService(db);
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id });
    for (let n = 0; n < 12; n++) {
      await expect(gateway.executeTool({ sessionToken: session.token, tool: "mcp-remote-fixture:update_note", parameters: { noteId: `note-${n}`, body: "review me" } })).rejects.toMatchObject({ reasonCode: "approval_required" });
    }
    const requests = await db.select().from(toolActionRequests);
    for (const request of requests) await gateway.declineActionRequest({ companyId: company.id, actionRequestId: request.id, actor: { userId: "reviewer" }, reason: "😀\n\\".repeat(4000) });
    await db.update(heartbeatRuns).set({ status: "succeeded" }).where(eq(heartbeatRuns.id, run.id));
    const wakeup = vi.fn(async (agentId: string, input: any) => {
      await db.insert(agentWakeupRequests).values({ companyId: company.id, agentId, source: input.source, idempotencyKey: input.idempotencyKey, payload: input.payload });
      throw new Error("crash after durable wake commit");
    });
    const delivery = toolActionDeliveryService(db, { wakeup });
    await expect(delivery.sweepPending()).rejects.toThrow("crash after durable wake commit");
    await delivery.sweepPending();
    expect(wakeup).toHaveBeenCalledTimes(1);
    const payload = wakeup.mock.calls[0][1].payload;
    expect(Buffer.byteLength(JSON.stringify(payload), "utf8")).toBeLessThan(32_768);
    expect(payload.toolActions.length).toBeLessThanOrEqual(8);
    expect(payload.interactionIds.length).toBe(payload.toolActions.length);
    expect(payload.toolActionOutcomeCount).toBe(12);
    expect(payload.paperclipAgentMessage.text).toContain(payload.toolActionResultsUrl);
    expect((await db.select().from(toolActionDeliveries)).every(row => row.deliveredAt)).toBe(true);
    // The reference retains all outcomes and their full notes, not just snippets.
    expect((await db.select().from(issueThreadInteractions)).every(row => JSON.stringify(row.result).length > 12_000)).toBe(true);
  });

  it("retires a former assignee's continuation after reassignment", async () => {
    const { company, agent, issue, run } = await createRunFixture(db);
    await db.insert(toolPolicies).values({ companyId: company.id, name: "Ask first", policyType: "require_approval", selectors: { toolName: "mcp-remote-fixture:update_note" } });
    const gateway = createTestToolGatewayService(db);
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id });
    await expect(gateway.executeTool({ sessionToken: session.token, tool: "mcp-remote-fixture:update_note", parameters: { noteId: "reassigned" } })).rejects.toMatchObject({ reasonCode: "approval_required" });
    const [request] = await db.select().from(toolActionRequests);
    await gateway.declineActionRequest({ companyId: company.id, actionRequestId: request.id, actor: { userId: "reviewer" } });
    const [replacement] = await db.insert(agents).values({ companyId: company.id, name: "Replacement", role: "engineer", adapterType: "process" }).returning();
    await db.update(issues).set({ assigneeAgentId: replacement.id }).where(eq(issues.id, issue.id));
    const wakeup = vi.fn();
    const delivery = toolActionDeliveryService(db, { wakeup });
    await delivery.sweepPending();
    expect((await db.select().from(toolActionDeliveries))[0].deliveredAt).not.toBeNull();
    expect(await delivery.sweepPending()).toEqual({ scanned: 0, delivered: 0 });
    expect(wakeup).not.toHaveBeenCalled();
  });

  it("recovers expired reviews beyond a full batch of approvals that cannot recover", async () => {
    const { company, agent, run } = await createRunFixture(db);
    await db.insert(toolPolicies).values({ companyId: company.id, name: "Ask first", policyType: "require_approval", selectors: { toolName: "mcp-remote-fixture:update_note" } });
    const gateway = createTestToolGatewayService(db);
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id });
    await expect(gateway.executeTool({ sessionToken: session.token, tool: "mcp-remote-fixture:update_note", parameters: { noteId: "expire" } })).rejects.toMatchObject({ reasonCode: "approval_required" });
    const [request] = await db.select().from(toolActionRequests);
    await db.update(toolActionRequests).set({ expiresAt: new Date(Date.now() - 1000) }).where(eq(toolActionRequests.id, request.id));
    await db.insert(toolActionRequests).values(Array.from({ length: 100 }, (_, i) => ({
      ...request, id: `00000000-0000-4000-8000-${String(i).padStart(12, "0")}`,
      interactionId: null, status: "approved" as const,
    })));
    const recover = vi.spyOn(gateway, "approveActionRequest").mockRejectedValue(new Error("Unavailable approval dependency"));
    expect(await gateway.sweepActionReviews()).toEqual({ scanned: 101 });
    expect(recover).toHaveBeenCalledTimes(100);
    const [settled] = await db.select().from(issueThreadInteractions).where(eq(issueThreadInteractions.id, request.interactionId!));
    expect(settled.status).toBe("expired");
  });

  it("settles expired reviews and interrupted execution without replaying an uncertain external action", async () => {
    const { company, agent, issue, run } = await createRunFixture(db);
    await db.insert(toolPolicies).values({ companyId: company.id, name: "Ask first", policyType: "require_approval", selectors: { toolName: "mcp-remote-fixture:update_note" } });
    const gateway = createTestToolGatewayService(db);
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id });
    await expect(gateway.executeTool({ sessionToken: session.token, tool: "mcp-remote-fixture:update_note", parameters: { noteId: "expire" } })).rejects.toMatchObject({ reasonCode: "approval_required" });
    const [expiring] = await db.select().from(toolActionRequests);
    await db.update(toolActionRequests).set({ expiresAt: new Date(Date.now() - 1000) }).where(eq(toolActionRequests.id, expiring.id));
    await gateway.sweepActionReviews();
    expect((await db.select().from(issueThreadInteractions))[0].status).toBe("expired");
    expect(await materializeNativeInteractionResponses({ db, companyId: company.id, issueId: issue.id, runId: randomUUID(), agentId: agent.id, interactionIds: [expiring.interactionId!] })).toMatchObject([{ response: { status: "expired", executionStatus: "expired" } }]);
    await expect(gateway.executeTool({ sessionToken: session.token, tool: "mcp-remote-fixture:update_note", parameters: { noteId: "uncertain" } })).rejects.toMatchObject({ reasonCode: "approval_required" });
    const pending = (await db.select().from(toolActionRequests)).find(row => row.status === "pending")!;
    await commitToolActionReview(db, { companyId: company.id, actionRequestId: pending.id, decision: "approved", actor: { userId: "reviewer" } });
    await db.update(toolActionRequests).set({ status: "executing", updatedAt: new Date(Date.now() - 11 * 60_000) }).where(eq(toolActionRequests.id, pending.id));
    await db.update(toolInvocations).set({ status: "executing" }).where(eq(toolInvocations.id, pending.invocationId));
    await gateway.sweepActionReviews();
    const [result] = await db.select().from(issueThreadInteractions).where(eq(issueThreadInteractions.id, pending.interactionId!));
    expect(result).toMatchObject({ status: "accepted", result: { toolAction: { status: "failed", errorCode: "tool_execution_outcome_unknown" } } });
    // Simulate a crash before the feed projection was saved, then repair it.
    await db.update(issueThreadInteractions).set({ result: { version: 1, outcome: "accepted", toolAction: { version: 1, status: "executing", updatedAt: new Date().toISOString() } } }).where(eq(issueThreadInteractions.id, pending.interactionId!));
    await gateway.sweepActionReviews();
    const [reconciled] = await db.select().from(issueThreadInteractions).where(eq(issueThreadInteractions.id, pending.interactionId!));
    expect(reconciled.result).toMatchObject({ toolAction: { status: "failed", errorCode: "tool_execution_outcome_unknown" } });
    expect(await db.select().from(toolCallEvents).where(eq(toolCallEvents.reasonCode, "approved_action_executed"))).toHaveLength(0);
  });

  it("remembers a read action atomically, allows changed arguments, and preserves explicit denials and definition review", async () => {
    const { company, agent, issue, run } = await createRunFixture(db);
    const [project] = await db.insert(projects).values({ companyId: company.id, name: "Reviewed project" }).returning();
    await db.update(issues).set({ projectId: project.id }).where(eq(issues.id, issue.id));
    const { connection, catalogEntry } = await createRemoteMcpToolFixture(db, company.id);
    await db.insert(toolPolicies).values({ companyId: company.id, name: "Ask about reads", policyType: "require_approval", selectors: { connectionId: connection.id } });
    let calls = 0;
    const gateway = createTestToolGatewayService(db, { remoteHttpRequest: async (_url, init) => {
      const body = JSON.parse(String(init.body));
      if (body.method === "tools/call") calls++;
      return new Response(JSON.stringify({ jsonrpc: "2.0", id: body.id, result: { content: [{ type: "text", text: "Roadmap and meeting notes" }] } }), { headers: { "content-type": "application/json" } });
    } });
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id });
    const tool = (await gateway.listToolsForSession(session.token)).find(t => t.connectionId === connection.id)!;
    const call = (limit: number) => gateway.executeTool({ sessionToken: session.token, tool: tool.name, parameters: { limit } });
    await expect(call(10)).rejects.toMatchObject({ reasonCode: "approval_required" });
    await expect(call(10)).rejects.toMatchObject({ reasonCode: "approval_required" });
    expect(calls).toBe(0);
    const requests = await db.select().from(toolActionRequests);
    expect(requests).toHaveLength(1);
    const [interaction] = await db.select().from(issueThreadInteractions);
    expect(interaction.payload).toMatchObject({ supersedeOnUserComment: false, toolAction: { risk: "read", rememberActionScope: expect.any(String) } });
    const approve = () => gateway.approveActionRequest({ companyId: company.id, actionRequestId: requests[0].id, rememberAction: true, actor: { userId: "reviewer" } });
    await Promise.all([approve(), approve()]);
    expect(calls).toBe(1);
    const rules = await db.select().from(toolPolicies).where(eq(toolPolicies.policyType, "trust_rule"));
    expect(rules).toHaveLength(1);
    expect(rules[0].selectors).toMatchObject({ agentId: agent.id, projectId: project.id, connectionId: connection.id, toolName: tool.name });
    await call(20);
    expect(calls).toBe(2);
    const [otherAgent] = await db.insert(agents).values({ companyId: company.id, name: "Other agent", role: "engineer", adapterType: "process" }).returning();
    for (const boundary of [{ agentId: agent.id, projectId: null }, { agentId: otherAgent.id, projectId: project.id }]) {
      const [otherIssue] = await db.insert(issues).values({ companyId: company.id, title: "Other scope", status: "in_progress", assigneeAgentId: boundary.agentId, projectId: boundary.projectId }).returning();
      const [otherRun] = await db.insert(heartbeatRuns).values({ companyId: company.id, agentId: boundary.agentId, invocationSource: "assignment", status: "running", contextSnapshot: { issueId: otherIssue.id } }).returning();
      const otherSession = await gateway.createSession({ companyId: company.id, agentId: boundary.agentId, runId: otherRun.id });
      await expect(gateway.executeTool({ sessionToken: otherSession.token, tool: tool.name, parameters: { limit: 25 } })).rejects.toMatchObject({ reasonCode: "approval_required" });
    }
    expect(calls).toBe(2);
    const [deny] = await db.insert(toolPolicies).values({ companyId: company.id, name: "Explicit denial", policyType: "block", priority: 999, selectors: { connectionId: connection.id } }).returning();
    await expect(call(30)).rejects.toMatchObject({ status: 403 });
    expect(calls).toBe(2);
    await db.delete(toolPolicies).where(eq(toolPolicies.id, deny.id));
    await db.update(toolCatalogEntries).set({ versionHash: "changed-definition" }).where(eq(toolCatalogEntries.id, catalogEntry.id));
    await expect(call(40)).rejects.toMatchObject({ reasonCode: "approval_required" });
    expect(calls).toBe(2);
  });

  it("rolls back approval when remembered permission cannot be saved", async () => {
    const { company, agent, run } = await createRunFixture(db);
    await db.insert(toolPolicies).values({ companyId: company.id, name: "Ask first", policyType: "require_approval", selectors: { toolName: "mcp-remote-fixture:update_note" } });
    const gateway = createTestToolGatewayService(db);
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id });
    await expect(gateway.executeTool({ sessionToken: session.token, tool: "mcp-remote-fixture:update_note", parameters: { noteId: "n1" } })).rejects.toMatchObject({ reasonCode: "approval_required" });
    const [request] = await db.select().from(toolActionRequests);
    // This internal fixture has no connection and cannot grant action-wide access.
    await expect(gateway.approveActionRequest({ companyId: company.id, actionRequestId: request.id, rememberAction: true, actor: { userId: "reviewer" } })).rejects.toThrow();
    expect((await db.select().from(toolActionRequests))[0].status).toBe("pending");
    expect((await db.select().from(issueThreadInteractions))[0].status).toBe("pending");
    expect((await db.select().from(toolActionDeliveries))[0].deliveredAt).toBeNull();
    expect(await db.select().from(toolCallEvents).where(eq(toolCallEvents.reasonCode, "approved_action_executed"))).toHaveLength(0);
  });

  it("refuses to approve an action request through a different interaction", async () => {
    const { company, agent, issue, run } = await createRunFixture(db);
    await db.insert(toolPolicies).values({
      companyId: company.id,
      name: "Review note writes",
      policyType: "require_approval",
      selectors: { toolName: "mcp-remote-fixture:update_note" },
    });
    const gateway = createTestToolGatewayService(db);
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id });

    await expect(gateway.executeTool({
      sessionToken: session.token,
      tool: "mcp-remote-fixture:update_note",
      parameters: { noteId: "n1", body: "reviewed body" },
    })).rejects.toMatchObject({ reasonCode: "approval_required" });

    const [actionRequest] = await db.select().from(toolActionRequests);
    await expect(gateway.approveActionRequest({
      companyId: company.id,
      issueId: issue.id,
      interactionId: randomUUID(),
      actionRequestId: actionRequest.id,
      actor: { userId: "board-user" },
    })).rejects.toMatchObject({ reasonCode: "action_context_mismatch" });

    const [stillPending] = await db.select().from(toolActionRequests);
    expect(stillPending.status).toBe("pending");
  });

  it("prevents another run from consuming an approved action request by id", async () => {
    const { company, agent, issue, run } = await createRunFixture(db);
    await db.insert(toolPolicies).values({
      companyId: company.id,
      name: "Review note writes",
      policyType: "require_approval",
      selectors: { toolName: "mcp-remote-fixture:update_note" },
    });
    const gateway = createTestToolGatewayService(db);
    const originatingSession = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id });

    await expect(gateway.executeTool({
      sessionToken: originatingSession.token,
      tool: "mcp-remote-fixture:update_note",
      parameters: { noteId: "n1", body: "reviewed body" },
    })).rejects.toMatchObject({ reasonCode: "approval_required" });

    const [actionRequest] = await db.select().from(toolActionRequests);
    const now = new Date();
    await db
      .update(issueThreadInteractions)
      .set({ status: "accepted", resolvedByUserId: "board-user", resolvedAt: now })
      .where(eq(issueThreadInteractions.id, actionRequest.interactionId!));
    await db
      .update(toolActionRequests)
      .set({ status: "approved", resolvedByUserId: "board-user", decidedAt: now, resolvedAt: now })
      .where(eq(toolActionRequests.id, actionRequest.id));

    const [otherRun] = await db.insert(heartbeatRuns).values({
      companyId: company.id,
      agentId: agent.id,
      invocationSource: "assignment",
      status: "running",
      contextSnapshot: { issueId: issue.id },
    }).returning();
    const otherSession = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: otherRun.id });

    await expect(gateway.executeTool({
      sessionToken: otherSession.token,
      tool: "mcp-remote-fixture:update_note",
      parameters: { noteId: "n1", body: "reviewed body" },
      approvedActionRequestId: actionRequest.id,
    })).rejects.toMatchObject({ reasonCode: "action_scope_mismatch" });

    const [stillApproved] = await db.select().from(toolActionRequests);
    expect(stillApproved.status).toBe("approved");
  });

  it("executes an approved identical-args race once and returns the winner result", async () => {
    const { company, agent, run } = await createRunFixture(db);
    await db.insert(toolPolicies).values({
      companyId: company.id,
      name: "Review note writes",
      policyType: "require_approval",
      selectors: { toolName: "mcp-remote-fixture:update_note" },
    });
    const gateway = createTestToolGatewayService(db);
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id });
    const parameters = { noteId: "n1", body: "race body" };

    await expect(gateway.executeTool({
      sessionToken: session.token,
      tool: "mcp-remote-fixture:update_note",
      parameters,
    })).rejects.toMatchObject({ reasonCode: "approval_required" });
    const [actionRequest] = await db.select().from(toolActionRequests);
    const now = new Date();
    await db.update(toolActionRequests).set({ status: "approved", decidedAt: now, resolvedAt: now }).where(eq(toolActionRequests.id, actionRequest.id));

    const [first, second] = await Promise.all([
      gateway.executeTool({ sessionToken: session.token, tool: "mcp-remote-fixture:update_note", parameters }),
      gateway.executeTool({ sessionToken: session.token, tool: "mcp-remote-fixture:update_note", parameters }),
    ]);
    expect(first.status).toBe("replayed");
    expect(second.status).toBe("replayed");
    expect(first.result).toEqual(second.result);
    const executionEvents = await db.select().from(toolCallEvents).where(and(
      eq(toolCallEvents.actionRequestId, actionRequest.id),
      eq(toolCallEvents.reasonCode, "approved_action_executed"),
    ));
    expect(executionEvents).toHaveLength(1);
  });

  it("refuses to execute an approved action after its issue closes", async () => {
    const { company, agent, issue, run } = await createRunFixture(db);
    await db.insert(toolPolicies).values({
      companyId: company.id,
      name: "Review note writes",
      policyType: "require_approval",
      selectors: { toolName: "mcp-remote-fixture:update_note" },
    });
    const gateway = createTestToolGatewayService(db);
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id });
    const parameters = { noteId: "n1", body: "post-close body" };

    await expect(gateway.executeTool({
      sessionToken: session.token,
      tool: "mcp-remote-fixture:update_note",
      parameters,
    })).rejects.toMatchObject({ reasonCode: "approval_required" });
    const [actionRequest] = await db.select().from(toolActionRequests);
    const now = new Date();
    await db.update(toolActionRequests).set({ status: "approved", decidedAt: now, resolvedAt: now }).where(eq(toolActionRequests.id, actionRequest.id));
    await db.update(issues).set({ status: "done" }).where(eq(issues.id, issue.id));

    await expect(gateway.executeTool({
      sessionToken: session.token,
      tool: "mcp-remote-fixture:update_note",
      parameters,
    })).rejects.toMatchObject({ reasonCode: "action_issue_closed" });

    const [settled] = await db.select().from(toolActionRequests).where(eq(toolActionRequests.id, actionRequest.id));
    expect(settled?.status).toBe("expired");
    const executionEvents = await db.select().from(toolCallEvents).where(and(
      eq(toolCallEvents.actionRequestId, actionRequest.id),
      eq(toolCallEvents.reasonCode, "approved_action_executed"),
    ));
    expect(executionEvents).toHaveLength(0);
  });

  it("keeps pre-execute-on-approve approved requests inert", async () => {
    const { company, agent, run } = await createRunFixture(db);
    await db.insert(toolPolicies).values({
      companyId: company.id,
      name: "Review note writes",
      policyType: "require_approval",
      selectors: { toolName: "mcp-remote-fixture:update_note" },
    });
    const gateway = createTestToolGatewayService(db);
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id });
    const parameters = { noteId: "n1", body: "legacy" };
    await expect(gateway.executeTool({ sessionToken: session.token, tool: "mcp-remote-fixture:update_note", parameters }))
      .rejects.toMatchObject({ reasonCode: "approval_required" });
    const [actionRequest] = await db.select().from(toolActionRequests);
    const [invocation] = await db.select().from(toolInvocations);
    const legacySignature = signToolArguments({
      invocationId: invocation.id,
      toolName: invocation.toolName,
      canonicalArguments: canonicalToolArguments(parameters),
      signingSecret: testToolActionSigningSecret,
    });
    await db.update(toolActionRequests).set({ signedArguments: legacySignature }).where(eq(toolActionRequests.id, actionRequest.id));

    const approved = await gateway.approveActionRequest({
      companyId: company.id,
      actionRequestId: actionRequest.id,
      actor: { userId: "board-user" },
    });
    expect(approved.status).toBe("approved");
    const [parkedInvocation] = await db.select().from(toolInvocations).where(eq(toolInvocations.id, invocation.id));
    expect(parkedInvocation.status).toBe("awaiting_approval");

    await expect(gateway.executeTool({
      sessionToken: session.token,
      tool: "mcp-remote-fixture:update_note",
      parameters,
    })).rejects.toMatchObject({ reasonCode: "legacy_approved_action_inert" });

    const [settledRequest] = await db
      .select()
      .from(toolActionRequests)
      .where(eq(toolActionRequests.id, actionRequest.id));
    const [settledInvocation] = await db
      .select()
      .from(toolInvocations)
      .where(eq(toolInvocations.id, invocation.id));
    expect(settledRequest.status).toBe("failed");
    expect(settledInvocation.status).toBe("failed");
    expect(settledInvocation.errorCode).toBe("legacy_approved_action_inert");
    expect(settledInvocation.idempotencyKey).toBeNull();

    await expect(gateway.executeTool({
      sessionToken: session.token,
      tool: "mcp-remote-fixture:update_note",
      parameters,
    })).rejects.toMatchObject({ reasonCode: "approval_required" });
    expect(await db.select().from(toolActionRequests)).toHaveLength(2);
  });

  it("does not let a stale legacy consumer overwrite the winning approved execution", async () => {
    const { company, agent, run } = await createRunFixture(db);
    await db.insert(toolPolicies).values({
      companyId: company.id,
      name: "Review note writes",
      policyType: "require_approval",
      selectors: { toolName: "mcp-remote-fixture:update_note" },
    });

    let observeLegacyClaim!: () => void;
    const legacyClaimObserved = new Promise<void>((resolve) => {
      observeLegacyClaim = resolve;
    });
    let releaseLegacyClaim!: () => void;
    const legacyClaimBlocked = new Promise<void>((resolve) => {
      releaseLegacyClaim = resolve;
    });
    const gateway = createTestToolGatewayService(db, {
      beforeLegacyApprovedActionClaim: async () => {
        observeLegacyClaim();
        await legacyClaimBlocked;
      },
    });
    const session = await gateway.createSession({
      companyId: company.id,
      agentId: agent.id,
      runId: run.id,
    });
    const parameters = { noteId: "n1", body: "legacy race" };

    await expect(gateway.executeTool({
      sessionToken: session.token,
      tool: "mcp-remote-fixture:update_note",
      parameters,
    })).rejects.toMatchObject({ reasonCode: "approval_required" });
    const [actionRequest] = await db.select().from(toolActionRequests);
    const [invocation] = await db.select().from(toolInvocations);
    const currentSignature = actionRequest.signedArguments!;
    const legacySignature = signToolArguments({
      invocationId: invocation.id,
      toolName: invocation.toolName,
      canonicalArguments: canonicalToolArguments(parameters),
      signingSecret: testToolActionSigningSecret,
    });
    await db
      .update(toolActionRequests)
      .set({ signedArguments: legacySignature })
      .where(eq(toolActionRequests.id, actionRequest.id));
    await gateway.approveActionRequest({
      companyId: company.id,
      actionRequestId: actionRequest.id,
      actor: { userId: "board-user" },
    });

    const staleAttempt = gateway.executeTool({
      sessionToken: session.token,
      tool: "mcp-remote-fixture:update_note",
      approvedActionRequestId: actionRequest.id,
      parameters,
    }).then(
      (value) => ({ status: "fulfilled" as const, value }),
      (error: unknown) => ({ status: "rejected" as const, error }),
    );
    await legacyClaimObserved;

    // Simulate a concurrent repair that restores the current signed envelope
    // after the stale consumer has read the legacy envelope but before it owns
    // the approved -> executing claim.
    await db
      .update(toolActionRequests)
      .set({ signedArguments: currentSignature, updatedAt: new Date() })
      .where(and(
        eq(toolActionRequests.id, actionRequest.id),
        eq(toolActionRequests.status, "approved"),
      ));
    const winner = await gateway.executeTool({
      sessionToken: session.token,
      tool: "mcp-remote-fixture:update_note",
      approvedActionRequestId: actionRequest.id,
      parameters,
    });
    expect(winner.status).toBe("completed");

    releaseLegacyClaim();
    const stale = await staleAttempt;
    expect(stale).toMatchObject({
      status: "rejected",
      error: { reasonCode: "action_already_consumed" },
    });

    const [settledRequest] = await db
      .select()
      .from(toolActionRequests)
      .where(eq(toolActionRequests.id, actionRequest.id));
    const [settledInvocation] = await db
      .select()
      .from(toolInvocations)
      .where(eq(toolInvocations.id, invocation.id));
    expect(settledRequest.status).toBe("executed");
    expect(settledInvocation).toMatchObject({
      status: "succeeded",
      errorCode: null,
      errorMessage: null,
    });
    expect(settledInvocation.idempotencyKey).not.toBeNull();
  });

  it("does not leave unsigned action requests pending when signing is unavailable", async () => {
    vi.stubEnv("PAPERCLIP_TOOL_ACTION_SIGNING_SECRET", "");
    const { company, agent, run } = await createRunFixture(db);
    await db.insert(toolPolicies).values({
      companyId: company.id,
      name: "Review note writes",
      policyType: "require_approval",
      selectors: { toolName: "mcp-remote-fixture:update_note" },
    });
    const gateway = createTestToolGatewayService(db, { toolActionSigningSecret: " " });
    const session = await gateway.createSession({
      companyId: company.id,
      agentId: agent.id,
      runId: run.id,
    });

    await expect(gateway.executeTool({
      sessionToken: session.token,
      tool: "mcp-remote-fixture:update_note",
      parameters: { noteId: "n1", body: "reviewed body" },
    })).rejects.toMatchObject({ reasonCode: "signing_secret_unconfigured" });

    const [actionRequest] = await db.select().from(toolActionRequests);
    expect(actionRequest).toMatchObject({
      status: "cancelled",
      signedArguments: null,
    });
    const [invocation] = await db.select().from(toolInvocations);
    expect(invocation).toMatchObject({
      status: "failed",
      errorCode: "signing_secret_unconfigured",
    });
  });

  it("explains how to recover when an approval-required session has no task", async () => {
    const company = await db.insert(companies).values({
      name: `Gateway ${randomUUID()}`,
      issuePrefix: `TG${randomUUID().slice(0, 6).toUpperCase()}`,
    }).returning().then((rows) => rows[0]!);
    const agent = await db.insert(agents).values({
      companyId: company.id,
      name: `Gateway Agent ${randomUUID()}`,
      role: "engineer",
      adapterType: "process",
      adapterConfig: {},
      runtimeConfig: {},
      permissions: {},
    }).returning().then((rows) => rows[0]!);
    const run = await db.insert(heartbeatRuns).values({
      companyId: company.id,
      agentId: agent.id,
      invocationSource: "assignment",
      status: "running",
      contextSnapshot: {},
    }).returning().then((rows) => rows[0]!);
    await db.insert(toolPolicies).values({
      companyId: company.id,
      name: "Review note writes",
      policyType: "require_approval",
      selectors: { toolName: "mcp-remote-fixture:update_note" },
    });
    const gateway = createTestToolGatewayService(db);
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id });

    await expect(gateway.executeTool({
      sessionToken: session.token,
      tool: "mcp-remote-fixture:update_note",
      parameters: { noteId: "n1", body: "no task" },
    })).rejects.toMatchObject({
      reasonCode: "approval_path_missing",
      details: {
        instructions: "This session is not attached to a task, so an approval card cannot be posted. Re-run this action from a run that has the task checked out.",
      },
    });
  });

  it("cancels a stale pending action request when direct approval sees an invalid signature", async () => {
    const { company, agent, run } = await createRunFixture(db);
    await db.insert(toolPolicies).values({
      companyId: company.id,
      name: "Review note writes",
      policyType: "require_approval",
      selectors: { toolName: "mcp-remote-fixture:update_note" },
    });
    const gateway = createTestToolGatewayService(db);
    const session = await gateway.createSession({
      companyId: company.id,
      agentId: agent.id,
      runId: run.id,
    });
    await expect(gateway.executeTool({
      sessionToken: session.token,
      tool: "mcp-remote-fixture:update_note",
      parameters: { noteId: "n1", body: "reviewed body" },
    })).rejects.toMatchObject({ reasonCode: "approval_required" });
    const [actionRequest] = await db.select().from(toolActionRequests);
    await db
      .update(toolActionRequests)
      .set({ signedArguments: "stale-invalid-signature" })
      .where(eq(toolActionRequests.id, actionRequest.id));

    await expect(gateway.approveActionRequest({
      companyId: company.id,
      actionRequestId: actionRequest.id,
      actor: { userId: "board-user" },
    })).rejects.toMatchObject({
      reasonCode: "action_request_invalidated",
      message: "Tool action request is no longer approvable; refresh the review queue",
    });
    const [cancelled] = await db.select().from(toolActionRequests).where(eq(toolActionRequests.id, actionRequest.id));
    expect(cancelled.status).toBe("cancelled");
  });

  it("declines a pending action request and rejects the invocation (PAP-10859)", async () => {
    const { company, agent, run } = await createRunFixture(db);
    await db.insert(toolPolicies).values({
      companyId: company.id,
      name: "Review note writes",
      policyType: "require_approval",
      selectors: { toolName: "mcp-remote-fixture:update_note" },
    });
    const gateway = createTestToolGatewayService(db);
    const session = await gateway.createSession({
      companyId: company.id,
      agentId: agent.id,
      runId: run.id,
    });

    await expect(gateway.executeTool({
      sessionToken: session.token,
      tool: "mcp-remote-fixture:update_note",
      parameters: { noteId: "n1", body: "short" },
    })).rejects.toMatchObject({ reasonCode: "approval_required" });

    const [actionRequest] = await db.select().from(toolActionRequests);
    const declined = await gateway.declineActionRequest({
      companyId: company.id,
      actionRequestId: actionRequest.id,
      actor: { userId: "board-user" },
    });
    expect(declined.status).toBe("rejected");
    expect(declined.resolvedByUserId).toBe("board-user");
    expect(declined.decidedByUserId).toBe("board-user");
    expect(declined.decidedAt).toBeInstanceOf(Date);

    const [invocation] = await db.select().from(toolInvocations);
    expect(invocation.approvalState).toBe("rejected");

    // Declining again is idempotent; approving a declined request is refused.
    const again = await gateway.declineActionRequest({
      companyId: company.id,
      actionRequestId: actionRequest.id,
      actor: { userId: "board-user" },
    });
    expect(again.status).toBe("rejected");
    await expect(gateway.approveActionRequest({
      companyId: company.id,
      actionRequestId: actionRequest.id,
      actor: { userId: "board-user" },
    })).rejects.toMatchObject({ reasonCode: "action_not_pending" });
    await expect(gateway.executeTool({
      sessionToken: session.token,
      tool: "mcp-remote-fixture:update_note",
      parameters: { noteId: "n1", body: "short" },
    })).rejects.toMatchObject({ reasonCode: "action_declined" });
  });

  it("expires a stale identical request and creates a fresh approval", async () => {
    const { company, agent, run } = await createRunFixture(db);
    await db.insert(toolPolicies).values({
      companyId: company.id,
      name: "Review note writes",
      policyType: "require_approval",
      selectors: { toolName: "mcp-remote-fixture:update_note" },
    });
    const gateway = createTestToolGatewayService(db);
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id });
    const parameters = { noteId: "n1", body: "expires" };
    await expect(gateway.executeTool({ sessionToken: session.token, tool: "mcp-remote-fixture:update_note", parameters }))
      .rejects.toMatchObject({ reasonCode: "approval_required" });
    const [stale] = await db.select().from(toolActionRequests);
    await db.update(toolActionRequests).set({ expiresAt: new Date(Date.now() - 1_000) }).where(eq(toolActionRequests.id, stale.id));

    await expect(gateway.executeTool({ sessionToken: session.token, tool: "mcp-remote-fixture:update_note", parameters }))
      .rejects.toMatchObject({ reasonCode: "approval_required" });
    const requests = await db.select().from(toolActionRequests).orderBy(toolActionRequests.createdAt);
    expect(requests).toHaveLength(2);
    expect(requests[0]?.status).toBe("expired");
    expect(requests[1]?.status).toBe("pending");
  });

  it("cannot approve an opaque plugin into a missing model liability contract", async () => {
    const {company,agent,run}=await createRunFixture(db); const dispatcher=fakePluginDispatcher(); const invoke=vi.spyOn(dispatcher,"executeTool");
    const gateway=createTestToolGatewayService(db,{pluginToolDispatcher:dispatcher});
    await db.insert(toolPolicies).values({companyId:company.id,name:"Review plugin",policyType:"require_approval",selectors:{toolName:"fixture:delete_everything"}});
    const session=await gateway.createSession({companyId:company.id,agentId:agent.id,runId:run.id});
    await expect(gateway.executeTool({sessionToken:session.token,tool:"fixture:delete_everything",parameters:{target:"repo"}})).rejects.toMatchObject({reasonCode:"tool_model_effect_unqualified"});
    expect(invoke).not.toHaveBeenCalled();expect(await db.select().from(toolActionRequests)).toEqual([]);expect(await db.select().from(approvals)).toEqual([]);
  });

  it("maps remote MCP elicitation to a durable issue interaction", async () => {
    const { company, agent, run } = await createRunFixture(db);
    await createRemoteMcpToolFixture(db, company.id);
    await db.insert(toolPolicies).values({
      companyId: company.id,
      name: "Allow read tools",
      policyType: "allow",
      selectors: { riskLevel: "read" },
    });
    const originalFetch = globalThis.fetch;
    globalThis.fetch = async (_url, init) => new Response(JSON.stringify({
      jsonrpc: "2.0",
      id: JSON.parse(String(init?.body)).id,
      result: {
        _meta: {
          elicitation: {
            message: "Which workspace should be used?",
            requestedSchema: {
              type: "object",
              required: ["workspace"],
              properties: {
                workspace: {
                  title: "Workspace",
                  enum: ["ops", "engineering"],
                },
              },
            },
          },
        },
        content: [],
      },
    }), { status: 200, headers: { "content-type": "application/json" } });
    try {
      const gateway = createTestToolGatewayService(db);
      const session = await gateway.createSession({
        companyId: company.id,
        agentId: agent.id,
        runId: run.id,
      });
      const tool = (await gateway.listToolsForSession(session.token))
        .find((candidate) => candidate.providerType === "mcp_remote_http");
      expect(tool).toBeTruthy();

      await expect(gateway.executeTool({
        sessionToken: session.token,
        tool: tool!.name,
        parameters: {},
      })).rejects.toMatchObject({ reasonCode: "elicitation_required" });

      const [interaction] = await db.select().from(issueThreadInteractions);
      expect(interaction).toMatchObject({
        kind: "ask_user_questions",
        status: "pending",
        issueId: session.issueId,
      });
      expect(interaction.payload).toMatchObject({
        title: "Which workspace should be used?",
        questions: [
          {
            id: "workspace",
            prompt: "Workspace",
            required: true,
            options: [{ id: "ops", label: "ops" }, { id: "engineering", label: "engineering" }],
          },
        ],
      });
      const [invocation] = await db.select().from(toolInvocations);
      expect(invocation).toMatchObject({
        status: "awaiting_approval",
        errorCode: "elicitation_required",
      });
      const [event] = await db.select().from(toolCallEvents).where(eq(toolCallEvents.reasonCode, "elicitation_required"));
      expect(event).toMatchObject({
        outcome: "pending",
        decision: "defer_runtime",
      });
    } finally {
      globalThis.fetch = originalFetch;
    }
  });

  it("initializes a fresh Streamable HTTP session before a stateful tools/call", async () => {
    const { company, agent, run } = await createRunFixture(db);
    const { connection } = await createRemoteMcpToolFixture(db, company.id);
    await db.update(toolConnections).set({
      config: { url: "https://example.invalid/mcp", mcpSessionRequired: true },
    }).where(eq(toolConnections.id, connection.id));
    await db.insert(toolPolicies).values({
      companyId: company.id,
      name: "Allow read tools",
      policyType: "allow",
      selectors: { riskLevel: "read" },
    });
    const requests: Array<{ method: string; sessionId: string | null; protocolVersion: string | null }> = [];
    const gateway = createTestToolGatewayService(db, {
      remoteHttpRequest: async (_url, init) => {
        const payload = JSON.parse(String(init.body)) as { method?: string; id?: string };
        const headers = new Headers(init.headers);
        requests.push({
          method: payload.method ?? "",
          sessionId: headers.get("mcp-session-id"),
          protocolVersion: headers.get("mcp-protocol-version"),
        });
        if (payload.method === "initialize") {
          return new Response(JSON.stringify({
            jsonrpc: "2.0",
            id: payload.id,
            result: {
              protocolVersion: "2025-06-18",
              capabilities: { tools: {} },
              serverInfo: { name: "stateful", version: "1" },
            },
          }), {
            status: 200,
            headers: { "content-type": "application/json", "mcp-session-id": "session-123" },
          });
        }
        if (payload.method === "notifications/initialized") return new Response(null, { status: 202 });
        return new Response(JSON.stringify({
          jsonrpc: "2.0",
          id: payload.id,
          result: { content: [{ type: "text", text: "stateful ok" }] },
        }), { status: 200, headers: { "content-type": "application/json" } });
      },
    });
    const session = await gateway.createSession({
      companyId: company.id,
      agentId: agent.id,
      runId: run.id,
    });
    const tool = (await gateway.listToolsForSession(session.token))
      .find((candidate) => candidate.providerType === "mcp_remote_http");

    const result = await gateway.executeTool({
      sessionToken: session.token,
      tool: tool!.name,
      parameters: {},
    });

    expect(result.status).toBe("completed");
    expect(requests).toEqual([
      { method: "initialize", sessionId: null, protocolVersion: null },
      { method: "notifications/initialized", sessionId: "session-123", protocolVersion: "2025-06-18" },
      { method: "tools/call", sessionId: "session-123", protocolVersion: "2025-06-18" },
    ]);
  });

  it("hides cached Chat unread filters and blocks agent and board requests before provider dispatch", async () => {
    const { company, agent, run } = await createRunFixture(db);
    const { connection, catalogEntry } = await createRemoteMcpToolFixture(db, company.id);
    await db.update(toolConnections).set({
      lastCatalogRefreshAt: new Date(),
      config: {
        url: "https://8.8.8.8/mcp",
        sourceTemplateKey: "google-chat",
        connectionMethodKey: "customer-read-oauth",
        oauth: { scopes: ["https://www.googleapis.com/auth/chat.users.readstate.readonly"] },
      },
    }).where(eq(toolConnections.id, connection.id));
    await db.update(toolCatalogEntries).set({
      name: "search_messages", toolName: "search_messages", description: "Search unread messages.",
      inputSchema: { type: "object", properties: {
        searchParameters: { type: "object", properties: {
          isUnread: { type: "boolean" }, keywords: { type: "array", items: { type: "string" } },
        } },
      } },
    }).where(eq(toolCatalogEntries.id, catalogEntry.id));
    await db.insert(toolPolicies).values({
      companyId: company.id, name: "Allow Chat reads", policyType: "allow", selectors: { riskLevel: "read" },
    });
    const provider = vi.fn(async (_url, init) => {
      const payload = JSON.parse(String(init.body));
      if (payload.method === "notifications/initialized") return new Response(null, { status: 202 });
      return Response.json({ jsonrpc: "2.0", id: payload.id, result: payload.method === "initialize"
        ? { protocolVersion: "2025-06-18", capabilities: { tools: {} }, serverInfo: { name: "chat-fixture", version: "1" } }
        : { content: [{ type: "text", text: "Found matching messages." }] } });
    });
    const gateway = createTestToolGatewayService(db, { remoteHttpRequest: provider });
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id });
    const tool = (await gateway.listToolsForSession(session.token))
      .find((candidate) => candidate.upstreamToolName === "search_messages")!;
    expect(tool).toBeTruthy();
    expect(JSON.stringify(tool.parametersSchema)).not.toContain("isUnread");
    expect(tool.description).toContain("Read/unread filtering is not supported.");
    const catalog = await toolAccessService(db).listCatalog(connection.id, company.id);
    expect(JSON.stringify(catalog[0].inputSchema)).not.toContain("isUnread");
    expect(catalog[0].description).toContain("Read/unread filtering is not supported.");

    for (const isUnread of [true, false]) {
      const parameters = { searchParameters: { isUnread, keywords: ["release"] } };
      const error = { status: 400, details: { code: "google_chat_unread_filter_unsupported" } };
      await expect(gateway.executeTool({ sessionToken: session.token, tool: tool.name, parameters }))
        .rejects.toMatchObject(error);
      await expect(gateway.executeTestCall({
        companyId: company.id, connectionId: connection.id, agentId: agent.id,
        userId: "board", toolName: "search_messages", parameters,
      })).rejects.toMatchObject(error);
    }
    expect(provider).not.toHaveBeenCalled();

    const parameters = { searchParameters: { keywords: ["release"], startTime: "2026-09-22T00:00:00Z" }, pageSize: 10 };
    await expect(gateway.executeTool({ sessionToken: session.token, tool: tool.name, parameters }))
      .resolves.toMatchObject({ status: "completed" });
    const calls = provider.mock.calls.map(([, init]) => JSON.parse(String(init.body)))
      .filter((payload) => payload.method === "tools/call");
    expect(calls).toHaveLength(1);
    expect(calls[0].params).toEqual({ name: "search_messages", arguments: parameters });
  });

  it("explains Google Workspace preview enrollment when a tool call is denied", async () => {
    const { company, agent, run } = await createRunFixture(db);
    const { connection } = await createRemoteMcpToolFixture(db, company.id);
    await db.update(toolConnections).set({
      config: {
        url: "https://drivemcp.googleapis.com/mcp/v1",
        sourceTemplateKey: "google-drive",
      },
    }).where(eq(toolConnections.id, connection.id));
    await db.insert(toolPolicies).values({
      companyId: company.id,
      name: "Allow Drive reads",
      policyType: "allow",
      selectors: { riskLevel: "read" },
    });
    const gateway = createTestToolGatewayService(db, {
      remoteHttpRequest: async (_url, init) => {
        const requestBody = JSON.parse(String(init.body)) as { id: string };
        return new Response(JSON.stringify({
          jsonrpc: "2.0",
          id: requestBody.id,
          result: {
            isError: true,
            content: [{ type: "text", text: "The caller does not have permission" }],
          },
        }), { status: 200, headers: { "content-type": "application/json" } });
      },
    });
    const session = await gateway.createSession({
      companyId: company.id,
      agentId: agent.id,
      runId: run.id,
    });
    const tool = (await gateway.listToolsForSession(session.token))
      .find((candidate) => candidate.providerType === "mcp_remote_http");

    await expect(gateway.executeTool({
      sessionToken: session.token,
      tool: tool!.name,
      parameters: {},
    })).rejects.toMatchObject({
      reasonCode: "tool_error",
      message: expect.stringContaining("enroll the signed-in Workspace account and this OAuth client's Google Cloud project"),
    });
  });

  it.each([
    ["token_run_cancel", 0, 1, "scoped_fixture_run_inactive"],
    ["initialize_grant_revoke", 1, 1, "scoped_tool_connection_changed"],
    ["notification_run_cancel", 2, 1, "scoped_fixture_run_inactive"],
    ["notification_destination_change", 2, 1, "scoped_tool_connection_changed"],
    ["call_grant_revoke", 1, 1, "scoped_tool_connection_changed"],
    ["unauthorized_refresh", 1, 1, "scoped_tool_connection_changed"],
    ["refresh_grant_revoke", 1, 2, "credential_grant_changed"],
    ["token_grant_revoke", 0, 1, "credential_grant_changed"],
    ["token_grant_revoke_ordinary", 0, 1, "credential_grant_changed"],
    ["healthy_refresh", 2, 2, null],
    ["healthy_last_rate_slot", 1, 1, null],
  ] as const)("fences scoped HTTP transport at native authority boundaries: %s", async (scenario, wireCount, tokenCount, reasonCode) => {
    const { company, agent, run } = await createRunFixture(db);
    const { connection } = await createRemoteMcpToolFixture(db, company.id);
    const initialize = scenario.startsWith("initialize_") || scenario.startsWith("notification_");
    await db.update(toolConnections).set({
      credentialSource: "vercel_connect",
      externalCredential: {
        provider: "vercel_connect", connectorId: "scoped-fixture", connectorUid: "scoped-fixture",
        service: "fixture", connectorType: "api-key", principalMode: "app",
        headerName: "Authorization", headerPrefix: "Bearer ", scopes: ["*"],
      },
      config: { ...connection.config, mcpSessionRequired: initialize },
    }).where(eq(toolConnections.id, connection.id));
    await db.update(connectionGrants).set({
      externalCredential: { provider: "vercel_connect", subjectType: "app" },
    }).where(eq(connectionGrants.connectionId, connection.id));
    await db.insert(toolPolicies).values({ companyId: company.id, name: "Scoped fixture reads",
      policyType: "allow", selectors: { riskLevel: "read" } });
    if (scenario === "healthy_last_rate_slot") await db.insert(toolPolicies).values({
      companyId: company.id, name: "Single native slot", policyType: "rate_limit", priority: -999,
      selectors: { connectionId: connection.id }, config: { rateLimit: { limit: 1, windowSeconds: 3600 } },
    });
    const revokeGrant = () => db.update(connectionGrants).set({ status: "revoked", revokedAt: new Date() })
      .where(eq(connectionGrants.connectionId, connection.id));
    const getToken = vi.fn<VercelConnectClient["getToken"]>(async (_request, options) => {
      if (scenario === "token_run_cancel") {
        await db.update(heartbeatRuns).set({ status: "cancelled" }).where(eq(heartbeatRuns.id, run.id));
      }
      if (scenario.startsWith("token_grant_revoke") || scenario === "refresh_grant_revoke" && options?.forceRefresh) await revokeGrant();
      return { token: options?.forceRefresh ? "scoped-fresh-fixture-key" : "scoped-stale-fixture-key",
        tokenId: options?.forceRefresh ? "fixture-fresh" : "fixture-stale", expiresAt: Date.now() + 60_000,
        connector: { id: "scoped-fixture", uid: "scoped-fixture", type: "api-key" } };
    });
    const wireMethods: string[] = [];
    const gateway = createTestToolGatewayService(db, {
      vercelConnectClient: { getConnectorMetadata: vi.fn(), getToken, startAuthorization: vi.fn(),
        revoke: vi.fn(), evict: vi.fn() },
      remoteHttpRequest: async (_url, init) => {
        const request = JSON.parse(String(init.body)) as { id?: string; method: string };
        wireMethods.push(request.method);
        if (request.method === "initialize") {
          if (scenario === "initialize_grant_revoke") await revokeGrant();
          return new Response(JSON.stringify({ jsonrpc: "2.0", id: request.id, result: {
            protocolVersion: "2025-03-26", capabilities: {}, serverInfo: { name: "private-fixture", version: "1" },
          } }), { headers: { "content-type": "application/json", "mcp-session-id": randomUUID() } });
        }
        if (request.method === "notifications/initialized") {
          if (scenario === "notification_run_cancel") await db.update(heartbeatRuns)
            .set({ status: "cancelled" }).where(eq(heartbeatRuns.id, run.id));
          if (scenario === "notification_destination_change") await db.update(toolConnections)
            .set({ config: { url: "https://1.1.1.1/mcp", mcpSessionRequired: true } }).where(eq(toolConnections.id, connection.id));
          return new Response(null, { status: 202 });
        }
        if (scenario === "call_grant_revoke") await revokeGrant();
        if (scenario.endsWith("refresh") || scenario === "refresh_grant_revoke") {
          if (wireMethods.length === 1) {
            if (scenario === "unauthorized_refresh") await revokeGrant();
            return new Response(null, { status: 401 });
          }
        }
        return new Response(JSON.stringify({ jsonrpc: "2.0", id: request.id,
          result: { content: [{ type: "text", text: "private-scoped-fixture-output" }] },
        }), { headers: { "content-type": "application/json" } });
      },
    });
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id });
    const context: ScopedToolGatewayContext = { session, assertCurrent: async () => {
      const [current] = await db.select({ status: heartbeatRuns.status }).from(heartbeatRuns)
        .where(eq(heartbeatRuns.id, run.id));
      if (current?.status !== "running") throw new ToolGatewayHttpError(403, "Fixture execution stopped", "scoped_fixture_run_inactive");
    } };
    const tool = (await gateway.listScopedTools(context)).find(candidate => candidate.providerType === "mcp_remote_http")!;
    const ordinary = scenario === "token_grant_revoke_ordinary";
    const call = gateway.executeTool({ sessionToken: ordinary ? session.token : "", tool: tool.name, parameters: {} },
      undefined, ordinary ? undefined : context);
    if (reasonCode) {
      await expect(call).rejects.toMatchObject({ reasonCode,
        ...(scenario === "token_run_cancel" ? { details: { execution: { request: { dispatched: false } } } } : {}),
      });
    } else expect((await call).status).toBe("completed");
    expect(wireMethods).toHaveLength(wireCount);
    expect(getToken).toHaveBeenCalledTimes(tokenCount);
    if (initialize) expect(wireMethods).not.toContain("tools/call");
    const invocations = await db.select().from(toolInvocations).where(eq(toolInvocations.companyId, company.id));
    expect(invocations).toHaveLength(1);
    expect(invocations[0]?.status).toBe(reasonCode ? "failed" : "succeeded");
    if (scenario === "healthy_last_rate_slot") {
      const counters = await db.select().from(toolRateLimitCounters).where(eq(toolRateLimitCounters.companyId, company.id));
      expect(counters).toHaveLength(1);
      expect(counters[0]?.remaining).toBe(0);
    }
    if (reasonCode) expect(invocations[0]?.workflowResultJson).toBeNull();
    if (scenario.includes("grant_revoke") || scenario === "unauthorized_refresh") {
      const [retainedGrant] = await db.select().from(connectionGrants).where(eq(connectionGrants.connectionId, connection.id));
      expect(retainedGrant?.status).toBe("revoked");
      expect(retainedGrant?.revokedAt).toBeInstanceOf(Date);
    }
    const audits = await db.select().from(toolAccessAuditEvents).where(eq(toolAccessAuditEvents.companyId, company.id));
    const calls = await db.select().from(toolCallEvents).where(eq(toolCallEvents.companyId, company.id));
    const persisted = JSON.stringify({ invocations, audits, calls });
    expect(persisted).not.toContain("scoped-stale-fixture-key");
    expect(persisted).not.toContain("scoped-fresh-fixture-key");
    if (reasonCode) expect(persisted).not.toContain("private-scoped-fixture-output");
  });

  it("injects Vercel tokens at dispatch and refreshes exactly once after an upstream 401", async () => {
    const { company, agent, run } = await createRunFixture(db);
    const { connection } = await createRemoteMcpToolFixture(db, company.id);
    await db.update(toolConnections).set({
      credentialSource: "vercel_connect",
      externalCredential: {
        provider: "vercel_connect",
        connectorId: "scl_posthog",
        connectorUid: "posthog-paperclip",
        service: "posthog",
        connectorType: "api-key",
        principalMode: "app",
        headerName: "Authorization",
        headerPrefix: "Bearer ",
        scopes: ["*"],
      },
      credentialRefs: [],
      credentialSecretRefs: [],
    }).where(eq(toolConnections.id, connection.id));
    await db.update(connectionGrants).set({
      externalCredential: { provider: "vercel_connect", subjectType: "app" },
      credentialSecretRefs: [],
    }).where(eq(connectionGrants.connectionId, connection.id));
    await db.insert(toolPolicies).values({
      companyId: company.id,
      name: "Allow Vercel-backed reads",
      policyType: "allow",
      selectors: { riskLevel: "read" },
    });

    const getToken = vi.fn<VercelConnectClient["getToken"]>(async (_request, options) => ({
      token: options?.forceRefresh ? "fresh-provider-bearer" : "stale-provider-bearer",
      tokenId: options?.forceRefresh ? "stk_fresh" : "stk_stale",
      expiresAt: Date.now() + 60_000,
      connector: { id: "scl_posthog", uid: "posthog-paperclip", type: "api-key" },
    }));
    const evict = vi.fn<VercelConnectClient["evict"]>();
    const vercelConnectClient: VercelConnectClient = {
      getConnectorMetadata: vi.fn(),
      getToken,
      startAuthorization: vi.fn(),
      revoke: vi.fn(),
      evict,
    };
    const authorizationHeaders: string[] = [];
    const gateway = createTestToolGatewayService(db, {
      vercelConnectClient,
      remoteHttpRequest: async (_url, init) => {
        authorizationHeaders.push(new Headers(init.headers).get("authorization") ?? "");
        if (authorizationHeaders.length === 1) return new Response(null, { status: 401 });
        const requestBody = JSON.parse(String(init.body)) as { id: string };
        return new Response(JSON.stringify({
          jsonrpc: "2.0",
          id: requestBody.id,
          result: { content: [{ type: "text", text: "posthog result" }] },
        }), { status: 200, headers: { "content-type": "application/json" } });
      },
    });
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id });
    const tool = (await gateway.listToolsForSession(session.token))
      .find((candidate) => candidate.providerType === "mcp_remote_http");

    const result = await gateway.executeTool({
      sessionToken: session.token,
      tool: tool!.name,
      parameters: {},
    });

    expect(result.status).toBe("completed");
    expect(authorizationHeaders).toEqual([
      "Bearer stale-provider-bearer",
      "Bearer fresh-provider-bearer",
    ]);
    expect(getToken).toHaveBeenCalledTimes(2);
    expect(getToken.mock.calls[1]?.[1]).toEqual({ forceRefresh: true });
    expect(evict).toHaveBeenCalledTimes(1);

    const [storedConnection] = await db.select().from(toolConnections).where(eq(toolConnections.id, connection.id));
    const [storedGrant] = await db.select().from(connectionGrants).where(eq(connectionGrants.connectionId, connection.id));
    const audits = await db.select().from(toolAccessAuditEvents).where(eq(toolAccessAuditEvents.companyId, company.id));
    const calls = await db.select().from(toolCallEvents).where(eq(toolCallEvents.companyId, company.id));
    const persisted = JSON.stringify({ storedConnection, storedGrant, audits, calls });
    expect(persisted).not.toContain("stale-provider-bearer");
    expect(persisted).not.toContain("fresh-provider-bearer");
    expect(storedGrant?.externalCredential).toMatchObject({ tokenId: "stk_fresh" });
  });

  it("keeps managed GitHub personal identity even under a legacy shared policy", async () => {
    const { company, agent, issue, run } = await createRunFixture(db);
    const { connection } = await createRemoteMcpToolFixture(db, company.id);
    await db.update(toolConnections).set({ authKind: "oauth", credentialSource: "paperclip_vault",
      config: { ...connection.config, sourceTemplateKey: "github" },
    }).where(eq(toolConnections.id, connection.id));
    await db.insert(toolConnectionInstalls).values({ companyId: company.id,
      connectionId: connection.id, targetType: "agent", targetId: agent.id });
    await db.insert(companyMemberships).values(["A", "B"].map(principalId => ({ companyId: company.id,
      principalType: "user", principalId, status: "active", membershipRole: "member" })));
    const grants = await db.insert(connectionGrants).values(["A", "B"].map(subjectUserId => ({
      companyId: company.id, connectionId: connection.id, kind: "user", subjectUserId,
      status: "active", credentialSecretRefs: [],
    }))).returning();
    await initializeRunIdentity(db, { companyId: company.id, runId: run.id, issueId: issue.id,
      responsibleUserId: "A", cause: "instruction" });
    await db.insert(toolPolicies).values({ companyId: company.id, name: "Allow reads",
      policyType: "allow", selectors: { riskLevel: "read" } });
    const resolvedGrants: string[] = [];
    const gateway = createTestToolGatewayService(db, {
      oauthGrantRefresher: async ({ grantId }) => {
        resolvedGrants.push(grantId);
        return db.select().from(connectionGrants).where(eq(connectionGrants.id, grantId)).then(rows => rows[0]!);
      },
      remoteHttpRequest: async (_url, init) => new Response(JSON.stringify({ jsonrpc: "2.0",
        id: JSON.parse(String(init.body)).id, result: { content: [{ type: "text", text: "ok" }] },
      }), { status: 200, headers: { "content-type": "application/json" } }),
    });
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id });
    const tool = (await gateway.listToolsForSession(session.token)).find(t => t.providerType === "mcp_remote_http")!;
    for (const [index, user] of ["A", "B", "A"].entries()) {
      if (index > 0) {
        const [message] = await db.insert(issueComments).values({ companyId: company.id, issueId: issue.id,
          authorUserId: user, body: "Next instruction" }).returning();
        const pending = await reserveSteeredIdentity(db, { companyId: company.id, runId: run.id,
          issueId: issue.id, messageId: message.id });
        await reconcileSteeredIdentity(db, pending!);
      }
      expect((await gateway.executeTool({ sessionToken: session.token, tool: tool.name, parameters: {} })).status).toBe("completed");
    }
    expect(resolvedGrants).toEqual([grants[0].id, grants[1].id, grants[0].id]);
    await db.delete(companyMemberships).where(eq(companyMemberships.companyId, company.id));
    await expect(gateway.executeTool({ sessionToken: session.token, tool: tool.name, parameters: {} }))
      .rejects.toMatchObject({ reasonCode: "grant_owner_membership_inactive" });
    expect(resolvedGrants).toHaveLength(3);
  });

  it.each([false, true])("reselects a duplicate only before GitHub dispatch (upstream failure: %s)", async (upstreamFailure) => {
    const { company, agent, issue, run } = await createRunFixture(db);
    const first = await createRemoteMcpToolFixture(db, company.id);
    await db.update(toolApplications).set({ name: "Older GitHub" }).where(eq(toolApplications.id, first.application.id));
    const fixtures = [first, await createRemoteMcpToolFixture(db, company.id)];
    const grants = [];
    for (const [index, { connection }] of fixtures.entries()) {
      const secret = await secretService(db).create(company.id, {
        provider: "local_encrypted", name: `GitHub ${index}`, key: `github.${randomUUID()}`, value: `token-${index}`,
      });
      await db.insert(companySecretBindings).values({ companyId: company.id, secretId: secret.id,
        targetType: "tool_connection", targetId: connection.id, configPath: "oauth.access_token" });
      await db.update(toolConnections).set({ authKind: "oauth", credentialSource: "paperclip_vault",
        config: { ...connection.config, sourceTemplateKey: "github" },
      }).where(eq(toolConnections.id, connection.id));
      await db.insert(toolConnectionInstalls).values({ companyId: company.id,
        connectionId: connection.id, targetType: "agent", targetId: agent.id });
      const [grant] = await db.insert(connectionGrants).values({ companyId: company.id,
        connectionId: connection.id, kind: "agent", subjectAgentId: agent.id, status: "active",
        createdAt: new Date(index === 0 ? "2026-01-01" : "2026-02-01"),
        credentialSecretRefs: [{ secretId: secret.id, configPath: "oauth.access_token", versionSelector: "latest" }],
        providerTenant: { github: { userId: "42", login: "octocat", installationCount: 1,
          repositoryCount: 1, repositorySelection: "all", installationIds: ["101"] } },
      }).returning();
      grants.push(grant!);
    }
    await initializeRunIdentity(db, { companyId: company.id, runId: run.id, issueId: issue.id,
      responsibleUserId: "A", cause: "instruction" });
    await db.insert(toolPolicies).values({ companyId: company.id, name: "Allow reads",
      policyType: "allow", selectors: { riskLevel: "read" } });
    const refreshed: string[] = [];
    const dispatched = vi.fn(async (_url: string, init: RequestInit) => {
      expect(new Headers(init.headers).get("authorization")).toBe(`Bearer token-${upstreamFailure ? 1 : 0}`);
      return new Response(JSON.stringify({ jsonrpc: "2.0", id: JSON.parse(String(init.body)).id,
        result: { content: [{ type: "text", text: "ok" }] } }),
      { status: upstreamFailure ? 500 : 200, headers: { "content-type": "application/json" } });
    });
    const gateway = createTestToolGatewayService(db, {
      oauthGrantRefresher: async ({ grantId }) => {
        refreshed.push(grantId);
        if (!upstreamFailure && grantId === grants[1]!.id) {
          await db.update(connectionGrants).set({ status: "revoked" }).where(eq(connectionGrants.id, grantId));
          throw new Error("refresh invalidated the selected authorization");
        }
        return grants.find(grant => grant.id === grantId)!;
      }, remoteHttpRequest: dispatched,
    });
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id });
    const tool = (await gateway.listToolsForSession(session.token)).find(t => t.providerType === "mcp_remote_http")!;
    const execution = gateway.executeTool({ sessionToken: session.token, tool: tool.name, parameters: {} });
    if (upstreamFailure) await expect(execution).rejects.toMatchObject({ status: 502 });
    else expect((await execution).status).toBe("completed");
    expect(dispatched).toHaveBeenCalledTimes(1);
    expect(refreshed).toEqual(upstreamFailure ? [grants[1]!.id] : [grants[1]!.id, grants[0]!.id]);
  });

  it("refreshes a customer OAuth grant once and retries after an upstream 401", async () => {
    const { company, agent, run } = await createRunFixture(db);
    const { connection } = await createRemoteMcpToolFixture(db, company.id);
    const accessSecret = await secretService(db).create(company.id, {
      provider: "local_encrypted",
      name: "Customer OAuth access token",
      key: `gateway.oauth.${randomUUID()}`,
      value: "stale-customer-token",
    });
    await db.insert(companySecretBindings).values({
      companyId: company.id,
      secretId: accessSecret.id,
      targetType: "tool_connection",
      targetId: connection.id,
      configPath: "oauth.access_token",
    });
    await db.update(toolConnections).set({
      authKind: "oauth",
      credentialSource: "paperclip_vault",
      credentialRefs: [{ name: "oauth.access_token", placement: "header", key: "Authorization", prefix: "Bearer ", secretId: accessSecret.id, versionSelector: "latest" }],
      config: {
        url: "https://example.invalid/mcp",
        oauth: {
          provider: "fixture",
          tokenUrl: "https://example.invalid/oauth/token",
          expiresAt: new Date(Date.now() + 60 * 60 * 1000).toISOString(),
        },
      },
    }).where(eq(toolConnections.id, connection.id));
    const [grant] = await db.select().from(connectionGrants).where(eq(
      connectionGrants.connectionId,
      connection.id,
    ));
    await db.update(connectionGrants).set({
      credentialSecretRefs: [{
        secretId: accessSecret.id,
        versionSelector: "latest",
        configPath: "oauth.access_token",
        required: true,
        label: "OAuth access token",
      }],
      providerTenant: {
        oauth: {
          strategy: "direct_oauth",
          accessTokenExpiresAt: new Date(Date.now() + 60 * 60 * 1000).toISOString(),
        },
      },
    }).where(eq(connectionGrants.id, grant.id));
    await db.insert(toolPolicies).values({
      companyId: company.id,
      name: "Allow customer OAuth reads",
      policyType: "allow",
      selectors: { riskLevel: "read" },
    });

    const oauthGrantRefresher: NonNullable<ToolGatewayServiceOptions["oauthGrantRefresher"]> = vi.fn(async (input) => {
      if (input.forceRefresh) {
        await secretService(db).rotate(accessSecret.id, { value: "fresh-customer-token" });
      }
      return db.select().from(connectionGrants).where(eq(connectionGrants.id, input.grantId))
        .then((rows) => rows[0]!);
    });
    const authorizationHeaders: string[] = [];
    const gateway = createTestToolGatewayService(db, {
      oauthGrantRefresher,
      remoteHttpRequest: async (_url, init) => {
        authorizationHeaders.push(new Headers(init.headers).get("authorization") ?? "");
        if (authorizationHeaders.length === 1) return new Response(null, { status: 401 });
        const requestBody = JSON.parse(String(init.body)) as { id: string };
        return new Response(JSON.stringify({
          jsonrpc: "2.0",
          id: requestBody.id,
          result: { content: [{ type: "text", text: "customer OAuth result" }] },
        }), { status: 200, headers: { "content-type": "application/json" } });
      },
    });
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id });
    const tool = (await gateway.listToolsForSession(session.token))
      .find((candidate) => candidate.providerType === "mcp_remote_http");

    const result = await gateway.executeTool({
      sessionToken: session.token,
      tool: tool!.name,
      parameters: {},
    });

    expect(result.status).toBe("completed");
    expect(authorizationHeaders).toEqual([
      "Bearer stale-customer-token",
      "Bearer fresh-customer-token",
    ]);
    expect(oauthGrantRefresher).toHaveBeenCalledTimes(2);
    expect(vi.mocked(oauthGrantRefresher).mock.calls[1]?.[0]).toMatchObject({ forceRefresh: true });
  });

  it("marks a managed OAuth grant reconnect-required after one rejected refresh retry", async () => {
    const { company, agent, run } = await createRunFixture(db);
    const { connection } = await createRemoteMcpToolFixture(db, company.id);
    const accessSecret = await secretService(db).create(company.id, {
      provider: "local_encrypted",
      name: "Managed OAuth access token",
      key: `gateway.managed-oauth.${randomUUID()}`,
      value: "stale-managed-token",
    });
    await db.insert(companySecretBindings).values({
      companyId: company.id,
      secretId: accessSecret.id,
      targetType: "tool_connection",
      targetId: connection.id,
      configPath: "oauth.access_token",
    });
    await db.update(toolConnections).set({
      authKind: "oauth",
      credentialSource: "paperclip_vault",
      config: {
        url: "https://example.invalid/mcp",
        oauth: {
          strategy: "paperclip_cloud_connector",
          connectorProfile: "github.code",
          connectorSubjectUserId: "responsible-user",
        },
      },
    }).where(eq(toolConnections.id, connection.id));
    const [grant] = await db.select().from(connectionGrants).where(eq(
      connectionGrants.connectionId,
      connection.id,
    ));
    await db.update(connectionGrants).set({
      credentialSecretRefs: [{
        secretId: accessSecret.id,
        versionSelector: "latest",
        configPath: "oauth.access_token",
        required: true,
        label: "OAuth access token",
      }],
      providerTenant: {
        oauth: {
          strategy: "paperclip_cloud_connector",
          accessTokenExpiresAt: new Date(Date.now() + 60 * 60 * 1000).toISOString(),
        },
      },
    }).where(eq(connectionGrants.id, grant.id));
    await db.insert(toolPolicies).values({
      companyId: company.id,
      name: "Allow managed OAuth reads",
      policyType: "allow",
      selectors: { riskLevel: "read" },
    });

    const oauthGrantRefresher: NonNullable<ToolGatewayServiceOptions["oauthGrantRefresher"]> = vi.fn(async (input) => {
      if (input.forceRefresh) {
        await secretService(db).rotate(accessSecret.id, { value: "fresh-managed-token" });
      }
      return db.select().from(connectionGrants).where(eq(connectionGrants.id, input.grantId))
        .then((rows) => rows[0]!);
    });
    const authorizationHeaders: string[] = [];
    const gateway = createTestToolGatewayService(db, {
      oauthGrantRefresher,
      remoteHttpRequest: async (_url, init) => {
        authorizationHeaders.push(new Headers(init.headers).get("authorization") ?? "");
        return new Response(null, { status: 401 });
      },
    });
    const session = await gateway.createSession({ companyId: company.id, agentId: agent.id, runId: run.id });
    const tool = (await gateway.listToolsForSession(session.token))
      .find((candidate) => candidate.providerType === "mcp_remote_http");

    await expect(gateway.executeTool({
      sessionToken: session.token,
      tool: tool!.name,
      parameters: {},
    })).rejects.toMatchObject({ reasonCode: "mcp_remote_status" });

    expect(authorizationHeaders).toEqual([
      "Bearer stale-managed-token",
      "Bearer fresh-managed-token",
    ]);
    expect(oauthGrantRefresher).toHaveBeenCalledTimes(2);
    expect(vi.mocked(oauthGrantRefresher).mock.calls[1]?.[0]).toMatchObject({ forceRefresh: true });
    const [storedGrant] = await db.select().from(connectionGrants).where(eq(connectionGrants.id, grant.id));
    expect(storedGrant?.status).toBe("needs_reauthorization");
  });

  it("fails clearly when remote MCP elicitation has no issue interaction path", async () => {
    const company = await db.insert(companies).values({
      name: `Gateway ${randomUUID()}`,
      issuePrefix: `TG${randomUUID().slice(0, 6).toUpperCase()}`,
    }).returning().then((rows) => rows[0]!);
    const agent = await db.insert(agents).values({
      companyId: company.id,
      name: `Gateway Agent ${randomUUID()}`,
      role: "engineer",
      adapterType: "process",
      adapterConfig: {},
      runtimeConfig: {},
      permissions: {},
    }).returning().then((rows) => rows[0]!);
    const run = await db.insert(heartbeatRuns).values({
      companyId: company.id,
      agentId: agent.id,
      invocationSource: "manual",
      status: "running",
      contextSnapshot: {},
    }).returning().then((rows) => rows[0]!);
    await createRemoteMcpToolFixture(db, company.id);
    await db.insert(toolPolicies).values({
      companyId: company.id,
      name: "Allow read tools",
      policyType: "allow",
      selectors: { riskLevel: "read" },
    });
    const originalFetch = globalThis.fetch;
    globalThis.fetch = async (_url, init) => new Response(JSON.stringify({
      jsonrpc: "2.0",
      id: JSON.parse(String(init?.body)).id,
      result: { elicitation: { message: "Need input" }, content: [] },
    }), { status: 200, headers: { "content-type": "application/json" } });
    try {
      const gateway = createTestToolGatewayService(db);
      const session = await gateway.createSession({
        companyId: company.id,
        agentId: agent.id,
        runId: run.id,
      });
      const tool = (await gateway.listToolsForSession(session.token))
        .find((candidate) => candidate.providerType === "mcp_remote_http");
      expect(tool).toBeTruthy();
      await expect(gateway.executeTool({
        sessionToken: session.token,
        tool: tool!.name,
        parameters: {},
      })).rejects.toMatchObject({ reasonCode: "elicitation_not_supported" });
      expect(await db.select().from(issueThreadInteractions)).toEqual([]);
    } finally {
      globalThis.fetch = originalFetch;
    }
  });

  it("refuses opaque plugin before malicious results can be produced", async () => {
    const {company,agent,run}=await createRunFixture(db);const dispatcher=fakePluginDispatcher();const invoke=vi.spyOn(dispatcher,"executeTool");
    const gateway=createTestToolGatewayService(db,{pluginToolDispatcher:dispatcher});
    await db.insert(toolPolicies).values({companyId:company.id,name:"Allow",policyType:"allow",selectors:{toolName:"fixture:delete_everything"}});
    await expect(gateway.executePluginTool({actor:{type:"agent",companyId:company.id,agentId:agent.id,runId:run.id},tool:"fixture:delete_everything",parameters:{},runContext:{companyId:company.id,agentId:agent.id,runId:run.id}})).rejects.toMatchObject({reasonCode:"tool_model_effect_unqualified"});
    expect(invoke).not.toHaveBeenCalled();expect(await db.select().from(toolInvocations)).toEqual([]);
  });

  it("refuses opaque plugin before sensitive arguments leave the gateway", async () => {
    const {company,agent,run}=await createRunFixture(db);const dispatcher=fakePluginDispatcher();const invoke=vi.spyOn(dispatcher,"executeTool");
    const gateway=createTestToolGatewayService(db,{pluginToolDispatcher:dispatcher});
    await db.insert(toolPolicies).values({companyId:company.id,name:"Allow",policyType:"allow",selectors:{toolName:"fixture:delete_everything"}});
    await expect(gateway.executePluginTool({actor:{type:"agent",companyId:company.id,agentId:agent.id,runId:run.id},tool:"fixture:delete_everything",parameters:{apiKey:"synthetic-secret"},runContext:{companyId:company.id,agentId:agent.id,runId:run.id}})).rejects.toMatchObject({reasonCode:"tool_model_effect_unqualified"});
    expect(invoke).not.toHaveBeenCalled();expect(await db.select().from(toolInvocations)).toEqual([]);
  });

});
