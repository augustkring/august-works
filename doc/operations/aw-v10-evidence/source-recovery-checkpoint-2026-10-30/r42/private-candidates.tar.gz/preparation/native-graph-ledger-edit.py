from pathlib import Path
p=Path('/workspace/blentera-v10/server/src/services/native-direct-input.ts')
s=p.read_text()
s=s.replace('interface NativeSourceReadPinnedRows {','''type NativeSiblingToolSourceProofs = Map<string, { descendants: Set<string>;
  policy: NativePayloadSourcePolicy; inputs: NativePayloadSourceInput[] }>;
// Every active recursive owner participates in structural proof ancestry.
function addNativeSourceActiveVisit(scope: NativeSourceReadScope, key: string): void {
  for (const frame of scope.context.ancestry.frozenTaskProofStacks.get(scope.actorKey) ?? [])
    frame.descendants.add(key);
  scope.active.add(key);
}
interface NativeSourceReadPinnedRows {''',1)
# Do not replace the helper's own add.
s=s.replace('scope.active.add(activeKey);','addNativeSourceActiveVisit(scope, activeKey);').replace('scope.active.add(completeKey);','addNativeSourceActiveVisit(scope, completeKey);').replace('scope.active.add(visitKey);','addNativeSourceActiveVisit(scope, visitKey);').replace('scope.active.add(key);\n    try {','addNativeSourceActiveVisit(scope, key);\n    try {')
s=s.replace('validatedDispatchSources?: ReadonlySet<string>): Promise<void> {','validatedDispatchSources?: ReadonlySet<string>, siblingToolSourceProofs?: NativeSiblingToolSourceProofs): Promise<void> {')
s=s.replace('scope, true, completedTaskSourceProofs, validatedDispatchSources);','scope, true, completedTaskSourceProofs, validatedDispatchSources, siblingToolSourceProofs);')
needle='''    if (source.kind === "tool_result") {
      const producerRun = await nativeSourceReadRun'''
replacement='''    if (source.kind === "tool_result") {
      // This ledger exists only across sibling components of this uncached
      // invocation. Keep each original full prefix for receipt/evidence checks;
      // never replace prefixes with a sliced union or share proofs with a new read.
      const siblingProofKey = siblingToolSourceProofs && source.toolName !== "create_project" && source.toolName !== "call_api"
        ? nativeSha256({ companyId: input.companyId, issueId: input.issueId, runId: input.runId,
            actor: input.actor, actorScope: scope.actorKey, memoryTemporalIdentity: scope.context.memoryTemporalIdentity, source }) : null;
      const siblingProof = siblingProofKey ? siblingToolSourceProofs?.get(siblingProofKey) : undefined;
      const prefixCoversProof = siblingProof && siblingProof.inputs.every(required =>
        inputs.data.some(candidate => isDeepStrictEqual(candidate, required))) &&
        (Object.keys(policy.data) as (keyof NativePayloadSourcePolicy)[]).every(key =>
          siblingProof.policy[key].every(id => policy.data[key].includes(id)));
      if (siblingProof && prefixCoversProof &&
        !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, siblingProof.descendants)) {
        // The source loop charged this hit above. Live authority and retention
        // are checked again by the mandatory current-reader pass.
        deferNativeSourceReaderCheck(scope, { companyId: input.companyId, runId: input.runId,
          actor: input.actor, policy: policy.data, inputs: inputs.data });
        for (const parent of scope.context.ancestry.frozenTaskProofStacks.get(scope.actorKey) ?? [])
          for (const descendant of siblingProof.descendants) parent.descendants.add(descendant);
        continue;
      }
      let siblingProofStack = scope.context.ancestry.frozenTaskProofStacks.get(scope.actorKey);
      if (!siblingProofStack) {
        siblingProofStack = [];
        scope.context.ancestry.frozenTaskProofStacks.set(scope.actorKey, siblingProofStack);
      }
      const siblingFrame = { visitKey: siblingProofKey ?? "", descendants: new Set<string>() };
      if (siblingProofKey) siblingProofStack.push(siblingFrame);
      let siblingCompleted = false;
      try {
      const producerRun = await nativeSourceReadRun'''
assert s.count(needle)==1
s=s.replace(needle,replacement)
needle='''      continue;
    }
    if (source.kind === "authored_definition")'''
replacement='''      siblingCompleted = true;
      } finally {
        if (siblingProofKey && siblingProofStack.at(-1) === siblingFrame) siblingProofStack.pop();
        if (siblingCompleted && siblingProofKey && siblingToolSourceProofs && siblingToolSourceProofs.size < 512)
          siblingToolSourceProofs.set(siblingProofKey, { descendants: siblingFrame.descendants,
            policy: policy.data, inputs: inputs.data });
      }
      continue;
    }
    if (source.kind === "authored_definition")'''
assert s.count(needle)==2
s=s.replace(needle,replacement,1)
s=s.replace('''  const completedTaskSourceProofs = new Map<string, string>();
  for (const [index''','''  const completedTaskSourceProofs = new Map<string, string>();
  const siblingToolSourceProofs: NativeSiblingToolSourceProofs = new Map();
  for (const [index''')
s=s.replace('''      completedTaskSourceProofs, validatedDispatchSources);
  }
}''','''      completedTaskSourceProofs, validatedDispatchSources, siblingToolSourceProofs);
  }
}''')
p.with_suffix('.ledger.tmp.ts').write_text(s)
