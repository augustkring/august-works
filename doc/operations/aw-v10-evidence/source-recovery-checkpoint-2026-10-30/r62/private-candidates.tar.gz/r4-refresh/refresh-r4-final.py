#!/usr/bin/env python3
"""Create a private R4 refresh overlay from explicit frozen inputs and owner receipts.
Does not run legacy hardwired builders, delete/rebuild bundles, or change qualification.
"""
import argparse, copy, hashlib, json, subprocess
from pathlib import Path, PurePosixPath

STATUS = 'e6630ae7f08def7034bdc1fc25fed68a8ea8ce216a9fe9938256a25eae06e19f'
PRIVATE = Path('/workspace/v10-preparation').resolve()
ROLES = {'native9', 'host', 'guard'}

def require(ok, text):
    if not ok:
        raise SystemExit(text)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def canonical(value):
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':')).encode())

def file_sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()

def pin(path):
    return {'path': str(path), 'sha256': file_sha(path)}

def relative(path):
    p = PurePosixPath(path)
    require(not p.is_absolute() and '..' not in p.parts and str(p) == path and '\\' not in path, 'invalid repository path')
    return path

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--frozen-root', type=Path, required=True)
    ap.add_argument('--expected-head', required=True)
    ap.add_argument('--baseline-r4', type=Path, required=True)
    ap.add_argument('--historical-amendment', type=Path, required=True)
    ap.add_argument('--baseline-pins', type=Path, required=True)
    ap.add_argument('--expected-baseline-pins-sha256', required=True)
    ap.add_argument('--owner-receipt-map', type=Path, required=True)
    ap.add_argument('--expected-owner-map-sha256', required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    root = args.frozen_root.resolve(strict=True); baseline = args.baseline_r4.resolve(strict=True)
    def git(*v):
        return subprocess.check_output(['git', *v], cwd=root, stderr=subprocess.PIPE)
    require(git('rev-parse', '--show-toplevel').decode().strip() == str(root), 'not a Git root')
    named_inputs = set()
    for named in (args.baseline_pins, args.owner_receipt_map, args.historical_amendment):
        resolved = named.resolve(strict=True)
        if resolved.is_relative_to(root):
            named_inputs.add(resolved.relative_to(root).as_posix())
    def frozen():
        require(len(args.expected_head) == 40 and git('rev-parse', 'HEAD').decode().strip() == args.expected_head, 'exact final frozen HEAD required')
        for entry in git('status', '--porcelain=v1', '-z', '--untracked-files=all').split(b'\0'):
            if not entry:
                continue
            require(entry.startswith(b'?? '), 'tracked/index changes remain')
            p = entry[3:].decode()
            require(p.startswith('doc/operations/aw-v10-evidence/') and p not in named_inputs, 'untracked source/input is not allowed: ' + p)
    frozen()
    output = args.output.absolute().parent.resolve(strict=True) / args.output.name
    require(output.is_relative_to(PRIVATE) and not output.is_relative_to(root) and not output.exists() and not output.is_symlink(), 'output must be a NEW private directory outside frozen root')
    require(not output.is_relative_to(baseline), 'never mutate the R4 baseline')
    pin_bytes = args.baseline_pins.read_bytes(); map_bytes = args.owner_receipt_map.read_bytes()
    require(sha(pin_bytes) == args.expected_baseline_pins_sha256 and sha(map_bytes) == args.expected_owner_map_sha256, 'explicit input map pin mismatch')
    pins = json.loads(pin_bytes); owners = json.loads(map_bytes)
    require(owners['schemaVersion'] == 1 and owners['frozenHead'] == args.expected_head and set(owners['owners']) == ROLES, 'owner map must match exact final HEAD and native9/host/guard roles')
    required = ['reconciliation.json', 'predecessor-claim-crosswalk.json', 'launch-claim-matrix.json', 'portable-source-map.json']
    require(set(pins['baselineFiles']) == set(required), 'baseline must pin report, predecessor crosswalk, launch matrix and historical portable map')
    originals = {}
    for name in required:
        baseline_input = baseline / name
        if baseline_input.is_relative_to(root):
            named_inputs.add(baseline_input.relative_to(root).as_posix())
        raw = (baseline / name).read_bytes()
        require(sha(raw) == pins['baselineFiles'][name], 'R4 baseline pin mismatch: ' + name)
        originals[name] = raw
    archive = baseline / 'source-bundle.tar.gz'
    require(file_sha(archive) == pins['baselineArchiveSha256'], 'historical baseline archive pin mismatch')
    historical_raw = args.historical_amendment.read_bytes()
    require(sha(historical_raw) == pins['historicalAmendmentSha256'], 'historical Nov01 amendment pin mismatch')
    prior_amendment = json.loads(historical_raw)
    require(prior_amendment['baseline']['historicalStatusCanonicalSha256'] == STATUS, 'historical amendment status digest changed')
    report = json.loads(originals['reconciliation.json']); launch = json.loads(originals['launch-claim-matrix.json'])
    historical = json.loads(git('show', args.expected_head + ':doc/operations/aw-v10-evidence/recovery-2026-10-22/requirement-reconciliation.json'))
    statuses = {r['id']: r['reconciliation'] for r in historical['items']}
    require(len(statuses) == 169 and canonical(statuses) == STATUS, 'canonical169 statuses changed')
    require({r['id']: r['historicalRegisterStatus'] for r in report['rows']} == statuses, 'R4 historical statuses differ')
    require({r['v10RequirementId']: r['historicalRegisterStatusPreserved'] for r in launch['rows']} == statuses, 'launch historical statuses differ')
    require(len(report['rows']) == len(launch['rows']) == 169, '169 unique rows required')
    qualification_before = canonical({r['id']: [r.get('actualQualification'), r.get('historicalEvidence'), r.get('currentDisposition'), r.get('currentReviewState')] for r in report['rows']})
    source_paths = owners['sourcePaths']
    require(isinstance(source_paths, list) and source_paths and len(source_paths) == len(set(source_paths)), 'explicit unique final sourcePaths required; no automatic discovery or empty refresh')
    named_inputs.update(source_paths)
    protected_predecessors = {'evals/aw-v7/pilot-readiness.json', 'evals/aw-v8/readiness.json', 'evals/aw-v9/readiness.json',
                              'doc/operations/aw-v6-evidence.md', 'doc/operations/aw-v8-source-acceptance.md', 'doc/experience/v9/coverage.json'}
    new_pins = {}
    for p in source_paths:
        relative(p)
        require(not p.startswith('doc/operations/aw-v10-evidence/') and not p.startswith('source-bundle/') and p not in protected_predecessors, 'historical receipt/bundle/predecessor paths must not be refreshed as current source')
        raw = git('show', args.expected_head + ':' + p)
        new_pins[p] = {'path': p, 'location': 'repository', 'state': 'present_at_frozen_source_checkpoint', 'sha256': sha(raw), 'roles': ['explicit_current_source_navigation_not_qualification']}
    def update_pins(entries):
        for item in entries:
            if item.get('location') == 'repository' and item.get('path') in new_pins:
                item['sha256'] = new_pins[item['path']]['sha256']
                item['state'] = 'present_at_frozen_source_checkpoint'
    update_pins(report['sourceHashInventory'])
    for row in report['rows']:
        update_pins(row.get('currentSourcePins', []))
    prior_paths = {p.get('path') for p in report['sourceHashInventory']}
    report['sourceHashInventory'].extend(new_pins[p] for p in sorted(new_pins) if p not in prior_paths)
    appendix = {}
    receipt_copies = []
    for role, value in owners['owners'].items():
        require(value['state'] in ('pending', 'recorded'), 'unknown owner receipt state')
        if value['state'] == 'pending':
            require(value.get('receipts') == [] and value.get('outcome') is None and value.get('counts') is None, 'pending owner cannot contain invented result/counts')
            appendix[role] = copy.deepcopy(value)
            continue
        require(value.get('outcome') in ('passed', 'failed', 'inconclusive') and value.get('qualificationScope') in ('software_component', 'software_managed_journey'), 'only explicit software owner outcomes may be recorded')
        require(value.get('frozenHead') == args.expected_head and value.get('receipts') and isinstance(value.get('summary'), str) and value['summary'].strip(), 'recorded outcome requires exact final HEAD, scoped summary and real receipt pins')
        if role == 'native9' and value['outcome'] == 'passed':
            require(value.get('counts') == {'passed': 9, 'failed': 0, 'skipped': 0, 'total': 9, 'exitCode': 0}, 'Native9 pass requires complete exact9/0/0 exit0 owner declaration')
        recorded = copy.deepcopy(value)
        for index, receipt in enumerate(recorded['receipts']):
            p = Path(receipt['path']).resolve(strict=True)
            require(p.is_relative_to(PRIVATE) or p.is_relative_to(root), 'receipt outside reviewed workspace roots')
            raw = p.read_bytes(); require(sha(raw) == receipt['sha256'], 'owner receipt mismatch: ' + str(p))
            # Compact explicit receipt sidecars only; never copy provider packs, raw DBs or old bundles.
            require(len(raw) <= 8 * 1024 * 1024 and not p.name.endswith(('.tar.gz', '.zip')), 'provide a compact owner receipt, not a large archive')
            target = Path('owner-receipts') / role / (str(index) + '-' + p.name)
            receipt['portablePath'] = target.as_posix(); receipt_copies.append((target, raw))
            if p.is_relative_to(root):
                named_inputs.add(p.relative_to(root).as_posix())
        appendix[role] = recorded
    frozen()
    require(canonical({r['id']: [r.get('actualQualification'), r.get('historicalEvidence'), r.get('currentDisposition'), r.get('currentReviewState')] for r in report['rows']}) == qualification_before, 'qualification/historical evidence changed')
    update = {'kind': 'append_only_final_owner_receipt_update_not_acceptance', 'sourceHead': args.expected_head,
              'historicalStatusCanonicalSha256': STATUS, 'ownerReceipts': appendix,
              'sourceRefreshScope': sorted(source_paths), 'sourcePresenceIsQualification': False,
              'remainingGates': ['Physical host/runtime behavior', 'All offered provider/account/tariff/route qualifications', 'Hosted deployment and arbitrary restore', 'Human/operator decisions and signed release'],
              'qualificationPolicy': 'Owner outcomes are exact scoped declarations backed by pinned receipts. No inherited qualification field, historical failure, predecessor status or overall release claim is overwritten.'}
    report['historicalSnapshotBeforeFinalRefresh'] = copy.deepcopy(report['snapshot'])
    report['snapshot'] = {**report['snapshot'], 'headCommit': args.expected_head, 'worktreeDirty': False,
                         'snapshotClass': 'explicit selected source pins refreshed from frozen Git; all unselected pins and qualification fields remain historical',
                         'sourceHashBasis': 'Only explicit owner-map sourcePaths refreshed from immutable Git blobs; historical receipt hashes and predecessor navigation preserved.'}
    report['finalOwnerReceiptUpdate'] = update
    portable = json.loads(originals['portable-source-map.json'])
    baseline_reference = {'root': str(baseline), 'reportSha256': pins['baselineFiles']['reconciliation.json'],
                          'archive': str(archive), 'archiveSha256': pins['baselineArchiveSha256'], 'policy': 'Existing immutable R4 baseline bundle reused by reference; no archive is deleted, recopied or rebuilt. This output is a compact additive overlay, not a newly self-contained evidence bundle.'}
    portable['finalRefreshOverlay'] = {'baseline': baseline_reference, 'ownerReceipts': appendix}
    report['portableEvidence']['finalRefreshOverlay'] = baseline_reference
    amendment = {'schemaVersion': 1, 'kind': 'additive_private_claim_amendment_not_acceptance', 'requirementId': 'V10-149',
                 'baseline': {'historicalAmendment': pin(args.historical_amendment), 'historicalR4': baseline_reference, 'requirementCount': 169, 'historicalStatusCanonicalSha256': STATUS},
                 'applicationPolicy': {'mode': 'append_evidence_and_pending_gates_only', 'rewriteHistoricalStatuses': False, 'alterOther168Requirements': False, 'promoteSourcePresenceToQualification': False, 'publishOrActivate': False},
                 'historicalStatusPreserved': statuses['V10-149'], 'finalOwnerReceiptUpdate': update,
                 'priorFactsDisposition': 'Earlier R77/Host14.21/33-file statements remain historical in the pinned original amendment; this update selects no latest result except the explicit current owner map. Pending is not pass.'}
    frozen()
    require(sha(args.baseline_pins.read_bytes()) == args.expected_baseline_pins_sha256 and sha(args.owner_receipt_map.read_bytes()) == args.expected_owner_map_sha256, 'input map changed during refresh')
    for name, raw in originals.items():
        require((baseline / name).read_bytes() == raw, 'baseline changed during refresh')
    require(args.historical_amendment.read_bytes() == historical_raw, 'historical amendment changed during refresh')
    require(file_sha(archive) == pins['baselineArchiveSha256'], 'historical baseline archive changed during refresh')
    output.mkdir()
    for name in ('predecessor-claim-crosswalk.json', 'launch-claim-matrix.json'):
        (output / name).write_bytes(originals[name])
    (output / 'historical-claim-amendment.json').write_bytes(historical_raw)
    for name, value in [('reconciliation.json', report), ('portable-source-map.json', portable), ('claim-amendment.json', amendment), ('final-owner-receipt-map.json', owners)]:
        (output / name).write_text(json.dumps(value, indent=2) + '\n')
    for target, raw in receipt_copies:
        p = output / target; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(raw)
    (output / 'SHA256SUMS').write_text(''.join(sha(p.read_bytes()) + '  ' + p.relative_to(output).as_posix() + '\n' for p in sorted(output.rglob('*')) if p.is_file()))
    print(json.dumps({'output': str(output), 'preservedHistoricalStatuses': 169, 'historicalStatusCanonicalSha256': STATUS, 'ownerStates': {k: v['state'] for k, v in appendix.items()}, 'qualificationUpgrade': False}))

if __name__ == '__main__':
    main()
