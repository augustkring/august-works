# Private R9 V7 diskBytes caller compatibility delta

This additive private revision updates only three V7 server test files against the exact R9 file overlays. It supplies the newly required `diskBytes` resource field from the actual compiled policy resources or the existing policy fixture resources; no standalone disk quota value is invented. The backend assertion now verifies `diskBytes` forwarding from the exact `policyInput.policy.compiledPolicy.resources` object.

Apply `v7-caller-compat-r1.patch` to the R9 candidate `files/` tree with `patch -p1`, or copy the three `candidate/` files over the corresponding R9 files. R9 source remains unchanged. No build, typecheck, PostgreSQL test, host test, or runtime qualification is claimed for this overlay.
