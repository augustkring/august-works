# R11 Rust disk-configuration correctness delta

This immutable delta is based on the privately qualified R10 candidate. It only changes the Docker driver config deserialization type annotation and disk-limited tmpfs validation/tests. It annotates deserialization as `Self` before reading `disk_limit_bytes`; disk-limited profiles now reject writable `rw` and contradictory `ro` + `rw` tmpfs flags, with tests for both rejected conflicting flags and accepted explicit read-only tmpfs.

R10 remains unchanged at its original archive/digest. R10 runtime and TypeScript receipts are historical and do not qualify the changed Rust driver. No R11 compile, unit, integration, or physical-host tests have run. The exact changed-source hashes are in `source-pins.json`; `r11-rust-correction.patch` reconstructs the delta from R10.
