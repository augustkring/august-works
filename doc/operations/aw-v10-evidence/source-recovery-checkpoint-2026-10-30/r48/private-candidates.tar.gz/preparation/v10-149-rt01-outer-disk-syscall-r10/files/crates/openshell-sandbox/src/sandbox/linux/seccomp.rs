// SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

//! Seccomp syscall filtering.
//!
//! The filter uses a default-allow policy with targeted blocks:
//!
//! 1. **Socket domain blocks** -- prevent raw/kernel sockets that bypass the proxy
//! 2. **Unconditional syscall blocks** -- block syscalls that enable sandbox escape
//!    (fileless exec, ptrace, BPF, cross-process memory access, `io_uring`, mount)
//! 3. **Conditional syscall blocks** -- block dangerous flag combinations on otherwise
//!    needed syscalls (`execveat+AT_EMPTY_PATH`, `unshare+CLONE_NEWUSER`,
//!    `seccomp+SET_MODE_FILTER`)
//!
//! ## `AF_NETLINK` policy
//!
//! `AF_NETLINK` sockets are allowed **only** for the `NETLINK_ROUTE` protocol
//! (protocol value 0). All other netlink protocols are blocked with `EPERM`.
//!
//! `NETLINK_ROUTE` is required by `getifaddrs(3)` on Linux (used by Node.js,
//! Python, Go, and many HTTP/gRPC client libraries during startup). Without it
//! those runtimes fail to enumerate network interfaces even when they have no
//! intent to modify them.
//!
//! The risk is contained by existing sandbox layers:
//! - **Privilege drop**: `CAP_NET_ADMIN` is not granted, so all write operations
//!   (add/delete routes, addresses, interfaces) fail with `EPERM` regardless.
//! - **Outer network fence**: direct workload egress is rejected outside this
//!   process by Docker network-none, Kubernetes `NetworkPolicy`, or a NIC-less
//!   VM.
//!
//! Every other netlink protocol (`NETLINK_SOCK_DIAG`, `NETLINK_NETFILTER`,
//! `NETLINK_AUDIT`, `NETLINK_XFRM`, `NETLINK_GENERIC`, etc.) remains blocked.

use miette::{IntoDiagnostic, Result};
use openshell_core::policy::{NetworkMode, SandboxPolicy};
use seccompiler::{
    SeccompAction, SeccompCmpArgLen, SeccompCmpOp, SeccompCondition, SeccompFilter, SeccompRule,
    apply_filter, apply_filter_all_threads,
};
use std::collections::BTreeMap;
use std::convert::TryInto;
use tracing::debug;

/// Value of `SECCOMP_SET_MODE_FILTER` (linux/seccomp.h).
const SECCOMP_SET_MODE_FILTER: u64 = 1;

// libc 0.2.185 omits `SYS_kexec_file_load` from the musl/aarch64 bindings even
// though the kernel exposes syscall 294. Fall back to the literal so the
// supervisor's seccomp filter still blocks fileless kernel-image loads when
// built statically against musl on aarch64.
#[cfg(all(target_arch = "aarch64", target_env = "musl"))]
#[allow(non_upper_case_globals)]
const SYS_kexec_file_load: libc::c_long = 294;
#[cfg(not(all(target_arch = "aarch64", target_env = "musl")))]
use libc::SYS_kexec_file_load;

/// Apply the supervisor seccomp filter across the running process.
///
/// This runs after privileged startup helpers complete and synchronizes the
/// filter across all supervisor threads via TSYNC. It intentionally blocks
/// only the privileged escape primitives that the long-lived supervisor no
/// longer needs once bootstrap is complete.
pub fn apply_supervisor_prelude() -> Result<()> {
    let filter = build_supervisor_prelude_filter()?;
    set_no_new_privs()?;
    apply_filter_all_threads(&filter).into_diagnostic()?;
    Ok(())
}

pub fn apply(policy: &SandboxPolicy) -> Result<()> {
    let allow_inet = matches!(policy.network.mode, NetworkMode::Proxy | NetworkMode::Allow);
    let main_filter = build_filter(allow_inet)?;
    let compatibility_filter = build_compatibility_filter()?;

    set_no_new_privs()?;
    apply_runtime_filters(&main_filter, &compatibility_filter)?;

    Ok(())
}

fn build_filter(allow_inet: bool) -> Result<seccompiler::BpfProgram> {
    let rules = build_filter_rules(allow_inet)?;
    compile_filter(rules, SeccompAction::Errno(libc::EPERM as u32))
}

fn build_supervisor_prelude_filter() -> Result<seccompiler::BpfProgram> {
    compile_filter(
        build_supervisor_prelude_rules(),
        SeccompAction::Errno(libc::EPERM as u32),
    )
}

fn build_supervisor_prelude_rules() -> BTreeMap<i64, Vec<SeccompRule>> {
    let mut rules: BTreeMap<i64, Vec<SeccompRule>> = BTreeMap::new();

    for syscall in [
        libc::SYS_mount,
        libc::SYS_fsopen,
        libc::SYS_fsconfig,
        libc::SYS_fsmount,
        libc::SYS_fspick,
        libc::SYS_move_mount,
        libc::SYS_open_tree,
        libc::SYS_pivot_root,
        libc::SYS_umount2,
        libc::SYS_bpf,
        libc::SYS_perf_event_open,
        libc::SYS_userfaultfd,
        libc::SYS_init_module,
        libc::SYS_finit_module,
        libc::SYS_delete_module,
        libc::SYS_kexec_load,
        SYS_kexec_file_load,
    ] {
        rules.entry(syscall).or_default();
    }

    rules
}

fn set_no_new_privs() -> Result<()> {
    // libc/syscall FFI requires unsafe
    #[allow(unsafe_code)]
    let rc = unsafe { libc::prctl(libc::PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) };
    if rc != 0 {
        return Err(miette::miette!(
            "Failed to set no_new_privs: {}",
            std::io::Error::last_os_error()
        ));
    }

    Ok(())
}

fn compile_filter(
    rules: BTreeMap<i64, Vec<SeccompRule>>,
    blocked_action: SeccompAction,
) -> Result<seccompiler::BpfProgram> {
    let arch = std::env::consts::ARCH
        .try_into()
        .map_err(|_| miette::miette!("Unsupported architecture for seccomp"))?;

    let filter =
        SeccompFilter::new(rules, SeccompAction::Allow, blocked_action, arch).into_diagnostic()?;

    filter.try_into().into_diagnostic()
}

/// Build a minimal BPF filter for unavailable process APIs.
///
/// This is a separate filter from the main one because seccomp BPF cannot
/// dereference the `struct clone_args *` pointer that clone3 takes as arg 0,
/// so we cannot selectively block `CLONE_NEWUSER`. We block clone3
/// unconditionally with ENOSYS so glibc falls back to the older clone
/// syscall (where flags are a direct register argument and CAN be filtered).
///
/// glibc's clone3 wrapper and process launchers that opportunistically use
/// pidfds check for ENOSYS specifically. EPERM is treated as a hard policy
/// failure instead of triggering their portable fallback paths.
fn build_compatibility_filter() -> Result<seccompiler::BpfProgram> {
    let mut rules: BTreeMap<i64, Vec<SeccompRule>> = BTreeMap::new();
    rules.entry(libc::SYS_clone3).or_default();
    rules.entry(libc::SYS_pidfd_open).or_default();
    compile_filter(rules, SeccompAction::Errno(libc::ENOSYS as u32))
}

/// Install the sandbox seccomp filters in the required order.
///
/// Order matters:
/// 1. Install the compatibility filter first so it can still call
///    `seccomp(SECCOMP_SET_MODE_FILTER)`.
/// 2. Install the main filter second. It blocks further seccomp filter
///    installation with `EPERM`, preserving the original hardening intent.
fn apply_runtime_filters(
    main_filter: seccompiler::BpfProgramRef<'_>,
    compatibility_filter: seccompiler::BpfProgramRef<'_>,
) -> Result<()> {
    apply_filter(compatibility_filter).into_diagnostic()?;
    apply_filter(main_filter).into_diagnostic()?;
    Ok(())
}

fn build_filter_rules(allow_inet: bool) -> Result<BTreeMap<i64, Vec<SeccompRule>>> {
    let mut rules: BTreeMap<i64, Vec<SeccompRule>> = BTreeMap::new();

    // --- Socket domain blocks ---
    let mut blocked_domains = vec![
        libc::AF_PACKET,
        libc::AF_BLUETOOTH,
        libc::AF_VSOCK,
        // AF_NETLINK is handled separately below: NETLINK_ROUTE (protocol 0)
        // is allowed for getifaddrs(3); all other netlink protocols are blocked.
    ];
    if !allow_inet {
        blocked_domains.push(libc::AF_INET);
        blocked_domains.push(libc::AF_INET6);
    }

    for domain in blocked_domains {
        debug!(domain, "Blocking socket domain via seccomp");
        add_socket_domain_rule(&mut rules, domain)?;
    }

    // Allow AF_NETLINK only for NETLINK_ROUTE (protocol 0).
    //
    // NETLINK_ROUTE is needed by getifaddrs(3) which is called by Node.js,
    // Python, Go, and many HTTP/gRPC client libraries during startup to
    // enumerate local network interfaces. Blocking it causes runtime errors
    // such as "getifaddrs returned an error" in tools like Claude Code.
    //
    // The rule blocks socket(AF_NETLINK, *, protocol) for any protocol != 0.
    // Write operations via NETLINK_ROUTE still require CAP_NET_ADMIN, which
    // the sandbox does not grant, so interface/route modification is not possible.
    add_netlink_non_route_rule(&mut rules)?;

    // --- Unconditional syscall blocks ---
    // These syscalls are blocked entirely (empty rule vec = unconditional EPERM).

    // Fileless binary execution via memfd bypasses Landlock filesystem restrictions.
    rules.entry(libc::SYS_memfd_create).or_default();
    // Cross-process memory inspection and code injection.
    rules.entry(libc::SYS_ptrace).or_default();
    // Kernel BPF program loading.
    rules.entry(libc::SYS_bpf).or_default();
    // Cross-process memory read.
    rules.entry(libc::SYS_process_vm_readv).or_default();
    // Cross-process memory write (symmetric with process_vm_readv).
    rules.entry(libc::SYS_process_vm_writev).or_default();
    // Process fd theft and signalling via pidfd. pidfd_open is made
    // unavailable with ENOSYS by the compatibility filter so runtimes can
    // fall back without gaining a handle to the trusted sandbox boundary.
    rules.entry(libc::SYS_pidfd_getfd).or_default();
    rules.entry(libc::SYS_pidfd_send_signal).or_default();
    // Async I/O subsystem with extensive CVE history.
    rules.entry(libc::SYS_io_uring_setup).or_default();
    // Filesystem mount could subvert Landlock or overlay writable paths.
    rules.entry(libc::SYS_mount).or_default();
    // New mount API syscalls (Linux 5.2+) bypass the SYS_mount block entirely.
    rules.entry(libc::SYS_fsopen).or_default();
    rules.entry(libc::SYS_fsconfig).or_default();
    rules.entry(libc::SYS_fsmount).or_default();
    rules.entry(libc::SYS_fspick).or_default();
    rules.entry(libc::SYS_move_mount).or_default();
    rules.entry(libc::SYS_open_tree).or_default();
    // Namespace manipulation — setns enters existing namespaces, pivot_root/umount2
    // change the filesystem root. The supervisor calls setns before seccomp is applied,
    // so blocking it here is safe.
    rules.entry(libc::SYS_setns).or_default();
    rules.entry(libc::SYS_umount2).or_default();
    rules.entry(libc::SYS_pivot_root).or_default();
    // Kernel exploit primitives: userfaultfd enables race-condition exploitation (multiple
    // CVEs), perf_event_open enables Spectre-class side channels. Both blocked by Docker's
    // default seccomp profile.
    rules.entry(libc::SYS_userfaultfd).or_default();
    rules.entry(libc::SYS_perf_event_open).or_default();

    // --- Conditional syscall blocks ---

    // execveat with AT_EMPTY_PATH enables fileless execution from an anonymous fd.
    add_masked_arg_rule(
        &mut rules,
        libc::SYS_execveat,
        4, // flags argument
        libc::AT_EMPTY_PATH as u64,
    )?;

    // unshare with CLONE_NEWUSER allows creating user namespaces to escalate privileges.
    add_masked_arg_rule(
        &mut rules,
        libc::SYS_unshare,
        0, // flags argument
        libc::CLONE_NEWUSER as u64,
    )?;

    // clone with CLONE_NEWUSER achieves the same as unshare via a different syscall.
    add_masked_arg_rule(
        &mut rules,
        libc::SYS_clone,
        0, // flags argument
        libc::CLONE_NEWUSER as u64,
    )?;
    // clone3 is handled by the ENOSYS compatibility filter.

    // seccomp(SECCOMP_SET_MODE_FILTER) would let sandboxed code replace the active filter.
    let condition = SeccompCondition::new(
        0, // operation argument
        SeccompCmpArgLen::Dword,
        SeccompCmpOp::Eq,
        SECCOMP_SET_MODE_FILTER,
    )
    .into_diagnostic()?;
    let rule = SeccompRule::new(vec![condition]).into_diagnostic()?;
    rules.entry(libc::SYS_seccomp).or_default().push(rule);

    Ok(rules)
}

#[allow(clippy::cast_sign_loss)]
fn add_socket_domain_rule(rules: &mut BTreeMap<i64, Vec<SeccompRule>>, domain: i32) -> Result<()> {
    let condition =
        SeccompCondition::new(0, SeccompCmpArgLen::Dword, SeccompCmpOp::Eq, domain as u64)
            .into_diagnostic()?;

    let rule = SeccompRule::new(vec![condition]).into_diagnostic()?;
    rules.entry(libc::SYS_socket).or_default().push(rule);
    Ok(())
}

/// Block `socket(AF_NETLINK, *, protocol)` for every protocol except
/// `NETLINK_ROUTE` (protocol 0).
///
/// Two AND'd conditions are required:
/// - arg0 == `AF_NETLINK`  (domain)
/// - arg2 != 0           (protocol is not `NETLINK_ROUTE`)
///
/// A seccomp rule fires (and returns EPERM) only when **all** conditions
/// match, so this rule is triggered for any `socket(AF_NETLINK, *, non-zero)`
/// call while leaving `socket(AF_NETLINK, *, 0)` (`NETLINK_ROUTE`) through.
#[allow(clippy::cast_sign_loss)]
fn add_netlink_non_route_rule(rules: &mut BTreeMap<i64, Vec<SeccompRule>>) -> Result<()> {
    let domain_condition = SeccompCondition::new(
        0, // domain argument
        SeccompCmpArgLen::Dword,
        SeccompCmpOp::Eq,
        libc::AF_NETLINK as u64,
    )
    .into_diagnostic()?;

    let protocol_condition = SeccompCondition::new(
        2, // protocol argument
        SeccompCmpArgLen::Dword,
        SeccompCmpOp::Ne,
        0, // NETLINK_ROUTE = 0
    )
    .into_diagnostic()?;

    let rule = SeccompRule::new(vec![domain_condition, protocol_condition]).into_diagnostic()?;
    rules.entry(libc::SYS_socket).or_default().push(rule);
    Ok(())
}

/// Block a syscall when a specific bit pattern is set in an argument.
///
/// Uses `MaskedEq` to check `(arg & flag_bit) == flag_bit`, which triggers
/// EPERM when the flag is present regardless of other bits in the argument.
fn add_masked_arg_rule(
    rules: &mut BTreeMap<i64, Vec<SeccompRule>>,
    syscall: i64,
    arg_index: u8,
    flag_bit: u64,
) -> Result<()> {
    let condition = SeccompCondition::new(
        arg_index,
        SeccompCmpArgLen::Dword,
        SeccompCmpOp::MaskedEq(flag_bit),
        flag_bit,
    )
    .into_diagnostic()?;
    let rule = SeccompRule::new(vec![condition]).into_diagnostic()?;
    rules.entry(syscall).or_default().push(rule);
    Ok(())
}

#[cfg(test)]
// libc/syscall FFI requires unsafe; these tests fork children and exercise
// blocked syscalls, so unsafe blocks/calls are pervasive.
#[allow(
    unsafe_code,
    unsafe_op_in_unsafe_fn,
    unused_unsafe,
    clippy::borrow_as_ptr,
    trivial_numeric_casts
)]
mod tests {
    use super::*;

    // These tests cover both filter construction (rule map shape and BPF
    // compilation) and selected runtime behavior on Linux via forked children.

    #[test]
    fn build_filter_proxy_mode_compiles() {
        let filter = build_filter(true);
        assert!(filter.is_ok(), "build_filter(true) should succeed");
    }

    #[test]
    fn build_filter_block_mode_compiles() {
        let filter = build_filter(false);
        assert!(filter.is_ok(), "build_filter(false) should succeed");
    }

    #[test]
    fn build_supervisor_prelude_filter_compiles() {
        let filter = build_supervisor_prelude_filter();
        assert!(
            filter.is_ok(),
            "build_supervisor_prelude_filter() should succeed"
        );
    }

    #[test]
    fn add_masked_arg_rule_creates_entry() {
        let mut rules: BTreeMap<i64, Vec<SeccompRule>> = BTreeMap::new();
        let result = add_masked_arg_rule(&mut rules, libc::SYS_execveat, 4, 0x1000);
        assert!(result.is_ok());
        assert!(
            rules.contains_key(&libc::SYS_execveat),
            "should have an entry for SYS_execveat"
        );
        assert_eq!(
            rules[&libc::SYS_execveat].len(),
            1,
            "should have exactly one rule"
        );
    }

    #[test]
    fn unconditional_blocks_present_in_filter() {
        // Build a real filter and verify all unconditional blocks are present.
        let filter_rules = build_filter_rules(true).unwrap();

        // Unconditional blocks have an empty Vec (no conditions = always match).
        let expected = [
            libc::SYS_memfd_create,
            libc::SYS_ptrace,
            libc::SYS_bpf,
            libc::SYS_process_vm_readv,
            libc::SYS_process_vm_writev,
            libc::SYS_pidfd_getfd,
            libc::SYS_pidfd_send_signal,
            libc::SYS_io_uring_setup,
            libc::SYS_mount,
            libc::SYS_fsopen,
            libc::SYS_fsconfig,
            libc::SYS_fsmount,
            libc::SYS_fspick,
            libc::SYS_move_mount,
            libc::SYS_open_tree,
            libc::SYS_setns,
            libc::SYS_umount2,
            libc::SYS_pivot_root,
            libc::SYS_userfaultfd,
            libc::SYS_perf_event_open,
        ];

        for syscall in expected {
            assert!(
                filter_rules.contains_key(&syscall),
                "syscall {syscall} should be in the rules map"
            );
            assert!(
                filter_rules[&syscall].is_empty(),
                "syscall {syscall} should have empty rules (unconditional block)"
            );
        }
    }

    #[test]
    fn conditional_blocks_have_rules() {
        // Build a real filter and verify the conditional syscalls have rule entries
        // (non-empty Vec means conditional match).
        let filter_rules = build_filter_rules(true).unwrap();

        for syscall in [
            libc::SYS_execveat,
            libc::SYS_unshare,
            libc::SYS_clone,
            libc::SYS_seccomp,
        ] {
            assert!(
                filter_rules.contains_key(&syscall),
                "syscall {syscall} should be in the rules map"
            );
            assert!(
                !filter_rules[&syscall].is_empty(),
                "syscall {syscall} should have conditional rules"
            );
        }
    }

    #[test]
    fn netlink_socket_rules_are_conditional_not_unconditional() {
        // SYS_socket must appear in the rules map (for domain blocks and the
        // AF_NETLINK+non-ROUTE filter), but it must NOT be an unconditional block
        // (empty Vec). An empty Vec would block ALL socket() calls, including
        // socket(AF_NETLINK, *, NETLINK_ROUTE=0) which getifaddrs(3) needs.
        let filter_rules = build_filter_rules(true).unwrap();

        assert!(
            filter_rules.contains_key(&libc::SYS_socket),
            "SYS_socket should be in the rules map (domain blocks present)"
        );

        // The Vec<SeccompRule> for SYS_socket must be non-empty (rules are
        // conditional), which is the opposite of an unconditional block.
        assert!(
            !filter_rules[&libc::SYS_socket].is_empty(),
            "SYS_socket should have conditional rules, not an unconditional block"
        );
    }

    #[test]
    fn supervisor_prelude_blocks_expected_syscalls() {
        let filter_rules = build_supervisor_prelude_rules();

        for syscall in [
            libc::SYS_mount,
            libc::SYS_fsopen,
            libc::SYS_fsconfig,
            libc::SYS_fsmount,
            libc::SYS_fspick,
            libc::SYS_move_mount,
            libc::SYS_open_tree,
            libc::SYS_pivot_root,
            libc::SYS_umount2,
            libc::SYS_bpf,
            libc::SYS_perf_event_open,
            libc::SYS_userfaultfd,
            libc::SYS_init_module,
            libc::SYS_finit_module,
            libc::SYS_delete_module,
            libc::SYS_kexec_load,
            SYS_kexec_file_load,
        ] {
            assert!(
                filter_rules.contains_key(&syscall),
                "syscall {syscall} should be in the supervisor prelude rules"
            );
            assert!(
                filter_rules[&syscall].is_empty(),
                "syscall {syscall} should be unconditionally blocked in the supervisor prelude"
            );
        }
    }

    #[test]
    fn supervisor_prelude_keeps_required_setup_syscalls_available() {
        let filter_rules = build_supervisor_prelude_rules();

        for syscall in [
            libc::SYS_setns,
            libc::SYS_clone,
            libc::SYS_unshare,
            libc::SYS_ptrace,
        ] {
            assert!(
                !filter_rules.contains_key(&syscall),
                "syscall {syscall} should remain available during supervisor startup"
            );
        }
    }

    #[test]
    fn compatibility_filter_compiles() {
        let bpf = build_compatibility_filter();
        assert!(
            bpf.is_ok(),
            "process API compatibility filter should compile"
        );
    }

    #[test]
    fn compatibility_syscalls_are_not_in_main_filter() {
        // These APIs must NOT be in the EPERM filter; the compatibility filter
        // reports them unavailable so process launchers can fall back.
        let filter_rules = build_filter_rules(true).unwrap();
        for syscall in [libc::SYS_clone3, libc::SYS_pidfd_open] {
            assert!(
                !filter_rules.contains_key(&syscall),
                "syscall {syscall} should use the ENOSYS compatibility filter"
            );
        }
    }

    // --- Behavioral tests ---
    //
    // These apply seccomp filters in a forked child and verify that blocked
    // syscalls actually return the expected errno. They only compile and run
    // on Linux (seccomp is a Linux kernel feature).

    /// Fork a child, apply the given filter, invoke `syscall_nr`, and return
    /// the errno observed by the child. The child exits 0 if the syscall
    /// returned the expected errno, 1 otherwise.
    unsafe fn assert_blocked_in_child(
        filter: &seccompiler::BpfProgram,
        syscall_nr: i64,
        expected_errno: i32,
    ) {
        let pid = libc::fork();
        assert!(pid >= 0, "fork failed");
        if pid == 0 {
            // Child: apply filter and try the syscall.
            libc::prctl(libc::PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0);
            apply_filter(filter).expect("apply_filter");
            let ret = libc::syscall(syscall_nr, 0 as libc::c_ulong, 0 as libc::c_ulong);
            let errno = *libc::__errno_location();
            if ret == -1 && errno == expected_errno {
                libc::_exit(0);
            } else {
                // Write diagnostic before exiting so test failures are debuggable.
                let msg = format!(
                    "syscall {syscall_nr}: expected errno={expected_errno}, got ret={ret} errno={errno}\n"
                );
                libc::write(2, msg.as_ptr().cast(), msg.len());
                libc::_exit(1);
            }
        }
        // Parent: wait for child.
        let mut status: libc::c_int = 0;
        libc::waitpid(pid, &mut status, 0);
        assert!(
            libc::WIFEXITED(status) && libc::WEXITSTATUS(status) == 0,
            "child failed: syscall {syscall_nr} was not blocked with errno {expected_errno}"
        );
    }

    unsafe fn install_runtime_filters_in_child(
        main_filter: &seccompiler::BpfProgram,
        compatibility_filter: &seccompiler::BpfProgram,
    ) {
        libc::prctl(libc::PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0);
        if let Err(err) = apply_runtime_filters(main_filter, compatibility_filter) {
            let msg = format!("failed to install runtime seccomp filters: {err}\n");
            libc::write(2, msg.as_ptr().cast(), msg.len());
            libc::_exit(1);
        }
    }

    #[test]
    fn behavioral_memfd_create_blocked() {
        let filter = build_filter(true).unwrap();
        unsafe { assert_blocked_in_child(&filter, libc::SYS_memfd_create, libc::EPERM) };
    }

    #[test]
    fn behavioral_getpid_allowed() {
        let filter = build_filter(true).unwrap();
        let pid = unsafe { libc::fork() };
        assert!(pid >= 0, "fork failed");
        if pid == 0 {
            // SAFETY: PR_SET_NO_NEW_PRIVS is required before applying the
            // filter and only tightens this forked test process.
            if unsafe { libc::prctl(libc::PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) } < 0 {
                libc::_exit(1);
            }
            apply_filter(&filter).expect("apply_filter");
            // SAFETY: getpid takes no arguments and has no memory side effects.
            let result = unsafe { libc::syscall(libc::SYS_getpid) };
            libc::_exit(if result > 0 { 0 } else { 1 });
        }
        let mut status: libc::c_int = 0;
        // SAFETY: pid is the direct child returned by fork and status is
        // writable storage for waitpid.
        assert_eq!(unsafe { libc::waitpid(pid, &mut status, 0) }, pid);
        assert!(
            libc::WIFEXITED(status) && libc::WEXITSTATUS(status) == 0,
            "getpid was denied by the built-in filter"
        );
    }

    #[test]
    fn behavioral_ptrace_blocked() {
        let filter = build_filter(true).unwrap();
        unsafe { assert_blocked_in_child(&filter, libc::SYS_ptrace, libc::EPERM) };
    }

    #[test]
    fn behavioral_process_vm_writev_blocked() {
        let filter = build_filter(true).unwrap();
        unsafe { assert_blocked_in_child(&filter, libc::SYS_process_vm_writev, libc::EPERM) };
    }

    #[test]
    fn behavioral_userfaultfd_blocked() {
        let filter = build_filter(true).unwrap();
        unsafe { assert_blocked_in_child(&filter, libc::SYS_userfaultfd, libc::EPERM) };
    }

    #[test]
    fn behavioral_perf_event_open_blocked() {
        let filter = build_filter(true).unwrap();
        unsafe { assert_blocked_in_child(&filter, libc::SYS_perf_event_open, libc::EPERM) };
    }

    #[test]
    fn behavioral_setns_blocked() {
        let filter = build_filter(true).unwrap();
        unsafe { assert_blocked_in_child(&filter, libc::SYS_setns, libc::EPERM) };
    }

    #[test]
    fn behavioral_supervisor_prelude_mount_blocked() {
        let pid = unsafe { libc::fork() };
        assert!(pid >= 0, "fork failed");
        if pid == 0 {
            unsafe {
                if let Err(err) = apply_supervisor_prelude() {
                    let msg = format!("failed to install supervisor prelude: {err}\n");
                    libc::write(2, msg.as_ptr().cast(), msg.len());
                    libc::_exit(1);
                }
                let ret = libc::syscall(
                    libc::SYS_mount,
                    std::ptr::null::<libc::c_char>(),
                    std::ptr::null::<libc::c_char>(),
                    std::ptr::null::<libc::c_char>(),
                    0 as libc::c_ulong,
                    std::ptr::null::<libc::c_void>(),
                );
                let errno = *libc::__errno_location();
                if ret == -1 && errno == libc::EPERM {
                    libc::_exit(0);
                } else {
                    let msg = format!(
                        "mount: expected EPERM after supervisor prelude, got ret={ret} errno={errno}\n"
                    );
                    libc::write(2, msg.as_ptr().cast(), msg.len());
                    libc::_exit(1);
                }
            }
        }

        let mut status: libc::c_int = 0;
        unsafe { libc::waitpid(pid, &mut status, 0) };
        assert!(
            unsafe { libc::WIFEXITED(status) && libc::WEXITSTATUS(status) == 0 },
            "mount should be blocked by the supervisor prelude filter"
        );
    }

    #[test]
    fn behavioral_clone3_returns_enosys() {
        // clone3 uses a separate filter that returns ENOSYS (not EPERM) so
        // glibc falls back to clone.
        let main_filter = build_filter(true).unwrap();
        let compatibility_filter = build_compatibility_filter().unwrap();
        // Apply in the same order as apply(): compatibility filter first, main filter second.
        let pid = unsafe { libc::fork() };
        assert!(pid >= 0, "fork failed");
        if pid == 0 {
            unsafe {
                install_runtime_filters_in_child(&main_filter, &compatibility_filter);
                let ret = libc::syscall(libc::SYS_clone3, 0 as libc::c_ulong, 0 as libc::c_ulong);
                let errno = *libc::__errno_location();
                if ret == -1 && errno == libc::ENOSYS {
                    libc::_exit(0);
                } else {
                    let msg = format!("clone3: expected ENOSYS, got ret={ret} errno={errno}\n");
                    libc::write(2, msg.as_ptr().cast(), msg.len());
                    libc::_exit(1);
                }
            }
        }
        let mut status: libc::c_int = 0;
        unsafe { libc::waitpid(pid, &mut status, 0) };
        assert!(
            unsafe { libc::WIFEXITED(status) && libc::WEXITSTATUS(status) == 0 },
            "clone3 should be blocked with ENOSYS, not EPERM"
        );
    }

    #[test]
    fn behavioral_pidfd_open_returns_enosys() {
        let filter = build_compatibility_filter().unwrap();
        unsafe { assert_blocked_in_child(&filter, libc::SYS_pidfd_open, libc::ENOSYS) };
    }

    #[test]
    fn behavioral_third_filter_install_blocked_after_startup() {
        let main_filter = build_filter(true).unwrap();
        let compatibility_filter = build_compatibility_filter().unwrap();
        let third_filter = build_compatibility_filter().unwrap();

        let pid = unsafe { libc::fork() };
        assert!(pid >= 0, "fork failed");
        if pid == 0 {
            unsafe {
                install_runtime_filters_in_child(&main_filter, &compatibility_filter);
                match apply_filter(&third_filter) {
                    Err(seccompiler::Error::Seccomp(e))
                        if e.raw_os_error() == Some(libc::EPERM) =>
                    {
                        libc::_exit(0);
                    }
                    Err(err) => {
                        let msg =
                            format!("third filter install failed with unexpected error: {err}\n");
                        libc::write(2, msg.as_ptr().cast(), msg.len());
                        libc::_exit(1);
                    }
                    Ok(()) => {
                        let msg = "third filter unexpectedly installed\n";
                        libc::write(2, msg.as_ptr().cast(), msg.len());
                        libc::_exit(1);
                    }
                }
            }
        }

        let mut status: libc::c_int = 0;
        unsafe { libc::waitpid(pid, &mut status, 0) };
        assert!(
            unsafe { libc::WIFEXITED(status) && libc::WEXITSTATUS(status) == 0 },
            "additional seccomp filter installation should be blocked after startup"
        );
    }

    #[test]
    fn behavioral_netlink_route_allowed() {
        // socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE=0) must succeed (not blocked).
        // This is the call getifaddrs(3) makes on Linux to enumerate interfaces.
        let filter = build_filter(true).unwrap();
        let pid = unsafe { libc::fork() };
        assert!(pid >= 0, "fork failed");
        if pid == 0 {
            unsafe {
                libc::prctl(libc::PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0);
                apply_filter(&filter).expect("apply_filter");
                // NETLINK_ROUTE = 0
                let fd = libc::socket(libc::AF_NETLINK, libc::SOCK_RAW, 0);
                if fd >= 0 {
                    libc::close(fd);
                    libc::_exit(0);
                } else {
                    let errno = *libc::__errno_location();
                    let msg = format!(
                        "socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE): expected success, got errno={errno}\n"
                    );
                    libc::write(2, msg.as_ptr().cast(), msg.len());
                    libc::_exit(1);
                }
            }
        }
        let mut status: libc::c_int = 0;
        unsafe { libc::waitpid(pid, &mut status, 0) };
        assert!(
            unsafe { libc::WIFEXITED(status) && libc::WEXITSTATUS(status) == 0 },
            "socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE) should be allowed for getifaddrs(3)"
        );
    }

    #[test]
    fn behavioral_netlink_non_route_blocked() {
        // socket(AF_NETLINK, SOCK_RAW, NETLINK_SOCK_DIAG=4) must be blocked.
        // NETLINK_SOCK_DIAG is representative of non-ROUTE netlink protocols
        // that have no legitimate use inside the sandbox.
        let filter = build_filter(true).unwrap();
        let pid = unsafe { libc::fork() };
        assert!(pid >= 0, "fork failed");
        if pid == 0 {
            unsafe {
                libc::prctl(libc::PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0);
                apply_filter(&filter).expect("apply_filter");
                // NETLINK_SOCK_DIAG = 4
                let fd = libc::socket(libc::AF_NETLINK, libc::SOCK_RAW, 4);
                let errno = *libc::__errno_location();
                if fd == -1 && errno == libc::EPERM {
                    libc::_exit(0);
                } else {
                    if fd >= 0 {
                        libc::close(fd);
                    }
                    let msg = format!(
                        "socket(AF_NETLINK, SOCK_RAW, NETLINK_SOCK_DIAG): expected EPERM, got fd={fd} errno={errno}\n"
                    );
                    libc::write(2, msg.as_ptr().cast(), msg.len());
                    libc::_exit(1);
                }
            }
        }
        let mut status: libc::c_int = 0;
        unsafe { libc::waitpid(pid, &mut status, 0) };
        assert!(
            unsafe { libc::WIFEXITED(status) && libc::WEXITSTATUS(status) == 0 },
            "socket(AF_NETLINK, SOCK_RAW, NETLINK_SOCK_DIAG) should be blocked with EPERM"
        );
    }

    #[test]
    fn behavioral_block_mode_denies_inet_and_packet_sockets() {
        let filter = build_filter(false).unwrap();
        let pid = unsafe { libc::fork() };
        assert!(pid >= 0, "fork failed");
        if pid == 0 {
            unsafe {
                libc::prctl(libc::PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0);
                apply_filter(&filter).expect("apply block-mode filter");
                for (domain, socket_type, protocol) in [
                    (libc::AF_INET, libc::SOCK_STREAM, 0),
                    (libc::AF_INET6, libc::SOCK_DGRAM, 0),
                    (libc::AF_PACKET, libc::SOCK_RAW, 0),
                ] {
                    let fd = libc::socket(domain, socket_type, protocol);
                    let errno = *libc::__errno_location();
                    if fd >= 0 || errno != libc::EPERM {
                        if fd >= 0 {
                            libc::close(fd);
                        }
                        libc::_exit(1);
                    }
                }
                let unix_fd = libc::socket(libc::AF_UNIX, libc::SOCK_STREAM, 0);
                if unix_fd < 0 {
                    libc::_exit(1);
                }
                libc::close(unix_fd);
                libc::_exit(0);
            }
        }
        let mut status: libc::c_int = 0;
        unsafe { libc::waitpid(pid, &mut status, 0) };
        assert!(
            unsafe { libc::WIFEXITED(status) && libc::WEXITSTATUS(status) == 0 },
            "block mode must deny IPv4, IPv6, and packet sockets while retaining Unix IPC"
        );
    }
}
