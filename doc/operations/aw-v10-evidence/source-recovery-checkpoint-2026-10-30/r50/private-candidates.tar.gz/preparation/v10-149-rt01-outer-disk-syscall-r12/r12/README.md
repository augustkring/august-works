# V10-149 RT-01 private R12 source delta

R12 is a private delta over the exact R11 candidate. The complete 12-path stage set is in `exact-stage-paths.txt`; candidate SHA-256 pins are in `source-pins.json`, and `source.patch` reconstructs the changed bytes from the R11 `files/` tree. R10/R11 evidence remains unchanged and historical.

The three Rust production/test deltas add Docker driver PID and memory-swap create settings plus bounded memory/disk probe corrections. The host-agent delta implements target-bound qualification credential probes using the existing OpenShell provider proxy: strict one-use JWT claim, command/target/scope/profile/body binding, fixed ToolGateway MCP path, expected-sandbox-ID provider attach/detach, persistent hashed jti replay fence, bounded output, exact typed mismatch/revocation responses, and cleanup journaling. Credential capability availability stays conditional on the inspected profile and exact current network policy. It does not put capability material in workload env/argv, returned probe output, or persistent host journal.

## Verification

The current private host-agent test suite passed 51/51 using mocked Docker and OpenShell CLI. It covers allow, raw-read, wrong-tool, wrong-binary, revoke, expected-ID attach/detach, target binding, and cleanup. Node syntax checks and Rustfmt 1.97.1 check passed. Raw logs are byte-preserved in `openshell.test.log` and `static-checks.log`.

No Cargo compilation or Rust tests were run for the changed R12 Rust paths. No physical Docker/OpenShell host, real local canary, or provider issuer run occurred. These tests qualify host-side decision logic only; they do not establish physical filesystem, syscall, resource, network, or credential enforcement. The full current-source shared/server typecheck and host-bridge integration are also not part of this R12 receipt. Capability flags remain contingent on the separate full qualification path and actual operator-controlled fixture evidence.
