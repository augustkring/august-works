# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: aw-v9-project-draft.spec.ts >> an explicit project draft recovers a lost Native acknowledgement after reload through reads without creating another project or running work
- Location: tests/e2e/aw-v9-project-draft.spec.ts:16:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "qu8lByP1wfXz4LOu1jEIm7OzbyinvNty"
Received: "user:qu8lByP1wfXz4LOu1jEIm7OzbyinvNty"
```

# Page snapshot

```yaml
- generic:
  - generic:
    - generic:
      - generic:
        - link:
          - /url: "#main-content"
          - text: Skip to Main Content
        - generic:
          - generic:
            - generic:
              - generic:
                - complementary:
                  - generic:
                    - button:
                      - generic:
                        - generic: D
                        - generic: Disposable Native project-draft qualification
                  - navigation:
                    - generic:
                      - generic:
                        - text: View
                        - combobox
                      - link:
                        - /url: /DISAA/dashboard
                        - generic: Home
                      - link:
                        - /url: /DISAA/needs-you
                        - generic: Needs You
                      - link:
                        - /url: /DISAA/work
                        - generic: Work
                      - link:
                        - /url: /DISAA/agents
                        - generic: Agents
                      - link:
                        - /url: /DISAA/apps
                        - generic: Apps
                      - link:
                        - /url: /DISAA/insights
                        - generic: Insights
                      - link:
                        - /url: /DISAA/advanced
                        - generic: Advanced
                      - generic:
                        - button: Ask Blentera
                        - link:
                          - /url: /DISAA/company/help
                          - generic: Help / Support
              - generic:
                - generic:
                  - button:
                    - generic: BR
                    - generic: Browser product reviewer
            - separator
          - generic:
            - generic:
              - region:
                - button: Ask Blentera
                - generic:
                  - generic:
                    - generic:
                      - generic: Language
                      - combobox
                - link:
                  - /url: /DISAA/company/help
                  - text: Help / Support
                - link:
                  - /url: mailto:support@blentera.com
                  - text: Contact support
                - link:
                  - /url: /DISAA/company/settings/instance/profile
            - generic:
              - generic:
                - main:
                  - generic:
                    - heading [level=1]: Home
                    - button: Ask Blentera
                    - paragraph: Nothing needs your attention right now.
  - dialog [active] [ref=e2]:
    - heading "Prepare a Project" [level=2] [ref=e3]
    - paragraph [ref=e4]: Review and edit your project before saving it.
    - generic [ref=e5]:
      - status [ref=e6]: Loading current work…
      - link "Check Projects" [ref=e7] [cursor=pointer]:
        - /url: /DISAA/projects
    - button "Close project draft" [ref=e8]
```

# Test source

```ts
  1   | import { createRequire } from "node:module";
  2   | import { expect, test, type APIResponse } from "@playwright/test";
  3   | import { registerEnglishAccountLocaleIsolation } from "./account-locale-isolation";
  4   | registerEnglishAccountLocaleIsolation(test);
  5   | const axePath = createRequire(import.meta.url).resolve("axe-core/axe.min.js");
  6   | async function json(response: APIResponse) {
  7   |   expect(response.ok(), `${response.status()}: ${await response.text()}`).toBe(
  8   |     true,
  9   |   );
  10  |   return response.json();
  11  | }
  12  | 
  13  | // Original authenticated-project APIs and current creator-bound receipt. Only
  14  | // the transport of the single committed POST and first receipt GET is aborted.
  15  | // This is software evidence, not hosted identity or live business acceptance.
  16  | test("an explicit project draft recovers a lost Native acknowledgement after reload through reads without creating another project or running work", async ({
  17  |   page,
  18  |   request,
  19  | }, info) => {
  20  |   test.setTimeout(120000);
  21  |   const flags = await json(
  22  |     await request.get("/api/instance/settings/experimental"),
  23  |   );
  24  |   const session = await json(await request.get("/api/auth/get-session"));
  25  |   await json(
  26  |     await request.patch("/api/instance/settings/experimental", {
  27  |       data: {
  28  |         experience_projection_v9: true,
  29  |         progressive_shell_v9: true,
  30  |         home_v9: true,
  31  |         ambient_commands_v9: true,
  32  |       },
  33  |     }),
  34  |   );
  35  |   const company = await json(
  36  |     await request.post("/api/companies", {
  37  |       data: { name: "Disposable Native project-draft qualification" },
  38  |     }),
  39  |   );
  40  |   const base = `/api/companies/${company.id}`;
  41  |   const attempts: Array<Record<string, unknown>> = [];
  42  |   let savedId: string | undefined, key: string | undefined, reads = 0;
  43  |   await page.route(`**${base}/projects?**`, async (route) => {
  44  |     if (route.request().method() !== "POST") return route.continue();
  45  |     expect(
  46  |       new URL(route.request().url()).searchParams.get("expectedActorId"),
> 47  |     ).toBe(session.user.id);
      |       ^ Error: expect(received).toBe(expected) // Object.is equality
  48  |     attempts.push(route.request().postDataJSON());
  49  |     expect(attempts).toHaveLength(1);
  50  |     key = attempts[0]!.idempotencyKey as string;
  51  |     const response = await route.fetch();
  52  |     const result = await json(response);
  53  |     expect(result.companyId).toBe(company.id);
  54  |     expect(result.status).toBe("planned");
  55  |     savedId ??= result.id;
  56  |     expect(result.id).toBe(savedId);
  57  |     await route.abort("failed");
  58  |   });
  59  |   await page.route(`**${base}/projects/create-receipts/**`, async (route) => {
  60  |     expect(route.request().method()).toBe("GET");
  61  |     expect(new URL(route.request().url()).searchParams.get("expectedActorId")).toBe(session.user.id);
  62  |     reads++;
  63  |     if (reads === 1) return route.abort("failed");
  64  |     await route.continue();
  65  |   });
  66  |   try {
  67  |     await page.goto(`/${company.issuePrefix}/dashboard`);
  68  |     await expect(
  69  |       page.getByRole("heading", { level: 1, name: "Home", exact: true }),
  70  |     ).toBeVisible();
  71  |     await page.keyboard.press("Control+k");
  72  |     await page.getByRole("combobox").fill("opret et projekt Customer Research");
  73  |     await page
  74  |       .getByRole("option", { name: "Prepare a Project", exact: true })
  75  |       .click();
  76  |     await expect(
  77  |       page.getByRole("textbox", { name: "Project name", exact: true }),
  78  |     ).toHaveValue("Customer Research");
  79  |     expect(attempts).toHaveLength(0);
  80  |     await page
  81  |       .getByRole("textbox", {
  82  |         name: "Goal or description (optional)",
  83  |         exact: true,
  84  |       })
  85  |       .fill("Private browser draft: review our customer research plan.");
  86  |     await page
  87  |       .getByRole("button", { name: "Create project", exact: true })
  88  |       .click();
  89  |     await expect(page.getByRole("alert")).toContainText(
  90  |       "We have not confirmed this project",
  91  |     );
  92  |     expect(attempts).toHaveLength(1);
  93  |     await expect(page.getByRole("textbox", { name: "Project name", exact: true })).toHaveCount(0);
  94  |     const once = await json(await request.get(`${base}/projects`));
  95  |     expect(once).toHaveLength(1);
  96  |     expect(once[0].id).toBe(savedId);
  97  |     await json(await request.patch(`/api/projects/${savedId}`, { data: { name: "Current Native research project" } }));
  98  |     const pending = await page.evaluate(() => sessionStorage.getItem("aw.v9.pending-project-receipts"));
  99  |     expect(pending).toContain(key!);
  100 |     expect(pending).not.toContain("Private browser draft");
  101 |     expect(pending).not.toContain("Customer Research");
  102 |     await page.reload();
  103 |     await expect(page.getByRole("heading", { level: 1, name: "Home", exact: true })).toBeVisible();
  104 |     await page.keyboard.press("Control+k");
  105 |     await page.getByRole("combobox").fill("create project A separate new draft");
  106 |     await page.getByRole("option", { name: "Prepare a Project", exact: true }).click();
  107 |     await expect(page.getByRole("heading", { name: "Find your project", exact: true })).toBeVisible();
  108 |     await expect(
  109 |       page.getByRole("heading", { name: "Project saved", exact: true }),
  110 |     ).toBeVisible();
  111 |     await expect(
  112 |       page.getByRole("heading", { name: "Project saved", exact: true }),
  113 |     ).toBeFocused();
  114 |     expect(attempts).toHaveLength(1);
  115 |     expect(reads).toBe(2);
  116 |     await expect(page.getByRole("dialog")).toContainText("Current Native research project");
  117 |     expect(await page.evaluate(() => sessionStorage.getItem("aw.v9.pending-project-receipts"))).toBeNull();
  118 |     const retained = await json(await request.get(`${base}/projects`));
  119 |     expect(retained).toHaveLength(1);
  120 |     expect(retained[0].id).toBe(savedId);
  121 |     expect(await json(await request.get(`${base}/issues`))).toEqual([]);
  122 |     expect(await json(await request.get(`${base}/agents`))).toEqual([]);
  123 |     const runs = await json(await request.get(`${base}/heartbeat-runs`));
  124 |     expect(Array.isArray(runs) ? runs : runs.items).toEqual([]);
  125 |     await page.setViewportSize({ width: 390, height: 844 });
  126 |     await page.addScriptTag({ path: axePath });
  127 |     expect(
  128 |       await page.evaluate(
  129 |         async () =>
  130 |           (
  131 |             await (
  132 |               window as unknown as {
  133 |                 axe: { run(scope: string): Promise<{ violations: unknown[] }> };
  134 |               }
  135 |             ).axe.run('[role="dialog"]')
  136 |           ).violations,
  137 |       ),
  138 |     ).toEqual([]);
  139 |     expect(
  140 |       await page.evaluate(
  141 |         () => document.documentElement.scrollWidth <= innerWidth,
  142 |       ),
  143 |     ).toBe(true);
  144 |     await page.screenshot({
  145 |       path: info.outputPath("v9-native-project-receipt-mobile.png"),
  146 |       fullPage: true,
  147 |     });
```