# Native 12 full CI log triage (private)

Run `42670374661`, job `129350434204` (`General tests (managed Native (12/16))`), merge SHA `14496880b89122931662c5a3eca6f557e000df52` for PR head `2e308ac740572b92204112453733f495d6bfeb80`. The completed job log is available from the GitHub log connector; CLI `gh run view --job --log` returned zero bytes. Vitest summary: 23 passed / 10 failed, one module, 895.11 seconds test time.

## Seven timeouts

The seven `STACK_TRACE_ERROR` cases in the compact artifact are all explicit Vitest timeouts in the full log: `Test timed out in 120000ms` for each. Cases: Human session/generation binding (line 723), company deletion stopping the live Native run (746), settlement/usage/purge (785), exact-budget boundary (1047), 64th/65th calls (1062), settlement rollback (1084), unknown hold/purge (1108). This is not a hidden application exception.

Allowlisted `conversation_software_host_progress` snapshots for these calls show fixture `stage: admit`, run status `running`, null run error code; event tails include process start/identity/session start and, in some cases, turn start/completion. The logs do not expose a single common lower-level blocking operation or closed error code, so avoid claiming a product admission failure. The wrapper's bounded 120s watchdog expires while the real local managed conversation fixture remains running.

## Three exact state mismatches

- At line 1298, after `broker.expire(now+60s)`, a dispatched row remains `dispatched`, expected `unknown`.
- At line 1346, after authority removal and `broker.expire(now+60s)`, a reserved row remains `reserved`, expected `cancelled`.
- At line 1842, `offboarding.processOne(now+1s)` returns true when the assertion expects false because the test's pending reservation should block deletion progress.

Source identifies a likely test-isolation cause for those state mismatches: this suite opens one embedded PG in `beforeAll` (lines 195-200), then `beforeEach` seeds a distinct new company but never resets the DB (line 209 onward). `broker.expire` calls `expireModelReservations(db, now, limit=20)`; that function queries eligible rows across the whole DB, sorts globally oldest-first, and processes only 20 (model reservations lines 1313 onward). `offboarding.processOne` likewise queries all companies' eligible operations, orders globally by `createdAt`, and processes the oldest one (offboarding.ts:165 onward). The later fixture therefore competes with earlier test companies for bounded global sweeps and worker selection. The root local focused expiry pair passed, consistent with isolation affecting the full-module run; it does not establish that production expiry semantics are wrong.

## Safest small fixture proposal

Give each `it` a fresh real embedded PG cluster, not a fresh fake row or production change: move `startEmbeddedPostgresTestDatabase`, `createDb`, singleton initialization, and `enableV5ForTest` into `beforeEach`; extend `afterEach` to run existing provider-fixture cleanup and then `database.cleanup()` in `finally`; keep `afterAll` as fallback cleanup. This preserves all 33 assertions and bounded production expiry/purge behavior while isolating global sweeps and background operations. The embedded PG helper documents this cost class as usually under 10s, but total 33-case runtime still needs measured CI qualification before merging; do not rerun here.

No product source changes or DB/test executions were made for this diagnosis.
