from pathlib import Path
import hashlib,json,difflib
r=Path('/workspace/blentera-v10');rel='server/src/services/native-direct-input.ts';a=(r/rel).read_text();s=a
def rep(old,new):
 global s
 assert s.count(old)==1,(old[:90],s.count(old));s=s.replace(old,new,1)
rep('''interface NativeSourceGraphObligations {
  actorKey: string;''','''interface NativeScopedTaskRead {
  companyId: string; actor: AuthorizationActor; issueId: string; contentHash: string; snapshotDigest: string;
  childHandle: NativeSourceGraphObligationHandle; mutableSources: NativeMutableSourceDependencies;
}
interface NativeSourceGraphObligations {
  actorKey: string;
  scopedTasks: NativeScopedTaskRead[];''')
rep('''  return { actorKey, readerSets, ownerReads, taskPins, analyticalReads, readResults, runtimeSkills };''','''  const scopedTasks = [...context.scopedTaskReads.values()];
  if (scopedTasks.some(check => nativeSha256(check.actor) !== actorKey)) return undefined;
  return { actorKey, readerSets, ownerReads, taskPins, analyticalReads, readResults, runtimeSkills, scopedTasks };''')
rep('''      ...obligations.readResults, ...obligations.runtimeSkills].some''','''      ...obligations.readResults, ...obligations.runtimeSkills, ...obligations.scopedTasks].some''')
rep('''  for (const [id, pin] of obligations.taskPins) scope.taskTemporalScopes.set(id, pin);
  if (process.env''','''  for (const [id, pin] of obligations.taskPins) scope.taskTemporalScopes.set(id, pin);
  for (const check of obligations.scopedTasks) deferNativeScopedTaskRead(scope, check);
  if (process.env''')
rep('''  checkedReadResultChecks: Set<string>;
  pendingReaderChecks:''','''  checkedReadResultChecks: Set<string>;
  scopedTaskReads: Map<string, NativeScopedTaskRead>; pendingScopedTaskReads: Set<string>; activeScopedTaskReads: Set<string>;
  pendingReaderChecks:''')
rep('''    deferredReadResultChecks: new Map(), checkedReadResultChecks: new Set(),''','''    deferredReadResultChecks: new Map(), checkedReadResultChecks: new Set(),
    scopedTaskReads: new Map(), pendingScopedTaskReads: new Set(), activeScopedTaskReads: new Set(),''')
# Defer only immutable task prefix descriptors, never child reader decisions.
needle='async function flushNativeSourceReaderChecks(context: NativeSourceReadContext) {'
helper='''function nativeScopedTaskReadKey(input: Pick<NativeScopedTaskRead,
  "companyId" | "actor" | "issueId" | "contentHash" | "snapshotDigest">): string {
  return `scoped-task-reader:${nativeSha256({ companyId: input.companyId, actor: input.actor,
    issueId: input.issueId, contentHash: input.contentHash, snapshotDigest: input.snapshotDigest })}`;
}
function deferNativeScopedTaskRead(scope: NativeSourceReadScope, input: NativeScopedTaskRead): void {
  const key = nativeScopedTaskReadKey(input);
  const groupKey = `${input.companyId}:${nativeSha256(input.actor)}`;
  if (!scope.context.scopedTaskReads.has(key)) {
    nativeSourceReadWork(scope, "deferNativeScopedTaskRead:1");
    if (scope.context.scopedTaskReads.size >= 512) throw forbidden("The Native scoped Task recheck exceeds its work bound");
    scope.context.scopedTaskReads.set(key, input);
    scope.context.pendingScopedTaskReads.add(key);
    const group = scope.context.deferredReaderChecks.get(groupKey);
    if (group) { group.version += 1; scope.context.pendingReaderChecks.add(groupKey); }
  } else if (!scope.context.activeScopedTaskReads.has(key) && !scope.context.activeReaderChecks.has(groupKey)) {
    // A known immutable prefix remains an obligation. Reusing a proof after a
    // prior flush must reenter its exact scope and recheck current readers.
    scope.context.pendingScopedTaskReads.add(key);
  }
}
async function recheckNativeScopedTaskRead(scope: NativeSourceReadScope, input: NativeScopedTaskRead): Promise<void> {
  const key = nativeScopedTaskReadKey(input);
  if (scope.active.has(key)) throw forbidden("The Native scoped Task reader graph contains a cycle");
  nativeSourceReadWork(scope, "recheckNativeScopedTaskRead:1");
  addNativeSourceActiveVisit(scope, key);
  try {
    await withReadPinnedNativeTaskSnapshot(scope.context.db as Db, input.actor, input.companyId, input.issueId,
      async (hash, digest) => {
        if (hash !== input.contentHash || digest !== input.snapshotDigest)
          throw forbidden("The Native scoped Task source changed");
        await withNativeSourceReadScope(scope.context.db as Db, input.actor, input.companyId, async childScope => {
          const completed = input.childHandle.completed;
          if (!childScope.context.ancestry.graphProofsDisabled && completed && input.mutableSources.compatible &&
            await nativeFrozenMutableSourcesCurrent(childScope.context.db as Db, input.companyId, input.mutableSources, childScope) &&
            await replayNativeSourceGraphObligations(childScope, completed)) return;
          // Changed dependencies, incomplete metadata, and effect-disabled
          // ancestry retain the complete current-owner traversal.
          markNativeSourceProofsIncompatible(scope);
          await assertNativeTaskSnapshotOwnerCurrentInScope(childScope.context.db as Db, input.companyId,
            input.actor, input.issueId, childScope);
        });
      });
  } finally { scope.active.delete(key); }
}
'''
rep(needle,helper+needle)
# Drain all scoped source work before the parent's final actor ACL queries.
rep('''    if (context.pendingReaderChecks.size) {
      const groupKeys''','''    while (context.pendingScopedTaskReads.size) {
      const keys = [...context.pendingScopedTaskReads];
      context.pendingScopedTaskReads.clear();
      for (const key of keys) {
        const check = context.scopedTaskReads.get(key);
        if (!check) continue;
        const scope = context.scopes.get(nativeSha256(check.actor));
        if (!scope) throw forbidden("The Native scoped Task reader is unavailable");
        context.activeScopedTaskReads.add(key);
        try { await recheckNativeScopedTaskRead(scope, check); }
        finally { context.activeScopedTaskReads.delete(key); }
        const groupKey = `${check.companyId}:${nativeSha256(check.actor)}`;
        if (context.deferredReaderChecks.has(groupKey)) context.pendingReaderChecks.add(groupKey);
      }
    }
    if (context.pendingReaderChecks.size) {
      const groupKeys''')
rep('''    if (!pendingResults && !pendingAnalytical && !context.pendingReaderChecks.size) break;''','''    if (!pendingResults && !pendingAnalytical && !context.pendingReaderChecks.size && !context.pendingScopedTaskReads.size) break;''')
# Move only the Task's frozen private traversal into the scope actually installed by its pinned prefix.
a0=s.index('    const validateProtocolOneTask = async () => {',s.index('async function assertNativeTaskSnapshotOwnerCurrentInScope'))
b0=s.index('    if (snapshot.data.inputs.some(source =>',s.index('    return snapshot.data.digest;',a0))
block=s[a0:b0]
block=block.replace('const validateProtocolOneTask = async () => {','const validateProtocolOneTask = async (taskScope: NativeSourceReadScope, taskProofs: NativeSiblingToolSourceProofs) => {',1)
import re
block=re.sub(r'\bscope\b','taskScope',block)
block=re.sub(r'\bsiblingToolSourceProofs\b','taskProofs',block)
s=s[:a0]+block+s[b0:]
old='''    if (snapshot.data.inputs.some(source =>
      source.kind === "worker_model_dispatch" || source.kind === "conversation_model_dispatch"))
      return withReadPinnedNativeTaskSnapshot(db, actor, companyId, issueId, validateProtocolOneTask);
    return validateProtocolOneTask();'''
new='''    if (snapshot.data.inputs.some(source =>
      source.kind === "worker_model_dispatch" || source.kind === "conversation_model_dispatch"))
      return withReadPinnedNativeTaskSnapshot(db, actor, companyId, issueId, async () => {
        const current = nativeSourceReadScopes.getStore();
        if (current === scope.context && current.active && current.db === (db as object) &&
          current.memoryTemporalIdentity === activeMemoryTemporalReadScopeIdentity(db, actor) &&
          scope.actorKey === nativeSha256(actor)) {
          if (!current.ancestry.graphProofsDisabled && current.privacyLockedCompanies.has(companyId))
            return validateProtocolOneTask(scope, siblingToolSourceProofs);
          // An effect-disabled matching context still needs fresh public maps.
          return withNativeSourceReadScope(db, actor, companyId,
            freshScope => validateProtocolOneTask(freshScope, new Map()));
        }
        const childHandle: NativeSourceGraphObligationHandle = {};
        const mutableSources = newNativeMutableSources();
        const descriptor = { companyId, actor, issueId, contentHash: snapshot.data.owner.contentHash,
          snapshotDigest: snapshot.data.digest, childHandle, mutableSources };
        const visitKey = nativeScopedTaskReadKey(descriptor);
        if (scope.active.has(visitKey)) throw forbidden("The Native scoped Task source graph contains a cycle");
        addNativeSourceActiveVisit(scope, visitKey);
        let childContext: NativeSourceReadContext | undefined;
        let result: string;
        try {
          result = await withNativeSourceReadScope(db, actor, companyId, async childScope => {
            childContext = childScope.context;
            childScope.context.readerObligations ??= childHandle;
            const stack = childScope.context.ancestry.frozenTaskProofStacks.get(childScope.actorKey) ?? [];
            childScope.context.ancestry.frozenTaskProofStacks.set(childScope.actorKey, stack);
            const frame: NativeSourceProofFrame = { visitKey, descendants: new Set(), mutableSources };
            stack.push(frame);
            try { return await validateProtocolOneTask(childScope, new Map()); }
            finally { if (stack.at(-1) === frame) stack.pop(); }
          });
        } finally { scope.active.delete(visitKey); }
        if (childContext !== scope.context) {
          // Preserve a pure scoped obligation, not its reader results. Its
          // complete queues are replayed only after reentering this Task prefix.
          const retainedHandle = childContext?.readerObligations;
          if (retainedHandle) descriptor.childHandle = retainedHandle;
          if (!retainedHandle?.completed || !mutableSources.compatible)
            markNativeSourceProofsIncompatible(scope);
          deferNativeScopedTaskRead(scope, descriptor);
          const ownPin = { contentHash: snapshot.data.owner.contentHash, snapshotDigest: snapshot.data.digest };
          const previous = scope.taskTemporalScopes.get(issueId);
          if (previous && !isDeepStrictEqual(previous, ownPin)) throw forbidden("The Native Task owner scope changed");
          scope.taskTemporalScopes.set(issueId, ownPin);
          deferNativeSourceOwnerReaderChecks(scope, { companyId, actor, issueIds: [issueId] });
        }
        return result;
      });
    return validateProtocolOneTask(scope, siblingToolSourceProofs);'''
rep(old,new)
o=Path('/workspace/v10-preparation/native-task-prefix-scope-r62-candidate');p=o/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
(o/'candidate.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
(o/'manifest.json').write_text(json.dumps({rel:{'priorSha256':hashlib.sha256(a.encode()).hexdigest(),'candidateSha256':hashlib.sha256(s.encode()).hexdigest()}},indent=2))
