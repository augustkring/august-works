#!/usr/bin/env bash
set -uo pipefail
NAME=v10-069-private-r3-20261030
OUT=/workspace/v10-preparation/$NAME
REPO=/workspace/blentera-v10
CAND=/workspace/v10-preparation/v10-069-private-candidate-r3
MIRROR=/workspace/v10-dep-qualification
COMPILED_BACKUP_READY=0
mkdir -m 700 "$OUT" || exit 73
exec 9>/workspace/v10-preparation/v10-pg-tests.lock
flock -x 9
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH
cleanup() {
  local failed=0 path expected actual
  while read -r expected path; do
    actual=$(sha256sum "$MIRROR/$path" | awk '{print $1}')
    if [[ "$actual" == "$expected" ]]; then
      cp "$OUT/mirror-baseline/$path" "$MIRROR/$path"
    else
      printf 'MIRROR_RESTORE_GUARD_MISMATCH %s expected_candidate=%s actual=%s\n' "$path" "$expected" "$actual" >> "$OUT/cleanup.log"
      failed=1
    fi
  done < "$CAND/candidate-source-pins.sha256"
  if (( failed == 0 )); then
    while read -r expected path; do
      actual=$(sha256sum "$MIRROR/$path" | awk '{print $1}')
      if [[ "$actual" != "$expected" ]]; then printf 'MIRROR_BASELINE_MISMATCH %s expected=%s actual=%s\n' "$path" "$expected" "$actual" >> "$OUT/cleanup.log"; failed=1; fi
    done < "$OUT/mirror-baseline-pins.sha256"
  fi
  if (( COMPILED_BACKUP_READY == 1 )); then
    rm -rf "$MIRROR/packages/db/dist" "$MIRROR/packages/shared/dist"
    mkdir -p "$MIRROR/packages/db" "$MIRROR/packages/shared"
    cp -a "$OUT/compiled-baseline/packages/db/dist" "$MIRROR/packages/db/dist"
    cp -a "$OUT/compiled-baseline/packages/shared/dist" "$MIRROR/packages/shared/dist"
    find "$MIRROR/packages/db" "$MIRROR/packages/shared" -maxdepth 1 -type f -name '*.tsbuildinfo' -delete
    find "$OUT/compiled-baseline/packages/db" -maxdepth 1 -type f -name '*.tsbuildinfo' -exec cp -a {} "$MIRROR/packages/db/" \;
    find "$OUT/compiled-baseline/packages/shared" -maxdepth 1 -type f -name '*.tsbuildinfo' -exec cp -a {} "$MIRROR/packages/shared/" \;
    (cd "$MIRROR" && find packages/db/dist packages/shared/dist -type f -print0 | sort -z | xargs -0 sha256sum) > "$OUT/compiled-output-restored.sha256"
    cmp "$OUT/compiled-output-baseline.sha256" "$OUT/compiled-output-restored.sha256" || failed=1
  fi
  printf '%s\n' "$failed" > "$OUT/cleanup.exit"
  return "$failed"
}
trap cleanup EXIT INT TERM
cd "$REPO" || exit 70
sha256sum -c "$CAND/baseline-source-pins.sha256" > "$OUT/main-baseline-guard.log" 2>&1 || { echo 73 > "$OUT/exit"; exit 73; }
python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$OUT/source-pins.json" > "$OUT/snapshot.log" 2>&1
snapshot_rc=$?
printf '%s\n' "$snapshot_rc" > "$OUT/snapshot.exit"
if (( snapshot_rc != 0 )); then echo "$snapshot_rc" > "$OUT/exit"; exit "$snapshot_rc"; fi
if [[ -e "$MIRROR/server/src/services/experience/private-0565/member-continuity-preflight.ts" ]]; then
  echo 'orphaned private-0565 TypeScript module remains in mirror after source reconstruction' > "$OUT/mirror-cleanliness.log"
  echo 75 > "$OUT/exit"
  exit 75
fi
mkdir -p "$OUT/mirror-baseline"
: > "$OUT/mirror-baseline-pins.sha256"
: > "$OUT/overlay-pins.json"
mkdir -p "$OUT/compiled-baseline/packages/db" "$OUT/compiled-baseline/packages/shared"
cp -a "$MIRROR/packages/db/dist" "$OUT/compiled-baseline/packages/db/dist"
cp -a "$MIRROR/packages/shared/dist" "$OUT/compiled-baseline/packages/shared/dist"
find "$MIRROR/packages/db" -maxdepth 1 -type f -name '*.tsbuildinfo' -exec cp -a {} "$OUT/compiled-baseline/packages/db/" \;
find "$MIRROR/packages/shared" -maxdepth 1 -type f -name '*.tsbuildinfo' -exec cp -a {} "$OUT/compiled-baseline/packages/shared/" \;
(cd "$MIRROR" && find packages/db/dist packages/shared/dist -type f -print0 | sort -z | xargs -0 sha256sum) > "$OUT/compiled-output-baseline.sha256"
COMPILED_BACKUP_READY=1
python3 - "$OUT" "$CAND" "$MIRROR" <<'PY'
import hashlib,json,sys
from pathlib import Path
out,cand,mirror=map(Path,sys.argv[1:])
paths=[line.strip() for line in (cand/'owned-files.txt').read_text().splitlines() if line.strip()]
rows=[]
for rel in paths:
 src=mirror/rel; saved=out/'mirror-baseline'/rel; saved.parent.mkdir(parents=True,exist_ok=True)
 data=src.read_bytes(); saved.write_bytes(data); rows.append(f'{hashlib.sha256(data).hexdigest()}  {rel}\n')
(out/'mirror-baseline-pins.sha256').write_text(''.join(rows))
overlay=[]
for rel in paths:
 data=(cand/'candidate-files'/rel).read_bytes(); target=mirror/rel; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(data)
 overlay.append({'path':rel,'sha256':hashlib.sha256(data).hexdigest()})
(out/'overlay-pins.json').write_text(json.dumps({'qualificationWorkspace':str(mirror),'copiedFiles':overlay},indent=2)+'\n')
PY
: > "$OUT/pre-overlay-mirror-guard.log"
while read -r expected path; do
  actual=$(sha256sum "$OUT/mirror-baseline/$path" | awk '{print $1}')
  if [[ "$actual" != "$expected" ]]; then printf 'MIRROR_COPY_MISMATCH %s expected=%s actual=%s\n' "$path" "$expected" "$actual" >> "$OUT/pre-overlay-mirror-guard.log"; echo 74 > "$OUT/exit"; exit 74; fi
done < "$OUT/mirror-baseline-pins.sha256"
node /workspace/v10-preparation/check-snapshot-syntax.cjs "$OUT/overlay-pins.json" > "$OUT/overlay-syntax.log" 2>&1
syntax_rc=$?
printf '%s\n' "$syntax_rc" > "$OUT/overlay-syntax.exit"
if (( syntax_rc != 0 )); then echo "$syntax_rc" > "$OUT/exit"; exit "$syntax_rc"; fi
cd "$MIRROR" || exit 70
timeout 240s pnpm --dir "$MIRROR/packages/db" build > "$OUT/db-build.log" 2>&1
db_build_rc=$?
printf '%s\n' "$db_build_rc" > "$OUT/db-build.exit"
timeout 240s pnpm --dir "$MIRROR/packages/shared" build > "$OUT/shared-build.log" 2>&1
shared_build_rc=$?
printf '%s\n' "$shared_build_rc" > "$OUT/shared-build.exit"
if (( db_build_rc || shared_build_rc )); then echo 1 > "$OUT/exit"; exit 1; fi
cd "$MIRROR/server" || exit 70
timeout 240s pnpm exec vitest run src/__tests__/tool-access-service.test.ts -t 'bounds full GitHub repository access pagination|binds a managed GitHub identity and protects refresh from concurrent access changes' --reporter=verbose > "$OUT/access.test.log" 2>&1
access_rc=$?; printf '%s\n' "$access_rc" > "$OUT/access.test.exit"
timeout 240s pnpm exec vitest run src/services/tool-connection-lifecycle.test.ts --reporter=verbose > "$OUT/lifecycle.test.log" 2>&1
lifecycle_rc=$?; printf '%s\n' "$lifecycle_rc" > "$OUT/lifecycle.test.exit"
timeout 240s pnpm exec vitest run src/__tests__/github-connection-events.test.ts --reporter=verbose > "$OUT/events.test.log" 2>&1
events_rc=$?; printf '%s\n' "$events_rc" > "$OUT/events.test.exit"
timeout 240s pnpm exec vitest run src/__tests__/v9-connector-recovery.integration.test.ts --reporter=verbose > "$OUT/recovery.test.log" 2>&1
recovery_rc=$?; printf '%s\n' "$recovery_rc" > "$OUT/recovery.test.exit"
timeout 600s pnpm exec tsc --noEmit --singleThreaded > "$OUT/server-tsc.log" 2>&1
tsc_rc=$?; printf '%s\n' "$tsc_rc" > "$OUT/server-tsc.exit"
printf 'db_build=%s shared_build=%s access=%s lifecycle=%s events=%s recovery=%s server_tsc=%s\n' "$db_build_rc" "$shared_build_rc" "$access_rc" "$lifecycle_rc" "$events_rc" "$recovery_rc" "$tsc_rc" > "$OUT/result.txt"
if (( access_rc || lifecycle_rc || events_rc || recovery_rc || tsc_rc )); then echo 1 > "$OUT/exit"; exit 1; fi
echo 0 > "$OUT/exit"
