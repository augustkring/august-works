from pathlib import Path
p=Path('/workspace/blentera-v10/server/src/services/native-direct-input.ts');s=p.read_text()
a=s.index('async function withNativeSourceGraphProof(');b=s.index('\n}\n',a);c=s[a:b]
c=c.replace('policy: NativePayloadSourcePolicy; inputs: NativePayloadSourceInput[] }, read:', 'policy: NativePayloadSourcePolicy; inputs: NativePayloadSourceInput[]; validatedDepth?: number }, read:')
c=c.replace('const proof = eligible ? proofs.get(key) : undefined;', 'const candidate = eligible ? proofs.get(key) : undefined;\n  const proof = candidate && (input.validatedDepth === undefined || input.validatedDepth <= (candidate.validatedDepth ?? -1)) ? candidate : undefined;')
c=c.replace('policy: input.policy, inputs: input.inputs });', 'policy: input.policy, inputs: input.inputs, validatedDepth: input.validatedDepth === undefined ? undefined :\n          Math.max(input.validatedDepth, candidate?.validatedDepth ?? -1) });')
s=s[:a]+c+s[b:]
a=s.index('async function assertNativeModelOutputCaptureCurrentInScope(');b=s.index('\n}\n',a);c=s[a:b]
managed='''  await assertNativeManagedConsumedSourceSetCurrentInScope(db, { companyId, issueId, runId: capture.runId,
    actor, components: capture.consumedSourceComponents, sourceSet: capture.sourceSet }, scope, siblingToolSourceProofs);
'''
assert c.count(managed)==1;c=c.replace(managed,'')
needle='''  // The source-set walk above checks every ordinary owner. Keep the''';assert c.count(needle)==1
start='''  const captureProofKey = `capture-node:${nativeSha256({ companyId, issueId, runId: capture.runId,
    actor, actorScope: scope.actorKey, memoryTemporalIdentity: scope.context.memoryTemporalIdentity,
    conversationState, capture })}`;
  await withNativeSourceGraphProof(scope, siblingToolSourceProofs, captureProofKey, {
    companyId, runId: capture.runId, actor, policy: capture.sourceSet.policy,
    inputs: capture.sourceSet.inputs, validatedDepth: depth,
  }, async () => {
'''+managed
c=c.replace(needle,start+needle)
assert c.endswith('\n');c=c.rstrip()+'\n  });\n'
s=s[:a]+c+s[b:]
Path('/workspace/v10-preparation/native-capture-node-candidate.ts').write_text(s)
