/** PRIVATE 0565 candidate: current responsibility readers backed by the
 * existing native domain services and source guards. This module performs no
 * mutations and creates no credential/session/effect actors. */
import { and, eq, inArray } from "drizzle-orm";
import type { Db } from "@paperclipai/db";
import {
  aiUseCases, aiUseCaseVersions, businessExperiments, businessMetrics, decisions,
  humanWorkflowCoverages, issues, routines, workflowRuns, workflows,
} from "@paperclipai/db";
import type { AuthorizationAction, AuthorizationActor } from "../../authorization.js";
import { authorizationService, workflowRunReadSqlCondition } from "../../authorization.js";
import { workflowService } from "../../workflows/workflow-service.js";
import { routineService } from "../../routines.js";
import { businessMetricService } from "../../business-metrics/service.js";
import { businessExperimentService } from "../../business-experiments/service.js";
import { canReadDecisionSource } from "../../decision-queues.js";
import { resolveCurrentDefaultResponsibleHuman } from "../../company-responsibility.js";
import { accessService } from "../../access.js";
import { assertV7Enabled } from "../../v7-authorization.js";
import { HttpError } from "../../../errors.js";
import { responsibilitySourceVersion } from "./native-metadata-sources.js";
import { responsibilityPolicySubject, canSubjectPerformNativeRead } from "./native-subject-policy.js";
import type { NativeResponsibilityReadPorts, ResponsibilityReadPort } from "./native-reader-ports.js";
import type { CurrentNativeResponsibility } from "./authorized-subset-reader.js";
import type { ResponsibilityScanKind } from "./responsibility-scan.js";

const hidden: CurrentNativeResponsibility = { state: "hidden" };
const missing: CurrentNativeResponsibility = { state: "missing" };
const stale: CurrentNativeResponsibility = { state: "stale" };
const denied = (error: unknown) => error instanceof HttpError && [403, 404].includes(error.status);
const userActor = (userId: string) => responsibilityPolicySubject(userId);
function isBoardHuman(actor: AuthorizationActor): actor is AuthorizationActor & { type: "board"; userId: string } {
  return actor.type === "board" && Boolean(actor.userId) && actor.source !== "local_implicit";
}
async function currentCompanyAction(db: Db, actor: AuthorizationActor, companyId: string, action: AuthorizationAction) {
  if (actor.type !== "board" || !actor.userId) return false;
  return (await authorizationService(db).decide({ actor, action, resource: { type: "company", companyId } })).allowed;
}
async function subjectCovered(db: Db, companyId: string, ownerUserId: string | null, action: AuthorizationAction,
  sourceRead: (subject: AuthorizationActor) => Promise<boolean>) {
  const fallback = await resolveCurrentDefaultResponsibleHuman(db, companyId);
  for (const userId of [...new Set([ownerUserId, fallback].filter((id): id is string => Boolean(id)))]) {
    if (!await canSubjectPerformNativeRead({ db, companyId, userId, action, resource: { type: "company", companyId } })) continue;
    if (await sourceRead(userActor(userId))) return true;
  }
  return false;
}
function asPort(fn: ResponsibilityReadPort): ResponsibilityReadPort { return fn; }

export function nativeWorkflowResponsibilityReader(db: Db): ResponsibilityReadPort {
  return asPort(async (actor, companyId, id) => {
    if (!isBoardHuman(actor)) return hidden;
    const [row] = await db.select({ id: workflows.id, updatedAt: workflows.updatedAt, archivedAt: workflows.archivedAt })
      .from(workflows).where(and(eq(workflows.companyId, companyId), eq(workflows.id, id))).limit(1);
    if (!row || row.archivedAt) return missing;
    const sourceVersion = responsibilitySourceVersion("workflow", row.id, row.updatedAt);
    if (!await currentCompanyAction(db, actor, companyId, "workflows:read")) return hidden;
    try {
      if (!await workflowService(db).getDetail(companyId, id, actor)) return missing;
    } catch (error) { if (denied(error)) return hidden; throw error; }
    const covered = await subjectCovered(db, companyId, null, "workflows:edit", async subject => {
      try { return Boolean(await workflowService(db).getDetail(companyId, id, subject)); }
      catch (error) { if (denied(error)) return false; throw error; }
    });
    const [current] = await db.select({ updatedAt: workflows.updatedAt }).from(workflows)
      .where(and(eq(workflows.companyId, companyId), eq(workflows.id, id), isNull(workflows.archivedAt))).limit(1);
    if (!current) return missing;
    if (responsibilitySourceVersion("workflow", id, current.updatedAt) !== sourceVersion) return stale;
    return { state: "visible", currentSourceVersion: sourceVersion, coveredByAuthorizedHumanOrNativeGroup: covered };
  });
}

export function nativeRoutineResponsibilityReader(db: Db): ResponsibilityReadPort {
  return asPort(async (actor, companyId, id) => {
    if (!isBoardHuman(actor) || !await canSubjectPerformNativeRead({ db, companyId, userId: actor.userId,
      action: "company_scope:read", resource: { type: "company", companyId } })) return hidden;
    const [row] = await db.select({ id: routines.id, companyId: routines.companyId, status: routines.status,
      responsibleUserId: routines.responsibleUserId, updatedAt: routines.updatedAt })
      .from(routines).where(and(eq(routines.companyId, companyId), eq(routines.id, id))).limit(1);
    if (!row || !["active", "paused"].includes(row.status)) return missing;
    const sourceVersion = responsibilitySourceVersion("routine", row.id, row.updatedAt);
    const readAs = async (subject: AuthorizationActor) => {
      try { return Boolean(await routineService(db, { sourceActor: subject }).get(id)); }
      catch (error) { if (denied(error)) return false; throw error; }
    };
    if (!await readAs(actor)) return hidden;
    const covered = await subjectCovered(db, companyId, row.responsibleUserId, "company_scope:read", readAs);
    return { state: "visible", currentSourceVersion: sourceVersion, coveredByAuthorizedHumanOrNativeGroup: covered };
  });
}

export function nativeMetricResponsibilityReader(db: Db): ResponsibilityReadPort {
  return asPort(async (actor, companyId, id) => {
    if (!isBoardHuman(actor)) return hidden;
    const [row] = await db.select({ id: businessMetrics.id, updatedAt: businessMetrics.updatedAt,
      status: businessMetrics.status, publishedVersionId: businessMetrics.publishedVersionId })
      .from(businessMetrics).where(and(eq(businessMetrics.companyId, companyId), eq(businessMetrics.id, id))).limit(1);
    if (!row || row.status !== "published" || !row.publishedVersionId) return missing;
    const sourceVersion = responsibilitySourceVersion("metric", row.id, row.updatedAt);
    const inspect = async (subject: AuthorizationActor) => {
      try { return await businessMetricService(db).inspectPublishedDefinition(companyId, subject, id, row.publishedVersionId!); }
      catch (error) { if (denied(error)) return null; throw error; }
    };
    const viewer = await inspect(actor);
    if (!viewer) return hidden;
    const canonicalOwner = viewer.version.definition.ownerUserId ?? null;
    const covered = await subjectCovered(db, companyId, canonicalOwner, "company_scope:read", async subject => Boolean(await inspect(subject)));
    const [current] = await db.select({ updatedAt: businessMetrics.updatedAt, publishedVersionId: businessMetrics.publishedVersionId,
      status: businessMetrics.status }).from(businessMetrics)
      .where(and(eq(businessMetrics.companyId, companyId), eq(businessMetrics.id, id))).limit(1);
    if (!current || current.status !== "published" || current.publishedVersionId !== row.publishedVersionId) return stale;
    if (responsibilitySourceVersion("metric", id, current.updatedAt) !== sourceVersion) return stale;
    return { state: "visible", currentSourceVersion: sourceVersion, coveredByAuthorizedHumanOrNativeGroup: covered };
  });
}

export function nativeExperimentResponsibilityReader(db: Db): ResponsibilityReadPort {
  return asPort(async (actor, companyId, id) => {
    if (!isBoardHuman(actor)) return hidden;
    const [row] = await db.select({ id: businessExperiments.id, updatedAt: businessExperiments.updatedAt, state: businessExperiments.state })
      .from(businessExperiments).where(and(eq(businessExperiments.companyId, companyId), eq(businessExperiments.id, id))).limit(1);
    if (!row || !["in_review", "ready", "running", "paused", "analyzing"].includes(row.state)) return missing;
    const sourceVersion = responsibilitySourceVersion("experiment", row.id, row.updatedAt);
    const inspect = async (subject: AuthorizationActor) => {
      try { return await businessExperimentService(db).detail(companyId, subject, id); }
      catch (error) { if (denied(error)) return null; throw error; }
    };
    const viewer = await inspect(actor);
    if (!viewer) return hidden;
    const latest = viewer.versions[0];
    const ownerUserId = latest?.definition.ownerUserId ?? null;
    const covered = Boolean(latest && latest.currentQualification === "current") && await subjectCovered(db, companyId,
      ownerUserId, "company_scope:read", async subject => {
        const current = await inspect(subject);
        return Boolean(current?.versions[0]?.currentQualification === "current");
      });
    const [current] = await db.select({ updatedAt: businessExperiments.updatedAt, state: businessExperiments.state })
      .from(businessExperiments).where(and(eq(businessExperiments.companyId, companyId), eq(businessExperiments.id, id))).limit(1);
    if (!current || current.state !== row.state || responsibilitySourceVersion("experiment", id, current.updatedAt) !== sourceVersion) return stale;
    return { state: "visible", currentSourceVersion: sourceVersion, coveredByAuthorizedHumanOrNativeGroup: covered };
  });
}

export function nativeDecisionResponsibilityReader(db: Db): ResponsibilityReadPort {
  return asPort(async (actor, companyId, id) => {
    if (!isBoardHuman(actor) || !await currentCompanyAction(db, actor, companyId, "decision_queue:read")) return hidden;
    const [row] = await db.select({ id: decisions.id, updatedAt: decisions.updatedAt,
      status: decisions.status, expiresAt: decisions.expiresAt, responsibleUserId: issues.responsibleUserId })
      .from(decisions).innerJoin(issues, and(eq(issues.companyId, decisions.companyId), eq(issues.id, decisions.originIssueId)))
      .where(and(eq(decisions.companyId, companyId), eq(decisions.id, id))).limit(1);
    if (!row || row.status !== "open" || row.expiresAt <= new Date()) return missing;
    const sourceVersion = responsibilitySourceVersion("decision", row.id, row.updatedAt);
    if (!await canReadDecisionSource(db, actor, companyId, "decision", id)) return hidden;
    const canOwn = async (subject: AuthorizationActor) => currentCompanyAction(db, subject, companyId, "decision_queue:read") &&
      canReadDecisionSource(db, subject, companyId, "decision", id);
    const covered = await subjectCovered(db, companyId, row.responsibleUserId, "decision_queue:read", canOwn);
    const [current] = await db.select({ updatedAt: decisions.updatedAt, status: decisions.status, expiresAt: decisions.expiresAt })
      .from(decisions).where(and(eq(decisions.companyId, companyId), eq(decisions.id, id))).limit(1);
    if (!current || current.status !== "open" || current.expiresAt <= new Date() ||
      responsibilitySourceVersion("decision", id, current.updatedAt) !== sourceVersion) return stale;
    return { state: "visible", currentSourceVersion: sourceVersion, coveredByAuthorizedHumanOrNativeGroup: covered };
  });
}

export function nativeAiUseCaseResponsibilityReader(db: Db): ResponsibilityReadPort {
  return asPort(async (actor, companyId, id) => {
    if (!isBoardHuman(actor) || !await currentCompanyAction(db, actor, companyId, "company_scope:read")) return hidden;
    await assertV7Enabled(db, "ai_use_cases_v7");
    const [row] = await db.select({ id: aiUseCases.id, updatedAt: aiUseCases.updatedAt, ownerUserId: aiUseCases.ownerUserId,
      purposeVersion: aiUseCases.purposeVersion, status: aiUseCases.status })
      .from(aiUseCases).where(and(eq(aiUseCases.companyId, companyId), eq(aiUseCases.id, id))).limit(1);
    if (!row || row.status === "retired") return missing;
    const [version] = await db.select({ id: aiUseCaseVersions.id, createdAt: aiUseCaseVersions.createdAt })
      .from(aiUseCaseVersions).where(and(eq(aiUseCaseVersions.companyId, companyId), eq(aiUseCaseVersions.useCaseId, id),
        eq(aiUseCaseVersions.purposeVersion, row.purposeVersion))).limit(1);
    if (!version) return missing;
    const sourceVersion = responsibilitySourceVersion("ai_use_case", row.id, row.updatedAt);
    const covered = await subjectCovered(db, companyId, row.ownerUserId, "company_scope:read", async subject => {
      if (!await currentCompanyAction(db, subject, companyId, "company_scope:read")) return false;
      const [current] = await db.select({ purposeVersion: aiUseCases.purposeVersion }).from(aiUseCases)
        .innerJoin(aiUseCaseVersions, and(eq(aiUseCaseVersions.companyId, aiUseCases.companyId),
          eq(aiUseCaseVersions.useCaseId, aiUseCases.id), eq(aiUseCaseVersions.purposeVersion, aiUseCases.purposeVersion)))
        .where(and(eq(aiUseCases.companyId, companyId), eq(aiUseCases.id, id), eq(aiUseCaseVersions.id, version.id))).limit(1);
      return Boolean(current);
    });
    const [current] = await db.select({ updatedAt: aiUseCases.updatedAt, purposeVersion: aiUseCases.purposeVersion,
      status: aiUseCases.status }).from(aiUseCases).where(and(eq(aiUseCases.companyId, companyId), eq(aiUseCases.id, id))).limit(1);
    if (!current || current.purposeVersion !== row.purposeVersion || current.status === "retired" ||
      responsibilitySourceVersion("ai_use_case", id, current.updatedAt) !== sourceVersion) return stale;
    return { state: "visible", currentSourceVersion: sourceVersion, coveredByAuthorizedHumanOrNativeGroup: covered };
  });
}

export function nativeWorkflowRunResponsibilityReader(db: Db): ResponsibilityReadPort {
  return asPort(async (actor, companyId, id) => {
    if (!isBoardHuman(actor) || !await currentCompanyAction(db, actor, companyId, "workflows:read")) return hidden;
    const [row] = await db.select({ id: workflowRuns.id, updatedAt: workflowRuns.updatedAt, status: workflowRuns.status,
      responsibleUserId: workflowRuns.responsibleUserId, workflowId: workflowRuns.workflowId,
      workflowRevisionId: workflowRuns.workflowRevisionId, humanCoverageId: workflowRuns.humanCoverageId,
      companyId: workflowRuns.companyId, sourceWorkflows: workflowRuns.authoringSourceWorkflowIds })
      .from(workflowRuns).where(and(eq(workflowRuns.companyId, companyId), eq(workflowRuns.id, id),
        inArray(workflowRuns.status, ["queued", "running", "waiting", "recovering", "cancelling"]))).limit(1);
    if (!row) return missing;
    const sourceVersion = responsibilitySourceVersion("workflow_run", row.id, row.updatedAt);
    const readRunAs = async (subject: AuthorizationActor) => {
      const [permitted] = await db.select({ id: workflowRuns.id }).from(workflowRuns).where(and(
        eq(workflowRuns.companyId, companyId), eq(workflowRuns.id, id), await workflowRunReadSqlCondition(db, subject),
      )).limit(1);
      if (!permitted) return false;
      const sourceWorkflowIds = [...new Set(row.sourceWorkflows ?? [])];
      if (sourceWorkflowIds.length > 32) throw new Error("workflow_run_source_budget_exceeded");
      try {
        if (!await workflowService(db).getDetail(companyId, row.workflowId, subject)) return false;
        if (!await workflowService(db).getRevision(companyId, row.workflowId, row.workflowRevisionId, subject)) return false;
        for (const sourceWorkflowId of sourceWorkflowIds) {
          if (!await workflowService(db).getDetail(companyId, sourceWorkflowId, subject)) return false;
        }
      } catch (error) { if (denied(error)) return false; throw error; }
      if (row.humanCoverageId && row.responsibleUserId === subject.userId) {
        try {
          const valid = await db.transaction(async raw => {
            const tx = raw as unknown as Db;
            const [coverage] = await tx.select({ scopeType: humanWorkflowCoverages.scopeType,
              taskId: humanWorkflowCoverages.taskId }).from(humanWorkflowCoverages)
              .where(and(eq(humanWorkflowCoverages.companyId, companyId),
                eq(humanWorkflowCoverages.id, row.humanCoverageId))).limit(1);
            if (!coverage) return false;
            await accessService(tx).authorizeWorkflowCoverage({ tx: raw, companyId, coverageId: row.humanCoverageId,
              delegateeUserId: subject.userId!, workflowId: row.workflowId, workflowRevisionId: row.workflowRevisionId,
              scopeType: coverage.scopeType as "manual" | "task", taskId: coverage.taskId });
            return true;
          });
          if (!valid) return false;
        } catch (error) { if (denied(error)) return false; throw error; }
      }
      return true;
    };
    if (!await readRunAs(actor)) return hidden;
    const covered = await subjectCovered(db, companyId, row.responsibleUserId, "workflows:run", readRunAs);
    const [current] = await db.select({ updatedAt: workflowRuns.updatedAt, status: workflowRuns.status })
      .from(workflowRuns).where(and(eq(workflowRuns.companyId, companyId), eq(workflowRuns.id, id))).limit(1);
    if (!current || !["queued", "running", "waiting", "recovering", "cancelling"].includes(current.status) ||
      responsibilitySourceVersion("workflow_run", id, current.updatedAt) !== sourceVersion) return stale;
    return { state: "visible", currentSourceVersion: sourceVersion, coveredByAuthorizedHumanOrNativeGroup: covered };
  });
}

/** Concrete implementations for the seven native sources with reusable current
 * read APIs. Remaining ports are implemented by their own owner adapters. */
export function bindKnownNativeResponsibilityPorts(db: Db, remaining: Omit<NativeResponsibilityReadPorts,
  "workflow" | "routine" | "metric" | "experiment" | "decision" | "ai_use_case" | "workflow_run">): NativeResponsibilityReadPorts {
  return { ...remaining, workflow: nativeWorkflowResponsibilityReader(db), routine: nativeRoutineResponsibilityReader(db),
    metric: nativeMetricResponsibilityReader(db), experiment: nativeExperimentResponsibilityReader(db),
    decision: nativeDecisionResponsibilityReader(db), ai_use_case: nativeAiUseCaseResponsibilityReader(db),
    workflow_run: nativeWorkflowRunResponsibilityReader(db) };
}
