# Native Claude built-in capture protocol candidate

This private candidate carries actual Claude ACP `PreToolUse` and `PostToolBatch` hook tuples through an awaited private ACPX request, an authenticated Runnerd control frame, and the existing server-owned source writer callback. The SDK hook resolves only after the server returns a scoped receipt. The callback path is conditional on a transient server-minted Claude source authority; it does not add a public MCP tool, durable event type, ledger, or database table. Hook failure explicitly cancels the active Claude turn.

The source patch is composed against the pinned MIRROR source paths listed in `source-copy-pins.json`; it is dry-run checked and kept separate from the shared source tree. The two pinned package patches in `package-patches/` are composed against pristine versions recorded by `snapshot-source-pins.json`.

The current authenticated Runnerd frame has a 64 KiB outer bound and hex-encoded ciphertext. To stay beneath that transport limit, the candidate caps each full-tree workspace snapshot at 4 KiB raw and the serialized capture event at 24 KiB. Larger workspaces or tuples fail closed before acknowledgement. Ordinary repository qualification is not claimed.

The feature remains disabled for production: a server-minted authority, complete gateway source mapping, and sanitized-workspace admission have not been qualified. In particular, a full-tree snapshot can contain unrelated small files such as `.env`; do not enable authority for ordinary or unsanitized checkouts.

Validation: full `paperclip-runner` TypeScript and surfaces TSC passed in a private full-package overlay; focused bridge, witness, and authenticated PRP tests passed 10/10. Private Rust `native_capture` tests compiled and passed 3/3 with the pinned 1.97.1 toolchain; the shared target cache is `/tmp/blentera-final-source-rust-target-20261101` (about 1.0 GiB).
