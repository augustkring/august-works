from pathlib import Path
import hashlib,json,difflib
r=Path('/workspace/blentera-v10');rel='server/src/services/native-direct-input.ts';a=(r/rel).read_text();s=a
old='''      hint: number; hints: Record<string, number>; calls: number; cold: number; hits: number; inputs: number; policyRefs: number;'''
new='''      hint: number; hints: Record<string, number>; ambientOwners: Record<string, number>;
      calls: number; cold: number; hits: number; inputs: number; policyRefs: number;'''
assert old in s;s=s.replace(old,new,1)
old='''        shape: diagnostic.shapes.get(shapeKey)!, hint: historicalDocumentDepthHint, hints: {},'''
new='''        shape: diagnostic.shapes.get(shapeKey)!, hint: historicalDocumentDepthHint, hints: {}, ambientOwners: {},'''
assert old in s;s=s.replace(old,new,1)
old='''      node.hints[historicalDocumentDepthHint] = (node.hints[historicalDocumentDepthHint] ?? 0) + 1; }'''
new='''      node.hints[historicalDocumentDepthHint] = (node.hints[historicalDocumentDepthHint] ?? 0) + 1;
      const ambientIdentity = activeMemoryTemporalReadScopeIdentity(scope.context.db as Db, input.actor);
      if (!diagnostic.memoryOwners.has(ambientIdentity) && diagnostic.memoryOwners.size < 512)
        diagnostic.memoryOwners.set(ambientIdentity, diagnostic.memoryOwners.size + 1);
      const ambientOwner = diagnostic.memoryOwners.get(ambientIdentity) ?? 0;
      node.ambientOwners[ambientOwner] = (node.ambientOwners[ambientOwner] ?? 0) + 1;
    }'''
assert old in s;s=s.replace(old,new,1)
old='  if (!diagnostic.memoryOwners.has(scope.context.memoryTemporalIdentity))'
new='  if (!diagnostic.memoryOwners.has(scope.context.memoryTemporalIdentity) && diagnostic.memoryOwners.size < 512)'
assert old in s;s=s.replace(old,new,1)
old='memoryOwner: diagnostic.memoryOwners.get(scope.context.memoryTemporalIdentity)!,'
new='memoryOwner: diagnostic.memoryOwners.get(scope.context.memoryTemporalIdentity) ?? 0,'
assert old in s;s=s.replace(old,new,1)
o=Path('/workspace/v10-preparation/native-ambient-prefix-r61-candidate');p=o/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
(o/'candidate.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
(o/'manifest.json').write_text(json.dumps({rel:{'priorSha256':hashlib.sha256(a.encode()).hexdigest(),'candidateSha256':hashlib.sha256(s.encode()).hexdigest()}},indent=2))
