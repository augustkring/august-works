#!/usr/bin/env bash
set -euo pipefail
exec flock -x /workspace/v10-preparation/v10-pg-tests.lock bash -lc '
set +e
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH
OUT=/workspace/v10-preparation/platform-skill-runtime-conformance-r5-20261030
ROOT=/workspace/v10-dep-qualification
MAIN=/workspace/blentera-v10
if [[ -e "$OUT" ]]; then echo "evidence directory already exists: $OUT" >&2; exit 73; fi
mkdir -p "$OUT"
trap '\''rc=$?; printf "%s\n" "$rc" > "$OUT/exit"; exit "$rc"'\'' EXIT
printf "qualifiedWorkspace=%s\nmainSource=%s\nlock=%s\nprofiles=blentera-managed-native,openclaw,hermes-local\n" "$ROOT" "$MAIN" /workspace/v10-preparation/v10-pg-tests.lock > "$OUT/runner.txt"
python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$OUT/source-pins.json" > "$OUT/snapshot.log" 2>&1
rc=$?; printf "%s\n" "$rc" > "$OUT/snapshot.exit"; if ((rc)); then exit "$rc"; fi
node /workspace/v10-preparation/check-snapshot-syntax.cjs "$OUT/source-pins.json" > "$OUT/oxc.log" 2>&1
rc=$?; printf "%s\n" "$rc" > "$OUT/oxc.exit"; if ((rc)); then exit "$rc"; fi
python3 - "$ROOT" "$MAIN" "$OUT" <<"PY"
import hashlib,json,pathlib,re,sys
root,main,out=map(pathlib.Path,sys.argv[1:]); pkg=root/"packages/adapters/openclaw-gateway/node_modules/typebox"
resolved=pkg.resolve(strict=True); manifest=json.loads((resolved/"package.json").read_text())
assert manifest.get("version")=="1.4.1",("Unexpected TypeBox version",manifest.get("version"))
lock=(main/"pnpm-lock.yaml").read_text()
start=lock.index("  packages/adapters/openclaw-gateway:\n")
end=lock.find("\n  packages/",start+1)
importer=lock[start:end if end!=-1 else None]
assert re.search(r"typebox:\n\s+specifier: 1\.4\.1\n\s+version: 1\.4\.1",importer)
locked=root/"node_modules/.pnpm/typebox@1.4.1/node_modules/typebox"
def tree(directory):
 return {str(p.relative_to(directory)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(directory.rglob("*")) if p.is_file()}
assert tree(resolved)==tree(locked),"Workspace TypeBox link differs from the exact installed pnpm-lock package tree"
rows={"requestedVersion":"1.4.1","installedVersion":manifest["version"],"workspaceLink":str(pkg),"resolvedPackageDirectory":str(resolved),
 "packageJsonSha256":hashlib.sha256((resolved/"package.json").read_bytes()).hexdigest(),"lockDeclaration":"packages/adapters/openclaw-gateway devDependency typebox=1.4.1 and pnpm-lock.yaml importer/package lock entry",
 "lockStorePackageDirectory":str(locked),"lockStoreTreeMatchesWorkspaceLink":True,"lockStoreTreeFileCount":len(tree(locked)),
 "networkInstall":False,"codeOrLockChange":False,"qualificationWorkspace":str(root)}
(out/"typebox-dependency-receipt.json").write_text(json.dumps(rows,indent=2)+"\n")
PY
rc=$?; printf "%s\n" "$rc" > "$OUT/typebox-dependency-receipt.exit"; if ((rc)); then exit "$rc"; fi
mkdir -p "$ROOT/doc/operations/aw-v10-evidence/platform-skill-runtime-conformance-2026-10-30-r5"
cd "$ROOT"
node scripts/run-platform-skill-runtime-conformance.mjs \
  --profile blentera-managed-native --profile openclaw --profile hermes-local \
  --evidence-dir doc/operations/aw-v10-evidence/platform-skill-runtime-conformance-2026-10-30-r5 \
  > "$OUT/tests.log" 2>&1
rc=$?; printf "%s\n" "$rc" > "$OUT/tests.exit"
REPORT="$ROOT/doc/operations/aw-v10-evidence/platform-skill-runtime-conformance-2026-10-30-r5/blentera-managed-native+openclaw+hermes-local-report.json"
if [[ -f "$REPORT" ]]; then cp "$REPORT" "$OUT/runtime-report.json"; fi
cd "$MAIN"
sha256sum "$OUT"/source-pins.json "$OUT"/runner.txt "$OUT"/typebox-dependency-receipt.json "$OUT"/snapshot.log "$OUT"/oxc.log "$OUT"/tests.log > "$OUT/SHA256SUMS"
exit "$rc"
' _
