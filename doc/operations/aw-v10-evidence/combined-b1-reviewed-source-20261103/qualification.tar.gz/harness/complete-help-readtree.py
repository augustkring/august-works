import hashlib,json,pathlib,re
root=pathlib.Path('/workspace/blentera-v10');work=pathlib.Path('/tmp/combined-b1-final-metadata-20261103/worktree');out=pathlib.Path('/workspace/v10-preparation/combined-b1-final-metadata-20261103');sha=lambda b:hashlib.sha256(b).hexdigest();copied={}
for p in (root/'docs').rglob('*.md'):
 if p.is_symlink():continue
 target=work/p.relative_to(root)
 if not target.exists():target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes());copied[str(p.relative_to(root))]=sha(p.read_bytes())
for p in (root/'docs').rglob('*.md'):
 match=re.search(r'^linked_source_files: \[(.*)\]$',p.read_text(),re.M)
 if not match:continue
 for item in match.group(1).split(','):
  name=item.strip().strip('\"\'');target=work/name
  if not target.exists():assert (root/name).is_file(),name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((root/name).read_bytes());copied[name]=sha((root/name).read_bytes())
(out/'help-readtree-completion.json').write_text(json.dumps({'scope':'Actual unchanged Markdown and linked inputs only; no reviewed source/metadata/guard change.','copiedFiles':copied,'count':len(copied)},indent=2)+'\n');print(json.dumps({'additionalUnchangedReadFiles':len(copied)}))
