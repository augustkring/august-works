import type { InteractionResolverGovernance } from "@paperclipai/shared";
import { pgTable, uuid, text, integer, timestamp, boolean, jsonb, uniqueIndex, check } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const companies = pgTable(
  "companies",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    name: text("name").notNull(),
    description: text("description"),
    // Company-level defaults apply only when a user's account preference or a
    // record-specific locale/timezone has not been set.
    locale: text("locale").notNull().default("en"),
    timezone: text("timezone").notNull().default("UTC"),
    status: text("status").notNull().default("active"),
    pauseReason: text("pause_reason"),
    // Native offboarding binds immutable-evidence deletion to its own database
    // transaction. A committed receipt cannot authorize a later transaction.
    contentErasureTransactionId: text("content_erasure_transaction_id"),
    pausedAt: timestamp("paused_at", { withTimezone: true }),
    issuePrefix: text("issue_prefix").notNull().default("PAP"),
    issueCounter: integer("issue_counter").notNull().default(0),
    budgetMonthlyCents: integer("budget_monthly_cents").notNull().default(0),
    spentMonthlyCents: integer("spent_monthly_cents").notNull().default(0),
    defaultResponsibleUserId: text("default_responsible_user_id"),
    /** Optional accountable tenant contacts; these labels do not grant access. */
    securityContactUserId: text("security_contact_user_id"),
    supportIncidentContactUserId: text("support_incident_contact_user_id"),
    requireBoardApprovalForNewAgents: boolean("require_board_approval_for_new_agents")
      .notNull()
      .default(false),
    interactionResolverGovernance: jsonb("interaction_resolver_governance")
      .$type<InteractionResolverGovernance>()
      .notNull()
      .default({}),
    feedbackDataSharingEnabled: boolean("feedback_data_sharing_enabled")
      .notNull()
      .default(false),
    feedbackDataSharingConsentAt: timestamp("feedback_data_sharing_consent_at", { withTimezone: true }),
    feedbackDataSharingConsentByUserId: text("feedback_data_sharing_consent_by_user_id"),
    feedbackDataSharingTermsVersion: text("feedback_data_sharing_terms_version"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    issuePrefixUniqueIdx: uniqueIndex("companies_issue_prefix_idx").on(table.issuePrefix),
    localeCheck: check("companies_locale_check", sql`${table.locale} in ('en', 'da')`),
    timezoneCheck: check("companies_timezone_check", sql`length(trim(${table.timezone})) > 0`),
  }),
);
