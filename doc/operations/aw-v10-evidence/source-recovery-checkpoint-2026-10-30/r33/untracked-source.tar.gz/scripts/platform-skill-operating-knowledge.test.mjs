import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";
import test from "node:test";
import { canonicalScenario, checkPlatformSkillOperatingKnowledge, validateFieldCase } from "./platform-skill-operating-knowledge.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

test("V10-145 audit binds every §21B/§43.15 domain to the current immutable release and retained Promptfoo scenarios", async () => {
  assert.deepEqual(await checkPlatformSkillOperatingKnowledge(root), []);
  const audit = JSON.parse(readFileSync(path.join(root, "evals/platform-skill/operating-knowledge.json"), "utf8"));
  const corpus = JSON.parse(readFileSync(path.join(root, "evals/platform-skill/cases.json"), "utf8"));
  for (const [domain, ids] of Object.entries(audit.coverageDomains)) {
    for (const id of ids) assert.equal(corpus.cases.find(item => item.id === id)?.domain, domain);
  }
  assert.equal(canonicalScenario("native_required_skill_missing")?.includes("required Platform Skill"), true);
});

test("field regressions require reviewed provenance and reject raw customer paths, identifiers, and transcript fields", () => {
  const safe = {
    id: "field-support-recovery", domain: "failure_recovery", scenario: "timeout_after_possible_external_effect",
    expectAny: ["unknown", "verify"], forbidAny: ["retry immediately"], sourceKind: "support_failure",
    sourceDigest: "a".repeat(64), reviewedByRole: "platform_skill_owner", reviewedAt: "2026-10-30T12:00:00.000Z",
    privacyReview: "sanitized_scenario_only", copiedTranscript: false,
  };
  assert.deepEqual(validateFieldCase(safe), []);
  assert.match(validateFieldCase({ ...safe, sourcePath: "/private/support/123" }).join("\n"), /unrecognized content field/);
  assert.match(validateFieldCase({ ...safe, sourceDigest: "ticket-123" }).join("\n"), /SHA-256/);
  assert.match(validateFieldCase({ ...safe, copiedTranscript: true }).join("\n"), /no transcript retention/);
  assert.match(validateFieldCase({ ...safe, reviewedAt: undefined }).join("\n"), /reviewedAt/);
});

test("efficiency observations are diagnostic only and unqualified runtimes are not asserted as GA", async () => {
  const audit = JSON.parse(readFileSync(path.join(root, "evals/platform-skill/operating-knowledge.json"), "utf8"));
  const corpus = JSON.parse(readFileSync(path.join(root, "evals/platform-skill/cases.json"), "utf8"));
  assert.equal(corpus.cases.filter(item => item.domain === "efficiency").every(item => item.diagnosticOnly && item.expectAny.length === 0 && item.forbidAny.length === 0), true);
  assert.deepEqual(audit.gaProfileInventory.claimedProfiles, []);
  assert.equal(audit.runtimeProfiles.some(item => item.profile === "openclaw" && item.qualification === "not_qualified_not_claimed_ga"), true);
  assert.equal(audit.runtimeProfiles.some(item => item.profile === "hermes" && item.qualification === "not_qualified_not_claimed_ga"), true);
});
