import { seedNativePasskeySession } from "./helpers/native-authentication-fixtures.js";
import { constants, createHash, generateKeyPairSync, privateDecrypt, randomBytes, randomUUID, sign } from "node:crypto";
import { readFileSync } from "node:fs";
import { createServer } from "node:http";
import { once } from "node:events";
import express from "express";
import request from "supertest";
import { WebSocket } from "ws";
import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it } from "vitest";
import { and, eq, sql } from "drizzle-orm";
import {
  activityLog,
  agents,
  agentPresenceRuntimeBindings,
  agentProviderBindings,
  authSessions,
  billingAccounts,
  billingAccountCompanies,
  billingSubscriptions,
  companyMemberships,
  connectionGrants,
  createDb,
  environmentLeases,
  runtimeCells,
  runtimeOperations,
  heartbeatRuns,
  issueRecoveryActions,
  assets,
  issues,
  runtimeCapacityProfiles,
  runtimeHostCommands,
  runtimeHosts,
  runtimePolicySnapshots,
  runtimeHostRequestNonces,
  runtimeSandboxBindings,
  runtimeVersionCatalog,
  toolApplications,
  toolCatalogEntries,
  toolConnections,
  toolProfileEntries,
  toolProfileBindings,
  toolProfiles,
} from "@paperclipai/db";
import { PROVIDER_CAPABILITY_FEATURES, SANDBOX_CONTROLS, SANDBOX_HOST_COMMAND, runtimeRequestSigningInput, sandboxCapabilitySnapshotSchema, sandboxHostReplySchema, type SandboxCapabilitySnapshot, type SandboxQualificationProbeFixture } from "@paperclipai/shared";
import {
  getEmbeddedPostgresTestSupport,
  startEmbeddedPostgresTestDatabase,
} from "./helpers/embedded-postgres.js";
import { seedV5Companies } from "./helpers/v5-fixtures.js";
import { policyFixture } from "./helpers/sandbox-fixture.js";
import { instanceSettingsService } from "../services/instance-settings.js";
import { executionSandboxService, sandboxCapabilityFacts } from "../services/execution-sandbox/sandbox-service.js";
import { executionSandboxRoutes } from "../routes/execution-sandbox.js";
import { heartbeatService } from "../services/heartbeat.js";
import { nativeSandboxHostTransport } from "../services/execution-sandbox/native-host-bridge.js";
import { open as unseal } from "../services/saas/crypto.js";
import type { SaasPlatformConfig } from "../saas-platform-config.js";
import { sandboxProbeCases, type SandboxIdentity } from "../services/execution-sandbox/backend.js";
import { openShellBackend } from "../services/execution-sandbox/openshell-backend.js";
import { projectOpenShellPolicy, projectOpenShellQualificationProbePolicy } from "../services/execution-sandbox/openshell-policy.js";
import { agentIdentityService } from "../services/agent-identities.js";
import { agentProviderBindingService } from "../services/agent-provider-bindings.js";
import { agentRuntimeFabricService } from "../services/agent-runtime-fabric.js";
import { discoverNativeCapabilities } from "../services/native-provider-conformance.js";
import { runtimeControlService } from "../services/runtime/control.js";
import { describeWorkspaceReconstruction, deliverReconciledExecutions, markExecutionReconciliation, validateExecutionReconciliation, verifyNativeWorkspaceDestructionReceipt } from "../services/execution-recovery-resolution.js";
import { errorHandler } from "../middleware/index.js";
import { nativeSha256 } from "../services/native-runtime/canonical.js";
import { environmentRuntimeService } from "../services/environment-runtime.js";
import { environmentService } from "../services/environments.js";
import { createSandboxBrokerJwt, createSandboxQualificationCredentialJwt, verifyLocalAgentJwt, verifySandboxBrokerJwt, verifySandboxExecJwt } from "../agent-auth-jwt.js";
import { createToolGatewayService } from "../services/tool-gateway.js";
import { registerAssignedMcpGateway } from "../services/native-runtime/assigned-mcp-tools.js";
import { mcpGatewayProtocolRoutes } from "../routes/tool-gateway.js";
const qualificationPolicyGolden = JSON.parse(readFileSync(new URL("./fixtures/openshell-qualification-policy-golden.json", import.meta.url), "utf8")) as { fixture: SandboxQualificationProbeFixture; document: unknown };

describe("sandbox qualification mechanism pins", () => {
  it("accepts a typed no-recreate prepare decision only without an active container claim", () => {
    const receipt = {
      action: "prepare" as const, backendVersion: "0.1.2" as const,
      imageDigest: `fixture.invalid/sandbox@sha256:${"b".repeat(64)}`,
      hostEpoch: 9, provisioningHash: "1".repeat(64), bindingVersion: 3,
      policyHash: "2".repeat(64), probePolicyHash: "3".repeat(64),
      resourceLimits: { cpuMillis: 500, memoryBytes: 268435456, diskBytes: 33554432, pidsLimit: 128 },
      requiresRecreate: true,
    };
    expect(sandboxHostReplySchema.parse(receipt)).toEqual(receipt);
    expect(() => sandboxHostReplySchema.parse({ ...receipt, sandboxId: randomUUID() })).toThrow();
  });
  const base = (): SandboxCapabilitySnapshot => {
    const fixtureBase = {
      version: 1 as const, fixtureId: "operator-canary-v1", profileId: "paperclip-qualification",
      profileHash: "5".repeat(64), binaries: ["/usr/bin/curl"] as ["/usr/bin/curl"], wrongBinaryPath: "/usr/bin/wget" as const,
      origin: "https://paperclip.example.test", port: 443, method: "POST" as const, gatewayPublicId: "gw-fixture",
      toolName: "read_canary", wrongToolName: "write_canary", argumentTemplateHash: nativeSha256({ caseId: "<caseId>", fixtureId: "<fixtureId>", nonce: "<nonce>" }), marker: "fixture-ok",
    };
    const credentialFixture = { ...fixtureBase, fixtureHash: nativeSha256(fixtureBase) };
    const { fixtureHash: _goldenFixtureHash, ...goldenFixtureBody } = qualificationPolicyGolden.fixture;
    const probeFixtureBody = { ...goldenFixtureBody, credential: credentialFixture };
    const probeFixture = { ...probeFixtureBody, fixtureHash: nativeSha256(probeFixtureBody) };
    const target = {
      hostEpoch: 9, companyId: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa", bindingId: "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb",
      bindingVersion: 2, cellId: "cccccccc-cccc-4ccc-8ccc-cccccccccccc", cellGeneration: "3",
      sandboxRef: "aw-v7-bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb", sandboxId: "dddddddd-dddd-4ddd-8ddd-dddddddddddd",
      containerId: "a".repeat(64), imageDigest: `fixture.invalid/sandbox@sha256:${"b".repeat(64)}`,
      hostKernelVersion: "fixture-kernel", runtimeBinarySha256: "c".repeat(64), openshellCliSha256: "d".repeat(64),
      dockerEngineIdHash: "e".repeat(64), policyHash: "f".repeat(64), provisioningHash: "1".repeat(64),
      resourceLimits: { cpuMillis: 500, memoryBytes: 268435456, diskBytes: 33554432, pidsLimit: 128 },
      policyVersion: 1, configRevision: "revision-1", phase: "Stopped" as const, mechanism: "openshell_create_sandbox_v0.1.2" as const,
      probePolicyHash: "2".repeat(64), probeFixtureHash: probeFixture.fixtureHash, qualificationCredentialFixture: credentialFixture,
    };
    return sandboxCapabilitySnapshotSchema.parse({
      ...Object.fromEntries(SANDBOX_CONTROLS.map(control => [control, true])), backend: "openshell", backendVersion: "0.1.2",
      hostKernelVersion: target.hostKernelVersion, sandboxImageDigest: target.imageDigest, filesystemEnforcementMode: "hard_requirement",
      staticPolicyRequiresRecreate: true, dynamicNetworkPolicy: true, policyProverBoundaryCheck: true,
      policyProverCoverage: [...SANDBOX_CONTROLS], credentialBindingDimensions: [], testedAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 60000).toISOString(), qualificationHash: nativeSha256(target), evidenceKind: "protected_host_report",
      qualificationTarget: { ...target, targetHash: nativeSha256(target) }, qualificationProbeFixture: probeFixture, qualificationCredentialFixture: credentialFixture,
    }) as SandboxCapabilitySnapshot;
  };
  it.each(["runtimeBinarySha256", "openshellCliSha256", "dockerEngineIdHash", "hostEpoch", "probeFixtureHash"])(
    "does not let an admission target borrow qualification after %s changes", field => {
      const qualified = base(), changed = structuredClone(qualified);
      const target = changed.qualificationTarget! as unknown as Record<string, unknown>;
      target[field] = typeof target[field] === "number" ? (target[field] as number) + 1 : "9".repeat(64);
      expect(nativeSha256(sandboxCapabilityFacts(changed))).not.toBe(nativeSha256(sandboxCapabilityFacts(qualified)));
    },
  );
  it("ignores active provisioning IDs and target policy hashes while preserving the qualification sample", () => {
    const qualified = base(), changed = structuredClone(qualified);
    Object.assign(changed.qualificationTarget!, { sandboxId: "eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee", containerId: "9".repeat(64),
      provisioningHash: "8".repeat(64), policyHash: "7".repeat(64), probePolicyHash: "6".repeat(64), phase: "Ready" });
    expect(nativeSha256(sandboxCapabilityFacts(changed))).toBe(nativeSha256(sandboxCapabilityFacts(qualified)));
  });
  it("keeps the exact operator fixture identity in the stable mechanism pin", () => {
    const qualified = base(), changed = structuredClone(qualified);
    changed.qualificationTarget!.qualificationCredentialFixture!.fixtureHash = "9".repeat(64);
    expect(nativeSha256(sandboxCapabilityFacts(changed))).not.toBe(nativeSha256(sandboxCapabilityFacts(qualified)));
  });
});
import { secretService } from "../services/secrets.js";
import { toolAccessService } from "../services/tool-access.js";
import { issueService } from "../services/issues.js";
import { lockAnalyticalCompany } from "../services/analytical-privacy.js";
import { lockMemoryPrivacy } from "../services/memory/memory-privacy.js";

const support = await getEmbeddedPostgresTestSupport();
const image = "fixture.invalid/openshell@sha256:" + "a".repeat(64);
function signedRuntimeRelayProof(hostId: string, privateKey: ReturnType<typeof generateKeyPairSync>["privateKey"]) {
  const fields = { hostId, epoch: 1, timestamp: String(Date.now()), nonce: randomBytes(32).toString("base64url") };
  const raw = Buffer.from(JSON.stringify({ hostId, epoch: 1 }));
  const message = runtimeRequestSigningInput("WS", "/api/internal/runtime/relay", createHash("sha256").update(raw).digest("hex"), fields);
  const signature = sign("sha256", Buffer.from(message), { key: privateKey, padding: constants.RSA_PKCS1_PSS_PADDING, saltLength: 32 }).toString("base64url");
  return { proof: { ...fields, signature }, nonce: fields.nonce };
}
(support.supported ? describe : describe.skip)(
  "native signed OpenShell command lane",
  () => {
    let database: Awaited<ReturnType<typeof startEmbeddedPostgresTestDatabase>>,
      db: ReturnType<typeof createDb>,
      f: Awaited<ReturnType<typeof seedV5Companies>>,
      host: typeof runtimeHosts.$inferSelect,
      cell: typeof runtimeCells.$inferSelect,
      scope: SandboxIdentity;
    let priorQualificationJwtSecret: string | undefined;
    let credentialFixtureForTest: SandboxCapabilitySnapshot["qualificationCredentialFixture"] = undefined;
    let qualificationProbeFixtureForTest: SandboxQualificationProbeFixture | undefined;
    let qualificationSecretValueForTest: string | null = null;
    const keys = generateKeyPairSync("rsa", { modulusLength: 3072 });
    beforeAll(async () => {
      database = await startEmbeddedPostgresTestDatabase("aw-v7-sandbox-host-");
      db = createDb(database.connectionString);
      await instanceSettingsService(db).getExperimental();
      await db.insert(runtimeVersionCatalog).values({
        imageDigest: image,
        providerVersion: "fixture",
        stateFormat: "v1",
        hostAgentMinimumVersion: "6.0.0",
        conformance: { fixtureOnly: true },
        status: "approved",
      });
      await db.insert(runtimeCapacityProfiles).values({
        // This database fixture represents the existing V6-qualified cell
        // profile/reservation owner required before physical qualification.
        key: "sandbox-host-fixture",
        cpuMillis: 1000,
        memoryBytes: 1073741824n,
        diskBytes: 10737418240n,
        pidsLimit: 128,
        qualified: true,
      });
    }, 60000);
    afterAll(async () => {
      await database?.cleanup();
    }, 30000);
    it("database admission gate accepts only the exact 19 qualified probe cases", async () => {
      const ids = [
        "filesystem_allow", "filesystem_deny", "filesystem_escape",
        "process_nonprivileged", "process_privilege_denied",
        "syscall_allow", "syscall_deny",
        "network_allow", "network_host_port_deny", "network_dns_redirect_deny",
        "network_l7_allow", "network_l7_deny",
        "credential_allow", "credential_raw_read_deny", "credential_wrong_destination_deny",
        "credential_wrong_binary_deny", "credential_revoke_deny",
        "resource_exhaustion_contained", "force_stop",
      ];
      const targetHash = "a".repeat(64);
      const valid = ids.map((caseId) => ({ caseId, verdict: "pass", observationHash: "b".repeat(64), targetQualificationHash: targetHash }));
      const check = async (results: unknown) => {
        const rows = await db.execute(sql`SELECT aw_v7_sandbox_qualification_probes_valid(${JSON.stringify(results)}::jsonb, ${targetHash}) AS valid`);
        return Boolean((rows as unknown as Array<{ valid: boolean }>)[0]?.valid);
      };
      expect(await check(valid)).toBe(true);
      expect(await check(valid.slice(0, -1))).toBe(false);
      expect(await check([...valid.slice(0, -1), { ...valid[18]!, caseId: valid[0]!.caseId }])).toBe(false);
      expect(await check([...valid.slice(0, -1), { ...valid[18]!, caseId: "unknown_case" }])).toBe(false);
      expect(await check([...valid.slice(0, -1), { ...valid[18]!, targetQualificationHash: "c".repeat(64) }])).toBe(false);
      expect(await check([...valid.slice(0, -1), { ...valid[18]!, verdict: "unsupported" }])).toBe(false);
      const missingVerdict = [...valid.slice(0, -1), { ...valid[18]! }];
      delete (missingVerdict[18] as { verdict?: string }).verdict;
      expect(await check(missingVerdict)).toBe(false);
      expect(await check([...valid.slice(0, -1), { ...valid[18]!, verdict: null }])).toBe(false);
      const missingTarget = [...valid.slice(0, -1), { ...valid[18]! }];
      delete (missingTarget[18] as { targetQualificationHash?: string }).targetQualificationHash;
      expect(await check(missingTarget)).toBe(false);
      expect(await check([...valid.slice(0, -1), { ...valid[18]!, targetQualificationHash: null }])).toBe(false);
    });

    beforeEach(async () => {
      priorQualificationJwtSecret = process.env.PAPERCLIP_AGENT_JWT_SECRET;
      process.env.PAPERCLIP_AGENT_JWT_SECRET = "v7-sandbox-qualification-fixture-secret";
      credentialFixtureForTest = undefined;
      qualificationProbeFixtureForTest = undefined;
      qualificationSecretValueForTest = null;
      await instanceSettingsService(db).updateExperimental({
        sandbox_abstraction_v7: true,
        openshell_v7: true,
        hosted_openclaw_v6: true,
        runtime_host_agent_v6: true,
        saas_deployment_profile_v6: true,
        billing_v6: true,
        billing_entitlements_v6: true,
        billing_usage_v6: true,
      });
      f = await seedV5Companies(db);
      f.actor.sessionId = await seedNativePasskeySession(db, f.userId);
      [host] = (await db
        .insert(runtimeHosts)
        .values({
          environment: "staging",
          region: "dk-cph1",
          capacityClass: "standard",
          cpuTotalMillis: 4000,
          memoryTotalBytes: 8000000000n,
          diskTotalBytes: 40000000000n,
          cpuReservedMillis: 1000,
          memoryReservedBytes: 1073741824n,
          diskReservedBytes: 10737418240n,
          publicKeyPem: keys.publicKey
            .export({ type: "spki", format: "pem" })
            .toString(),
          status: "READY",
          hostAgentVersion: "6.0.2",
          lastHeartbeatAt: new Date(),
        })
        .returning()) as [typeof host];
      const [account] = await db
        .insert(billingAccounts)
        .values({ displayName: "Fixture", payerUserId: f.userId })
        .returning();
      await db
        .insert(billingAccountCompanies)
        .values({ companyId: f.home, billingAccountId: account!.id });
      await db.insert(billingSubscriptions).values({
        billingAccountId: account!.id,
        providerSubscriptionId: `sandbox-host-fixture-${randomUUID()}`,
        status: "active",
        productKeys: ["platform", "runtime_standard"],
        currentPeriodEnd: new Date(Date.now() + 86_400_000),
        providerUpdatedAt: new Date(),
        sourceHash: "local-commercial-entitlement-fixture",
      });
      await db.insert(billingSubscriptions).values({
        billingAccountId: account!.id,
        providerSubscriptionId: `sandbox-host-capacity-fixture-${randomUUID()}`,
        status: "active",
        productKeys: ["runtime_standard"],
        currentPeriodEnd: new Date(Date.now() + 86_400_000),
        providerUpdatedAt: new Date(),
        sourceHash: "local-commercial-entitlement-fixture",
      });
      [cell] = (await db
        .insert(runtimeCells)
        .values({
          companyId: f.home,
          billingAccountId: account!.id,
          capacityProfile: "sandbox-host-fixture",
          desiredImageDigest: image,
          status: "STOPPED",
          isolationMode: "company_cell",
          runtimeHostId: host.id,
        })
        .returning()) as [typeof cell];
      transportForTest = nativeSandboxHostTransport(db, { operatorUserIds: [f.userId] });
      testWorkloadStates.clear();
      testWorkloadPolicies.clear();
      qualificationToolResponses.length = 0;
      const binding = await executionSandboxService(db, { operatorUserIds: [f.userId] }).create(
        f.actor,
        f.home,
        {
          runtimeCellId: cell.id,
          expectedCellGeneration: "1",
          backend: "openshell",
          profile: "development",
          boundaryPolicy: policyFixture(),
        },
      );
      scope = {
        companyId: f.home,
        bindingId: binding.id,
        cellId: cell.id,
        cellGeneration: "1",
        sandboxRef: `aw-v7-${binding.id}`,
      };
    });
    afterEach(() => {
      if (priorQualificationJwtSecret === undefined) delete process.env.PAPERCLIP_AGENT_JWT_SECRET;
      else process.env.PAPERCLIP_AGENT_JWT_SECRET = priorQualificationJwtSecret;
    });
    async function pending() {
      await expect
        .poll(
          async () =>
            (
              await db
                .select()
                .from(runtimeHostCommands)
                .where(
                  and(
                    eq(runtimeHostCommands.runtimeCellId, cell.id),
                    eq(runtimeHostCommands.commandType, SANDBOX_HOST_COMMAND),
                  ),
                )
            )[0]?.id,
        )
        .toBeTruthy();
      return (
        await db
          .select()
          .from(runtimeHostCommands)
          .where(eq(runtimeHostCommands.runtimeCellId, cell.id))
      )[0]!;
    }
    async function qualificationCredentialProbe(expiresInMs = 20_000) {
      const [binding] = await db.select().from(runtimeSandboxBindings).where(eq(runtimeSandboxBindings.id, scope.bindingId)).limit(1);
      const commandId = randomUUID(), nonce = randomBytes(16).toString("hex"), fixtureId = "operator-canary-v1";
      const base = sandboxProbeCases("1".repeat(64), SANDBOX_CONTROLS).find(test => test.caseId === "credential_allow")!;
      const argumentsValue = { fixtureId, caseId: base.caseId, nonce };
      const requestBody = { jsonrpc: "2.0", id: commandId, method: "tools/call", params: { name: "read_canary", arguments: argumentsValue } };
      const claim = {
        version: 1 as const, purpose: "qualification_credential_probe" as const, aud: "paperclip-sandbox-qualification" as const,
        jti: randomUUID(), commandId, caseId: "credential_allow" as const, fixtureId, fixtureHash: "a".repeat(64),
        hostEpoch: host.credentialVersion, scope: { companyId: scope.companyId, bindingId: scope.bindingId, cellId: scope.cellId,
          generation: scope.cellGeneration, sandboxRef: scope.sandboxRef }, bindingVersion: binding!.version,
        sandboxId: "33333333-3333-4333-8333-333333333333", containerId: "b".repeat(64),
        provisioningHash: "c".repeat(64), targetQualificationHash: "d".repeat(64),
        connectionId: "44444444-4444-4444-8444-444444444444", grantId: "55555555-5555-4555-8555-555555555555",
        secretVersionHash: "e".repeat(64), sourceBindingHash: "f".repeat(64), operatorUserId: f.userId,
        operatorSessionId: f.actor.sessionId!, profileId: "paperclip-qualification", profileHash: "1".repeat(64),
        binaries: ["/usr/bin/curl"], gatewayPublicId: "gw-fixture", toolName: "read_canary",
        argumentTemplateHash: nativeSha256({ caseId: "<caseId>", fixtureId: "<fixtureId>", nonce: "<nonce>" }),
        argumentsHash: nativeSha256(argumentsValue), requestBodyHash: nativeSha256(requestBody), nonce,
        origin: "https://paperclip.example.test", method: "POST" as const, path: "/mcp/gateways/gw-fixture",
        expiresAt: new Date(Date.now() + expiresInMs).toISOString(), maxUses: 1 as const,
      };
      const capabilityToken = createSandboxQualificationCredentialJwt({ companyId: scope.companyId,
        bindingId: scope.bindingId, operatorUserId: f.userId, claim });
      if (!capabilityToken) throw new Error("Could not create test-only qualification capability");
      return { commandId, nonce, capabilityToken, probe: { ...base, qualificationCredentialCapability: capabilityToken,
        qualificationCredentialNonce: nonce, qualificationCommandId: commandId } };
    }
    function supportedPolicy() {
      const policy = policyFixture();
      policy.filesystem.deniedPaths = [];
      policy.process.allowedBinaries = [];
      policy.process.allowedSyscalls = [];
      policy.network.destinations = [];
      policy.requiredControls = [...SANDBOX_CONTROLS];
      return policy;
    }
    function simulatedBackend(identity: SandboxIdentity, bridge: ReturnType<ReturnType<typeof nativeSandboxHostTransport>["bridge"]>) {
      let state: "stopped" | "ready" | "running" = "stopped";
      let policyHash: string | null = null;
      return {
        backend: "openshell" as const,
        evidenceKind: "protected_host_report" as const,
        capabilities: () => bridge.capabilities(identity),
        prepareSandbox: async (_input: SandboxIdentity, intent?: import("../services/execution-sandbox/backend.js").SandboxProvisioningIntent) => {
          if (!intent) return bridge.prepare(identity);
          let document;
          let policyHash: string;
          if (intent.purpose === "qualification") {
            const preflight = await bridge.capabilities(identity);
            const probeFixture = preflight?.qualificationProbeFixture;
            if (!preflight || !probeFixture || !qualificationProbeFixtureForTest ||
              nativeSha256(probeFixture) !== nativeSha256(qualificationProbeFixtureForTest) ||
              preflight.qualificationHash !== probeFixture.fixtureHash || preflight.policyProverBoundaryCheck ||
              preflight.policyProverCoverage.length > 0 || SANDBOX_CONTROLS.some(control => preflight[control]))
              throw new Error("Qualification setup has no exact capability-free protected probe fixture preflight");
            const projected = projectOpenShellQualificationProbePolicy(probeFixture);
            if (projected.unsupportedFeatures.length || !projected.document || !projected.documentHash)
              throw new Error("Qualification probe policy projection is unsupported");
            document = projected.document;
            policyHash = projected.documentHash;
          } else {
            document = projectOpenShellPolicy(intent.policy!.compiledPolicy, intent.policy!.modelBrokerEndpoint).document;
            policyHash = nativeSha256(intent.policy!);
          }
          const resources = intent.purpose === "qualification" ? policyFixture().resources : intent.policy!.compiledPolicy.resources;
          const request = { purpose: intent.purpose, operationKey: intent.operationKey, bindingVersion: intent.bindingVersion, expiresAt: intent.expiresAt,
            policyHash, document,
            resourceLimits: { cpuMillis: resources.cpuMillis, memoryBytes: resources.memoryBytes, diskBytes: resources.diskBytes, pidsLimit: resources.pidsLimit },
            ...(intent.purpose === "qualification" && qualificationProbeFixtureForTest ? {
              probeFixtureHash: qualificationProbeFixtureForTest.fixtureHash, qualificationProbeFixture: qualificationProbeFixtureForTest,
            } : {}) };
          const prepared = await bridge.prepare(identity, request);
          return { ...prepared, bindingVersion: intent.bindingVersion, policyHash,
            probePolicyHash: nativeSha256(document), resourceLimits: request.resourceLimits };
        },
        inspectWorkload: async () => ({ ...await bridge.inspect(identity), state, policyHash, controlsHealthy: true }),
        applyPolicy: async input => {
          const hash = nativeSha256(input.policy);
          const result = await bridge.apply({ ...identity, document: projectOpenShellPolicy(input.policy.compiledPolicy).document, policyHash: hash, expiresAt: input.expiresAt, idempotencyKey: input.idempotencyKey, resourceLimits: { cpuMillis: input.policy.compiledPolicy.resources.cpuMillis, memoryBytes: input.policy.compiledPolicy.resources.memoryBytes, diskBytes: input.policy.compiledPolicy.resources.diskBytes, pidsLimit: input.policy.compiledPolicy.resources.pidsLimit } });
          if (result.applied) { state = "ready"; policyHash = hash; }
          return { applied: result.applied, requiresRecreate: result.requiresRecreate, observedPolicyHash: result.policyHash, unsupportedFeatures: [] };
        },
        startWorkload: input => bridge.start({ ...identity, expiresAt: input.expiresAt, policyHash: nativeSha256(input.policy), idempotencyKey: input.idempotencyKey }).then(result => { state = "running"; return result; }),
        stopWorkload: async input => { await bridge.revokeProviders(identity); const result = await bridge.stop({ ...identity, idempotencyKey: input.idempotencyKey }); state = "stopped"; return result; },
        destroySandbox: input => bridge.destroy({ ...identity, idempotencyKey: input.idempotencyKey }),
        probeBoundary: input => bridge.probe({ ...identity, test: input.test }),
      };
    }
    async function driveHost<T>(work: Promise<T>, targetCellId: string,
      onCommand?: (command: Record<string, any>) => Promise<void> | void): Promise<T> {
      let settled = false;
      const result = work.then(value => ({ value }), error => ({ error })).then(value => { settled = true; return value; });
      const deadline = Date.now() + 15000;
      while (!settled && Date.now() < deadline) {
        const claim = await transportForTest.claim(host.id);
        if (!claim) { await new Promise(resolve => setTimeout(resolve, 2)); continue; }
        const secret = privateDecrypt({ key: keys.privateKey, padding: constants.RSA_PKCS1_OAEP_PADDING, oaepHash: "sha256", oaepLabel: Buffer.from("aw-runtime-command-v6") }, Buffer.from(claim.envelope.encryptedKey, "base64url"));
        const command = unseal<Record<string, any>>(claim.envelope.ciphertext, secret.toString("hex"), `command:${claim.id}:${host.id}:1`);
        const action = command.action as string;
        await onCommand?.(command);
        if (typeof command.probe?.qualificationCredentialCapability === "string") {
          const persisted = await db.select({ payload: runtimeHostCommands.payload }).from(runtimeHostCommands).where(eq(runtimeHostCommands.id, claim.id)).limit(1);
          const serialized = JSON.stringify(persisted[0]?.payload ?? null);
          expect(serialized).not.toContain(command.probe.qualificationCredentialCapability);
          expect(serialized).not.toContain(command.probe.qualificationCredentialNonce);
          expect(serialized).toContain("__sealedQualificationCredential");
          const envelope = (persisted[0]?.payload as Record<string, any>).__sealedQualificationCredential;
          expect(envelope).toMatchObject({ version: 1, commandId: claim.id });
          expect(envelope.tokenSha256).toMatch(/^[0-9a-f]{64}$/);
          expect(envelope.nonceSha256).toMatch(/^[0-9a-f]{64}$/);
          expect(envelope.sealed).toEqual(expect.any(String));
        }
        const common = { generation: command.scope.cellGeneration, imageDigest: command.imageDigest };
        const reply = action === "capabilities" ? { action, capabilities: testCapabilities(command.imageDigest, command.scope) }
          : action === "prepare" ? (() => {
              const provisioning = command.provisioning;
              const target = testQualificationTarget(command, provisioning);
              testTargets.set(command.scope.bindingId, target);
              if (provisioning?.purpose === "qualification") testQualificationSamples.set(command.scope.bindingId, target);
              testWorkloadStates.set(command.scope.cellId, provisioning?.purpose === "admission" ? "stopped" : "ready");
              return { action, backendVersion: "0.1.2", imageDigest: command.imageDigest, hostEpoch: command.hostEpoch,
                sandboxId: target.sandboxId, containerId: target.containerId, provisioningHash: target.provisioningHash,
                bindingVersion: provisioning.bindingVersion, policyHash: provisioning.policyHash,
                probePolicyHash: target.probePolicyHash, resourceLimits: provisioning.resourceLimits };
            })()
          : action === "probe" ? await (async () => {
              let verdict: "pass" | "fail" | "unsupported" = "pass";
              let observation: unknown = { caseId: command.probe.caseId, simulated: true };
              if (command.probe.qualificationCredentialCapability) {
                const fixture = testTargets.get(command.scope.bindingId)?.qualificationCredentialFixture;
                if (!qualificationProtocolApp || !fixture) throw new Error("Credential probe has no pinned local protocol fixture");
                const caseId = command.probe.caseId;
                const tool = caseId === "credential_wrong_destination_deny" ? fixture.wrongToolName : fixture.toolName;
                const call = request(qualificationProtocolApp).post(`/mcp/gateways/${fixture.gatewayPublicId}`);
                if (caseId !== "credential_wrong_binary_deny") call.set("Authorization", `Bearer ${command.probe.qualificationCredentialCapability}`);
                const response = await call.send({ jsonrpc: "2.0", id: claim.id, method: "tools/call", params: { name: tool,
                  arguments: { fixtureId: fixture.fixtureId, caseId, nonce: command.probe.qualificationCredentialNonce } } });
                const reasonCode = response.body?.error?.data?.reasonCode;
                const marker = response.body?.result?.structuredContent?.marker;
                const serializedResponse = JSON.stringify(response.body);
                expect(serializedResponse).not.toContain("qualification-provider-output-sentinel");
                if (qualificationSecretValueForTest) expect(serializedResponse).not.toContain(qualificationSecretValueForTest);
                expect(serializedResponse).not.toContain(command.probe.qualificationCredentialCapability);
                if (response.status === 200) {
                  expect(response.body.result.content).toEqual([{ type: "text", text: fixture.marker }]);
                  expect(response.body.result.structuredContent).toEqual({ marker: fixture.marker });
                }
                qualificationToolResponses.push({ caseId, status: response.status, reasonCode: reasonCode ?? null, marker: marker ?? null });
                if (caseId === "credential_allow") {
                  const replay = await request(qualificationProtocolApp).post(`/mcp/gateways/${fixture.gatewayPublicId}`)
                    .set("Authorization", `Bearer ${command.probe.qualificationCredentialCapability}`)
                    .send({ jsonrpc: "2.0", id: claim.id, method: "tools/call", params: { name: tool,
                      arguments: { fixtureId: fixture.fixtureId, caseId, nonce: command.probe.qualificationCredentialNonce } } });
                  expect(replay.status).toBe(409);
                  expect(JSON.stringify(replay.body)).toContain("sandbox_qualification_capability_replayed");
                }
                const passed = caseId === "credential_allow" || caseId === "credential_raw_read_deny"
                  ? response.status === 200 && marker === fixture.marker
                  : caseId === "credential_wrong_destination_deny"
                    ? response.status === 403 && reasonCode === "sandbox_qualification_tool_mismatch"
                    : caseId === "credential_wrong_binary_deny"
                      ? response.status === 401 && reasonCode === "sandbox_qualification_credential_required"
                      : response.status === 403 && reasonCode === "sandbox_qualification_grant_revoked";
                verdict = passed ? "pass" : "fail";
                observation = { caseId, status: response.status, reasonCode: reasonCode ?? null, marker: marker ?? null };
              }
              return { action, verdict, observationHash: nativeSha256(observation), contractHash: command.probe.contractHash,
                targetQualificationHash: testTargets.get(command.scope.bindingId)?.targetHash };
            })()
          : action === "inspect" ? { action, ...common, state: testWorkloadStates.get(command.scope.cellId) ?? "stopped", policyHash: testWorkloadPolicies.get(command.scope.cellId) ?? null, controlsHealthy: true }
          : action === "apply" ? (testWorkloadStates.set(command.scope.cellId, "ready"), testWorkloadPolicies.set(command.scope.cellId, command.admission.policyHash), { action, applied: true, requiresRecreate: false, policyHash: command.admission.policyHash, effectivePolicyHash: command.admission.policyHash })
          : action === "start" ? (testWorkloadStates.set(command.scope.cellId, "running"), testWorkloadPolicies.set(command.scope.cellId, command.start.policyHash), { action, started: true, operationId: claim.id, sandboxId: command.scope.bindingId, containerId: "b".repeat(64), imageDigest: command.imageDigest, policyHash: command.start.policyHash, effectivePolicyHash: command.start.policyHash })
          : action === "stop" ? (testWorkloadStates.set(command.scope.cellId, "stopped"), { action, stopped: true })
          : action === "revoke_providers" ? { action, revoked: true }
          : action === "destroy" ? { action, destroyed: true }
          : { action, document: projectOpenShellPolicy(supportedPolicy()).document };
        await transportForTest.complete(host.id, claim.id, { claimToken: command.claimToken, generation: command.scope.cellGeneration, success: true, reply, errorCode: null });
      }
      if (!settled) {
        const pendingRows = await db.select().from(runtimeHostCommands).where(eq(runtimeHostCommands.runtimeCellId, targetCellId));
        throw new Error(`test host did not drain commands for cell ${targetCellId}: ${JSON.stringify(pendingRows.map(row => ({ status: row.status, errorCode: row.errorCode, action: (row.payload as Record<string, unknown>).action })))}`);
      }
      const output = await result;
      if ("error" in output) throw output.error;
      return output.value;
    }
    let qualificationProtocolApp: any = null;
    const qualificationToolResponses: Array<{ caseId: string; status: number; reasonCode: string | null; marker: string | null }> = [];
    const testWorkloadStates = new Map<string, "stopped" | "ready" | "running">();
    const testWorkloadPolicies = new Map<string, string>();
    const testCapabilitySnapshots = new Map<string, Record<string, unknown>>();
    const testTargets = new Map<string, Record<string, any>>();
    const testQualificationSamples = new Map<string, Record<string, any>>();
    const testQualificationTarget = (command: Record<string, any>, provisioning: Record<string, any>) => {
      const sandboxId = "f3a4f0a0-cd95-4fd2-8f4c-2b5223309a17";
      const containerId = "b".repeat(64);
      const target = {
        hostEpoch: command.hostEpoch, companyId: command.scope.companyId, bindingId: command.scope.bindingId,
        bindingVersion: provisioning.bindingVersion,
        cellId: command.scope.cellId, cellGeneration: command.scope.cellGeneration, sandboxRef: command.scope.sandboxRef,
        sandboxId, containerId, imageDigest: command.imageDigest, hostKernelVersion: "fixture-kernel", runtimeBinarySha256: "a".repeat(64),
        openshellCliSha256: "b".repeat(64), dockerEngineIdHash: "d".repeat(64),
        policyHash: provisioning.policyHash, provisioningHash: provisioning.provisioningHash,
        resourceLimits: provisioning.resourceLimits, policyVersion: 1, configRevision: "fixture-config-1",
        phase: provisioning.purpose === "admission" ? "Stopped" : "Ready",
        mechanism: "openshell_create_sandbox_v0.1.2", probePolicyHash: nativeSha256(provisioning.document),
        probeFixtureHash: provisioning.probeFixtureHash ?? testQualificationSamples.get(command.scope.bindingId)?.probeFixtureHash,
        ...((provisioning.qualificationProbeFixture?.credential ?? testQualificationSamples.get(command.scope.bindingId)?.qualificationCredentialFixture)
          ? { qualificationCredentialFixture: provisioning.qualificationProbeFixture?.credential ?? testQualificationSamples.get(command.scope.bindingId)?.qualificationCredentialFixture } : {}),
      };
      return { ...target, targetHash: nativeSha256(target) };
    };
    const testCapabilities = (digest: string, scope?: SandboxIdentity) => {
      const target = scope ? testTargets.get(scope.bindingId) : undefined;
      const cacheKey = scope ? `${scope.bindingId}:${digest}` : digest;
      let snapshot = testCapabilitySnapshots.get(cacheKey);
      if (!snapshot) {
        const preflight = Boolean(scope && !target);
        const probeFixture = preflight ? qualificationProbeFixtureForTest : undefined;
        snapshot = { ...Object.fromEntries(SANDBOX_CONTROLS.map(control => [control, !preflight])), backend: "openshell", backendVersion: "0.1.2", hostKernelVersion: "fixture-kernel", sandboxImageDigest: digest, filesystemEnforcementMode: "hard_requirement", staticPolicyRequiresRecreate: true, dynamicNetworkPolicy: !preflight, policyProverBoundaryCheck: !preflight, policyProverCoverage: preflight ? [] : [...SANDBOX_CONTROLS], credentialBindingDimensions: preflight ? [] : ["company", "presence", "host", "port", "method", "path", "binary", "expiry", "revocation"], credentialBrokerProviderProfile: { id: "paperclip-broker", hash: "d".repeat(64) }, testedAt: new Date(Date.now() - 1000).toISOString(), expiresAt: new Date(Date.now() + 86400000).toISOString(), qualificationHash: probeFixture?.fixtureHash ?? "a".repeat(64), evidenceKind: "protected_host_report",
          ...(probeFixture ? { qualificationProbeFixture: probeFixture, qualificationCredentialFixture: probeFixture.credential } : {}) };
        testCapabilitySnapshots.set(cacheKey, snapshot);
      }
      if (target) {
        for (const control of SANDBOX_CONTROLS) snapshot[control] = true;
        snapshot.dynamicNetworkPolicy = true; snapshot.policyProverBoundaryCheck = true;
        snapshot.policyProverCoverage = [...SANDBOX_CONTROLS];
        snapshot.credentialBindingDimensions = ["company", "presence", "host", "port", "method", "path", "binary", "expiry", "revocation"];
        snapshot.qualificationTarget = target;
        snapshot.qualificationProbeFixture = qualificationProbeFixtureForTest;
        snapshot.qualificationCredentialFixture = target.qualificationCredentialFixture ?? testQualificationSamples.get(scope!.bindingId)?.qualificationCredentialFixture;
        snapshot.qualificationHash = target.targetHash;
      }
      return snapshot;
    };
    let transportForTest: ReturnType<typeof nativeSandboxHostTransport>;
    function decrypt(
      claim: NonNullable<
        Awaited<
          ReturnType<ReturnType<typeof nativeSandboxHostTransport>["claim"]>
        >
      >,
    ) {
      const key = privateDecrypt(
        {
          key: keys.privateKey,
          padding: constants.RSA_PKCS1_OAEP_PADDING,
          oaepHash: "sha256",
          oaepLabel: Buffer.from("aw-runtime-command-v6"),
        },
        Buffer.from(claim.envelope.encryptedKey, "base64url"),
      );
      return unseal<{ claimToken: string }>(
        claim.envelope.ciphertext,
        key.toString("hex"),
        `command:${claim.id}:${host.id}:1`,
      );
    }
    it("observes fixed platform qualification HTTP credentials and all nineteen probes with revocation and replay checks", async () => {
      await instanceSettingsService(db).updateExperimental({
        agent_identities_v5: true,
        agent_provider_bindings_v5: true,
        agent_runtime_fabric_v5: true,
        enableFoundationV1: true,
        enableContextEngineV1: true,
      });
      const created = await agentIdentityService(db).create(f.actor, { name: "Sandbox admission Task fixture", homeCompanyId: f.home });
      const presence = created.presence;
      const [runtimePresence] = await db.select({ id: agentPresenceRuntimeBindings.id }).from(agentPresenceRuntimeBindings).where(and(
        eq(agentPresenceRuntimeBindings.companyId, f.home), eq(agentPresenceRuntimeBindings.agentId, presence.id), eq(agentPresenceRuntimeBindings.status, "active"),
      )).limit(1);
      expect(runtimePresence).toBeTruthy();
      const providerService = agentProviderBindingService(db);
      const provider = await providerService.create(f.actor, f.home, presence.id, { providerType: "paperclip_native", providerAgentRef: presence.id, providerEndpointRef: null, isolationMode: "isolated_per_presence" });
      const newCellId = randomUUID();
      const [admissionCell] = await db.insert(runtimeCells).values({
        id: newCellId, companyId: f.home, billingAccountId: cell.billingAccountId,
        runtimeHostId: host.id, providerBindingId: provider.id,
        capacityProfile: "sandbox-host-fixture", desiredImageDigest: image,
        status: "STOPPED", isolationMode: "company_cell",
      }).returning();
      await providerService.attach(f.actor, f.home, presence.id, { providerBindingId: provider.id, providerProfileRef: `aw:cell:${admissionCell!.id}:generation:${admissionCell!.generation}` });
      const features = Object.fromEntries(PROVIDER_CAPABILITY_FEATURES.map(key => [key, false])) as Record<(typeof PROVIDER_CAPABILITY_FEATURES)[number], boolean>;
      await providerService.recordDiscovery(f.home, presence.id, { provider: "paperclip_native", version: "ci-software-fixture", features, skills: [], tools: [], discoveredAt: new Date().toISOString() }, { connect: true, identity: true, start: true, stream: true, wait: true, cancel: true, memoryScoping: true });
      const [task] = await db.insert(issues).values({ companyId: f.home, title: "Run through the qualified sandbox", status: "in_progress", assigneeAgentId: presence.id, responsibleUserId: f.userId }).returning();
      // Saved comment-bound uploads predate the execution. A new comment after
      // the failed run would correctly supersede conversation continuation.
      const savedBytes = Buffer.from("saved reconstruction source\n");
      const savedHash = createHash("sha256").update(savedBytes).digest("hex");
      const savedComment = await issueService(db).addComment(task!.id,
        "Saved source context for recovery.", { userId: f.userId }, { manualInputActor: { ...f.actor } });
      const savedAttachment = await issueService(db).createAttachment({
        issueId: task!.id, issueCommentId: savedComment.id, provider: "local_fixture", objectKey: `recovery/${randomUUID()}`,
        contentType: "text/plain", byteSize: savedBytes.byteLength, sha256: savedHash,
        originalFilename: "saved-source.txt", createdByUserId: f.userId,
      }, { actor: { ...f.actor }, bytes: savedBytes });
      const withdrawnAttachment = await issueService(db).createAttachment({
        issueId: task!.id, issueCommentId: savedComment.id, provider: "local_fixture", objectKey: `recovery/${randomUUID()}`,
        contentType: "text/plain", byteSize: savedBytes.byteLength, sha256: savedHash,
        originalFilename: "withdrawn-source.txt", createdByUserId: f.userId,
      }, { actor: { ...f.actor }, bytes: savedBytes });
      const verifyFixtureSavedBytes = async (source: { objectKey: string; sha256: string; byteSize: number }) => {
        if (source.objectKey === savedAttachment!.objectKey) expect(source).toMatchObject({ sha256: savedHash, byteSize: savedBytes.byteLength });
      };
      const [run] = await db.insert(heartbeatRuns).values({ companyId: f.home, agentId: presence.id, status: "running", startedAt: new Date(), runtimeMode: "native", runtimeModeResolvedAt: new Date(), nativeIssueId: task!.id, responsibleUserId: f.userId, contextSnapshot: { issueId: task!.id } }).returning();
      await db.update(issues).set({ executionRunId: run!.id }).where(eq(issues.id, task!.id));
      const manifest = await agentRuntimeFabricService(db).prepare({ companyId: f.home, agentId: presence.id, runId: run!.id, responsibleUserId: f.userId, issueId: task!.id, query: task!.title });
      expect(manifest).toBeTruthy();
      const providerSecretValue = `provider-secret-${randomUUID()}`;
      const providerSecret = await secretService(db).create(f.home, {
        name: `Brokered provider secret ${randomUUID()}`,
        key: `brokered_provider_secret_${randomUUID().replace(/-/g, "")}`,
        provider: "local_encrypted", value: providerSecretValue,
      });
      const applicationKey = `brokered-${randomUUID().replace(/-/g, "")}`;
      const [application] = await db.insert(toolApplications).values({ companyId: f.home, applicationKey, name: "Brokered provider fixture", type: "mcp_http", status: "active" }).returning();
      const [connection] = await db.insert(toolConnections).values({
        companyId: f.home, applicationId: application!.id, name: "Brokered provider fixture", uid: `fixture/${randomUUID()}`,
        transport: "mcp_remote", status: "active", enabled: true, healthStatus: "ok",
        config: { url: "https://provider.example.test/mcp" }, transportConfig: { url: "https://provider.example.test/mcp" },
        credentialRefs: [{ name: "credentials.authorization", secretId: providerSecret.id, version: "latest", placement: "header", key: "Authorization", prefix: "Bearer " }],
        credentialSecretRefs: [{ secretId: providerSecret.id, versionSelector: "latest", configPath: "credentials.authorization", required: true, label: "Brokered provider token" }],
      }).returning();
      await secretService(db).createBinding({ companyId: f.home, secretId: providerSecret.id, targetType: "tool_connection", targetId: connection!.id, configPath: "credentials.authorization", versionSelector: "latest", required: true, label: "Brokered provider token" });
      const [brokerGrant] = await db.insert(connectionGrants).values({ companyId: f.home, connectionId: connection!.id, kind: "organization", credentialSecretRefs: connection!.credentialSecretRefs, status: "active", isDefault: true }).returning();
      qualificationSecretValueForTest = `qualification-secret-${randomUUID()}`;
      const qualificationSecret = await secretService(db).create(f.home, {
        name: `Operator qualification canary secret ${randomUUID()}`,
        key: `qualification_canary_secret_${randomUUID().replace(/-/g, "")}`,
        provider: "local_encrypted", value: qualificationSecretValueForTest,
      });
      const qualificationApplicationKey = `qualification-canary-${randomUUID().replace(/-/g, "")}`;
      const [qualificationApplication] = await db.insert(toolApplications).values({ companyId: f.home,
        applicationKey: qualificationApplicationKey, name: "Operator qualification canary", type: "mcp_http", status: "active" }).returning();
      const qualificationCredentialRefs = [{ name: "credentials.authorization", secretId: qualificationSecret.id,
        version: "latest", placement: "header", key: "Authorization", prefix: "Bearer " }];
      const qualificationSecretRefs = [{ secretId: qualificationSecret.id, versionSelector: "latest",
        configPath: "credentials.authorization", required: true, label: "Qualification-only canary credential" }];
      // This owner seam supplies a public DNS answer without performing live
      // DNS. All provider HTTP stays on the local `remoteHttpRequest` stub.
      const qualificationToolAccess = toolAccessService(db, {
        remoteHttpEndpointLookup: async () => [{ address: "8.8.8.8", family: 4 }],
        remoteHttpRequest: async (url, init) => {
          expect(url).toBe("https://paperclip.example.test/mcp/qualification/credential-echo");
          const request = JSON.parse(String(init.body)) as { id: string; method: string };
          expect(request.method).toBe("tools/list");
          return new Response(JSON.stringify({ jsonrpc: "2.0", id: request.id, result: { tools: [{
            name: "read_canary", description: "Fixed local qualification marker",
            inputSchema: { type: "object", properties: { fixtureId: { type: "string" }, caseId: { type: "string" }, nonce: { type: "string" } },
              required: ["fixtureId", "caseId", "nonce"], additionalProperties: false },
            annotations: { readOnlyHint: true },
          }] } }), { status: 200, headers: { "content-type": "application/json" } });
        },
      });
      const qualificationConnection = await qualificationToolAccess.createConnection(f.home, {
        applicationId: qualificationApplication!.id, name: "Operator qualification canary", transport: "mcp_remote",
        status: "active", enabled: true, config: { url: "https://paperclip.example.test/mcp/qualification/credential-echo" }, transportConfig: { url: "https://paperclip.example.test/mcp/qualification/credential-echo" },
        credentialRefs: qualificationCredentialRefs, credentialSecretRefs: qualificationSecretRefs,
      }, { actorType: "user", actorId: f.userId });
      let qualificationGrant: typeof connectionGrants.$inferSelect | undefined;
      const expectedQualificationToolName = `mcp.${qualificationApplicationKey.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "")}-${qualificationConnection.id.replace(/-/g, "").slice(0, 8)}:read-canary`;
      await db.insert(toolCatalogEntries).values({ companyId: f.home, applicationId: qualificationApplication!.id,
        connectionId: qualificationConnection.id, entryKind: "tool", name: `read_canary-${randomUUID()}`, toolName: "read_canary",
        title: "Read operator qualification canary", description: "Returns one fixed, non-sensitive qualification marker",
        inputSchema: { type: "object", properties: { fixtureId: { type: "string" }, caseId: { type: "string" }, nonce: { type: "string" } },
          required: ["fixtureId", "caseId", "nonce"], additionalProperties: false },
        annotations: { readOnlyHint: true }, riskLevel: "read", isReadOnly: true, isWrite: false, isDestructive: false,
        status: "active", versionHash: randomUUID(), quarantinedAt: null,
      });
      await db.insert(toolCatalogEntries).values({
        companyId: f.home, applicationId: application!.id, connectionId: connection!.id, entryKind: "tool",
        name: `read_record-${randomUUID()}`, toolName: "read_record", title: "Read record", description: "Read a fixture record",
        inputSchema: { type: "object", properties: { id: { type: "string" } }, required: ["id"], additionalProperties: false },
        annotations: { readOnlyHint: true }, riskLevel: "read", isReadOnly: true, isWrite: false, isDestructive: false,
        status: "active", versionHash: randomUUID(), quarantinedAt: null,
      });
      // Use the canonical health owner with a deterministic local protocol stub so
      // the active shared-grant fixture is catalog-visible without live network.
      const qualificationHealth = await qualificationToolAccess.checkHealth(qualificationConnection.id, { actorType: "user", actorId: f.userId });
      expect(qualificationHealth.connection.healthStatus).toBe("ok");
      [qualificationGrant] = await db.select().from(connectionGrants).where(and(
        eq(connectionGrants.companyId, f.home), eq(connectionGrants.connectionId, qualificationConnection.id),
        eq(connectionGrants.status, "active"), eq(connectionGrants.isDefault, true),
      )).limit(1);
      expect(qualificationGrant).toMatchObject({ kind: "organization", status: "active", isDefault: true });
      const [agentToolProfile] = await db.insert(toolProfiles).values({ companyId: f.home, profileKey: `broker-agent-${randomUUID()}`, name: "Brokered agent tool profile", defaultAction: "deny" }).returning();
      await db.insert(toolProfileBindings).values({ companyId: f.home, profileId: agentToolProfile!.id, targetType: "agent", targetId: presence.id });
      const expectedBrokerToolName = `mcp.${applicationKey.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "")}-${connection!.id.replace(/-/g, "").slice(0, 8)}:read-record`;
      await db.insert(toolProfileEntries).values({ companyId: f.home, profileId: agentToolProfile!.id, selectorType: "tool_name", effect: "include", toolName: expectedBrokerToolName });
      const [gatewayProfile] = await db.insert(toolProfiles).values({ companyId: f.home, profileKey: `broker-gateway-${randomUUID()}`, name: "Brokered gateway profile", defaultAction: "deny" }).returning();
      await db.insert(toolProfileEntries).values({ companyId: f.home, profileId: gatewayProfile!.id, selectorType: "connection", effect: "include", connectionId: connection!.id });
      await db.insert(toolProfileEntries).values({ companyId: f.home, profileId: gatewayProfile!.id, selectorType: "connection", effect: "include", connectionId: qualificationConnection.id });
      const dispatchedBrokerCalls: Array<{ url: string; body: string | null; authorization: string | null }> = [];
      let qualificationProviderMarkerOverride: string | null = null;
      let nextProviderBarrier: { started: () => void; wait: Promise<void> } | null = null;
      const deferNextProviderResponse = () => {
        let markStarted!: () => void, release!: () => void;
        const started = new Promise<void>(resolve => { markStarted = resolve; });
        const wait = new Promise<void>(resolve => { release = resolve; });
        nextProviderBarrier = { started: markStarted, wait };
        return { started, release };
      };
      let concurrentEchoChecked = false;
      const gatewayOptions: Parameters<typeof createToolGatewayService>[1] = {
        operatorUserIds: [f.userId],
        qualificationBrokerOrigin: "https://paperclip.example.test",
        toolActionSigningSecret: "v7-sandbox-broker-fixture",
        remoteHttpRequest: async (url, init) => {
          const body = typeof init.body === "string" ? init.body : null;
          const authorization = new Headers(init.headers).get("authorization");
          dispatchedBrokerCalls.push({ url, body, authorization });
          const barrier = nextProviderBarrier;
          if (barrier) { nextProviderBarrier = null; barrier.started(); await barrier.wait; }
          expect(url).toBe("https://paperclip.example.test/mcp/qualification/credential-echo");
          expect(init.method).toBe("POST"); expect(init.redirect).toBe("manual");
          expect(authorization).toBe(`Bearer ${qualificationSecretValueForTest}`);
          const send = (wrongAuthorization = false) => {
            const http = request(qualificationProtocolApp).post(new URL(url).pathname);
            new Headers(init.headers).forEach((value, key) => http.set(key, value));
            if (wrongAuthorization) http.set("authorization", "Bearer wrong-canary-value");
            return http.send(JSON.parse(String(init.body)));
          };
          if (!concurrentEchoChecked) expect((await send(true)).status).toBe(403);
          const responses = await (concurrentEchoChecked ? Promise.all([send()]) : Promise.all([send(), send()]));
          if (!concurrentEchoChecked) {
            expect(responses.map(response=>response.status).sort()).toEqual([200,409]);
            concurrentEchoChecked = true;
          }
          const response = responses.find(response => response.status === 200) ?? responses[0]!;
          let returned = response.body;
          if (qualificationProviderMarkerOverride && response.status === 200)
            returned = { ...returned, result: { ...returned.result, structuredContent: { marker: qualificationProviderMarkerOverride } } };
          expect(JSON.stringify(returned)).not.toContain(qualificationSecretValueForTest);
          return Response.json(returned, {status:response.status});
        },
      };
      const gateway = createToolGatewayService(db, gatewayOptions);
      registerAssignedMcpGateway(db, gateway, scopedDb => createToolGatewayService(scopedDb, gatewayOptions));
      const namedGateway = await gateway.createNamedGateway({ companyId: f.home, body: { name: "Native task broker fixture", profileId: gatewayProfile!.id } });
      const argumentTemplateHash = nativeSha256({ caseId: "<caseId>", fixtureId: "<fixtureId>", nonce: "<nonce>" });
      const credentialFixtureBase = {
        version: 1 as const, fixtureId: "operator-canary-v1", profileId: "paperclip-qualification", profileHash: "5".repeat(64),
        binaries: ["/usr/bin/curl"] as ["/usr/bin/curl"], wrongBinaryPath: "/usr/bin/wget" as const,
        origin: "https://paperclip.example.test", port: 443, method: "POST" as const,
        gatewayPublicId: namedGateway.gatewayPublicId, toolName: expectedQualificationToolName, wrongToolName: "wrong_scope_canary",
        argumentTemplateHash, marker: "paperclip-qualification-credential-ok-v1",
      };
      credentialFixtureForTest = { ...credentialFixtureBase, fixtureHash: nativeSha256(credentialFixtureBase) };
      const { fixtureHash: _goldenHash, ...goldenFixtureBody } = qualificationPolicyGolden.fixture;
      const probeFixtureBody = { ...goldenFixtureBody, credential: credentialFixtureForTest };
      qualificationProbeFixtureForTest = { ...probeFixtureBody, fixtureHash: nativeSha256(probeFixtureBody) };
      const qualificationCanary = {
        argumentTemplateHash, endpointOrigin: "https://paperclip.example.test", endpointPath: "/mcp/qualification/credential-echo",
        fixtureHash: credentialFixtureForTest.fixtureHash, fixtureId: credentialFixtureForTest.fixtureId,
        gatewayPublicId: namedGateway.gatewayPublicId, grantId: qualificationGrant!.id,
        kind: "platform_owned_qualification_echo", marker: credentialFixtureForTest.marker,
        noSideEffects: true, purpose: "sandbox_qualification", readOnly: true, setupOnly: true,
        toolName: expectedQualificationToolName, version: 1, wrongToolName: "wrong_scope_canary",
      };
      await qualificationToolAccess.updateConnection(qualificationConnection.id, {
        config: { ...(qualificationConnection.config as Record<string, unknown>), sandboxQualificationCanary: qualificationCanary },
      });
      qualificationProtocolApp = express();
      qualificationProtocolApp.use(express.json());
      qualificationProtocolApp.use(mcpGatewayProtocolRoutes(gateway));
      const fixedMetadata = await request(qualificationProtocolApp).post("/mcp/qualification/credential-echo")
        .send({jsonrpc:"2.0",id:"catalogue-health",method:"tools/list"});
      expect(fixedMetadata.status).toBe(200);
      expect(fixedMetadata.body.result.tools.map((tool: {name:string})=>tool.name)).toEqual(["read_canary"]);
      const noCapability = await request(qualificationProtocolApp).post("/mcp/qualification/credential-echo")
        .set("authorization",`Bearer ${qualificationSecretValueForTest}`)
        .send({jsonrpc:"2.0",id:randomUUID(),method:"tools/call",params:{name:expectedQualificationToolName,arguments:{fixtureId:"unknown",caseId:"credential_allow",nonce:"unknown"}}});
      expect(noCapability.status).toBe(401);
      expect(noCapability.body.reasonCode).toBe("sandbox_qualification_credential_required");
      const initialBrokerBinding = {
        connectionId: connection!.id, grantVersionHash: "0".repeat(64), hostname: "provider.example.test", port: 443,
        methods: ["POST"] as const, pathPrefixes: ["/mcp"], binary: null, ttlSeconds: 120,
      };
      const initialBrokerResolution = await gateway.resolveSandboxCredentialBrokerPolicyBindings({
        companyId: f.home, agentId: presence.id, runId: run!.id, responsibleUserId: f.userId,
        presenceId: runtimePresence!.id, bindings: [initialBrokerBinding],
      });
      expect(initialBrokerResolution.bindings[0]?.allowedTools).toContain(expectedBrokerToolName);
      const boundary = supportedPolicy();
      boundary.riskClass = "C3";
      boundary.credentials = { mode: "brokered", bindings: [{ ...initialBrokerBinding, grantVersionHash: initialBrokerResolution.authorizedConnectionGrantHashes[connection!.id]! }] };
      const sandboxBinding = await executionSandboxService(db, { operatorUserIds: [f.userId] }).create(f.actor, f.home, { runtimeCellId: admissionCell!.id, expectedCellGeneration: admissionCell!.generation.toString(), backend: "openshell", profile: "development", boundaryPolicy: boundary });
      const sandboxIdentity: SandboxIdentity = { companyId: f.home, bindingId: sandboxBinding.id, cellId: admissionCell!.id, cellGeneration: admissionCell!.generation.toString(), sandboxRef: `aw-v7-${sandboxBinding.id}` };
      expect(sandboxCapabilitySnapshotSchema.safeParse({ ...testCapabilities(image), evidenceKind: "local_fixture", qualificationTarget: undefined, qualificationProbeFixture: undefined, qualificationCredentialFixture: undefined }).success).toBe(true);
      const serviceOptions = {
        operatorUserIds: [f.userId],
        credentialBrokerOrigin: "https://paperclip.example.test/",
        backendFor: (binding: any, actor: any) => simulatedBackend(sandboxIdentity, transportForTest.bridge(actor)),
      };
      const qualification = await driveHost(executionSandboxService(db, serviceOptions).qualify(f.actor, f.home, sandboxBinding.id, 1), admissionCell!.id);
      if (qualification.status !== "ready") {
        const retained = await executionSandboxService(db, serviceOptions).get(f.actor, f.home, sandboxBinding.id);
        const probeReceipts = await db.select().from(runtimeHostCommands).where(eq(runtimeHostCommands.runtimeCellId, admissionCell!.id));
        throw new Error(`CI-only qualification did not pass: ${JSON.stringify({ report: retained.qualifications[0], probes: probeReceipts.filter(row => (row.payload as Record<string, any>).action === "probe").map(row => ({ test: (row.payload as any).probe, status: row.status, errorCode: row.errorCode, safeResult: row.safeResult })) })}`);
      }
      expect(qualification).toMatchObject({ status: "ready", version: 2 });
      expect(concurrentEchoChecked).toBe(true);
      const [revokedQualificationGrant] = await db.select({ status: connectionGrants.status }).from(connectionGrants)
        .where(eq(connectionGrants.id, qualificationGrant!.id)).limit(1);
      const [activeRuntimeGrant] = await db.select({ status: connectionGrants.status }).from(connectionGrants)
        .where(eq(connectionGrants.id, brokerGrant!.id)).limit(1);
      expect(revokedQualificationGrant?.status).toBe("revoked");
      expect(activeRuntimeGrant?.status).toBe("active");
      expect(qualificationToolResponses).toEqual(expect.arrayContaining([
        { caseId: "credential_allow", status: 200, reasonCode: null, marker: credentialFixtureForTest!.marker },
        { caseId: "credential_raw_read_deny", status: 200, reasonCode: null, marker: credentialFixtureForTest!.marker },
        { caseId: "credential_wrong_destination_deny", status: 403, reasonCode: "sandbox_qualification_tool_mismatch", marker: null },
        { caseId: "credential_wrong_binary_deny", status: 401, reasonCode: "sandbox_qualification_credential_required", marker: null },
        { caseId: "credential_revoke_deny", status: 403, reasonCode: "sandbox_qualification_grant_revoked", marker: null },
      ]));

      // Recreate only the setup-only canary grant, then revoke it while a
      // read-only request is in flight. The task's actual boundary grant is
      // separate and must remain active throughout this race.
      const qualificationActor = { actorType: "user" as const, actorId: f.userId };
      const reactivatedCanaryGrant = await qualificationToolAccess.addConnectionInstallation(qualificationConnection.id, {
        credentialSecretRefs: qualificationSecretRefs, isDefault: true,
      }, qualificationActor);
      const [currentCanaryConnection] = await db.select().from(toolConnections).where(eq(toolConnections.id, qualificationConnection.id)).limit(1);
      await qualificationToolAccess.updateConnection(qualificationConnection.id, {
        config: { ...(currentCanaryConnection!.config as Record<string, unknown>), sandboxQualificationCanary: {
          ...qualificationCanary, grantId: reactivatedCanaryGrant.id,
        } },
      });
      const [currentQualificationBinding] = await db.select().from(runtimeSandboxBindings)
        .where(eq(runtimeSandboxBindings.id, sandboxBinding.id)).limit(1);
      const qualifiedTarget = testTargets.get(sandboxBinding.id)!;
      const priorTarget = qualifiedTarget;
      const targetWithoutHash = { ...priorTarget, bindingVersion: currentQualificationBinding!.version };
      delete targetWithoutHash.targetHash;
      const raceTarget = { ...targetWithoutHash, targetHash: nativeSha256(targetWithoutHash) };
      testTargets.set(sandboxBinding.id, raceTarget);
      const badMarkerCommandId = randomUUID();
      const badMarkerCapability = await gateway.issueSandboxQualificationCredentialProbe({
        actor: f.actor, scope: sandboxIdentity, bindingVersion: currentQualificationBinding!.version,
        operationKey: `qualification-canary-bad-marker:${sandboxBinding.id}:${currentQualificationBinding!.version}`,
        target: raceTarget as NonNullable<SandboxCapabilitySnapshot["qualificationTarget"]>,
        caseId: "credential_allow", commandId: badMarkerCommandId,
      });
      expect(badMarkerCapability).toBeTruthy();
      const allowProbe = sandboxProbeCases(raceTarget.probePolicyHash, SANDBOX_CONTROLS).find(test => test.caseId === "credential_allow")!;
      qualificationProviderMarkerOverride = "wrong-provider-marker";
      const badMarkerProbe = { ...allowProbe, qualificationCredentialCapability: badMarkerCapability!.capabilityToken,
        qualificationCredentialNonce: badMarkerCapability!.nonce, qualificationCommandId: badMarkerCommandId };
      await driveHost(transportForTest.bridge(f.actor).probe({ ...sandboxIdentity, test: badMarkerProbe }), admissionCell!.id);
      qualificationProviderMarkerOverride = null;
      expect(qualificationToolResponses.at(-1)).toMatchObject({
        caseId: "credential_allow", status: 502, reasonCode: "sandbox_qualification_result_invalid", marker: null,
      });
      const inFlightCommandId = randomUUID();
      const inFlightCapability = await gateway.issueSandboxQualificationCredentialProbe({
        actor: f.actor, scope: sandboxIdentity, bindingVersion: currentQualificationBinding!.version,
        operationKey: `qualification-canary-race:${sandboxBinding.id}:${currentQualificationBinding!.version}`,
        target: raceTarget as NonNullable<SandboxCapabilitySnapshot["qualificationTarget"]>,
        caseId: "credential_allow", commandId: inFlightCommandId,
      });
      expect(inFlightCapability).toBeTruthy();
      const raceProbe = { ...allowProbe, qualificationCredentialCapability: inFlightCapability!.capabilityToken,
        qualificationCredentialNonce: inFlightCapability!.nonce, qualificationCommandId: inFlightCommandId };
      const raceBarrier = deferNextProviderResponse();
      const raceRequest = driveHost(transportForTest.bridge(f.actor).probe({ ...sandboxIdentity, test: raceProbe }), admissionCell!.id);
      await raceBarrier.started;
      await qualificationToolAccess.revokeConnectionGrant(qualificationConnection.id, reactivatedCanaryGrant.id, qualificationActor);
      raceBarrier.release();
      await raceRequest;
      expect(qualificationToolResponses.at(-1)).toMatchObject({
        caseId: "credential_allow", status: 403, reasonCode: "sandbox_qualification_grant_revoked", marker: null,
      });
      const [stillActiveRuntimeGrant] = await db.select({ status: connectionGrants.status }).from(connectionGrants)
        .where(eq(connectionGrants.id, brokerGrant!.id)).limit(1);
      expect(stillActiveRuntimeGrant?.status).toBe("active");
    }, 240000);
  },
);
