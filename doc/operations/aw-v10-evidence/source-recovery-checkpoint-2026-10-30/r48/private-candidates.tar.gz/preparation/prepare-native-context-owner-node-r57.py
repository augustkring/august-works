from pathlib import Path
import hashlib,json,difflib
r=Path('/workspace/blentera-v10');o=Path('/workspace/v10-preparation/native-context-owner-node-r57-candidate');rel='server/src/services/native-direct-input.ts';a=(r/rel).read_text();s=a
# Reuse the existing incompatibility signal for unsupported owner selectors.
needle='''  for (const stack of scope.context.ancestry.frozenTaskProofStacks.values())
    for (const frame of stack) frame.mutableSources.compatible = false;
}
function recordNativeProofReaderSet''';assert needle in s
s=s.replace(needle,'''  markNativeSourceProofsIncompatible(scope);
}
function markNativeSourceProofsIncompatible(scope: NativeSourceReadScope): void {
  for (const stack of scope.context.ancestry.frozenTaskProofStacks.values())
    for (const frame of stack) frame.mutableSources.compatible = false;
}
function recordNativeProofReaderSet''',1)
start=s.index('async function assertNativeContextInputOwnersCurrent(');end=s.index('\nexport async function assertNativeTemporalContextInputsCurrent',start);part=s[start:end]
needle='''  for (const manifest of manifests) {
    if(await assertNativeAnalyticalResultContextCurrent(db,companyId,actor,manifest,
      items.filter(value=>value.manifestId===manifest.id),roots.filter(value=>value.manifestId===manifest.id)))continue;
    for (const item of items.filter(value => value.manifestId === manifest.id)) {''';assert needle in part
part=part.replace(needle,'''  for (const manifest of manifests) {
    const manifestItems = items.filter(value => value.manifestId === manifest.id);
    const manifestRoots = roots.filter(value => value.manifestId === manifest.id);
    if(await assertNativeAnalyticalResultContextCurrent(db,companyId,actor,manifest,manifestItems,manifestRoots)) {
      markNativeSourceProofsIncompatible(scope);
      continue;
    }
    const readOwners = async () => {
    for (const item of manifestItems) {''',1)
part=part.replace('for (const root of roots.filter(value => value.manifestId === manifest.id)) {','for (const root of manifestRoots) {',1)
needle='''    }
  }
  if (legacyTaskIssueIds.size) deferNativeAnalyticalTaskChecks(scope, companyId, actor, legacyTaskIssueIds);
}''';assert needle in part
part=part.replace(needle,'''    }
    };
    const reusable = is(db, PgTransaction) && scope.context.db === (db as object) && manifest.projectId === null && manifestItems.every(item =>
      item.sourceProvider === "august_works_tasks" || item.sourceProvider === "august_works_memory" ||
      item.sourceProvider === "august_works_derived_memory");
    if (!reusable) {
      markNativeSourceProofsIncompatible(scope);
      await readOwners();
      continue;
    }
    const contextSource = inputs.find(source => source.manifestId === manifest.id);
    if (!contextSource) throw forbidden("A Native Context manifest source is unavailable");
    const taskBindings = manifestItems.filter(item => item.sourceProvider === "august_works_tasks").map(item => {
      const taskId = item.sourceRef.slice("issue://".length);
      return { owner: taskOwnerById.get(taskId), hash: taskHashById.get(taskId) };
    });
    const ownerKey = `context-owner:${nativeSha256({ companyId, actor, actorScope: scope.actorKey,
      memoryTemporalIdentity: scope.context.memoryTemporalIdentity, source: contextSource,
      manifest, items: manifestItems, roots: manifestRoots, taskBindings,
      alreadyValidatedMemoryIds: [...alreadyValidatedMemoryIds].sort() })}`;
    const reader = { companyId, actor, runId: manifest.runId ?? manifest.id,
      policy: { issueIds: [], projectIds: [], runIds: [], memoryIds: [], foundationRevisionIds: [] },
      inputs: [contextSource] };
    await withNativeSourceGraphProof(scope, siblingToolSourceProofs, ownerKey, reader, async () => {
      await readOwners();
      for (const binding of taskBindings) {
        const snapshot = nativePayloadSourceSnapshotSchema.safeParse(binding.owner?.payloadSourceSnapshot);
        if (binding.owner?.payloadSourceProtocolVersion !== 1 || !snapshot.success ||
          !snapshot.data.inputs.some(source => source.kind === "worker_model_dispatch" || source.kind === "conversation_model_dispatch")) continue;
        const pin = scope.taskTemporalScopes.get(binding.owner.id);
        if (!pin || pin.contentHash !== snapshot.data.owner.contentHash || pin.snapshotDigest !== snapshot.data.digest)
          markNativeSourceProofsIncompatible(scope);
      }
      deferNativeSourceReaderCheck(scope, reader);
    });
    // A hit carries the exact current Task pins/readers via the existing
    // completed obligation replay; don't reclassify those v1 owners as legacy.
    for (const binding of taskBindings) if (binding.owner?.payloadSourceProtocolVersion === 1)
      legacyTaskIssueIds.delete(binding.owner.id);
  }
  if (legacyTaskIssueIds.size) deferNativeAnalyticalTaskChecks(scope, companyId, actor, legacyTaskIssueIds);
}''',1)
s=s[:start]+part+s[end:]
s=s.replace('''    const kind = key.startsWith("payload-source-set:") ? "payload_source_set" : "managed_consumed";''','''    const kind = key.startsWith("payload-source-set:") ? "payload_source_set" :
      key.startsWith("context-owner:") ? "context_owner" : "managed_consumed";''',1)
p=o/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);(o/'candidate.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)));(o/'manifest.json').write_text(json.dumps({rel:{'priorSha256':hashlib.sha256(a.encode()).hexdigest(),'candidateSha256':hashlib.sha256(s.encode()).hexdigest()}},indent=2))
