#!/usr/bin/env bash
set -euo pipefail
REPO=/workspace/blentera-v10
MIRROR=/workspace/v10-dep-qualification
CAND=/workspace/v10-preparation/v10-149-r14.38.4.62-worker-provider-pack-option-private
OUT=$CAND/qualification-r14.38.4.62-worker-provider-pack-option
BAKDIR=/tmp/blentera-r14.38.4.62-worker-provider-pack-option-build-backup
mkdir -m 700 "$OUT"
if [[ -e "$BAKDIR" ]]; then echo "compiled backup path already exists: $BAKDIR" > "$OUT/preflight.log"; exit 73; fi
exec 9>/workspace/v10-preparation/v10-pg-tests.lock
flock -x 9
root_kb=$(df -Pk / | awk 'NR==2 {print $4}')
tmp_kb=$(df -Pk /tmp | awk 'NR==2 {print $4}')
if [[ ! "$root_kb" =~ ^[0-9]+$ || ! "$tmp_kb" =~ ^[0-9]+$ ]] || ((root_kb < 120000 || tmp_kb < 120000)); then
  echo "headroom guard failed before snapshot: root=${root_kb:-unknown}KB tmp=${tmp_kb:-unknown}KB" > "$OUT/preflight.log"; exit 78
fi
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH
export PAPERCLIP_QUALIFIED_OPENCODE_BINARY=/workspace/.cloud-setup/lockfile/node_modules/.pnpm/opencode-linux-x64-baseline@1.18.32/node_modules/opencode-linux-x64-baseline/bin/opencode
export PAPERCLIP_RUNNER_REMOTE_PROVIDER_PACK_PATH=/tmp/paperclip-runner-provider-pack-f06f1ffaa1cbc10c56809c0a1e60c96768ee53f13df23c2830279d881a873baa
export PAPERCLIP_NATIVE_CONTEXT_PHASE_DIAGNOSTICS=0
export PAPERCLIP_NATIVE_SOURCE_MEMO_DIAGNOSTICS=1
export PAPERCLIP_NATIVE_SOURCE_CLOSURE_DIAGNOSTICS=1
export PAPERCLIP_NATIVE_TEST_TOOL_RESULT_DIAGNOSTICS=1
cd "$REPO"
PARSER=/workspace/v10-preparation/v10-149-r14.38.4.10-focused-host-private/oxc-parse.mjs
PARSER_SHA=5453aa3a596a7806cb89d607da707c5bbe8f4f870732d92c4d93130545a47c7d
if [[ ! -r "$PARSER" ]] || [[ $(sha256sum "$PARSER" | awk '{print $1}') != "$PARSER_SHA" ]]; then
  echo "immutable Oxc parser preflight failed" > "$OUT/preflight.log"; exit 78
fi
node --check "$PARSER" > "$OUT/parser-check.log" 2>&1
python3 - "$OUT/toolchain.json" "$PARSER" "$PARSER_SHA" <<'PYTOOL'
from pathlib import Path
import hashlib,json,sys
p=Path(sys.argv[2]); digest=hashlib.sha256(p.read_bytes()).hexdigest()
if digest!=sys.argv[3]: raise SystemExit('Oxc parser SHA changed after preflight')
Path(sys.argv[1]).write_text(json.dumps({'parserPath':str(p),'parserSha256':digest},indent=2)+'\n')
PYTOOL
mkdir -m 700 "$BAKDIR"
python3 - "$CAND/source-pins.json" "$CAND/files" "$REPO" "$MIRROR" "$BAKDIR/source-backup" "$BAKDIR" "$OUT/overlay-state.json" <<'PY'
from pathlib import Path
import hashlib,json,os,shutil,stat,sys
pins=json.loads(Path(sys.argv[1]).read_text())['sourceFiles']; cand=Path(sys.argv[2]); repo=Path(sys.argv[3]); mirror=Path(sys.argv[4]); sourceBackup=Path(sys.argv[5]); build=Path(sys.argv[6]); state=Path(sys.argv[7]); rows=[]
for row in pins:
 p=row['path']; wantParent=row['parentSha256']; wantMirror=row.get('qualificationMirrorBaseSha256',wantParent); wantCandidate=row['candidateSha256']
 for label,root,want in [('MAIN',repo,wantParent),('mirror-before-snapshot',mirror,wantMirror),('candidate',cand,wantCandidate)]:
  f=root/p; actual=hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None
  if actual!=want: raise SystemExit(f'{label} pin mismatch {p}: {actual} != {want}')
 src=mirror/p; saved=sourceBackup/p
 if src.is_file():
  saved.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,saved)
 rows.append({'path':p,'parentSha256':wantParent,'mirrorSha256':wantMirror,'candidateSha256':wantCandidate,
   'mode':stat.S_IMODE(src.stat().st_mode) if src.is_file() else None,'present':src.is_file()})
dirs=['packages/shared/dist','packages/db/dist','server/dist']; present=[]; tree=[]
for rel in dirs:
 src=mirror/rel
 if src.exists():
  present.append(rel); dst=build/'dirs'/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copytree(src,dst,symlinks=True)
  for f in src.rglob('*'):
   rr=f.relative_to(mirror).as_posix()
   if f.is_symlink(): tree.append({'path':rr,'kind':'link','target':os.readlink(f),'mode':stat.S_IMODE(f.lstat().st_mode)})
   elif f.is_file(): tree.append({'path':rr,'kind':'file','sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'mode':stat.S_IMODE(f.stat().st_mode)})
infos=[p.relative_to(mirror).as_posix() for p in mirror.rglob('*.tsbuildinfo') if p.is_file()]
for rel in infos:
 src=mirror/rel; dst=build/'files'/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
state.write_text(json.dumps({'sourceFiles':rows,'distDirs':present,'distTree':tree,'tsbuildinfo':infos},indent=2)+'\n')
PY
restore_ready=1
restore_all() {
python3 - "$OUT/overlay-state.json" "$MIRROR" "$BAKDIR/source-backup" "$BAKDIR" "$OUT/restore.log" <<'PY'
from pathlib import Path
import hashlib,json,os,shutil,stat,sys
state=json.loads(Path(sys.argv[1]).read_text()); root=Path(sys.argv[2]); backup=Path(sys.argv[3]); build=Path(sys.argv[4]); log=Path(sys.argv[5]); errors=[]
for row in state['sourceFiles']:
 p=row['path']; dst=root/p; saved=backup/p; got=hashlib.sha256(dst.read_bytes()).hexdigest() if dst.is_file() else None
 if got in (row['candidateSha256'],row['parentSha256'],row['mirrorSha256']):
  if row['present']:
   dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(saved,dst)
  else: dst.unlink(missing_ok=True)
 else: errors.append(f'SOURCE_RESTORE_GUARD {p} actual={got}')
for rel in state['distDirs']:
 dst=root/rel; saved=build/'dirs'/rel
 if dst.exists(): shutil.rmtree(dst)
 if saved.exists(): shutil.copytree(saved,dst,symlinks=True)
for rel in state['tsbuildinfo']:
 dst=root/rel; saved=build/'files'/rel
 if dst.exists() or dst.is_symlink(): dst.unlink()
 dst.parent.mkdir(parents=True,exist_ok=True)
 if saved.exists(): shutil.copy2(saved,dst)
keep=set(state['tsbuildinfo'])
for p in root.rglob('*.tsbuildinfo'):
 if p.relative_to(root).as_posix() not in keep: p.unlink()
for row in state['sourceFiles']:
 p=row['path']; dst=root/p; got=hashlib.sha256(dst.read_bytes()).hexdigest() if dst.is_file() else None
 expected=row['mirrorSha256']
 if got!=expected: errors.append(f'SOURCE_POST_RESTORE {p} {got} != {expected}')
 if row['present'] and stat.S_IMODE(dst.stat().st_mode)!=row['mode']: errors.append(f'SOURCE_MODE_POST_RESTORE {p}')
actual=[]
for rel in state['distDirs']:
 d=root/rel
 if d.exists():
  for f in d.rglob('*'):
   rr=f.relative_to(root).as_posix()
   if f.is_symlink(): actual.append({'path':rr,'kind':'link','target':os.readlink(f),'mode':stat.S_IMODE(f.lstat().st_mode)})
   elif f.is_file(): actual.append({'path':rr,'kind':'file','sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'mode':stat.S_IMODE(f.stat().st_mode)})
if sorted(actual,key=lambda x:x['path'])!=sorted(state['distTree'],key=lambda x:x['path']): errors.append('COMPILED_POST_RESTORE tree/mode/hash mismatch')
for rel in state['tsbuildinfo']:
 dst=root/rel; saved=build/'files'/rel
 if not dst.is_file() or hashlib.sha256(dst.read_bytes()).digest()!=hashlib.sha256(saved.read_bytes()).digest(): errors.append(f'TSBUILDINFO_POST_RESTORE {rel}')
log.write_text(('\n'.join(errors)+'\n') if errors else 'pinned sources restored to pre-snapshot source bytes and modes; compiled outputs and tsbuildinfo restored byte-for-byte\n')
if errors: raise SystemExit(1)
PY
}
cleanup() { if ((restore_ready)); then restore_all || echo 'restore_failed=1' >> "$OUT/restore.log"; fi; }
trap cleanup EXIT INT TERM
python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$OUT/snapshot-source-pins.json" > "$OUT/snapshot.log" 2>&1
cp "$OUT/overlay-state.json" "$OUT/pre-overlay-state.json"
python3 - "$CAND/source-pins.json" "$CAND/files" "$MIRROR" <<'PY'
from pathlib import Path
import hashlib,json,shutil,sys
pins=json.loads(Path(sys.argv[1]).read_text())['sourceFiles']; cand=Path(sys.argv[2]); mirror=Path(sys.argv[3])
for row in pins:
 src=cand/row['path']; dst=mirror/row['path']; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
 if hashlib.sha256(dst.read_bytes()).hexdigest()!=row['candidateSha256']: raise SystemExit(f'overlay mismatch {row["path"]}')
PY
run_step() { local n="$1"; shift; set +e; "$@" > "$OUT/$n.log" 2>&1; local rc=$?; set -e; printf '%s\n' "$rc" > "$OUT/$n.exit"; }
cd "$MIRROR"
run_step source-oxc node "$PARSER" "$CAND/files"
if [[ $(cat "$OUT/source-oxc.exit") != 0 ]]; then exit 1; fi
cd "$MIRROR"
run_step shared-build pnpm --filter @paperclipai/shared build
run_step db-build pnpm --filter @paperclipai/db build
cd "$MIRROR/server"
cd "$MIRROR"
cd "$MIRROR/server"
run_step targeted-worker-vitest timeout 420 pnpm exec vitest run src/__tests__/managed-worker-sandbox-lifecycle.integration.test.ts --maxWorkers=1 --reporter=verbose
python3 - "$OUT" <<'PY'
from pathlib import Path
import json,sys
(out/'result-before-restore.json').write_text(json.dumps(result,indent=2)+'\n'); print(result)
if any(result[n] for n in names): raise SystemExit(1)
PY
