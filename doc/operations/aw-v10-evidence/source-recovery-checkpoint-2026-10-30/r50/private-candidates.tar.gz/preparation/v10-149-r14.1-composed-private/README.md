# V10-149 R14.1 composed private source candidate

This is a private 20-path source candidate composed from the frozen Quality R2 snapshot (`v10-149-native-provision-r2-source-snapshot-20261030`), the R10 host source closure, and the host-only R12/R13/R14 patch lineage. Vendor Rust is pinned separately by the vendor workflow and was not changed or compiled here. The R10-to-R14 host patches were applied in order; the Quality bridge-test semantic delta was applied against its exact Main parent. The R14.1 fixes make malformed protected capability reports return unsupported, align JWT origin validation with the actual no-trailing-slash URL origin emitted by the host, and resolve the missing credential case/type import. A policy test now uses a valid synthetic exact target for protected-profile proof.

`source-pins.json` records the current-MAIN parent and candidate SHA-256 for every source path. `source.patch` reconstructs the candidate, and `exact-stage-paths.txt` is the exact path list. `reconstruction-check.log` records a successful patch dry-run against current MAIN (`ae983829e2bc2e5db2064769c72e700eeaf0a600`). No MAIN source is changed by this work.

The first R14 run is retained under `v10-149-r14-composed-private/qualification-initial2` with its original result and failure logs. R14.1 qualification is in `qualification-r14.1`; it snapshots the canonical dependency mirror, verifies source pins, overlays only the listed paths, and restores source files plus dist/tsbuildinfo byte-for-byte.

R14.1 verdicts: host agent 51/51; shared typecheck pass; auth/policy/backend tests 75/75 with the pinned official prover; the selected ToolGateway broker test 1 pass; qualification fault tests 13/13. The existing host-bridge integration has 18/21 passing tests. Its remaining cases are test-fixture contract updates: one replays a provisioning claim after the binding version has advanced (now correctly rejected), and another lacks the separate setup-only canary fixture needed for credential probes. Quality owns a superseding host-bridge test delta and a separate PG test file.

Full server TypeScript checking reports only two errors in unrelated current dirty Native source at `server/src/services/native-direct-input.ts:272–273` (transaction-to-Db casts). It reports no diagnostics in the 20 candidate paths. Source restoration and dist/tsbuildinfo restoration both passed.

This source qualification does not attest a physical host or provider. The local prover was SHA-256 checked and used only by focused source tests; no paid provider or deployment was used.
