import { createHash } from "node:crypto";
import { isDeepStrictEqual } from "node:util";
import path from "node:path";
import { nativePayloadSourceInputSchema, nativePayloadSourcePolicySchema, type NativePayloadSourceInput } from "@paperclipai/shared";
import type { NativeRuntimeAssetReference } from "../../vendor/paperclip-runner/index.js";
import type { NativePayloadSourceSet } from "./native-execution-input.js";
import { nativeSha256 } from "./canonical.js";
import { materializeAsset, readNativeRuntimeAssetText } from "./runtime-context.js";
import { nativeRuntimeAssetsRoot, type NativeRuntimeAssetOwner } from "./runtime-asset-retention.js";

export interface NativeBuiltinToolCall {
  tool_name: string;
  tool_use_id: string;
  tool_input: unknown;
  tool_response: unknown;
}

export interface NativeBuiltinToolBatch {
  session_id: string;
  transcript_path: string;
  cwd: string;
  prompt_id: string;
  permission_mode: string;
  hook_event_name: "PostToolBatch";
  tool_calls: NativeBuiltinToolCall[];
}

/** Private runner witness. Its bytes must come from the authenticated runner's
 * trusted launch root; a hook cwd or model-supplied file list is not a witness. */
export interface NativeBuiltinWorkspaceWitness {
  executionWorkspaceId: string;
  sessionId: string;
  rootPath: string;
  before: NativeBuiltinWorkspaceSnapshot;
  after: NativeBuiltinWorkspaceSnapshot;
}

export interface NativeBuiltinToolCaptureAsset {
  schema: "paperclip.native-builtin-tool-capture.v1";
  companyId: string;
  runId: string;
  eventSeq: number;
  attempt: number;
  captureId: string;
  normalizedSessionId: string;
  turnId: string;
  sdkSessionId: string;
  batch: NativeBuiltinToolBatch;
  workspace: NativeBuiltinWorkspaceWitness;
  fileSourcesBefore: NativeBuiltinFileSource[];
  fileSourcesAfter: NativeBuiltinFileSource[];
  producedSources: NativePayloadSourceSet;
  resultSources: Array<{ callId: string; sourceSet: NativePayloadSourceSet }>;
}

const opaque = (value: unknown): value is string => typeof value === "string" && /^[\x21-\x7e]{1,240}$/.test(value);
const object = (value: unknown): value is Record<string, unknown> => !!value && typeof value === "object" && !Array.isArray(value);
const failure = () => new Error("native_builtin_capture_binding_invalid");

export function assertNativeBuiltinToolSourceSupported(toolName: string) {
  if (!["Read","Write","Edit"].includes(toolName))
    throw new Error("native_builtin_capture_tool_source_unsupported");
}

export function validateNativeBuiltinToolCaptureAsset(value: NativeBuiltinToolCaptureAsset, owner: NativeRuntimeAssetOwner): void {
  if (!object(value) || value.schema !== "paperclip.native-builtin-tool-capture.v1" ||
    value.companyId !== owner.companyId || value.runId !== owner.runId ||
    !Number.isSafeInteger(value.eventSeq) || value.eventSeq < 0 || !Number.isSafeInteger(value.attempt) || value.attempt < 1 ||
    ![value.captureId, value.normalizedSessionId, value.turnId, value.sdkSessionId].every(opaque) ||
    !object(value.batch) || value.batch.hook_event_name !== "PostToolBatch" ||
    value.batch.session_id !== value.sdkSessionId || !opaque(value.batch.prompt_id) ||
    typeof value.batch.cwd !== "string" || !path.isAbsolute(value.batch.cwd) ||
    typeof value.batch.transcript_path !== "string" || !path.isAbsolute(value.batch.transcript_path) ||
    typeof value.batch.permission_mode !== "string" || !value.batch.permission_mode ||
    !Array.isArray(value.batch.tool_calls) || value.batch.tool_calls.length < 1 || value.batch.tool_calls.length > 128 ||
    !object(value.workspace) || value.workspace.sessionId !== value.sdkSessionId ||
    !nativePayloadSourceInputSchema.safeParse({ kind: "retained_workspace", runId: value.runId,
      executionWorkspaceId: value.workspace.executionWorkspaceId, sessionId: value.sdkSessionId,
      contentHash: nativeSha256(value.workspace) }).success ||
    typeof value.workspace.rootPath !== "string" || !path.isAbsolute(value.workspace.rootPath) ||
    value.batch.cwd !== value.workspace.rootPath || !object(value.workspace.before) || !object(value.workspace.after)) throw failure();
  validateNativeBuiltinWorkspaceSnapshot(value.workspace.before);
  validateNativeBuiltinWorkspaceSnapshot(value.workspace.after);
  if (value.workspace.before.workspaceRootDigest !== nativeBuiltinWorkspaceRootDigest(value.workspace.rootPath) ||
    value.workspace.before.phase !== "pre" || value.workspace.after.phase !== "post" ||
    value.workspace.before.workspaceRootDigest !== value.workspace.after.workspaceRootDigest ||
    value.batch.tool_calls.length !== 1 || value.workspace.before.toolUseId !== value.batch.tool_calls[0]!.tool_use_id ||
    value.workspace.after.toolUseId !== value.batch.tool_calls[0]!.tool_use_id ||
    value.workspace.before.toolName !== value.batch.tool_calls[0]!.tool_name ||
    value.workspace.after.toolName !== value.batch.tool_calls[0]!.tool_name) throw failure();
  if (!Array.isArray(value.fileSourcesBefore) || !Array.isArray(value.fileSourcesAfter) || !Array.isArray(value.resultSources)) throw failure();
  parseNativeBuiltinSourceSet(value.producedSources);
  for (const entry of [...value.fileSourcesBefore, ...value.fileSourcesAfter, ...value.resultSources]) parseNativeBuiltinSourceSet(entry.sourceSet);
  const ids = new Set<string>();
  for (const call of value.batch.tool_calls) {
    if (!object(call) || !opaque(call.tool_name) || !opaque(call.tool_use_id) ||
      !Object.hasOwn(call, "tool_input") || !Object.hasOwn(call, "tool_response") || ids.has(call.tool_use_id)) throw failure();
    assertNativeBuiltinToolWorkspaceAccess(call,value.workspace.rootPath);
    ids.add(call.tool_use_id);
  }
  if (Buffer.byteLength(JSON.stringify(value), "utf8") > 256000) throw new Error("native_builtin_capture_budget_exceeded");
}

/** Call only inside withRetainedNativeRuntimeAssets and the execution lease
 * transaction. This stores no raw payload in a run event or profile JSON. */
export async function materializeNativeBuiltinToolCaptureAsset(value: NativeBuiltinToolCaptureAsset) {
  const owner = { companyId: value.companyId, runId: value.runId };
  validateNativeBuiltinToolCaptureAsset(value, owner);
  const text = JSON.stringify(value);
  const bundle = await materializeAsset([{ path: "native-builtin-capture.json", content: Buffer.from(text), mode: 0o444 }], owner);
  await readNativeBuiltinToolCaptureAsset(bundle, owner);
  return { bundle, captureDigest: nativeSha256(value) };
}

/** Unlike legacy runtime instruction readers, capture assets never admit a
 * global root, another run, another company, or an alternate bundle path. */
export async function readNativeBuiltinToolCaptureAsset(bundle: NativeRuntimeAssetReference, owner: NativeRuntimeAssetOwner) {
  if (!bundle || typeof bundle.rootPath !== "string" || !/^[a-f0-9]{64}$/.test(bundle.digest) ||
    bundle.rootPath !== path.join(nativeRuntimeAssetsRoot(owner), "bundles", bundle.digest)) throw failure();
  const files = await readNativeRuntimeAssetText(bundle, 256000, owner);
  if (files.length !== 1 || files[0]!.path !== "native-builtin-capture.json") throw failure();
  const asset = JSON.parse(files[0]!.text) as NativeBuiltinToolCaptureAsset;
  validateNativeBuiltinToolCaptureAsset(asset, owner);
  return asset;
}

/** Match the exact SDK tuple against exactly one settled provider response.
 * The caller checks the reservation's current DB settlement under run locks. */
export function nativeBuiltinToolUseIntent(profile: Record<string, unknown>, asset: Pick<NativeBuiltinToolCaptureAsset, "sdkSessionId">, call: Omit<NativeBuiltinToolCall, "tool_response">) {
  const intents = profile.nativeAwModelWireIntents;
  if (!Array.isArray(intents)) throw failure();
  const matches = intents.flatMap(intent => object(intent) && Array.isArray(intent.responseToolUses)
    ? intent.responseToolUses.flatMap(use => object(use) && use.id === call.tool_use_id ? [{ intent, use }] : []) : []);
  if (matches.length !== 1) throw failure();
  const { intent, use } = matches[0]!;
  if (intent.providerProtocol !== "claude_messages" || intent.sdkSessionId !== asset.sdkSessionId ||
    use.name !== call.tool_name || use.argumentsHash !== nativeSha256(call.tool_input) ||
    !opaque(intent.reservationId) || typeof intent.responseContentHash !== "string" ||
    !/^[a-f0-9]{64}$/.test(intent.responseContentHash)) throw failure();
  const source = object(intent.consumedSourceSet) ? intent.consumedSourceSet : {};
  const policy = nativePayloadSourcePolicySchema.safeParse(source.policy);
  const inputs = nativePayloadSourceInputSchema.array().safeParse(source.inputs);
  if (!policy.success || !inputs.success || !Array.isArray(intent.consumedSourceComponents) ||
    intent.consumedSourceSetHash !== nativeSha256({ policy: policy.data, inputs: inputs.data })) throw failure();
  return { intent, sourceSet: { policy: policy.data, inputs: inputs.data } satisfies NativePayloadSourceSet };
}

export async function assertNativeBuiltinToolCaptureRow(row: Record<string, unknown>, owner: NativeRuntimeAssetOwner) {
  if (row.nativeBuiltin !== true || !object(row.captureAsset) || typeof row.captureDigest !== "string") throw failure();
  const asset = await readNativeBuiltinToolCaptureAsset(row.captureAsset as unknown as NativeRuntimeAssetReference, owner);
  if (nativeSha256(asset) !== row.captureDigest || row.captureId !== asset.captureId ||
    row.eventSeq !== asset.eventSeq || row.attempt !== asset.attempt || row.turnId !== asset.turnId ||
    row.sdkSessionId !== asset.sdkSessionId || row.executionWorkspaceId !== asset.workspace.executionWorkspaceId) throw failure();
  const calls = asset.batch.tool_calls.filter(call => call.tool_use_id === row.callId);
  if (calls.length !== 1 || calls[0]!.tool_name !== row.tool || nativeSha256(calls[0]!.tool_input) !== row.argumentsHash ||
    nativeSha256(calls[0]!.tool_response) !== row.resultDigest) throw failure();
  const source: NativePayloadSourceInput = { kind: "tool_result", runId: owner.runId, callId: calls[0]!.tool_use_id,
    toolName: calls[0]!.tool_name, invocationId: null, contentHash: nativeSha256(calls[0]!.tool_response) };
  const resultSources = asset.resultSources.filter(entry => entry.callId === row.callId);
  if (!isDeepStrictEqual(source, row.source) || resultSources.length !== 1 ||
    !isDeepStrictEqual(resultSources[0]!.sourceSet, row.sourceSet) ||
    !isDeepStrictEqual(resultSources[0]!.sourceSet.inputs, row.sourceInputs)) throw failure();
  const pre = await readNativeBuiltinToolPreAsset(row.preCaptureAsset as NativeRuntimeAssetReference,owner);
  if (nativeSha256(pre) !== row.preCaptureDigest || !isDeepStrictEqual(row.workspaceSource,nativeBuiltinDeclaredWorkspaceSource(pre)) ||
    pre.call.tool_use_id !== row.callId ||
    pre.normalizedSessionId !== asset.normalizedSessionId || pre.sdkSessionId !== asset.sdkSessionId ||
    !isDeepStrictEqual(pre.snapshot,asset.workspace.before) || !isDeepStrictEqual(pre.fileSources,asset.fileSourcesBefore) ||
    !isDeepStrictEqual(asset.fileSourcesAfter,nativeBuiltinFileLineageAfter(asset.workspace.before,asset.workspace.after,
      asset.fileSourcesBefore,asset.producedSources)) ||
    !isDeepStrictEqual(resultSources[0]!.sourceSet,calls[0]!.tool_name === "Read"
      ? nativeBuiltinReadFileSourceSet(calls[0]!,asset.workspace,asset.fileSourcesBefore) : asset.producedSources)) throw failure();
  return { asset, pre, call: calls[0]!, source };
}


export interface NativeBuiltinWorkspaceSnapshot {
  schema: "paperclip.native-workspace-witness.v1";
  snapshotDigest: string;
  fileCount: number;
  totalBytes: number;
  phase: "pre" | "post";
  toolUseId: string;
  toolName: string;
  workspaceRootDigest: string;
  files: Array<{ relativePath: string; exists: true; sha256: string; size: number; contentBase64: string;
    device: number; inode: number; mtimeMs: number }>;
  excludedSymlinks: [];
}
export interface NativeBuiltinFileSource {
  relativePath: string;
  sha256: string;
  sourceSet: NativePayloadSourceSet;
}

export function parseNativeBuiltinSourceSet(value: NativePayloadSourceSet): NativePayloadSourceSet {
  if (!object(value)) throw failure();
  const sourceSet = { policy: nativePayloadSourcePolicySchema.parse(value.policy),
    inputs: nativePayloadSourceInputSchema.array().parse(value.inputs) };
  if (new Set(sourceSet.inputs.map(nativeSha256)).size !== sourceSet.inputs.length) throw failure();
  return sourceSet;
}

export function validateNativeBuiltinWorkspaceSnapshot(value: NativeBuiltinWorkspaceSnapshot): void {
  if (!object(value) || value.schema !== "paperclip.native-workspace-witness.v1" || !["pre", "post"].includes(value.phase) || !opaque(value.toolUseId) || !opaque(value.toolName) ||
    !/^sha256:[a-f0-9]{64}$/.test(value.workspaceRootDigest) || !Array.isArray(value.files) || value.files.length > 4096 ||
    !Array.isArray(value.excludedSymlinks) || value.excludedSymlinks.length !== 0) throw failure();
  let previous = "", total = 0;
  for (const file of value.files) {
    if (!object(file) || file.exists !== true || typeof file.relativePath !== "string" || Buffer.compare(Buffer.from(file.relativePath),Buffer.from(previous)) <= 0 ||
      file.relativePath.includes("\\") || file.relativePath.includes("\0") || path.posix.isAbsolute(file.relativePath) ||
      file.relativePath.split("/").some(part => !part || part === "." || part === "..") ||
      !/^[a-f0-9]{64}$/.test(file.sha256) || !Number.isSafeInteger(file.size) || file.size < 0 ||
      typeof file.contentBase64 !== "string" || !Number.isFinite(file.device) || !Number.isFinite(file.inode) || !Number.isFinite(file.mtimeMs)) throw failure();
    previous = file.relativePath;
    const bytes = Buffer.from(file.contentBase64, "base64");
    if (bytes.toString("base64") !== file.contentBase64 || bytes.length !== file.size ||
      createHash("sha256").update(bytes).digest("hex") !== file.sha256) throw failure();
    total += bytes.length;
    if (total > 65536) throw new Error("native_builtin_capture_budget_exceeded");
  }
  const snapshotDigest = `sha256:${nativeSha256(value.files.map(file => ({path:file.relativePath,hash:file.sha256,size:file.size})))}`;
  if (value.fileCount !== value.files.length || value.totalBytes !== total || value.snapshotDigest !== snapshotDigest) throw failure();
}

/** File-version identity excludes observation timestamps/inodes, which can
 * change when an identical version is restored. Raw snapshots retain both. */
export function nativeBuiltinWorkspaceContentHash(snapshot: NativeBuiltinWorkspaceSnapshot) {
  validateNativeBuiltinWorkspaceSnapshot(snapshot);
  return nativeSha256(snapshot.files.map(file => ({ path: file.relativePath, hash: file.sha256, size: file.size })));
}

export function nativeBuiltinWorkspaceInputHash(input: Pick<NativeBuiltinToolPreAsset,
  "runId" | "executionWorkspaceId" | "sdkSessionId" | "snapshot" | "captureId" | "eventSeq" | "attempt" | "turnId" | "normalizedSessionId">) {
  return nativeSha256({ schema:"paperclip.native-workspace-input.v1",runId:input.runId,executionWorkspaceId:input.executionWorkspaceId,
    sdkSessionId:input.sdkSessionId,captureId:input.captureId,eventSeq:input.eventSeq,attempt:input.attempt,turnId:input.turnId,
    normalizedSessionId:input.normalizedSessionId,workspaceRootDigest:input.snapshot.workspaceRootDigest,
    snapshotHash:nativeBuiltinWorkspaceContentHash(input.snapshot) });
}

export function nativeBuiltinDeclaredWorkspaceSource(input: Parameters<typeof nativeBuiltinWorkspaceInputHash>[0]):
  Extract<NativePayloadSourceInput, { kind: "retained_workspace" }> {
  return nativePayloadSourceInputSchema.parse({ kind: "retained_workspace", runId: input.runId,
    executionWorkspaceId: input.executionWorkspaceId, sessionId: input.sdkSessionId,
    contentHash: nativeBuiltinWorkspaceInputHash(input) }) as Extract<NativePayloadSourceInput, { kind: "retained_workspace" }>;
}

export function nativeBuiltinFileLineageBefore(snapshot: NativeBuiltinWorkspaceSnapshot, previous: NativeBuiltinToolCaptureAsset | null,
  initialSourceSet: NativePayloadSourceSet): NativeBuiltinFileSource[] {
  validateNativeBuiltinWorkspaceSnapshot(snapshot);
  if (!previous) return snapshot.files.map(file => ({ relativePath: file.relativePath, sha256: file.sha256,
    sourceSet: parseNativeBuiltinSourceSet(initialSourceSet) }));
  if (nativeBuiltinWorkspaceContentHash(snapshot) !== nativeBuiltinWorkspaceContentHash(previous.workspace.after)) throw failure();
  return snapshot.files.map(file => {
    const versions = previous.fileSourcesAfter.filter(entry => entry.relativePath === file.relativePath && entry.sha256 === file.sha256);
    if (versions.length !== 1) throw failure();
    return { relativePath: file.relativePath, sha256: file.sha256, sourceSet: parseNativeBuiltinSourceSet(versions[0]!.sourceSet) };
  });
}

export function nativeBuiltinFileLineageAfter(before: NativeBuiltinWorkspaceSnapshot, after: NativeBuiltinWorkspaceSnapshot,
  lineage: NativeBuiltinFileSource[], producedSources: NativePayloadSourceSet): NativeBuiltinFileSource[] {
  validateNativeBuiltinWorkspaceSnapshot(before); validateNativeBuiltinWorkspaceSnapshot(after);
  return after.files.map(file => {
    const old = before.files.find(entry => entry.relativePath === file.relativePath);
    const prior = lineage.filter(entry => entry.relativePath === file.relativePath && entry.sha256 === file.sha256);
    if (old?.sha256 === file.sha256 && prior.length !== 1) throw failure();
    return { relativePath: file.relativePath, sha256: file.sha256,
      sourceSet: old?.sha256 === file.sha256 ? parseNativeBuiltinSourceSet(prior[0]!.sourceSet) : parseNativeBuiltinSourceSet(producedSources) };
  });
}

export function nativeBuiltinReadFileSourceSet(call: Omit<NativeBuiltinToolCall,"tool_response">, workspace: NativeBuiltinWorkspaceWitness,
  lineage: NativeBuiltinFileSource[]): NativePayloadSourceSet {
  if (call.tool_name !== "Read" || !object(call.tool_input) || typeof call.tool_input.file_path !== "string") throw failure();
  const target = path.resolve(workspace.rootPath, call.tool_input.file_path);
  const relativePath = path.relative(workspace.rootPath, target).split(path.sep).join("/");
  if (!relativePath || relativePath.startsWith("../") || path.isAbsolute(relativePath)) throw failure();
  const before = workspace.before.files.filter(file => file.relativePath === relativePath);
  const after = workspace.after.files.filter(file => file.relativePath === relativePath);
  const sources = lineage.filter(file => file.relativePath === relativePath && file.sha256 === before[0]?.sha256);
  if (before.length !== 1 || after.length !== 1 || before[0]!.sha256 !== after[0]!.sha256 || sources.length !== 1) throw failure();
  if (nativeBuiltinWorkspaceContentHash(workspace.before) !== nativeBuiltinWorkspaceContentHash(workspace.after)) throw failure();
  // Actual SDK Read output must be captured intact. This is lineage selection,
  // not a replacement for the provider-wire adapter's exact output proof.
  return parseNativeBuiltinSourceSet(sources[0]!.sourceSet);
}

export interface NativeBuiltinToolPreAsset {
  schema: "paperclip.native-builtin-tool-pre.v1";
  companyId: string; runId: string; eventSeq: number; attempt: number;
  captureId: string; normalizedSessionId: string; turnId: string; sdkSessionId: string;
  executionWorkspaceId: string; rootPath: string;
  call: Omit<NativeBuiltinToolCall, "tool_response">;
  snapshot: NativeBuiltinWorkspaceSnapshot;
  fileSources: NativeBuiltinFileSource[];
  previousCaptureDigest:string|null;
  sourceSet: NativePayloadSourceSet;
}

export async function materializeNativeBuiltinToolPreAsset(value: NativeBuiltinToolPreAsset) {
  validateNativeBuiltinWorkspaceSnapshot(value.snapshot);
  const bundle = await materializeAsset([{ path: "native-builtin-pre.json", content: Buffer.from(JSON.stringify(value)), mode: 0o444 }], value);
  const retained = await readNativeBuiltinToolPreAsset(bundle, value);
  if (!isDeepStrictEqual(retained, value)) throw failure();
  return { bundle, captureDigest: nativeSha256(value) };
}

export async function readNativeBuiltinToolPreAsset(bundle: NativeRuntimeAssetReference, owner: NativeRuntimeAssetOwner) {
  if (!bundle || typeof bundle.rootPath !== "string" || !/^[a-f0-9]{64}$/.test(bundle.digest) ||
    bundle.rootPath !== path.join(nativeRuntimeAssetsRoot(owner), "bundles", bundle.digest)) throw failure();
  const files = await readNativeRuntimeAssetText(bundle, 256000, owner);
  if (files.length !== 1 || files[0]!.path !== "native-builtin-pre.json") throw failure();
  const value = JSON.parse(files[0]!.text) as NativeBuiltinToolPreAsset;
  if (!object(value) || value.schema !== "paperclip.native-builtin-tool-pre.v1" || value.companyId !== owner.companyId ||
    value.runId !== owner.runId || ![value.captureId,value.normalizedSessionId,value.turnId,value.sdkSessionId].every(opaque) ||
    !Number.isSafeInteger(value.eventSeq) || value.eventSeq < 0 || !Number.isSafeInteger(value.attempt) || value.attempt < 1 ||
    !object(value.call) || !opaque(value.call.tool_use_id) || !opaque(value.call.tool_name) || !Object.hasOwn(value.call,"tool_input") ||
    !Array.isArray(value.fileSources) || !(value.previousCaptureDigest === null ||
      typeof value.previousCaptureDigest === "string" && /^[a-f0-9]{64}$/.test(value.previousCaptureDigest)) || typeof value.rootPath !== "string" || !path.isAbsolute(value.rootPath)) throw failure();
  assertNativeBuiltinToolWorkspaceAccess(value.call,value.rootPath);
  validateNativeBuiltinWorkspaceSnapshot(value.snapshot);
  if (value.snapshot.workspaceRootDigest !== nativeBuiltinWorkspaceRootDigest(value.rootPath) ||
    value.snapshot.phase !== "pre" || value.snapshot.toolUseId !== value.call.tool_use_id || value.snapshot.toolName !== value.call.tool_name ||
    value.fileSources.length !== value.snapshot.files.length) throw failure();
  parseNativeBuiltinSourceSet(value.sourceSet);
  for (const file of value.snapshot.files) {
    const sources = value.fileSources.filter(entry => entry.relativePath === file.relativePath && entry.sha256 === file.sha256);
    if (sources.length !== 1) throw failure();
    parseNativeBuiltinSourceSet(sources[0]!.sourceSet);
  }
  nativeBuiltinDeclaredWorkspaceSource(value);
  return value;
}

/** Decode only after the private transport and live connection/lease manifest
 * have been authenticated. This parser alone grants no capture authority. */
export function nativeBuiltinToolCaptureRequestFromSourceEvent(sourceEvent: unknown, expected: {
  captureId: string; runId: string; normalizedSessionId: string; turnId: string;
}) {
  if (!object(sourceEvent) || sourceEvent.eventType !== "runtime.native_tool_batch_capture" ||
    sourceEvent.runId !== expected.runId || sourceEvent.turnId !== expected.turnId ||
    !Number.isSafeInteger(sourceEvent.sequence) || (sourceEvent.sequence as number) < 0 ||
    !object(sourceEvent.payload) || sourceEvent.payload.captureId !== expected.captureId ||
    !object(sourceEvent.payload.capture)) throw failure();
  const request = sourceEvent.payload.capture, hook = request.sdkHookInput;
  if (!object(hook) || !opaque(hook.session_id) || !opaque(request.sessionId) ||
    !["pre","post"].includes(request.phase as string) || !object(request.workspaceWitness)) throw failure();
  const identity = { captureId: expected.captureId, normalizedSessionId:expected.normalizedSessionId,
    turnId:expected.turnId,sdkSessionId:hook.session_id };
  if (request.phase === "pre") {
    if (hook.hook_event_name !== "PreToolUse" || !opaque(hook.tool_use_id) || !opaque(hook.tool_name) ||
      !Object.hasOwn(hook,"tool_input") || request.toolUseId !== hook.tool_use_id || request.toolName !== hook.tool_name ||
      !isDeepStrictEqual(request.toolInput,hook.tool_input)) throw failure();
    assertNativeBuiltinToolSourceSupported(hook.tool_name);
    const snapshot = { ...request.workspaceWitness,phase:"pre",toolUseId:hook.tool_use_id,toolName:hook.tool_name } as unknown as NativeBuiltinWorkspaceSnapshot;
    validateNativeBuiltinWorkspaceSnapshot(snapshot);
    return { phase:"pre" as const,acpSessionId:request.sessionId,capture:{...identity,
      call:{tool_name:hook.tool_name,tool_use_id:hook.tool_use_id,tool_input:hook.tool_input},snapshot} };
  }
  if (hook.hook_event_name !== "PostToolBatch" || !Array.isArray(hook.tool_calls) || hook.tool_calls.length !== 1 ||
    !object(hook.tool_calls[0]) || !opaque(hook.tool_calls[0].tool_use_id) || !opaque(hook.tool_calls[0].tool_name) ||
    !Object.hasOwn(hook.tool_calls[0],"tool_input") || !Object.hasOwn(hook.tool_calls[0],"tool_response") ||
    !Array.isArray(request.toolUseIds) || !isDeepStrictEqual(request.toolUseIds,[hook.tool_calls[0].tool_use_id]) ||
    !object(request.preReceiptDigests) || Object.keys(request.preReceiptDigests).length !== 1 ||
    typeof request.preReceiptDigests[hook.tool_calls[0].tool_use_id] !== "string" ||
    !/^sha256:[a-f0-9]{64}$/.test(request.preReceiptDigests[hook.tool_calls[0].tool_use_id] as string)) throw failure();
  assertNativeBuiltinToolSourceSupported(hook.tool_calls[0].tool_name);
  const snapshot = { ...request.workspaceWitness,phase:"post",toolUseId:hook.tool_calls[0].tool_use_id,toolName:hook.tool_calls[0].tool_name } as unknown as NativeBuiltinWorkspaceSnapshot;
  validateNativeBuiltinWorkspaceSnapshot(snapshot);
  return { phase:"post" as const,acpSessionId:request.sessionId,capture:{...identity,batch:hook as unknown as NativeBuiltinToolBatch,
    snapshot,preReceiptDigests:request.preReceiptDigests as Record<string,string>} };
}


export function nativeBuiltinWorkspaceRootDigest(canonicalRootPath: string) {
  if (typeof canonicalRootPath !== "string" || !path.isAbsolute(canonicalRootPath)) throw failure();
  return `sha256:${createHash("sha256").update(canonicalRootPath,"utf8").digest("hex")}`;
}


export function assertNativeBuiltinToolWorkspaceAccess(call:Omit<NativeBuiltinToolCall,"tool_response">,rootPath:string) {
  assertNativeBuiltinToolSourceSupported(call.tool_name);
  if (!object(call.tool_input) || typeof call.tool_input.file_path !== "string" || call.tool_input.file_path.includes("\0")) throw failure();
  const relative=path.relative(rootPath,path.resolve(rootPath,call.tool_input.file_path));
  if (!relative || relative.startsWith(`..${path.sep}`) || relative === ".." || path.isAbsolute(relative))
    throw new Error("native_builtin_capture_workspace_scope_unsupported");
}
