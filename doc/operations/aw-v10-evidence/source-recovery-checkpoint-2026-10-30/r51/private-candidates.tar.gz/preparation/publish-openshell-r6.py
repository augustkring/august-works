from pathlib import Path
import json,hashlib,shutil,subprocess
root=Path('/workspace/blentera-v10');src=Path('/workspace/v10-preparation/openshell-rt01-repo-integration-candidate-r6');prefix='third_party/openshell/rt01/'
old=json.loads((root/(prefix+'source-pins.json')).read_text());new=json.loads((src/(prefix+'source-pins.json')).read_text())
assert old['patch']['sha256']=='1b964e22688124645ad0b05653c533943724adc2a589dcdb87fe6219f617e227'
assert new['patch']['sha256']=='9181ed297038877322ddb11991f819c4609d25205cf0905b8356447bb48383d5'
assert old['files'].keys()==new['files'].keys()
assert [p for p in old['files'] if old['files'][p]!=new['files'][p]]==['crates/openshell-cli/src/main.rs','crates/openshell-cli/src/run.rs','crates/openshell-driver-docker/src/lib.rs','crates/openshell-driver-docker/src/tests.rs','crates/openshell-sandbox/src/main.rs']
assert hashlib.sha256((src/new['patch']['path']).read_bytes()).hexdigest()==new['patch']['sha256']
assert hashlib.sha256((src/(prefix+'source-pins.json')).read_bytes()).hexdigest()=='536b57feda007eb98c087804f67e16c7efe9751bd0746c49fffb77293bd0403f'
rows=(src/'STAGE-LIST.txt').read_text().splitlines();paths=[r for r in rows if not r.startswith('DELETE ')]
assert len(paths)==len(set(paths))==10
assert not (root/'third_party/openshell/rt01/openshell-rt01-expected-id.patch').exists()
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--',*paths],cwd=root).strip()
for rel in paths:shutil.copy2(src/rel,root/rel)
subprocess.run(['git','diff','--check','--',*paths],cwd=root,check=True);subprocess.run(['git','add','--',*paths],cwd=root,check=True);subprocess.run(['git','commit','-m','build: qualify pinned OpenShell provisioning and bounded runtime probes [skip ci]'],cwd=root,check=True)
