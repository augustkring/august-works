from pathlib import Path
import hashlib,json,difflib
r=Path('/workspace/blentera-v10');base=Path('/workspace/v10-preparation/native-unchecked-task-r67-candidate');out=Path('/workspace/v10-preparation/native-capacity-r70-candidate');rel='server/src/services/native-direct-input.ts';old=(base/rel).read_text();s=old
needle='type Transaction = Parameters<Parameters<Db["transaction"]>[0]>[0];';assert s.count(needle)==1;s=s.replace(needle,needle+'\nconst NATIVE_SOURCE_VALIDATION_WORK_LIMIT = 1024;',1)
needle='  if (++scope.context.ancestry.work > 512) {';assert s.count(needle)==1;s=s.replace(needle,'  if (++scope.context.ancestry.work > NATIVE_SOURCE_VALIDATION_WORK_LIMIT) {',1)
needle='  if (scope.context.ancestry.work > 512) throw';assert s.count(needle)==1;s=s.replace(needle,'  if (scope.context.ancestry.work > NATIVE_SOURCE_VALIDATION_WORK_LIMIT) throw',1)
needle='    finally { scope.context.active = false; }';replacement='''    finally {
      if (scope.context.ancestry.diagnostics && scope.context.parentContext?.ancestry !== scope.context.ancestry)
        console.error("native_source_validation_work_counts", JSON.stringify({ work: scope.context.ancestry.work }));
      scope.context.active = false;
    }''';assert s.count(needle)==1;s=s.replace(needle,replacement,1)
f=out/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s);(out/'r70-only.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
test='server/src/__tests__/native-payload-temporal-sources.integration.test.ts';(out/test).parent.mkdir(parents=True,exist_ok=True);(out/test).write_bytes((base/test).read_bytes())
m={}
for path in [rel,test]:
 a=(r/path).read_bytes();b=(out/path).read_bytes();m[path]={'priorSha256':hashlib.sha256(a).hexdigest(),'candidateSha256':hashlib.sha256(b).hexdigest()};(out/(Path(path).name+'.diff')).write_text(''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+path,tofile='b/'+path)))
(out/'manifest.json').write_text(json.dumps(m,indent=2));(out/'syntax-pins.json').write_text(json.dumps({'qualificationWorkspace':str(out),'copiedFiles':[{'path':path} for path in m]},indent=2))
p=Path('/workspace/v10-preparation');snapshot=(p/'snapshot-private-native-r67.py').read_text().replace('native-unchecked-task-r67-candidate','native-capacity-r70-candidate');(p/'snapshot-private-native-r70.py').write_text(snapshot);runner=(p/'run-private-native-unchecked-r67.sh').read_text().replace('snapshot-private-native-r67.py','snapshot-private-native-r70.py');(p/'run-private-native-capacity-r70.sh').write_text(runner)
print((out/'r70-only.diff').read_text())
