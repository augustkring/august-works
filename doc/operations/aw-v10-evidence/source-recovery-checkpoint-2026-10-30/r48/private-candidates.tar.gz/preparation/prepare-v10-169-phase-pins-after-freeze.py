#!/usr/bin/env python3
"""Create a source-freeze phase-register pin proposal, validate it, and never overwrite the register."""
import argparse, hashlib, json, subprocess
from pathlib import Path

REPO = Path('/workspace/blentera-v10')
DEFAULT = REPO / 'doc/operations/aw-v10-evidence/v10-169-migration-phases-current-2026-10-30/phase-matrix.json'
CHECKER = REPO / 'scripts/check-v10-169-migration-phase-register.mjs'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--freeze-confirmed', action='store_true', help='required acknowledgment that tracked source and named inputs are frozen and committed')
    parser.add_argument('--input', type=Path, default=DEFAULT)
    parser.add_argument('--output', type=Path, default=REPO / 'doc/operations/aw-v10-evidence/v10-169-migration-phases-current-2026-10-30/phase-matrix.freeze-proposed.json')
    args = parser.parse_args()
    if not args.freeze_confirmed:
        parser.error('refusing to refresh pins without --freeze-confirmed')
    # Old, untracked qualification archives are not source inputs. Keep them
    # intact, but reject every tracked edit or untracked non-archive path.
    if git('status', '--porcelain=v1', '--untracked-files=no'):
        raise SystemExit('source freeze requires committed tracked files; no proposal written')
    untracked = subprocess.check_output(
        ['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=REPO,
    ).decode().split('\0')
    untracked = [path for path in untracked if path]
    matrix = json.loads(args.input.read_text())
    named_inputs = {pin['path'] for pin in matrix.get('sourcePins', [])}
    if any(not path.startswith('doc/operations/aw-v10-evidence/') or path in named_inputs for path in untracked):
        raise SystemExit('source freeze has uncommitted source or named inputs; no proposal written')
    head = git('rev-parse', 'HEAD')
    journal_path = REPO / matrix['officialMigrationInterval']['journalSource']
    journal = json.loads(journal_path.read_text())
    latest = journal['entries'][-1]
    if matrix['officialMigrationInterval']['last'] != latest['idx'] or matrix['officialMigrationInterval']['latestOfficialMigration'] != latest['tag']:
        raise SystemExit('migration journal advanced past the reviewed owner/phase matrix; update inventory manually before pin refresh')
    pins = matrix.get('sourcePins', [])
    if not pins:
        raise SystemExit('phase matrix has no sourcePins')
    changes = []
    for pin in pins:
        path = pin.get('path')
        full = REPO / path
        if not path or not full.is_file():
            raise SystemExit(f'missing phase-register source pin at freeze: {path}')
        new_hash = sha(full)
        changes.append({'path': path, 'oldSha256': pin.get('sha256'), 'newSha256': new_hash})
        pin['sha256'] = new_hash
        if 'gitStatusAtCapture' in pin:
            pin['gitStatusAtCapture'] = 'clean at source freeze'
    migration_path = f"packages/db/src/migrations/{latest['tag']}.sql"
    migration_commit = git('log', '-1', '--format=%H', '--', migration_path)
    matrix['officialMigrationInterval']['latestOfficialMigrationCommit'] = migration_commit
    matrix['latestMigrationPublication']['sourceCommit'] = migration_commit
    matrix['latestMigrationPublication']['sourceState'] = f"published source at {migration_commit[:12]}; exact software qualification bundle remains separately pinned"
    matrix['sourcePinFinality'] = f"FINAL source bytes at committed source freeze HEAD {head}; unrelated untracked evidence archives excluded; qualification and external/Human/runtime boundaries remain unchanged."
    matrix['sourcePinBasis'] = 'Exact SHA-256 hashes of committed repository source bytes; unrelated untracked evidence archives are excluded; this pin refresh does not promote a phase, requirement, migration fleet, production rollout or Human/provider gate.'
    matrix['sourceFreeze'] = {'head': head, 'sourceDirty': False, 'repositoryWorkingTreeClean': not untracked, 'excludedUntrackedEvidenceFiles': len(untracked), 'latestMigrationCommit': migration_commit, 'journalLatestTag': latest['tag'], 'pinCount': len(pins)}
    args.output.write_text(json.dumps(matrix, indent=2, ensure_ascii=False) + '\n')
    result = subprocess.run(['node', str(CHECKER), f'--root={REPO}', f'--register={args.output}'], cwd=REPO)
    report = args.output.with_suffix('.pin-report.json')
    report.write_text(json.dumps({'head': head, 'latestMigrationTag': latest['tag'], 'latestMigrationCommit': migration_commit, 'pinCount': len(changes), 'changedPinCount': sum(1 for row in changes if row['oldSha256'] != row['newSha256']), 'changes': changes, 'checkerExit': result.returncode}, indent=2) + '\n')
    print(json.dumps({'proposal': str(args.output), 'pinReport': str(report), 'head': head, 'latestMigration': latest['tag'], 'pins': len(changes), 'changedPins': sum(1 for row in changes if row['oldSha256'] != row['newSha256']), 'checkerExit': result.returncode}, indent=2))
    if result.returncode: raise SystemExit(result.returncode)

if __name__ == '__main__': main()
