from pathlib import Path
import hashlib,json,difflib
r=Path('/workspace/blentera-v10');base=Path('/workspace/v10-preparation/native-plan-jit-r75-candidate');out=Path('/workspace/v10-preparation/native-tool-stage-r76-candidate');rels=list(json.loads((base/'manifest.json').read_text()))
for rel in rels:
 (out/rel).parent.mkdir(parents=True,exist_ok=True);(out/rel).write_bytes((base/rel).read_bytes())
rel='server/src/services/native-runtime/native-session-executor.ts';old=(r/rel).read_text();s=old
needle='    const phaseEnabled = process.env.PAPERCLIP_NATIVE_CONTEXT_PHASE_DIAGNOSTICS === "1";';assert s.count(needle)==1;s=s.replace(needle,'    const phaseEnabled = process.env.PAPERCLIP_NATIVE_CONTEXT_PHASE_DIAGNOSTICS === "1" ||\n      process.env.PAPERCLIP_NATIVE_TOOL_PHASE_DIAGNOSTICS === "1";',1)
needle='  let phaseStarted = process.env.PAPERCLIP_NATIVE_CONTEXT_PHASE_DIAGNOSTICS === "1" ? performance.now() : null;';assert s.count(needle)==1;s=s.replace(needle,'  let phaseStarted = process.env.PAPERCLIP_NATIVE_CONTEXT_PHASE_DIAGNOSTICS === "1" ||\n    process.env.PAPERCLIP_NATIVE_TOOL_PHASE_DIAGNOSTICS === "1" ? performance.now() : null;',1)
(out/rel).parent.mkdir(parents=True,exist_ok=True);(out/rel).write_text(s);(out/'r76-only.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)));rels.append(rel)
m={}
for rel in rels:
 a=(r/rel).read_bytes();b=(out/rel).read_bytes();m[rel]={'priorSha256':hashlib.sha256(a).hexdigest(),'candidateSha256':hashlib.sha256(b).hexdigest()}
(out/'manifest.json').write_text(json.dumps(m,indent=2));(out/'syntax-pins.json').write_text(json.dumps({'qualificationWorkspace':str(out),'copiedFiles':[{'path':rel} for rel in m]},indent=2))
p=Path('/workspace/v10-preparation');snapshot=(p/'snapshot-private-native-r75.py').read_text().replace('native-plan-jit-r75-candidate','native-tool-stage-r76-candidate');(p/'snapshot-private-native-r76.py').write_text(snapshot);runner=(p/'run-private-native-plan-jit-r75-quiet.sh').read_text().replace('snapshot-private-native-r75.py','snapshot-private-native-r76.py');needle='export PAPERCLIP_NATIVE_CONTEXT_PHASE_DIAGNOSTICS=0';assert runner.count(needle)==1;runner=runner.replace(needle,needle+'\nexport PAPERCLIP_NATIVE_TOOL_PHASE_DIAGNOSTICS=1',1);runner=runner.replace('cpu_profile=disabled','tool_stage_clock=1\\ncpu_profile=disabled');(p/'run-private-native-tool-stage-r76.sh').write_text(runner)
print((out/'r76-only.diff').read_text())
