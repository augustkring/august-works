const fs = require('node:fs');
const { createHash } = require('node:crypto');
const [candidate, target, expectedHash] = process.argv.slice(2);
const sha = p => fs.existsSync(p) ? createHash('sha256').update(fs.readFileSync(p)).digest('hex') : 'absent';
(async () => {
  if (!candidate || !target || !/^(?:[a-f0-9]{64}|absent)$/.test(expectedHash ?? ''))
    throw new Error('Usage: publish-parsed-source.cjs candidate target expected-prior-sha256-or-absent');
  const { transformWithOxc } = await import(require.resolve('vite', { paths: [fs.realpathSync('/workspace/v10-dep-qualification/node_modules/vitest')] }));
  await transformWithOxc(fs.readFileSync(candidate, 'utf8'), target, { target: 'esnext' });
  if (sha(target) !== expectedHash) throw new Error('Target changed since the edit began; rebase the candidate before publication.');
  if (fs.existsSync(target)) fs.chmodSync(candidate, fs.statSync(target).mode & 0o777);
  fs.renameSync(candidate, target);
  console.log(JSON.stringify({ target, sha256: sha(target), parser: 'Vitest Vite/Oxc', published: true }));
})().catch(error => { console.error(error.message); process.exitCode = 1; });
