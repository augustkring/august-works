import fcntl,hashlib,json,os,pathlib,subprocess,time
O=pathlib.Path('/workspace/v10-preparation/combined-b1-final-metadata-20261103'); W=pathlib.Path('/tmp/combined-b1-final-metadata-20261103/worktree');P=json.loads((O/'preparation-proof.json').read_text());env={**os.environ,**P['alternateGitEnvironment'],'NODE_OPTIONS':'--max-old-space-size=128'};Q=O/'qualification-final-count';Q.mkdir(exist_ok=True);node='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node';lock=open('/workspace/v10-preparation/v10-pg-tests.lock','a');start=time.monotonic()
while True:
 try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);break
 except BlockingIOError:
  if time.monotonic()-start>60:raise RuntimeError('flock timeout')
  time.sleep(.1)
assert os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize//1024>=120000
before={p:hashlib.sha256((W/p).read_bytes()).hexdigest() for p in json.loads((O/'final-stage-paths.json').read_text())}; events=pathlib.Path('/sys/fs/cgroup/memory.events').read_text();results=[]
for name,script in [('generate-safe-change','scripts/generate-v10-safe-change-graph.mjs'),('safe-change-check','scripts/check-v10-safe-change-graph.mjs')]:
 with (Q/(name+'.log')).open('wb') as f:r=subprocess.run([node,'--max-old-space-size=128',script],cwd=W,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=60)
 (Q/(name+'.exit')).write_text(str(r.returncode)+'\n');results.append({'name':name,'actualExitCode':r.returncode});assert r.returncode==0
assert pathlib.Path('/sys/fs/cgroup/memory.events').read_text()==events
after={p:hashlib.sha256((W/p).read_bytes()).hexdigest() for p in before};delta=[p for p in before if before[p]!=after[p]];assert delta==['doc/operations/v10-safe-change-graph.json'],delta
(Q/'receipt.json').write_text(json.dumps({'scope':'Documentation-only fullDiffPathCount 13838->13842; material paths1939 unchanged. Original generator and checker only.','results':results,'beforePins':before,'afterPins':after,'changedGeneratedPaths':delta,'memoryEventsUnchanged':True},indent=2)+'\n');print('actual2/2PASS')
