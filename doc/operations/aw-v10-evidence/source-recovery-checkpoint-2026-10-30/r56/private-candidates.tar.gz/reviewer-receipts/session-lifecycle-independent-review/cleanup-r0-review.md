# Cleanup purpose r0 independent review

**P1 CL-01 — v2 producer is rejected by v1 parser.** `server/src/services/runtime/control.ts:2662–2666` still requires exactly 13 fields and schema v1; the new producer supplies 16 fields and schema v2. The first use at :2722 therefore fails before erasure dispatch. Update the strict field/schema/profile checks together. Sent SourceOwner and root.

The purpose-limited job/target/deadline checks and all eight fresh capability observations remain present. Nine local probes do not renew old business qualification. Nonzero workload UID, root-owned Node ancestry, clean environment and built-in Node module use support the intended fixed-local profile.

Unconfirmed follow-ups: trusted-image coverage for every PATH executable/library; existing pathname-walk race if a same-UID writer can execute after fresh force_stop. These are not counted as new confirmed r0 bugs. See JSON for exact scope and assumptions.

Patch SHA-256: `f642279ffb7dd1c19e8273a201977e8e3e185bc7f09c272e92419ae41b6ed951`. No source edits, tests, database changes, or network calls.
