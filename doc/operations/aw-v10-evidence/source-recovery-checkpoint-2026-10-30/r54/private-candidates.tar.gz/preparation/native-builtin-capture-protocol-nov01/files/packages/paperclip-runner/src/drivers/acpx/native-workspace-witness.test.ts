import { mkdtemp, mkdir, rm, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";

import { afterEach, describe, expect, it } from "vitest";

import { captureNativeWorkspaceWitness } from "./native-workspace-witness.js";

const roots: string[] = [];

afterEach(async () => {
  await Promise.all(roots.splice(0).map((root) => rm(root, { recursive: true, force: true })));
});

async function workspace(): Promise<string> {
  const root = await mkdtemp(path.join(tmpdir(), "native-workspace-witness-"));
  roots.push(root);
  return root;
}

describe("captureNativeWorkspaceWitness", () => {
  it("binds stable root identity and changing full-tree content snapshots", async () => {
    const root = await workspace();
    await mkdir(path.join(root, "src"));
    await writeFile(path.join(root, "src", "input.ts"), "before\n");

    const before = await captureNativeWorkspaceWitness({ trustedRoot: root, toolName: "Read", toolInput: {} });
    await writeFile(path.join(root, "src", "input.ts"), "after\n");
    const after = await captureNativeWorkspaceWitness({ trustedRoot: root, toolName: "Write", toolInput: {} });

    expect(before.workspaceRootDigest).toBe(after.workspaceRootDigest);
    expect(before.snapshotDigest).not.toBe(after.snapshotDigest);
    expect(before.files).toHaveLength(1);
    expect(Buffer.from(before.files[0]!.contentBase64!, "base64").toString()).toBe("before\n");
    expect(Buffer.from(after.files[0]!.contentBase64!, "base64").toString()).toBe("after\n");
  });

  it("rejects symlinks rather than following workspace paths", async () => {
    const root = await workspace();
    const external = await workspace();
    await writeFile(path.join(external, "outside.txt"), "outside\n");
    await symlink(external, path.join(root, "linked"));

    await expect(captureNativeWorkspaceWitness({ trustedRoot: root, toolName: "Bash", toolInput: {} }))
      .rejects.toThrow("native_workspace_symlink_rejected");
  });

  it("rejects snapshots above the authenticated-frame witness bound", async () => {
    const root = await workspace();
    await writeFile(path.join(root, "large.txt"), Buffer.alloc(4 * 1024 + 1, 0x61));

    await expect(captureNativeWorkspaceWitness({ trustedRoot: root, toolName: "Bash", toolInput: {} }))
      .rejects.toThrow("native_workspace_witness_byte_limit");
  });
});
