from pathlib import Path
p=Path('/workspace/blentera-v10/server/src/services/native-direct-input.ts');s=p.read_text()
# Capture-node memo had zero hits in the actual bounded profile. Remove it.
a=s.index('  const captureVisitKey =');b=s.index('  for (const memoryId',a)
s=s[:a]+'''  await assertNativeManagedConsumedSourceSetCurrentInScope(db, { companyId, issueId, runId: capture.runId,
    actor, components: capture.consumedSourceComponents, sourceSet: capture.sourceSet }, scope, siblingToolSourceProofs);
'''+s[b:]
a=s.index('  captureCompleted = true;');b=s.index('\n}\n\n/** Revalidate a driver',a);s=s[:a]+s[b:]
s=s.replace(' documentNodeHits: 0, captureNodeHits: 0,',' documentNodeHits: 0,').replace('  nativeSourceMemoDiagnostics.captureNodeHits = 0;\n','').replace(', captureHits: nativeSourceMemoDiagnostics.captureNodeHits','')
# Shared helper stores exact original full prefixes, never a sliced union.
a=s.index('function nativeGraphProofInputsEligible(')
s=s[:a]+'''async function withNativeSourceGraphProof(scope: NativeSourceReadScope, proofs: NativeSiblingToolSourceProofs,
  key: string, input: { companyId: string; runId: string; actor: AuthorizationActor;
    policy: NativePayloadSourcePolicy; inputs: NativePayloadSourceInput[] }, read: () => Promise<void>): Promise<void> {
  if (scope.active.has(key)) throw forbidden("The Native source graph contains a cycle");
  const eligible = nativeGraphProofInputsEligible(input.policy, input.inputs);
  const proof = eligible ? proofs.get(key) : undefined;
  let stack = scope.context.ancestry.frozenTaskProofStacks.get(scope.actorKey);
  if (!stack) {
    stack = [];
    scope.context.ancestry.frozenTaskProofStacks.set(scope.actorKey, stack);
  }
  if (proof && !nativeFrozenTaskMemoWouldIntersectActiveAncestry(scope.active, proof.descendants)) {
    nativeSourceReadWork(scope);
    deferNativeSourceReaderCheck(scope, input);
    for (const parent of stack) addNativeFrozenTaskDescendantClosure(parent.descendants, key, proof.descendants);
    return;
  }
  addNativeSourceActiveVisit(scope, key);
  const frame = { visitKey: key, descendants: new Set<string>() };
  stack.push(frame);
  let completed = false;
  try {
    await read();
    completed = true;
  } finally {
    scope.active.delete(key);
    if (stack.at(-1) === frame) stack.pop();
    if (completed) {
      if (eligible && proofs.size < 512)
        proofs.set(key, { descendants: frame.descendants, policy: input.policy, inputs: input.inputs });
      for (const parent of stack) addNativeFrozenTaskDescendantClosure(parent.descendants, key, frame.descendants);
    }
  }
}
'''+s[a:]
# Source-set wrapper gets one invocation-local map if called by a public source-set API.
a=s.index('async function assertNativePayloadSourceSetCurrentInScope(');b=s.index('\n}\n',a);chunk=s[a:b]
chunk=chunk.replace('siblingToolSourceProofs?: NativeSiblingToolSourceProofs','siblingToolSourceProofs: NativeSiblingToolSourceProofs = new Map()')
chunk=chunk.replace('runId: input.runId, actor: input.actor, policy: policy.data, inputs: inputs.data })}`;','runId: input.runId, actor: input.actor, actorScope: scope.actorKey, memoryTemporalIdentity: scope.context.memoryTemporalIdentity,\n    policy: policy.data, inputs: inputs.data })}`;')
a2=chunk.index('  if (scope.active.has(completeKey))');chunk=chunk[:a2]+'''  return withNativeSourceGraphProof(scope, siblingToolSourceProofs, completeKey, {
    companyId: input.companyId, runId: input.runId, actor: input.actor, policy: policy.data, inputs: inputs.data,
  }, async () => {
    await assertNativePayloadSourceSetCurrentUncachedInScope(db, {
      ...input, policy: policy.data, inputs: inputs.data,
    }, scope, true, completedTaskSourceProofs, validatedDispatchSources, siblingToolSourceProofs);
    deferNativeSourceReaderCheck(scope, { companyId: input.companyId, runId: input.runId, actor: input.actor,
      policy: policy.data, inputs: inputs.data });
  });'''
s=s[:a]+chunk+s[b:]
# Consumed prefix wrapper: full actor and exact ordered full components remain its identity.
a=s.index('async function assertNativeManagedConsumedSourceSetCurrentInScope(');b=s.index('\n}\n',a);chunk=s[a:b]
a2=chunk.index('  const actorBinding =');b2=chunk.index('  const visitKey =',a2);chunk=chunk[:a2]+chunk[b2:]
chunk=chunk.replace('actor: actorBinding, components:', 'actor: input.actor, actorScope: scope.actorKey, memoryTemporalIdentity: scope.context.memoryTemporalIdentity, components:')
a2=chunk.index('  if (scope.active.has(visitKey))');chunk=chunk[:a2]+'''  return withNativeSourceGraphProof(scope, siblingToolSourceProofs, visitKey, {
    companyId: input.companyId, runId: input.runId, actor: input.actor,
    policy: input.sourceSet.policy, inputs: input.sourceSet.inputs,
  }, () => assertNativeManagedConsumedSourceSetCurrentUncached(db, input, scope, siblingToolSourceProofs));'''
s=s[:a]+chunk+s[b:];p.with_suffix('.prefixnode.tmp.ts').write_text(s)
p=Path('/workspace/blentera-v10/server/src/__tests__/native-payload-temporal-sources.integration.test.ts');t=p.read_text().replace('    expect(nativeSourceMemoDiagnosticsForTest().captureNodeHits).toBeGreaterThan(0);\n','');p.with_suffix('.prefixnode.tmp.ts').write_text(t)
