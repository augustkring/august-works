#!/usr/bin/env bash
set -uo pipefail
NAME=native-selection-lock-order-20261026-r2
OUT=/workspace/v10-preparation
ROOT=/workspace/v10-dep-qualification
cd /workspace/blentera-v10
python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$OUT/$NAME-source-pins.json" > "$OUT/$NAME-snapshot.log" 2>&1
rc=$?
printf '%s\n' "$rc" > "$OUT/$NAME-snapshot.exit"
if [ "$rc" -ne 0 ]; then printf '%s\n' "$rc" > "$OUT/$NAME.exit"; exit "$rc"; fi
node /workspace/v10-preparation/check-snapshot-syntax.cjs "$OUT/$NAME-source-pins.json" > "$OUT/$NAME-syntax.log" 2>&1
rc=$?
printf '%s\n' "$rc" > "$OUT/$NAME-syntax.exit"
if [ "$rc" -ne 0 ]; then printf '%s\n' "$rc" > "$OUT/$NAME.exit"; exit "$rc"; fi
cd "$ROOT/server"
timeout --signal=TERM --kill-after=5s 120s ../node_modules/.bin/vitest run src/__tests__/heartbeat-process-recovery.test.ts -t 'locks the issue before the run during native runtime selection|fences native selection when cancellation wins during preparation|does not dispatch when cancellation wins after native selection' --maxWorkers=1 > "$OUT/$NAME-test.log" 2>&1
rc=$?
printf '%s\n' "$rc" > "$OUT/$NAME-test.exit"
printf '%s\n' "$rc" > "$OUT/$NAME.exit"
exit "$rc"
