/** PRIVATE 0565 PostgreSQL acceptance tests. Copy beside the source only after
 * the complete migration is serialized; these tests create isolated fixture
 * tables only in their disposable embedded PostgreSQL database. */
import { randomUUID } from "node:crypto";
import { sql } from "drizzle-orm";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { companies, createDb, EMBEDDED_POSTGRES_TEST_TIMEOUT_MS } from "@paperclipai/db";
import { startEmbeddedPostgresTestDatabase } from "./helpers/embedded-postgres.js";
import { RESPONSIBILITY_SCAN_KINDS, runResponsibilityScanOnce, type NativeResponsibilityMetadataSource } from "../services/experience/private-0565/responsibility-scan.js";
import { enqueueResponsibilityScan, postgresResponsibilityScanStore, readResponsibilityPointersForResolution } from "../services/experience/private-0565/responsibility-scan-store.js";
import { readAuthorizedResponsibilitySubset, type NativeResponsibilityReader } from "../services/experience/private-0565/authorized-subset-reader.js";
import { bindNativeResponsibilityReaders } from "../services/experience/private-0565/native-reader-ports.js";
import { nativeResponsibilityMetadataSources } from "../services/experience/private-0565/native-metadata-sources.js";
import { agents } from "@paperclipai/db";

describe("PRIVATE 0565 responsibility scan store", () => {
  let database: Awaited<ReturnType<typeof startEmbeddedPostgresTestDatabase>>;
  let db: ReturnType<typeof createDb>;
  beforeAll(async () => {
    database = await startEmbeddedPostgresTestDatabase("responsibility-scan-0565-");
    db = createDb(database.connectionString, { maxConnections: 4 });
    await db.execute(sql`create table if not exists responsibility_scan_runs (
      id uuid primary key default gen_random_uuid(), company_id uuid not null references companies(id) on delete cascade,
      contract_version integer not null default 1, status text not null default 'queued', cursor_json jsonb not null default '{}'::jsonb,
      requested_at timestamptz not null default now(), next_attempt_at timestamptz not null default now(), lease_owner text,
      lease_token uuid, lease_expires_at timestamptz, attempt_count integer not null default 0, last_error_code text,
      started_at timestamptz, completed_at timestamptz, expires_at timestamptz not null,
      created_at timestamptz not null default now(), updated_at timestamptz not null default now())`);
    await db.execute(sql`create unique index if not exists responsibility_scan_runs_one_active_per_company
      on responsibility_scan_runs(company_id) where status in ('queued','running','failed')`);
    await db.execute(sql`create table if not exists responsibility_scan_candidates (
      id uuid primary key default gen_random_uuid(), company_id uuid not null references companies(id) on delete cascade,
      scan_run_id uuid not null references responsibility_scan_runs(id) on delete cascade, resource_kind text not null,
      resource_id text not null, source_version text not null, observed_at timestamptz not null default now(), expires_at timestamptz not null,
      unique(scan_run_id,resource_kind,resource_id))`);
  }, EMBEDDED_POSTGRES_TEST_TIMEOUT_MS);
  afterAll(async () => { await database?.cleanup(); }, 30_000);

  async function company() {
    const id = randomUUID();
    await db.insert(companies).values({ id, name: "0565 scan fixture", issuePrefix: `RS${id.slice(0, 6)}` });
    return id;
  }
  const emptySources = (agentPage?: NativeResponsibilityMetadataSource): NativeResponsibilityMetadataSource[] => RESPONSIBILITY_SCAN_KINDS.map(kind =>
    kind === "agent" && agentPage ? agentPage : { kind, async readPage() { return { pointers: [], nextCursor: null, complete: true }; } });

  it("persists bounded keyset progress and resumes rather than truncating a kind", async () => {
    const companyId = await company(), now = new Date(), store = postgresResponsibilityScanStore(db);
    await enqueueResponsibilityScan(db, companyId, now);
    const firstId = randomUUID(), secondId = randomUUID();
    let pages = 0;
    const agentSource: NativeResponsibilityMetadataSource = { kind: "agent", async readPage(_company, after, limit) {
      expect(limit).toBe(40); pages++;
      if (after === null) return { pointers: [{ kind: "agent", id: firstId, sourceVersion: "a".repeat(64) }], nextCursor: firstId, complete: false };
      return { pointers: [{ kind: "agent", id: secondId, sourceVersion: "b".repeat(64) }], nextCursor: null, complete: true };
    } };
    const sources = emptySources(agentSource);
    expect(await runResponsibilityScanOnce({ store, sources, worker: "worker-a", now: () => now })).toBe("progressed");
    const lease = await store.claimDue({ worker: "inspector", now, leaseMs: 30_000, cursorTtlMs: 86_400_000 });
    expect(lease?.cursor.agent).toEqual({ after: firstId, complete: false });
    await store.releaseForNextPage({ runId: lease!.runId, owner: lease!.owner, token: lease!.token, now });
    // Continue with the regular one-page worker and confirm both pointers survive
    // the cursor boundary without a caller-visible hasMore/overflow signal.
    for (let i = 0; i < 15; i++) await runResponsibilityScanOnce({ store, sources, worker: `worker-${i}`, now: () => now });
    expect(pages).toBe(2);
    const pointers = await readResponsibilityPointersForResolution(db, companyId, now);
    expect(pointers.map(item => item.resource_id)).toEqual(expect.arrayContaining([firstId, secondId]));
  });

  it("fences an expired worker lease and lets only the new token commit", async () => {
    const companyId = await company(), now = new Date(), store = postgresResponsibilityScanStore(db);
    await enqueueResponsibilityScan(db, companyId, now);
    const old = await store.claimDue({ worker: "old", now, leaseMs: 30_000, cursorTtlMs: 86_400_000 });
    const later = new Date(now.getTime() + 31_000);
    const current = await store.claimDue({ worker: "new", now: later, leaseMs: 30_000, cursorTtlMs: 86_400_000 });
    expect(old?.token).toBeTruthy();
    expect(current?.token).not.toBe(old?.token);
    const staleCommit = await store.commitPage({ runId: old!.runId, companyId, owner: old!.owner, token: old!.token,
      now: later, kind: "agent", pointers: [], nextCursor: null, complete: true,
      pointerExpiresAt: new Date(later.getTime() + 1_800_000), cursorExpiresAt: new Date(later.getTime() + 86_400_000) });
    expect(staleCommit).toBe(false);
  });

  it("expires candidate pointers without changing the native source or returning stale identities", async () => {
    const companyId = await company(), now = new Date(), store = postgresResponsibilityScanStore(db);
    await enqueueResponsibilityScan(db, companyId, now);
    const id = randomUUID();
    const sources = emptySources({ kind: "agent", async readPage() {
      return { pointers: [{ kind: "agent", id, sourceVersion: "c".repeat(64) }], nextCursor: null, complete: true };
    } });
    for (let i = 0; i < RESPONSIBILITY_SCAN_KINDS.length; i++)
      await runResponsibilityScanOnce({ store, sources, worker: `worker-${i}`, now: () => now });
    expect((await readResponsibilityPointersForResolution(db, companyId, now)).map(item => item.resource_id)).toContain(id);
    const expired = new Date(now.getTime() + 1_800_001);
    expect(await readResponsibilityPointersForResolution(db, companyId, expired)).toEqual([]);
    // This table is only a candidate cache; no native agent/resource row exists
    // and expiry did not create, delete, or transfer any source record.
    const [count] = await db.execute<{ count: string }>(sql`select count(*)::text as count from agents where company_id=${companyId}::uuid`);
    expect(Number(count?.count ?? 0)).toBe(0);
  });
  it("produces zero output for private pointers and recomputes effective owner coverage after revocation", async () => {
    const companyId = await company(), now = new Date(), store = postgresResponsibilityScanStore(db);
    await enqueueResponsibilityScan(db, companyId, now);
    const agentId = randomUUID(), privateWorkflowId = randomUUID();
    const sources = emptySources({ kind: "agent", async readPage(_company, after) {
      if (after === null) return { pointers: [{ kind: "agent", id: agentId, sourceVersion: "d".repeat(64) }], nextCursor: null, complete: true };
      return { pointers: [], nextCursor: null, complete: true };
    } });
    // Also persist a private workflow pointer through its own native metadata page.
    sources.find(source => source.kind === "workflow")!.readPage = async () => ({
      pointers: [{ kind: "workflow", id: privateWorkflowId, sourceVersion: "e".repeat(64) }], nextCursor: null, complete: true,
    });
    for (let i = 0; i < RESPONSIBILITY_SCAN_KINDS.length; i++)
      await runResponsibilityScanOnce({ store, sources, worker: `worker-${i}`, now: () => now });
    let ownerStillAuthorized = true;
    const nativeReaders: NativeResponsibilityReader[] = RESPONSIBILITY_SCAN_KINDS.map(kind => ({
      kind, title: kind, href: "/native-owner",
      async inspectCurrent(_actor, _company, resourceId) {
        if (resourceId === privateWorkflowId) return { state: "hidden" };
        return { state: "visible", currentSourceVersion: "d".repeat(64), coveredByAuthorizedHumanOrNativeGroup: ownerStillAuthorized };
      },
    }));
    const input = { db, actor: { type: "board" as const, source: "session" as const, userId: "viewer" }, companyId,
      signal: new AbortController().signal, mayReviewCompanyResponsibility: async () => true, nativeReaders, now: () => now };
    const beforeRevocation = await readAuthorizedResponsibilitySubset(input);
    expect(beforeRevocation.needsYou).toEqual([]);
    expect(JSON.stringify(beforeRevocation)).not.toContain(privateWorkflowId);
    expect(JSON.stringify(beforeRevocation)).not.toContain(agentId);
    ownerStillAuthorized = false;
    const afterRevocation = await readAuthorizedResponsibilitySubset(input);
    expect(afterRevocation.needsYou.map(card => card.source.resourceId)).toEqual(["agent"]);
    expect(JSON.stringify(afterRevocation)).not.toContain(privateWorkflowId);
    expect(JSON.stringify(afterRevocation)).not.toContain(agentId);
    expect(JSON.stringify(afterRevocation)).not.toContain("viewer");
    expect(afterRevocation.coverage).toBe("currently_authorized_subset");
  });

  it("requires native read ports for every applicable §17 kind", () => {
    const ports = Object.fromEntries(RESPONSIBILITY_SCAN_KINDS.map(kind => [kind, async () => ({ state: "hidden" as const })]));
    const bound = bindNativeResponsibilityReaders(ports as Parameters<typeof bindNativeResponsibilityReaders>[0]);
    expect(bound.map(reader => reader.kind).sort()).toEqual([...RESPONSIBILITY_SCAN_KINDS].sort());
    expect(new Set(bound.map(reader => reader.kind)).size).toBe(RESPONSIBILITY_SCAN_KINDS.length);
  });

  it("scans native agent metadata in stable 40-row pages without selecting content fields", async () => {
    const companyId = await company();
    const fixture = Array.from({ length: 41 }, (_, index) => ({ companyId, name: `private metadata agent ${index}`, role: "general", status: "idle" }));
    const created = await db.insert(agents).values(fixture).returning({ id: agents.id });
    const source = nativeResponsibilityMetadataSources(db).find(item => item.kind === "agent")!;
    const first = await source.readPage(companyId, null, 40);
    expect(first.pointers).toHaveLength(40);
    expect(first.complete).toBe(false);
    expect(first.nextCursor).toBe(first.pointers.at(-1)?.id);
    const second = await source.readPage(companyId, first.nextCursor, 40);
    expect(second.pointers).toHaveLength(1);
    expect(second.complete).toBe(true);
    expect(second.nextCursor).toBeNull();
    expect([...first.pointers, ...second.pointers].map(pointer => pointer.id).sort())
      .toEqual(created.map(row => row.id).sort());
    expect(JSON.stringify([...first.pointers, ...second.pointers])).not.toContain("private metadata agent");
  });

});
