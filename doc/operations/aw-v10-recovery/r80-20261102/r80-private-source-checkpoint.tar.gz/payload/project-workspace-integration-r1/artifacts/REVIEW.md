# One real managed Project scheduler case — private source only

Main EAD exact parents are pinned. New case: `server/src/__tests__/heartbeat-managed-project-workspace.integration.test.ts`, explicit owner **Native Runtime** (final R12 membership update required before publication; no metadata activation here).

This reuses `withManagedNativeHeartbeatFixture` and the reviewed source-only Project R3 preparation hooks. It does not duplicate the TLS/provider/Host setup and does not change the existing ordinary no-Project case. The real Human Project route, issueService, Plan quote/start and wakeup create every owned domain object; no Run/Attempt/ExecutionWorkspace rows or adapter effects are seeded.

The actual provider reply follows the existing ordinary case: write_document with required null baseRevisionId, then paperclip_finish using the actual current contract. It makes no filesystem, Task-status or output-capture edits. Before each real reply, the test checks the actual persisted Native input, source receipt, worktree, original active lease and compiled policy; after settlement it requires accepted result/assessment/applied done decision, a real result document and canonical cleanup/Stop. The base repository main branch and original main SHA must remain unchanged.

This is one fresh local Git worktree baseline. It neither replaces the three mocked finalize-branch behavioral checks nor migrates all thirteen repository cases. Managed Project-create output and Project-wait tests remain distinct. Sourceowner socket producer changes the same Host helper privately; keep the R3 dependency and any future producer merge explicit and pinned, with no whole stale-helper copy.

Validation: git apply --check PASS only. No semantic compiler, unit, DB, SDK, browser or acceptance evidence. Root review and execution/resource/CI gates remain required. The actual guarded runner must reuse existing failure-preservation/owned-service closure and exact-source/output restoration owners when execution is later authorized.
