import subprocess,hashlib,shutil,json,sys
from pathlib import Path
src=Path('/workspace/blentera-v10'); dst=Path('/workspace/v10-dep-qualification')
# Never qualify new source/lock bytes against an older partially installed tree.
import re
assert (src/'pnpm-lock.yaml').read_bytes()==(dst/'pnpm-lock.yaml').read_bytes(), 'Install the current frozen lock before source qualification'
locked_dependency_pins=[]
lock_text=(src/'pnpm-lock.yaml').read_text()
for package_name in ('sso','scim'):
 pattern=r"^  ['\"]?@better-auth/"+package_name+r"@1\.7\.7['\"]?:\n    hash: ([a-z0-9]+)$"
 match=re.search(pattern,lock_text,re.M)
 assert match, 'Missing locked Better Auth patch fingerprint: '+package_name
 import base64
 patch_bytes=(src/('patches/@better-auth__'+package_name+'@1.7.7.patch')).read_bytes()
 # pnpm9 encodes its patch-file MD5 in base32; this is lock consistency,
 # while the receipt separately records SHA-256 source/module evidence.
 source_patch_hash=base64.b32encode(hashlib.md5(patch_bytes).digest()).decode().lower().rstrip('=')
 assert source_patch_hash==match[1], 'Regenerate and install the current patch lock before qualification: '+package_name
 package=dst/'server/node_modules/@better-auth'/package_name
 assert 'patch_hash='+match[1]+'_' in str(package.resolve()), 'Installed Better Auth patch differs from current lock: '+package_name
 metadata=json.loads((package/'package.json').read_text())
 assert metadata['version']=='1.7.7', 'Unexpected Better Auth version'
 locked_dependency_pins.append({'package':'@better-auth/'+package_name,'version':metadata['version'],
   'patchHash':match[1],'moduleSha256':hashlib.sha256((package/'dist/index.mjs').read_bytes()).hexdigest()})
installed_opencode=dst/'node_modules/.pnpm/opencode-ai@1.18.32/node_modules/opencode-ai/bin/opencode.exe'
with installed_opencode.open('rb') as binary_stream:
 assert hashlib.file_digest(binary_stream,'sha256').hexdigest()=='513f500a1a5ea1dc7d865547ac87b32a8936334e8d5abd5b3ff585c45a170080', 'Restore the pinned OpenCode postinstall executable'
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=dst,text=True).strip()
names=subprocess.check_output(['git','diff','--name-only',base,'-z'],cwd=src).decode().split('\0')
names+=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=src).decode().split('\0')
# Restore tracked qualification-only edits too: a reverted main-tree file
# must not leave old diagnostics or fixture authority in later snapshots.
names+=subprocess.check_output(['git','diff','--name-only','-z'],cwd=dst).decode().split('\0')
# Regeneration can rename a not-yet-committed migration. Retain the abandoned
# qualification copy for diagnosis, but never execute it in a fresh snapshot.
orphans=[]
for name in subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z','--','packages/db/src/migrations'],cwd=dst).decode().split('\0'):
 if not name or (src/name).exists(): continue
 b=dst/name
 if not b.is_file() or b.suffix not in ('.sql','.json'): continue
 data=b.read_bytes(); h=hashlib.sha256(data).hexdigest()
 archive=Path('/workspace/v10-preparation/orphan-qualification-migrations')/h/name
 archive.parent.mkdir(parents=True,exist_ok=True); archive.write_bytes(data)
 assert hashlib.sha256(archive.read_bytes()).hexdigest()==h
 b.unlink(); orphans.append({'path':name,'sha256':h,'preservedAt':str(archive)})
# Operational contracts are live inputs to Node gates, not archived evidence.
# Keep their exact bytes in the qualified workspace and reconstruction patch.
contract_paths={str(path.relative_to(src)) for path in (src/'doc/operations').glob('*.json') if path.is_file()}
contract_paths.update({
 'doc/operations/aw-v10-evidence/recovery-2026-10-22/requirement-reconciliation.json',
 'doc/operations/aw-v10-evidence/v10-169-migration-phases-current-2026-10-30/phase-matrix.json',
})
names += sorted(contract_paths)
rows=[]
for name in sorted(set(names)):
 if not name or (name.startswith('doc/operations/') and name not in contract_paths): continue
 a=src/name;b=dst/name
 if not a.is_file():
  if b.is_file(): b.unlink();rows.append({'path':name,'deleted':True})
  continue
 b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(a,b)
 h=hashlib.sha256(a.read_bytes()).hexdigest();assert h==hashlib.sha256(b.read_bytes()).hexdigest(),name
 rows.append({'path':name,'sha256':h})
# Private R67 qualification overlay. MAIN remains unchanged; reconstruction
# patch and copied-file receipt below include the exact candidate bytes.
candidate=Path('/workspace/v10-preparation/native-grouped-reader-profile-r103-candidate')
for relative,pin in json.loads((candidate/'manifest.json').read_text()).items():
 assert (hashlib.sha256((src/relative).read_bytes()).hexdigest() if (src/relative).exists() else None)==pin['priorSha256'], ('MAIN source changed',relative)
 data=(candidate/relative).read_bytes()
 assert hashlib.sha256(data).hexdigest()==pin['candidateSha256'], ('Candidate changed',relative)
 (dst/relative).write_bytes(data)
 rows=[row for row in rows if row['path']!=relative]
 rows.append({'path':relative,'sha256':pin['candidateSha256'],'privateCandidateBaseSha256':pin['priorSha256']})
source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip()
receipt_path=Path(sys.argv[1])
# Keep the small difference from the committed source head, rather than another
# full source tarball. Later edits and reuse of the qualification workspace must
# not make a recorded stack-frame line or uncommitted test source unrecoverable.
patch_path=receipt_path.with_suffix('.source.patch')
# The mirror's real index belongs to an older base. Compare using a disposable
# index at source_head so newly committed source is not falsely shown deleted.
import os,tempfile
index_fd,index_name=tempfile.mkstemp(prefix='qualification-source-index-',dir='/workspace/v10-preparation')
os.close(index_fd); os.unlink(index_name)
index_env={**os.environ,'GIT_INDEX_FILE':index_name}
try:
 subprocess.run(['git','read-tree',source_head],cwd=dst,env=index_env,check=True)
 patch_bytes=subprocess.check_output(['git','diff','--binary','--no-ext-diff','--no-textconv',source_head,'--','.',':(exclude)doc/operations/'],cwd=dst,env=index_env)
 patch_bytes+=subprocess.check_output(['git','diff','--binary','--no-ext-diff','--no-textconv',source_head,'--',*sorted(contract_paths)],cwd=dst,env=index_env)
finally:
 Path(index_name).unlink(missing_ok=True)

patch_path.write_bytes(patch_bytes)
tracked=set(subprocess.check_output(['git','ls-tree','-r','--name-only',source_head],cwd=dst,text=True).splitlines())
source_files=[]
for row in rows:
 name=row['path']
 if row.get('deleted') or name in tracked: continue
 a=dst/name
 if not a.is_file(): continue
 preserved=receipt_path.with_suffix('.source-files')/name
 preserved.parent.mkdir(parents=True,exist_ok=True)
 shutil.copy2(a,preserved)
 assert hashlib.sha256(preserved.read_bytes()).hexdigest()==row['sha256'],name
 source_files.append({'path':name,'preservedAt':str(preserved),'sha256':row['sha256']})
receipt_path.write_text(json.dumps({'sourceReconstructionFormat':'temporary-source-head-index-v2','qualificationBaseCommit':base,'sourceHead':source_head,'qualificationWorkspace':str(dst),'copiedFiles':rows,'includedOperationalContractPaths':sorted(contract_paths),'lockedDependencyPins':locked_dependency_pins,'orphanQualificationMigrations':orphans,'sourceHeadDiffPatch':{'path':str(patch_path),'sha256':hashlib.sha256(patch_bytes).hexdigest()},'untrackedSourceFiles':source_files,'limits':'Current copied source at qualification start; later main-tree edits excluded. Reconstruct exact uncommitted source from sourceHead plus sourceHeadDiffPatch and untrackedSourceFiles. Locked dependencies are qualified separately.'},indent=2)+'\n')
print('Copied and verified source files',len(rows))
