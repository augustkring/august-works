import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdtempSync,rmSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createRequire} from 'node:module';
import {createHash,randomUUID} from 'node:crypto';
import {tmpdir} from 'node:os';import {join,posix} from 'node:path';import vm from 'node:vm';
import {runtimeSandboxExecRelayRequestSchema} from '/workspace/v10-dep-qualification/packages/shared/dist/runtime-relay-contracts.js';
const req=createRequire('/workspace/v10-dep-qualification/package.json');const {transformSync}=req('esbuild');
const root='/workspace/v10-preparation/native-sandbox-artifact-staging-r115';
const source=readFileSync(root+'/files/server/src/services/native-runtime/native-session-executor.ts','utf8');
const owner=readFileSync('/workspace/v10-preparation/v10-149-r14.38.4.67-worker-zod-diagnostic-output-private/files/server/src/services/runtime/control.ts','utf8');
const file=source.slice(source.indexOf('export async function stageRemoteRunnerFile('),source.indexOf('function archiveExcludeArgs('));
const chunks=source.slice(source.indexOf('async function stageRemoteArtifactBytesInChunks('),source.indexOf('export async function remoteRunnerPathExists('));
const checker=owner.slice(owner.indexOf('function exactNativeProviderArtifactChunkCommand('),owner.indexOf('export function runtimeControlService('));
const script=transformSync(file+chunks+checker+'\nglobalThis.check=exactNativeProviderArtifactChunkCommand;',{loader:'ts',format:'cjs'}).code;
const ctx=vm.createContext({exports:{},module:{exports:{}},readFileSync,posix,path:{posix},randomUUID,Buffer});vm.runInContext(script,ctx);
const temp=mkdtempSync(join(tmpdir(),'native-artifact-local-'));const target=join(temp,'.paperclip-runtime','paperclip-runner','bin','paperclip-runnerd');
const bytes=Buffer.from(Array.from({length:768*1024+17},(_,i)=>i%251));const input=join(temp,'source');writeFileSync(input,bytes);
const frames=[];const runner={syncIn:async()=>{throw new Error('wrong unbounded Sandbox path');},execute:async call=>{
 const bindingId=randomUUID();const frame={requestId:randomUUID(),bindingId,hostEpoch:1,runId:randomUUID(),attemptId:null,attempt:1,manifestId:randomUUID(),manifestHash:'a'.repeat(64),policySnapshotId:randomUUID(),policyHash:'b'.repeat(64),commandDigest:'c'.repeat(64),deadlineAt:new Date(Date.now()+30000).toISOString(),sandboxRef:'aw-v7-'+bindingId,imageDigest:'fixture.invalid/openshell@sha256:'+'d'.repeat(64),argv:[call.command,...call.args],cwd:temp,env:{},stdinBase64:Buffer.from(call.stdin??'','utf8').toString('base64')};
 const parsed=runtimeSandboxExecRelayRequestSchema.parse(frame);assert(ctx.check({request:parsed,taskRoot:temp}));assert(!ctx.check({request:{...parsed,cwd:temp+'/foreign'},taskRoot:temp}));
 assert(!ctx.check({request:{...parsed,argv:parsed.argv.map(arg=>arg.replaceAll('.paperclip-runtime','foreign-runtime'))},taskRoot:temp}));
 if(call.stdin)assert(!ctx.check({request:{...parsed,argv:parsed.argv.map(arg=>arg.replaceAll('67108864','67108865'))},taskRoot:temp}));
 frames.push(parsed);execFileSync(call.command,call.args,{input:call.stdin??'',cwd:call.cwd});return{exitCode:0,timedOut:false};
}};
try{
 await ctx.module.exports.stageRemoteRunnerFile({target:{kind:'remote',transport:'sandbox',remoteCwd:temp,runner},runner,sourcePath:input,targetPath:target,mode:0o700,nativePreparationPurpose:'provider_artifact'});
 assert.equal(frames.length,6);assert.equal(Math.max(...frames.map(x=>x.stdinBase64.length)),466040);assert.equal(createHash('sha256').update(readFileSync(target)).digest('hex'),createHash('sha256').update(bytes).digest('hex'));
 const former={...frames[1],stdinBase64:Buffer.from(bytes.toString('base64'),'utf8').toString('base64')};assert(!runtimeSandboxExecRelayRequestSchema.safeParse(former).success);assert(!ctx.check({request:former,taskRoot:temp}));
 writeFileSync(root+'/local-validation.json',JSON.stringify({status:'PASS',sourceFunctions:['stageRemoteRunnerFile','stageRemoteArtifactBytesInChunks','exactNativeProviderArtifactChunkCommand'],sourceBytes:bytes.length,frames:frames.length,maxNestedBase64Characters:466040,checks:['real shell reconstructs exact SHA','all frames pass existing shared schema','actual receiver admits exact frames','wrong root rejected','wrong target rejected','modified artifact limit rejected','former single frame rejected by schema and receiver'],scope:'Actual existing source functions executed locally; no Host/model/source-admission qualification claimed'},null,2)+'\n');
 console.log('PASS: real producer/receiver functions, exact reconstruction, typed nested relay bounds, wrong-root/target/limit negatives');
}finally{rmSync(temp,{recursive:true,force:true});}
