#!/usr/bin/env bash
set -uo pipefail
REPO=/workspace/blentera-v10
MIRROR=/workspace/v10-dep-qualification
CAND=/workspace/v10-preparation/v10-149-openshell-outer-controls-r4
OUT=$CAND/qualification-r1
mkdir -m 700 "$OUT" || exit 73
exec 9>/workspace/v10-preparation/v10-pg-tests.lock
flock -x 9
source /workspace/v10-preparation/env.sh
export PATH=/workspace/v10-preparation/pinned-bin:$PATH
cd "$REPO" || exit 70

restore_overlay() {
  python3 - "$CAND/source-pins-r4.json" "$CAND/files" "$MIRROR" "$OUT/restore-files" "$OUT/restore.log" <<'PY'
from pathlib import Path
import hashlib,json,shutil,sys
pins=json.loads(Path(sys.argv[1]).read_text())['files']; cand=Path(sys.argv[2]); mirror=Path(sys.argv[3]); backup=Path(sys.argv[4]); log=Path(sys.argv[5]); failures=[]
for row in pins:
 p=row['path']; target=mirror/p; expected=row['candidate_sha256']; base=row['baseline_sha256']
 actual=hashlib.sha256(target.read_bytes()).hexdigest() if target.is_file() else None
 saved=backup/p
 if actual==expected:
  if not saved.is_file() or hashlib.sha256(saved.read_bytes()).hexdigest()!=base:
   failures.append(f'BASELINE_BACKUP_BAD {p}'); continue
  target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(saved,target)
 elif actual==base:
  pass
 else:
  failures.append(f'RESTORE_GUARD_MISMATCH {p} expected_candidate={expected} expected_baseline={base} actual={actual}')
for row in pins:
 p=row['path']; target=mirror/p; actual=hashlib.sha256(target.read_bytes()).hexdigest() if target.is_file() else None
 if actual!=row['baseline_sha256']: failures.append(f'POST_RESTORE_MISMATCH {p} expected={row["baseline_sha256"]} actual={actual}')
log.write_text('\n'.join(failures) + ('\n' if failures else 'source overlay restored byte-for-byte\n'))
if failures: raise SystemExit(1)
PY
}
restore_build_state() {
  python3 - "$OUT/build-state" "$MIRROR" "$OUT/build-restore.log" <<'PY'
from pathlib import Path
import hashlib,shutil,sys
backup=Path(sys.argv[1]); mirror=Path(sys.argv[2]); log=Path(sys.argv[3]); failures=[]
for name in ('packages/shared/dist','packages/db/dist','server/dist'):
 src=backup/name; dst=mirror/name
 if not src.exists(): continue
 def treehash(root):
  return [(p.relative_to(root).as_posix(),hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(root.rglob('*')) if p.is_file()]
 before=treehash(src)
 if treehash(dst)!=before:
  if dst.exists(): shutil.rmtree(dst)
  shutil.copytree(src,dst)
  if treehash(dst)!=before: failures.append(f'DIST_RESTORE_MISMATCH {name}')
# Restore exact prior tsbuildinfo set and remove any newly-created file under mirror.
prior={p.relative_to(backup/'tsbuildinfo').as_posix():p for p in (backup/'tsbuildinfo').rglob('*') if p.is_file()} if (backup/'tsbuildinfo').exists() else {}
current={p.relative_to(mirror).as_posix():p for p in mirror.rglob('*.tsbuildinfo') if p.is_file()}
for rel,p in current.items():
 if rel not in prior: p.unlink(); continue
 saved=prior[rel]
 if hashlib.sha256(p.read_bytes()).digest()!=hashlib.sha256(saved.read_bytes()).digest(): shutil.copy2(saved,p)
for rel,saved in prior.items():
 target=mirror/rel
 if not target.exists(): target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(saved,target)
 if hashlib.sha256(target.read_bytes()).digest()!=hashlib.sha256(saved.read_bytes()).digest(): failures.append(f'TSBUILDINFO_RESTORE_MISMATCH {rel}')
log.write_text('\n'.join(failures) + ('\n' if failures else 'compiled output and tsbuildinfo restored byte-for-byte\n'))
if failures: raise SystemExit(1)
PY
}
cleanup() {
  if [[ -f "$OUT/overlay-ready" ]] && [[ $(cat "$OUT/overlay-ready") == 1 ]]; then restore_overlay || echo restore_overlay_failed=1 >> "$OUT/restore.log"; fi
  if [[ ${BUILD_BACKUP_READY:-0} == 1 ]]; then restore_build_state || echo restore_build_state_failed=1 >> "$OUT/build-restore.log"; fi
}
trap cleanup EXIT INT TERM

python3 /workspace/v10-preparation/snapshot-current-source-for-dependency-check.py "$OUT/snapshot-source-pins.json" > "$OUT/snapshot.log" 2>&1
rc=$?; printf '%s\n' "$rc" > "$OUT/snapshot.exit"; if ((rc)); then exit "$rc"; fi
node /workspace/v10-preparation/check-snapshot-syntax.cjs "$OUT/snapshot-source-pins.json" > "$OUT/snapshot-syntax.log" 2>&1
rc=$?; printf '%s\n' "$rc" > "$OUT/snapshot-syntax.exit"; if ((rc)); then exit "$rc"; fi

python3 - "$CAND/source-pins-r4.json" "$CAND/files" "$REPO" "$MIRROR" "$OUT/restore-files" "$OUT/overlay-pins.json" <<'PY'
from pathlib import Path
import hashlib,json,shutil,sys
pinpath,candidate,repo,mirror,backup,out=map(Path,sys.argv[1:])
rows=json.loads(pinpath.read_text())['files']; records=[]
for row in rows:
 p=row['path']; main=repo/p; target=mirror/p; cand=candidate/p
 for label,file,expected in [('MAIN baseline',main,row['baseline_sha256']),('mirror snapshot',target,row['baseline_sha256']),('candidate',cand,row['candidate_sha256'])]:
  actual=hashlib.sha256(file.read_bytes()).hexdigest() if file.is_file() else None
  if actual!=expected: raise SystemExit(f'{label} pin mismatch {p}: {actual} != {expected}')
 saved=backup/p; saved.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(target,saved)
 records.append({'path':p,'baseline_sha256':row['baseline_sha256'],'candidate_sha256':row['candidate_sha256']})
(out.parent/'overlay-ready').write_text('0\n')
(out.parent/'overlay-pins.json').write_text(json.dumps({'files':records},indent=2)+'\n')
(out.parent/'overlay-ready').write_text('1\n')
for row in rows:
 p=row['path']; target=mirror/p; cand=candidate/p
 shutil.copy2(cand,target)
 actual=hashlib.sha256(target.read_bytes()).hexdigest()
 if actual!=row['candidate_sha256']: raise SystemExit(f'overlay copy mismatch {p}: {actual}')
PY
rc=$?; if ((rc)); then exit "$rc"; fi
OVERLAY_READY=1

mkdir -p "$OUT/build-state"
for d in packages/shared/dist packages/db/dist server/dist; do
  if [[ -d "$MIRROR/$d" ]]; then mkdir -p "$OUT/build-state/$(dirname "$d")"; cp -a "$MIRROR/$d" "$OUT/build-state/$d"; fi
done
mkdir -p "$OUT/build-state/tsbuildinfo"
find "$MIRROR" -name '*.tsbuildinfo' -type f -print0 | while IFS= read -r -d '' f; do rel=${f#"$MIRROR/"}; mkdir -p "$OUT/build-state/tsbuildinfo/$(dirname "$rel")"; cp -a "$f" "$OUT/build-state/tsbuildinfo/$rel"; done
BUILD_BACKUP_READY=1

run_step() {
  local name="$1"; shift
  "$@" > "$OUT/$name.log" 2>&1
  local rc=$?
  printf '%s\n' "$rc" > "$OUT/$name.exit"
  return 0
}
run_step host-agent node --test "$CAND/files/deploy/v6/host-agent/openshell.test.mjs"
cd "$MIRROR" || exit 70
run_step shared-typecheck pnpm --filter @paperclipai/shared typecheck
cd "$MIRROR/server" || exit 70
run_step auth-policy-backend-tests pnpm exec vitest run src/__tests__/agent-auth-jwt.test.ts src/__tests__/v7-sandbox-policy.test.ts src/__tests__/v7-openshell-backend.test.ts --maxWorkers=1 --reporter=verbose
run_step tool-gateway-broker-test pnpm exec vitest run src/__tests__/tool-gateway.test.ts -t 'resolves broker bindings from the current run grant and assigned gateway without returning secrets' --maxWorkers=1 --reporter=verbose
run_step sandbox-host-integration pnpm exec vitest run src/__tests__/v7-sandbox-host-bridge.integration.test.ts --maxWorkers=1 --reporter=verbose
run_step server-typecheck pnpm exec tsc --noEmit --singleThreaded
python3 - "$OUT" <<'PY'
from pathlib import Path
import json,sys
out=Path(sys.argv[1]); checks=['host-agent','shared-typecheck','auth-policy-backend-tests','tool-gateway-broker-test','sandbox-host-integration','server-typecheck']
rows={name:int((out/f'{name}.exit').read_text().strip()) for name in checks}
(out/'result.json').write_text(json.dumps(rows,indent=2)+'\n')
print(rows)
PY
