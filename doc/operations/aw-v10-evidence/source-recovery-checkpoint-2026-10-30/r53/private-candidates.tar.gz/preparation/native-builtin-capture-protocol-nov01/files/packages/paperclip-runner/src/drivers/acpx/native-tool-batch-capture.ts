import { createHash, randomUUID } from "node:crypto";

import type {
  AcpxNativeToolBatchCaptureAck,
  AcpxNativeToolBatchCaptureRequest,
} from "./sidecar-protocol.js";

export const ACPX_NATIVE_TOOL_BATCH_CAPTURE_TIMEOUT_MS = 45_000;
export const ACPX_NATIVE_TOOL_BATCH_CAPTURE_MAX_BYTES = 220 * 1024;
export const ACPX_NATIVE_TOOL_BATCH_CAPTURE_MAX_PENDING = 8;

export interface NativeToolBatchCapturePending {
  captureId: string;
  runId: string;
  turnId: string;
  capture: AcpxNativeToolBatchCaptureRequest;
}

interface PendingCapture extends NativeToolBatchCapturePending {
  resolve(value: AcpxNativeToolBatchCaptureAck): void;
  reject(error: Error): void;
  cleanup(): void;
}

export interface NativeToolBatchCaptureResolution {
  captureId: string;
  runId: string;
  turnId: string;
  accepted: boolean;
  receiptDigest?: string;
  code?: string;
}

export class NativeToolBatchCaptureBridge {
  readonly #pending = new Map<string, PendingCapture>();

  get pendingCount(): number {
    return this.#pending.size;
  }

  request(input: {
    runId: string;
    turnId: string;
    request: AcpxNativeToolBatchCaptureRequest;
    signal: AbortSignal;
    publish(capture: NativeToolBatchCapturePending): void;
    timeoutMs?: number;
  }): Promise<AcpxNativeToolBatchCaptureAck> {
    const request = normalizeNativeToolBatchCaptureRequest(input.request);
    const timeoutMs = input.timeoutMs ?? ACPX_NATIVE_TOOL_BATCH_CAPTURE_TIMEOUT_MS;
    if (!isStableCaptureIdentity(input.runId) || !isStableCaptureIdentity(input.turnId)) {
      throw new Error("native_tool_batch_capture_binding_invalid");
    }
    if (
      !Number.isSafeInteger(timeoutMs) ||
      timeoutMs < 1 ||
      timeoutMs > ACPX_NATIVE_TOOL_BATCH_CAPTURE_TIMEOUT_MS
    ) {
      throw new Error("native_tool_batch_capture_deadline_invalid");
    }
    if (input.signal.aborted) {
      throw input.signal.reason instanceof Error
        ? input.signal.reason
        : new Error("native_tool_batch_capture_cancelled");
    }
    if (this.#pending.size >= ACPX_NATIVE_TOOL_BATCH_CAPTURE_MAX_PENDING) {
      throw new Error("native_tool_batch_capture_pending_limit");
    }
    const captureId = randomUUID();
    return new Promise<AcpxNativeToolBatchCaptureAck>((resolve, reject) => {
      const settle = (operation: () => void): void => {
        if (!this.#pending.delete(captureId)) return;
        cleanup();
        operation();
      };
      const timer = setTimeout(() => {
        settle(() => reject(new Error("native_tool_batch_capture_timeout")));
      }, timeoutMs);
      timer.unref?.();
      const onAbort = (): void => {
        settle(() => reject(new Error("native_tool_batch_capture_cancelled")));
      };
      const cleanup = (): void => {
        clearTimeout(timer);
        input.signal.removeEventListener("abort", onAbort);
      };
      const pending: PendingCapture = {
        captureId,
        runId: input.runId,
        turnId: input.turnId,
        capture: request,
        resolve: (ack) => settle(() => resolve(ack)),
        reject: (error) => settle(() => reject(error)),
        cleanup,
      };
      this.#pending.set(captureId, pending);
      input.signal.addEventListener("abort", onAbort, { once: true });
      if (input.signal.aborted) {
        onAbort();
        return;
      }
      try {
        input.publish({
          captureId,
          runId: input.runId,
          turnId: input.turnId,
          capture: request,
        });
      } catch {
        settle(() => reject(new Error("native_tool_batch_capture_publish_failed")));
      }
    });
  }

  resolve(input: NativeToolBatchCaptureResolution): { resolved: true } {
    const pending = this.#pending.get(input.captureId);
    if (!pending) throw new Error("native_tool_batch_capture_unknown_or_replayed");
    if (pending.runId !== input.runId || pending.turnId !== input.turnId) {
      throw new Error("native_tool_batch_capture_ack_scope_mismatch");
    }
    if (input.accepted) {
      if (!isSha256Prefix(input.receiptDigest)) {
        throw new Error("native_tool_batch_capture_ack_digest_invalid");
      }
      pending.resolve({ accepted: true, receiptDigest: input.receiptDigest });
    } else {
      const code = input.code;
      pending.reject(new Error(
        code && /^[a-z0-9_]{1,96}$/.test(code)
          ? `native_tool_batch_capture_rejected:${code}`
          : "native_tool_batch_capture_rejected",
      ));
    }
    return { resolved: true };
  }

  rejectTurn(runId: string, turnId: string, reason = "native_tool_batch_capture_turn_ended"): void {
    for (const pending of this.#pending.values()) {
      if (pending.runId === runId && pending.turnId === turnId) {
        pending.reject(new Error(reason));
      }
    }
  }

  rejectAll(reason = "native_tool_batch_capture_bridge_closed"): void {
    for (const pending of this.#pending.values()) pending.reject(new Error(reason));
  }
}

function normalizeNativeToolBatchCaptureRequest(
  value: AcpxNativeToolBatchCaptureRequest,
): AcpxNativeToolBatchCaptureRequest {
  if (!isRecord(value) || !isBoundedText(value.sessionId, 160) || !isRecord(value.sdkHookInput)) {
    throw new Error("native_tool_batch_capture_request_invalid");
  }
  if (value.phase === "pre") {
    if (!exactKeys(value, ["phase", "sessionId", "sdkHookInput", "sdkHookToolUseId", "toolUseId", "toolName", "toolInput", "workspaceWitness"])) {
      throw new Error("native_tool_batch_capture_request_invalid");
    }
    if (!isBoundedText(value.sdkHookToolUseId, 240) ||
        value.sdkHookInput.hook_event_name !== "PreToolUse" ||
        !isBoundedText(value.sdkHookInput.tool_name, 160) ||
        !isBoundedText(value.sdkHookInput.tool_use_id, 240) ||
        value.sdkHookInput.tool_use_id !== value.sdkHookToolUseId ||
        value.toolUseId !== value.sdkHookToolUseId ||
        value.toolName !== value.sdkHookInput.tool_name ||
        !isBoundedText(value.toolName, 160) ||
        !jsonValueEquals(value.toolInput, value.sdkHookInput.tool_input)) {
      throw new Error("native_tool_batch_capture_pre_hook_invalid");
    }
    validateWorkspaceWitness(value.workspaceWitness);
  } else if (value.phase === "post") {
    if (!exactKeys(value, ["phase", "sessionId", "sdkHookInput", "toolUseIds", "workspaceWitness", "preReceiptDigests"])) {
      throw new Error("native_tool_batch_capture_request_invalid");
    }
    if (!Array.isArray(value.toolUseIds) || value.sdkHookInput.hook_event_name !== "PostToolBatch" ||
        !Array.isArray(value.sdkHookInput.tool_calls) ||
        value.sdkHookInput.tool_calls.length < 1 || value.sdkHookInput.tool_calls.length > 128 ||
        !isRecord(value.preReceiptDigests)) {
      throw new Error("native_tool_batch_capture_post_hook_invalid");
    }
    const toolIds = value.sdkHookInput.tool_calls.map((call) => {
      if (!isRecord(call) || !exactKeys(call, ["tool_name", "tool_input", "tool_use_id"], ["tool_response"]) ||
          !isBoundedText(call.tool_name, 160) || !isBoundedText(call.tool_use_id, 240)) {
        throw new Error("native_tool_batch_capture_tool_tuple_invalid");
      }
      return call.tool_use_id;
    });
    if (new Set(toolIds).size !== toolIds.length ||
        JSON.stringify(value.toolUseIds) !== JSON.stringify(toolIds) ||
        Object.keys(value.preReceiptDigests).length !== toolIds.length) {
      throw new Error("native_tool_batch_capture_batch_binding_invalid");
    }
    for (const toolId of toolIds) {
      if (!isSha256Prefix(value.preReceiptDigests[toolId])) throw new Error("native_tool_batch_capture_pre_receipt_invalid");
    }
    validateWorkspaceWitness(value.workspaceWitness);
  } else {
    throw new Error("native_tool_batch_capture_phase_invalid");
  }
  let serialized: string;
  try {
    serialized = JSON.stringify(value);
  } catch {
    throw new Error("native_tool_batch_capture_request_unserializable");
  }
  if (!serialized || Buffer.byteLength(serialized) > ACPX_NATIVE_TOOL_BATCH_CAPTURE_MAX_BYTES) {
    throw new Error("native_tool_batch_capture_request_exceeds_limit");
  }
  try {
    return JSON.parse(serialized) as AcpxNativeToolBatchCaptureRequest;
  } catch {
    throw new Error("native_tool_batch_capture_request_unserializable");
  }
}

function validateWorkspaceWitness(value: unknown): void {
  if (!isRecord(value) || value.schema !== "paperclip.native-workspace-witness.v1" ||
      !isSha256Prefix(value.workspaceRootDigest) ||
      !isSha256Prefix(value.snapshotDigest) ||
      !Number.isSafeInteger(value.fileCount) || (value.fileCount as number) < 0 ||
      (value.fileCount as number) > 512 || !Number.isSafeInteger(value.totalBytes) ||
      (value.totalBytes as number) < 0 || (value.totalBytes as number) > 64 * 1024 ||
      !Array.isArray(value.files) || value.files.length !== value.fileCount ||
      !Array.isArray(value.excludedSymlinks) || value.excludedSymlinks.length !== 0) {
    throw new Error("native_tool_batch_capture_workspace_witness_invalid");
  }
  let totalBytes = 0;
  let previousPath: string | undefined;
  for (const file of value.files) {
    if (!isRecord(file) || !exactKeys(file, ["relativePath", "sha256", "size", "contentBase64", "device", "inode", "mtimeMs"]) ||
        !isBoundedText(file.relativePath, 4096) || file.relativePath.startsWith("/") ||
        file.relativePath.split("/").some((part) => part === ".." || part === ".") ||
        !isSha256(file.sha256) || !Number.isSafeInteger(file.size) ||
        (file.size as number) < 0 || typeof file.contentBase64 !== "string" ||
        !Number.isSafeInteger(file.device) || (file.device as number) < 0 ||
        !Number.isSafeInteger(file.inode) || (file.inode as number) < 0 ||
        typeof file.mtimeMs !== "number" || !Number.isFinite(file.mtimeMs) || file.mtimeMs < 0 ||
        (previousPath !== undefined && file.relativePath <= previousPath)) {
      throw new Error("native_tool_batch_capture_workspace_file_invalid");
    }
    previousPath = file.relativePath;
    if (!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(file.contentBase64)) {
      throw new Error("native_tool_batch_capture_workspace_file_encoding_invalid");
    }
    const content = Buffer.from(file.contentBase64 as string, "base64");
    if (content.toString("base64") !== file.contentBase64 || content.byteLength !== file.size ||
        createHash("sha256").update(content).digest("hex") !== file.sha256) {
      throw new Error("native_tool_batch_capture_workspace_file_digest_invalid");
    }
    totalBytes += content.byteLength;
  }
  const digestInput = value.files.map((file) => ({
    path: file.relativePath,
    hash: file.sha256,
    size: file.size,
  }));
  const snapshotDigest = `sha256:${createHash("sha256").update(canonicalNativeJson(digestInput)).digest("hex")}`;
  if (totalBytes !== value.totalBytes || snapshotDigest !== value.snapshotDigest) {
    throw new Error("native_tool_batch_capture_workspace_digest_invalid");
  }
}

function canonicalNativeJson(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonicalNativeJson).join(",")}]`;
  if (typeof value === "object" && value !== null) {
    const record = value as Record<string, unknown>;
    return `{${Object.keys(record)
      .filter((key) => record[key] !== undefined)
      .sort()
      .map((key) => `${JSON.stringify(key)}:${canonicalNativeJson(record[key])}`)
      .join(",")}}`;
  }
  return JSON.stringify(value) ?? "null";
}

function jsonValueEquals(left: unknown, right: unknown): boolean {
  try {
    return JSON.stringify(left) === JSON.stringify(right);
  } catch {
    return false;
  }
}

function isSha256Prefix(value: unknown): value is string {
  return typeof value === "string" && /^sha256:[a-f0-9]{64}$/.test(value);
}

function isStableCaptureIdentity(value: string): boolean {
  return /^[A-Za-z0-9][A-Za-z0-9._:-]{0,239}$/.test(value);
}

function isBoundedText(value: unknown, maximumLength: number): value is string {
  return typeof value === "string" && value.length > 0 && value.length <= maximumLength;
}

function isSha256(value: unknown): value is string {
  return typeof value === "string" && /^[a-f0-9]{64}$/.test(value);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function exactKeys(
  value: Record<string, unknown>,
  keys: readonly string[],
  optional: readonly string[] = [],
): boolean {
  const allowed = new Set([...keys, ...optional]);
  const present = Object.keys(value);
  return present.length >= keys.length && present.every((key) => allowed.has(key)) &&
    keys.every((key) => Object.hasOwn(value, key));
}
