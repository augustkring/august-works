import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createRequire } from "node:module";

const requireFromServer = createRequire("/workspace/blentera-v10/server/package.json");
const esbuild = requireFromServer("esbuild");
const acorn = requireFromServer("acorn");
const sourcePath = "/workspace/v10-preparation/host-runner-closure-witness-r16/files/server/src/__tests__/helpers/managed-native-conversation-sandbox-host.ts";
const sourceText = readFileSync(sourcePath, "utf8");
const compiled = esbuild.transformSync(sourceText, { loader: "ts", format: "esm" }).code;
const sourceFile = acorn.parse(compiled, { ecmaVersion: "latest", sourceType: "module" });

function initializerFor(name, requiredFragment) {
  const found = [];
  const visit = (node) => {
    if (!node || typeof node !== "object") return;
    if (node.type === "VariableDeclarator" && node.id?.type === "Identifier" && node.id.name === name && node.init) {
      const text = compiled.slice(node.init.start, node.init.end);
      if (text.includes(requiredFragment)) found.push(text);
    }
    for (const value of Object.values(node)) {
      if (Array.isArray(value)) value.forEach(visit);
      else if (value && typeof value === "object") visit(value);
    }
  };
  visit(sourceFile);
  assert.equal(found.length, 1, `expected exactly one source initializer for ${name}`);
  return found[0];
}

// Evaluate the actual two predicates from the fixture source. This control does
// not reimplement the matching logic in the test.
const startedExpression = initializerFor("started", "modelBrokerSessionReceipts.some");
const stoppedExpression = initializerFor("stopped", "closureWitness.startBindingDigest");
const startedFromSource = new Function("modelBrokerSessionReceipts", "descriptor", `return ${startedExpression};`);
const stoppedFromSource = new Function("started", "stoppedReceipt", "closureWitness", "descriptor", `return ${stoppedExpression};`);

const descriptor = {
  sessionKey: "session-key",
  sessionDigest: "a".repeat(64),
  startBindingDigest: "b".repeat(64),
  runId: "run-1",
  taskRoot: "/workspace/task",
  runnerInstanceId: "runner-1",
  leaseId: "lease-1",
};
const startReceipt = {
  phase: "start",
  sessionKey: descriptor.sessionKey,
  nativeSessionIdDigest: descriptor.sessionDigest,
  startBindingDigest: descriptor.startBindingDigest,
};
const witness = {
  phase: "stop_observed",
  stopReceiptMatched: true,
  sessionKey: descriptor.sessionKey,
  sessionDigest: descriptor.sessionDigest,
  runId: descriptor.runId,
  taskRoot: descriptor.taskRoot,
  runnerId: descriptor.runnerInstanceId,
  leaseId: descriptor.leaseId,
  startBindingDigest: descriptor.startBindingDigest,
  expectedCapabilityHash: "c".repeat(64),
  sessionDeadlineAt: "2030-01-01T00:00:00.000Z",
};
// The stop wire receipt correctly has no startBindingDigest: that field is
// start-only. Its capability receipt is tied to the independently observed
// stop witness and original start provenance.
const stopReceipt = {
  phase: "stop",
  sessionKey: descriptor.sessionKey,
  nativeSessionIdDigest: descriptor.sessionDigest,
  capabilityHash: witness.expectedCapabilityHash,
  sessionDeadlineAt: witness.sessionDeadlineAt,
  startBindingDigest: null,
};

const startMatches = startedFromSource([startReceipt, stopReceipt], descriptor);
assert.equal(startMatches, true, "original signed start receipt binds the start-only digest");
assert.equal(stoppedFromSource(startMatches, stopReceipt, witness, descriptor), true,
  "matching stop receipt and process witness accept without a stop-wire start digest");

const stopCases = [
  ["missing original start", false, stopReceipt, witness, descriptor],
  ["missing stop receipt", startMatches, null, witness, descriptor],
  ["missing stop witness", startMatches, stopReceipt, null, descriptor],
  ["unobserved stop", startMatches, stopReceipt, { ...witness, phase: "alive_observed" }, descriptor],
  ["unmatched stop receipt", startMatches, { ...stopReceipt, capabilityHash: "d".repeat(64) }, witness, descriptor],
  ["wrong stop deadline", startMatches, { ...stopReceipt, sessionDeadlineAt: "2030-01-02T00:00:00.000Z" }, witness, descriptor],
  ["wrong session digest", startMatches, stopReceipt, { ...witness, sessionDigest: "e".repeat(64) }, descriptor],
  ["wrong start digest", startMatches, stopReceipt, { ...witness, startBindingDigest: "f".repeat(64) }, descriptor],
  ["wrong run", startMatches, stopReceipt, { ...witness, runId: "run-2" }, descriptor],
  ["wrong task root", startMatches, stopReceipt, { ...witness, taskRoot: "/workspace/other" }, descriptor],
  ["wrong runner", startMatches, stopReceipt, { ...witness, runnerId: "runner-2" }, descriptor],
  ["wrong lease", startMatches, stopReceipt, { ...witness, leaseId: "lease-2" }, descriptor],
];
for (const [name, started, receipt, processWitness, target] of stopCases) {
  assert.equal(stoppedFromSource(started, receipt, processWitness, target), false, `${name} must fail closed`);
}

const wrongStartReceipt = { ...startReceipt, startBindingDigest: "0".repeat(64) };
assert.equal(startedFromSource([wrongStartReceipt], descriptor), false, "wrong start digest must fail closed");
console.log(JSON.stringify({ control: "start-only-digest-to-stop-witness", positive: 1, negatives: stopCases.length + 1 }));
