#!/usr/bin/env bash
set -euo pipefail
OUT=/workspace/v10-preparation/v10-069-private-r4-attempt3-20261030
CAND=/workspace/v10-preparation/v10-069-private-candidate-r4
MIRROR=/workspace/v10-dep-qualification
exec 9>/workspace/v10-preparation/v10-pg-tests.lock
flock -x 9
python3 - "$OUT" "$CAND" "$MIRROR" <<'PY'
import hashlib,json,sys
from pathlib import Path
out,cand,mirror=map(Path,sys.argv[1:])
candidate={}
baseline={}
for line in (cand/'candidate-source-pins.sha256').read_text().splitlines():
    sha,rel=line.split(None,1); candidate[rel.strip()]=sha
for line in (out/'mirror-baseline-pins.sha256').read_text().splitlines():
    sha,rel=line.split(None,1); baseline[rel.strip()]=sha
if set(candidate)!=set(baseline): raise SystemExit('candidate/baseline path sets differ')
states=[]
for rel,want_candidate in candidate.items():
    path=mirror/rel
    actual=hashlib.sha256(path.read_bytes()).hexdigest()
    want_baseline=baseline[rel]
    if actual not in (want_candidate,want_baseline):
        raise SystemExit(f'REFUSE unexpected mirror bytes {rel}: {actual}')
    states.append({'path':rel,'beforeSha256':actual,'state':'candidate' if actual==want_candidate else 'baseline'})
for row in states:
    if row['state']=='candidate':
        rel=row['path']; (mirror/rel).write_bytes((out/'mirror-baseline'/rel).read_bytes())
final=[]
for rel,want in baseline.items():
    actual=hashlib.sha256((mirror/rel).read_bytes()).hexdigest()
    if actual!=want: raise SystemExit(f'RESTORE_VERIFY_FAIL {rel}: {actual} != {want}')
    final.append({'path':rel,'sha256':actual})
r5='server/src/services/experience/private-0565/member-continuity-preflight.ts'
r5sha=hashlib.sha256((mirror/r5).read_bytes()).hexdigest()
expected='792f451a52cffd83550105c371e281c999c699ffaf792076d6756f13a3bc0daf'
if r5sha!=expected: raise SystemExit(f'R5 module changed unexpectedly: {r5sha}')
compiled=out/'compiled-output-restored.sha256'
actual_compiled=[]
for rel in sorted(p.relative_to(mirror).as_posix() for base in ('packages/db/dist','packages/shared/dist') for p in (mirror/base).rglob('*') if p.is_file()):
    actual_compiled.append(f"{hashlib.sha256((mirror/rel).read_bytes()).hexdigest()}  {rel}\n")
actual_compiled=''.join(actual_compiled).encode()
if not compiled.is_file() or actual_compiled!=(out/'compiled-output-baseline.sha256').read_bytes():
    raise SystemExit('compiled DB/shared outputs do not match baseline manifest')
receipt={'format':'guarded-r4-overlay-restoration-v1','qualification':'R4 source and tests remain as recorded in this attempt; no source change or rerun','mirror':str(mirror),'trackedPaths':states,'finalBaselinePins':final,'r5Module':{'path':r5,'sha256':r5sha},'compiledOutputManifestMatched':True}
(out/'guarded-restoration-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('GUARDED_R4_RESTORE_OK paths=%d r5=%s compiled_manifest=match' % (len(final),r5sha))
PY
