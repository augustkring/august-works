from pathlib import Path
import os,stat,hashlib,json,tarfile,gzip,time,shutil
src=Path('/tmp/paperclip-runner-provider-pack-1c8d7db6c4042bb084fb')
out=Path('/tmp/blentera-generated-cache-recovery-20261101');out.mkdir(exist_ok=True)
archive=out/(src.name+'.tar.gz');manifest=out/(src.name+'.manifest.json')
receipt=Path('/workspace/v10-preparation/old-provider-pack-archive-receipt-20261101.json')
assert src.is_dir() and not src.is_symlink() and not archive.exists() and not receipt.exists()
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
rows=[]
for p in [src,*sorted(src.rglob('*'))]:
 s=p.lstat();rel='.' if p==src else p.relative_to(src).as_posix()
 row={'path':rel,'mode':stat.S_IMODE(s.st_mode),'mtimeNs':s.st_mtime_ns}
 if stat.S_ISREG(s.st_mode):row.update(kind='file',bytes=s.st_size,sha256=digest(p))
 elif stat.S_ISDIR(s.st_mode):row.update(kind='directory')
 elif stat.S_ISLNK(s.st_mode):row.update(kind='symlink',target=os.readlink(p))
 else:raise RuntimeError(('unexpected file kind',str(p)))
 rows.append(row)
manifest.write_text(json.dumps({'purpose':'lossless recovery of reproducible generated provider cache; not source qualification','originalPath':str(src),'entries':rows},indent=2)+'\n')
print(json.dumps({'phase':'manifest','entries':len(rows),'inputBytes':sum(r.get('bytes',0) for r in rows)}),flush=True)
with archive.open('xb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',compresslevel=1,mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w|') as tar:
 for r in rows:
  p=src if r['path']=='.' else src/r['path'];i=tarfile.TarInfo(r['path']);i.mode=r['mode'];i.mtime=r['mtimeNs']/1e9
  if r['kind']=='directory':i.type=tarfile.DIRTYPE;tar.addfile(i)
  elif r['kind']=='symlink':i.type=tarfile.SYMTYPE;i.linkname=r['target'];tar.addfile(i)
  else:
   i.size=r['bytes']
   with p.open('rb') as f:tar.addfile(i,f)
print(json.dumps({'phase':'archive-written','bytes':archive.stat().st_size}),flush=True)
expected={r['path']:r for r in rows};seen=set()
with tarfile.open(archive,'r:gz') as tar:
 for i in tar:
  r=expected[i.name];assert i.name not in seen;seen.add(i.name);assert i.mode==r['mode']
  if r['kind']=='file':
   assert i.isfile() and i.size==r['bytes'];h=hashlib.sha256();f=tar.extractfile(i)
   for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
   assert h.hexdigest()==r['sha256']
  elif r['kind']=='directory':assert i.isdir()
  else:assert i.issym() and i.linkname==r['target']
assert seen==set(expected)
# Compare original identity and content again before deleting this generated cache.
for r in rows:
 p=src if r['path']=='.' else src/r['path'];s=p.lstat();assert stat.S_IMODE(s.st_mode)==r['mode'] and s.st_mtime_ns==r['mtimeNs']
 if r['kind']=='file':assert s.st_size==r['bytes'] and digest(p)==r['sha256']
 elif r['kind']=='symlink':assert os.readlink(p)==r['target']
result={'purpose':'generated dependency/provider cache archive only; no user source or qualification receipt removed','originalPath':str(src),'archive':str(archive),'archiveBytes':archive.stat().st_size,'archiveSha256':digest(archive),'manifest':str(manifest),'manifestSha256':digest(manifest),'entries':len(rows),'originalBytes':sum(r.get('bytes',0) for r in rows),'archiveVerified':True,'originalContentReverified':True,'removedExtractedCache':False}
receipt.write_text(json.dumps(result,indent=2)+'\n')
shutil.rmtree(src)
result['removedExtractedCache']=True;receipt.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
