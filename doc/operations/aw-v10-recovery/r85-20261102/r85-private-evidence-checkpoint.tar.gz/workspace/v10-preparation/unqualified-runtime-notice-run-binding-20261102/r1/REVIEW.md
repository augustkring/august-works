# PRIVATE ACP unavailable-runtime notice targeting correction

Source-only against003404c031dad874db43aa1ad8c07e80568bdd17. One existing fixture changes; no product fields, authority, timeouts, browser/SDK/DB/compiler execution or Main/Mirror writes.

## Actual evidence and exact race

Root's authentic prior62 whole E2E8 log `/dev/shm/ci-e2e8-head62ce903-20261102.log` records26PASS/1FAIL. The failure is ACP Interrupt's SECOND assertUnqualifiedRuntime call (spec40), after its first call already expanded the first unavailable notice. It reaches the new failed Run detailGET at14:19:15.063 and the browser commentsGET completes14:19:15.122, then fails missing Runtime settings link at14:19:20.411. No missing-product-link conclusion follows: the other two ACP variants using this helper passed.

The current helper's dynamic text `.last()` locator can first resolve to the old already-expanded notice while the new failed Run's system comment is still arriving. Its one-time aria-expanded check then skips the click. The SAME locator resolves again during the link assertion; after append it can address the newly collapsed notice. TaskChatSystemNotice.tsx initializes independent open state per item and only mounts Markdown/link when open. This proves a source-level race consistent with the actual failing second invocation; the raw log is not a DOM snapshot, so the exact browser interleaving is not claimed directly observed.

## Existing identity reused

No caller issueId parameter is needed. The real detail endpoint in routes/agents.ts6847 returns heartbeat.getRun's persisted columns; publicRun718 strips only runnerProfileJson/nativeInputSourceProtocolVersion. `heartbeat_runs.issue_id` already exists (schema28) and public HeartbeatRun.issueId is retained (shared heartbeat162), even for legacy pre-dispatch failures. The fixture explicitly asserts the actual detail's id/company/Agent/status/errorCode and nonnull retained issueId before using it. It does not infer Native selection or require nativeIssueId for an unqualified legacy profile.

Recovery's buildStrandedRecoveryEscalationNotice writes existing metadata.sourceRunId (stranded-notice246); its raw presentation title is Configuration incomplete. System comment IDs feed the existing chat adapter id/renderKey and TaskChatThreadView's `id=comment-<item.id>` wrapper in both presentation modes. The candidate polls the exact Task's public comments for ONE current-Run/system/configuration notice and binds that existing DOM wrapper. No `.last()`, count-based old notice guess, new product attribute, manufactured comment or old-Run fallback is introduced. If recovery deduplication leaves no exact current-Run notice, this assertion deliberately fails rather than silently claiming the old notice proves the new attempt.

The original30s notice budget is captured ONCE and shared by the durable-comment poll, DOM visibility, aria read/click/assert and link check. The link retains its original maximum5s and exact href suffix; it is also capped by remaining notice budget. No blanket increase. All original structured owner/reason/actionUrl, processPid/processStartedAt null, no Answered text, no Stop and returned Run guards remain. The three existing ACP cases and their ENOENT/session/write/tree assertions are unchanged. Composer Stop and legacy continuation are the only other caller files (five call sites total across three files); all unchanged.

## Meaningful qualification plan (NOT RUN)

1. Actual first unavailable Run/notice expanded, then a real second failed Run. Delay only the browser's actual current Task commentsGET via route.fetch until the old notice is visible; keep the helper's real API read/current sourceRun binding. Assert the helper waits for and expands the second comment anchor, never old notice. No fake auth/Run response.
2. Append a different same-title notice after selecting the current comment: exact anchor must stay on the current Run; no dynamic last-row retarget.
3. Missing or duplicate exact current-Run comment must fail; foreign Task/company/Agent/run provenance cannot substitute. A present current notice without the exact runtime link still fails. Shared notice deadline remains30s.
4. Run whole original ACP three-case file after source review, then other affected caller files in their existing CI partitions. Retain actual failed admission rows and no process/session/tool-file assertions; do not misreport this as no Run created.

No checks were executed for this candidate beyond source reading/hash/diff generation. Kernel diagnostics/CI actual results retain priority over any browser work.
